# Gates: feature-events-lifecycle (направление В — события: полный цикл, приказ «Б потом В потом Г»)

OWNS: specs/feature-events-lifecycle/**, worklog.md (запись В)
TOUCHES: src/components/events/**, src/app/api/events/[id]/rsvp/route.ts, worklog.md

Scope: замкнуть цикл событий. Бэкенд уже закалён (fix-adversarial ADV-B112: withRoute+zod,
SSRF-гейт, санитайзер, Pro-гейт 403; RSVP с лимитами и идемпотентностью). Не хватает:
(1) UI-создания — кнопка-обещание ведёт в пустой просмотр; (2) живой обратной связи
организатору. Live-доставка едет по рельсам направления Б (notifyNotificationNew), новый
транспорт НЕ строится.

## Gates

- G1 LEDGER_FIRST: этот ledger написан ДО реализации.
- G2 CREATE_UI: в events-view — кнопка «Создать событие» + диалог-форма (title, description,
  format, category, startDate, endDate, location, maxParticipants). Pro-гейт в UI:
  subscriptionTier==='free' → создание недоступно С ОБЪЯСНЕНИЕМ (доступно на Pro/Business),
  вызова API нет. Submit → POST /api/events; 201 → toast + обновление списка; ошибки API
  (403 тариф, 422 даты/URL) показываются пользователю понятным текстом.
- G3 RSVP_NOTIFY: POST /api/events/[id]/rsvp после успешного RSVP создаёт организатору
  notification (type='event_rsvp') ТОЛЬКО при первом RSVP участника (повторные смены статуса —
  без спама) и шлёт live-пуш через notifyNotificationNew (транспорт Б). RSVP-логика
  EventService (лимиты мест, идемпотентность) не меняется.
- G4 TRANSPORT_ONLY: канон — REST; сокет — только доставка; при недоступности chat-service
  всё деградирует без ошибок.
- G5 E2E_LIVE: (а) free-гейт: у Ивана (free) создание недоступно с объяснением; (б) promote
  Ивана → pro: событие создаётся через UI-диалог, появляется в списке; (в) RSVP от пира B на
  новое событие → у Ивана live: бейдж +1 и тост; (г) откат Ивана → free, тестовое событие и
  тестовые уведомления вычищены из БД.
- G6 REGRESSION: bun run lint = 0; tsc --noEmit = 0; bun test tests/ = 44/0;
  adversarial = 43 BLOCKED / 0 EXPLOITED.
- G7 WORKLOG: запись «Task ID: feature-events-lifecycle (В)» после ревёрча.
