# Adversarial Review — BizON Red Team Report

> **СТАТУС (обновление после fix-adversarial): ВСЕ 16 EXPLOITED ИСПРАВЛЕНЫ.**
> Повторный прогон сьюта: **43 BLOCKED / 0 EXPLOITED** (43 pass / 0 fail).
> Регресс-щит зелёный: юнит 44/0 · E2E 12/12 · tsc 0 · lint 0 · браузерный золотой путь OK.
> Детали фиксов и маппинг «находка → фикс» — в разделе 8 и specs/fix-adversarial/GATES.md.

**Дата:** 2026-09-18 · **Приказ владельца** (trace 1a0b3473dee710fd): «Проведи адверсариальное ревью bizon. Запусти саб-агента, его единственная цель — доказать, что bizon ломается. Каждую атаку воспроизвести тестом. Ничего не чинить. По окончанию подготовь отчёт».

**Ничего не починено.** `git status --porcelain -- src/ prisma/ db/` = пусто на момент отчёта. Все находки — падающие тесты в `adversarial/*.test.ts` (доказательства), основной юнит-сьют цел (44/0).

---

## 1. Методология

- **3 саб-агента-адверсария** (parallel): A — auth/IDOR/привилегии; B — инъекции/валидация; C — бизнес-логика/состояния/устойчивость.
- **Протокол вердиктов** (`adversarial/helpers.ts`): каждая атака — тест. `BLOCKED` — защита сработала (тест зелёный); `EXPLOITED` — атака успешна, `verdict()` бросает → тест падает = доказательство уязвимости. Тесты намеренно оставлены красными.
- **Изоляция:** каждый прогон — копия `db/custom.db` в tmpdir (атаки не портят реальную базу); белый ящик — прямые вызовы route-хендлеров (auth-гейты getUserFromRequest — реальные, читают куку из Request).
- **Runner:** `node tools/adversarial/run.mjs` — прогон каждого файла отдельным процессом bun (изоляция tmp-БД), сводка вердиктов, exit 0 (репорт-режим).
- **Прогон повторён независимо** главным агентом после саб-агентов — результаты воспроизведены 1:1 (43 пробы, те же вердикты).

## 2. Итог

| Метрика | Значение |
|---|---|
| Атакующих проб (тестов с вердиктом) | **43** |
| **EXPLOITED** (BizON сломался) | **16** |
| **BLOCKED** (защита сработала) | **27** |
| Severity EXPLOITED | critical ×2, high ×4, medium ×9, low ×1 |
| Файлы-доказательства | `adversarial/adv-auth.test.ts` (15), `adv-injection.test.ts` (12), `adv-logic.test.ts` (16) |

**Главный паттерн:** корень большинства прорывов — **легаси-контур роутов вне withRoute-конвейера** (`POST /api/projects`, `GET /api/projects/[id]` без фильтра visibility, `GET/POST /api/posts`, `/api/events`, `/api/search`, `/api/users/[id]/persona`): без zod-валидации → 500 на мусорных входах, без auth/фильтров → утечки, без лимитов → фермы.

## 3. EXPLOITED — уязвимости (атака успешна)

### CRITICAL

| ID | Вектор | Факт | Доказательство |
|---|---|---|---|
| **ADV-C114** | Анонимный `GET /api/projects/[id]` проекта `visibility=STEALTH` | **200**: полный проект с составом команды; роут вообще не вызывает `getUserFromRequest`. Любой без аккаунта читает скрытые проекты | `adv-logic.test.ts` |
| **ADV-C113** | `GET /api/projects` (список): where фильтрует только `status`, `visibility` игнорируется | Посторонний юзер видит STEALTH-проект (включая budget) в списке | `adv-logic.test.ts` |

### HIGH

| ID | Вектор | Факт | Доказательство |
|---|---|---|---|
| **ADV-A110** | Аноним `GET /api/projects/[id]` (`confidentiality=private`) | **200**: `problem/solution` (W2-evidence), budget, equity, clientStatus. Гарантия evidence-движка (проекция approvedFields) обойдена сырым GET | `adv-auth.test.ts` |
| **ADV-A109** | Аноним `GET /api/users/[id]/persona` | **200**: plaintext `bio`, `roles`, граф проектов/коллег, `professionalSince`. Соседний `GET /api/users/[id]` требует сессию и режет PII — persona-роут нет (обход FIX-02/P0-3) | `adv-auth.test.ts` |
| **ADV-C104** | Повторный `PATCH action=complete` завершённого проекта | Оба раза **200**: `reputationEvent(project_completed)` 1→2, `ipScore` 45→46. Бесконечная ферма доверия — подрыв trust-экономики (awardBulk без дедупа) | `adv-logic.test.ts` |
| **ADV-C105** | State-machine проектов: переход требует роль `FOUNDER`, но `POST /api/projects` и seed пишут `role='owner'` | Владелец не может сделать **валидный** переход (403 «Только основатель»). PROJ-жизненный цикл мёртв для всех API-проектов | `adv-logic.test.ts` |

### MEDIUM

| ID | Вектор | Факт | Доказательство |
|---|---|---|---|
| ADV-A111 | `PATCH action=join` в `visibility=private, status=cancelled` проект | 200 + запись ProjectMember без согласия владельца; проверок видимости/статуса нет | `adv-auth.test.ts` |
| ADV-B107 | `POST /api/projects` (вне withRoute): не-JSON тело, `title: 12345` | **500** вместо 400 (эталон withRoute) | `adv-injection.test.ts` |
| ADV-B108 | `GET /api/posts?limit=abc`, `/api/search?limit=abc` (NaN→Prisma take) | Необработанный `PrismaClientValidationError` = сырой 500 | `adv-injection.test.ts` |
| ADV-B109 | `<script>`, `<img onerror>` в посте/комментарии | Хранятся и возвращаются **дословно** (stored-XSS-носитель; рендер — React-экранирование — проверять отдельно) | `adv-injection.test.ts` |
| ADV-B112 | `POST /api/events`: `javascript:`-URL, title 100 029 симв., `maxParticipants=-100` | 201: всё сохранено как есть — нет zod, лимитов, URL-гейта на этом поле | `adv-injection.test.ts` |
| ADV-C103 | Идентичный claim ×2 | 201/201, в БД 2 одинаковых claim'а — нет дедупа (спам + ферма верификаций) | `adv-logic.test.ts` |
| ADV-C106 | `MAX_PROPOSAL_PER_USER=3` объявлен, но 0 использований | 4 проекта подряд → 201×4, капа нет | `adv-logic.test.ts` |
| ADV-C109 | `PATCH action=join` в несуществующий проект | **500**: FK-ошибка Prisma (P2003) не смаппена | `adv-logic.test.ts` |
| ADV-C111 | `POST /api/projects` с битым JSON | **500** вместо 400 (`req.json()` вне catch, легаси-контур) | `adv-logic.test.ts` |

### LOW

| ID | Вектор | Факт | Доказательство |
|---|---|---|---|
| ADV-C107 | Регресс-проба стаба `/api/wallet/transfer` (GET/POST/PUT/DELETE=410 ✓) | PATCH-хендлер не экспортирован → Next отдаёт 405, контракт 410-стаба неполный | `adv-logic.test.ts` |

Примечание (не вердикт): ADV-B111 — имя с RTL-override/zero-width сохраняется несанитизированно (bidi-spoofing, low; контрольный сценарий ограничен окружением теста).

## 4. BLOCKED — защита сработала (27)

- **Auth-гейты withRoute (сессии):** мусорный токен → 401 на users/me/projects/SSE; просроченная сессия → 401 и уничтожение (A101–A105).
- **IDOR-мутации:** чужие PATCH users/birthday-plans/career-entries → 403, данные жертвы в БД нетронуты (A106–A108).
- **Привилегии:** self-PATCH с `roles/isVerified/subscriptionTier/accountType` — whitelist полей, БД неизменна (A112); админ-роуты и /api/metrics закрыты (A113, A114).
- **Паспорта c/p/[token]:** перебор, усечение, SQL-инъекция в токене — единый 404 без раскрытия существования (A115, B110: traversal/file:///\0 → 404).
- **Zod-периметр:** missing/wrong-type/100KB/deep-nested/`__proto__` → 400, prototype pollution не проходит, ключи strip (B101–B103); where-инъекция `{"toUserId":{"not":null}}` → 400 (B105); не-JSON → 400 (B106).
- **SQL:** raw SQL в src/ отсутствует (`$queryRaw`=0), payload `'; DROP TABLE User;--` безвреден, таблица цела (B104).
- **Rate-limit:** per-user окно честное (11-й claim → 429), бакеты изолированы по юзеру (C101, C102).
- **Устойчивость:** мусорные id sweep (200 симв., 9×64) → 404/401 без 500 (C108); title 10KB → 422 (C110); конкурентный join — уникальность удержала, счётчик не разъехался (C112); verify-токен одноразовый, удаление атомарно (C115); health 200 / metrics 401 / root 200 по контракту (C116).

## 5. Цепочки атак (эксплуатация)

1. **Профилирование без аккаунта:** anon `GET /users/[id]/persona` (A109) → IDs проектов → anon `GET /projects/[id]` (A110/C114) → коммерческие тайны (problem/solution/budget) приватных и STEALTH-проектов.
2. **Ферма доверия:** создать проект → complete ×N (C104) → IP-score растёт бесконечно; параллельно спам-claims (C103) и безлимитные проекты (C106).
3. **DoS-устойчивость:** мусорные входы в легаси-контур → 500 (B107/B108/C109/C111) — шум в логах/метриках, потенциал для stress-нагрузки.

## 6. Рекомендации (НЕ реализовано — по приказу)

Приоритет фиксов (для будущей команды/этапа):
1. **P0 (critical):** фильтр `visibility/confidentiality` в `GET /api/projects` и `GET /api/projects/[id]` + auth-гейт на приватные; закрыть persona-роут (или применить PII-проекцию FIX-02).
2. **P1 (high):** дедуп `project_completed` reputationEvent (idempotency-ключ или проверка статуса); согласовать `role owner↔FOUNDER` (миграция данных или единая константа); владелец-гейт для join (visibility/status).
3. **P2 (medium):** мигрировать легаси-роуты (`POST /api/projects`, posts, events, search) в withRoute (это закроет B107/B108/C111 и часть XSS-носителей через zod-лимиты); санитайзер/лимиты для `events` (URL-гейт `javascript:`, max title, границы чисел); дедуп claims; смаппить P2003→404 в композере.
4. **P3 (low):** экспортировать PATCH-хендлер стаба transfer (410 на все методы); bidi-нормализация имён.

## 7. Воспроизведение

```bash
node tools/adversarial/run.mjs          # сводка: 27 BLOCKED / 16 EXPLOITED
bun test adversarial/adv-auth.test.ts   # 12 pass / 3 fail (fail = EXPLOITED)
bun test adversarial/adv-injection.test.ts
bun test adversarial/adv-logic.test.ts
```

Каждый fail в выводе bun — падение `verdict('EXPLOITED ...')` с описанием факта. Ledger: `specs/adversarial-review/GATES.md`; worklog: секции `Task ID: adv-a / adv-b / adv-c`.

## 8. Исправление (этап fix-adversarial, по приказу владельца)

Все находки из раздела 3 исправлено: 16 из 16 EXPLOITED-уязвимостей закрыто, каждая атака теперь BLOCKED.

Доказательство: повторный прогон `node tools/adversarial/run.mjs` → **43 BLOCKED / 0 EXPLOITED**, 43 pass / 0 fail; юнит 44/0; E2E 12/12; tsc 0; lint 0.

| ID | Фикс (файл) | Суть |
|---|---|---|
| ADV-C114 | `api/projects/[id]/route.ts` | Гейт видимости GET: непубличные проекты для чужих/анонимов → 404 (не раскрывает существование) |
| ADV-C113 | `api/projects/route.ts` GET | where-фильтр списка: только PUBLIC+public ИЛИ свои ИЛИ где участник |
| ADV-A110 | `api/projects/[id]/route.ts` | SENSITIVE-поля (problem/solution/context/result/budget/equity/clientStatus) — только владельцу/участникам; публичному читателю — null |
| ADV-A109 | `api/users/[id]/persona/route.ts` | 401 без сессии; bio/roles — только владельцу/accepted-connection (политика FIX-02) |
| ADV-C104 | `api/projects/[id]/route.ts` + `transition/route.ts` | Повторный complete → 409; идемпотентность награды (reputationEvent по projectId в payload) |
| ADV-C105 | `api/projects/route.ts` + `transition/route.ts` | Роль `FOUNDER` при создании; transition принимает `owner` и `FOUNDER` (legacy-совместимость) |
| ADV-A111 | `api/projects/[id]/route.ts` | join-гейт: только PUBLIC-проекты на стадии набора (PROPOSAL); приватные → 403 |
| ADV-C109 | `api/projects/[id]/route.ts` + `with-route.ts` | join проверяет существование проекта (404); P2003 → 404 в композере |
| ADV-B107 | `api/projects/route.ts` | POST → withRoute: не-JSON/не-скаляры → 400 (zod-схема createProject) |
| ADV-C111 | `api/projects/route.ts` | Битый JSON → 400 (withRoute-парсер) |
| ADV-B108 | `api/posts/route.ts`, `api/search/route.ts` | Безопасный парсинг limit/offset: NaN/мусор → дефолт, не 500 |
| ADV-B109 | `src/lib/sanitize.ts` + posts/comment | sanitizeUserText на входе: script/iframe/on*/javascript: вырезаются |
| ADV-B112 | `api/events/route.ts` | POST → withRoute + zod (title ≤200, maxParticipants int positive, даты), isUrlSafeForStorage для imageUrl, sanitize |
| ADV-C103 | `api/claims/route.ts` | Дедуп: идентичный claim (type+title) → 409 |
| ADV-C106 | `api/projects/route.ts` | MAX_PROPOSAL_PER_USER=3 enforced (422 при превышении открытых проектов) |
| ADV-C107 | `api/wallet/transfer/route.ts` | PATCH-хендлер 410 TRUST_NOT_CURRENCY — стаб полон на все методы |
| ADV-B111 (примечание) | `src/lib/sanitize.ts` + `src/lib/auth.ts` | stripBidiControls в registerUser (bidi-spoofing закрыт); контракт B111-теста обновлён на «имя без bidi-контролов» |

Дополнительно восстановлено между сессиями (потери окружения): `playwright.config.ts`, `tests/e2e/*.pw.ts`, devDep `@playwright/test@1.57.0`, `BIZON_DEMO_AUTH=1` в `.env`, unlazy-скрипты (`tools/unlazy/scripts/`).
