# Gates: adversarial-review (приказ владельца: доказать, что BizON ломается)

OWNS: adversarial/**, tools/adversarial/**, specs/adversarial-review/**, worklog.md

Scope: адверсариальное ревью BizON. Саб-агенты с единственной целью — доказать, что
BizON ломается (auth/IDOR, инъекции/валидация, бизнес-логика/устойчивость).
КАЖДАЯ атака воспроизводится тестом в adversarial/*.test.ts. НИЧЕГО НЕ ЧИНИТСЯ:
находка EXPLOITED = падающий тест = доказательство; фиксируется в REPORT.md.
Продакшн-код (src/, prisma/, db/) неприкосновенен — нарушение = провал этапа.

Протокол вердиктов (adversarial/helpers.ts):
- BLOCKED — защита сработала, тест зелёный
- EXPLOITED — атака успешна, verdict() бросает → тест красный (доказательство)
- Изоляция БД: копия db/custom.db в tmpdir (пишущие атаки безопасны)
- Runner: node tools/adversarial/run.mjs (exit 0 всегда, репорт-режим)

- [x] G1: атакующий сьют существует и содержит >= 20 проб (каждая атака = тест)
  CHECK: rg -c "test\\(" adversarial/*.test.ts | awk -F: '{s+=$2} END {print (s>=20)?"ADV_COUNT_OK":"ADV_COUNT_LOW"}'
  EXPECT: ADV_COUNT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ff378f66ef3ee15a6c5ef414da401d1c39cf6331114f2ea46f4fc59761617606; exit=0; EXPECT=matched; output-sha256=90b244af457d16fa42662a14e2aa7d9708d3a998667c2aef5a196bf3515aae03; output-bytes=13; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G2: runner даёт сводку вердиктов (прогон сьюта воспроизводим)
  CHECK: node tools/adversarial/run.mjs > /tmp/adv-run.txt 2>&1; grep -q "ADVERSARIAL SUMMARY" /tmp/adv-run.txt && grep -qE "ИТОГ: [0-9]+ BLOCKED / [0-9]+ EXPLOITED" /tmp/adv-run.txt && echo ADV_RUN_OK
  EXPECT: ADV_RUN_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=de9be70aa15f1c1510c7b44b02a3730275c00d832a0a0c2c0d216f7a0701c2db; exit=0; EXPECT=matched; output-sha256=188fefa9b9f04bd1b2d64bd0bdd2c8be731433756180fcb590612be6588c4273; output-bytes=11; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G3: продакшн-код НЕ тронут (ничего не чинили): src/ и prisma/ чисты от изменений
  CHECK: git status --porcelain -- src/ prisma/ db/ | wc -l | awk '{if ($1==0) print "NO_PATCHES_OK"; else print "PATCHED_" $1}'
  EXPECT: NO_PATCHES_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=58f0b12db0e2dd32f2866aff936866566aa31e3d7d39b4117bfd470351dd6c64; exit=0; EXPECT=matched; output-sha256=eb3663bdda6a758fec85741924cd3fd8a288dbf55a1e01e93e6904eeea2d5cc7; output-bytes=14; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G4: отчёт существует и классифицирует находки (EXPLOITED/BLOCKED + severity)
  CHECK: test -f specs/adversarial-review/REPORT.md && grep -q "EXPLOITED" specs/adversarial-review/REPORT.md && grep -q "BLOCKED" specs/adversarial-review/REPORT.md && grep -qi "severity" specs/adversarial-review/REPORT.md && echo REPORT_OK
  EXPECT: REPORT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=7160b9b1f1b426ee0eda036e8e55dd9f2dc04589c686cfa3b4204fcc77537c5a; exit=0; EXPECT=matched; output-sha256=eb16663a916b76d482477f484d07e7312cd36ac8d18d0245f4c1cc8d635f163c; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G5: основные сьюты не пострадали (ревью ничего не сломало)
  CHECK: bun test tests/ > /tmp/adv-unit.txt 2>&1; grep -q "0 fail" /tmp/adv-unit.txt && echo UNIT_STILL_OK
  EXPECT: UNIT_STILL_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=6619bd48e943dafe2e83041d43dfb5161bbc02dc633ea3471ffdc5326b310571; exit=0; EXPECT=matched; output-sha256=998d97da628be462c8a6f27f187376281a645918a646a29df50cd979971e4326; output-bytes=14; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G6: worklog содержит записи всех адверсариальных саб-агентов
  CHECK: grep -q "Task ID: adv-a" worklog.md && grep -q "Task ID: adv-b" worklog.md && grep -q "Task ID: adv-c" worklog.md && echo WORKLOG_ADV_OK
  EXPECT: WORKLOG_ADV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=168feac802b08e5111ee9df1cba3ad9da2e86fc2a0d81b3451a3532d064c8ca0; exit=0; EXPECT=matched; output-sha256=7f32905188f13a394bf0bfd60a92fa10812cbd7ee9bb484d7f21bf0dbdc5148c; output-bytes=15; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries
