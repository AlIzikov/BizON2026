# Gates: fix-campaign-17-09 (исправление всех открытых находок, применению эталонов 15-16)

OWNS: prisma/schema.prisma, src/lib/api-helpers.ts, src/lib/services/**, src/app/api/**, src/components/**, src/middleware.ts, src/instrumentation.ts, scripts/cron-outbox-drain.mjs, scripts/verify-fix-campaign.mjs, specs/fix-campaign-17-09/**, docs/BENCHMARK-STUDY.md, docs/gpt-audit/**, worklog.md

Scope: снапшот сделан (/home/z/17-09-2026); консолидированный список открытых находок
(GAP-MATRIX P1, WCAG §5, WAITING-лист) исправляется по очереди; каждый этап подтверждается
оракулом, финал — полный гейт-прогон + браузерная верификация.

- [x] G1: рейтинг против идеологии удалён — Project.rating и Mentorship.mentorRating отсутствуют в схеме, коде API/UI/сервисах (reputation/passport/company-trust считают по verified-действиям)
  CHECK: node scripts/verify-fix-campaign.mjs rating
  EXPECT: RATING_REMOVED_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=455ff14bdeb8f3ab936a4d0ad67960b5b5a0bf481309af7d7fb8cdc4782ea59a; exit=0; EXPECT=matched; output-sha256=64fbdee2e673daa52ce7ddabdbe35d3c08ca87d8c54ef3e7d8b7f87801d3caff; output-bytes=23; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G2: ipScore скрыт из публичной проекции UserPublicLite (паспорт-level видит только владелец)
  CHECK: node scripts/verify-fix-campaign.mjs ipscore
  EXPECT: IPSCORE_HIDDEN_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=a10f22aee3ff22b007dd221492620835f19ceacff536cf8407c9e6fcbb595460; exit=0; EXPECT=matched; output-sha256=5f7657e25a4f77082467ae8bd0913a17aa35930001de12a032657cf05ce5876f; output-bytes=23; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G3: цепочки результатов (getUserChains) показаны в профиле пользователя
  CHECK: node scripts/verify-fix-campaign.mjs chains
  EXPECT: CHAINS_WIRED_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=23489b0cbe62eff2b652b05e2a8cece588641d9003c40f5fefadf2efda0b3b44; exit=0; EXPECT=matched; output-sha256=54d3606e16d39b8f626bc08f6f6837cc3ce77d6d9e2e37a4a9e9fb938d57db99; output-bytes=21; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G4: DEMO_TOKEN не захардкожен — только через env-гейт BIZON_DEMO_TOKEN
  CHECK: node scripts/verify-fix-campaign.mjs demotoken
  EXPECT: DEMO_TOKEN_GATED_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=fb1105fd1c6f18a2f74590281a87f72a07aebc13de908512b8d1dd7362de8bc4; exit=0; EXPECT=matched; output-sha256=1e1707f31961e814eb609640d757fa48188e064b24e27571200ed065ab7677c9; output-bytes=25; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G5: внешний News-контент проходит prompt-sanitizer перед входом в AI-промпты
  CHECK: node scripts/verify-fix-campaign.mjs sanitizer
  EXPECT: NEWS_SANITIZED_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=c2a267e6e9cc21a24e63de1d15876a56b07775145de064d78291f99438ed104a; exit=0; EXPECT=matched; output-sha256=b8713a186f53fde9dc5bff634e6a5e511c14835ef0d17e5c0c8bf3e649541447; output-bytes=23; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G6: outbox получает периодический drain (не только при старте)
  CHECK: node scripts/verify-fix-campaign.mjs outbox
  EXPECT: OUTBOX_CRON_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=3ff1e2caaa452a6a9c2ae3681b68a4a591c30bceedc1b8be2550515ba9c50286; exit=0; EXPECT=matched; output-sha256=03e21b843cd9d1a3202b84b8c5a4f022383343418d839565dc1bfec5bcd4b85e; output-bytes=20; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G7: admin kill-switch управляется из UI Decision Inbox (тумблер с подтверждением)
  CHECK: node scripts/verify-fix-campaign.mjs killswitch
  EXPECT: KILLSWITCH_UI_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=c53b606b3c924123ee6c139021bc8eea812a9ab6741e3b6a0fd1ed5ef19b0984; exit=0; EXPECT=matched; output-sha256=278a210f4cef36f37f7b4180d3190b079575a480ef1c8df2e5e5f7725195e608; output-bytes=22; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G8: a11y-волна WCAG §5 — контраст --input, звезда amber+sr-only, online-точка role, текстовые маркеры в compare
  CHECK: node scripts/verify-fix-campaign.mjs a11y
  EXPECT: A11Y_WAVE_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=4e2eb57b409c34cafb66a0d45aef047e2098232bfdbcd61ffb4ab1d360cf89f9; exit=0; EXPECT=matched; output-sha256=e273994410aa878b490c4e3028321bfa0e61511fec11ee51365fb2ca32be9b68; output-bytes=18; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G9: guard рекомендаций — «работали вместе» требует Connection или совместный projectId (не улица)
  CHECK: node scripts/verify-fix-campaign.mjs guard
  EXPECT: REC_GUARD_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0f77ba2ac38d7ca954b44e738f0778c6e9e477054f6f5478929dfb7ee049aa89; exit=0; EXPECT=matched; output-sha256=422423f1f33a560cfa755d3dc48d62806c8d8f0307e6146f0142693c4ca5710e; output-bytes=18; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G10: GPT-аудит текст подготовлен в docs/gpt-audit/16-09-2026
  CHECK: node scripts/verify-fix-campaign.mjs gptaudit
  EXPECT: GPT_AUDIT_DOC_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=efca2578e8dbd1aa39456ce68c2abad20e8b7efc8e2edd8941676a3ba3d39b9d; exit=0; EXPECT=matched; output-sha256=f5b941f75a05c454d9e063bbb72507774709baaadea632f46e7293c122e691e3; output-bytes=22; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G11: полный тест-сьют зелёный (bun test)
  CHECK: bun test tests/ && echo TESTS_GATE_OK
  EXPECT: TESTS_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=b577169965f7ee2ba3979b9cf2b7383b15d9c789a27398c84e01ad7fd3b16afa; exit=0; EXPECT=matched; output-sha256=7e8a12782aac15a83d27217934e8dc10f8a3924abf35cfd19bc35273f17a1de8; output-bytes=20872; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G12: ESLint чистый
  CHECK: bun run lint && echo LINT_GATE_OK
  EXPECT: LINT_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=2d20153f9639cb0456ccf4a567094fac1b571a437c7714a5fb86e46e7af4e273; exit=0; EXPECT=matched; output-sha256=e5e812cdcfbbe9427a88a603551fca6f3ce5249595095f71592b15a60f1f4312; output-bytes=25; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G13: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB npx tsc --noEmit --incremental false && echo TSC_GATE_OK
  EXPECT: TSC_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ec3cdece8d769c21fd776b54ea1182d051bb7a28fe7b66fa26c990419497074f; exit=0; EXPECT=matched; output-sha256=6c00450bb1db8d7fb3b09a095703383442ce451d460f5bb069fc1dec5dc594fd; output-bytes=12; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G14: worklog содержит запись о кампании
  CHECK: grep -q 'Task ID: fix-campaign-17-09' worklog.md && echo WORKLOG_GATE_OK
  EXPECT: WORKLOG_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=54135deeb965d34fe6ef31e00a6b69b395dc04f14d36dc0dd7e40730f103ad74; exit=0; EXPECT=matched; output-sha256=5c78035241e06eb38b6724c0c22ec9b15d3023773b310407ec99e732fb39b671; output-bytes=16; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries
