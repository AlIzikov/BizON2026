# Wave 6 E2E — Governance hardening + Scale-prep

Дата: 19.09.2026 · Инцидент доступности: dev-сервер повторно гасился супервизором песочницы (4 рестарта за сессию, паттерн запуска `bash -c "... bun run dev ... &"` — как у chat-service); к логике продукта инциденты отношения не имеют, зафиксированы честно.

## API-золотой путь (2 реальные сессии, HTTP)

Сессии: пользователь A (`w6g-a-…@bizon.test`) и пользователь B (`w6g-b-…@bizon.test`), регистрация через POST /api/auth/register (acceptedTos=true), 200.

| # | Шаг | Результат |
|---|-----|-----------|
| 1 | Регистрация A+B | 200/200 |
| 2 | A (basic): PATCH /api/ai/autonomy {level:3} | **403 TIER_TOO_LOW** («basic→1») — тир-гейт честный |
| 3 | A: POST /api/push (подписка) | **201**, id сохранён |
| 4 | A: GET /api/me/credentials (пустой профиль) | **200 {credentials:[], count:0}** — без выдуманных VC |
| 5 | A: GET /api/admin/kill-switch (статус) | 200 {envKilled:false, fileKilled:false, policyKilled:false, adminConfigured:false} |
| 6 | POST /api/admin/kill-switch без токена | **401** — управления нет без настроенного токена (safe default) |
| 7 | A (verified): PATCH level 3 | **200 {ok:true, level:3}**; level 4 → **403** (verified max 3) |
| 8 | proposeAction SPEND_MONEY (manual-mode authority, явная выдача) | pending_approval (MANUAL_MODE) |
| 9 | A: GET /api/ai/decisions | в инбоксе SPEND_MONEY, mode manual |
| 10 | A: PATCH /api/ai/decisions/[id] approved | **200 pending_second_approval** — 1 голос ≠ approved |
| 11 | A: повторный PATCH | **409 ALREADY_DECIDED** — двойной голос одним пользователем блокирован |
| 12 | B: PATCH approved (второй подтвердитель) | **200 approved** — 2-of-N закрыт; БД: approvalsJson = 2 РАЗНЫХ пользователя, action.status=approved, действие НЕ исполнено (§38: executor отдельный контур) |
| 13 | GET /api/admin/audit-verify?limit=100 | **{ok:true, checked:5}** — hash-chain валиден |
| 14 | GET /sitemap.xml | **200** (динамическая часть: паспорта + verified-компании) |

## Найдены и исправлены реальными проверками (5 багов кода прерванной сессии)

1. **decideAction делал 2-of-N физически невозможным** — FORBIDDEN-гейт «только владелец» отсекал второго подтвердителя. Исправлено: critical → запрашивающий + другой пользователь (approvalsJson + аудит); non-critical — прежние W3-семантики; rejection любого участника отклоняет действие; TTL уважается и в critical-ветке.
2. **PATCH /api/ai/autonomy → 500** «Value is not JSON serializable» — роут сериализовал несуществующий `result.data` (контракт сервиса `{ok, level}`). Исправлено.
3. **Hash-chain ломался на коллизии миллисекунд** — одинаковые `createdAt` соседних записей делали порядок цепочки недетерминированным → ложный разрыв verifyChain. Исправлено: строго монотонные метки времени + мьютекс сериализации flush.
4. **BizonDiscover (дашборд) падал клиентским исключением** — карточка читала `/api/opportunities/radar` (контракт `{windows,...}` без `items`) → `TypeError: … reading 'length'` у залогиненного пользователя. Исправлено: источник `/api/opportunities?limit=5` + defensive `data?.items`.
5. **Схема/типы**: `AiApproval`-поток (`params`→`inputPayload` в тесте), `confirmedBy`→`confirmationsCount`, несуществующее поле `companyPublic` в sitemap (→ `isVerified`), `require()`-импорты (lint 4×) — все исправлены.

## Браузерная E2E (agent-browser, реальная сессия A)

- Дашборд рендерится чисто после фикса BizonDiscover: console errors = 0, page errors = 0.
- Настройки → «Решения AI (Decision Inbox)»: переключатель режима (ручной/совместный) на месте.
- **IL-слайдер (S-138)**: рендерится с текущим уровнем («сейчас: 3 · Поднадзорный»), подписи 0–4, объяснение anti-creeping и тир-гейтов; интеракция клавиатурой (ArrowLeft ×2) → **уровень 3→2, сервер подтвердил autonomyLevel:2 (collaborative)** — персистентно через PATCH /api/ai/autonomy.
- Скриншоты: `specs/wave-6/e2e-desktop.png`, `specs/wave-6/e2e-slider.png`, мобильная 390px `specs/wave-6/e2e-mobile-390.png` — **NO_HSCROLL**, ошибок консоли нет.

## Юнит/adversarial-щиты

- `tests/wave6-governance.test.ts` — **9/9** (2-of-N полный цикл, подпись политик, prohibitions, hash-chain + тампер, HOP anti-creeping + IL-тиры, outbox идемпотентность, VC-подпись + исключение claimed, честный VAPID NOT_CONFIGURED, memory-security consent-гейт).
- `tests/wave6-adversarial.test.ts` — **9/9 BLOCKED** (secure-by-default critical, обход 2-of-N одним пользователем, подделка chain ловится, agent-эскалация ANTI_CREEPING, prohibition сильнее полномочий «*», kill-switch останавливает proposeAction + восстановление, подмена подписи политики детектируется, expired-TTL уважается).
- Регрессия: wave1-trust 16/16 · wave4-projects 16/16 · wave5-opportunities 11/11. tsc: 0 ошибок. lint: 0/0.

## Вердикт

**E2E_PASS**

Оговорки честности: email-верификация E2E-персонажей выполнена прямой записью БД (в песочнице нет почты); выдача полномочия SPEND_MONEY тестовым пользователям — прямая запись БД (API выдачи полномочий не существует по дизайну — safe default); VAPID-ключи не настроены → web-push честно NOT_CONFIGURED; админ-API (kill-switch POST, outbox) требуют BIZON_ADMIN_TOKEN, которого в песочнице нет — управление недоступно by design.
