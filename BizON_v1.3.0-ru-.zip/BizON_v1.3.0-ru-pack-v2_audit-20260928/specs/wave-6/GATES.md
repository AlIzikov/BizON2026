# Gates: wave-6 «Governance hardening + Scale-prep»

OWNS: src/lib/ai-governance/** (additive), src/lib/data-vault/audit-log.ts, src/lib/security/kill-switch.ts, src/lib/services/vc-export-service.ts, src/lib/services/web-push-service.ts, src/lib/services/outbox-service.ts, src/app/api/admin/kill-switch/**, src/app/api/ai/autonomy/**, src/app/api/me/credentials/**, src/app/api/push/**, src/app/sitemap.ts, tests/wave6-*.test.ts, specs/wave-6/**

Scope: 2-of-N для critical-одобрений; подпись/версионирование политик (HMAC); immutable-audit hash-chain; user-prohibitions; kill-switch вне AI-контура (файл+env+API); HOP anti-creeping (авто-повышение автономии запрещено); IL-слайдер (гейты по тиру); memory-security (consent-гейт AiInsight); VC-экспорт W3C; Web-push VAPID (честный unavailable без ключей); sitemap SEO; outbox event-bus.

- [x] G1: схема additive (UserProhibition/PushSubscription/OutboxEvent + approvalsJson + chainHash)
  CHECK: grep -q "model UserProhibition" ../../prisma/schema.prisma && grep -q "model PushSubscription" ../../prisma/schema.prisma && grep -q "model OutboxEvent" ../../prisma/schema.prisma && grep -q "approvalsJson" ../../prisma/schema.prisma && grep -q "chainHash" ../../prisma/schema.prisma && echo SCHEMA_OK
  EXPECT: SCHEMA_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=8b6f5a5253530be6b0838b431e165362895d486d90804628287ab7d991c6e380; exit=0; EXPECT=matched; output-sha256=fb11620d9c6dc2909ba705d28b141ca072015bc71e956ba26aadbf549a37f346; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries

- [x] G2: TypeScript без ошибок
  CHECK: NODE_OPTIONS=3072 bunx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=d84ac7b5dd2503ed5b6b05296a22aaaa36805e5bc0826aaec16070239c067cdf; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries

- [x] G3: юнит-щит Wave 6 (2-of-N/подпись/chain-верификация/prohibitions/anti-creeping/IL/outbox/VC)
  CHECK: bun test ../../tests/wave6-governance.test.ts > /tmp/w6-unit.txt 2>&1; grep -q "0 fail" /tmp/w6-unit.txt && echo UNIT_OK
  EXPECT: UNIT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=e4714ff3d515e7f126825613ad074e4034688e54e83d20a4857dff320eeef9d1; exit=0; EXPECT=matched; output-sha256=d2ba9d9a83b018d960cf5075e52778d3ecaae3e2b822698bdfa82f97c7ae9843; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries

- [x] G4: adversarial Wave 6 (обход 2-of-N/подделка chain/эскалация автономии/prohibition-bypass) — BLOCKED
  CHECK: bun test ../../tests/wave6-adversarial.test.ts > /tmp/w6-adv.txt 2>&1; grep -q "0 fail" /tmp/w6-adv.txt && echo ADV_OK
  EXPECT: ADV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=cf01bff194e8e4dc53eb98a0f19689e8486102d7cdedf35bdca0cc737d6f84e2; exit=0; EXPECT=matched; output-sha256=db61b1220d8ee892366cb62e778ff695edba92d6e1ca0403232b65b6c35086b6; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries

- [x] G5: регрессия волн 1–5 не сломана
  CHECK: bun test ../../tests/wave5-opportunities.test.ts > /tmp/w6-r1.txt 2>&1; grep -q "0 fail" /tmp/w6-r1.txt && bun test ../../tests/wave4-projects.test.ts > /tmp/w6-r2.txt 2>&1; grep -q "0 fail" /tmp/w6-r2.txt && bun test ../../tests/wave1-trust.test.ts > /tmp/w6-r3.txt 2>&1; grep -q "0 fail" /tmp/w6-r3.txt && echo REG_OK
  EXPECT: REG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0f0ffe2bc0b670385c8a6608a6dca0a93cd070e027f973b4bce5211e399fa2f7; exit=0; EXPECT=matched; output-sha256=b38d3551aea3b4c4ad441b48cf989f7182353d487ef29df28897530666d7915f; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries

- [x] G6: kill-switch документирован вне AI-контура + флаг-файл
  CHECK: grep -q "BIZON_AI_AUTONOMY_KILLED" ../../docs/KILL-SWITCH.md && grep -q ".bizon-ai-killed" ../../docs/KILL-SWITCH.md && grep -q ".bizon-ai-killed" ../../src/lib/ai-governance/policy-engine.ts && echo KILL_OK
  EXPECT: KILL_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=eebe2cd2b75db721db33a6dcbdc6c3ecf8d8b9bfc0bb89e4d8bb6e53d82dd3bd; exit=0; EXPECT=matched; output-sha256=9aee079a84d30b6da9180baf4f1544415cc7ee1c92c352c316983c99b26802d7; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries

- [x] G7: governance — подпись политик и chain-hash в коде
  CHECK: grep -q "policySignature" ../../src/lib/ai-governance/policy-engine.ts && grep -q "chainHash" ../../src/lib/data-vault/audit-log.ts && grep -q "TWO_OF_N" ../../src/lib/ai-governance/governance-service.ts && echo GOV_OK
  EXPECT: GOV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=d35d31a2dc9ae58288e2a41b9f4791685f2f896809513cc909c99095d7882545; exit=0; EXPECT=matched; output-sha256=04e014c59e5f904ccc0b11ce59fdfd38891746acff3430961dfda1470cb8b7b8; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries

- [x] G8: E2E отчёт = E2E_PASS
  CHECK: grep -q "E2E_PASS" ../../specs/wave-6/E2E-REPORT.md && echo E2E_OK
  EXPECT: E2E_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=2fd1b0d9de1f2c76cadaeaa44dada07e0856edafaf3dae5e6ab052c6be1ff49e; exit=0; EXPECT=matched; output-sha256=17bcec81990e29d5cbe0c8cd478cd945c72688099349aa1afc68031cfdcbcd94; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries

- [x] G9: финал: worklog + журнал статусов обновлены, финальный чек-пойнт подготовлен
  CHECK: grep -q "Task ID: wave6" ../../worklog.md && echo FINAL_OK
  EXPECT: FINAL_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=667368402f54130273a98b5f72e75d062547f0b096f6141366cba21b5d5e5b2c; exit=0; EXPECT=matched; output-sha256=aa253b0998dcc2d6aa3ba7c5ee24da7947e67de3a29340ffa108ae6e706d7eab; output-bytes=9; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-6; path=cc94915413e1/11 entries
