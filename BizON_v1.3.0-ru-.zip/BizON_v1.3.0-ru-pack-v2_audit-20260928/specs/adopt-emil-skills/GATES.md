# Gates: adopt emilkowalski/skills (эталон №16: study + codify + mobile baseline)

OWNS: docs/UI-CRAFT.md, specs/adopt-emil-skills/**, scripts/verify-emil-adoption.mjs, src/app/globals.css, src/app/layout.tsx, src/components/ui/button.tsx, src/components/landing/landing-page.tsx, docs/BENCHMARK-STUDY.md, worklog.md

Scope: скиллы Эмиля Ковальски изучены по первоисточнику, стандарты design-engineering
кодифицированы в docs/UI-CRAFT.md, мобильный натив-baseline применён к коду
(globals.css, layout viewport, футер, press-фидбек кнопок), карточка №16 добавлена,
worklog записан — всё подтверждено исполнимым ledger-ом, а не отчётом по памяти.

- [x] G1: ledger проходит собственный линт без ошибок
  CHECK: node tools/unlazy/scripts/gate-lint.mjs specs/adopt-emil-skills/GATES.md && echo LEDGER_LINT_OK
  EXPECT: LEDGER_LINT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=1c6236568ea320d577ca523a568c3dcdde8fe22bd031418390622980ed7dee61; exit=0; EXPECT=matched; output-sha256=29aae854fecdee84e002be7459917e8d2b92839b65a1a9b2acad34a0e8451046; output-bytes=23; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G2: полный тест-сьют проекта зелёный (bun test)
  CHECK: bun test tests/ && echo TESTS_GATE_OK
  EXPECT: TESTS_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=b577169965f7ee2ba3979b9cf2b7383b15d9c789a27398c84e01ad7fd3b16afa; exit=0; EXPECT=matched; output-sha256=289bb6e4f6dc5b15e28fe9c53e96bd14036f08fa3139839dbced8b009a174356; output-bytes=20874; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G3: ESLint проекта чистый
  CHECK: bun run lint && echo LINT_GATE_OK
  EXPECT: LINT_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=2d20153f9639cb0456ccf4a567094fac1b571a437c7714a5fb86e46e7af4e273; exit=0; EXPECT=matched; output-sha256=e5e812cdcfbbe9427a88a603551fca6f3ce5249595095f71592b15a60f1f4312; output-bytes=25; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G4: TypeScript-компиляция без ошибок
  CHECK: NODE_OPTIONS=6GB npx tsc --noEmit --incremental false && echo TSC_GATE_OK
  EXPECT: TSC_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ec3cdece8d769c21fd776b54ea1182d051bb7a28fe7b66fa26c990419497074f; exit=0; EXPECT=matched; output-sha256=6c00450bb1db8d7fb3b09a095703383442ce451d460f5bb069fc1dec5dc594fd; output-bytes=12; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G5: docs/UI-CRAFT.md содержит десять стандартов, таблицы решений и библиотечную карту
  CHECK: node scripts/verify-emil-adoption.mjs doc
  EXPECT: EMIL_DOC_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ae03d687d370d3537a67cbe8a147c91a480d6dc284cbcaa765cfa655bc86886b; exit=0; EXPECT=matched; output-sha256=d53f5db6c1d51f8ca93171fc0ac90455d2326320d0640b95b79fcd33512b4854; output-bytes=17; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G6: globals.css содержит мобильный натив-baseline и easing-токены
  CHECK: node scripts/verify-emil-adoption.mjs css
  EXPECT: MOBILE_BASELINE_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=5306f9ddb6557f2d79f770b157a01a4483fe85aa3728fc71608318dace42f343; exit=0; EXPECT=matched; output-sha256=75130023aec377a796ea47bc64e1fd24f8ed97f429980231e54c79e975660d68; output-bytes=24; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G7: layout.tsx содержит viewport-экспорт (viewportFit, themeColor по схемам)
  CHECK: node scripts/verify-emil-adoption.mjs layout
  EXPECT: VIEWPORT_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=8b58f2a413928f53ded5b98985dd7c53559a082d00d451844ed54e962ac7c341; exit=0; EXPECT=matched; output-sha256=7a21feafdf6e5eebedd99b46455b3464d09b780fdd91a66bf52a88df5351f5e3; output-bytes=17; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G8: футер лендинга уважает safe-area (env(safe-area-inset-bottom))
  CHECK: node scripts/verify-emil-adoption.mjs footer
  EXPECT: FOOTER_SAFEAREA_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=4f16dabd7f97cee00c770101f72b4fca1e26a9aa56b3837719c9d1d37c3f6075; exit=0; EXPECT=matched; output-sha256=e33a336a83d5c6a2a6f8882a2d540cf5e6b737257ecad5172702805f4ea48701; output-bytes=24; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G9: Button имеет press-фидбек и точные свойства перехода вместо transition-all
  CHECK: node scripts/verify-emil-adoption.mjs button
  EXPECT: BUTTON_PRESS_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=a85d89038a725c1099f84049bb170aea0e363f8a45caeefea12fc045da597464; exit=0; EXPECT=matched; output-sha256=fa700b4ad327b7643a433605c6799b7d2b8cc6da6431a7c8c29a8f0eeea4ceb8; output-bytes=21; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G10: worklog содержит запись о внедрении emil-skills
  CHECK: grep -q 'Task ID: benchmark-16-emil-skills' worklog.md && echo WORKLOG_GATE_OK
  EXPECT: WORKLOG_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=a378dbeceb4f98505995bb37c5a7dfef8cf59fa4731df38e97773b7d65e0b019; exit=0; EXPECT=matched; output-sha256=5c78035241e06eb38b6724c0c22ec9b15d3023773b310407ec99e732fb39b671; output-bytes=16; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries
