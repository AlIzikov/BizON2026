# Gates: adopt unlazy (эталон №15: вендоринг + интеграция + dogfood)

OWNS: tools/unlazy/**, specs/adopt-unlazy/**, docs/AGENT-WORKFLOW.md, docs/BENCHMARK-STUDY.md, worklog.md

Scope: unlazy встроен в проект (tools/unlazy), дисциплина обновлена (AGENT-WORKFLOW §6.1), карточка №15
добавлена, worklog записан — и всё это подтверждено исполнимым ledger-ом, а не отчётом по памяти.

- [x] G1: ledger проходит собственный линт без ошибок
  CHECK: node tools/unlazy/scripts/gate-lint.mjs specs/adopt-unlazy/GATES.md && echo LEDGER_LINT_OK
  EXPECT: LEDGER_LINT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=e73e22a7a5999a798004f19a9448d45bfdc2fe16d9d6875efd9e18e794b27f5c; exit=0; EXPECT=matched; output-sha256=29aae854fecdee84e002be7459917e8d2b92839b65a1a9b2acad34a0e8451046; output-bytes=23; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G2: полный тест-сьют проекта зелёный (bun test)
  CHECK: bun test tests/ && echo TESTS_GATE_OK
  EXPECT: TESTS_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=b577169965f7ee2ba3979b9cf2b7383b15d9c789a27398c84e01ad7fd3b16afa; exit=0; EXPECT=matched; output-sha256=64cad1f2e993973226392eec057b5abb60f56314f031f1f5b77ff28e6f13ec7d; output-bytes=20872; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G3: ESLint проекта чистый
  CHECK: bun run lint && echo LINT_GATE_OK
  EXPECT: LINT_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=2d20153f9639cb0456ccf4a567094fac1b571a437c7714a5fb86e46e7af4e273; exit=0; EXPECT=matched; output-sha256=e5e812cdcfbbe9427a88a603551fca6f3ce5249595095f71592b15a60f1f4312; output-bytes=25; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G4: TypeScript-компиляция без ошибок
  CHECK: NODE_OPTIONS=6GB npx tsc --noEmit --incremental false && echo TSC_GATE_OK
  EXPECT: TSC_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ec3cdece8d769c21fd776b54ea1182d051bb7a28fe7b66fa26c990419497074f; exit=0; EXPECT=matched; output-sha256=6c00450bb1db8d7fb3b09a095703383442ce451d460f5bb069fc1dec5dc594fd; output-bytes=12; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G5: eval-сьют без провалов (отчёт FAIL=0)
  CHECK: grep -q 'FAIL: \*\*0\*\*' docs/ai-eval/REPORT-latest.md && echo EVAL_GATE_OK
  EXPECT: EVAL_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=2a5ac095da669ea7d745873befae4d98fb2b0729e9d1ebeef1ef2fbe60b0c26e; exit=0; EXPECT=matched; output-sha256=e5dc86afde873ea468aad38ca211dd47f177a8b7338389592fa92179065f5cf1; output-bytes=13; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G6: worklog содержит запись о внедрении unlazy
  CHECK: grep -q 'Task ID: benchmark-15-unlazy' worklog.md && echo WORKLOG_GATE_OK
  EXPECT: WORKLOG_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=3c5cb891413b4b4f59ea4a92f85f40fb328dd23fc8bdeaf37337a28eb235891c; exit=0; EXPECT=matched; output-sha256=5c78035241e06eb38b6724c0c22ec9b15d3023773b310407ec99e732fb39b671; output-bytes=16; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G7: AGENT-WORKFLOW содержит раздел Acceptance Ledger unlazy
  CHECK: grep -q 'Acceptance Ledger — unlazy' docs/AGENT-WORKFLOW.md && echo WORKFLOW_GATE_OK
  EXPECT: WORKFLOW_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=b6b0e2f966c1ecc13679e836d10cbc138695f78585227f11e90eabea71a28ed8; exit=0; EXPECT=matched; output-sha256=0ea10df028e7fcde577b2b714134a6680914e36de682526e727a96052afadcde; output-bytes=17; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G8: вендоренный чекер v2.1.0 присутствует (версия в package.json)
  CHECK: test -f tools/unlazy/scripts/gate-check.mjs && grep -q '"version": "2\.1\.0"' tools/unlazy/package.json && echo CHECKER_GATE_OK
  EXPECT: CHECKER_GATE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=114c1772568d298e3902a3241a1ddfb73a325a39ccf12036708db45e41c56483; exit=0; EXPECT=matched; output-sha256=3da185a68de79dcefb4e727fe2dbbc523f05c9c0e1001af94b2f83bbbc34af67; output-bytes=16; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries
