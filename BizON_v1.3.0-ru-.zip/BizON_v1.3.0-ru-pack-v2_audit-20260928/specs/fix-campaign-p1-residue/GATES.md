# Gates: fix-campaign-p1-residue (остатки P1 GAP-MATRIX: W withRoute-миграция GET-зон, V-подготовка)

OWNS: src/app/api/**/route.ts, src/app/api/notifications/stream/** (whitelist-only),
docs/solutions/architecture/api-route-conventions.md, specs/fix-campaign-p1-residue/**, worklog.md

Scope: кампания fix-campaign-17-09 закрыта ALL MET 14/14. Открытые P1-остатки GAP-MATRIX:
- W (P1): 152 GET-роута сырые (`export async function GET`), 5 сырых мутаций — миграция на
  withRoute (единая обвязка auth/params/ошибки/trace; поведение НЕ меняется).
- Whitelist: src/app/api/notifications/stream/route.ts — SSE-стрим, withRoute НЕ применяем
  (жизненный цикл стрима несовместим с композером; обоснование в worklog и доке конвенций).
- wallet/transfer — deprecated 410-стаб на все методы: обёртка withRoute(auth:false),
  поведение 1:1 (анонимный 410 сохраняется).

Правила миграции (сохранение поведения — обязательное):
1. auth: в сыром GET был getUserFromRequest+401 → withRoute default; НЕ было → { auth:false }.
2. params: `const { id } = await ctx.params` → `const { id } = ctx.params` (уже разрешены).
3. body: `await req.json()` → ctx.data (withRoute читает/валидирует тело сам).
4. try/catch с общим 500 → удаляется (withRoute маппит), ветки специфических классов
   (ServiceError) с .status < 500 сохраняются внутри handler-а.
5. Форматы ответов, статусы, Prisma-запросы, checkUserRateLimit внутри — НЕ менять.
6. rateLimit в opts НЕ добавлять (меняло бы поведение ключа лимитера).

- [x] G1: сырых мутаций в src/app/api не осталось (кроме нуля)
  CHECK: rg -l "export async function (POST|PUT|PATCH|DELETE)" src/app/api -g "route.ts" | wc -l
  EXPECT: 0
  EVIDENCE: automatic-evidence=v1; definition-sha256=870711665fe57f1bc5d8c923c307168749e2c7093e1ae2ac2654d3642d2e2cea; exit=0; EXPECT=matched; output-sha256=9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa; output-bytes=2; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G2: сырых GET не осталось, кроме SSE-whitelist (notifications/stream)
  CHECK: rg -l "export async function GET" src/app/api -g "route.ts" | grep -v "notifications/stream" | wc -l
  EXPECT: 0
  EVIDENCE: automatic-evidence=v1; definition-sha256=4fd389372403d52039678b34ca96bec5630f2114d16e2fdc63d7051ac931c01b; exit=0; EXPECT=matched; output-sha256=9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa; output-bytes=2; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G3: whitelist SSE задокументирован в доке конвенций API
  CHECK: grep -q "notifications/stream" docs/solutions/architecture/api-route-conventions.md && grep -q "SSE" docs/solutions/architecture/api-route-conventions.md && echo DOCS_OK
  EXPECT: DOCS_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=f2bfa23e658cd9d0ddd549b71d28551b2d1f333fc1ec4dec346e959587ad0b17; exit=0; EXPECT=matched; output-sha256=6d36de704b81554dfb84505a4da24630d2ffb6dc40ba29dd836d0c858704f7bc; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G4: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB npx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=1036424409e8eabeed82736be86d70187487dda1fc28dc05d19c123faa181c98; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G5: ESLint чистый
  CHECK: bun run lint && echo LINT_OK
  EXPECT: LINT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=2a664b78f2d8bd1921cdc719c3deb605021aa59c3f21d7e5d0fe4d8b74ff7f18; exit=0; EXPECT=matched; output-sha256=90ab8959dc79e37ac053a28f63ec4f9d5d11ceed9c43333f32cf58ff31877b4e; output-bytes=20; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G6: полный тест-сьют зелёный
  CHECK: bun test tests/ && echo TESTS_OK
  EXPECT: TESTS_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=72ee2e8353e5660eaa1055031c4af0ddb6560e0582586f0fce0dcddfd0948441; exit=0; EXPECT=matched; output-sha256=19000a8067baf4cb523097da6b5ffc6b4aa50733e7d3b543013ec8c3319c5d8a; output-bytes=20867; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G7: worklog содержит запись этапа p1-residue
  CHECK: grep -q "Task ID: fix-campaign-p1-residue" worklog.md && echo WORKLOG_OK
  EXPECT: WORKLOG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=4f688c54621a1e11124915eb0bfdbd114dc31e7572e32eb7763a83b2a2b4842e; exit=0; EXPECT=matched; output-sha256=24f6ed3b668fa67aa709f097b7ca7c2dedb5b7714f6bf4e204013743b91c9bb9; output-bytes=11; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries
