# Gates: feature-notifications-live (направление Б — live-уведомления, приказ владельца «делай дальше Б потом В потом Г»)

OWNS: specs/feature-notifications-live/**, worklog.md (запись Б)
TOUCHES: src/lib/chat-notify.ts, mini-services/chat-service/**, src/lib/services/notification-service.ts,
         src/app/api/** (только точки создания уведомлений), src/components/shell/app-shell.tsx

Scope: убрать 30-секундное слепое окно поллинга уведомлений. Реалтайм-доставка поверх уже
доказанного транспорта направления А (chat-service :3003/:3004, прокси XTransformPort).
Архитектурный закон направления А сохраняется: каноничное хранение и бизнес-правила — в REST,
socket — ТОЛЬКО транспорт. Forged-пуши от клиентов невозможны: доставку инициирует Next API.

## Gates

- G1 LEDGER_FIRST: этот ledger написан ДО реализации; запись в worklog — после верификации.
- G2 TRANSPORT_ONLY: чтение/хранение уведомлений не меняется (REST канон); внутренняя
  поверхность chat-service расширяется /internal/notify и /internal/notify-refresh с тем же
  контуром безопасности направления А: x-internal-secret (timingSafeEqual, fail-closed),
  валидация payload (типы строк, лимиты длин, participants/userIds — массивы строк с лимитом),
  тела >16KB — destroy; bind 127.0.0.1. При недоступности chat-service REST деградирует
  без ошибок (fire-and-forget, AbortSignal.timeout).
- G3 COVERAGE_FULL: hook доставки добавлен во ВСЕ точки создания уведомлений:
  NotificationService.notify + все прямые db.notification.create в src/app/api/** и
  src/lib/services/** (по состоянию на старт работ — 10 файлов) + createMany
  (project-evidence) → notify-refresh. Проверка: rg "db.notification.create" — у каждой
  точки есть хук или покрытие через сервис. 0 незакрытых точек.
- G4 FRONTEND: NotificationsDropdown держит постоянный сокет (io('/?XTransformPort=3003'),
  withCredentials, реконнект Infinity как в направлении А):
  • notification:new → prepend в список с дедупом по id + мгновенный badge++ (без поллинга);
  • toast — только для не-message типов (в открытом диалоге сообщение и так живое — без шума);
  • notification:refresh → тихий рефетч списка;
  • поллинг 30с сохраняется как фолбэк при разрыве сокета; никакого визуального шума.
- G5 E2E_LIVE (браузер A = демо-Иван, пир B = scripts/rt-peer-b.mjs / REST):
  (а) message: B отправляет сообщение → бейдж колокола A растёт мгновенно (<2с) на любой
  вью, не в «Сообщениях»; (б) не-message: B рекомендует новость A (news/recommend) →
  toast у A вживую + prepend в дропдаун.
- G6 REGRESSION: bun run lint = 0; tsc --noEmit = 0; bun test tests/ = 44/0;
  adversarial = 43 BLOCKED / 0 EXPLOITED.
- G7 WORKLOG: запись «Task ID: feature-notifications-live (Б)» в worklog.md после ревёрча.
