# Gates: fix-campaign-e2e (GAP-MATRIX V, P1: воспроизводимый E2E smoke-сьют Playwright)

OWNS: playwright.config.ts, tests/e2e/**, specs/fix-campaign-e2e/**, package.json (devDeps), worklog.md

Scope: последний открытый P1 из GAP-MATRIX — «V: E2E | нет системного E2E | P1: Playwright
smoke-сьют 10 сценариев». Сьют покрывает золотой путь BizON в песочнице: лендинг → SPA-навигация
(Работа/Профиль) → search → публичные поверхности → гейты withRoute (401/404/410) → health.
Демо-сессия: middleware песочницы выдаёт bizon_session автоматически — auth-гейты проверяются
и через API (мусорная cookie → 401), и через UI (авторизованный вид).

- [x] G1: сьют существует и содержит >= 10 тестов (файлы .pw.ts — bun test их не подхватывает)
  CHECK: rg -c "test\\(" tests/e2e/*.pw.ts | awk -F: '{s+=$2} END {print (s>=10)?"E2E_COUNT_OK":"E2E_COUNT_LOW"}'
  EXPECT: E2E_COUNT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=cf8e47e7eeb33111413d85a7a66ff8de44eddb485f1d06378addfceb58a75754; exit=0; EXPECT=matched; output-sha256=b95276ecff8bc88813bfcb706493950e0ab5df5d29b00fb220743258bf21d191; output-bytes=13; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G2: полный прогон E2E зелёный (chromium)
  CHECK: bunx playwright test --reporter=line > /tmp/e2e-out.txt 2>&1; tail -5 /tmp/e2e-out.txt | grep -qE "passed" && ! grep -qE "failed|did not run" /tmp/e2e-out.txt && echo E2E_RUN_OK
  EXPECT: E2E_RUN_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=f42651b67a6b800615031cac7ee5071d7ce919933268cc914b9f3e9fb5e52eb6; exit=0; EXPECT=matched; output-sha256=3460f0a5872e7fa3dd7b670f9f74bf3a0eeb7e201b8a70ff8df3f60df8878cf7; output-bytes=11; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G3: unit-сьют не сломан
  CHECK: bun test tests/ && echo UNIT_OK
  EXPECT: UNIT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=c7ccf1ce87d808aa56c0387ba75c6b877975ce77ab1651b79e4a8578ec7d7fe1; exit=0; EXPECT=matched; output-sha256=ab0b754db736050b01277ef1222f952eedad2d2594933d6ae38284b3c19772e9; output-bytes=20865; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G4: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB npx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=1036424409e8eabeed82736be86d70187487dda1fc28dc05d19c123faa181c98; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G5: ESLint чистый
  CHECK: bun run lint && echo LINT_OK
  EXPECT: LINT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=2a664b78f2d8bd1921cdc719c3deb605021aa59c3f21d7e5d0fe4d8b74ff7f18; exit=0; EXPECT=matched; output-sha256=90ab8959dc79e37ac053a28f63ec4f9d5d11ceed9c43333f32cf58ff31877b4e; output-bytes=20; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G6: worklog содержит запись этапа e2e
  CHECK: grep -q "Task ID: fix-campaign-e2e" worklog.md && echo WORKLOG_OK
  EXPECT: WORKLOG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=289ba0da9732c65acd5953e0f10f9256784f433296ed087eb4089482ea2e9a5b; exit=0; EXPECT=matched; output-sha256=24f6ed3b668fa67aa709f097b7ca7c2dedb5b7714f6bf4e204013743b91c9bb9; output-bytes=11; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries
