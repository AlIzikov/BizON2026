# Wave 5 — E2E Report (S-121)

**Вердикт: E2E_PASS**

## API-золотой путь (реальная сессия W5 E2E через /api/auth/register)

| Шаг | Действие | Результат |
|---|---|---|
| 1 | Фасетный поиск /api/jobs/facets?q=E2E+W5&level=Senior | total=1, вакансия найдена, агрегация level=[Senior:1] (фактические счётчики) |
| 2 | Radar /api/opportunities/radar | dataSufficient=true, 4 окна (3/7/30/90), honest basis |
| 3 | SEARCH_PREF: POST → PATCH toggle | создана (капа 5 активных), toggle isActive=false → 200 |
| 4 | VIEW_LOG: POST ×2 → calendar | counted=true → counted=false (дедуп по дню), календарь 1 день/1 просмотр |
| 5 | RESUME blocks: PUT валидные → GET | 200, 3 блока сохранены/прочитаны; невалидные (2 is_primary) → 422 с честным сообщением |
| 6 | 12 типов: /api/opportunities?type=gig | LOT Wave 4 «E2E W5 Gig GraphQL» → gig-возможность для другого пользователя (межволновая связка) |

## Браузерная проверка (agent-browser, 2 viewport)

- Раздел «Работа» рендерит все блоки Wave 5: **OPPORTUNITY RADAR** (1/3дн · 2/7дн · 8/30дн · 23/90дн, объяснение темпа, чипы топ-типов), **ФИЛЬТРЫ 14 ВАКАНСИЙ** (занятость/график/уровень/формат/индустрия с фактическими счётчиками, мин. зарплата, «только проверенные работодатели», «Применить к поиску»), **АВТОПОИСК (SEARCH_PREF)**, **календарь просмотров**.
- Мобильная 390px: скриншот specs/wave-5/e2e-mobile-390.png — без перекрытий.
- Console errors: 0.

## Eval (protocol §12)

- JOBS_MATCHER_EVAL: samples=160, users=16, **Precision@Top3 = 0.979** (цель ≥ 0.85), XAI coverage = 1.0, latency p50 2.5мс / p95 4мс, Lead Time = 3 дн (факт платформы), статус **READY**.
- Честная оговорка: ground truth выведен из skill-overlap — с эвристикой v0 есть корреляция метода; ML-замена (Career BERT) через ADR + независимую разметку при накоплении данных (правило §8.1).
