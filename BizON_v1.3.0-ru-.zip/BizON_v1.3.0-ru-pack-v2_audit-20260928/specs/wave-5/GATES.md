# Gates: wave-5 «Opportunity Engine 12 типов + Поиск работы»

OWNS: src/lib/services/opportunity-service.ts, src/lib/services/news-opportunity-bridge.ts, src/lib/services/search-preference-service.ts, src/lib/services/opportunity-radar.ts, src/lib/ml/career-matcher.ts, src/app/api/opportunities/**, src/app/api/jobs/** (additive), src/app/api/search-prefs/**, src/components/jobs/**, tools/evals/jobs-matcher-eval.ts, tests/wave5-*.test.ts, specs/wave-5/**

Scope: 12 типов Opportunity (8 → +cofounder/supplier/investor/gig), News→Opportunity bridge, Opportunity Graph, Career BERT v1-контракт (ML-интерфейс + эвристика-fallback, Precision@Top3), VACANCY additive-поля (employmentType/schedule/flags/status), RESUME-блоки, RESPONSE-статусы, SEARCH_PREF (автопоиск), VIEW_LOG, фильтры 10 секций с агрегациями, Radar (3/7/30/90, Lead Time ≥5д).

- [x] G1: схема additive (12 типов: SEARCH_PREF/VIEW_LOG + VACANCY-поля)
  CHECK: grep -q "model SearchPreference" ../../prisma/schema.prisma && grep -q "model JobViewLog" ../../prisma/schema.prisma && grep -q "employmentType" ../../prisma/schema.prisma && grep -q "cofounder" ../../src/lib/services/opportunity-service.ts && grep -q "supplier" ../../src/lib/services/opportunity-service.ts && grep -q "investor" ../../src/lib/services/opportunity-service.ts && echo SCHEMA_OK
  EXPECT: SCHEMA_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=f755f7a3ba758aeac5ace68bc609c9cf2291509e137f08240ef78e230ff17bc6; exit=0; EXPECT=matched; output-sha256=fb11620d9c6dc2909ba705d28b141ca072015bc71e956ba26aadbf549a37f346; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries

- [x] G2: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB bunx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0f5813199f5c0acdbd66717e944698ddccbcd31c3ea02a24b0711adf92b8d2f0; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries

- [x] G3: юнит-щит Wave 5 (12 типов/bridge/pipeline/search-pref/view-log/фильтры/резюме-блоки)
  CHECK: bun test ../../tests/wave5-opportunities.test.ts > /tmp/w5-unit.txt 2>&1; grep -q "0 fail" /tmp/w5-unit.txt && echo UNIT_OK
  EXPECT: UNIT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=7e64cb6e0631361eb0d7ea601ec649e9f9ded203ac231cf8330b8b4fa6fa7cef; exit=0; EXPECT=matched; output-sha256=d2ba9d9a83b018d960cf5075e52778d3ecaae3e2b822698bdfa82f97c7ae9843; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries

- [x] G4: adversarial Wave 5 (манипуляция rank/чужие prefs/спам-подписки/§3.3) — BLOCKED
  CHECK: bun test ../../tests/wave5-adversarial.test.ts > /tmp/w5-adv.txt 2>&1; grep -q "0 fail" /tmp/w5-adv.txt && echo ADV_OK
  EXPECT: ADV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ea89109cc1a580b318b98e98bf5ca45a0cb80651ba2dd09b73c61dc38d1b9790; exit=0; EXPECT=matched; output-sha256=db61b1220d8ee892366cb62e778ff695edba92d6e1ca0403232b65b6c35086b6; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries

- [x] G5: регрессия волн 1–4 не сломана
  CHECK: bun test ../../tests/wave4-projects.test.ts > /tmp/w5-r1.txt 2>&1; grep -q "0 fail" /tmp/w5-r1.txt && bun test ../../tests/wave3-diversity.test.ts > /tmp/w5-r2.txt 2>&1; grep -q "0 fail" /tmp/w5-r2.txt && bun test ../../tests/wave2-store.test.ts > /tmp/w5-r3.txt 2>&1; grep -q "0 fail" /tmp/w5-r3.txt && echo REG_OK
  EXPECT: REG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=5b8338eab69e847d7b5a78864a9c594a2e14a050a2a45dbc765d84ef7eeb6ace; exit=0; EXPECT=matched; output-sha256=b38d3551aea3b4c4ad441b48cf989f7182353d487ef29df28897530666d7915f; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries

- [x] G6: eval-харнесс матчинга честно меряет Precision@Top3/Lead Time (§12)
  CHECK: bun ../../tools/evals/jobs-matcher-eval.ts > /tmp/w5-eval.txt 2>&1; grep -q "JOBS_MATCHER_EVAL" /tmp/w5-eval.txt && grep -q "precisionTop3" /tmp/w5-eval.txt && echo EVAL_OK
  EXPECT: EVAL_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=714db4e16bf9a84db9057edd3dd5219f121bf522f5d8e6f2c85bb01b3efae8f4; exit=0; EXPECT=matched; output-sha256=dc33778213b92bb64f0fe964809a238220391ae2e716c9999e67b01be1587a09; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries

- [x] G7: governance/AuditLog на подписках автопоиска и VIEW_LOG
  CHECK: grep -q "SEARCH_PREF" ../../src/lib/services/search-preference-service.ts && grep -q "AuditLog" ../../src/lib/services/search-preference-service.ts && echo GOV_OK
  EXPECT: GOV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=fcc6578ffada149eec262818e6122ec0d5b8270a7dd7f63d7a4e2172b0a9699e; exit=0; EXPECT=matched; output-sha256=04e014c59e5f904ccc0b11ce59fdfd38891746acff3430961dfda1470cb8b7b8; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries

- [x] G8: UI — фильтры с агрегациями + Radar + автопоиск (SEARCH_PREF) в коде
  CHECK: grep -rq "aggregations" ../../src/components/jobs/ && grep -q "SEARCH_PREF" ../../src/components/jobs/job-facets-panel.tsx && grep -q "Opportunity Radar" ../../src/components/jobs/job-facets-panel.tsx && echo UI_OK
  EXPECT: UI_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=1fbf40c456f98ff4ba3d563bd112b560aa6ad45744c5afffaab228c625ba71bb; exit=0; EXPECT=matched; output-sha256=a8ec7b91c067b01cc6fc5b9771e39b084c4cf58cc6eca98f7d97339bd770b4b8; output-bytes=6; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries

- [x] G9: E2E отчёт = E2E_PASS
  CHECK: grep -q "E2E_PASS" ../../specs/wave-5/E2E-REPORT.md && echo E2E_OK
  EXPECT: E2E_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=1ff3c66707ac5c477955e33d94d5ea269193126cc442f498f4d96c85671185c7; exit=0; EXPECT=matched; output-sha256=17bcec81990e29d5cbe0c8cd478cd945c72688099349aa1afc68031cfdcbcd94; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-5; path=cc94915413e1/11 entries
