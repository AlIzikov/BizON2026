# Gates: wave-3 «Diversity + AI-экономика + News/Events» (S-046…S-075)

OWNS: src/lib/diversity/**, src/lib/services/diversity-service.ts, src/lib/ai-core/operations.ts, src/lib/ai-core/metering.ts, src/lib/services/hypothesis-service.ts, src/lib/services/skill-futures-service.ts (v1), src/lib/services/fraud-text-sync.ts, src/app/api/hypotheses/**, src/components/feed/** (composer/типы/опросы), src/components/events/** (цена/спикеры), prisma/schema.prisma (additive), specs/wave-3/**

Scope: Diversity-лента (квоты 75/15/10 + decay + капы + SkillSynonym), AI-экономика (реестр операций + semantic cache v0 + метринг → AiBudget), cron-гипотезы (ActionEvent 30 дней, ≤3/сутки), skill-futures v1 (Lead Time ≥5 дней), Reputation Estimator (гейт ≥90 дней данных — честный BLOCKED-DATA), GNN-анти-фрауд v2 (синхронность текстов, FPR-замер), POST 5 типов + POLL/SUBSCRIPTION/TERM, Мероприятия (цена/спикеры/lifecycle/поиск/напоминания), Сообщества (ролевая матрица + BAN_WORD).

- [x] G1: схема additive (SkillSynonym, Post: pollOptions/subscriptionPriceLumens/termExpiresAt, Event: priceLumens/registrationUrl/status/speakers, CommunityMember: role, BanWord)
  CHECK: grep -q "model SkillSynonym" ../../prisma/schema.prisma && grep -q "pollOptions" ../../prisma/schema.prisma && grep -q "subscriptionPriceLumens" ../../prisma/schema.prisma && grep -q "registrationUrl" ../../prisma/schema.prisma && grep -q "model BanWord" ../../prisma/schema.prisma && echo SCHEMA_OK
  EXPECT: SCHEMA_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=e24255d597942328fad17e43ca7b5e1e5674385546dca125767a51838724b805; exit=0; EXPECT=matched; output-sha256=fb11620d9c6dc2909ba705d28b141ca072015bc71e956ba26aadbf549a37f346; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries

- [x] G2: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB bunx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0f5813199f5c0acdbd66717e944698ddccbcd31c3ea02a24b0711adf92b8d2f0; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries

- [x] G3: юнит-щит Diversity (квоты 75/15/10, капы на автора, decay, SkillSynonym)
  CHECK: bun test ../../tests/wave3-diversity.test.ts > /tmp/w3-div.txt 2>&1; grep -q "0 fail" /tmp/w3-div.txt && echo DIV_OK
  EXPECT: DIV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=f34cb4d2438033611dd3a87f6949983c9a210625a7e7cb8e03beb148306c87b3; exit=0; EXPECT=matched; output-sha256=1e3f9ac7f3713312e5f25b0d42a27f49d4a9234a932d6cf032086dd74f69f29b; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries

- [x] G4: юнит-щит AI-экономики (реестр, метринг→AiBudget, semantic cache v0)
  CHECK: bun test ../../tests/wave3-aicore.test.ts > /tmp/w3-ai.txt 2>&1; grep -q "0 fail" /tmp/w3-ai.txt && echo AICORE_OK
  EXPECT: AICORE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=3ada4bfc2a77462217f48f133ff246a28dd00483dff6425a5b22b11eea6c38b8; exit=0; EXPECT=matched; output-sha256=2249d7ca0384878f2a3238289e93d1b7b56533947e8c02e70303f7264b76faf9; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries

- [x] G5: регрессия волн 1–2 не сломана
  CHECK: bun test ../../tests/wave1-trust.test.ts > /tmp/w3-r1.txt 2>&1; grep -q "0 fail" /tmp/w3-r1.txt && bun test ../../tests/wave2-store.test.ts > /tmp/w3-r2.txt 2>&1; grep -q "0 fail" /tmp/w3-r2.txt && echo REG_OK
  EXPECT: REG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=fe1f13e9adf4c89d2ba906fb7575d774be937a7fc45412b23272ff21869335a7; exit=0; EXPECT=matched; output-sha256=b38d3551aea3b4c4ad441b48cf989f7182353d487ef29df28897530666d7915f; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries

- [x] G6: governance: операции в реестре, метринг пишет расход, гипотезы ≤3/сутки
  CHECK: grep -q "AI_OPERATIONS" ../../src/lib/ai-core/operations.ts && grep -q "AiBudget" ../../src/lib/ai-core/metering.ts && grep -q "MAX_HYPOTHESES_PER_DAY" ../../src/lib/services/hypothesis-service.ts && echo GOV_OK
  EXPECT: GOV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=cd01198f1d19e850b597f3aeba0e0814360c3a0d1f2d44a8b9438169fa7e6e8f; exit=0; EXPECT=matched; output-sha256=04e014c59e5f904ccc0b11ce59fdfd38891746acff3430961dfda1470cb8b7b8; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries

- [x] G7: UI: composer типов POST + рендер опроса + paywall подписки
  CHECK: grep -q "PollInline" ../../src/components/feed/trust-stream.tsx && grep -q "subscriptionPriceLumens" ../../src/components/feed/trust-stream.tsx && grep -q "TYPE_CHIPS" ../../src/components/feed/post-composer.tsx && echo UI_OK
  EXPECT: UI_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=fd8cf04d5e07f850855a09893b9e64b7bb22f2b5cc3c3af00d3a009ac4837a07; exit=0; EXPECT=matched; output-sha256=a8ec7b91c067b01cc6fc5b9771e39b084c4cf58cc6eca98f7d97339bd770b4b8; output-bytes=6; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries

- [x] G8: Мероприятия: цена/спикеры/lifecycle/поиск в API
  CHECK: grep -q "priceLumens" ../../src/app/api/events/route.ts && grep -q "EventSpeaker" ../../prisma/schema.prisma && grep -q "publishEvent\|cancelEvent" ../../src/lib/services/event-service.ts && echo EVENTS_OK
  EXPECT: EVENTS_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=bd483483ad7396d244e7396e2b8c2a7d2866cb7988e2f2fecb8371c0579d6224; exit=0; EXPECT=matched; output-sha256=cb2cb9b6c63abec1bdec19141d9ed17d492b11b8b04d973ec1869254d9428736; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries

- [x] G9: adversarial + eval волны зелёные (fraud-text-sync FPR-замер, skill-futures Lead Time)
  CHECK: bun test ../../tests/wave3-adversarial.test.ts > /tmp/w3-adv.txt 2>&1; grep -q "0 fail" /tmp/w3-adv.txt && grep -q "LEAD_TIME" ../../tools/evals/skill-futures-eval.ts && echo SHIELDS_OK
  EXPECT: SHIELDS_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=c88f8e8d1ae28afbd2bc8ec7e445e2c0e90ad969e6caeb1833dfc998ab6307ea; exit=0; EXPECT=matched; output-sha256=4fdc884a8debfc64a186f73eb26b3819b5b982346fd815c8ffaca0ee8ffaccd3; output-bytes=11; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-3; path=cc94915413e1/11 entries
