# Gates: wave-1 «Кольцо доверия» (Sarafan Radio × 5 Handshakes)

OWNS: src/lib/trust/**, src/lib/services/intro-service.ts, src/lib/services/sarafan-guard.ts, src/app/api/intros/**, src/app/api/complaints/**, src/app/api/me/bizcard/**, src/components/trust/**, specs/wave-1/**, prisma/schema.prisma

Scope: замыкание цепочки §7.6 (путь → интро → согласие → сообщение → репутация) + щиты §8.2 (тиры, fingerprint/honeypot, velocity, жалобы) + ML-контракт §8.1 (интерфейсы, лог данных) + UI Wave 1 (S-020..S-023 частично).

- [x] G1: схема additive и клиент сгенерирован
  CHECK: grep -q "model IntroductionRequest" ../../prisma/schema.prisma && grep -q "verificationTier" ../../prisma/schema.prisma && grep -q "model TrainingExample" ../../prisma/schema.prisma && grep -q "model Complaint" ../../prisma/schema.prisma && grep -q "relationshipType" ../../prisma/schema.prisma && grep -q "lastVerifiedAt" ../../prisma/schema.prisma && echo SCHEMA_OK
  EXPECT: SCHEMA_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=af83a88287e63045efa330c08466e5d39ac41506f93e2ab46c46db812a34d39d; exit=0; EXPECT=matched; output-sha256=fb11620d9c6dc2909ba705d28b141ca072015bc71e956ba26aadbf549a37f346; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries

- [x] G2: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB bunx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0f5813199f5c0acdbd66717e944698ddccbcd31c3ea02a24b0711adf92b8d2f0; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries

- [x] G3: юнит-щит Wave 1 (16 кейсов: decay/levels/forecast/anomaly/гварды)
  CHECK: bun test ../../tests/wave1-trust.test.ts > /tmp/w1-unit.txt 2>&1; grep -q "0 fail" /tmp/w1-unit.txt && echo UNIT_OK
  EXPECT: UNIT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ee8c7cc0f486b9e2779a6e7f252302eed98669b5b81cd24203f8e1193080439b; exit=0; EXPECT=matched; output-sha256=d2ba9d9a83b018d960cf5075e52778d3ecaae3e2b822698bdfa82f97c7ae9843; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries

- [x] G4: adversarial Wave 1 (кольца/массовые/взаимные/velocity) — BLOCKED
  CHECK: bun test ../../tests/wave1-adversarial.test.ts > /tmp/w1-adv.txt 2>&1; grep -q "0 fail" /tmp/w1-adv.txt && echo ADV_OK
  EXPECT: ADV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=a7fb439d789d779a3855b7d8659a4ebcc207ee5d64d6bed6ccc9f8d6e90e8420; exit=0; EXPECT=matched; output-sha256=db61b1220d8ee892366cb62e778ff695edba92d6e1ca0403232b65b6c35086b6; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries

- [x] G5: старый adversarial-щит не сломан (43 пробы зелёные пофайлово)
  CHECK: bun test ../../adversarial/adv-injection.test.ts > /tmp/w1-r1.txt 2>&1; grep -q "0 fail" /tmp/w1-r1.txt && bun test ../../adversarial/adv-auth.test.ts > /tmp/w1-r2.txt 2>&1; grep -q "0 fail" /tmp/w1-r2.txt && bun test ../../adversarial/adv-logic.test.ts > /tmp/w1-r3.txt 2>&1; grep -q "0 fail" /tmp/w1-r3.txt && echo REG_OK
  EXPECT: REG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=82d948fc120be6b711b0a25bb6f6096927485a44528f74ac070be82656536b2c; exit=0; EXPECT=matched; output-sha256=b38d3551aea3b4c4ad441b48cf989f7182353d487ef29df28897530666d7915f; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries

- [x] G6: eval-харнесс работает и меряет честные метрики
  CHECK: bun ../../tools/evals/matchmaker-eval.ts > /tmp/w1-eval.txt 2>&1; grep -q "MATCHMAKER_EVAL" /tmp/w1-eval.txt && grep -q "xaiCoverage" /tmp/w1-eval.txt && echo EVAL_OK
  EXPECT: EVAL_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=8adb821a19180e54879d76524d8e614717863d3b84cdbcad7f14da5bc58f2e4d; exit=0; EXPECT=matched; output-sha256=dc33778213b92bb64f0fe964809a238220391ae2e716c9999e67b01be1587a09; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries

- [x] G7: governance: REQUEST_INTRO зарегистрирован, аудит на действиях
  CHECK: grep -q "REQUEST_INTRO" ../../src/lib/ai-governance/action-registry.ts && grep -q "INTRO_REQUESTED" ../../src/lib/services/intro-service.ts && grep -q "INTRO_ACCEPTED" ../../src/lib/services/intro-service.ts && echo GOV_OK
  EXPECT: GOV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=cc5fa9935ef7d2715582dac1c7b3afa603dc15144d32c6b64a8048aa391c2521; exit=0; EXPECT=matched; output-sha256=04e014c59e5f904ccc0b11ce59fdfd38891746acff3430961dfda1470cb8b7b8; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries

- [x] G8: щиты в проде: velocity, honeypot, fingerprint, тир
  CHECK: grep -q "checkVelocity" ../../src/app/api/intros/route.ts && grep -q "websiteConfirmation" ../../src/app/api/auth/register/route.ts && grep -q "REGISTER_DEVICE" ../../src/app/api/auth/register/route.ts && grep -q "contact_verified" ../../src/app/api/auth/verify-email/route.ts && grep -q "COMPLAINT_CATEGORIES" ../../src/app/api/complaints/route.ts && echo SHIELDS_OK
  EXPECT: SHIELDS_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0f5bc30eef4ae38bc0521a494ae486e965fdd7bb4e31e58f55ee0424001547a4; exit=0; EXPECT=matched; output-sha256=4fdc884a8debfc64a186f73eb26b3819b5b982346fd815c8ffaca0ee8ffaccd3; output-bytes=11; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries

- [x] G9: UI Wave 1 смонтирован (интро-инбокс, визитка, AuthorChip)
  CHECK: grep -q "IntroInbox" ../../src/components/network/network-view.tsx && grep -q "BizCardDialog" ../../src/components/network/network-view.tsx && grep -q "AuthorChip" "../../src/app/p/[token]/page.tsx" && echo UI_OK
  EXPECT: UI_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=777b1ca4de263dea63fbd56fa3e6ca87f9c6e286cac84f7a97bd4ec4381bd4f2; exit=0; EXPECT=matched; output-sha256=a8ec7b91c067b01cc6fc5b9771e39b084c4cf58cc6eca98f7d97339bd770b4b8; output-bytes=6; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-1; path=cc94915413e1/11 entries
