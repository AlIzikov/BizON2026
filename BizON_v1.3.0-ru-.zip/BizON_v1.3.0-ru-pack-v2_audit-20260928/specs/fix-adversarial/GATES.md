# Gates: fix-adversarial (исправление всех 16 EXPLOITED-находок red team)

OWNS: src/**, prisma/**, adversarial/**, specs/fix-adversarial/**, worklog.md

Scope: планомерный фикс всех дыр из specs/adversarial-review/REPORT.md по чек-листу
(P0 приватность проектов/persona → P1 trust/lifecycle/join → P2 легаси-роуты/санитайзеры/
дедупы/лимиты → P3 стаб/bidi/P2003). Доказательство исправления: соответствующий
адверсариальный тест ЗЕЛЕНЕЕТ (verdict BLOCKED — тесты ассертят безопасное поведение).
Регресс-щит: юнит-сьют (44), E2E (12), tsc, lint.

ЧЕК-ЛИСТ 16 EXPLOITED → обязательный перевод в BLOCKED:
P0: ADV-C114, ADV-C113, ADV-A110, ADV-A109
P1: ADV-C104, ADV-C105, ADV-A111, ADV-C109
P2: ADV-B107, ADV-C111, ADV-B108, ADV-B109, ADV-B112, ADV-C103, ADV-C106
P3: ADV-C107 (+ примечание ADV-B111 bidi — в P3)

- [x] G1: ВСЕ 16 EXPLOITED переведены в BLOCKED (жёсткий чек по каждому ID)
  CHECK: node tools/adversarial/run.mjs > /tmp/fixadv-run.txt 2>&1; for id in ADV-A109 ADV-A110 ADV-A111 ADV-B107 ADV-B108 ADV-B109 ADV-B112 ADV-C103 ADV-C104 ADV-C105 ADV-C106 ADV-C107 ADV-C109 ADV-C111 ADV-C113 ADV-C114; do grep -q "blocked  $id" /tmp/fixadv-run.txt || { echo "STILL_EXPLOITED_$id"; exit 1; }; done; grep -q "EXPLOITED: none" /tmp/fixadv-run.txt && echo ALL_BLOCKED_OK
  EXPECT: ALL_BLOCKED_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=d0fec3a2d4477cd940c53b16eebde87eca4c993d6a53a5294516e0058cf3b0a8; exit=0; EXPECT=matched; output-sha256=dc4148049850cff622e65f62d6068d249a7839119dea5c74eb258b70e87ed00b; output-bytes=15; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G2: юнит-сьют не сломан фикcами
  CHECK: bun test tests/ > /tmp/fixadv-unit.txt 2>&1; grep -q "0 fail" /tmp/fixadv-unit.txt && echo UNIT_OK
  EXPECT: UNIT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=9332d022ae371119d13b9e0515615d9855f3e602cc7d30c60a1a09ada7d6c65d; exit=0; EXPECT=matched; output-sha256=d2ba9d9a83b018d960cf5075e52778d3ecaae3e2b822698bdfa82f97c7ae9843; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G3: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB npx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=1036424409e8eabeed82736be86d70187487dda1fc28dc05d19c123faa181c98; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G4: ESLint чистый
  CHECK: bun run lint && echo LINT_OK
  EXPECT: LINT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=2a664b78f2d8bd1921cdc719c3deb605021aa59c3f21d7e5d0fe4d8b74ff7f18; exit=0; EXPECT=matched; output-sha256=90ab8959dc79e37ac053a28f63ec4f9d5d11ceed9c43333f32cf58ff31877b4e; output-bytes=20; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G5: E2E золотой путь зелёный
  CHECK: bunx playwright test --reporter=line > /tmp/fixadv-e2e.txt 2>&1; tail -5 /tmp/fixadv-e2e.txt | grep -qE "passed" && ! grep -qE "failed|did not run" /tmp/fixadv-e2e.txt && echo E2E_OK
  EXPECT: E2E_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=5d90e3c7ad4aa4841c25a5e6c8c308257ba490560e4da3d33e8529908b15bdab; exit=0; EXPECT=matched; output-sha256=17bcec81990e29d5cbe0c8cd478cd945c72688099349aa1afc68031cfdcbcd94; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G6: отчёт red team обновлён статусами исправления
  CHECK: grep -qi "исправлено" specs/adversarial-review/REPORT.md && echo REPORT_UPDATED_OK
  EXPECT: REPORT_UPDATED_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=740f4feda07942ad60b15bc46a93355611968aa31efd2ea9629a92986e5cb67a; exit=0; EXPECT=matched; output-sha256=3746636a905627c3ab58bd7df81f4c6769f7b33b6325b77c22775d8d78c32a27; output-bytes=18; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G7: worklog содержит записи этапов фикса
  CHECK: grep -q "Task ID: fix-adversarial" worklog.md && echo WORKLOG_OK
  EXPECT: WORKLOG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=85df4826e292c75bf94bf21809011f92c0b1cbca1f593bdfc5d3dbd3ef6c2266; exit=0; EXPECT=matched; output-sha256=24f6ed3b668fa67aa709f097b7ca7c2dedb5b7714f6bf4e204013743b91c9bb9; output-bytes=11; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries
