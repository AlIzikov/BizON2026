# Gates: feature-chat (направление А — реалтайм-мессенджер, приказ владельца «запусти первую»)

OWNS: mini-services/chat-service/**, specs/feature-chat/**, worklog.md
TOUCHES: src/components/messages/messages-view.tsx, src/app/api/messages/**, package.json, .env

Scope: добить существующий polling-чат (REST /api/messages, модели Conversation/Message)
до реального реалтайма. Архитектура:
- socket.io mini-service (port 3003, путь '/' — Caddy/XTransformPort), изолированный bun-проект
- авторизация handshake: cookie bizon_session → проверка через Next /api/auth/me; без валидной сессии коннект отклоняется
- комнаты: user:{id} (личная), conv:{id} (только после проверки членства через существующий Next-API авторизации)
- сохранение сообщений остаётся каноничным в REST POST /api/messages (бизнес-правила: connection/ipScore-гейт, лимиты, notification) — socket-серверPersistent-логики НЕ дублирует
- доставка в реалтайме: Next API → internal HTTP listener (port 3004, bind 127.0.0.1) с общим секретом x-internal-secret (timing-safe) — клиентские forged-броадкасты невозможны
- typing/read-receipts/presence — релей ТОЛЬКО внутри проверенных conv-комнат, typing-троттлинг

- [x] G1: mini-service chat-service существует: собственный package.json, вход index.ts, жёсткий порт 3003 (не PORT-env), запускается bun run dev (bun --hot)
  CHECK: test -f mini-services/chat-service/index.ts && test -f mini-services/chat-service/package.json && grep -q "3003" mini-services/chat-service/index.ts && echo CHAT_SVC_OK
  EXPECT: CHAT_SVC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=47b399799b9c217124371319109e7a4ac50e16ddd91487f68d7c9617fe7a2c62; exit=0; EXPECT=matched; output-sha256=b207699aaba7dbd5d99cbf3dee450ef34107be54735dcc9e782eae8cb250f91f; output-bytes=12; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G2: socket.io-client добавлен в главный проект
  CHECK: grep -q '"socket.io-client"' package.json && echo CLIENT_DEP_OK
  EXPECT: CLIENT_DEP_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0c781c303ddd669200b64bccf90c53007fa244463dcc81f525fe0d092674151d; exit=0; EXPECT=matched; output-sha256=d34f3d8d5591792126231f3760c8d62a56ccb8c1e3c4540fe5d008a35a7030f0; output-bytes=14; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G3: внутренняя поверхность защищена: internal listener требует секрет (x-internal-secret), Next-хук шлёт секрет из env (src/lib/chat-notify.ts, подключён в роутах messages); сравнение timing-safe
  CHECK: grep -q "timingSafeEqual" mini-services/chat-service/index.ts && grep -q "CHAT_INTERNAL_SECRET" src/lib/chat-notify.ts && grep -q "notifyChatBroadcast" src/app/api/messages/route.ts && echo SECRET_OK
  EXPECT: SECRET_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=f406ff0d7c0f15996254b8c602412de3652637f83be8e2ecba3633a2d93f9cae; exit=0; EXPECT=matched; output-sha256=f6bc85d1cf2d3ba8ace2938252963a89e5882dac0b3dbce90eb57c9bdbbd680e; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G4: сокет-сервер не доверяет клиенту: handshake отклоняет неавторизованных (unauthorized), conversation:join проверяет членство через Next API, typing/read релеятся только в присоединённые комнаты
  CHECK: grep -q "unauthorized" mini-services/chat-service/index.ts && grep -q "conversation:join" mini-services/chat-service/index.ts && echo SOCKET_AUTH_OK
  EXPECT: SOCKET_AUTH_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=9264ef97fd9bc53da15029fe24ad121dfdfde2aca1b21d3b79502b46115ba59b; exit=0; EXPECT=matched; output-sha256=a032dc3805dba4832fa420198e83524e12a959d1ee46c195a1861ca0dbd660b1; output-bytes=15; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G5: фронт реалтайм-проводка в messages-view.tsx: io('/?XTransformPort=3003'), подписка message:new, typing, read, presence-индикатор, live-unread
  CHECK: grep -q "XTransformPort=3003" src/components/messages/messages-view.tsx && grep -q "message:new" src/components/messages/messages-view.tsx && grep -q "typing" src/components/messages/messages-view.tsx && echo FRONT_RT_OK
  EXPECT: FRONT_RT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=8919738edd48cb08777ecf9cd776104ca8ab8668b173e59cc202259c91b2528c; exit=0; EXPECT=matched; output-sha256=b4839eb3f7b72b84ee95c886a2eb70a1bca6e924aa88821c5a7ad31473131e68; output-bytes=12; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G6: mini-service жив: engine.io polling-handshake отвечает на 3003
  CHECK: curl -s 'http://127.0.0.1:3003/?EIO=4&transport=polling' | grep -q '"sid"' && echo WS_ALIVE_OK
  EXPECT: WS_ALIVE_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=22e2ca0855b9248cf62a44a11e5d1efc7a9f5be4e19f3c89318f1ac7ec2d537d; exit=0; EXPECT=matched; output-sha256=c80bc1c09fe3cf7677d0aec93f172e0028066f9f15bb0a5880cde9dca05e462f; output-bytes=12; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G7: самопроверка новой поверхности (адверсарная гигиена): internal/broadcast без секрета/с неверным секретом → отказ; с мусорным телом → 400; сокет без сессии → коннект отклонён
  CHECK: grep -q "RT_SELFTEST_OK" worklog.md && echo SELFTEST_LOGGED
  EXPECT: SELFTEST_LOGGED
  EVIDENCE: automatic-evidence=v1; definition-sha256=a9b4e529b341f5a44f726be8a5d1d2f40127d2a1f9ebfb9fffd3ad3bb85d9607; exit=0; EXPECT=matched; output-sha256=9c1dfb0a79ace738b58cf78a910013a72cd3e17b22c06c6cb732d3fa07646b9c; output-bytes=16; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G8: E2E реалтайм двух пользователей задокументирован в worklog (доставка без перезагрузки, typing, read-receipt, unread-live)
  CHECK: grep -q "RT_E2E_OK" worklog.md && echo E2E_LOGGED
  EXPECT: E2E_LOGGED
  EVIDENCE: automatic-evidence=v1; definition-sha256=228d28ae90c40c72cf27982ee7970556647fe2895c5b2418a47a378aa360d521; exit=0; EXPECT=matched; output-sha256=fcdae08d9529bc387631cc19cb2529ca833d162a2255b8c1edde60cfa6f29339; output-bytes=11; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries

- [x] G9: регресс цел: lint 0, tsc 0, bun test tests/ 0 fail, adversarial 43 BLOCKED / 0 EXPLOITED
  CHECK: grep -q "REGRESSION_OK" worklog.md && echo REGRESSION_LOGGED
  EXPECT: REGRESSION_LOGGED
  EVIDENCE: automatic-evidence=v1; definition-sha256=116cfa494e52ca4b2576c6fb80881ebb395b6aae1549d81617e934e87cd503f3; exit=0; EXPECT=matched; output-sha256=36d3a841ea5d4acdaef8e9c5e7ed9238c1487c1a322371645b1a6159bbaef0b8; output-bytes=18; shell=/bin/sh; cwd=/home/z/my-project; path=cc94915413e1/11 entries
