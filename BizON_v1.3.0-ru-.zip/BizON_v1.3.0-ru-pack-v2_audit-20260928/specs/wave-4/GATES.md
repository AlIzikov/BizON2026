# Gates: wave-4 «Project Room + Evidence»

OWNS: src/lib/services/lot-service.ts, src/lib/services/milestone-service.ts, src/lib/services/project-room-service.ts, src/app/api/lots/**, src/app/api/projects/[id]/milestones/**, src/app/api/projects/[id]/applications/**, src/app/api/projects/[id]/reviews/**, src/app/api/projects/gallery/**, src/app/api/projects/[id]/evidence/overview/**, src/app/api/companies/[id]/memory/**, src/components/projects/project-room.tsx, tests/wave4-*.test.ts, specs/wave-4/**

Scope: LOT-биржа (эскроу, acceptUntil, 9 блоков витрины), milestones+discussion, заявки, verified-отзывы (§3.3: scoreInternal не публикуется), галерея ≤20, Company Memory, rating → внутренний сигнал.

- [x] G1: схема additive (5 моделей Wave 4) и клиент сгенерирован
  CHECK: grep -q "model ProjectLot" ../../prisma/schema.prisma && grep -q "model LotResponse" ../../prisma/schema.prisma && grep -q "model Milestone" ../../prisma/schema.prisma && grep -q "model MilestoneComment" ../../prisma/schema.prisma && grep -q "model ProjectApplication" ../../prisma/schema.prisma && grep -q "model ProjectReview" ../../prisma/schema.prisma && grep -q "escrowTxId" ../../prisma/schema.prisma && echo SCHEMA_OK
  EXPECT: SCHEMA_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=21f972309e2e7e6154524f2a1a6c5ce3a32abf32e9297f62d61b1777bc8addda; exit=0; EXPECT=matched; output-sha256=fb11620d9c6dc2909ba705d28b141ca072015bc71e956ba26aadbf549a37f346; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries

- [x] G2: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB bunx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0f5813199f5c0acdbd66717e944698ddccbcd31c3ea02a24b0711adf92b8d2f0; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries

- [x] G3: юнит-щит Wave 4 (16 кейсов: lot lifecycle/эскроу/дедлайны/milestones/заявки/отзывы/§3.3)
  CHECK: bun test ../../tests/wave4-projects.test.ts > /tmp/w4-unit.txt 2>&1; grep -q "0 fail" /tmp/w4-unit.txt && echo UNIT_OK
  EXPECT: UNIT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ccd3b3c9209f93483cf20815d0a7e356cde544fe144b3579b12900c61c346783; exit=0; EXPECT=matched; output-sha256=d2ba9d9a83b018d960cf5075e52778d3ecaae3e2b822698bdfa82f97c7ae9843; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries

- [x] G4: adversarial Wave 4 (гонки accept/эскроу-манипуляции/чужие решения/FPR) — BLOCKED
  CHECK: bun test ../../tests/wave4-adversarial.test.ts > /tmp/w4-adv.txt 2>&1; grep -q "0 fail" /tmp/w4-adv.txt && echo ADV_OK
  EXPECT: ADV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=d3e6aecb54fe19263b56f89af797d27b4b6ad24ab791be000eb2a072ce4f88eb; exit=0; EXPECT=matched; output-sha256=db61b1220d8ee892366cb62e778ff695edba92d6e1ca0403232b65b6c35086b6; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries

- [x] G5: регрессия волн 1–3 не сломана
  CHECK: bun test ../../tests/wave1-trust.test.ts > /tmp/w4-r1.txt 2>&1; grep -q "0 fail" /tmp/w4-r1.txt && bun test ../../tests/wave2-store.test.ts > /tmp/w4-r2.txt 2>&1; grep -q "0 fail" /tmp/w4-r2.txt && bun test ../../tests/wave3-diversity.test.ts > /tmp/w4-r3.txt 2>&1; grep -q "0 fail" /tmp/w4-r3.txt && bun test ../../tests/wave3-aicore.test.ts > /tmp/w4-r4.txt 2>&1; grep -q "0 fail" /tmp/w4-r4.txt && echo REG_OK
  EXPECT: REG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=1d1cb6d743284d17e9664325ee47a51dc11e36632f463bf46d0e571dfd5928d5; exit=0; EXPECT=matched; output-sha256=b38d3551aea3b4c4ad441b48cf989f7182353d487ef29df28897530666d7915f; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries

- [x] G6: §3.3 — rating вырезан из публичных API-поверхностей проектов
  CHECK: grep -q "rating: undefined" "../../src/app/api/projects/[id]/route.ts" && grep -q "clientVerified" ../../src/app/api/projects/route.ts && ! grep -n "rating: p.rating" ../../src/app/api/projects/route.ts && echo S33_OK
  EXPECT: S33_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=a803668ea3afd60c633d42c4f4cf0d78ffc0f64f739fa7935acd4c2efd3aca97; exit=0; EXPECT=matched; output-sha256=c79b67a98a7856573a3425802502fc0e4ae87a92c66784f491d0cb74155934f2; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries

- [x] G7: governance — AuditLog на ключевых действиях Wave 4
  CHECK: grep -q "LOT_CREATED" ../../src/lib/services/lot-service.ts && grep -q "LOT_RESPONSE_ACCEPTED" ../../src/lib/services/lot-service.ts && grep -q "MILESTONE_CREATED" ../../src/lib/services/milestone-service.ts && grep -q "PROJECT_APPLICATION_DECIDED" ../../src/lib/services/project-room-service.ts && grep -q "PROJECT_REVIEW_CREATED" ../../src/lib/services/project-room-service.ts && echo GOV_OK
  EXPECT: GOV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=b04d1f4400a6957d941fbdf71a4baa3fe60a639479d41cf7e6bf26bf99aebcc1; exit=0; EXPECT=matched; output-sha256=04e014c59e5f904ccc0b11ce59fdfd38891746acff3430961dfda1470cb8b7b8; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries

- [x] G8: UI — Project Room табы (7 ТЗ + LOT) и 9 блоков витрины в коде
  CHECK: grep -q "value=\"milestones\"" ../../src/components/projects/project-room.tsx && grep -q "value=\"discussion\"" ../../src/components/projects/project-room.tsx && grep -q "value=\"results\"" ../../src/components/projects/project-room.tsx && grep -q "LOT-биржа проекта" ../../src/components/projects/project-room.tsx && grep -q "ProjectRoomTabs" ../../src/components/projects/projects-view.tsx && echo UI_OK
  EXPECT: UI_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=4ea1b31919454f1ddeb1c7018a472f746d8ebd34077b71b4824347b77cbf70d2; exit=0; EXPECT=matched; output-sha256=a8ec7b91c067b01cc6fc5b9771e39b084c4cf58cc6eca98f7d97339bd770b4b8; output-bytes=6; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries

- [x] G9: E2E отчёт = E2E_PASS
  CHECK: grep -q "E2E_PASS" ../../specs/wave-4/E2E-REPORT.md && echo E2E_OK
  EXPECT: E2E_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=8c5cda250fad9c88d075f8724a082851dafd4a0e4a1bb8875f11b95e741fcc09; exit=0; EXPECT=matched; output-sha256=17bcec81990e29d5cbe0c8cd478cd945c72688099349aa1afc68031cfdcbcd94; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-4; path=cc94915413e1/11 entries
