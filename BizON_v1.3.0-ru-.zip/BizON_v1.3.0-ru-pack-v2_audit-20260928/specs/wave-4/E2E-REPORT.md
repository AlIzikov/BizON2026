# Wave 4 — E2E Report (S-098)

**Вердикт: E2E_PASS** (API-золотой путь полностью; браузерная проверка UI пройдена с одним найденным и исправленным багом мобильной вёрстки)

## Золотой путь (2 сессии, реальные cookie-сессии через /api/auth/register)

| Шаг | Действие | Результат |
|---|---|---|
| 1 | Owner: регистрация + topup 500 люменов (демо-шлюз) | 200, баланс 500 |
| 2 | Owner: POST /api/projects (W4 E2E Project, public/recruiting) | 201 |
| 3 | Owner: POST /api/lots (Backend LOT E2E, бюджет 20, acceptUntil) | 201 |
| 4 | Candidate: регистрация; POST /api/lots/[id]/respond | 201; отклики владельца скрыты от кандидата (только count=1) |
| 5 | Owner: POST /api/lots/[id]/accept | 200, escrowTxId создан, баланс 500→480 (эскроу 20) |
| 6 | Candidate до принятия в команду: комментарий milestone | 403 FORBIDDEN (правило участников работает) |
| 7 | Candidate: заявка POST /api/projects/[id]/applications → Owner PATCH accept | 201 → 200 joined=true |
| 8 | Candidate: комментарий milestone | 200 (после членства — доступ открыт) |
| 9 | Owner: POST /api/lots/[id]/complete | release: кандидат 0→20 люменов; повторный complete → 409 (идемпотентный guard) |
| 10 | Owner: POST /api/projects/[id]/reviews (scoreInternal 5) | 201; повторный → 409 ALREADY_REVIEWED |
| 11 | §3.3-щит: GET /api/projects (16 шт.) — поля rating нет; публичные отзывы — scoreInternal не утекает | PASS |

## Браузерная проверка (agent-browser)

- Project Room открывается, все 8 табов рендерятся: Обзор/Команда/Роли/Доказательства/Этапы/Обсуждение/Результаты/LOT.
- Таб LOT: карточка с 9 блоками (обзор, условия, навыки, сроки, бюджет, отклики, заказчик, статус «Завершён», действия) — контент из API.
- Таб Результаты: отзыв с меткой «проверенный участник», «готов(а) работать снова», scoreInternal НЕ отображается.
- Таб Этапы: «E2E Milestone / Запланирован / В работу» — реальный переход статуса доступен.
- **Найден и исправлен баг**: shadcn TabsTrigger `h-[calc(100%-1px)]`+`flex-1` ломает многострочный таб-бар на 390px (триггеры 139px, перекрытие контента). Фикс: `h-auto flex-none px-2.5 py-1` + `items-stretch` на списке. После фикса: 8 триггеров × 44px, 3 строки без перекрытий (скриншот).
- Мобильная 390px: `e2e-mobile-390.png` — чисто. Desktop: `e2e-desktop.png` — чисто.
- Console errors: 0 (только pre-existing aria-describedby-предупреждения shadcn Dialog, не из Wave 4 кода).

## Замечания (честно)

- email-верификация E2E-пользователей выполнена прямой записью в БД (в песочнице нет почтового сервера); продакшн-путь — через письмо со ссылкой /api/auth/verify-email?token=…
- Dev-сервер песочницы периодически гасится супервизором — рестарты в процессе E2E, к логике отношения не имеет.
