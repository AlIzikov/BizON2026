# Gates: wave-2 «Store MVP» (§18 — закрытие единственного MISSING)

OWNS: src/lib/services/store-service.ts, src/app/api/store/**, src/components/store/**, src/lib/services/lumen-service.ts (EXTEND), specs/wave-2/**, docs/adr/adr-store-item.md, docs/KYC-REAL-GATEWAY-GATE.md, prisma/schema.prisma (additive)

Scope: витрина + эскроу-сделки на люменах (REUSE PaymentGateway/FIX-06-паттерн), «Как со мной работать» в профиле, Premium-поверхности (is_premium, таргетинг мероприятий), adversarial «купленное ≠ доверие», E2E golden path, KYC-гейт документация.

- [x] G1: схема additive (StoreItem + StoreBooking + индексы), клиент сгенерирован
  CHECK: grep -q "model StoreItem" ../../prisma/schema.prisma && grep -q "model StoreBooking" ../../prisma/schema.prisma && grep -q "releaseTxId" ../../prisma/schema.prisma && grep -q "priceLumens" ../../prisma/schema.prisma && echo SCHEMA_OK
  EXPECT: SCHEMA_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=89cea948cfe00b9a31f21eefe968ca9b95f40dc9606bd06914ee9f3cd867c452; exit=0; EXPECT=matched; output-sha256=fb11620d9c6dc2909ba705d28b141ca072015bc71e956ba26aadbf549a37f346; output-bytes=10; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries

- [x] G2: TypeScript без ошибок
  CHECK: NODE_OPTIONS=6GB bunx tsc --noEmit --incremental false && echo TSC_OK
  EXPECT: TSC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0f5813199f5c0acdbd66717e944698ddccbcd31c3ea02a24b0711adf92b8d2f0; exit=0; EXPECT=matched; output-sha256=d018f66bb24b65f8f3c86936c97cc0c033c796f2f7b335753a186d3d2c5818a4; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries

- [x] G3: юнит-щит Wave 2 (эскроу атомарен, self-purchase BLOCKED, insufficient, refund идемпотентен, слоты не перепроданы)
  CHECK: bun test ../../tests/wave2-store.test.ts > /tmp/w2-unit.txt 2>&1; grep -q "0 fail" /tmp/w2-unit.txt && echo UNIT_OK
  EXPECT: UNIT_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=cadb1ab8a52d0411676a7d6623eb80ed1cfc9816c38b03f61ca48513ad1f5e2d; exit=0; EXPECT=matched; output-sha256=d2ba9d9a83b018d960cf5075e52778d3ecaae3e2b822698bdfa82f97c7ae9843; output-bytes=8; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries

- [x] G4: adversarial Wave 2 «купленная рекомендация не влияет на trust» — BLOCKED
  CHECK: bun test ../../tests/wave2-adversarial.test.ts > /tmp/w2-adv.txt 2>&1; grep -q "0 fail" /tmp/w2-adv.txt && echo ADV_OK
  EXPECT: ADV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=3d40a248ef5c9de40020c0847a6616668cb8d3d396910a336a67f84c4503285d; exit=0; EXPECT=matched; output-sha256=db61b1220d8ee892366cb62e778ff695edba92d6e1ca0403232b65b6c35086b6; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries

- [x] G5: регрессия Wave 1 не сломана (trust-щит зелёный)
  CHECK: bun test ../../tests/wave1-trust.test.ts > /tmp/w2-r1.txt 2>&1; grep -q "0 fail" /tmp/w2-r1.txt && echo REG_OK
  EXPECT: REG_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=93d27ac6e4965a4b4cfae91dfe7e24b26bf46b328da6c8cd67bd58c9d9c07be3; exit=0; EXPECT=matched; output-sha256=b38d3551aea3b4c4ad441b48cf989f7182353d487ef29df28897530666d7915f; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries

- [x] G6: governance: SPEND_MONEY покрывает покупку, аудит на каждой смене статуса, velocity на booking
  CHECK: grep -q "SPEND_MONEY" ../../src/lib/services/store-service.ts && grep -q "STORE_BOOKING_CREATED" ../../src/lib/services/store-service.ts && grep -q "STORE_BOOKING_RELEASED" ../../src/lib/services/store-service.ts && grep -q "checkVelocity" "../../src/app/api/store/items/[id]/book/route.ts" && echo GOV_OK
  EXPECT: GOV_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=aa8005653aab74429992a3eb551ccaf10b58dc1cd9ce8ee043b5949e4499361d; exit=0; EXPECT=matched; output-sha256=04e014c59e5f904ccc0b11ce59fdfd38891746acff3430961dfda1470cb8b7b8; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries

- [x] G7: UI Wave 2 смонтирован (view store в page.tsx + секция «Как со мной работать» в профиле)
  CHECK: grep -q "StoreView" ../../src/app/page.tsx && grep -q "StoreSection" ../../src/components/profile/profile-view.tsx && echo UI_OK
  EXPECT: UI_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0beafd6454d657c84f63456effc719bff3196e41030a932fdb4e28c5a3b9c6ec; exit=0; EXPECT=matched; output-sha256=a8ec7b91c067b01cc6fc5b9771e39b084c4cf58cc6eca98f7d97339bd770b4b8; output-bytes=6; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries

- [x] G8: KYC-гейт реальных денег задокументирован ДО приёма денег
  CHECK: grep -q "KYC" ../../docs/KYC-REAL-GATEWAY-GATE.md && grep -q "ExternalGatewayAdapter" ../../docs/KYC-REAL-GATEWAY-GATE.md && grep -q "чек-пойнт" ../../docs/KYC-REAL-GATEWAY-GATE.md && echo KYC_OK
  EXPECT: KYC_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=ddd64b1b12fdaec9b9ab5b9e6c3a1ddf824de74b3d1cca9ef8609424556f63e1; exit=0; EXPECT=matched; output-sha256=96ff1dd5d1bee7b03dbc80e4b19853d3f5b9320760d645a4c387cd5231ed3cf8; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries

- [x] G9: E2E golden path пройден (витрина → booking → fulfil → release; балансы сходятся)
  CHECK: grep -q "E2E_PASS" ../../specs/wave-2/E2E-REPORT.md && echo E2E_OK
  EXPECT: E2E_OK
  EVIDENCE: automatic-evidence=v1; definition-sha256=0583008baaea08052222f9415d44ebfeb138a313073dffb82f6c6cd4916f31fd; exit=0; EXPECT=matched; output-sha256=17bcec81990e29d5cbe0c8cd478cd945c72688099349aa1afc68031cfdcbcd94; output-bytes=7; shell=/bin/sh; cwd=/home/z/my-project/specs/wave-2; path=cc94915413e1/11 entries
