// =============================================================================
// A3 «Red-Team» (R2-A3) — ВАЛИДАЦИЯ ВХОДА: NaN/типы в люмен-операциях,
// инъекции в name/email/title, неограниченная длина, обход границ в updateItem.
//
// BLOCKED-семантика: зелёный = система отбила атаку; красный = BizON сломан.
// =============================================================================

import '../tests/helpers/setup';
import { beforeAll, describe, expect, test } from 'bun:test';

import { db } from '@/lib/db';
import { AuthService } from '@/lib/services/auth-service';
import { LumenService } from '@/lib/services/lumen-service';
import { StoreService } from '@/lib/services/store-service';
import { BizonError } from '@/lib/errors';

const GOOD_PASSWORD = 'Correct-Horse-9!';

describe('A3 Validation: инъекции и типы на уровне сервисов', () => {
  let sellerId = '';
  let richId = '';

  beforeAll(async () => {
    sellerId = (await AuthService.register({ email: 'a3val-seller@bizon.test', password: GOOD_PASSWORD, name: 'A3 Val Seller' })).id;
    richId = (await AuthService.register({ email: 'a3val-rich@bizon.test', password: GOOD_PASSWORD, name: 'A3 Val Rich' })).id;
    await db.user.update({ where: { id: richId }, data: { lumenBalance: { increment: 300 } } });
  });

  test('[A3-ATK-016] Store: updateItem принимает невалидный slotsTotal (в createItem — граница 0..1000)', async () => {
    const item = await StoreService.createItem(sellerId, {
      type: 'expert-access', title: 'A3-016 slots', description: '', priceLumens: 20, deliveryMode: 'online-meeting', slotsTotal: 3,
    });

    // АТАКА: владелец ослабляет/ломает квоту через боковую дверь updateItem.
    let negativeAccepted = false;
    try {
      await StoreService.updateItem(sellerId, item.id, { slotsTotal: -1 });
      negativeAccepted = true;
    } catch (e) {
      if (!(e instanceof BizonError)) throw e; // иная ошибка — не BLOCKED-семантика по контрактам API
    }
    if (negativeAccepted) {
      const after = await db.storeItem.findUnique({ where: { id: item.id } });
      throw new Error(
        `A3-ATK-016 АТАКА УДАЛАСЬ: updateItem записал slotsTotal=${after?.slotsTotal} (createItem требует 0..1000). ` +
        'slot-guard в requestBooking трактует slotsTotal<=0 как «безлимит» — квота сессий тихо снята. store-service.ts:255.',
      );
    }

    // NaN тоже должен быть отброшен (любым исключением с отклонением записи)
    let nanRejected = false;
    try {
      await StoreService.updateItem(sellerId, item.id, { slotsTotal: Number.NaN });
    } catch {
      nanRejected = true;
    }
    if (!nanRejected) throw new Error('A3-ATK-016b АТАКА УДАЛАСЬ: updateItem принял slotsTotal=NaN.');
    expect(true).toBe(true);
  });

  test('[A3-ATK-017] Регистрация: name с HTML/спецсимволами и неограниченной длиной сохраняется дословно', async () => {
    // (а) XSS-носитель в имени
    const payload = '<script>alert("A3-017")</script>';
    const u1 = await AuthService.register({ email: 'a3val-xss@bizon.test', password: GOOD_PASSWORD, name: payload });
    if (u1.name.includes('<script')) {
      throw new Error(
        `A3-ATK-017a АТАКА УДАЛАСЬ: name сохранён дословно с <script> (userId=${u1.id}). ` +
        'AuthService.register:50 не применяет ни sanitizeUserText, ни ограничение длины.',
      );
    }

    // (б) длина имени не ограничена (контракт аудита: максимум 300)
    const longName = 'A'.repeat(5000);
    const u2 = await AuthService.register({ email: 'a3val-long@bizon.test', password: GOOD_PASSWORD, name: longName });
    if (u2.name.length > 300) {
      throw new Error(
        `A3-ATK-017b АТАКА УДАЛАСЬ: name длиной ${u2.name.length} символов принят (контракт: максимум 300). ` +
        'Хранится в профиле и расходуется в уведомлениях/ленте без ограничений.',
      );
    }
    expect(true).toBe(true);
  });

  test('[A3-ATK-018] Store: title/description товара с HTML сохраняются дословно', async () => {
    const title = '<script>alert("A3-018")</script>Консультация';
    const item = await StoreService.createItem(sellerId, {
      type: 'services', title, description: 'Обычное описание', priceLumens: 10, deliveryMode: 'async',
    });
    const stored = await db.storeItem.findUnique({ where: { id: item.id } });
    if (stored && stored.title.includes('<script')) {
      throw new Error(
        `A3-ATK-018 АТАКА УДАЛАСЬ: title товара сохранён с <script> дословно (itemId=${stored.id}). ` +
        'store-service.ts:160 — только trim(); sanitizeUserText не применён.',
      );
    }
    expect(stored?.title).not.toContain('<script');
  });

  test('[A3-ATK-020] Регистрация: email без формата и длины (сервисный уровень)', async () => {
    // (а) не-email вообще
    let badFormatAccepted = false;
    let u3id = '';
    try {
      const u = await AuthService.register({ email: 'not-an-email-at-all', password: GOOD_PASSWORD, name: 'A3 BadEmail' });
      badFormatAccepted = true;
      u3id = u.id;
    } catch { /* BLOCKED */ }
    if (badFormatAccepted) {
      throw new Error(
        `A3-ATK-020a АТАКА УДАЛАСЬ: AuthService.register принял email «not-an-email-at-all» (userId=${u3id}). ` +
        'auth-service.ts:27-32 — проверок формата нет (route проверяет только includes("@")).',
      );
    }

    // (б) сверхдлинный email
    const longEmail = `a3val-long-${'x'.repeat(500)}@bizon.test`;
    let longAccepted = false;
    try {
      await AuthService.register({ email: longEmail, password: GOOD_PASSWORD, name: 'A3 LongEmail' });
      longAccepted = true;
    } catch { /* BLOCKED */ }
    if (longAccepted) {
      throw new Error(
        `A3-ATK-020b АТАКА УДАЛАСЬ: email длиной ${longEmail.length} символов принят сервисом без ограничения длины.`,
      );
    }

    // контроль: валидный формат проходит
    const ok = await AuthService.register({ email: 'a3val-ok@bizon.test', password: GOOD_PASSWORD, name: 'A3 OkEmail' });
    if (!ok.emailHash) throw new Error('fixture: нормальная регистрация сломалась');
    expect(true).toBe(true);
  });

  test('[A3-ATK-020c] Люмены: NaN/строка не изменяют баланс ни в одной операции', async () => {
    const before = (await db.user.findUnique({ where: { id: richId }, select: { lumenBalance: true } }))!.lumenBalance;

    const spendNaN = await LumenService.spendVar(richId, Number.NaN, { action: 'x', label: 'x' });
    const spendStr = await LumenService.spendVar(richId, '100' as unknown as number, { action: 'x', label: 'x' });
    if (spendNaN.ok || spendStr.ok) {
      throw new Error('A3-ATK-020c АТАКА УДАЛАСЬ: spendVar принял NaN/строку.');
    }

    let debitThrew = 0;
    for (const bad of [Number.NaN, '100' as unknown as number, Number.POSITIVE_INFINITY]) {
      try { await LumenService.debit(richId, bad as number, { action: 'x', label: 'x' }); } catch { debitThrew++; }
    }
    if (debitThrew !== 3) {
      throw new Error(`A3-ATK-020d АТАКА УДАЛАСЬ: debit принял некорректные типы (отбито ${debitThrew}/3).`);
    }

    const after = (await db.user.findUnique({ where: { id: richId }, select: { lumenBalance: true } }))!.lumenBalance;
    expect(after).toBe(before);
  });
});
