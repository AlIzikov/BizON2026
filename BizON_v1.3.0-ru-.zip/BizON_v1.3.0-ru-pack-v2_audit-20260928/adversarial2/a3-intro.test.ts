// =============================================================================
// A3 «Red-Team» (R2-A3) — ИНТРО-ЦИКЛ: self-intro, согласие (consent), velocity,
// перенос пользовательского текста в сообщения (XSS-носитель).
//
// BLOCKED-семантика: зелёный = система отбила атаку; красный = BizON сломан.
// =============================================================================

import '../tests/helpers/setup';
import { beforeAll, describe, expect, test } from 'bun:test';

import { db } from '@/lib/db';
import { registerUser } from '@/lib/auth';
import { AuthService } from '@/lib/services/auth-service';
import { introService } from '@/lib/services/intro-service';
import { evaluateIntroRequest } from '@/lib/services/sarafan-guard';
import { BizonError } from '@/lib/errors';

async function connect(a: string, b: string) {
  await db.connection.create({ data: { fromUserId: a, toUserId: b, status: 'accepted', kind: 'colleague', provenance: 'manual' } });
}
async function mkUser(email: string, name: string) {
  return (await registerUser({ email, password: 'Correct-Horse-9!', name })).user.id;
}

describe('A3 Intro: инварианты цикла знакомств', () => {
  let requester = '';
  let mediator = '';
  let target = '';
  let stranger = '';

  beforeAll(async () => {
    requester = await mkUser('a3intro-requester@bizon.test', 'A3 Intro Requester');
    mediator = await mkUser('a3intro-mediator@bizon.test', 'A3 Intro Mediator');
    target = await mkUser('a3intro-target@bizon.test', 'A3 Intro Target');
    stranger = await mkUser('a3intro-stranger@bizon.test', 'A3 Intro Stranger');
    await connect(requester, mediator);
    await connect(mediator, target);
  });

  test('[A3-ATK-013] Интро: self-intro, мусорная цель, дубликат pending, accept по истечении', async () => {
    // self-intro
    let selfBlocked = false;
    try { await introService.create(requester, requester, 'job'); } catch (e) {
      if (!(e instanceof BizonError)) throw e;
      selfBlocked = true;
    }
    if (!selfBlocked) throw new Error('A3-ATK-013a АТАКА УДАЛАСЬ: self-intro (requester==target) прошёл.');

    // недопустимая цель
    let purposeBlocked = false;
    try { await introService.create(requester, target, 'scam-purposes'); } catch (e) {
      if (!(e instanceof BizonError)) throw e;
      purposeBlocked = true;
    }
    if (!purposeBlocked) throw new Error('A3-ATK-013b АТАКА УДАЛАСЬ: purpose вне белого списка принят.');

    // дубликат pending на ту же пару
    const first = await introService.create(requester, target, 'job');
    let dupBlocked = false;
    try { await introService.create(requester, target, 'job'); } catch (e) {
      if (!(e instanceof BizonError)) throw e;
      dupBlocked = true;
    }
    if (!dupBlocked) throw new Error('A3-ATK-013c АТАКА УДАЛАСЬ: второй активный pending на ту же пару создан.');

    // accept после истечения TTL
    await db.introductionRequest.update({
      where: { id: first.id },
      data: { expiresAt: new Date(Date.now() - 1000) },
    });
    let expiredBlocked = false;
    try { await introService.accept(first.id, mediator); } catch (e) {
      if (!(e instanceof BizonError)) throw e;
      expiredBlocked = true;
    }
    if (!expiredBlocked) throw new Error('A3-ATK-013d АТАКА УДАЛАСЬ: согласие по истёкшему интро принято.');

    // accept чужого (не посредника) — уже в ATK-007, здесь повтор для полноты цикла
    let foreignBlocked = false;
    try { await introService.accept(first.id, stranger); } catch (e) {
      if (!(e instanceof BizonError)) throw e;
      foreignBlocked = true;
    }
    if (!foreignBlocked) throw new Error('A3-ATK-013e АТАКА УДАЛАСЬ: чужое интро принято посторонним.');
    expect(true).toBe(true);
  });

  test('[A3-ATK-014] Интро: consent-обход — диалог до accept посредника (параллельный путь чата)', async () => {
    const { POST } = await import('@/app/api/messages/route');
    // создаём pending-интро: согласия посредника ещё НЕТ
    const intro = await introService.create(requester, target, 'project');
    const convBefore = await db.conversation.findFirst({
      where: { OR: [{ fromUserId: requester, toUserId: target }, { fromUserId: target, toUserId: requester }] },
    });
    if (convBefore) {
      throw new Error('A3-ATK-014a АТАКА УДАЛАСЬ: диалог создан ещё ДО accept посредника (внутри интро-цикла).');
    }

    // Контроль: гейт для новичка (ipScore=0) честно отбивает — гейт СУЩЕСТВУЕТ.
    await db.user.update({ where: { id: stranger }, data: { ipScore: 0 } });
    const token0 = await AuthService.createSession(stranger);
    const res0 = await POST(
      new Request('http://localhost/api/messages', {
        method: 'POST',
        headers: { authorization: `Bearer ${token0}`, 'content-type': 'application/json' },
        body: JSON.stringify({ toUserId: target, content: 'A3-014 контроль ipScore=0' }),
      }) as never,
    );
    if (res0.status === 201) {
      throw new Error('A3-ATK-014c АТАКА УДАЛАСЬ: ipScore=0 прошёл гейт прямых сообщений незнакомцу.');
    }

    // АТАКА: гейт — репутационный порог ipScore>=30 («позволяет экспертам отправлять
    // интро незнакомцам», M4), а НЕ согласие посредника. ipScore достижим легитимной
    // активностью → consent-инвариант интро-цикла обходится параллельным путём.
    await db.user.update({ where: { id: requester }, data: { ipScore: 30 } });
    const token = await AuthService.createSession(requester);
    const req = new Request('http://localhost/api/messages', {
      method: 'POST',
      headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
      body: JSON.stringify({ toUserId: target, content: 'A3-014: пишу до согласия посредника' }),
    });
    const res = await POST(req as never);
    if (res.status === 201) {
      const convAfter = await db.conversation.findFirst({
        where: { OR: [{ fromUserId: requester, toUserId: target }, { fromUserId: target, toUserId: requester }] },
      });
      throw new Error(
        `A3-ATK-014b АТАКА УДАЛАСЬ: /api/messages создал диалог ${convAfter?.id ?? '?'} с незнакомцем ДО accept интро ` +
        `(контроль ipScore=0 отбился с кодом ${res0.status} — гейт существует, но он репутационный, а не consent-ный). ` +
        'Инвариант intro-service «сообщение цели уходит ТОЛЬКО после accept посредника» обходится.',
      );
    }
    expect(res.status).not.toBe(201);
  });

  test('[A3-ATK-015] Интро: velocity — спам интро-запросами не блокируется', async () => {
    const spammer = await mkUser('a3intro-spammer@bizon.test', 'A3 Spammer');
    // 8 интро-запросов за последний час на 8 разных целей (fixture истории)
    const targets: string[] = [];
    for (let i = 0; i < 8; i++) {
      const t = await mkUser(`a3intro-spam-target-${i}@bizon.test`, `A3 SpamTarget ${i}`);
      targets.push(t);
      await db.introductionRequest.create({
        data: {
          requesterId: spammer, introducerId: mediator, targetId: t,
          purpose: 'other', message: 'A3-015 velocity fixture', status: 'pending',
          expiresAt: new Date(Date.now() + 7 * 86_400_000),
        },
      });
    }

    const failures: string[] = [];

    // (а) velocity на новом неверифицированном аккаунте: 25 (час) + 25 (новый/нужный объём) = 50 < 70
    const v1 = await evaluateIntroRequest(spammer);
    if (v1.allowed) {
      failures.push(
        `A3-ATK-015a АТАКА УДАЛАСЬ: 8 интро/час разрешены гвардом (riskScore=${v1.riskScore} < 70, action=${v1.action}). ` +
        'Чистый velocity-спам не блокируется никогда.',
      );
    }

    // (б) взаимное кольцо на ВЕРИФИЦИРОВАННОМ аккаунте: 40 < 70 → observe/allow
    const ringer = await mkUser('a3intro-ringer@bizon.test', 'A3 Ringer');
    await db.user.update({ where: { id: ringer }, data: { verificationTier: 'contact_verified' } });
    const ringTarget = targets[0];
    await db.introductionRequest.create({
      data: {
        requesterId: ringTarget, introducerId: mediator, targetId: ringer,
        purpose: 'other', message: 'A3-015 reciprocal', status: 'pending',
        expiresAt: new Date(Date.now() + 7 * 86_400_000),
      },
    });
    await db.introductionRequest.create({
      data: {
        requesterId: ringer, introducerId: mediator, targetId: ringTarget,
        purpose: 'other', message: 'A3-015 reciprocal', status: 'pending',
        expiresAt: new Date(Date.now() + 7 * 86_400_000),
      },
    });
    const v2 = await evaluateIntroRequest(ringer);
    if (v2.allowed) {
      failures.push(
        `A3-ATK-015b АТАКА УДАЛАСЬ: взаимное кольцо «ты-за-меня» на верифицированном аккаунте разрешено ` +
        `(riskScore=${v2.riskScore} < 70, action=${v2.action}).`,
      );
    }
    if (failures.length > 0) throw new Error(failures.join(' | '));
    expect(!v1.allowed && !v2.allowed).toBe(true);
  });

  test('[A3-ATK-019] Интро: пользовательский текст без санитизации уходит в сообщения цели', async () => {
    const r2 = await mkUser('a3intro-xss-r@bizon.test', 'A3 XSS Requester');
    const t2 = await mkUser('a3intro-xss-t@bizon.test', 'A3 XSS Target');
    await connect(r2, mediator);
    await connect(mediator, t2);

    const payload = '<img src=x onerror=alert("A3-019")>Познакомимся?';
    const intro = await introService.create(r2, t2, 'other', payload);
    await introService.accept(intro.id, mediator); // посредник согласился — цикл легитимный

    const msg = await db.message.findFirst({
      where: { conversation: { fromUserId: r2, toUserId: t2 } },
      orderBy: { createdAt: 'desc' },
    });
    if (msg && msg.content.includes('onerror')) {
      throw new Error(
        `A3-ATK-019 АТАКА УДАЛАСЬ: текст интро с <img onerror> сохранён в Message ДОСЛОВНО ` +
        `(messageId=${msg.id}). sanitizeUserText не применён: intro-service.ts:107 (slice 2000) → message.create:174.`,
      );
    }
    if (!msg) throw new Error('fixture: сообщение после accept не найдено');
    expect(msg.content).not.toContain('onerror');
  });
});
