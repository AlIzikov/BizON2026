// =============================================================================
// A5 «Formal-Invariants» (R2-A5) — денежное ядро: I1 SPLIT, I2 ESCROW-IDEMPOTENT,
// I3 NON-NEG, I4 LEDGER-CONSERVATION.
//
// Методика: rocq-мышление — каждый инвариант сформулирован как теорема с
// кванторами (полные формулировки: docs/audit/r2/A5-invariants.md). Полный
// Rocq-тулчейн в песочнице недоступен (зафиксировано в
// docs/knowledge/REPO-LEARNING-2026-09-19.md §5) — те же свойства проверяются
// property-тестами bun на конечных данных.
//
// Семантика тестов A5:
//   • PROVEN   — зелёный тест, утверждающий КОРРЕКТНОЕ поведение (свойство выполняется);
//   • COUNTEREXAMPLE — зелёный тест, утверждающий ФАКТИЧЕСКОЕ поведение системы
//     там, где теорема требует иного: это воспроизведённый контрпример
//     (инвариант VIOLATED). Ничего не чинится: src/** и prisma/** только читаются.
//
// Изоляция: tests/helpers/setup.ts — работа с копией db/custom.db во tmp.
// Файл НЕ вызывает cleanupTestDb: при совместном прогоне a5-*.test.ts БД одна
// на процесс (module cache), удалять её до конца прогона нельзя.
// =============================================================================

import '../tests/helpers/setup';

// Kill-switch дивидендов (FIX-08): в conservation-модели не должно быть
// внеплановых начислений (accrueInternal срабатывает только из getWallet,
// но выключаем и на будущее).
process.env.LUMEN_DIVIDENDS_ENABLED = '0';

import { afterAll, beforeAll, describe, expect, test } from 'bun:test';

import { Prisma } from '@prisma/client';
import { db } from '@/lib/db';
import { registerUser } from '@/lib/auth';
import { LumenService } from '@/lib/services/lumen-service';
import { StoreService } from '@/lib/services/store-service';
import {
  COMMISSION_PERCENT_CAP,
  computeSplit,
  getCashierConfig,
} from '@/lib/services/virtual-cashier-service';
import { BizonError } from '@/lib/errors';

// -----------------------------------------------------------------------------
// Детерминированный PRNG (mulberry32) — воспроизводимость property-прогонов
// -----------------------------------------------------------------------------

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

async function balanceOf(userId: string): Promise<number> {
  const u = await db.user.findUnique({ where: { id: userId }, select: { lumenBalance: true } });
  return u?.lumenBalance ?? 0;
}

async function ledgerSum(userId: string): Promise<number> {
  const agg = await db.lumenTransaction.aggregate({
    _sum: { lumens: true },
    where: { userId },
  });
  return agg._sum.lumens ?? 0;
}

const CASHIER_ENV_KEYS = ['CASHIER_MODE', 'PLATFORM_COMMISSION_PERCENT', 'CASHIER_PLATFORM_ACCOUNT_ID', 'STORE_REAL_MONEY_ENABLED'] as const;
let savedEnv: Record<string, string | undefined> = {};

const trackedUsers: string[] = [];
let userSeq = 0;

async function makeUser(tag: string): Promise<{ id: string; email: string }> {
  userSeq += 1;
  const email = `a5m-${tag}-${userSeq}-${Date.now()}@a5.test`;
  const { user } = await registerUser({ email, password: 'Correct-Horse-9!', name: `A5 Money ${tag}` });
  trackedUsers.push(user.id);
  return { id: user.id, email };
}

async function giveLumens(userId: string, amount: number): Promise<void> {
  // пополнение демо-шлюзом, только валидные суммы каталога
  let remaining = amount;
  while (remaining > 0) {
    const step = Math.min(remaining, 1000);
    const res = await LumenService.topup(userId, step);
    if (!res.ok) throw new Error(`topup failed: ${JSON.stringify(res)}`);
    remaining -= step;
  }
}

// =============================================================================
// I1 (SPLIT)
// Теорема: ∀ amount ∈ ℤ, amount ≥ 1; ∀ p ∈ ℤ ∩ [0, CAP=50]:
//   commission = floor(amount·p / 100)
//   ∧ sellerGets = amount − commission
//   ∧ commission + sellerGets = amount          (сохранение суммы)
//   ∧ commission ≥ 0 ∧ sellerGets ≥ 0           (неотрицательность долей)
// Гарантия в коде: src/lib/services/virtual-cashier-service.ts:126-138 (computeSplit),
// кап p — конфиг-слой parseCommissionPercent (там же :94-104).
// =============================================================================

describe('A5-I1 SPLIT: computeSplit сохраняет сумму и округляет комиссию вниз', () => {
  const AMOUNTS = [1, 2, 3, 5, 7, 10, 99, 100, 101, 123, 499, 500, 501, 999, 1000, 1234, 9999, 99_999, 999_999, 1_000_000, 1_000_000_000, 1_999_999_999];

  test('PROVEN: ∀ amount∈A, ∀p∈[0..cap]: conservation ∧ floor ∧ неотрицательность долей', () => {
    let cases = 0;
    for (const amount of AMOUNTS) {
      for (let p = 0; p <= COMMISSION_PERCENT_CAP; p++) {
        const { commission, sellerGets } = computeSplit(amount, p);
        expect(commission).toBe(Math.floor((amount * p) / 100)); // определение floor
        expect(sellerGets).toBe(amount - commission);            // определение доли продавца
        expect(commission + sellerGets).toBe(amount);            // сохранение суммы
        expect(commission).toBeGreaterThanOrEqual(0);
        expect(sellerGets).toBeGreaterThanOrEqual(0);
        cases++;
      }
    }
    console.log(`[A5-I1] PROVEN на ${cases} пар (amount × p∈[0..${COMMISSION_PERCENT_CAP}])`);
  });

  test('PROVEN: границы — amount=1, p=0, p=cap, amount=999, большие числа', () => {
    expect(computeSplit(1, 0)).toEqual({ commission: 0, sellerGets: 1 });
    expect(computeSplit(1, COMMISSION_PERCENT_CAP)).toEqual({ commission: 0, sellerGets: 1 }); // floor(0.5)=0
    expect(computeSplit(2, COMMISSION_PERCENT_CAP)).toEqual({ commission: 1, sellerGets: 1 });
    expect(computeSplit(999, 5)).toEqual({ commission: 49, sellerGets: 950 }); // floor(49.95)
    expect(computeSplit(1_000_000_000, 50)).toEqual({ commission: 500_000_000, sellerGets: 500_000_000 });
    expect(computeSplit(1_999_999_999, 3)).toEqual({ commission: 59_999_999, sellerGets: 1_940_000_000 }); // floor(5_999_999_997/100)
  });

  test('PROVEN: невалидные входы отклоняются (0, дробные, отрицательные, NaN)', () => {
    expect(() => computeSplit(0, 0)).toThrow(BizonError);
    expect(() => computeSplit(-5, 0)).toThrow();
    expect(() => computeSplit(10.5, 0)).toThrow();
    expect(() => computeSplit(Number.NaN, 0)).toThrow();
    expect(() => computeSplit(100, -1)).toThrow();
    expect(() => computeSplit(100, 1.5)).toThrow();
    expect(() => computeSplit(100, Number.NaN)).toThrow();
  });

  test('A5-6 FIXED (KV2): внутренний guard p≤100 в самой computeSplit', () => {
    // Было (COUNTEREXAMPLE-замечание): прямой вызов computeSplit(100,200) давал
    // sellerGets=-100. A5-6: добавлен внутренний guard ≤100% — отрицательная
    // выплата продавцу невозможна ДАЖЕ в обход конфиг-слоя (соответствует
    // теореме T1c из docs/knowledge/rocq/BizonInvariants.v).
    let threw = false;
    try {
      computeSplit(100, 200);
    } catch (e) {
      threw = e instanceof BizonError;
    }
    expect(threw).toBe(true);
    // Граница капа по-прежнему enforced и на уровне конфига:
    process.env.PLATFORM_COMMISSION_PERCENT = '5000';
    expect(() => getCashierConfig()).toThrow(/PLATFORM_COMMISSION_PERCENT/);
    delete process.env.PLATFORM_COMMISSION_PERCENT;
    console.log('[A5-I1] A5-6 FIXED: computeSplit самопроверяет p≤100 (двойная защита: функция + config).');
  });
});

// =============================================================================
// I2 (ESCROW-IDEMPOTENT)
// Теорема: ∀ booking b: release(b)² = release(b) — повторный release не меняет
//   балансы и ledger; refund(b) после release(b) не создаёт денег (эскроу
//   расходуется ровно один раз: spend(b) + ровно один исход (release | refund)).
// Теорема I2' (нет печати денег): ∀ spend-транзакции t: refund(t) ≤ spend(t).
// Гарантия в коде: store-service.ts:438-498 (release: guard updateMany по
//   status='fulfilled' + credit в одной $transaction), :501-583 (decline/cancel
//   гвардят status='held'); lumen-service.ts:505-539 (spendVar), :545-593 (refundVar,
//   идемпотентность через LumenTransaction.refundOf @unique).
// =============================================================================

describe('A5-I2 ESCROW: release² идемпотентен, refund после release не удваивает', () => {
  let buyer = '';
  let seller = '';
  let item300Id = '';

  beforeAll(async () => {
    savedEnv = Object.fromEntries(CASHIER_ENV_KEYS.map((k) => [k, process.env[k]]));
    for (const k of CASHIER_ENV_KEYS) delete process.env[k]; // комиссия 0% (дефолт владельца)

    const b = await makeUser('buyer');
    const s = await makeUser('seller');
    buyer = b.id;
    seller = s.id;
    await giveLumens(buyer, 4000);

    const item = await StoreService.createItem(seller, {
      type: 'digital',
      title: 'A5 I2: цифровой товар 300',
      description: 'инвариант-тест',
      priceLumens: 300,
      deliveryMode: 'async',
    });
    item300Id = item.id;
  });

  afterAll(() => {
    for (const k of CASHIER_ENV_KEYS) {
      if (savedEnv[k] === undefined) delete process.env[k];
      else process.env[k] = savedEnv[k];
    }
  });

  test('PROVEN: release → повторный release 409, баланс продавца не меняется, ровно один escrow_release в ledger', async () => {
    const booking = await StoreService.requestBooking(buyer, item300Id, {});
    await StoreService.fulfil(seller, booking.id);

    const before = await balanceOf(seller);
    await StoreService.release(buyer, booking.id);
    const after = await balanceOf(seller);
    expect(after - before).toBe(300); // 0% комиссия: полная сумма

    let secondError = '';
    await StoreService.release(buyer, booking.id).catch((e: unknown) => {
      secondError = e instanceof Error ? e.message : String(e);
    });
    expect(secondError).toContain('исполненный заказ'); // 409: статус уже 'released' → ранний guard
    expect(await balanceOf(seller)).toBe(after); // release² — деньги не изменились

    const releases = await db.lumenTransaction.count({
      where: { userId: seller, type: 'escrow_release', meta: { contains: booking.id } },
    });
    expect(releases).toBe(1);
    console.log('[A5-I2] PROVEN: release(x)² = release(x) на booking ' + booking.id);
  });

  test('PROVEN: refund после release (через StoreService decline/cancel) невозможен — деньги не удваиваются', async () => {
    const booking = await StoreService.requestBooking(buyer, item300Id, {});
    await StoreService.fulfil(seller, booking.id);
    await StoreService.release(buyer, booking.id);

    const buyerBefore = await balanceOf(buyer);
    await expect(StoreService.decline(seller, booking.id)).rejects.toThrow(); // только из held
    await expect(StoreService.cancel(buyer, booking.id)).rejects.toThrow();   // только из held
    expect(await balanceOf(buyer)).toBe(buyerBefore); // refund-пути закрыты статусом
  });

  test('PROVEN: гонка двух параллельных release → ровно один зачёт продавцу', async () => {
    const booking = await StoreService.requestBooking(buyer, item300Id, {});
    await StoreService.fulfil(seller, booking.id);
    const before = await balanceOf(seller);

    const settled = await Promise.allSettled([StoreService.release(buyer, booking.id), StoreService.release(buyer, booking.id)]);
    const okCount = settled.filter((r) => r.status === 'fulfilled').length;
    expect(okCount).toBe(1);
    expect(await balanceOf(seller) - before).toBe(300); // зачислен ровно один раз

    const releases = await db.lumenTransaction.count({
      where: { userId: seller, type: 'escrow_release', meta: { contains: booking.id } },
    });
    expect(releases).toBe(1);
  });

  test('PROVEN: гонка двух параллельных refundVar → ровно один инкремент (refundOf @unique + P2002)', async () => {
    const spend = await LumenService.spendVar(buyer, 150, { action: 'store_escrow', label: 'A5: гонка refund' });
    expect(spend.ok).toBe(true);
    if (!spend.ok) return;
    const before = await balanceOf(buyer);

    const results = await Promise.allSettled([
      LumenService.refundVar(buyer, 150, 'гонка-1', spend.transactionId),
      LumenService.refundVar(buyer, 150, 'гонка-2', spend.transactionId),
    ]);
    for (const r of results) expect(r.status).toBe('fulfilled');
    expect(await balanceOf(buyer) - before).toBe(150); // возврат ровно один

    const refunds = await db.lumenTransaction.count({ where: { refundOf: spend.transactionId } });
    expect(refunds).toBe(1);
  });

  test('PROVEN: повторный refundVar по тому же spend — идемпотентный no-op', async () => {
    const spend = await LumenService.spendVar(buyer, 120, { action: 'store_escrow', label: 'A5: идемпотент refund' });
    if (!spend.ok) throw new Error('spendVar должен пройти');
    const before = await balanceOf(buyer);
    const first = await LumenService.refundVar(buyer, 120, 'первый', spend.transactionId);
    expect(first?.alreadyRefunded).toBe(false);
    const afterFirst = await balanceOf(buyer);
    expect(afterFirst - before).toBe(120);

    const second = await LumenService.refundVar(buyer, 120, 'второй', spend.transactionId);
    expect(second?.alreadyRefunded).toBe(true);
    expect(await balanceOf(buyer)).toBe(afterFirst); // второй — no-op
  });

  test('PROVEN: refund (AI-путь) идемпотентен по spendTransactionId', async () => {
    const spend = await LumenService.spend(buyer, 'cv_generate'); // cost 2
    expect(spend.ok).toBe(true);
    if (!spend.ok) return;
    const before = await balanceOf(buyer);
    await LumenService.refund(buyer, 'cv_generate', 'A5 тест', spend.transactionId);
    expect((await balanceOf(buyer)) - before).toBe(2);
    const again = await LumenService.refund(buyer, 'cv_generate', 'A5 тест повтор', spend.transactionId);
    expect(again && 'alreadyRefunded' in again ? again.alreadyRefunded : false).toBe(true);
    expect(await balanceOf(buyer)).toBe(before + 2);
  });

  test("I2' (D-19 FIXED): refundVar привязан к исходному spend → печать денег невозможна", async () => {
    // Было (A5 COUNTEREXAMPLE): spend 100 → refundVar(250) → +250 (печать денег).
    // D-19: refundAmount = -original.lumens (ledger — источник истины); переданный
    // cost — санити (расхождение логируется REFUND_AMOUNT_BOUND). Теорема
    // T_D19_fixed (docs/knowledge/rocq/BizonInvariants.v) теперь выполняется и в коде.
    const spend = await LumenService.spendVar(buyer, 100, { action: 'store_escrow', label: 'A5: провокация I2prime' });
    if (!spend.ok) throw new Error('spendVar должен пройти');
    const before = await balanceOf(buyer);

    const refund = await LumenService.refundVar(buyer, 250, 'A5: сумма больше исходного spend', spend.transactionId);
    expect(refund).not.toBeNull();
    expect(refund?.alreadyRefunded).toBe(false);
    const delta = (await balanceOf(buyer)) - before;
    expect(delta).toBe(100); // D-19: вернуло РОВНО spend (100), а не 250

    const refundRow = await db.lumenTransaction.findUniqueOrThrow({ where: { refundOf: spend.transactionId } });
    expect(refundRow.lumens).toBe(100);
    console.log(`[A5-I2'] D-19 FIXED: spend=100 → refundVar(250) зачислил 100 (привязано к ledger, не к вызывателю).`);
  });

  test('REMARK (примитив) D-19b FIXED: refund после release БЛОКИРОВАН claim-ом escrow_release', async () => {
    // Было: примитив позволял refund по release-нутой сделке (удвоение эскроу).
    // D-19b: escrow_release CLAIM-ит слот refundOf исходного spend (см. credit()) —
    // escrow закрывается РОВНО одним исходом (release ИЛИ refund), enforced
    // @unique(refundOf) на уровне БД, а не гвардами вызывающих.
    const booking = await StoreService.requestBooking(buyer, item300Id, {});
    await StoreService.fulfil(seller, booking.id);
    await StoreService.release(buyer, booking.id); // эскроу израсходован

    const reloaded = await db.storeBooking.findUniqueOrThrow({ where: { id: booking.id } });
    const spendTxId = reloaded.spendTxId;
    expect(spendTxId).not.toBeNull();
    if (!spendTxId) return;

    const buyerBefore = await balanceOf(buyer);
    const rogue = await LumenService.refundVar(buyer, 300, 'A5: refund после release (примитив)', spendTxId);
    expect(rogue).not.toBeNull();
    expect(rogue?.alreadyRefunded).toBe(true); // слот занят escrow_release
    expect((await balanceOf(buyer)) - buyerBefore).toBe(0); // удвоения эскроу нет
    console.log('[A5-I2] D-19b FIXED: refund после release = no-op (escrow_release claim-ит refundOf, защита в БД).');
  });
});

// =============================================================================
// I3 (NON-NEG)
// Теорема: ∀ последовательности операций из {spendVar, debit, spend, refund,
//   refundVar, credit, topup} с любыми значениями аргументов (включая
//   NaN/undefined/строки/дробные/отрицательные): либо операция отклонена, либо
//   после неё balance ≥ 0. Мусорные аргументы баланс не меняют.
// Гарантия в коде: guard-декремент `lumenBalance: { gte: cost }` —
//   lumen-service.ts:517-522 (spendVar), :330-334 (spend), :386-391 (debit);
//   валидация целых ≥1: :514, :382, :607 (credit throw), каталоги topup :253.
// =============================================================================

describe('A5-I3 NON-NEG: баланс никогда не уходит в минус, мусор не меняет баланс', () => {
  let u = '';

  beforeAll(async () => {
    const created = await makeUser('nonneg');
    u = created.id;
    await giveLumens(u, 1000);
  });

  test('PROVEN: NaN / undefined / строка / 0 / отрицательные / дробные отклоняются, баланс не меняется', async () => {
    const before = await balanceOf(u);
    expect(before).toBeGreaterThan(0);

    // spendVar: мусор → bad_cost
    expect(await LumenService.spendVar(u, Number.NaN, { action: 'x', label: 'x' })).toMatchObject({ ok: false, code: 'bad_cost' });
    expect(await LumenService.spendVar(u, undefined as unknown as number, { action: 'x', label: 'x' })).toMatchObject({ ok: false, code: 'bad_cost' });
    expect(await LumenService.spendVar(u, '100' as unknown as number, { action: 'x', label: 'x' })).toMatchObject({ ok: false, code: 'bad_cost' });
    expect(await LumenService.spendVar(u, 0, { action: 'x', label: 'x' })).toMatchObject({ ok: false, code: 'bad_cost' });
    expect(await LumenService.spendVar(u, -7, { action: 'x', label: 'x' })).toMatchObject({ ok: false, code: 'bad_cost' });
    expect(await LumenService.spendVar(u, 1.5, { action: 'x', label: 'x' })).toMatchObject({ ok: false, code: 'bad_cost' });

    // debit/credit: бросают ошибку валидации
    expect(LumenService.debit(u, Number.NaN, { action: 'x', label: 'x' })).rejects.toThrow();
    expect(LumenService.debit(u, 0.5, { action: 'x', label: 'x' })).rejects.toThrow();
    await db.$transaction(async (tx) => {
      await expect(LumenService.credit(tx, u, Number.NaN, { action: 'x', label: 'x' })).rejects.toThrow();
      await expect(LumenService.credit(tx, u, 2.5, { action: 'x', label: 'x' })).rejects.toThrow();
    });

    // topup: только суммы каталога
    expect(await LumenService.topup(u, 99)).toMatchObject({ ok: false });
    expect(await LumenService.topup(u, Number.NaN)).toMatchObject({ ok: false });
    expect(await LumenService.topup(u, '300' as unknown as number)).toMatchObject({ ok: false });

    // refundVar: мусорные суммы → null (no-op)
    expect(await LumenService.refundVar(u, Number.NaN, 'x', 'nonexistent')).toBeNull();
    expect(await LumenService.refundVar(u, 0, 'x', 'nonexistent')).toBeNull();

    expect(await balanceOf(u)).toBe(before); // ни одна мусорная операция не изменила баланс
  });

  test('PROVEN: попытка списать больше баланса отклонена (insufficient), баланс не изменился', async () => {
    const before = await balanceOf(u);
    const res = await LumenService.spendVar(u, before + 1000, { action: 'store_escrow', label: 'A5: оверспенд' });
    expect(res).toMatchObject({ ok: false, code: 'insufficient' });
    expect(await balanceOf(u)).toBe(before);
  });

  test('PROVEN (property): 300 случайных операций — баланс совпадает с моделью и ≥ 0 на каждом шаге', async () => {
    const users = [u];
    const model = new Map<string, number>([[u, await balanceOf(u)]]);
    const spends = new Map<string, Array<{ txId: string; cost: number; refunded: boolean }>>([[u, []]]);
    const rnd = mulberry32(20260919);

    const pick = <T,>(arr: T[]): T => arr[Math.floor(rnd() * arr.length)];
    const int = (lo: number, hi: number): number => lo + Math.floor(rnd() * (hi - lo + 1));

    for (let i = 0; i < 300; i++) {
      const uid = pick(users);
      const bal = model.get(uid) ?? 0;
      const roll = rnd();
      let expectedDelta = 0;

      if (roll < 0.2) {
        // topup валидной суммой
        const amount = pick([100, 300, 500, 1000] as const);
        const res = await LumenService.topup(uid, amount);
        expect(res.ok).toBe(true);
        expectedDelta = amount;
      } else if (roll < 0.5) {
        // spendVar: иногда оверспенд
        const cost = rnd() < 0.25 ? bal + int(1, 500) : int(1, 250);
        const res = await LumenService.spendVar(uid, cost, { action: 'store_escrow', label: `A5 seq #${i}` });
        if (cost <= bal) {
          expect(res.ok).toBe(true);
          if (res.ok) {
            (spends.get(uid) as Array<{ txId: string; cost: number; refunded: boolean }>).push({ txId: res.transactionId, cost, refunded: false });
          }
          expectedDelta = -cost;
        } else {
          expect(res).toMatchObject({ ok: false, code: 'insufficient' });
          expectedDelta = 0;
        }
      } else if (roll < 0.7) {
        // debit (guard, без эскроу-меты)
        const cost = int(1, 250);
        const res = await LumenService.debit(uid, cost, { action: 'seq_debit', label: `A5 seq #${i}` });
        if (cost <= bal) {
          expect(res.ok).toBe(true);
          expectedDelta = -cost;
        } else {
          expect(res).toMatchObject({ ok: false, code: 'insufficient' });
          expectedDelta = 0;
        }
      } else if (roll < 0.9) {
        // refundVar по корректной сумме не-возвращённого spend
        const open = (spends.get(uid) as Array<{ txId: string; cost: number; refunded: boolean }>).filter((r) => !r.refunded);
        if (open.length === 0) continue;
        const rec = pick(open);
        const res = await LumenService.refundVar(uid, rec.cost, `A5 seq refund #${i}`, rec.txId);
        expect(res?.alreadyRefunded).toBe(false);
        rec.refunded = true;
        expectedDelta = rec.cost;
      } else {
        // попытка двойного refund — обязана быть no-op
        const done = (spends.get(uid) as Array<{ txId: string; cost: number; refunded: boolean }>).filter((r) => r.refunded);
        if (done.length === 0) continue;
        const rec = pick(done);
        const res = await LumenService.refundVar(uid, rec.cost, 'двойной возврат', rec.txId);
        expect(res?.alreadyRefunded).toBe(true);
        expectedDelta = 0;
      }

      model.set(uid, bal + expectedDelta);
      const actual = await balanceOf(uid);
      expect(actual).toBe(model.get(uid)!); // модель == БД после каждой операции
      expect(actual).toBeGreaterThanOrEqual(0); // инвариант I3
    }

    // Конечная конserвация: баланс == сумме ledger-строк (дивиденды выключены)
    for (const uid of users) {
      expect(await ledgerSum(uid)).toBe(model.get(uid)!);
    }
    console.log('[A5-I3] PROVEN: 300 случайных операций, баланс ≥ 0 и совпадает с моделью на каждом шаге');
  }, 120_000);
});

// =============================================================================
// I4 (LEDGER-CONSERVATION)
// Теорема: ∀ money-операции o, выполняемой сервисом: изменение баланса == сумма
//   записей ledger (LumenTransaction), созданных o; сбой в любой точке o
//   откатывает ВСЁ (баланс без ledger и ledger без баланса невозможны).
// Гарантия в коде: одна $transaction — spend :328-347, spendVar :517-532,
//   refund :447-463/:476-491, refundVar :566-582, credit (в $transaction
//   вызывающего) :610-623. КОНТРПРИМЕР: topup :252-289 — increment и ledger
//   двумя независимыми await БЕЗ $transaction.
// =============================================================================

describe('A5-I4 LEDGER-CONSERVATION', () => {
  let seller = '';
  let item100Id = '';

  beforeAll(async () => {
    const s = await makeUser('conservation-seller');
    seller = s.id;
    const item = await StoreService.createItem(seller, {
      type: 'services',
      title: 'A5 I4: услуга 100',
      description: 'инвариант-тест',
      priceLumens: 100,
      deliveryMode: 'online-meeting',
    });
    item100Id = item.id;
  });

  test('PROVEN: сбой ПОСЛЕ credit внутри $transaction → полный откат (нет «зачисления без статуса»)', async () => {
    const u = (await makeUser('rollback-credit')).id;
    await giveLumens(u, 500);
    const before = await balanceOf(u);
    const ledgerBefore = await db.lumenTransaction.count({ where: { userId: u, type: 'escrow_release' } });

    let caught = '';
    await db.$transaction(async (tx) => {
      await LumenService.credit(tx, u, 50, { action: 'store_escrow', label: 'A5: rollback-тест' });
      throw new Error('A5 SIMULATED_CRASH: упало между credit и сменой статуса');
    }).catch((e: unknown) => {
      caught = e instanceof Error ? e.message : String(e);
    });

    expect(caught).toContain('SIMULATED_CRASH');
    expect(await balanceOf(u)).toBe(before);       // зачисление откатилось
    expect(await db.lumenTransaction.count({ where: { userId: u, type: 'escrow_release' } })).toBe(ledgerBefore); // ledger тоже
  });

  test('PROVEN: сбой ПОСЛЕ debit внутри $transaction → полный откат (нет «списания без ledger» и наоборот)', async () => {
    const u = (await makeUser('rollback-debit')).id;
    await giveLumens(u, 500);
    const before = await balanceOf(u);
    const ledgerBefore = await db.lumenTransaction.count({ where: { userId: u, type: 'spend' } });

    let caught = '';
    await db.$transaction(async (tx) => {
      await LumenService.debit(u, 50, { action: 'seq_debit', label: 'A5: rollback-debit' }, tx);
      throw new Error('A5 SIMULATED_CRASH: упало между debit и следующей операцией');
    }).catch((e: unknown) => {
      caught = e instanceof Error ? e.message : String(e);
    });

    expect(caught).toContain('SIMULATED_CRASH');
    expect(await balanceOf(u)).toBe(before);
    expect(await db.lumenTransaction.count({ where: { userId: u, type: 'spend' } })).toBe(ledgerBefore);
  });

  test("I4t (D-22 FIXED): topup АТОМАРЕН — краш записи ledger откатывает и баланс", async () => {
    // Было (A5 COUNTEREXAMPLE): increment и ledger — два независимых top-level
    // await → краш между ними = «+300 баланса без ledger».
    // D-22: обе операции в одной $transaction — краш записи ledger откатывает
    // increment. Симуляция: патчим tx.lumenTransaction.create ВНУТРИ транзакции.
    const u = (await makeUser('topup-crash')).id;
    const before = await balanceOf(u);
    const rublesBefore = (await db.user.findUniqueOrThrow({ where: { id: u }, select: { lumenRubles: true } })).lumenRubles;
    const topupLedgerBefore = await db.lumenTransaction.count({ where: { userId: u, type: 'topup' } });

    const origTransaction = db.$transaction.bind(db);
    (db as unknown as { $transaction: unknown }).$transaction = (
      fn: (tx: Prisma.TransactionClient) => Promise<unknown>,
      opts?: { maxWait?: number; timeout?: number; isolationLevel?: 'Serializable' },
    ) =>
      origTransaction(async (tx: Prisma.TransactionClient) => {
        const origCreate = tx.lumenTransaction.create.bind(tx.lumenTransaction) as (
          ...args: unknown[]
        ) => Promise<unknown>;
        let failed = false;
        tx.lumenTransaction.create = ((...args: unknown[]) => {
          if (!failed) {
            failed = true;
            return Promise.reject(new Error('A5 SIMULATED_CRASH: запись ledger не удалась'));
          }
          return origCreate(...args);
        }) as typeof tx.lumenTransaction.create;
        return fn(tx);
      }, opts);

    let caught = '';
    try {
      await LumenService.topup(u, 300);
    } catch (e) {
      caught = e instanceof Error ? e.message : String(e);
    } finally {
      (db as unknown as { $transaction: unknown }).$transaction = origTransaction; // восстановить
    }

    expect(caught).toContain('SIMULATED_CRASH');
    // D-22: ПОЛНЫЙ откат — баланс, рубли и ledger без изменений (консервация)
    expect(await balanceOf(u)).toBe(before);
    const rubles = (await db.user.findUniqueOrThrow({ where: { id: u }, select: { lumenRubles: true } })).lumenRubles;
    expect(rubles - rublesBefore).toBe(0);
    expect(await db.lumenTransaction.count({ where: { userId: u, type: 'topup' } })).toBe(topupLedgerBefore);
    expect((await balanceOf(u)) - (await ledgerSum(u))).toBe(0);
    console.log('[A5-I4] D-22 FIXED: topup атомарен — краш ledger откатил весь topup, «баланс без ledger» невозможен.');
  });

  test('PROVEN: после восстановления патча обычный topup снова атомарен по результату (balance+ledger согласованы)', async () => {
    const u = (await makeUser('topup-ok')).id;
    const res = await LumenService.topup(u, 500);
    expect(res.ok).toBe(true);
    expect(await balanceOf(u)).toBe(500);
    expect(await ledgerSum(u)).toBe(500);
  });

  test('I4c (D-22b FIXED): sweepStale КОМПЕНСИРУЕТ crash-window — деньги покупателю возвращены', async () => {
    // Было (A5 COUNTEREXAMPLE): sweep отменял held-бронь без возврата —
    // покупатель терял 100 люменов. D-22b: sweep находит spend по bookingId
    // в meta, возвращает деньги (компенсация) и закрывает бронь.
    const buyer = (await makeUser('sweep-buyer2')).id;
    await giveLumens(buyer, 500);
    const before = await balanceOf(buyer);

    // Воспроизводим итоговое состояние crash-окна: held + spendTxId=null + деньги списаны
    const booking = await db.storeBooking.create({
      data: {
        itemId: item100Id,
        buyerId: buyer,
        sellerId: seller,
        priceLumens: 100,
        status: 'held',
        createdAt: new Date(Date.now() - 20 * 60 * 1000), // старше TTL 15 мин
      },
    });
    const spend = await LumenService.spendVar(buyer, 100, { action: 'store_escrow', label: 'A5: crash-window', bookingId: booking.id });
    expect(spend.ok).toBe(true);
    // NB: spendTxId в booking НЕ записываем — это и есть точка краша.

    const sweep = await StoreService.sweepStale();
    expect(sweep.crashWindowCompensations).toBeGreaterThanOrEqual(1);

    const reloaded = await db.storeBooking.findUniqueOrThrow({ where: { id: booking.id } });
    expect(reloaded.status).toBe('cancelled');   // бронь закрыта...
    expect(reloaded.spendTxId).not.toBeNull();   // ...со ссылкой на spend...

    const refundRow = spend.ok ? await db.lumenTransaction.findUnique({ where: { refundOf: spend.transactionId } }) : null;
    expect(refundRow).not.toBeNull();            // ...возврат есть...
    expect(await balanceOf(buyer)).toBe(before); // ...деньги покупателя вернулись (консервация)
    console.log('[A5-I4] D-22b FIXED: crash-window компенсирован sweep-ом — потери покупателя исключены.');
  });
});
