// =============================================================================
// A5 «Formal-Invariants» (R2-A5) — I5 HASH-CHAIN, I6 CONSENT.
//
// Теоремы с кванторами (полные формулировки: docs/audit/r2/A5-invariants.md):
//   I5: ∀ tamper-текст (metadata/actorId/action/resource/resourceId) любой записи
//       AuditLog → verifyChain() = { ok: false }; вставка/удаление записи → ok:false;
//       порядок выборки записей не влияет на верификацию.
//   I6: ∀ userId: ¬consentAiAnalysis(userId) → AI-анализ класса A невозможен;
//       cross-border без consentCrossBorder → внешний compute запрещён.
//
// Семантика: зелёный тест, утверждающий фактическое поведение там, где теорема
// требует иного = воспроизведённый КОНТРПРИМЕР (VIOLATED). Ничего не чинится.
// Изоляция: tests/helpers/setup.ts (копия db/custom.db). Файл НЕ удаляет БД:
// при совместном прогоне a5-*.test.ts она одна на процесс.
// =============================================================================

import '../tests/helpers/setup';
process.env.LUMEN_DIVIDENDS_ENABLED = '0';

import { afterAll, beforeAll, describe, expect, test } from 'bun:test';

import { db } from '@/lib/db';
import { registerUser } from '@/lib/auth';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { SovereigntyGateway, pseudonymizeUser } from '@/lib/sovereignty/gateway';
import { BizonMomentService } from '@/lib/services/bizon-moment-service';

let userSeq = 0;
async function makeUser(tag: string): Promise<{ id: string; email: string }> {
  userSeq += 1;
  const email = `a5a-${tag}-${userSeq}-${Date.now()}@a5.test`;
  const { user } = await registerUser({ email, password: 'Correct-Horse-9!', name: `A5 Audit ${tag}` });
  return { id: user.id, email };
}

// =============================================================================
// I5 (HASH-CHAIN)
// Гарантия в коде: src/lib/data-vault/audit-log.ts:92-118 (построение цепочки:
//   chainHash = SHA256(prevHash|actorId|action|resource|resourceId|metadata|createdAt),
//   строго монотонные createdAt — S-134), :129-156 (verifyChain).
// =============================================================================

describe('A5-I5 HASH-CHAIN: tamper-evidence журнала AuditLog', () => {
  const MARK = 'a5-chain-marker';
  const entryIds: string[] = [];

  async function verifyAll() {
    return AuditLog.verifyChain(1_000_000); // окно = вся таблица (детерминизм теста)
  }

  beforeAll(async () => {
    // 5 записей одним батчем: проверка и монотонности меток, и сцепления
    for (let i = 1; i <= 5; i++) {
      AuditLog.log({
        actorId: 'a5-audit-actor',
        action: 'read_pii',
        resource: 'user:email',
        resourceId: `a5-target-${i}`,
        metadata: { [MARK]: i, note: `A5 I5 entry #${i}` },
      });
    }
    await AuditLog.flush();

    const rows = await db.auditLog.findMany({
      where: { metadata: { contains: MARK } },
      orderBy: { createdAt: 'asc' },
      select: { id: true },
    });
    expect(rows.length).toBe(5);
    entryIds.push(...rows.map((r) => r.id));
  });

  test('PROVEN: цепочка свежих записей верифицируется; порядок выборки не влияет', async () => {
    const res = await verifyAll();
    expect(res.ok).toBe(true);
    expect(res.checked).toBeGreaterThanOrEqual(5);

    // окно меньше цепочки — тоже ok (внутри функция сама упорядочивает: desc → reverse)
    const windowed = await AuditLog.verifyChain(3);
    expect(windowed.ok).toBe(true);

    // строгая монотонность createdAt соседних записей (S-134: нет одинаковых мс)
    const ts = await db.auditLog.findMany({
      where: { id: { in: entryIds } },
      orderBy: { createdAt: 'asc' },
      select: { createdAt: true },
    });
    for (let i = 1; i < ts.length; i++) {
      expect(ts[i].createdAt.getTime()).toBeGreaterThan(ts[i - 1].createdAt.getTime());
    }
    console.log('[A5-I5] PROVEN: verifyChain ok на всей цепочке и в окне; метки строго монотонны');
  });

  test('PROVEN: tamper metadata в средней записи → ok:false, brokenAtId указывает на запись; восстановление → ok:true', async () => {
    const targetId = entryIds[1]; // вторая из моих записей (не самая старая)
    const original = await db.auditLog.findUniqueOrThrow({ where: { id: targetId }, select: { metadata: true } });

    await db.auditLog.update({ where: { id: targetId }, data: { metadata: JSON.stringify({ [MARK]: 2, hacked: true }) } });
    const broken = await verifyAll();
    expect(broken.ok).toBe(false);
    expect(broken.brokenAtId).toBe(targetId);

    // восстановление текста чинит цепочку (доказательство детерминированности хэша)
    await db.auditLog.update({ where: { id: targetId }, data: { metadata: original.metadata } });
    expect((await verifyAll()).ok).toBe(true);
  });

  test('PROVEN: tamper actorId/action/resource тоже детектируется', async () => {
    const targetId = entryIds[2];
    const original = await db.auditLog.findUniqueOrThrow({ where: { id: targetId }, select: { actorId: true, action: true } });

    await db.auditLog.update({ where: { id: targetId }, data: { actorId: 'a5-forger' } });
    expect((await verifyAll()).ok).toBe(false);
    await db.auditLog.update({ where: { id: targetId }, data: { actorId: original.actorId } });

    await db.auditLog.update({ where: { id: targetId }, data: { action: 'forged_action' } });
    expect((await verifyAll()).ok).toBe(false);
    await db.auditLog.update({ where: { id: targetId }, data: { action: original.action } });

    expect((await verifyAll()).ok).toBe(true);
  });

  test('COUNTEREXAMPLE (I5 VIOLATED, частично): tamper САМОЙ СТАРОЙ записи окна verifyChain НЕ детектирует', async () => {
    // verifyChain (audit-log.ts:138) проверяет пары, начиная с i=1: хэш самой
    // старой записи окна (ordered[0], включая генезис всей таблицы) никогда
    // не пересчитывается по её СОДЕРЖИМОМУ — только используется как якорь
    // prev.chainHash для следующей. Меняем текст первой записи — цепочка
    // «верна».
    const oldest = await db.auditLog.findFirst({
      where: { chainHash: { not: null } },
      orderBy: { createdAt: 'asc' },
    });
    expect(oldest).not.toBeNull();
    if (!oldest) return;
    const originalMetadata = oldest.metadata;
    const originalChainHash = oldest.chainHash;

    await db.auditLog.update({
      where: { id: oldest.id },
      data: { metadata: JSON.stringify({ a5: 'genesis-tamper', forged: true }) },
    });

    const res = await verifyAll();
    // D-27 FIXED: генезис окна/таблицы ПЕРЕСЧИТЫВАЕТСЯ по содержимому —
    // тампер самой старой записи теперь ДЕТЕКТИРУЕТСЯ (brokenAtId = запись).
    const tampered = await db.auditLog.findUniqueOrThrow({ where: { id: oldest.id } });
    expect(tampered.metadata).not.toBe(originalMetadata);          // текст изменён
    expect(tampered.chainHash).toBe(originalChainHash);            // хэш не пересчитан (злоумышленник ленив)
    expect(res.ok).toBe(false);                                    // верификатор ПОЙМАЛ
    expect(res.brokenAtId).toBe(oldest.id);

    // восстановление
    await db.auditLog.update({ where: { id: oldest.id }, data: { metadata: originalMetadata } });
    expect((await verifyAll()).ok).toBe(true);
    console.log(`[A5-I5] D-27 FIXED: tamper генезиса (${oldest.id}) детектируется verifyChain (пересчёт по контенту, якорь GENESIS).`);
  });

  test('PROVEN: вставка посторонней записи в журнал разрывает цепочку (и откатывается)', async () => {
    // Записи одного flush идут с шагом 1мс (S-134), свободных ms между ними нет —
    // поэтому forged-запись ставим сразу ПОСЛЕ самой новой записи цепочки
    // (позиция «головы»). Сбойный chainHash детектируется на самой записи.
    const newest = await db.auditLog.findFirst({
      where: { chainHash: { not: null } },
      orderBy: { createdAt: 'desc' },
      select: { createdAt: true },
    });
    expect(newest).not.toBeNull();
    if (!newest) return;

    const injected = await db.auditLog.create({
      data: {
        actorId: 'a5-forger',
        action: 'read_pii',
        resource: 'user:email',
        resourceId: 'a5-injected',
        metadata: JSON.stringify({ injected: true }),
        chainHash: 'a5-forged-hash',
        createdAt: new Date(newest.createdAt.getTime() + 1),
      },
    });

    const res = await verifyAll();
    expect(res.ok).toBe(false);
    expect(res.brokenAtId).toBe(injected.id);

    // уборка: доказываем, что разрыв именно от вставки
    await db.auditLog.delete({ where: { id: injected.id } });
    expect((await verifyAll()).ok).toBe(true);
    console.log('[A5-I5] PROVEN: инъекция записи с чужим chainHash детектируется (brokenAtId = инъекция)');
  });

  test('PROVEN: удаление средней записи разрывает цепочку → детект → восстановление цепи', async () => {
    // R5.5-гигиена: раньше тест намеренно оставлял цепь разорванной («цепь
    // остаётся разорванной») — это роняло verifyChain-тесты всех файлов,
    // идущих позже (wave6 и др.). Теперь: доказываем детект удаления и
    // ВОССТАНАВЛИВАЕМ строку байт-в-байт (те же id/createdAt/chainHash) —
    // доказательство сохранено, хвост прогона не ломается.
    const victimId = entryIds[3];
    const victim = await db.auditLog.findUniqueOrThrow({ where: { id: victimId } });
    await db.auditLog.delete({ where: { id: victimId } });
    const res = await verifyAll();
    expect(res.ok).toBe(false);
    expect(res.brokenAtId).not.toBeNull();
    console.log('[A5-I5] PROVEN: удаление записи детектируется');
    // восстановление байт-в-байт (без пересчёта хэшей — содержимое идентично)
    await db.auditLog.create({
      data: {
        id: victim.id,
        actorId: victim.actorId,
        action: victim.action,
        resource: victim.resource,
        resourceId: victim.resourceId,
        ip: victim.ip,
        metadata: victim.metadata,
        createdAt: victim.createdAt,
        chainHash: victim.chainHash,
      },
    });
    expect((await verifyAll()).ok).toBe(true);
    console.log('[A5-I5] PROVEN: восстановление записи → цепь снова целостна');
  });
});

// =============================================================================
// I6 (CONSENT)
// Гарантия в коде: src/lib/sovereignty/gateway.ts:117-229 (SovereigntyGateway.check:
//   согласия читаются :118-136, класс A блокируется без consentAiAnalysis :151-157,
//   cross-border fail-closed :173-191), minimizeForAI :239-257;
//   src/lib/ai-core/gateway.ts:266-302 (LLM не вызывается при allowed=false);
//   src/lib/services/bizon-moment-service.ts:160-162, 182-183 (S-139 fail-closed).
// =============================================================================

describe('A5-I6 CONSENT: AI-анализ и согласия пользователя', () => {
  let uid = '';

  beforeAll(async () => {
    const u = await makeUser('consent');
    uid = u.id;
    await db.user.update({
      where: { id: uid },
      data: {
        consentAiAnalysis: false,
        consentCrossBorder: false,
        citizenship: 'RU',
        region: 'RU',
      },
    });
  });

  test('PROVEN (field-level): класс A без consentAiAnalysis попадает в blockedFields и минимизируется', async () => {
    const d = await SovereigntyGateway.check(uid, 'ai.analyze', ['email', 'name', 'skills']);
    expect(d.blockedFields).toEqual(expect.arrayContaining(['email', 'name']));
    expect(d.minimizationRequired).toBe(true);
    expect(d.consents?.aiAnalysis).toBe(false);

    const minimized = SovereigntyGateway.minimizeForAI({
      name: 'Иван Иванов',
      email: 'ivan@a5.test',
      emailEncrypted: 'xx',
      phone: '+7 900 000-00-00',
      phoneEncrypted: 'yy',
      birthday: '1990-01-01',
      passwordHash: 'zz',
      ip: '10.0.0.1',
      location: 'Москва, Россия',
      bio: 'а'.repeat(400),
      skills: ['rust', 'typescript'],
    });
    expect(minimized.email).toBeUndefined();
    expect(minimized.emailEncrypted).toBeUndefined();
    expect(minimized.phone).toBeUndefined();
    expect(minimized.phoneEncrypted).toBeUndefined();
    expect(minimized.birthday).toBeUndefined();
    expect(minimized.passwordHash).toBeUndefined();
    expect(minimized.ip).toBeUndefined();
    expect(minimized.location).toBe('Москва'); // регион без города
    expect(String(minimized.bio).length).toBeLessThanOrEqual(301);
    expect(minimized.name).toBe('Профессионал'); // без anonymousId — дефолт
    console.log('[A5-I6] PROVEN: поля класса A без согласия блокируются/минимизируются на уровне полей');
  });

  test('PROVEN: cross-border без consentCrossBorder → fail-closed (allowed=false, внешний compute заблокирован)', async () => {
    const d = await SovereigntyGateway.check(uid, 'ai.analyze', ['skills'], 'DE');
    expect(d.crossBorder).toBe(true);
    expect(d.allowed).toBe(false);
    expect(d.externalComputeBlocked).toBe(true);

    await db.user.update({ where: { id: uid }, data: { consentCrossBorder: true } });
    const d2 = await SovereigntyGateway.check(uid, 'ai.analyze', ['skills'], 'DE');
    expect(d2.allowed).toBe(true);
    expect(d2.externalComputeBlocked).toBe(false);
    await db.user.update({ where: { id: uid }, data: { consentCrossBorder: false } }); // вернуть
  });

  test('COUNTEREXAMPLE (I6 VIOLATED): consentAiAnalysis=false НЕ запрещает сам AI-анализ — операция allowed=true', async () => {
    // Теорема требует: ¬consent → AI-анализ невозможен. Фактически check()
    // возвращает allowed=true даже с блокированными полями класса A —
    // AIGateway (ai-core/gateway.ts:273,299) вызывает LLM, т.к. blocked=false.
    // D-27 FIXED: отказ от согласия + поля класса A = ПОЛНЫЙ операционный блок.
    const d = await SovereigntyGateway.check(uid, 'ai.analyze', ['email', 'name']);
    expect(d.consents?.aiAnalysis).toBe(false);
    expect(d.allowed).toBe(false); // LLM НЕ состоится (fail-closed)
    expect(d.reason).toContain('consentAiAnalysis');

    // Класс B/C без consent — разрешён (не персональные данные):
    const dB = await SovereigntyGateway.check(uid, 'ai.analyze', ['skills', 'title', 'ipScore']);
    expect(dB.allowed).toBe(true);
    expect(dB.blockedFields).toBeUndefined();
    console.log('[A5-I6] D-27 FIXED: consentAiAnalysis=false + класс A → allowed=false (операционный блок).');
  });

  test('COUNTEREXAMPLE (I6 VIOLATED): несуществующий userId / сбой БД → fail-open (согласия считаются выданными)', async () => {
    // gateway.ts:133-136: user==null (чужой id / ошибка БД) → consentAi=true,
    // consentXb=true — прежнее permissive-поведение. Класс A проходит без блокировок.
    // D-27 FIXED: неизвестный юзер / сбой БД → fail-CLOSED (согласия считаются
    // НЕ выданными, класс A → операционный блок).
    const d = await SovereigntyGateway.check('a5-nonexistent-user-id', 'ai.analyze', ['email', 'phone']);
    expect(d.allowed).toBe(false);
    expect(d.consents).toEqual({ aiAnalysis: false, crossBorder: false });
    console.log('[A5-I6] D-27 FIXED: fail-closed для несуществующего пользователя/сбоя БД.');
  });

  test('PROVEN: детерминированный псевдоним (doc_scaling) — stable и различимый', () => {
    expect(pseudonymizeUser(uid)).toBe(pseudonymizeUser(uid));
    expect(pseudonymizeUser(uid)).toMatch(/^anonymous_user_\d{5}$/);
    expect(pseudonymizeUser(uid)).not.toBe(pseudonymizeUser('another-user-id'));
  });

  test('PROVEN (S-139 memory-security): BizON-момент без согласия не отдаётся и не генерируется (fail-closed)', async () => {
    await db.aiInsight.create({
      data: {
        userId: uid,
        type: 'bizon_moment',
        title: 'A5: тестовый момент',
        content: 'контент',
        insight: 'контент',
        evidence: '{}',
        isRead: false,
      },
    });

    // consent=false: инсайт в БД есть, но гейт возвращает null ДО чтения
    expect(await BizonMomentService.getCurrent(uid)).toBeNull();

    // дифференциально: тот же инсайт при consent=true — отдаётся
    await db.user.update({ where: { id: uid }, data: { consentAiAnalysis: true } });
    const got = await BizonMomentService.getCurrent(uid);
    expect(got).not.toBeNull();

    // генерация: consent=false при optIn=true → null (bizon-moment-service.ts:183)
    await db.user.update({ where: { id: uid }, data: { consentAiAnalysis: false, bizonMomentOptIn: true } });
    expect(await BizonMomentService.generate(uid)).toBeNull();
    console.log('[A5-I6] PROVEN: BizonMoment fail-closed по consentAiAnalysis (S-139)');
  });
});
