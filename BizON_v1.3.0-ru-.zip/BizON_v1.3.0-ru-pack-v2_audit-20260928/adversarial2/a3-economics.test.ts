// =============================================================================
// A3 «Red-Team» (R2-A3) — ЭКОНОМИКА: эскроу, refund, сплит комиссии, суммы.
//
// ПРАВИЛА A3: ничего не чиним. Каждый тест написан в BLOCKED-семантике:
//   тест ЗЕЛЁНЫЙ  = атака НЕ удалась (система отбила);
//   тест КРАСНЫЙ  = атака УДАЛАСЬ (BizON сломан, доказано воспроизведением).
// =============================================================================

import '../tests/helpers/setup';
import { beforeAll, describe, expect, test } from 'bun:test';

import { db } from '@/lib/db';
import { registerUser } from '@/lib/auth';
import { LumenService } from '@/lib/services/lumen-service';
import { StoreService } from '@/lib/services/store-service';
import { computeSplit, getCashierConfig } from '@/lib/services/virtual-cashier-service';
import { BizonError } from '@/lib/errors';

const PRICE = 50;

async function giveLumens(userId: string, amount: number) {
  await db.user.update({ where: { id: userId }, data: { lumenBalance: { increment: amount } } });
}

async function balanceOf(userId: string): Promise<number> {
  const u = await db.user.findUnique({ where: { id: userId }, select: { lumenBalance: true } });
  return u?.lumenBalance ?? 0;
}

describe('A3 Economics: эскроу Store / LumenService / касса', () => {
  let sellerId = '';
  let buyerId = '';
  let attackerId = '';

  beforeAll(async () => {
    const seller = await registerUser({ email: 'a3eco-seller@bizon.test', password: 'Correct-Horse-9!', name: 'A3 Eco Seller' });
    const buyer = await registerUser({ email: 'a3eco-buyer@bizon.test', password: 'Correct-Horse-9!', name: 'A3 Eco Buyer' });
    const attacker = await registerUser({ email: 'a3eco-attacker@bizon.test', password: 'Correct-Horse-9!', name: 'A3 Eco Attacker' });
    sellerId = seller.user.id;
    buyerId = buyer.user.id;
    attackerId = attacker.user.id;
    await giveLumens(buyerId, 500);
    await giveLumens(attackerId, 100);
  });

  // ===========================================================================
  test('[A3-ATK-001] Экономика: refund ПОСЛЕ release → двойной расход (печатный станок)', async () => {
    const item = await StoreService.createItem(sellerId, {
      type: 'services', title: 'A3-001 release-then-refund', description: '', priceLumens: PRICE, deliveryMode: 'async',
    });
    const booking = await StoreService.requestBooking(buyerId, item.id, {});
    await StoreService.fulfil(sellerId, booking.id);
    await StoreService.release(buyerId, booking.id); // продавец получил PRICE

    const sellerAfterRelease = await balanceOf(sellerId);
    const buyerAfterRelease = await balanceOf(buyerId);
    const stored = await db.storeBooking.findUnique({ where: { id: booking.id } });
    if (!stored?.spendTxId) throw new Error('fixture: нет spendTxId');

    // АТАКА: примитив refundVar не знает о состоянии сделки — пробуем вернуть
    // покупателю деньги ЗА УЖЕ ЗАКРЫТУЮ (released) сделку.
    const refund = await LumenService.refundVar(buyerId, PRICE, 'A3-ATK-001 double claim', stored.spendTxId);

    // BLOCKED-семантика: refund должен быть отклонён (null) или быть no-op.
    const blocked = refund === null || refund.alreadyRefunded === true;
    if (!blocked) {
      throw new Error(
        `A3-ATK-001 АТАКА УДАЛАСЬ: refundVar вернул деньги после release ` +
        `(alreadyRefunded=${(refund as { alreadyRefunded: boolean }).alreadyRefunded}, balance=${(refund as { balance: number }).balance}). ` +
        `Итог: продавец получил ${PRICE} И покупателю вернули ${PRICE} — люмены напечатаны из воздуха.`,
      );
    }
    expect(await balanceOf(sellerId)).toBe(sellerAfterRelease);
    expect(await balanceOf(buyerId)).toBe(buyerAfterRelease);
  });

  // ===========================================================================
  test('[A3-ATK-002] Экономика: refundVar с ЗАВЫШЕННОЙ суммой (не сверяется со списанием)', async () => {
    const before = await balanceOf(attackerId);
    const spend = await LumenService.spendVar(attackerId, 10, { action: 'store_escrow', label: 'A3-002' });
    if (!spend.ok) throw new Error('fixture: spend не прошёл');

    // АТАКА: возвращаем 5000 по транзакции, в которой списали 10.
    // D-19 FIXED: сумма возврата привязана к ledger (refundAmount = -original.lumens) —
    // вернёт РОВНО 10, переданные 5000 игнорируются (REFUND_AMOUNT_BOUND в аудите).
    const refund = await LumenService.refundVar(attackerId, 5000, 'A3-ATK-002 inflated', spend.transactionId);
    expect(refund).not.toBeNull();
    expect(refund!.alreadyRefunded).toBe(false);
    expect(await balanceOf(attackerId)).toBe(before); // вернуло РОВНО 10, а не 5000
    const refundRow = await db.lumenTransaction.findUnique({ where: { refundOf: spend.transactionId } });
    expect(refundRow?.lumens).toBe(10); // привязка к ledger, не к вызывателю
  });

  // ===========================================================================
  test('[A3-ATK-003] Экономика: двойной release одного booking (идемпотентность эскроу)', async () => {
    const item = await StoreService.createItem(sellerId, {
      type: 'services', title: 'A3-003 double release', description: '', priceLumens: PRICE, deliveryMode: 'async',
    });
    const booking = await StoreService.requestBooking(buyerId, item.id, {});
    await StoreService.fulfil(sellerId, booking.id);
    await StoreService.release(buyerId, booking.id);
    const sellerAfter = await balanceOf(sellerId);

    // АТАКА: повторное подтверждение получения тем же покупателем.
    let doubleReleased = false;
    try {
      await StoreService.release(buyerId, booking.id);
      doubleReleased = true;
    } catch (e) {
      if (!(e instanceof BizonError)) throw e;
    }
    if (doubleReleased) {
      throw new Error('A3-ATK-003 АТАКА УДАЛАСЬ: второй release прошёл без 409 — двойная выплата продавцу.');
    }
    expect(await balanceOf(sellerId)).toBe(sellerAfter); // второго зачисления нет

    // АТАКА-2: release БУКВАЛЬНО тем же вызовом, но до fulfil (-held) — должен быть 409.
    const item2 = await StoreService.createItem(sellerId, {
      type: 'services', title: 'A3-003 release-before-fulfil', description: '', priceLumens: PRICE, deliveryMode: 'async',
    });
    const booking2 = await StoreService.requestBooking(buyerId, item2.id, {});
    let earlyRelease = false;
    try {
      await StoreService.release(buyerId, booking2.id);
      earlyRelease = true;
    } catch (e) {
      if (!(e instanceof BizonError)) throw e;
    }
    if (earlyRelease) {
      throw new Error('A3-ATK-003b АТАКА УДАЛАСЬ: release прошёл для booking в статусе held (минуя fulfil).');
    }
    expect(await balanceOf(sellerId)).toBe(sellerAfter);
  });

  // ===========================================================================
  test('[A3-ATK-004] Экономика: сплит с комиссией > капа → sellerGets уходит в минус', async () => {
    // (а) Правильное поведение env-парсера: 150% не должно приниматься.
    const prev = process.env.PLATFORM_COMMISSION_PERCENT;
    try {
      process.env.PLATFORM_COMMISSION_PERCENT = '150';
      let envThrew = false;
      try { getCashierConfig(); } catch { envThrew = true; }
      if (!envThrew) {
        throw new Error('A3-ATK-004a АТАКА УДАЛАСЬ: PLATFORM_COMMISSION_PERCENT=150 принят (кап 50 не работает).');
      }
    } finally {
      if (prev === undefined) delete process.env.PLATFORM_COMMISSION_PERCENT;
      else process.env.PLATFORM_COMMISSION_PERCENT = prev;
    }

    // (б) A5-6 FIXED (KV2): внутренний guard ≤100% добавлен — computeSplit(100,150)
    // бросает BizonError; p=100 легален (sellerGets=0, математика доказана T1c),
    // продуктовый кап 50 остаётся в конфиг-слое.
    let threw = false;
    try {
      computeSplit(100, 150);
    } catch (e) {
      threw = e instanceof BizonError;
    }
    expect(threw).toBe(true);
    const s100 = computeSplit(100, 100);
    expect(s100.sellerGets).toBe(0);
    expect(s100.commission).toBe(100);
  });

  // ===========================================================================
  test('[A3-ATK-005] Экономика: нулевые/отрицательные/дробные/NaN суммы в люмен-операциях', async () => {
    const before = await balanceOf(attackerId);

    const spendZero = await LumenService.spendVar(attackerId, 0, { action: 'x', label: 'x' });
    const spendNeg = await LumenService.spendVar(attackerId, -5, { action: 'x', label: 'x' });
    const spendFrac = await LumenService.spendVar(attackerId, 10.5, { action: 'x', label: 'x' });
    const spendNaN = await LumenService.spendVar(attackerId, Number.NaN, { action: 'x', label: 'x' });
    const spendStr = await LumenService.spendVar(attackerId, '50' as unknown as number, { action: 'x', label: 'x' });
    for (const [name, r] of [['zero', spendZero], ['negative', spendNeg], ['fraction', spendFrac], ['NaN', spendNaN], ['string', spendStr]] as const) {
      if (r.ok) throw new Error(`A3-ATK-005 АТАКА УДАЛАСЬ: spendVar принял ${name} сумму.`);
    }

    const topupNaN = await LumenService.topup(attackerId, Number.NaN as unknown as 100);
    const topupOdd = await LumenService.topup(attackerId, 777 as unknown as 100);
    if (topupNaN.ok || topupOdd.ok) {
      throw new Error('A3-ATK-005b АТАКА УДАЛАСЬ: topup принял произвольную/NaN сумму.');
    }

    // debit должен fail-fast на некорректных суммах
    let debitRejected = true;
    try { await LumenService.debit(attackerId, 0, { action: 'x', label: 'x' }); debitRejected = false; } catch { /* ок */ }
    try { await LumenService.debit(attackerId, Number.NaN, { action: 'x', label: 'x' }); debitRejected = false; } catch { /* ок */ }
    if (!debitRejected) throw new Error('A3-ATK-005c АТАКА УДАЛАСЬ: debit принял 0/NaN.');

    // цена товара: отрицательная / 0 / NaN / за максимум
    for (const price of [-1, 0, Number.NaN, 1_000_001]) {
      let rejected = false;
      try {
        await StoreService.createItem(sellerId, {
          type: 'services', title: 'A3-005 bad price', description: '', priceLumens: price, deliveryMode: 'async',
        });
      } catch (e) {
        if (!(e instanceof BizonError)) throw e;
        rejected = true;
      }
      if (!rejected) throw new Error(`A3-ATK-005d АТАКА УДАЛАСЬ: createItem принял цену ${price}.`);
    }

    // некорректное время сессии
    const item = await StoreService.createItem(sellerId, {
      type: 'services', title: 'A3-005 slot check', description: '', priceLumens: PRICE, deliveryMode: 'online-meeting',
    });
    let slotRejected = false;
    try {
      await StoreService.requestBooking(attackerId, item.id, { slotAt: 'yesterday-32-oxford' });
      await giveLumens(attackerId, PRICE); // если вдруг прошло — выравниваем fixture
    } catch (e) {
      if (!(e instanceof BizonError)) throw e;
      slotRejected = true;
    }
    if (!slotRejected) throw new Error('A3-ATK-005e АТАКА УДАЛАСЬ: requestBooking принял мусорный slotAt.');

    expect(await balanceOf(attackerId)).toBeLessThanOrEqual(before);
  });

  // ===========================================================================
  test('[A3-ATK-006] Экономика: сбой в середине транзакции → частичное списание?', async () => {
    // Окно 1: краш ДО списания (held без spendTxId) → sweep обязан закрыть, денег нет.
    const ghost = await db.storeBooking.create({
      data: {
        itemId: (await StoreService.createItem(sellerId, {
          type: 'services', title: 'A3-006 ghost', description: '', priceLumens: PRICE, deliveryMode: 'async',
        })).id,
        buyerId, sellerId, priceLumens: PRICE,
        status: 'held',
        createdAt: new Date(Date.now() - 20 * 60_000),
      },
    });
    const buyerBefore = await balanceOf(buyerId);
    await StoreService.sweepStale();
    const ghostAfter = await db.storeBooking.findUnique({ where: { id: ghost.id } });
    if (ghostAfter?.status !== 'cancelled') {
      throw new Error('A3-ATK-006a АТАКА УДАЛАСЬ: held-мусор без spendTxId не закрыт sweep → вечное зависание эскроу.');
    }

    // Окно 2: краш ПОСЛЕ смены статуса, ДО возврата (declined без refund) →
    // sweep обязан дослать идемпотентный refund.
    const item = await StoreService.createItem(sellerId, {
      type: 'services', title: 'A3-006 crash mid-decline', description: '', priceLumens: PRICE, deliveryMode: 'async',
    });
    const booking = await StoreService.requestBooking(buyerId, item.id, {});
    const stored = await db.storeBooking.findUnique({ where: { id: booking.id } });
    if (!stored?.spendTxId) throw new Error('fixture: нет spendTxId');
    // имитация «краша между статусом и возвратом»:
    await db.storeBooking.update({
      where: { id: booking.id },
      data: { status: 'declined', closedAt: new Date() },
    });
    const buyerMidCrash = await balanceOf(buyerId); // деньги ещё заморожены
    const sweep = await StoreService.sweepStale();
    const buyerAfterSweep = await balanceOf(buyerId);
    if (buyerAfterSweep !== buyerMidCrash + PRICE) {
      throw new Error(
        `A3-ATK-006b АТАКА УДАЛАСЬ: после краша в decline деньги не вернулись даже sweep'ом ` +
        `(mid=${buyerMidCrash}, after=${buyerAfterSweep}, completedRefunds=${sweep.completedRefunds}). Частичная потеря средств.`,
      );
    }
    expect(buyerBefore).toBeGreaterThanOrEqual(0);
  });
});
