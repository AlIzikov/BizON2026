// =============================================================================
// A3 «Red-Team» (R2-A3) — АВТОРИЗАЦИЯ/GOVERNANCE: IDOR, пауза агентов,
// user-prohibitions, реестр действий, порядок гейтов decideAction.
//
// BLOCKED-семантика: зелёный = система отбила атаку; красный = BizON сломан.
// =============================================================================

import '../tests/helpers/setup';
import { beforeAll, describe, expect, test } from 'bun:test';

import { db } from '@/lib/db';
import { registerUser } from '@/lib/auth';
import { AuthService } from '@/lib/services/auth-service';
import { resolveSession } from '@/lib/security/session-token';
import { StoreService } from '@/lib/services/store-service';
import { introService } from '@/lib/services/intro-service';
import { ProjectRoomService } from '@/lib/services/project-room-service';
import { GovernanceService } from '@/lib/ai-governance/governance-service';
import { BizonError } from '@/lib/errors';

const APPROVAL_TTL_MS = 15 * 60_000;

async function connect(a: string, b: string) {
  await db.connection.create({ data: { fromUserId: a, toUserId: b, status: 'accepted', kind: 'colleague', provenance: 'manual' } });
}

describe('A3 Authz: IDOR по booking/intro/review', () => {
  let sellerId = '';
  let buyerId = '';
  let strangerId = '';
  let mediatorId = '';
  let targetId = '';

  beforeAll(async () => {
    const mk = async (email: string, name: string) => (await registerUser({ email, password: 'Correct-Horse-9!', name })).user.id;
    sellerId = await mk('a3auth-seller@bizon.test', 'A3 Seller');
    buyerId = await mk('a3auth-buyer@bizon.test', 'A3 Buyer');
    strangerId = await mk('a3auth-stranger@bizon.test', 'A3 Stranger');
    mediatorId = await mk('a3auth-mediator@bizon.test', 'A3 Mediator');
    targetId = await mk('a3auth-target@bizon.test', 'A3 Target');
    await db.user.update({ where: { id: buyerId }, data: { lumenBalance: { increment: 300 } } });
    await connect(mediatorId, buyerId);
    await connect(mediatorId, targetId);
  });

  test('[A3-ATK-007] IDOR: чужие booking/intro операции по ID', async () => {
    // чужой booking: release/fulfil/decline/cancel посторонним
    const item = await StoreService.createItem(sellerId, {
      type: 'services', title: 'A3-007 IDOR booking', description: '', priceLumens: 50, deliveryMode: 'async',
    });
    const booking = await StoreService.requestBooking(buyerId, item.id, {});

    const attempts: Array<[string, () => Promise<unknown>]> = [
      ['release(stranger)', () => StoreService.release(strangerId, booking.id)],
      ['fulfil(stranger)', () => StoreService.fulfil(strangerId, booking.id)],
      ['decline(stranger)', () => StoreService.decline(strangerId, booking.id)],
      ['cancel(stranger)', () => StoreService.cancel(strangerId, booking.id)],
      ['release(buyer как seller)', () => StoreService.fulfil(buyerId, booking.id)],
    ];
    for (const [name, fn] of attempts) {
      let blocked = false;
      try { await fn(); } catch (e) {
        if (!(e instanceof BizonError)) throw e;
        blocked = true;
      }
      if (!blocked) {
        throw new Error(`A3-ATK-007 АТАКА УДАЛАСЬ: ${name} прошёл по чужому bookingId ${booking.id}.`);
      }
    }
    const after = await db.storeBooking.findUnique({ where: { id: booking.id } });
    if (after?.status !== 'held') {
      throw new Error(`A3-ATK-007b АТАКА УДАЛАСЬ: статус чужой сделки изменён посторонним → ${after?.status}.`);
    }

    // чужое интро: accept НЕ посредником
    const intro = await introService.create(buyerId, targetId, 'job');
    let introBlocked = false;
    try { await introService.accept(intro.id, strangerId); } catch (e) {
      if (!(e instanceof BizonError)) throw e;
      introBlocked = true;
    }
    if (!introBlocked) {
      throw new Error(`A3-ATK-007c АТАКА УДАЛАСЬ: чужое интро ${intro.id} принял посторонний (не посредник).`);
    }
    const introRow = await db.introductionRequest.findUnique({ where: { id: intro.id } });
    if (introRow?.status !== 'pending') {
      throw new Error(`A3-ATK-007d АТАКА УДАЛАСЬ: интро изменено посторонним → ${introRow?.status}, диалог создан без согласия посредника.`);
    }
    expect(true).toBe(true);
  });

  test('[A3-ATK-008] Утечка: scoreInternal не покидает сервер через публичные отзывы', async () => {
    const project = await db.project.create({
      data: { title: 'A3-008 project', description: 'red-team fixture', ownerId: buyerId, status: 'active' },
    });
    await db.projectMember.createMany({
      data: [
        { projectId: project.id, userId: buyerId, role: 'owner' },
        { projectId: project.id, userId: strangerId, role: 'member' },
      ],
    });
    const review = await ProjectRoomService.review(project.id, buyerId, {
      subjectId: strangerId,
      text: 'Атака A3-008: проверяем утечку внутреннего скора.',
      wouldWorkAgain: true,
      scoreInternal: 5,
    });
    if (!review.ok) throw new Error(`fixture: review не создался (${review.code})`);

    const pub = await ProjectRoomService.listPublic(project.id);
    if (!pub.ok) throw new Error('fixture: listPublic упал');
    const raw = JSON.stringify(pub.data.reviews);
    if (raw.includes('scoreInternal') || raw.includes('"scoreInternal":5')) {
      throw new Error('A3-ATK-008 АТАКА УДАЛАСЬ: scoreInternal утёк через публичный список отзывов.');
    }

    // self-review тоже должен быть отброшен
    const self = await ProjectRoomService.review(project.id, buyerId, {
      subjectId: buyerId, text: 'Отзыв самому себе через публичную функцию.', wouldWorkAgain: true,
    });
    if (self.ok) throw new Error('A3-ATK-008b АТАКА УДАЛАСЬ: self-review прошёл.');
    expect(true).toBe(true);
  });
});

describe('A3 Governance: реестр, prohibitions, права vs состояние', () => {
  let userA = '';
  let userB = '';
  let prohibited = '';

  beforeAll(async () => {
    const mk = async (email: string, name: string) => (await registerUser({ email, password: 'Correct-Horse-9!', name })).user.id;
    userA = await mk('a3auth-gov-a@bizon.test', 'A3 Gov A');
    userB = await mk('a3auth-gov-b@bizon.test', 'A3 Gov B');
    prohibited = await mk('a3auth-gov-p@bizon.test', 'A3 Gov Prohibited');
    await db.userProhibition.create({ data: { userId: prohibited, actionKey: '*', reason: 'A3 fixture: запрет всех AI-действий' } });
  });

  test('[A3-ATK-009] Governance: pause/resume ЧУЖОГО агента без прав', async () => {
    const agent = await db.aiAgent.create({
      data: { key: `a3-agent-victim-${Date.now()}`, name: 'A3 Victim Agent', status: 'active', ownerType: 'user', ownerId: userA },
    });

    // АТАКА: случайный пользователь (не владелец, не админ) останавливает агент.
    const paused = await GovernanceService.pauseAgent(agent.key, userB);
    const after = await db.aiAgent.findUnique({ where: { key: agent.key } });
    if (paused || after?.status !== 'active') {
      throw new Error(
        `A3-ATK-009 АТАКА УДАЛАСЬ: GovernanceService.pauseAgent выполнен посторонним ` +
        `(userId=${userB}, агент ${agent.key} → status=${after?.status}). На сервисном уровне проверка прав отсутствует.`,
      );
    }
    // выравнивание fixture, если сервис всё-таки отбил
    if (after?.status !== 'active') await db.aiAgent.update({ where: { key: agent.key }, data: { status: 'active' } });
    expect(after?.status).toBe('active');
  });

  test('[A3-ATK-010] Governance: user-prohibition «*» обходится в основном пути proposeAction', async () => {
    const agentKey = `a3-agent-probe-${Date.now()}`;
    await db.aiAgent.create({ data: { key: agentKey, name: 'A3 Probe Agent', status: 'active' } });

    // Контроль: у пользователя БЕЗ запрета действие проходит (механизм жив).
    const control = await GovernanceService.proposeAction({ agentKey, userId: userA, actionKey: 'SEARCH_JOBS' });
    if (!control.ok) throw new Error(`fixture: контрольный proposeAction не прошёл (${control.code}) — неверен сам тест`);

    // АТАКА: пользователь с запретом '*' на ВСЕ AI-действия.
    const res = await GovernanceService.proposeAction({ agentKey, userId: prohibited, actionKey: 'SEARCH_JOBS' });
    if (res.ok) {
      throw new Error(
        `A3-ATK-010 АТАКА УДАЛАСЬ: proposeAction вернул ${res.data.status} для пользователя с UserProhibition('*'). ` +
        'Причина: governance-service.proposeAction НЕ передаёт userId в PolicyEngine.evaluateAction — ' +
        'user-prohibitions (Wave 6 S-135) не проверяются в основном пути.',
      );
    }
    expect(res.ok).toBe(false);
  });

  test('[A3-ATK-011] Governance: риск-действие без записи в action-registry', async () => {
    const agentKey = `a3-agent-unreg-${Date.now()}`;
    await db.aiAgent.create({ data: { key: agentKey, name: 'A3 Unreg Agent', status: 'active' } });

    const res = await GovernanceService.proposeAction({
      agentKey, userId: userA, actionKey: 'MASS_EMAIL_ALL_USERS', inputPayload: { victims: 'all' },
    });
    if (res.ok) {
      throw new Error('A3-ATK-011a АТАКА УДАЛАСЬ: незарегистрированное действие прошло политику.');
    }

    // SPEND_MONEY (critical) без явной выдачи полномочия — secure-by-default
    const spend = await GovernanceService.proposeAction({ agentKey, userId: userA, actionKey: 'SPEND_MONEY' });
    if (spend.ok) {
      throw new Error('A3-ATK-011b АТАКА УДАЛАСЬ: SPEND_MONEY доступен без явной выдачи в authority.');
    }
    expect(true).toBe(true);
  });

  test('[A3-ATK-012] Governance: порядок проверок права vs ALREADY_DECIDED + повторное решение', async () => {
    // --- non-critical: чужой не должен даже узнать состояние действия ---
    const action1 = await db.aiAction.create({
      data: { agentId: 'a3-agent-test', actionKey: 'CHANGE_PROFILE', risk: 'medium', status: 'proposed' },
    });
    await db.aiApproval.create({
      data: { actionId: action1.id, requestedBy: userA, status: 'pending', expiresAt: new Date(Date.now() + APPROVAL_TTL_MS) },
    });

    const foreign = await GovernanceService.decideAction({ actionId: action1.id, userId: userB, decision: 'approved' });
    if (foreign.ok || foreign.code !== 'FORBIDDEN') {
      throw new Error(
        `A3-ATK-012a АТАКА УДАЛАСЬ: посторонний получил не-FORBIDDEN ответ (${foreign.ok ? 'ok' : foreign.code}) ` +
        '— утечка состояния чужого действия (права должны проверяться раньше состояния).',
      );
    }

    // владелец решает; повторное решение тем же — ALREADY_DECIDED
    const owner1 = await GovernanceService.decideAction({ actionId: action1.id, userId: userA, decision: 'approved' });
    if (!owner1.ok) throw new Error(`fixture: владелец не смог решить (${owner1.code})`);
    const replay = await GovernanceService.decideAction({ actionId: action1.id, userId: userA, decision: 'approved' });
    if (replay.ok || replay.code !== 'ALREADY_DECIDED') {
      throw new Error(`A3-ATK-012b АТАКА УДАЛАСЬ: повторное решение по non-critical прошло (${replay.ok ? 'ok' : replay.code}).`);
    }

    // --- critical: двойное одобрение ОДНИМ пользователем (2-of-N) ---
    const action2 = await db.aiAction.create({
      data: { agentId: 'a3-agent-test', actionKey: 'SPEND_MONEY', risk: 'critical', status: 'proposed' },
    });
    await db.aiApproval.create({
      data: { actionId: action2.id, requestedBy: userA, status: 'pending', expiresAt: new Date(Date.now() + APPROVAL_TTL_MS) },
    });
    const first = await GovernanceService.decideAction({ actionId: action2.id, userId: userA, decision: 'approved' });
    if (!first.ok || first.status !== 'pending_second_approval') {
      throw new Error(`fixture: первый approve critical → ${first.ok ? first.status : first.code}`);
    }
    const sameUserSecond = await GovernanceService.decideAction({ actionId: action2.id, userId: userA, decision: 'approved' });
    if (sameUserSecond.ok) {
      throw new Error(
        `A3-ATK-012c АТАКА УДАЛАСЬ: 2-of-N пробит одним пользователем (${sameUserSecond.status}) — ` +
        'дубликат одобрения не пойман через approvalsJson.',
      );
    }
    if (sameUserSecond.code !== 'ALREADY_DECIDED') {
      throw new Error(`A3-ATK-012c-variant: повторный approve вернул ${sameUserSecond.code} вместо ALREADY_DECIDED.`);
    }
    const actionRow = await db.aiAction.findUnique({ where: { id: action2.id } });
    if (actionRow?.status === 'approved') {
      throw new Error('A3-ATK-012d АТАКА УДАЛАСЬ: critical-действие переведено в approved одним пользователем.');
    }

    // --- просроченное решение ---
    const action3 = await db.aiAction.create({
      data: { agentId: 'a3-agent-test', actionKey: 'CHANGE_PROFILE', risk: 'medium', status: 'proposed' },
    });
    await db.aiApproval.create({
      data: { actionId: action3.id, requestedBy: userA, status: 'pending', expiresAt: new Date(Date.now() - 1000) },
    });
    const expired = await GovernanceService.decideAction({ actionId: action3.id, userId: userA, decision: 'approved' });
    if (expired.ok || expired.code !== 'EXPIRED') {
      throw new Error(`A3-ATK-012e АТАКА УДАЛАСЬ: решение по истёкшему одобрению прошло (${expired.ok ? 'ok' : expired.code}).`);
    }
    expect(true).toBe(true);
  });

  test('[A3-ATK-007x] Сессии: сервисные токены не выдаются по чужому userId', async () => {
    // createSession принимает ЛЮБОЙ userId — проверяем, что это не даёт прав
    // чужому пользователю: токен для A не должен проходить как сессия B.
    // D-21: в БД — sha256(token); резолв через resolveSession (lookup по хэшу).
    const token = await AuthService.createSession(userA);
    const session = await resolveSession(token);
    if (!session) throw new Error('fixture: сессия не создана');
    if (session.user.id !== userA) {
      throw new Error('A3-ATK-007x АТАКА УДАЛАСЬ: сессия создана для другого пользователя.');
    }
    expect(session.user.id).toBe(userA);
  });
});
