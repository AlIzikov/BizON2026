// Полный цикл 2FA через ЖИВОЙ сервер: register → enable → confirm(TOTP) → me → disable → cleanup.
// Пароль re-auth требует email, расшифруемого КЛЮЧОМ СЕРВЕРА — поэтому фикс-юзер
// регистрируется через /api/auth/register (сервер сам шифрует email своим ключом).
const { PrismaClient } = await import('@prisma/client');
const db = new PrismaClient();
const require2 = (await import('node:module')).createRequire(import.meta.url);
const nodeCrypto = require2('node:crypto');
const BASE = 'http://localhost:3000';
const EMAIL = `test-2fa-${Date.now()}@bizon.test`;
const PASSWORD = 'T2fa-Cycle-Test-2026!';

let COOKIE = '';
async function post(path, body) {
  const res = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(COOKIE ? { cookie: COOKIE } : {}) },
    body: JSON.stringify(body),
  });
  const setCookie = res.headers.getSetCookie?.() || [];
  for (const c of setCookie) if (c.startsWith('bizon_session=')) COOKIE = c.split(';')[0];
  return { status: res.status, json: await res.json().catch(() => null) };
}
function generateTotp(secret, shift = 0) {
  const b32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const c of secret) { const v = b32.indexOf(c.toUpperCase()); if (v >= 0) bits += v.toString(2).padStart(5, '0'); }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  const counter = Math.floor(Date.now() / 1000 / 30) + shift;
  const buf = Buffer.alloc(8); buf.writeUInt32BE(Math.floor(counter / 2 ** 32), 0); buf.writeUInt32BE(counter % 2 ** 32, 4);
  const hmac = nodeCrypto.createHmac('sha1', Buffer.from(bytes)).update(buf).digest();
  const off = hmac[hmac.length - 1] & 0xf;
  const code = ((hmac[off] & 0x7f) << 24 | hmac[off+1] << 16 | hmac[off+2] << 8 | hmac[off+3]) % 1000000;
  return code.toString().padStart(6, '0');
}
async function findByName() { return db.user.findFirst({ where: { emailHash: { not: null } }, orderBy: { createdAt: 'desc' } }); }

try {
  // 0. Регистрация через живой сервер (сервер шифрует email своим ключом)
  const reg = await post('/api/auth/register', { email: EMAIL, password: PASSWORD, name: 'Тест 2FA Цикл', acceptedTos: true });
  console.log('register →', reg.status, '| keys:', Object.keys(reg.json || {}), '| cookie set:', COOKIE ? 'yes' : 'no');
  const userId = reg.json?.user?.id;
  if (!COOKIE || !userId) throw new Error('register failed: ' + JSON.stringify(reg.json).slice(0, 200));

  // 1. enable с неверным паролем → 401
  const wrong = await post('/api/auth/2fa/enable', { password: 'wrong-password' });
  console.log('enable wrong password →', wrong.status, JSON.stringify(wrong.json));

  // 2. enable без пароля → 422
  const nopass = await post('/api/auth/2fa/enable', {});
  console.log('enable no password →', nopass.status, JSON.stringify(nopass.json));

  // 3. enable верный → secret/qrUrl/backupCodes
  const en = await post('/api/auth/2fa/enable', { password: PASSWORD });
  console.log('enable →', en.status, '| qrUrl:', (en.json?.qrUrl || '').slice(0, 50), '| secret:', (en.json?.secret || '').slice(0, 6) + '...', '| backupCodes:', en.json?.backupCodes?.length);
  if (en.status !== 200) throw new Error('enable failed: ' + JSON.stringify(en.json));

  // 5. confirm неверный код → 401
  const bad = await post('/api/auth/2fa/confirm', { token: '000000' });
  console.log('confirm 000000 →', bad.status, JSON.stringify(bad.json));

  // 6. confirm валидный TOTP (RFC 6238 SHA1/30s/6dig — те же дефолты otplib) → ok
  let ok = null, usedCode = '';
  for (const shift of [0, -1, 1]) {
    const code = generateTotp(en.json.secret, shift);
    ok = await post('/api/auth/2fa/confirm', { token: code });
    console.log(`confirm TOTP (shift ${shift}) →`, ok.status, JSON.stringify(ok.json));
    if (ok.status === 200) { usedCode = code; break; }
  }
  if (!ok || ok.status !== 200) throw new Error('confirm failed for all shifts');

  // 7. БД: включена?
  let u = await db.user.findUnique({ where: { id: userId }, select: { twoFactorEnabled: true } });
  console.log('DB after confirm: twoFactorEnabled =', u.twoFactorEnabled);

  // 8. повторный confirm → 409
  const dup = await post('/api/auth/2fa/confirm', { token: generateTotp(en.json.secret) });
  console.log('confirm again →', dup.status, JSON.stringify(dup.json));

  // 9. GET /api/auth/me → twoFactorEnabled аддитивное поле
  const meRes = await fetch(BASE + '/api/auth/me', { headers: { cookie: COOKIE } });
  const me = await meRes.json();
  console.log('me.twoFactorEnabled =', me?.user?.twoFactorEnabled);

  // 10. disable
  const dis = await post('/api/auth/2fa/disable', { password: PASSWORD });
  console.log('disable →', dis.status, JSON.stringify(dis.json));
  if (dis.status !== 200) throw new Error('disable failed');

  // 11. ФИНАЛ в БД — КРИТИЧНО: twoFactorEnabled=false, секрет/коды очищены
  u = await db.user.findUnique({ where: { id: userId }, select: { twoFactorEnabled: true, twoFactorSecret: true, backupCodes: true } });
  console.log('DB FINAL:', JSON.stringify(u));
  if (u.twoFactorEnabled !== false) throw new Error('CRITICAL: 2FA still enabled!');

  // 12. cleanup фикстуры
  await db.session.deleteMany({ where: { userId } });
  await db.notification.deleteMany({ where: { userId } }).catch(() => {});
  await db.user.delete({ where: { id: userId } });
  console.log('CLEANUP: fixture user deleted, RESIDUE 0');
  console.log('>>> CYCLE OK — 2FA ENDED DISABLED <<<');
} catch (e) {
  console.error('CYCLE FAILED:', e.message);
  await db.user.deleteMany({ where: { emailHash: { not: null }, createdAt: { gte: new Date(Date.now() - 3600_000) }, name: 'Тест 2FA Цикл' } }).catch(() => {});
  console.error('cleanup attempted');
  process.exitCode = 1;
} finally {
  await db.$disconnect();
}
