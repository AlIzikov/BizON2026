// BizON — Service Worker (MOB-1: PWA v1)
// Минимальный SW с двумя стратегиями:
//   • Network-first для HTML-навигации (с offline fallback на закэшированную страницу)
//   • Cache-first для статики (_next/static, logo.svg, manifest.json)
// Версия кэша bumped при изменении SW-логики — см. CACHE_VERSION.

const CACHE_VERSION = 'v1';
const STATIC_CACHE = `bizon-static-${CACHE_VERSION}`;
const RUNTIME_CACHE = `bizon-runtime-${CACHE_VERSION}`;

// Ресурсы, которые кэшируем при install (cache-first навсегда)
const PRECACHE_URLS = [
  '/logo.svg',
  '/manifest.json',
  '/lighthouse-logo.jpg',
];

// Статические паттерны — cache-first
function isStaticAsset(url) {
  const u = new URL(url);
  return (
    u.pathname.startsWith('/_next/static/') ||
    u.pathname === '/logo.svg' ||
    u.pathname === '/manifest.json' ||
    u.pathname === '/lighthouse-logo.jpg' ||
    u.pathname === '/robots.txt'
  );
}

// HTML-навигация — network-first
function isNavigationRequest(request) {
  return (
    request.mode === 'navigate' ||
    (request.method === 'GET' &&
      request.headers.get('accept') &&
      request.headers.get('accept').includes('text/html'))
  );
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(STATIC_CACHE);
      // ignore errors on individual resources (e.g. offline during install)
      await Promise.all(
        PRECACHE_URLS.map((url) =>
          cache.add(new Request(url, { cache: 'reload' })).catch(() => {})
        )
      );
      await self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => k !== STATIC_CACHE && k !== RUNTIME_CACHE)
          .map((k) => caches.delete(k))
      );
      await self.clients.claim();
    })()
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  // Только same-origin — кросс-доменные (GA, Metrica, etc.) не кэшируем
  if (url.origin !== self.location.origin) return;

  // === Cache-first для статики ===
  if (isStaticAsset(url.toString())) {
    event.respondWith(
      (async () => {
        const cached = await caches.match(request);
        if (cached) return cached;
        try {
          const fresh = await fetch(request);
          // кэшируем только успешные ответы
          if (fresh && fresh.status === 200) {
            const cache = await caches.open(STATIC_CACHE);
            cache.put(request, fresh.clone());
          }
          return fresh;
        } catch (e) {
          // нет кэша и нет сети — отдаём пустой ответ
          return new Response('', { status: 504, statusText: 'Offline' });
        }
      })()
    );
    return;
  }

  // === Network-first для HTML-навигации ===
  if (isNavigationRequest(request)) {
    event.respondWith(
      (async () => {
        try {
          const fresh = await fetch(request);
          // кэшируем последнюю HTML-страницу как offline-fallback
          const cache = await caches.open(RUNTIME_CACHE);
          cache.put(request, fresh.clone());
          return fresh;
        } catch (e) {
          // сети нет — пытаемся отдать закэшированную страницу
          const cached = await caches.match(request);
          if (cached) return cached;
          // fallback на любую закэшированную HTML-страницу (например, главную)
          const runtimeCache = await caches.open(RUNTIME_CACHE);
          const keys = await runtimeCache.keys();
          for (const key of keys) {
            const res = await runtimeCache.match(key);
            if (res && res.headers.get('content-type') && res.headers.get('content-type').includes('text/html')) {
              return res;
            }
          }
          return new Response(
            '<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>BizON — Offline</title></head>' +
              '<body style="font-family:system-ui,sans-serif;padding:2rem;text-align:center">' +
              '<h1>Нет соединения</h1><p>BizON недоступен офлайн. Проверьте подключение к сети.</p>' +
              '<button onclick="location.reload()">Повторить</button></body></html>',
            { status: 503, headers: { 'content-type': 'text/html; charset=utf-8' } }
          );
        }
      })()
    );
    return;
  }

  // Остальные GET-запросы (например, /api/*) — не кэшируем, просто идём в сеть.
  // SW не должен вмешиваться в API-вызовы (auth, mutations).
});

// === Push notifications (заглушка) ===
// Реальная обработка push-сообщений будет в Фазе 3 (см. TASKS.md P3-7).
// Сейчас SW только умеет показывать уведомления по команде от страницы.
self.addEventListener('push', (event) => {
  let payload = { title: 'BizON', body: 'Новое уведомление' };
  try {
    if (event.data) payload = { ...payload, ...event.data.json() };
  } catch (e) {
    if (event.data) payload.body = event.data.text();
  }
  event.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body,
      icon: '/logo.svg',
      badge: '/logo.svg',
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(self.clients.openWindow('/'));
});
