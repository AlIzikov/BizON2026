# BizON — русскоязычная профессиональная платформа

**Соцсеть + вакансии + обучение** на принципе «только реальные данные». Версия: см. `VERSION` (текущая — 1.0.0-rc.1 «Audit Snapshot»).

- 📦 Пакет полного описания системы (для аудита и разработки): **`docs/handover/00-README.md`**
- 🚀 Запуск: `bun install` → `cp .env.example .env` → `bun run db:push` → `bun run dev` (порт 3000; при `BIZON_DEMO_AUTH=1` — демо-вход «Иван Петров»)
- ✅ Проверки: `bun run lint` · `bunx tsc --noEmit` · `curl localhost:3000/api/health`
- 🧾 Правила разработки и история: `docs/CHECKPOINT.md`, `docs/DECISIONS.md`, `worklog.md`, `CHANGELOG.md`
- 🔒 Перед прод-деплоем: `PRE-LAUNCH.md` (все пункты обязательны)

Стек: Next.js 16 (App Router, одна страница `/`) · TypeScript strict · Tailwind 4 + shadcn/ui · Prisma + SQLite · Bun · z-ai-web-dev-sdk (только backend).
