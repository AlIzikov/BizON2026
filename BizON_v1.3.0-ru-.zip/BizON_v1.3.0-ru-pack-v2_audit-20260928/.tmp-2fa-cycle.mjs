// Полный цикл 2FA: fixture-юзер → enable → confirm(валидный TOTP) → disable → очистка
const { createRequire } = await import('node:module');
const require0 = createRequire(import.meta.url);
const nodeCrypto = require0('node:crypto');
const { hashEmail, encrypt } = await import('./src/lib/security/crypto');
const { PrismaClient } = await import('@prisma/client');
const db = new PrismaClient();
const BASE = 'http://localhost:3000';

async function hashPassword(password) {
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const derivedBits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 600000, hash: 'SHA-256' }, keyMaterial, 256);
  const saltHex = Array.from(salt).map(b => b.toString(16).padStart(2, '0')).join('');
  const hashHex = Array.from(new Uint8Array(derivedBits)).map(b => b.toString(16).padStart(2, '0')).join('');
  return `pbkdf2$600000$${saltHex}$${hashHex}`;
}
function generateTotp(secret) {
  // RFC 6238, как в totp-service (otplib defaults: SHA1, 6 цифр, 30s)
  const base32chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const c of secret) {
    const val = base32chars.indexOf(c.toUpperCase());
    if (val === -1) continue;
    bits += val.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  const key = Buffer.from(bytes);
  const counter = Math.floor(Date.now() / 1000 / 30);
  const buf = Buffer.alloc(8);
  buf.writeUInt32BE(Math.floor(counter / 2 ** 32), 0);
  buf.writeUInt32BE(counter % 2 ** 32, 4);
  const hmac = nodeCrypto.createHmac('sha1', key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0xf;
  const code = ((hmac[offset] & 0x7f) << 24 | hmac[offset+1] << 16 | hmac[offset+2] << 8 | hmac[offset+3]) % 1000000;
  return code.toString().padStart(6, '0');
}

const EMAIL = `test-2fa-${Date.now()}@bizon.test`;
const PASSWORD = 'T2fa-Cycle-Test-2026!';

const post = async (path, body, token) => {
  const res = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(body),
  });
  return { status: res.status, json: await res.json().catch(() => null) };
};

try {
  // 0. Фикстура: юзер + сессия
  const hash = await hashPassword(PASSWORD);
  // emailHash не важен для этого цикла (нужен только для verify backup-кода)
  const user = await db.user.create({ data: { name: 'Тест 2FA Цикл', emailHash: hashEmail(EMAIL), emailEncrypted: encrypt(EMAIL), passwordHash: hash, ipScore: 0 } });
  const token = 'test-2fa-cycle-token';
  await db.session.create({ data: { userId: user.id, token, expiresAt: new Date(Date.now() + 3600_000) } });
  console.log('fixture user:', user.id);

  // 1. enable (неверный пароль — честная проверка отклонения)
  const wrong = await post('/api/auth/2fa/enable', { password: 'wrong' }, token);
  console.log('enable wrong password →', wrong.status, JSON.stringify(wrong.json));

  // 2. enable (верный пароль)
  const en = await post('/api/auth/2fa/enable', { password: PASSWORD }, token);
  console.log('enable →', en.status, '| qrUrl:', en.json?.qrUrl?.slice(0, 45), '| secret:', en.json?.secret?.slice(0, 8) + '...', '| backupCodes:', en.json?.backupCodes?.length);
  if (en.status !== 200) throw new Error('enable failed: ' + JSON.stringify(en.json));

  // 3. confirm — неверный код сначала
  const badConfirm = await post('/api/auth/2fa/confirm', { token: '000000' }, token);
  console.log('confirm 000000 →', badConfirm.status, JSON.stringify(badConfirm.json));

  // 4. confirm — валидный TOTP из секрета
  const code = generateTotp(en.json.secret);
  const okConfirm = await post('/api/auth/2fa/confirm', { token: code }, token);
  console.log('confirm valid TOTP →', okConfirm.status, JSON.stringify(okConfirm.json));

  // 5. БД: twoFactorEnabled?
  let u = await db.user.findUnique({ where: { id: user.id }, select: { twoFactorEnabled: true, twoFactorSecret: true, backupCodes: true } });
  console.log('DB after confirm:', JSON.stringify({ enabled: u.twoFactorEnabled, hasSecret: !!u.twoFactorSecret, hasBackup: !!u.backupCodes }));

  // 6. verify-роут логина шаг-2? (не тестируем login tempToken — вне задачи; но проверим /api/auth/2fa/verify через tempToken нельзя без логина — пропускаем)

  // 7. disable
  const dis = await post('/api/auth/2fa/disable', { password: PASSWORD }, token);
  console.log('disable →', dis.status, JSON.stringify(dis.json));

  // 8. БД финал
  u = await db.user.findUnique({ where: { id: user.id }, select: { twoFactorEnabled: true, twoFactorSecret: true, backupCodes: true } });
  console.log('DB FINAL:', JSON.stringify(u));
  if (u.twoFactorEnabled !== false) throw new Error('CRITICAL: 2FA still enabled!');

  // 9. cleanup
  await db.session.deleteMany({ where: { userId: user.id } });
  await db.user.delete({ where: { id: user.id } });
  console.log('CLEANUP: fixture user deleted');
  console.log('CYCLE OK, 2FA ENDED DISABLED');
} catch (e) {
  console.error('CYCLE FAILED:', e.message);
  // аварийная очистка любого fixture-юзера
  await db.user.deleteMany({ where: { name: 'Тест 2FA Цикл' } });
  console.error('cleanup done');
  process.exitCode = 1;
} finally {
  await db.$disconnect();
}
