// BizON API — /api/connections
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { ReputationService } from '@/lib/services';
import { NotificationService } from '@/lib/services/notification-service';

export const runtime = 'nodejs';

// Список моих связей (входящие/исходящие/принятые)
export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // W3-4: аддитивный режим «состояние пары я ↔ counterpart» — статусная машина
  // кнопки «Добавить в контакты» на чужом профиле. Односторонний @@unique
  // ([fromUserId, toUserId]) допускает оба ребра пары — смотрим в обе стороны.
  const counterpartId = req.nextUrl.searchParams.get('counterpartId');
  if (counterpartId) {
    if (counterpartId === user.id) return json({ state: 'none', connectionId: null });

    const pair = await db.connection.findMany({
      where: {
        OR: [
          { fromUserId: user.id, toUserId: counterpartId },
          { fromUserId: counterpartId, toUserId: user.id },
        ],
      },
      orderBy: { createdAt: 'desc' },
      select: { id: true, status: true, fromUserId: true },
    });

    const acceptedRow = pair.find((c) => c.status === 'accepted');
    if (acceptedRow) return json({ state: 'accepted', connectionId: acceptedRow.id });

    const pendingRow = pair.find((c) => c.status === 'pending');
    if (pendingRow) {
      return json({
        state: pendingRow.fromUserId === user.id ? 'pending_out' : 'pending_in',
        connectionId: pendingRow.id,
      });
    }

    // Активных отношений нет (нет рёбер или только declined): кнопка снова
    // активна — повторный POST перезапишет declined → pending (честный
    // повторный запрос, получатель снова решает сам).
    return json({ state: 'none', connectionId: null });
  }

  const status = (req.nextUrl.searchParams.get('status') ?? 'all') as 'all' | 'pending' | 'accepted' | 'declined';
  const direction = req.nextUrl.searchParams.get('direction') ?? 'all'; // all | incoming | outgoing

  const where: any = {
    OR: [{ fromUserId: user.id }, { toUserId: user.id }],
  };
  if (status !== 'all') where.status = status;
  if (direction === 'incoming') where.OR = [{ toUserId: user.id }];
  if (direction === 'outgoing') where.OR = [{ fromUserId: user.id }];

  const conns = await db.connection.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    include: {
      // company (аккаунт компании) + employments (текущее подтверждённое место работы) —
      // нужно для табличного вида контактов (11-b); аддитивно, старым потребителям не мешает
      fromUser: {
        select: {
          id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, birthday: true,
          company: { select: { name: true } },
          employments: { where: { isCurrent: true }, take: 1, select: { company: { select: { name: true } } } },
        },
      },
      toUser: {
        select: {
          id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, birthday: true,
          company: { select: { name: true } },
          employments: { where: { isCurrent: true }, take: 1, select: { company: { select: { name: true } } } },
        },
      },
    },
  });

  const companyName = (u: typeof conns[number]['fromUser']): string | null =>
    u.company?.name ?? u.employments?.[0]?.company?.name ?? null;

  return json({
    connections: conns.map((c) => ({
      id: c.id,
      fromUser: { ...c.fromUser, company: companyName(c.fromUser) },
      toUser: { ...c.toUser, company: companyName(c.toUser) },
      status: c.status,
      note: c.note,
      createdAt: c.createdAt.toISOString(),
      // помечаем направление относительно текущего пользователя
      direction: c.fromUserId === user.id ? 'outgoing' : 'incoming',
    })),
  });
}

// Создание запроса на связь
export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { toUserId, note } = body ?? {};
    if (!toUserId) return errorJson('toUserId обязателен', 422);
    if (toUserId === user.id) return errorJson('Нельзя добавить себя', 400);

    const target = await db.user.findUnique({ where: { id: toUserId } });
    if (!target) return errorJson('Пользователь не найден', 404);

    const existing = await db.connection.findFirst({
      where: {
        OR: [
          { fromUserId: user.id, toUserId },
          { fromUserId: toUserId, toUserId: user.id },
        ],
      },
    });
    // W3-4: дубль объясняется текстом (было 400 «Запрос уже существует» без
    // объяснения — нарушение принципа №3 плана «отказ системы объясняется текстом»).
    if (existing) {
      if (existing.status === 'pending') {
        return errorJson(
          existing.fromUserId === user.id
            ? 'Запрос уже отправлен — ожидайте ответа'
            : 'Этот пользователь уже отправил вам запрос — примите или отклоните его во «Входящих»',
          409,
        );
      }
      if (existing.status === 'accepted') {
        return errorJson('Вы уже в контактах', 409);
      }
      // declined → повторный запрос разрешён: перезаписываем существующее ребро
      // (односторонний @@unique не даёт создать второе ребро пары).
      const reopened = await db.connection.update({
        where: { id: existing.id },
        data: { fromUserId: user.id, toUserId, status: 'pending', note },
      });
      await notifyConnectionRequest(user, toUserId, reopened.id);
      return json({ connection: reopened }, 201);
    }

    let conn;
    try {
      conn = await db.connection.create({
        data: { fromUserId: user.id, toUserId, status: 'pending', note },
      });
    } catch (e: any) {
      // P2002 — гонка POST (ребро создал параллельный запрос): тот же 409 с
      // честным текстом по актуальному состоянию пары.
      if (e?.code === 'P2002') {
        const raced = await db.connection.findFirst({
          where: {
            OR: [
              { fromUserId: user.id, toUserId },
              { fromUserId: toUserId, toUserId: user.id },
            ],
          },
          select: { status: true },
        });
        return errorJson(
          raced?.status === 'accepted' ? 'Вы уже в контактах' : 'Запрос уже отправлен — ожидайте ответа',
          409,
        );
      }
      throw e;
    }

    // W3-4: уведомление получателю (раньше НЕ создавалось — получатель узнавал
    // о запросе только случайно; дыра разведки, пункт 5 плана владельца).
    await notifyConnectionRequest(user, toUserId, conn.id);

    return json({ connection: conn }, 201);
  } catch (e) {
    console.error('[connections/create] error:', e);
    return errorJson('Ошибка создания связи', 500);
  }
}

/** W3-4: уведомление получателю запроса в контакты (type='connection_request').
 *  link='/network' — тот же паттерн, что у intro-запросов (intro-service):
 *  запрос обрабатывается в «Контакты → Входящие». */
async function notifyConnectionRequest(
  from: { id: string; name: string },
  toUserId: string,
  connectionId: string,
): Promise<void> {
  try {
    await NotificationService.notify(toUserId, {
      type: 'connection_request',
      title: 'Новый запрос в контакты',
      body: `${from.name} хочет добавить вас в контакты`,
      link: '/network',
      metadata: { connectionId, fromUserId: from.id },
    });
  } catch (e) {
    // FAIL-OPEN: ошибка уведомления не роняет создание связи
    console.error('[connections/notify] error:', e);
  }
}

// Принять/отклонить запрос
export async function PATCH(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { connectionId, action } = body ?? {};
    if (!connectionId || !action) return errorJson('connectionId и action обязательны', 422);
    if (!['accept', 'decline'].includes(action)) return errorJson('action: accept | decline', 422);

    const conn = await db.connection.findUnique({ where: { id: connectionId } });
    if (!conn) return errorJson('Связь не найдена', 404);
    if (conn.toUserId !== user.id) return errorJson('Только получатель может принять/отклонить', 403);

    const updated = await db.connection.update({
      where: { id: connectionId },
      data: { status: action === 'accept' ? 'accepted' : 'declined' },
    });

    if (action === 'accept') {
      // FIX-06: репутация обоим участникам одной пачкой (awardBulk) вместо
      // 2 × ~10 последовательных запросов (event + findUnique + recompute)
      const participants = await db.user.findMany({
        where: { id: { in: [conn.fromUserId, conn.toUserId] } },
        select: { id: true, name: true },
      });
      const nameById = new Map(participants.map((p) => [p.id, p.name]));
      await ReputationService.awardBulk({
        userIds: [conn.fromUserId, conn.toUserId],
        eventType: 'connection_accepted',
        weight: 2,
        payload: (uid) => ({
          with: uid === conn.fromUserId ? nameById.get(conn.toUserId) : nameById.get(conn.fromUserId),
        }),
      });
    }

    return json({ connection: updated });
  } catch (e) {
    console.error('[connections/patch] error:', e);
    return errorJson('Ошибка', 500);
  }
}
