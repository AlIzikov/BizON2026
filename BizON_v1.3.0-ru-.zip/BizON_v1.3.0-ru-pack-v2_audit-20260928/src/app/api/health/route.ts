// BizON API — /api/health
// Этап 6.6 MON: Health check для load balancer'ов и uptime-мониторинга.
// Без auth — публичный endpoint (только статус: ok/error + версия + uptime).
// Не раскрывает sensitive данные.
// (FIX-07/p1-residue): withRoute(auth:false) — health остаётся анонимным для LB;
// поведение (200/503, no-store) сохранено 1:1.

import { db } from '@/lib/db';
import { cache } from '@/lib/cache';
import { withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

// Process start time — для расчёта uptime
const START_TIME = Date.now();

// Phase 16: bumped to 2.0.0 (perf + monitoring)
const VERSION = '2.0.0';

export const GET = withRoute(
  async () => {
    let dbStatus: 'ok' | 'error' = 'ok';
    try {
      // Лёгкий запрос — простой COUNT, чтобы проверить что БД отвечает
      await db.user.count();
    } catch (e: unknown) {
      console.error('[health] DB check failed:', e);
      dbStatus = 'error';
    }

    const uptimeSeconds = Math.floor((Date.now() - START_TIME) / 1000);
    const overall = dbStatus === 'ok' ? 'ok' : 'degraded';

    return Response.json(
      {
        status: overall,
        db: dbStatus,
        version: VERSION,
        uptime: uptimeSeconds,
        // Phase 16: cache size — наблюдаем за in-memory кэшем из health-check
        cacheSize: cache.size(),
        timestamp: new Date().toISOString(),
      },
      {
        status: overall === 'ok' ? 200 : 503,
        headers: {
          // LB часто кэшируют health — даём короткий TTL чтобы не застревать на больном узле
          'cache-control': 'no-store, max-age=0',
        },
      },
    );
  },
  { auth: false },
);
