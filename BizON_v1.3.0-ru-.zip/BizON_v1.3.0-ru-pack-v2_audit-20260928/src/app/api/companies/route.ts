// BizON API — /api/companies (Xing-style Company Hub)
// Использует CompanyService (микросервисный слой)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CompanyService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const industry = req.nextUrl.searchParams.get('industry') ?? undefined;
  const q = req.nextUrl.searchParams.get('q') ?? undefined;

  const companies = await CompanyService.list(user.id, industry, q);
  return json({
    companies: companies.map((c: any) => ({
      id: c.id,
      name: c.name,
      description: c.description,
      logoUrl: c.logoUrl,
      coverUrl: c.coverUrl,
      industry: c.industry,
      size: c.size,
      location: c.location,
      foundedYear: c.foundedYear,
      website: c.website,
      adTrustIndex: c.adTrustIndex,
      followersCount: c._count.followers,
      employeesCount: c._count.employees,
      activeJobsCount: c._count.jobs,
      reviewsCount: c._count.reviews,
      isFollowing: c.followers.length > 0,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  if (user.subscriptionTier !== 'business') {
    return errorJson('Создание компаний доступно только на тарифе Business', 403);
  }

  try {
    const body = await req.json();
    const { name, description, industry, size, location, foundedYear, website, logoUrl, coverUrl } = body ?? {};
    if (!name || !description) return errorJson('name и description обязательны', 422);

    const company = await db.company.create({
      data: {
        name,
        description,
        industry: industry ?? null,
        size: size ?? null,
        location: location ?? null,
        foundedYear: foundedYear ?? null,
        website: website ?? null,
        logoUrl: logoUrl ?? null,
        coverUrl: coverUrl ?? null,
        adTrustIndex: 0.5,
      },
    });

    await db.employee.create({
      data: {
        companyId: company.id,
        userId: user.id,
        position: 'Founder',
        isCurrent: true,
        startDate: new Date(),
      },
    });

    return json({ company }, 201);
  } catch (e) {
    console.error('[companies/create] error:', e);
    return errorJson('Ошибка создания компании', 500);
  }
}
