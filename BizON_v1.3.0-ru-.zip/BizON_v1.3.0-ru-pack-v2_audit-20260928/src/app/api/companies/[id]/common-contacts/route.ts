// BizON API — /api/companies/[id]/common-contacts (ПРАВКА 1 — Vings-UX)
// Возвращает пересечение контактов текущего пользователя (Connection accepted)
// и команды компании (User.companyPublic=true + companyId=this).
// ТЗ: «У вас N общих контактов» + 3 аватара.
import { db } from '@/lib/db';
import { json, withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

// (fix-campaign-p1-residue/wave-b): withRoute — auth 401, params из ctx.
export const GET = withRoute<{ id: string }>(async (_req, { params, user }) => {
  const { id } = params;

  // 1. Контакт-лист текущего пользователя (accepted в обе стороны)
  const myConnections = await db.connection.findMany({
    where: {
      status: 'accepted',
      OR: [{ fromUserId: user.id }, { toUserId: user.id }],
    },
    select: { fromUserId: true, toUserId: true },
  });
  const myContactIds = new Set<string>();
  for (const c of myConnections) {
    if (c.fromUserId === user.id) myContactIds.add(c.toUserId);
    else myContactIds.add(c.fromUserId);
  }

  // 2. Команда компании (с согласия companyPublic)
  const teamUsers = await db.user.findMany({
    where: { companyId: id, companyPublic: true },
    select: {
      id: true, name: true, title: true, avatarUrl: true,
      ipScore: true, level: true,
    },
  });

  // 3. Пересечение: team-users, которые есть в контакт-листе пользователя
  const commonContacts = teamUsers
    .filter((u) => myContactIds.has(u.id))
    .map((u) => ({
      id: u.id,
      name: u.name,
      title: u.title,
      avatarUrl: u.avatarUrl,
      ipScore: u.ipScore,
      level: u.level,
    }));

  return json({
    count: commonContacts.length,
    contacts: commonContacts.slice(0, 8), // 3 для аватаров + запас
  });
});
