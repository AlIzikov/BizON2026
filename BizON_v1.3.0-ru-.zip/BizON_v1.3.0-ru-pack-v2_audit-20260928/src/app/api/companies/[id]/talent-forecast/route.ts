import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { TalentForecastService } from '@/lib/services/talent-forecast-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const rl = checkUserRateLimit(user.id, 'talent:forecast', 10, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Повторите через ${rl.retryAfter}с`, 429);
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const { role, requiredSkills, count, deadlineMonths, withScenarios } = body ?? {};
    if (!role || !Array.isArray(requiredSkills) || !count) return errorJson('role, requiredSkills[], count обязательны', 422);
    const params = {
      role, requiredSkills,
      count: Number(count),
      deadlineMonths: Number(deadlineMonths ?? 12),
    };
    // v6.2 (Task 9-b, doc_a §58): withScenarios=true → многосценарный прогноз
    // (консервативный/реалистичный/оптимистичный × 6/12/24 мес + pipeline-сводка).
    // Ответ аддитивный: поле forecast (старый контракт) сохраняется всегда.
    if (withScenarios === true) {
      const result = await TalentForecastService.forecastScenarios(id, params);
      return json({
        // Старый контракт (default-сценарий) сохраняется без изменений
        forecast: result.baseForecast,
        // Новые аддитивные поля (doc_a §58)
        scenarios: result.scenarios,
        summary: result.summary,
        note: result.note,
        companyId: result.companyId,
        role: result.role,
        requiredSkills: result.requiredSkills,
        requestedCount: result.requestedCount,
      });
    }
    const result = await TalentForecastService.forecast(id, params);
    return json({ forecast: result });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
