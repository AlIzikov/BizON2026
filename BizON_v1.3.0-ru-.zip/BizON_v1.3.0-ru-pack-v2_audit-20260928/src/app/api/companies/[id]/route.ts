// BizON API — /api/companies/[id] (Company Hub — единая страница)
// REV-13 (директива владельца 22-09): представителю компании (своя страничка)
// отзывы отдаются с приватным полем authorRelation (почему автор оставил отзыв)
// и флагом hidden (скрыт модерацией). Внешним поле не отдаётся, скрытые не видны.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { weightedAvgRating } from '@/lib/services/review-eligibility-service';

export const runtime = 'nodejs';

// REV-13: представитель компании = User.companyId (аккаунт компании) ИЛИ Employee
async function isCompanyRepresentative(userId: string, companyId: string): Promise<boolean> {
  const [accountLinked, employment] = await Promise.all([
    db.user.findFirst({ where: { id: userId, companyId }, select: { id: true } }),
    db.employee.findFirst({ where: { companyId, userId }, select: { id: true } }),
  ]);
  return !!(accountLinked || employment);
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // REV-13: приватная проекция отзыва для представителей компании —
  // считаем ДО fetch (where по reviews зависит от флага)
  const isRep = await isCompanyRepresentative(user.id, id);

  const company = await db.company.findUnique({
    where: { id },
    include: {
      employees: {
        where: { isCurrent: true },
        take: 12,
        include: {
          user: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true } },
        },
        orderBy: { startDate: 'desc' },
      },
      reviews: {
        take: 5,
        orderBy: { createdAt: 'desc' },
        // REV-13: внешние не видят скрытых; представителям показываем все
        // (с флагом hidden) — они должны знать исход своих обращений
        where: isRep ? {} : { hiddenAt: null },
        include: {
          author: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true } },
        },
      },
      jobs: {
        where: { active: true },
        take: 6,
        orderBy: { createdAt: 'desc' },
      },
      events: {
        where: { startDate: { gte: new Date() } },
        take: 4,
        orderBy: { startDate: 'asc' },
      },
      _count: {
        select: {
          followers: true,
          employees: { where: { isCurrent: true } },
          jobs: { where: { active: true } },
          reviews: true,
        },
      },
      followers: { where: { userId: user.id }, select: { id: true } },
    },
  });

  if (!company) return errorJson('Компания не найдена', 404);

  // Средний рейтинг из отзывов — ВЗВЕШЕННЫЙ по типу доказательства (W1-4,
  // анти-«дружеские обмены отзывами»): проект/клиент/подрядчик ×1.0,
  // сотрудник ×0.8, прямой контакт ×0.3. Формула — review-eligibility-service.
  // Скрытые модерацией (hiddenAt) в рейтинге не участвуют — ни для кого.
  const allReviews = await db.companyReview.findMany({
    where: { companyId: id, hiddenAt: null },
    select: { rating: true, evidenceType: true },
  });
  const weightedAvg = weightedAvgRating(allReviews);
  const avgRating = weightedAvg === null ? 0 : Math.round(weightedAvg * 10) / 10;
  // REV-13: счётчик отзывов без скрытых (иначе у внешних счётчик врёт)
  const visibleReviewsCount = await db.companyReview.count({
    where: { companyId: id, hiddenAt: null },
  });

  // Похожие компании (та же отрасль, исключая текущую)
  const similarCompanies = company.industry
    ? await db.company.findMany({
        where: {
          industry: company.industry,
          id: { not: id },
        },
        take: 4,
        include: {
          _count: { select: { followers: true, employees: { where: { isCurrent: true } } } },
        },
      })
    : [];

  return json({
    company: {
      id: company.id,
      name: company.name,
      description: company.description,
      logoUrl: company.logoUrl,
      coverUrl: company.coverUrl,
      website: company.website,
      industry: company.industry,
      size: company.size,
      location: company.location,
      foundedYear: company.foundedYear,
      adTrustIndex: company.adTrustIndex,
      // статистика
      followersCount: company._count.followers,
      employeesCount: company._count.employees,
      activeJobsCount: company._count.jobs,
      reviewsCount: visibleReviewsCount,
      avgRating,
      isFollowing: company.followers.length > 0,
      // REV-13: флаг приватной проекции для UI (показать rep-блоки на своей страничке)
      viewerIsCompanyRep: isRep,
      // карусели
      employees: company.employees.map((e) => ({
        ...e.user,
        position: e.position,
        startDate: e.startDate?.toISOString() ?? null,
      })),
      reviews: company.reviews.map((r) => ({
        id: r.id,
        rating: r.rating,
        title: r.title,
        pros: r.pros,
        cons: r.cons,
        verifiedEmployee: r.verifiedEmployee,
        // W1-2 (аддитивно, тот же контракт, что W0-4 GET /reviews): тип
        // доказательства для бейджа ReviewCard — встроенные отзывы здесь
        // единственный источник отзывов для UI страницы компании.
        evidenceType: r.evidenceType,
        createdAt: r.createdAt.toISOString(),
        author: r.author,
        // REV-13: приватная часть — ТОЛЬКО представителю компании
        ...(isRep
          ? {
              authorRelation: r.authorRelation || null,
              authorRelationNote: r.authorRelationNote,
              hidden: !!r.hiddenAt,
            }
          : {}),
      })),
      jobs: company.jobs.map((j) => ({
        id: j.id,
        title: j.title,
        description: j.description,
        requiredSkills: j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [],
        salaryFrom: j.salaryFrom,
        salaryTo: j.salaryTo,
        location: j.location,
        growthScore: j.growthScore,
      })),
      events: company.events.map((e) => ({
        id: e.id,
        title: e.title,
        format: e.format,
        category: e.category,
        startDate: e.startDate?.toISOString() ?? null,
        endDate: e.endDate?.toISOString() ?? null,
        location: e.location,
        imageUrl: e.imageUrl,
        maxParticipants: e.maxParticipants,
      })),
      // похожие компании
      similarCompanies: similarCompanies.map((c) => ({
        id: c.id,
        name: c.name,
        logoUrl: c.logoUrl,
        industry: c.industry,
        size: c.size,
        location: c.location,
        followersCount: c._count.followers,
        employeesCount: c._count.employees,
      })),
    },
  });
}
