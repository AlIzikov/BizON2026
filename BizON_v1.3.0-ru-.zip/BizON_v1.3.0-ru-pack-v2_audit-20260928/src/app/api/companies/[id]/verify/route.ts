// BizON API — /api/companies/[id]/verify (admin only)
// Этап 4.1 — Company Persona: подтверждение юр.инфо (ИНН/ОГРН)
// В реальном проде — интеграция с ЕГРЮЛ API (пока заглушка: простая валидация длины)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли

export const runtime = 'nodejs';

function normalizeDigits(s: unknown): string {
  return String(s ?? '').replace(/\D+/g, '');
}

function isValidInn(inn: string): boolean {
  // ИНН: 10 цифр (юр.лицо) или 12 цифр (ИП)
  return inn.length === 10 || inn.length === 12;
}

function isValidOgrn(ogrn: string): boolean {
  // ОГРН: 13 цифр (юр.лицо) или ОГРНИП: 15 цифр (ИП)
  return ogrn.length === 13 || ogrn.length === 15;
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Admin only: роль 'admin' в CSV-строке user.roles (FIX-02: isAdminRole)
  if (!isAdminRole(user.roles)) return errorJson('Доступ только для администратора', 403);

  let body: any = null;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }

  const inn = normalizeDigits(body?.inn);
  const ogrn = normalizeDigits(body?.ogrn);

  if (!inn && !ogrn) {
    return errorJson('Укажите ИНН и/или ОГРН', 422);
  }
  if (inn && !isValidInn(inn)) {
    return errorJson('ИНН должен содержать 10 или 12 цифр', 422);
  }
  if (ogrn && !isValidOgrn(ogrn)) {
    return errorJson('ОГРН должен содержать 13 или 15 цифр', 422);
  }

  const company = await db.company.findUnique({ where: { id } });
  if (!company) return errorJson('Компания не найдена', 404);

  // Заглушка: в проде — запрос в ЕГРЮЛ API и проверка соответствия name/inn/ogrn.
  // Здесь — простая валидация длины и пометка isVerified=true.
  const updated = await db.company.update({
    where: { id },
    data: {
      inn: inn || company.inn,
      ogrn: ogrn || company.ogrn,
      isVerified: true,
      verifiedAt: new Date(),
    },
    select: {
      id: true,
      name: true,
      inn: true,
      ogrn: true,
      isVerified: true,
      verifiedAt: true,
    },
  });

  return json({
    company: {
      ...updated,
      verifiedAt: updated.verifiedAt?.toISOString() ?? null,
    },
    note: 'Заглушка ЕГРЮЛ: верификация выполнена по валидации длины ИНН/ОГРН. В проде — интеграция с ЕГРЮЛ API.',
  });
}
