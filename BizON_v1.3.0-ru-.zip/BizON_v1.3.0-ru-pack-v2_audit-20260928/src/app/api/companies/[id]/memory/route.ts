// BizON API — GET /api/companies/[id]/memory (Wave 4, S-094).
// «Память компании»: верифицированные заказчиком проекты + уникальные
// участники. §3.3: только факты, без рейтингов.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { CompanyMemoryService } from '@/lib/services/project-evidence-service';

export const runtime = 'nodejs';

export const GET = withRoute<{ id: string }>(async (req, ctx) => {
  const result = await CompanyMemoryService.get(ctx.params.id);
  if (result.ok) return NextResponse.json(result.data);
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
}, { auth: false });
