// BizON API — /api/companies/[id]/trust (Phase 2 — Company Trust)
// GET — возвращает 4 индекса доверия (employerTrust, businessTrust, deliveryTrust,
//        transparency) + overall + basis (основа расчёта).
import { json, errorJson, withRoute, RATE_CLASSES } from '@/lib/api-helpers';
import { CompanyTrustService } from '@/lib/services/company-trust-service';
import { cache, CACHE_TTL } from '@/lib/cache';

export const runtime = 'nodejs';

// (fix-campaign-p1-residue/wave-b): withRoute — auth 401, params из ctx.
export const GET = withRoute<{ id: string }>(async (_req, { params }) => {
  const { id } = params;

  // Phase 16: кэш 5 минут по companyId — CompanyTrustService.calculate делает
  // несколько JOIN-запросов (jobs, reviews, culturalSignals). Trust-индексы
  // меняются редко — отзыв оставлен / вакансия опубликована.
  // Инвалидация: cache.invalidatePrefix(`company-trust:${id}:`) при новом отзыве.
  const cacheKey = `company-trust:${id}`;
  const cached = cache.get<unknown>(cacheKey);
  if (cached !== null) return json(cached);

  const score = await CompanyTrustService.calculate(id);
  if (!score) return errorJson('Компания не найдена', 404);

  const result = { trust: score };
  cache.set(cacheKey, result, CACHE_TTL.MEDIUM);
  return json(result);
}, {
  // PR #3 (волна R0.3): rate-класс для безлимитного withRoute —
  // холодный расчёт = несколько JOIN-запросов (кэш 5 мин его смягчает).
  rateLimit: {
    key: 'company-trust:get',
    limit: RATE_CLASSES.USER_READ.limit,
    windowMs: RATE_CLASSES.USER_READ.windowMs,
  },
});
