// BizON API — /api/companies/[id]/stream
// P1: Company Stream — лента компании (хронологическая).
// Объединяет 5 типов карточек:
//   📰 news    — NewsCard где sourceDomain совпадает с website компании или одним из newsSources URL
//   🚀 project — последние 5 COMPLETED + ACTIVE проектов компании
//   💼 job     — последние 5 активных вакансий
//   ⭐ review  — последние 3 CulturalSignal (published + verified)
//   🏆 achievement — ActionEvent где metadata содержит companyId=this
// Все карточки сортируются по timestamp (desc).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

type StreamItemType = 'news' | 'project' | 'job' | 'review' | 'achievement';

interface StreamItemBase {
  id: string;
  type: StreamItemType;
  timestamp: string; // ISO
}

interface NewsStreamItem extends StreamItemBase {
  type: 'news';
  title: string;
  description: string | null;
  url: string;
  imageUrl: string | null;
  aiSummary: string;
  sourceDomain: string;
  publishedAt: string;
}

interface ProjectStreamItem extends StreamItemBase {
  type: 'project';
  title: string;
  description: string;
  status: string;
  outcome: string | null;
  rating: number;
  fundingType: string | null;
  tags: string[];
  startedAt: string;
  completedAt: string | null;
}

interface JobStreamItem extends StreamItemBase {
  type: 'job';
  title: string;
  description: string;
  salaryFrom: number | null;
  salaryTo: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  location: string | null;
  requiredSkills: string[];
  growthScore: number;
}

interface ReviewStreamItem extends StreamItemBase {
  type: 'review';
  rating: number;
  category: string;
  text: string;
  isAnonymous: boolean;
  isVerified: boolean;
  author: {
    id: string | null;
    name: string;
    title: string | null;
    avatarUrl: string | null;
    ipScore: number;
    level: string;
  } | null;
}

interface AchievementStreamItem extends StreamItemBase {
  type: 'achievement';
  title: string;
  description: string | null;
  eventType: string;
}

type StreamItem =
  | NewsStreamItem
  | ProjectStreamItem
  | JobStreamItem
  | ReviewStreamItem
  | AchievementStreamItem;

/**
 * Извлечь домен из URL.
 * "https://blog.example.com/path" → "blog.example.com"
 */
function extractDomain(url: string): string | null {
  try {
    const u = new URL(url);
    return u.hostname.toLowerCase().replace(/^www\./, '');
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  // stream публичный — но в текущейBizON-модели require auth для всех /api/companies/[id]/*
  // следуем тому же паттерну (read-only)
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 30), 100);

  const company = await db.company.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      website: true,
      newsSources: true,
    },
  });
  if (!company) return errorJson('Компания не найдена', 404);

  // Собираем домены компании: website + up to 5 newsSources URLs
  const companyDomains = new Set<string>();
  if (company.website) {
    const d = extractDomain(company.website);
    if (d) companyDomains.add(d);
  }
  if (company.newsSources) {
    try {
      const sources: unknown = JSON.parse(company.newsSources);
      if (Array.isArray(sources)) {
        for (const url of sources) {
          if (typeof url === 'string') {
            const d = extractDomain(url);
            if (d) companyDomains.add(d);
          }
        }
      }
    } catch {
      // ignore broken JSON
    }
  }

  // Запускаем все 5 запросов параллельно
  const [news, projects, jobs, reviews, achievements] = await Promise.all([
    // 📰 News: sourceDomain ∈ companyDomains (status=published)
    companyDomains.size > 0
      ? db.newsCard.findMany({
          where: {
            status: 'published',
            sourceDomain: { in: Array.from(companyDomains) },
          },
          orderBy: { publishedAt: 'desc' },
          take: 10,
          select: {
            id: true,
            url: true,
            title: true,
            description: true,
            imageUrl: true,
            aiSummary: true,
            sourceDomain: true,
            publishedAt: true,
          },
        })
      : Promise.resolve([]),

    // 🚀 Projects: последние 5 (COMPLETED + ACTIVE)
    db.project.findMany({
      where: {
        companyId: id,
        status: { in: ['COMPLETED', 'ACTIVE'] },
      },
      orderBy: [{ status: 'asc' }, { createdAt: 'desc' }],
      take: 5,
      select: {
        id: true,
        title: true,
        description: true,
        status: true,
        outcome: true,
        rating: true,
        fundingType: true,
        tags: true,
        startedAt: true,
        completedAt: true,
        createdAt: true,
      },
    }),

    // 💼 Jobs: последние 5 активных
    db.job.findMany({
      where: { companyId: id, active: true },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: {
        id: true,
        title: true,
        description: true,
        salaryFrom: true,
        salaryTo: true,
        salaryMin: true,
        salaryMax: true,
        currency: true,
        location: true,
        requiredSkills: true,
        growthScore: true,
        createdAt: true,
      },
    }),

    // ⭐ Reviews: последние 3 CulturalSignal (published + verified)
    db.culturalSignal.findMany({
      where: { companyId: id, status: 'published', isVerified: true },
      orderBy: { createdAt: 'desc' },
      take: 3,
      select: {
        id: true,
        rating: true,
        category: true,
        text: true,
        isAnonymous: true,
        isVerified: true,
        createdAt: true,
        author: {
          select: {
            id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true,
          },
        },
      },
    }),

    // 🏆 Achievements: ActionEvent где metadata JSON содержит "companyId":"<id>"
    //    SQLite не поддерживает JSON-фильтры напрямую — фильтруем в JS (после выборки по isPublic).
    db.actionEvent.findMany({
      where: {
        isPublic: true,
        // быстрый пре-фильтр: metadata содержит строку id
        // SQLite: LIKE с шаблоном. cuid — 24 символа, без спецсимволов — безопасно в LIKE.
        metadata: { contains: id },
      },
      orderBy: { createdAt: 'desc' },
      take: 50, // пре-фильтр, точный match — ниже
      select: {
        id: true,
        type: true,
        title: true,
        description: true,
        metadata: true,
        createdAt: true,
      },
    }),
  ]);

  // === Точная фильтрация achievements по metadata.companyId ===
  const filteredAchievements = achievements.filter((a) => {
    if (!a.metadata) return false;
    try {
      const parsed = JSON.parse(a.metadata);
      if (parsed && typeof parsed === 'object' && parsed.companyId === id) return true;
      return false;
    } catch {
      return false;
    }
  }).slice(0, 10);

  // === Маппинг в унифицированные StreamItem ===
  const items: StreamItem[] = [];

  for (const n of news) {
    items.push({
      id: `news:${n.id}`,
      type: 'news',
      timestamp: n.publishedAt.toISOString(),
      title: n.title,
      description: n.description,
      url: n.url,
      imageUrl: n.imageUrl,
      aiSummary: n.aiSummary,
      sourceDomain: n.sourceDomain,
      publishedAt: n.publishedAt.toISOString(),
    });
  }

  for (const p of projects) {
    items.push({
      id: `project:${p.id}`,
      type: 'project',
      // timestamp: completedAt для COMPLETED, createdAt для ACTIVE
      timestamp: (p.completedAt ?? p.createdAt).toISOString(),
      title: p.title,
      description: p.description,
      status: p.status,
      outcome: p.outcome,
      rating: p.rating,
      fundingType: p.fundingType,
      tags: p.tags ? p.tags.split(',').filter(Boolean) : [],
      startedAt: p.startedAt.toISOString(),
      completedAt: p.completedAt?.toISOString() ?? null,
    });
  }

  for (const j of jobs) {
    items.push({
      id: `job:${j.id}`,
      type: 'job',
      timestamp: j.createdAt.toISOString(),
      title: j.title,
      description: j.description,
      salaryFrom: j.salaryFrom,
      salaryTo: j.salaryTo,
      salaryMin: j.salaryMin,
      salaryMax: j.salaryMax,
      currency: j.currency,
      location: j.location,
      requiredSkills: j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [],
      growthScore: j.growthScore,
    });
  }

  for (const r of reviews) {
    items.push({
      id: `review:${r.id}`,
      type: 'review',
      timestamp: r.createdAt.toISOString(),
      rating: r.rating,
      category: r.category,
      text: r.text,
      isAnonymous: r.isAnonymous,
      isVerified: r.isVerified,
      author: r.isAnonymous
        ? null
        : {
            id: r.author.id,
            name: r.author.name,
            title: r.author.title,
            avatarUrl: r.author.avatarUrl,
            ipScore: r.author.ipScore,
            level: r.author.level,
          },
    });
  }

  for (const a of filteredAchievements) {
    items.push({
      id: `achievement:${a.id}`,
      type: 'achievement',
      timestamp: a.createdAt.toISOString(),
      title: a.title,
      description: a.description,
      eventType: a.type,
    });
  }

  // Сортировка по timestamp desc, ограничение по limit
  items.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  const limited = items.slice(0, limit);

  return json({
    items: limited,
    total: items.length,
    counts: {
      news: news.length,
      projects: projects.length,
      jobs: jobs.length,
      reviews: reviews.length,
      achievements: filteredAchievements.length,
    },
  });
}
