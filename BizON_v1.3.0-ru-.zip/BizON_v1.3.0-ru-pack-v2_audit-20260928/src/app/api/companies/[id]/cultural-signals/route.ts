// BizON API — /api/companies/[id]/cultural-signals
// GET  — список сигналов компании (public: только published+verified; owner: все)
// POST — создать/обновить отзыв (auth + verified employee check)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { CulturalSignalsService } from '@/lib/services/cultural-signals-service';

export const runtime = 'nodejs';

// Список сигналов
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);

  // public: только published + isVerified
  // owner / admin: все сигналы
  let onlyPublished = true;
  if (user) {
    const company = await db.company.findUnique({
      where: { id },
      select: { id: true },
    });
    if (company) {
      const isOwnerOfCompany = await db.user.findFirst({
        where: { id: user.id, companyId: id },
        select: { id: true },
      });
      if (isOwnerOfCompany || isAdminRole(user.roles)) {
        onlyPublished = false;
      }
    }
  }

  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 50), 200);
  const offset = Math.max(Number(req.nextUrl.searchParams.get('offset') ?? 0), 0);

  try {
    const [signals, rating] = await Promise.all([
      CulturalSignalsService.getSignalsForCompany(id, { onlyPublished, limit, offset }),
      CulturalSignalsService.getAverageRating(id),
    ]);

    return json({
      signals,
      rating,
      isVerifiedEmployee: user
        ? await CulturalSignalsService.isVerifiedEmployee(user.id, id)
        : false,
    });
  } catch (e: any) {
    console.error('[cultural-signals/list] error:', e);
    return errorJson('Ошибка получения отзывов', 500);
  }
}

// Создать / обновить сигнал
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { rating, category, text, isAnonymous } = body ?? {};

    if (typeof rating !== 'number' || rating < 1 || rating > 5) {
      return errorJson('rating должен быть числом 1-5', 422);
    }
    if (typeof category !== 'string' || !category) {
      return errorJson('category обязателен', 422);
    }
    if (typeof text !== 'string' || !text.trim()) {
      return errorJson('text обязателен', 422);
    }

    const signal = await CulturalSignalsService.createSignal({
      companyId: id,
      authorId: user.id,
      rating,
      category,
      text,
      isAnonymous: !!isAnonymous,
    });

    return json(
      {
        signal: {
          id: signal.id,
          rating: signal.rating,
          category: signal.category,
          text: signal.text,
          isAnonymous: signal.isAnonymous,
          isVerified: signal.isVerified,
          status: signal.status,
          createdAt: signal.createdAt.toISOString(),
        },
        // Для UI: пометка про премодерацию (rating<=2 → pending)
        moderationNote:
          signal.status === 'pending'
            ? 'Отзыв с низкой оценкой отправлен на премодерацию администратору.'
            : undefined,
      },
      201
    );
  } catch (e: any) {
    const msg = e?.message || 'Ошибка создания отзыва';
    // Известные user-facing ошибки → 403/422
    if (msg.includes('подтвердите работу')) return errorJson(msg, 403);
    if (msg.includes('rating') || msg.includes('категория') || msg.includes('Текст')) {
      return errorJson(msg, 422);
    }
    console.error('[cultural-signals/create] error:', e);
    return errorJson(msg, 500);
  }
}
