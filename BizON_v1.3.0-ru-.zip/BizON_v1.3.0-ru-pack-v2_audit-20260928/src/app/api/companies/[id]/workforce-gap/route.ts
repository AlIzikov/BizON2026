import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { WorkforceService } from '@/lib/services/workforce-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const { id } = await ctx.params;
    const gaps = await WorkforceService.getGap(id);
    return json({ gaps, totalGaps: gaps.length, criticalGaps: gaps.filter((g: any) => g.severity === 'critical').length });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
