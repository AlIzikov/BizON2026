// BizON API — /api/companies/[id]/claims/[claimId]/dispute
// P1: любой авторизованный пользователь может оспорить заявление компании.
// claim.status → 'disputed'. Опционально: { reason } — добавляется в evidence.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson , withRoute } from '@/lib/api-helpers';
import { CompanyClaimService } from '@/lib/services';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIP } from '@/lib/security/rate-limiter';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

async function __bizon_impl_post(req: Request, ctx: { params: {  id: string; claimId: string  } }) {
  const { id, claimId } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Rate-limit: оспаривание — мутация, лимитируем как reviews/claims
  const rl = checkUserRateLimit(user.id, 'company_claim:dispute', ...MUTATION_LIMITS.eventsCreate);
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  // Проверка: claim принадлежит этой компании
  const claim = await db.companyClaim.findUnique({ where: { id: claimId } });
  if (!claim) return errorJson('Заявление не найдено', 404);
  if (claim.companyId !== id) {
    return errorJson('Заявление не принадлежит этой компании', 400);
  }

  let reason: string | undefined;
  try {
    const body = await req.json();
    reason = typeof body?.reason === 'string' ? body.reason : undefined;
  } catch {
    // body опциональный
  }

  try {
    const updated = await CompanyClaimService.disputeClaim(claimId, reason);

    try {
      AuditLog.log({
        actorId: user.id,
        action: 'dispute',
        resource: 'company_claim',
        resourceId: claimId,
        ip: getClientIP(req),
        metadata: {
          companyId: id,
          type: claim.type,
          claimText: claim.claimText,
          previousStatus: claim.status,
          reason: reason?.slice(0, 500) ?? null,
        },
      });
    } catch {
      // fail-open
    }

    return json({ claim: updated });
  } catch (e: any) {
    const msg = e?.message || 'Ошибка оспаривания заявления';
    if (msg.includes('не найден')) return errorJson(msg, 404);
    console.error('[companies/claims/dispute] error:', e);
    return errorJson(msg, 500);
  }
}


// DEF-16 (FIX-07): withRoute — auth 401, malformed JSON → 400, P2002 → 409, safe 500 + H11 лимит 60/мин.
export const POST = withRoute<{  id: string; claimId: string  }>(__bizon_impl_post, {
  rateLimit: { key: 'api:companies/[id]/claims/[claimId]/dispute:POST', limit: 60, windowMs: 60_000 },
});
