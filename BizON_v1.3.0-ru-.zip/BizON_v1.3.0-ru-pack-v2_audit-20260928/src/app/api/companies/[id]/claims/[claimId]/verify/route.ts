// BizON API — /api/companies/[id]/claims/[claimId]/verify
// P1: admin/moderator подтверждает заявление компании (status → verified)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { CompanyClaimService } from '@/lib/services';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIP } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string; claimId: string }> }) {
  const { id, claimId } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if (!isAdminRole(user.roles)) {
    return errorJson('Доступ только для администратора', 403);
  }

  // Проверка: claim принадлежит этой компании
  const claim = await db.companyClaim.findUnique({ where: { id: claimId } });
  if (!claim) return errorJson('Заявление не найдено', 404);
  if (claim.companyId !== id) {
    return errorJson('Заявление не принадлежит этой компании', 400);
  }

  try {
    const updated = await CompanyClaimService.verifyClaim(claimId, user.id);

    try {
      AuditLog.log({
        actorId: user.id,
        action: 'verify',
        resource: 'company_claim',
        resourceId: claimId,
        ip: getClientIP(req),
        metadata: { companyId: id, type: claim.type, claimText: claim.claimText },
      });
    } catch {
      // fail-open
    }

    return json({ claim: updated });
  } catch (e: any) {
    const msg = e?.message || 'Ошибка верификации заявления';
    if (msg.includes('не найден')) return errorJson(msg, 404);
    console.error('[companies/claims/verify] error:', e);
    return errorJson(msg, 500);
  }
}
