// BizON API — /api/companies/[id]/claims
// P1: CompanyClaim — список и создание заявлений компании (Claim → Evidence → Verification)
//
// GET  — список claims компании.
//        public (anon/не-владелец): только verified claims.
//        owner (user.companyId === id) / admin: все claims.
// POST — создать claim. Только company admin (user.companyId === id).
//        Опционально: evidence[] — массив доказательств (ссылки/комментарии).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { CompanyClaimService, COMPANY_CLAIM_TYPES } from '@/lib/services';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIP } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

async function isCompanyOwner(userId: string, companyId: string): Promise<boolean> {
  const u = await db.user.findFirst({
    where: { id: userId, companyId },
    select: { id: true },
  });
  return !!u;
}

// GET — список claims
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);

  // public: только verified. owner/admin: все.
  let owner = false;
  if (user) {
    if (isAdminRole(user.roles)) {
      owner = true;
    } else {
      owner = await isCompanyOwner(user.id, id);
    }
  }

  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 100), 200);
  const offset = Math.max(Number(req.nextUrl.searchParams.get('offset') ?? 0), 0);

  try {
    const claims = await CompanyClaimService.listClaims(id, { owner, limit, offset });
    const truth = await CompanyClaimService.getCompanyTruth(id);
    return json({
      claims,
      truthScore: truth.truthScore,
      counts: {
        claimed: truth.claimed.length,
        verified: truth.verified.length,
        disputed: truth.disputed.length,
        rejected: truth.rejected.length,
      },
      isOwner: owner,
    });
  } catch (e: any) {
    console.error('[companies/claims/list] error:', e);
    return errorJson('Ошибка получения заявлений', 500);
  }
}

// POST — создать claim (company admin only)
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только admin ИЛИ user, привязанный к этой компании
  // FIX-07 cross-fix: остаток миграции FIX-02 (isAdmin удалён, должен быть isAdminRole)
  const admin = isAdminRole(user.roles);
  if (!admin) {
    const owner = await isCompanyOwner(user.id, id);
    if (!owner) {
      return errorJson('Только представитель компании может создавать заявления', 403);
    }
  }

  let body: any = null;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }

  const { type, claimText, claimValue, evidence } = body ?? {};

  if (!type || !COMPANY_CLAIM_TYPES.includes(type)) {
    return errorJson(`type должен быть одним из: ${COMPANY_CLAIM_TYPES.join(', ')}`, 422);
  }
  if (typeof claimText !== 'string' || !claimText.trim()) {
    return errorJson('claimText обязателен', 422);
  }

  // Проверка существования компании
  const company = await db.company.findUnique({ where: { id }, select: { id: true, name: true } });
  if (!company) return errorJson('Компания не найдена', 404);

  try {
    const claim = await CompanyClaimService.createClaim({
      companyId: id,
      type,
      claimText,
      claimValue: claimValue != null ? String(claimValue) : null,
      evidence: Array.isArray(evidence) ? evidence : null,
    });

    try {
      AuditLog.log({
        actorId: user.id,
        action: 'create',
        resource: 'company_claim',
        resourceId: claim.id,
        ip: getClientIP(req),
        metadata: { companyId: id, type, claimText: claim.claimText },
      });
    } catch {
      // fail-open
    }

    return json({ claim }, 201);
  } catch (e: any) {
    const msg = e?.message || 'Ошибка создания заявления';
    if (msg.includes('type') || msg.includes('claimText')) {
      return errorJson(msg, 422);
    }
    console.error('[companies/claims/create] error:', e);
    return errorJson(msg, 500);
  }
}
