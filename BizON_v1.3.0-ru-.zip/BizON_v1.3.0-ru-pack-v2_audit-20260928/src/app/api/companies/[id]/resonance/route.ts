// BizON API — Анкета резонанса компании
// (GET/PUT /api/companies/[id]/resonance).
//
// GET: USER_READ — анкета компании или честный INSUFFICIENT_DATA.
// PUT: AUTH_STRICT 10/мин — только владелец компании (право проверяет
// CompanyResonanceService.upsert); zod: offering/team 8 слайдеров 0..100,
// evidence ≥3 (canonical гейт RESONANCE_EVIDENCE_REQUIRED).
import { z } from 'zod';
import { json } from '@/lib/api-helpers';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { CompanyResonanceService, MIN_EVIDENCE } from '@/lib/services/company-resonance-service';
import { TRAIT_IDS } from '@/lib/resonance/traits';

export const runtime = 'nodejs';

const paramsSchema = z.object({
  id: z.string().cuid('Некорректный id компании'),
});

const slidersSchema = z.object(
  Object.fromEntries(TRAIT_IDS.map((t) => [t, z.number().min(0).max(100)])) as Record<
    string,
    z.ZodNumber
  >,
);

const evidenceSchema = z
  .array(
    z.object({
      ref: z.string().trim().min(1, 'Ссылка/идентификатор обязательны').max(200),
      note: z.string().trim().min(1, 'Пояснение обязательно').max(500),
    }),
  )
  .min(MIN_EVIDENCE, `Нужно минимум ${MIN_EVIDENCE} доказательства`)
  .max(20);

const putSchema = z.object({
  offering: slidersSchema,
  team: slidersSchema,
  evidence: evidenceSchema,
});

export const GET = withRoute(async (_req, { params }) => {
  const { id } = params as z.infer<typeof paramsSchema>;
  const result = await CompanyResonanceService.get(id);
  return json(result);
}, {
  paramsSchema,
  rateLimit: {
    key: 'resonance:company:get',
    limit: RATE_CLASSES.USER_READ.limit,
    windowMs: RATE_CLASSES.USER_READ.windowMs,
  },
});

export const PUT = withRoute(async (req, { user, params, data }) => {
  const { id } = params as z.infer<typeof paramsSchema>;
  const body = data as z.infer<typeof putSchema>;
  const result = await CompanyResonanceService.upsert(id, user.id, {
    offering: body.offering,
    team: body.team,
    evidence: body.evidence,
  });
  return json(result, 201);
}, {
  paramsSchema,
  schema: putSchema,
  rateLimit: {
    key: 'resonance:company:put',
    limit: RATE_CLASSES.AUTH_STRICT.limit,
    windowMs: RATE_CLASSES.AUTH_STRICT.windowMs,
  },
});
