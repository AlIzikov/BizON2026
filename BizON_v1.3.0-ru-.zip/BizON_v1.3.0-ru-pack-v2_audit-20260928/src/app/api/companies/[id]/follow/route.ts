// BizON API — /api/companies/[id]/follow
// Использует CompanyService
// API-005 (аудит 22-09-26): catch-all `e.message → 400` удалён — сырой текст
// исключения (стек/провайдер) не покидает сервер. Ошибки маппятся честно:
// P2003/P2025 → 404 NOT_FOUND, остальное → 500 INTERNAL_ERROR (+console-лог).
import { NextRequest } from 'next/server';
import { Prisma } from '@prisma/client';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { CompanyService } from '@/lib/services';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401, 'AUTH_REQUIRED');

  try {
    const result = await CompanyService.follow(id, user.id);
    const count = await db.companyFollower.count({ where: { companyId: id } });
    return json({ following: result.following, followersCount: count });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && (e.code === 'P2003' || e.code === 'P2025')) {
      return errorJson('Компания не найдена', 404, 'NOT_FOUND');
    }
    console.error('[companies/follow] unexpected:', e);
    return errorJson('Внутренняя ошибка сервера', 500, 'INTERNAL_ERROR');
  }
}
