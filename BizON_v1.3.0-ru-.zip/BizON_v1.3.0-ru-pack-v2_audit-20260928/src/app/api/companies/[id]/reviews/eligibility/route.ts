// BizON API — GET /api/companies/[id]/reviews/eligibility
// OWNER-UX-PLAN W1-2: гейт-эндпоинт «может ли текущий пользователь оставить
// отзыв об этой компании». Отвечает объяснением (reasons) — принцип №3 плана:
// отказ системы объясняется текстом, никаких молчаливых 403.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkCompanyReviewEligibility } from '@/lib/services/review-eligibility-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const company = await db.company.findUnique({ where: { id }, select: { id: true } });
  if (!company) return errorJson('Компания не найдена', 404);

  const eligibility = await checkCompanyReviewEligibility(user.id, id);
  const strongestEvidence = eligibility.strongest
    ? eligibility.evidence.find((e) => e.type === eligibility.strongest)
    : undefined;

  return json({
    eligible: eligibility.eligible,
    reasons: eligibility.reasons,
    strongest: eligibility.strongest,
    evidenceCount: eligibility.evidence.length,
    // аддитивно для UI: какие категории найдены (чтобы показать подсказки только
    // по НЕдостающим) + label самого сильного доказательства (сноска в форме)
    evidenceTypes: [...new Set(eligibility.evidence.map((e) => e.type))],
    strongestLabel: strongestEvidence?.label ?? null,
  });
}
