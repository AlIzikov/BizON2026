// BizON API — /api/companies/[id]/reviews
// OWNER-UX-PLAN W0-4 (гигиена: дедуп/лимиты/rate-limit) + W1-2 (гейт взаимодействия).
// REV-13 (директива владельца 22-09): обязательное поле «почему я оставляю отзыв»
// (authorRelation) + приватная видимость: поле видит ТОЛЬКО тот, на кого написан
// отзыв (представители компании) через свою страничку; внешним не отдаётся.
// Модерация: скрытые (hiddenAt) отзывы не видны никому, кроме представителей
// компании (те видят с флагом hidden) — так компания знает исход своей жалобы.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkCompanyReviewEligibility } from '@/lib/services/review-eligibility-service';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

// Лимиты длин (W0-4): заголовок ≤120, pros/cons ≤1000
const TITLE_MAX = 120;
const PROS_CONS_MAX = 1000;

// REV-13: обязательная причина отзыва (выпадающее меню формы).
// worked_there — «я работал(а) там», was_client — «я был(а) клиентом»,
// project_together — «мы работали над одним проектом»,
// discussion_participant — «мы участвовали в обсуждении темы/проекта»,
// other — «другое» (требует пояснения в authorRelationNote).
export const AUTHOR_RELATIONS = ['worked_there', 'was_client', 'project_together', 'discussion_participant', 'other'] as const;
type AuthorRelation = (typeof AUTHOR_RELATIONS)[number];

const AUTHOR_RELATION_NOTE_MAX = 300;

// REV-13: представитель компании = User.companyId (аккаунт компании)
// ИЛИ строка Employee (сотрудник). Только он видит authorRelation.
async function isCompanyRepresentative(userId: string, companyId: string): Promise<boolean> {
  const [accountLinked, employment] = await Promise.all([
    db.user.findFirst({ where: { id: userId, companyId }, select: { id: true } }),
    db.employee.findFirst({ where: { companyId, userId }, select: { id: true } }),
  ]);
  return !!(accountLinked || employment);
}

// Список отзывов (с пагинацией). REV-13: authorRelation отдаётся ТОЛЬКО
// представителям компании; скрытые (hiddenAt) — тоже только им, с флагом hidden.
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 20), 100);
  const offset = Math.max(Number(req.nextUrl.searchParams.get('offset') ?? 0), 0);

  const isRep = await isCompanyRepresentative(user.id, id);

  const reviews = await db.companyReview.findMany({
    where: { companyId: id, ...(isRep ? {} : { hiddenAt: null }) },
    take: limit,
    skip: offset,
    orderBy: [{ createdAt: 'desc' }],
    include: {
      author: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true } },
    },
  });

  return json({
    viewerIsCompanyRep: isRep,
    reviews: reviews.map((r) => ({
      id: r.id,
      rating: r.rating,
      title: r.title,
      pros: r.pros,
      cons: r.cons,
      verifiedEmployee: r.verifiedEmployee,
      // W1-2 (аддитивно): тип доказательства для бейджа UI
      evidenceType: r.evidenceType,
      createdAt: r.createdAt.toISOString(),
      author: r.author,
      // REV-13: приватная часть — ТОЛЬКО представителям компании.
      ...(isRep
        ? {
            authorRelation: r.authorRelation || null,
            authorRelationNote: r.authorRelationNote,
            hidden: !!r.hiddenAt,
          }
        : {}),
    })),
  });
}

// Создать отзыв (гейт: только при подтверждённом взаимодействии — W1-2)
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // W0-4: rate-limit 5 отзывов/час на пользователя (анти-спам)
  const rl = checkUserRateLimit(user.id, 'reviews:create', ...MUTATION_LIMITS.reviewsCreate);
  if (!rl.allowed) return errorJson(`Слишком много отзывов. Повторите через ${rl.retryAfter}с`, 429);

  try {
    const body = await req.json();
    const { rating, title, pros, cons, authorRelation, authorRelationNote } = body ?? {};
    if (!rating || !title) return errorJson('rating и title обязательны', 422);
    if (rating < 1 || rating > 5) return errorJson('rating должен быть 1-5', 422);

    // W0-4: лимиты длин → 422 с объяснением
    if (typeof title !== 'string' || title.trim().length === 0) return errorJson('rating и title обязательны', 422);
    if (title.length > TITLE_MAX) return errorJson(`Максимум ${TITLE_MAX} символов в заголовке`, 422);
    if (pros && String(pros).length > PROS_CONS_MAX) return errorJson(`Максимум ${PROS_CONS_MAX} символов в поле «Плюсы»`, 422);
    if (cons && String(cons).length > PROS_CONS_MAX) return errorJson(`Максимум ${PROS_CONS_MAX} символов в поле «Минусы»`, 422);

    // W1-2: гейт подтверждённого взаимодействия (объясняющий отказ 403) —
    // ДО валидации причины: «нельзя вообще» важнее «неверное поле»
    const eligibility = await checkCompanyReviewEligibility(user.id, id);
    if (!eligibility.eligible) {
      return json(
        {
          error: 'Вы не можете оставить отзыв об этой компании: нет подтверждённого взаимодействия',
          code: 'REVIEW_NOT_ALLOWED',
          reasons: eligibility.reasons,
        },
        403,
      );
    }

    // REV-13: причина отзыва — ОБЯЗАТЕЛЬНОЕ поле (директива владельца).
    if (!authorRelation || !AUTHOR_RELATIONS.includes(authorRelation as AuthorRelation)) {
      return json(
        {
          error: 'Выберите, почему вы оставляете отзыв: работали там, были клиентом, общий проект, обсуждение или другое',
          code: 'AUTHOR_RELATION_REQUIRED',
        },
        422,
      );
    }
    const relationNote = typeof authorRelationNote === 'string' ? authorRelationNote.trim() : null;
    if (relationNote && relationNote.length > AUTHOR_RELATION_NOTE_MAX) {
      return errorJson(`Максимум ${AUTHOR_RELATION_NOTE_MAX} символов в пояснении к причине`, 422);
    }
    // «Другое» без пояснения — не проходит: компания должна понимать суть
    if (authorRelation === 'other' && !relationNote) {
      return json(
        {
          error: 'Опишите подробнее, почему вы оставляете отзыв (пояснение обязательно для «Другое»)',
          code: 'AUTHOR_RELATION_NOTE_REQUIRED',
        },
        422,
      );
    }

    // W0-4: дедуп (первая линия — до create; вторая — перехват P2002 ниже)
    const existing = await db.companyReview.findFirst({
      where: { companyId: id, authorId: user.id },
      select: { id: true },
    });
    if (existing) return errorJson('Вы уже оставляли отзыв об этой компании', 409);

    // W1-2: доказательство пишется вместе с отзывом — самый сильный источник
    // (fallback 'contact' — теоретически недостижим при eligible, страховка)
    const evidenceType = eligibility.strongest ?? 'contact';
    const strongestEvidence =
      eligibility.evidence.find((e) => e.type === evidenceType) ?? eligibility.evidence[0];
    const evidenceRef = strongestEvidence ? JSON.stringify(strongestEvidence.ref) : null;

    // verifiedEmployee: автор — сотрудник (наследие старого контракта поля)
    const verifiedEmployee = eligibility.evidence.some((e) => e.type === 'employee');

    const review = await db.companyReview.create({
      data: {
        companyId: id,
        authorId: user.id,
        rating: Math.round(rating),
        title: title.trim(),
        pros: pros?.trim() || null,
        cons: cons?.trim() || null,
        verifiedEmployee,
        evidenceType,
        evidenceRef,
        // REV-13: причина отзыва — приватное поле, видит только компания
        authorRelation: authorRelation as AuthorRelation,
        authorRelationNote: relationNote || null,
      },
      include: {
        author: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true } },
      },
    });

    return json({
      review: {
        id: review.id,
        rating: review.rating,
        title: review.title,
        pros: review.pros,
        cons: review.cons,
        verifiedEmployee: review.verifiedEmployee,
        evidenceType: review.evidenceType,
        createdAt: review.createdAt.toISOString(),
        author: review.author,
        // автору возвращаем его же причину — чтобы UI мог подтвердить выбор
        authorRelation: review.authorRelation,
      },
    }, 201);
  } catch (e: unknown) {
    // W0-4: гонка дублей → P2002 (unique companyId+authorId) = понятный 409, не 500
    if ((e as { code?: string })?.code === 'P2002') {
      return errorJson('Вы уже оставляли отзыв об этой компании', 409);
    }
    console.error('[review/create] error:', e);
    return errorJson('Ошибка создания отзыва', 500);
  }
}
