// BizON API — /api/expert-invites/[id]/decide (Волна 12 / В8 «Экспертные приглашения»)
//
// POST — решение ЭКСПЕРТА по приглашению (opt-in контракт): accept | decline.
// Guards: приглашение 404, решает только адресат (expertId = me) 403,
// повторное решение 409 ALREADY_DECIDED.
// Решение уведомлением уходит приглашающему (fromUser).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

const decideSchema = z.object({
  action: z.enum(['accept', 'decline']),
});

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const input = decideSchema.parse(ctx.data);

  const invite = await db.expertInvite.findUnique({
    where: { id: ctx.params.id },
    include: { lot: { select: { id: true, title: true } } },
  });
  if (!invite) {
    return NextResponse.json({ error: 'Приглашение не найдено', code: 'NOT_FOUND' }, { status: 404 });
  }
  if (invite.expertId !== ctx.user.id) {
    return NextResponse.json(
      { error: 'Решение по приглашению принимает только приглашённый эксперт', code: 'FORBIDDEN' },
      { status: 403 },
    );
  }
  if (invite.status !== 'pending') {
    return NextResponse.json(
      { error: 'По этому приглашению уже есть решение', code: 'ALREADY_DECIDED' },
      { status: 409 },
    );
  }

  const updated = await db.expertInvite.update({
    where: { id: invite.id },
    data: {
      status: input.action === 'accept' ? 'accepted' : 'declined',
      decidedAt: new Date(),
    },
  });

  // Уведомление приглашающему владельцу задания
  await db.notification
    .create({
      data: {
        userId: invite.fromUserId,
        type: 'expert_invite_decision',
        title: input.action === 'accept' ? 'Эксперт принял приглашение' : 'Эксперт отклонил приглашение',
        content: `${ctx.user.name} · задание «${invite.lot.title}»`,
        link: '/lots',
      },
    })
    .catch(() => undefined);

  return NextResponse.json({ invite: updated });
}, {
  rateLimit: { key: 'expert-invite-decide', limit: 60, windowMs: 60 * 60 * 1000 },
});
