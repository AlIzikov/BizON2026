// BizON API — /api/career-compass/vacancy-count (A14, STUBS-AUDIT-2026-09-10)
//
// Реальный счёт вакансий для области из карьерного компаса:
//   GET /api/career-compass/vacancy-count?skill=Data%20Engineering
//   → { skill, count }
//
// Как считается (детерминировано, без AI):
//   1. Из названия области строится набор терминов: сама строка + отдельные
//      слова (длина ≥ 3) + синонимы из SkillSynonym (оба направления,
//      переиспользуется buildSynonymIndex — тот же слой, что у semantic search
//      и /api/jobs?prof=1).
//   2. Считаются активные вакансии (Job.active=true — тот же фильтр, что в
//      /api/jobs), у которых среди requiredSkills есть совпадение с термином:
//      точное равенство ИЛИ вхождение подстроки в обе стороны (для терминов
//      длиной ≥ 4 — защита от ложных срабатываний коротких слов).
//
// Auth: обязательна (withRoute). N=0 — честный ответ, UI скрывает чип.
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/api-helpers';
import { buildSynonymIndex } from '@/lib/services/build-talent-service';
import { parseRequiredSkillsWithLevels } from '@/lib/services/job-growth-service';

export const runtime = 'nodejs';

const querySchema = z.object({
  skill: z.string().trim().min(2).max(100),
});

/** Минимальная длина слова/термина для substring-матча (анти-ложные срабатывания). */
const SUBSTRING_MIN_LEN = 4;

/** Разбивает строку на слова (буквы/цифры), нижний регистр, без коротких и пустых. */
function tokenize(s: string): string[] {
  return s
    .toLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .map((w) => w.trim())
    .filter((w) => w.length >= 3);
}

export const GET = withRoute(
  async (_req, ctx) => {
    const { skill } = ctx.data as { skill: string };

    // 1. Термины: полная строка + отдельные слова
    const normalized = skill.toLowerCase().replace(/\s+/g, ' ').trim();
    const terms = new Set<string>([normalized]);
    for (const w of tokenize(skill)) terms.add(w);

    // 2. Расширяем синонимами из SkillSynonym (оба направления)
    const synonymIndex = await buildSynonymIndex();
    for (const t of [...terms]) {
      const syns = synonymIndex.get(t);
      if (syns) for (const s of syns) terms.add(s.toLowerCase().trim());
    }

    // 3. Активные вакансии (тот же фильтр, что в /api/jobs)
    const jobs = await db.job.findMany({
      where: { active: true },
      select: { requiredSkills: true },
      take: 200,
    });

    // 4. Считаем совпадения по requiredSkills
    let count = 0;
    const termList = [...terms];
    for (const j of jobs) {
      const requiredLower = parseRequiredSkillsWithLevels(j.requiredSkills)
        .map((r) => r.name.toLowerCase().trim())
        .filter(Boolean);
      const matched = requiredLower.some((r) => {
        if (terms.has(r)) return true; // точное совпадение
        return termList.some((t) => {
          if (t.length < SUBSTRING_MIN_LEN) return false;
          return r.includes(t) || (r.length >= SUBSTRING_MIN_LEN && t.includes(r));
        });
      });
      if (matched) count += 1;
    }

    return Response.json({ skill: skill.trim(), count });
  },
  {
    schema: querySchema,
    rateLimit: { key: 'compass-vacancy-count', limit: 60, windowMs: 60_000 },
  },
);
