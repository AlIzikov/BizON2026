// BizON API — POST /api/cron/insights (Task 9-a, B14 — doc_agents стр. 34/37:
// «Алгоритм генерации гипотез — Cron-задача, запускаемая раз в сутки»).
//
// Суточная генерация CoachInsight (гипотез «Помогите нам понять вас лучше»)
// для АКТИВНЫХ пользователей: до этого инсайты появлялись только on-demand
// (POST /api/me/coach/discover из UI) — пользователь без заходов в профиль
// гипотез не получал.
//
// Аутентификация: заголовок x-cron-secret === process.env.BIZON_CRON_SECRET.
// Если секрет не настроен на сервере — 503 (fail-closed, «честная» недоступность);
// не совпал — 401.
//
// Идемпотентность (повторный запуск в тот же день не дублирует инсайты):
//   - внутри discoverHiddenPotential: дедуп по title за 7 дней, лимит
//     ≤3 новых инсайта/сутки на юзера, карантин 7 дней после 2 dismiss подряд;
//   - здесь дополнительно: юзер, которому сегодня уже создан CoachInsight,
//     пропускается по дешёвому критерию — наличие CoachInsight юзера
//     с createdAt >= начала UTC-суток.
//
// Лимиты как в discover: max 3/сутки на юзера (внутри сервиса), только активные
// юзеры (сессия за CRON_ACTIVE_DAYS дней), ограничение по числу юзеров за прогон.
//
// Запуск (см. scripts/cron-insights.js):
//   BIZON_CRON_SECRET=... node scripts/cron-insights.js
//   crontab: 10 5 * * *  cd /home/z/my-project && BIZON_CRON_SECRET=... /usr/bin/node scripts/cron-insights.js >> /var/log/bizon-cron.log 2>&1
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson } from '@/lib/api-helpers';
import { CoachService } from '@/lib/services/coach-service';

export const runtime = 'nodejs';

/** «Активный пользователь» — сессия за последние N дней (Session.createdAt) */
const ACTIVE_DAYS = 30;
/** Максимум пользователей за один прогон (защита от таймаута на больших БД) */
const MAX_USERS_PER_RUN = 500;

interface CronInsightsBody {
  /** Переопределить окно активности (дней), 1..365 — опционально */
  activeDays?: unknown;
}

export async function POST(req: NextRequest) {
  const secret = process.env.BIZON_CRON_SECRET;
  if (!secret) {
    return errorJson('BIZON_CRON_SECRET не настроен на сервере — cron-эндпоинт отключён', 503);
  }
  const provided = req.headers.get('x-cron-secret');
  if (!provided || provided !== secret) {
    return errorJson('Unauthorized', 401);
  }

  const body = (await req.json().catch(() => null)) as CronInsightsBody | null;
  let activeDays = ACTIVE_DAYS;
  if (body && typeof body.activeDays === 'number' && Number.isFinite(body.activeDays)) {
    activeDays = Math.min(365, Math.max(1, Math.floor(body.activeDays)));
  }

  const activeSince = new Date(Date.now() - activeDays * 24 * 60 * 60 * 1000);
  // Начало текущих UTC-суток — для идемпотентности повтора в тот же день
  const startOfToday = new Date();
  startOfToday.setUTCHours(0, 0, 0, 0);

  const users = await db.user.findMany({
    where: { sessions: { some: { createdAt: { gte: activeSince } } } },
    select: { id: true, name: true },
    orderBy: { createdAt: 'asc' },
    take: MAX_USERS_PER_RUN,
  });

  let processed = 0;
  let skipped = 0;
  let created = 0;
  let failed = 0;

  for (const user of users) {
    try {
      // Идемпотентность дня: сегодня этому юзеру уже генерировали инсайты —
      // суточный лимит 3/сутки внутри сервиса всё равно вернёт [] (честно и
      // без лишних запросов пропускаем).
      const alreadyToday = await db.coachInsight.findFirst({
        where: { userId: user.id, createdAt: { gte: startOfToday } },
        select: { id: true },
      });
      if (alreadyToday) {
        skipped += 1;
        continue;
      }

      const insights = await CoachService.discoverHiddenPotential(user.id);
      processed += 1;
      created += insights.length;
    } catch {
      // FAIL-OPEN: ошибка одного пользователя не прерывает прогон
      failed += 1;
    }
  }

  return json({
    ok: true,
    processed,
    skipped,
    created,
    failed,
    activeDays,
    maxUsersPerRun: MAX_USERS_PER_RUN,
    at: new Date().toISOString(),
  });
}
