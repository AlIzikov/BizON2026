// BizON API — POST /api/cron/weekly-resonance-digest (R5-A2: недельный дайджест).
//
// Раз в ISO-неделю: юзеры со свежими ResonanceMatch score ≥ 70 (за 7 дней)
// получают ОДНО письмо с топ-5 вакансиями (max score, уникальные jobId,
// title/company) + in-app запись weekly_digest. Юзеру без матчей — письмо
// НЕ отправляется (честно: нет повода — нет письма), в ответе sent учитывается
// только реально отправленное.
//
// Аутентификация: x-cron-secret === process.env.BIZON_CRON_SECRET (образец —
// cron/insights): не настроен → 503 fail-closed; не совпал → 401. НЕ withRoute.
//
// Идемпотентность недели: tryAcquireRun('weekly-resonance-digest', 'weekly') —
// ключ cron:run:weekly-resonance-digest:YYYY-Www (ISO-неделя) в runtimeKV;
// второй рубеж — in-app запись weekly_digest с metadata.weekKey (БД помнит
// даже после рестарта процесса). Повторный прогон → честный skip.
//
// Consent: email уходит только при emailNotificationsEnabled=true и валидном
// расшифрованном User.emailEncrypted (tryDecrypt) — как в re-engagement cron.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson } from '@/lib/api-helpers';
import { tryDecrypt } from '@/lib/security/crypto';
import { sendEmail } from '@/lib/services/email-service';
import { NotificationService } from '@/lib/services/notification-service';
import { tryAcquireRun, isoWeekKeyOf } from '@/lib/services/cron-run-guard';

export const runtime = 'nodejs';

/** Порог дайджеста — тот же канон, что у проактивного матча (R5-A2). */
const DIGEST_SCORE_MIN = 70;
/** Топ вакансий в письме. */
const TOP_JOBS = 5;
/** Максимум юзеров за прогон (как в insights). */
const MAX_USERS_PER_RUN = 500;

const appUrl = () => process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

function escapeHtml(s: string): string {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/** Простой локальный HTML (без шаблонов email-service — они не публичный API). */
function digestEmailHtml(name: string, jobs: Array<{ title: string; company: string; score: number }>): string {
  const link = `${appUrl()}/?view=jobs`;
  const items = jobs
    .map(
      (j) =>
        `<li>${escapeHtml(j.company ? `${j.company} — ` : '')}${escapeHtml(j.title)} — резонанс ${Math.round(j.score)}%</li>`,
    )
    .join('');
  return [
    '<!doctype html><html lang="ru"><body style="font-family:sans-serif;color:#0f172a;">',
    `<p>${escapeHtml(name)}, ваша недельная сводка резонанса.</p>`,
    `<p>Топ-${jobs.length} вакансий с самым высоким резонансом за неделю:</p>`,
    `<ol>${items}</ol>`,
    `<p><a href="${link}">Открыть вакансии на BizON</a></p>`,
    '</body></html>',
  ].join('');
}

export async function POST(req: NextRequest) {
  const secret = process.env.BIZON_CRON_SECRET;
  if (!secret) {
    return errorJson('BIZON_CRON_SECRET не настроен на сервере — cron-эндпоинт отключён', 503);
  }
  const provided = req.headers.get('x-cron-secret');
  if (!provided || provided !== secret) {
    return errorJson('Unauthorized', 401);
  }

  const weekKey = isoWeekKeyOf();

  // Идемпотентность недели: один прогон на ISO-неделю
  if (!tryAcquireRun('weekly-resonance-digest', 'weekly')) {
    return json({
      ok: true,
      skipped: true,
      reason: 'already_ran_this_week',
      week: weekKey,
      checked: 0,
      sent: 0,
      at: new Date().toISOString(),
    });
  }

  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const matches = await db.resonanceMatch.findMany({
    where: { createdAt: { gte: since }, score: { gte: DIGEST_SCORE_MIN } },
    select: {
      userId: true,
      jobId: true,
      score: true,
      job: { select: { title: true, company: true } },
    },
    orderBy: { score: 'desc' },
    take: 5000, // сырьё для группировки; на юзера ниже свой потолок
  });

  // Группировка по юзеру, уникальные jobId, max score на вакансию
  const byUser = new Map<string, Map<string, { title: string; company: string; score: number }>>();
  for (const m of matches) {
    let jobs = byUser.get(m.userId);
    if (!jobs) {
      jobs = new Map();
      byUser.set(m.userId, jobs);
    }
    const prev = jobs.get(m.jobId);
    if (!prev || m.score > prev.score) {
      jobs.set(m.jobId, { title: m.job.title, company: m.job.company, score: m.score });
    }
  }

  const userIds = [...byUser.keys()].slice(0, MAX_USERS_PER_RUN);
  let checked = 0;
  let sent = 0;
  let failed = 0;

  for (const userId of userIds) {
    try {
      checked += 1;
      const jobsMap = byUser.get(userId)!;
      const topJobs = [...jobsMap.entries()]
        .map(([jobId, j]) => ({ jobId, ...j }))
        .sort((a, b) => b.score - a.score)
        .slice(0, TOP_JOBS);
      if (topJobs.length === 0) continue; // без матчей письмо не выдумываем

      const user = await db.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          name: true,
          emailEncrypted: true,
          emailNotificationsEnabled: true,
          deletedAt: true,
        },
      });
      if (!user || user.deletedAt) continue;

      // Второй рубеж идемпотентности: in-app запись этой недели уже есть — skip
      const already = await db.notification.findFirst({
        where: {
          userId,
          type: 'weekly_digest',
          metadata: { contains: weekKey },
        },
        select: { id: true },
      });
      if (already) continue;

      // In-app запись (частотный гейт 'off' уважается NotificationService)
      await NotificationService.notify(userId, {
        type: 'weekly_digest',
        title: `Ваш недельный резонанс: ${topJobs.length} совпадений`,
        body: topJobs
          .map((j) => `${j.company ? `${j.company} — ` : ''}${j.title} (${Math.round(j.score)}%)`)
          .join('; '),
        link: '/?view=jobs',
        metadata: { weekKey, matchCount: jobsMap.size },
      });

      // Email — только при согласии и валидном расшифрованном адресе
      const email = user.emailEncrypted
        ? user.emailNotificationsEnabled
          ? tryDecrypt(user.emailEncrypted) || ''
          : ''
        : '';
      if (email.includes('@') && topJobs.length > 0) {
        const res = await sendEmail({
          to: email,
          subject: `BizON: топ-${topJobs.length} вакансий по вашему резонансу на этой неделе`,
          html: digestEmailHtml(user.name, topJobs),
          text: `${user.name}, топ-${topJobs.length} вакансий с резонансом ≥ ${DIGEST_SCORE_MIN}%: ${topJobs
            .map((j) => `${j.company ? `${j.company} — ` : ''}${j.title} (${Math.round(j.score)}%)`)
            .join('; ')}. Открыть: ${appUrl()}/?view=jobs`,
        });
        if (res.ok) sent += 1;
        else failed += 1;
      }
      // else: email не отправлен (нет согласия/адреса) — in-app запись уже есть,
      // «sent» честно не увеличиваем.
    } catch {
      // FAIL-OPEN: ошибка одного юзера не прерывает прогон
      failed += 1;
    }
  }

  return json({
    ok: true,
    week: weekKey,
    checked,
    sent,
    failed,
    scoreMin: DIGEST_SCORE_MIN,
    topJobs: TOP_JOBS,
    maxUsersPerRun: MAX_USERS_PER_RUN,
    at: new Date().toISOString(),
  });
}
