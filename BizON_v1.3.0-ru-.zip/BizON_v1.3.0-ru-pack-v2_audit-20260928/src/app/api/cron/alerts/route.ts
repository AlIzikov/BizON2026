// BizON API — R5-B6: POST /api/cron/alerts — периодическая оценка алертов.
//
// Аутентификация: заголовок x-cron-secret === process.env.BIZON_CRON_SECRET
// (образец /api/cron/insights): секрет не настроен на сервере → 503
// (fail-closed, «честная» недоступность); не совпал → 401.
//
// Вызывает evaluateAndAlert() (src/lib/observability/alerts.ts):
// snapshot() → errorRate > 5% ИЛИ p95 > 2000ms → Slack (cooldown 15 минут).
// Ответ: { evaluated, breached, alerted, reason? }.
//
// Запуск (crontab.bizon):
//   */5 * * * *  cd /home/z/my-project && BIZON_CRON_SECRET=... node -e \
//     "fetch('http://localhost:3000/api/cron/alerts',{method:'POST',headers:{'x-cron-secret':process.env.BIZON_CRON_SECRET}})"
import { NextRequest } from 'next/server';
import { json, errorJson } from '@/lib/api-helpers';
import { evaluateAndAlert } from '@/lib/observability/alerts';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const secret = process.env.BIZON_CRON_SECRET;
  if (!secret) {
    return errorJson('BIZON_CRON_SECRET не настроен на сервере — cron-эндпоинт отключён', 503);
  }
  const provided = req.headers.get('x-cron-secret');
  if (!provided || provided !== secret) {
    return errorJson('Unauthorized', 401);
  }

  const evaluation = await evaluateAndAlert();
  return json(evaluation);
}
