// BizON API — П4 Фаза 2.2: POST /api/cron/receipt-retry — обработка очереди
// фискализации 54-ФЗ (Receipt, receipt-хаб ADR-007).
//
// Аутентификация: x-cron-secret === process.env.BIZON_CRON_SECRET (образец
// /api/cron/alerts): секрет не настроен → 503 fail-closed; не совпал → 401.
//
// Честность: активный порт console-receipt (stub) очередь НЕ обрабатывает —
// ответ честно skipped:'STUB_ACTIVE' без имитации фискализации; ok:false
// кассы → экспоненциальный backoff, потолок MAX_ATTEMPTS → terminal failed.
//
// Запуск (crontab.bizon, рядом с /api/cron/alerts):
//   * * * * *  BIZON_CRON_SECRET=... node -e \
//     "fetch('http://localhost:3000/api/cron/receipt-retry',{method:'POST',headers:{'x-cron-secret':process.env.BIZON_CRON_SECRET}})"
import { NextRequest } from 'next/server';
import { json, errorJson } from '@/lib/api-helpers';
import { processReceiptQueue } from '@/lib/hubs/receipt/queue';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const secret = process.env.BIZON_CRON_SECRET;
  if (!secret) {
    return errorJson('BIZON_CRON_SECRET не настроен на сервере — cron-эндпоинт отключён', 503);
  }
  const provided = req.headers.get('x-cron-secret');
  if (!provided || provided !== secret) {
    return errorJson('Unauthorized', 401);
  }
  const result = await processReceiptQueue();
  return json(result);
}
