// BizON API — POST /api/cron/proactive-match (R5-A2: проактивный матч).
//
// Суточный cron: свежие ResonanceMatch (createdAt ≥ вчера, score ≥ 70) с ещё
// НЕ отправленным уведомлением match_created → кандидату: «Новый матч:
// резонанс {score}% с {company|job.title}» + ссылка на вакансию.
//
// Аутентификация: заголовок x-cron-secret === process.env.BIZON_CRON_SECRET
// (образец — cron/insights). Секрет не настроен на сервере → 503 (fail-closed,
// «честная» недоступность); не совпал → 401. НЕ withRoute — cron-канал свой.
//
// Идемпотентность суток (два рубежа, как в insights — по состоянию БД):
//   1. tryAcquireRun('proactive-match', 'daily') — один прогон в сутки
//      (ключ cron:run:proactive-match:YYYY-MM-DD в runtimeKV, Redis-совместимо);
//   2. дедуп по самому эффекту: уведомление match_created с metadata,
//      содержащей matchId, — повторный прогон не задублирует even после
//      рестарта процесса (KV потерян — БД помнит).
//
// Честность: нет матчей → { matched: 0, notified: 0 } без выдуманных чисел.
// Лимит N=500 за прогон — как в insights (защита от таймаута на больших БД).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson } from '@/lib/api-helpers';
import { NotificationService } from '@/lib/services/notification-service';
import { tryAcquireRun } from '@/lib/services/cron-run-guard';

export const runtime = 'nodejs';

/** Порог «достойного» проактивного матча (канон R5-A2). */
const MATCH_SCORE_MIN = 70;
/** Максимум матчей за один прогон. */
const MAX_MATCHES_PER_RUN = 500;

export async function POST(req: NextRequest) {
  const secret = process.env.BIZON_CRON_SECRET;
  if (!secret) {
    return errorJson('BIZON_CRON_SECRET не настроен на сервере — cron-эндпоинт отключён', 503);
  }
  const provided = req.headers.get('x-cron-secret');
  if (!provided || provided !== secret) {
    return errorJson('Unauthorized', 401);
  }

  // Рубеж 1: один прогон в сутки
  if (!tryAcquireRun('proactive-match', 'daily')) {
    return json({
      ok: true,
      skipped: true,
      reason: 'already_ran_today',
      matched: 0,
      notified: 0,
      at: new Date().toISOString(),
    });
  }

  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const matches = await db.resonanceMatch.findMany({
    where: { createdAt: { gte: since }, score: { gte: MATCH_SCORE_MIN } },
    select: {
      id: true,
      userId: true,
      jobId: true,
      score: true,
      job: { select: { title: true, company: true } },
    },
    orderBy: { score: 'desc' },
    take: MAX_MATCHES_PER_RUN,
  });

  let notified = 0;
  for (const match of matches) {
    try {
      // Рубеж 2: дедуп по эффекту — уведомление с этим matchId уже существует
      const already = await db.notification.findFirst({
        where: {
          userId: match.userId,
          type: 'match_created',
          metadata: { contains: match.id },
        },
        select: { id: true },
      });
      if (already) continue;

      const label = match.job.company || match.job.title;
      const created = await NotificationService.notify(match.userId, {
        type: 'match_created',
        title: `Новый матч: резонанс ${Math.round(match.score)}% с ${label}`,
        body: `Вакансия «${match.job.title}» совпала с вашим профилем на ${Math.round(match.score)}%.`,
        // канон deep-link вакансии (app-shell): /?view=jobs&jobId=<id>
        link: `/?view=jobs&jobId=${encodeURIComponent(match.jobId)}`,
        metadata: { matchId: match.id },
      });
      if (created) notified += 1;
    } catch {
      // FAIL-OPEN: ошибка одного матча не прерывает прогон
    }
  }

  return json({
    ok: true,
    matched: matches.length,
    notified,
    scoreMin: MATCH_SCORE_MIN,
    maxMatchesPerRun: MAX_MATCHES_PER_RUN,
    at: new Date().toISOString(),
  });
}
