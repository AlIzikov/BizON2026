// BizON API — POST /api/cron/hire-feedback (R5-A3: закрытый цикл найма, шаг 2).
//
// Суточный cron: наймы старше 90 дней без обратной связи (HireOutcomeService
// .pendingFeedback). Каждому HR: письмо (sendEmail, локальный простой HTML —
// «Сработал ли резонанс? 3 вопроса») + in-app уведомление; каждому кандидату —
// мягкое in-app напоминание поделиться опытом.
//
// Аутентификация: x-cron-secret === process.env.BIZON_CRON_SECRET (образец —
// cron/insights): не настроен → 503 fail-closed; не совпал → 401. НЕ withRoute.
//
// Идемпотентность суток: tryAcquireRun('hire-feedback', 'daily') — один прогон
// в сутки; повторный вызов → честный skip (никаких дублированных писем).
//
// Email: расшифровка email HR — decrypt из '@/lib/security/crypto' над
// User.emailEncrypted (tryDecrypt — legacy/чужой ключ → null → честный skip,
// письмо не выдумывается). Consent: email уходит только при
// emailNotificationsEnabled=true (как в scripts/cron-email-reengagement.js).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson } from '@/lib/api-helpers';
import { tryDecrypt } from '@/lib/security/crypto';
import { sendEmail } from '@/lib/services/email-service';
import { NotificationService } from '@/lib/services/notification-service';
import { HireOutcomeService } from '@/lib/services/hire-outcome-service';
import { tryAcquireRun } from '@/lib/services/cron-run-guard';

export const runtime = 'nodejs';

const FEEDBACK_LIMIT = 500;

const appUrl = () => process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

function escapeHtml(s: string): string {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/** Простой локальный HTML (без шаблонов email-service — они не публичный API). */
function feedbackEmailHtml(hrName: string, jobTitle: string, jobId: string): string {
  const link = `${appUrl()}/?view=jobs&jobId=${encodeURIComponent(jobId)}`;
  return [
    '<!doctype html><html lang="ru"><body style="font-family:sans-serif;color:#0f172a;">',
    `<p>${escapeHtml(hrName)}, сработал ли резонанс?</p>`,
    `<p>Кандидат работает в «${escapeHtml(jobTitle)}» уже 90 дней. Ответьте на 3 вопроса,`,
    ' чтобы платформа научилась предсказывать успешные наймы:</p>',
    '<ol>',
    '<li>Кандидат всё ещё работает у вас?</li>',
    '<li>Оцените найм от 1 до 5.</li>',
    '<li>Что сработало (или не сработало)?</li>',
    '</ol>',
    `<p><a href="${link}">Сообщить исход на BizON</a></p>`,
    '<p style="color:#64748b;font-size:12px;">Ответ передаётся в HR-кабинете: вакансия → отклики (статус «Принят»).</p>',
    '</body></html>',
  ].join('');
}

export async function POST(req: NextRequest) {
  const secret = process.env.BIZON_CRON_SECRET;
  if (!secret) {
    return errorJson('BIZON_CRON_SECRET не настроен на сервере — cron-эндпоинт отключён', 503);
  }
  const provided = req.headers.get('x-cron-secret');
  if (!provided || provided !== secret) {
    return errorJson('Unauthorized', 401);
  }

  // Идемпотентность суток: повторный прогон не дублирует письма/уведомления
  if (!tryAcquireRun('hire-feedback', 'daily')) {
    return json({
      ok: true,
      skipped: true,
      reason: 'already_ran_today',
      checked: 0,
      emailed: 0,
      notified: 0,
      at: new Date().toISOString(),
    });
  }

  const pending = await HireOutcomeService.pendingFeedback(FEEDBACK_LIMIT);
  let emailed = 0;
  let notified = 0;

  for (const application of pending) {
    try {
      const hrId = application.job.hiringManagerId;
      let hr: { id: string; name: string; email: string } | null = null;
      if (hrId) {
        const hrUser = await db.user.findUnique({
          where: { id: hrId },
          select: { id: true, name: true, emailEncrypted: true, emailNotificationsEnabled: true },
        });
        if (hrUser) {
          hr = {
            id: hrUser.id,
            name: hrUser.name,
            email: hrUser.emailEncrypted ? tryDecrypt(hrUser.emailEncrypted) || '' : '',
          };
          if (!hrUser.emailNotificationsEnabled) hr.email = '';
        }
      }

      // 1) HR: письмо (3 вопроса) — только при согласии и валидном расшифрованном адресе
      if (hr && hr.email.includes('@')) {
        const res = await sendEmail({
          to: hr.email,
          subject: `BizON: сработал ли резонанс? Кандидат в «${application.job.title}» — 90 дней`,
          html: feedbackEmailHtml(hr.name, application.job.title, application.job.id),
          text: `${hr.name}, кандидат работает в «${application.job.title}» уже 90 дней. 3 вопроса: остался ли кандидат, оценка 1–5, что сработало. Ответить: ${appUrl()}/?view=jobs&jobId=${application.job.id}`,
        });
        if (res.ok) emailed += 1;
      }

      // 2) HR: in-app уведомление
      if (hr) {
        const created = await NotificationService.notify(hr.id, {
          type: 'application_status',
          title: `Сработал ли резонанс? Расскажите об исходе найма в «${application.job.title}»`,
          body: '90 дней после найма: остался ли кандидат, оценка 1–5, что сработало.',
          link: `/?view=jobs&jobId=${encodeURIComponent(application.job.id)}`,
          metadata: { applicationId: application.id, kind: 'hire_feedback_request' },
        });
        if (created) notified += 1;
      }

      // 3) Кандидат: мягкое напоминание (in-app)
      const reminded = await NotificationService.notify(application.user.id, {
        type: 'application_status',
        title: `Как всё прошло в «${application.job.title}»? Поделитесь опытом`,
        body: 'Вы работаете здесь уже 90 дней. Ваш отзыв поможет другим кандидатам.',
        link: '/applications',
        metadata: { applicationId: application.id, kind: 'hire_feedback_reminder' },
      });
      if (reminded) notified += 1;
    } catch {
      // FAIL-OPEN: ошибка одного отклика не прерывает прогон
    }
  }

  return json({
    ok: true,
    checked: pending.length,
    emailed,
    notified,
    limit: FEEDBACK_LIMIT,
    at: new Date().toISOString(),
  });
}
