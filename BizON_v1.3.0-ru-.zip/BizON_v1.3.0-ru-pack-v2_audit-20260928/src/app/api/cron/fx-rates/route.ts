// BizON API — П4 Фаза 2.3: POST /api/cron/fx-rates — синхронизация курсов
// ЦБ РФ (ExchangeRate, pricing-service) раз в 24 часа.
//
// Аутентификация: x-cron-secret === process.env.BIZON_CRON_SECRET (образец
// /api/cron/alerts): секрет не настроен → 503 fail-closed; не совпал → 401.
//
// Честность: курс берётся ТОЛЬКО из ответа ЦБ РФ (daily_json.js); недоступен
// → ok:false с reason, снапшот в БД не трогается (никаких выдуманных
// курсов); отображение при этом fail-open на последний свежий снапшот.
// ЦБ РФ — публичный API без секретов → вне реестра портов (канон 42 пунктов
// манифеста сохранён; решение зафиксировано в отчёте Фазы 2).
import { NextRequest } from 'next/server';
import { json, errorJson } from '@/lib/api-helpers';
import { syncCbrRates } from '@/lib/services/pricing-service';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const secret = process.env.BIZON_CRON_SECRET;
  if (!secret) {
    return errorJson('BIZON_CRON_SECRET не настроен на сервере — cron-эндпоинт отключён', 503);
  }
  const provided = req.headers.get('x-cron-secret');
  if (!provided || provided !== secret) {
    return errorJson('Unauthorized', 401);
  }
  const result = await syncCbrRates();
  // ok:false — это честный факт недоступности ЦБ (не 5xx: cron-скрипт
  // журналирует и повторит на следующем запуске; снапшот в БД не тронут).
  return json(result);
}
