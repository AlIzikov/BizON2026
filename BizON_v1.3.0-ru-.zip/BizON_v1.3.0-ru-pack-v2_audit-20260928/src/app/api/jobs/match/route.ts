// BizON API — /api/jobs/match
// AI-подбор вакансий: top-3 по matchConfidence + LLM-симмаризация
// H12: rate limit по тарифу + кэш на 1 час (LLM-генерация дорогая)
//
// === OWNER-UX-PLAN W4-3a (шаг 16 из 24): аддитивная ветка GET ?resumeId= ===
// Скоринг АКТИВНЫХ вакансий под КОНТЕНТ выбранного резюме (без LLM, без кэша):
//   • навыки извлекаются из content резюме — ФАКТИЧЕСКИЕ форматы в БД:
//       1) блоковый: { blocks: [{ kind:'skill', skill, ... }, ...] } (блоковый редактор);
//       2) секционный генератора /api/cv/generate: { topSkills: string[],
//          skills: [{ name, ... }], ... };
//   • score 0..1 (задокументированная формула — развитие базовой эвристики
//     computeJobMatch (ai.ts: skillMatch = overlap/required) и /api/me/discover
//     (match = overlap/req.length) — их skill-ядро переиспользовано):
//         skillScore = matchedSkills.length / requiredSkills.length (required пуст → 0)
//         +0.15 title-hit  — любой навык резюме входит в title вакансии (case-insensitive)
//         +0.05 desc-hit   — любой навык резюме входит в description (case-insensitive)
//         score = min(1, skillScore + titleHit + descHit)
//   • вакансии со score = 0 не возвращаются; сортировка по score desc, кап 20;
//   • 404 — чужое/несуществующее резюме; 422 — «В резюме не найдено навыков».
//
// NOTE (SavedFilter-контракт «монитор под резюме», W4-3): SavedFilter.params —
// JSON-строка; resumeId кладётся ВНУТРЬ params (миграция схемы не нужна):
//   params = JSON.stringify({ mode:'quick', q:'<навыки CSV>', resumeId })
// Готовый UI сохранения фильтров (SavedFiltersPanel) персистит
// jobsCurrentSearchParams как есть; передача resumeId через applyJobsFilter
// (см. resumes-panel.tsx) документирует контракт для будущего монитора.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson, toUserPublic } from '@/lib/api-helpers';
import { computeJobMatch, generateJobMatchSummary } from '@/lib/ai';
import { checkUserRateLimit, getAiLimitKey } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

// H12: In-memory кэш на 1 час — key=userId, value={ data, expiresAt }
// LLM-генерация дорогая, результат не меняется часто
const CACHE_TTL = 60 * 60 * 1000; // 1 час
const cache = new Map<string, { data: any; expiresAt: number }>();

// Очистка кэша каждые 10 минут
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of cache) {
    if (entry.expiresAt < now) cache.delete(key);
  }
}, 10 * 60 * 1000);

// === W4-3a: извлечение нормализованного набора навыков из content резюме ===
export function extractResumeSkills(content: string): string[] {
  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    return [];
  }
  if (!parsed || typeof parsed !== 'object') return [];
  const obj = parsed as Record<string, unknown>;
  const out = new Set<string>();

  // 1) Блоковый формат: kind='skill' → block.skill
  if (Array.isArray(obj.blocks)) {
    for (const b of obj.blocks) {
      if (b && typeof b === 'object' && (b as Record<string, unknown>).kind === 'skill') {
        const s = (b as Record<string, unknown>).skill;
        if (typeof s === 'string' && s.trim()) out.add(s.trim());
      }
    }
  }

  // 2) Секционный формат генератора: topSkills[] + skills[].name
  if (Array.isArray(obj.topSkills)) {
    for (const s of obj.topSkills) {
      if (typeof s === 'string' && s.trim()) out.add(s.trim());
    }
  }
  if (Array.isArray(obj.skills)) {
    for (const s of obj.skills) {
      const name = (s as Record<string, unknown> | null)?.name;
      if (typeof name === 'string' && name.trim()) out.add(name.trim());
    }
  }

  return Array.from(out);
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const url = new URL(req.url);
  const resumeId = url.searchParams.get('resumeId')?.trim() ?? '';

  // ======================================================================
  // W4-3a: скоринг вакансий под КОНТЕНТ резюме (?resumeId=)
  // ======================================================================
  if (resumeId) {
    // Отдельный лимит: дешёвый запрос без LLM (ai:jobsMatch — лимит LLM-ветки, не трогаем)
    const rl = checkUserRateLimit(user.id, 'resumes:jobs-match', 60, 60 * 60 * 1000);
    if (!rl.allowed) {
      return errorJson(
        `Слишком много запросов подбора. Повторите через ${rl.retryAfter} секунд.`,
        429
      );
    }

    const resume = await db.resume.findUnique({ where: { id: resumeId } });
    if (!resume || resume.userId !== user.id) {
      return errorJson('Резюме не найдено', 404);
    }

    const skills = extractResumeSkills(resume.content);
    if (skills.length === 0) {
      return errorJson('В резюме не найдено навыков', 422);
    }

    const skillsLower = skills.map((s) => s.toLowerCase());
    const jobs = await db.job.findMany({ where: { active: true }, take: 200 });

    const matches = jobs
      .map((j) => {
        const required = j.requiredSkills
          ? j.requiredSkills.split(',').map((s) => s.trim()).filter(Boolean)
          : [];
        const requiredLower = required.map((s) => s.toLowerCase());
        // Переиспользованное skill-ядро computeJobMatch (/api/me/discover):
        const matchedSkills = required.filter((s) => skillsLower.includes(s.toLowerCase()));
        const missingSkills = required.filter((s) => !skillsLower.includes(s.toLowerCase()));

        const skillScore = required.length > 0 ? matchedSkills.length / required.length : 0;
        const titleLower = j.title.toLowerCase();
        const descLower = (j.description ?? '').toLowerCase();
        const titleHit = skillsLower.some((s) => titleLower.includes(s));
        const descHit = skillsLower.some((s) => descLower.includes(s));
        const score = Math.min(1, skillScore + (titleHit ? 0.15 : 0) + (descHit ? 0.05 : 0));

        return {
          jobId: j.id,
          title: j.title,
          company: j.company,
          salaryMin: j.salaryMin,
          salaryMax: j.salaryMax,
          currency: j.currency,
          location: j.location,
          score: Number(score.toFixed(3)),
          matchedSkills,
          missingSkills,
        };
      })
      .filter((m) => m.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 20);

    return json({ matches });
  }

  // ======================================================================
  // Легаси-ветка: AI-подбор top-3 по навыкам ПРОФИЛЯ (+LLM-суммаризация).
  // Контракт не менялся (ветка resumeId — аддитивна выше).
  // ======================================================================

  // H12: AI rate limit по тарифу — защита от LLM-billing DoS
  const [max, windowMs] = getAiLimitKey('jobsMatch', user.subscriptionTier);
  const rl = checkUserRateLimit(user.id, 'ai:jobsMatch', max, windowMs);
  if (!rl.allowed) {
    return errorJson(
      `Лимит AI-подбора вакансий исчерпан (${max} запросов в час для тарифа ${user.subscriptionTier}). Повторите через ${rl.retryAfter} секунд.`,
      429
    );
  }

  // H12: Проверяем кэш — если есть свежий результат, возвращаем без LLM-вызова
  const cached = cache.get(user.id);
  if (cached && cached.expiresAt > Date.now()) {
    return json({ ...cached.data, cached: true, cachedUntil: new Date(cached.expiresAt).toISOString() });
  }

  const userSkills = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkills.map((us) => us.skill.name);

  const jobs = await db.job.findMany({
    where: { active: true },
    take: 50,
  });

  const ranked = jobs
    .map((j) => {
      const requiredSkills = j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [];
      const match = computeJobMatch(userSkillNames, user.ipScore, {
        requiredSkills,
        growthScore: j.growthScore,
      });
      return {
        id: j.id,
        title: j.title,
        company: j.company,
        description: j.description,
        requiredSkills,
        salaryFrom: j.salaryFrom,
        salaryTo: j.salaryTo,
        location: j.location,
        growthScore: j.growthScore,
        matchConfidence: match,
        createdAt: j.createdAt.toISOString(),
      };
    })
    .sort((a, b) => b.matchConfidence - a.matchConfidence)
    .slice(0, 3);

  // LLM-симмаризация top-3
  const publicUser = await toUserPublic(user);
  const enriched = await Promise.all(
    ranked.map(async (j) => ({
      ...j,
      aiSummary: await generateJobMatchSummary(publicUser, j, j.matchConfidence),
    }))
  );

  const result = { jobs: enriched };

  // H12: Сохраняем в кэш на 1 час
  cache.set(user.id, { data: result, expiresAt: Date.now() + CACHE_TTL });

  return json({ ...result, cached: false });
}
