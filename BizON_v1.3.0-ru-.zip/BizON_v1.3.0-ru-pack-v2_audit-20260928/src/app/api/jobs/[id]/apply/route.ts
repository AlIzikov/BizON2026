// BizON API — /api/jobs/[id]/apply
// FIX-07: withRoute — auth 401, единый маппинг ошибок (Prisma P2002→409, P2025→404),
// без сырых e.message для 5xx.
// OWNER-UX-PLAN W4-2a (шаг 17 из 24): тело запроса больше НЕ игнорируется.
//   Раньше роут не читал body — сопроводительное письмо клиента молча терялось.
//   Теперь читается ctx.data (withRoute парсит body ВСЕГДА для POST, пустое тело
//   → {} — старые клиенты job-passport.tsx с пустым body работают как раньше):
//     { coverLetter?: string ≤5000, resumeId?: string }
//   • coverLetter: >5000 символов → 422 «Сопроводительное письмо: максимум 5000
//     символов» (паттерн Message length-зон); пустая/пробельная → null;
//   • resumeId: резюме должно существовать И принадлежать текущему пользователю
//     → иначе 422 «Выбранное резюме не найдено» (чужое не раскрываем);
//   • coverLetter + resumeId персистятся в create вместе с прежними полями
//     (status/matchConfidence — логика не тронута: computeJobMatch, EventBus,
//     ReputationService.awardBulk, дубль-гейт 400 «Вы уже откликнулись»).
import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { computeJobMatch } from '@/lib/ai';
import { ReputationService } from '@/lib/services';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

// W4-2a: лимит сопроводительного письма (синхронизирован с UI-счётчиком диалога)
const COVER_LETTER_MAX = 5000;

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const { id } = ctx.params;
  const user = ctx.user!;

  const job = await db.job.findUnique({ where: { id } });
  if (!job) return errorJson('Вакансия не найдена', 404);

  const existing = await db.jobApplication.findUnique({
    where: { jobId_userId: { jobId: id, userId: user.id } },
  }).catch(() => null);
  if (existing) return errorJson('Вы уже откликнулись', 400);

  // === W4-2a: тело запроса (withRoute отдаёт распарсенный JSON в ctx.data) ===
  const body = (ctx.data ?? {}) as { coverLetter?: unknown; resumeId?: unknown };

  let coverLetter: string | null = null;
  if (body.coverLetter !== undefined && body.coverLetter !== null) {
    if (typeof body.coverLetter !== 'string') {
      return errorJson('Сопроводительное письмо: максимум 5000 символов', 422);
    }
    const trimmed = body.coverLetter.trim();
    if (trimmed.length > COVER_LETTER_MAX) {
      return errorJson('Сопроводительное письмо: максимум 5000 символов', 422);
    }
    coverLetter = trimmed.length > 0 ? trimmed : null;
  }

  let resumeId: string | null = null;
  if (body.resumeId !== undefined && body.resumeId !== null && body.resumeId !== '') {
    if (typeof body.resumeId !== 'string') {
      return errorJson('Выбранное резюме не найдено', 422);
    }
    const resume = await db.resume.findUnique({
      where: { id: body.resumeId },
      select: { id: true, userId: true },
    });
    // Чужое/несуществующее → 422 «Выбранное резюме не найдено» (по гейту задачи;
    // существование чужого резюме не раскрываем)
    if (!resume || resume.userId !== user.id) {
      return errorJson('Выбранное резюме не найдено', 422);
    }
    resumeId = resume.id;
  }

  const userSkills = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkills.map((us) => us.skill.name);
  const requiredSkills = job.requiredSkills ? job.requiredSkills.split(',').filter(Boolean) : [];
  const match = computeJobMatch(userSkillNames, user.ipScore, {
    requiredSkills,
    growthScore: job.growthScore,
  });

  const app = await db.jobApplication.create({
    data: {
      jobId: id,
      userId: user.id,
      status: 'submitted',
      matchConfidence: match,
      // W4-2a: письмо и резюме больше не теряются (FIX: ранее body игнорировался)
      coverLetter,
      resumeId,
    },
  });

  // Event Bus: отклик отправлен (публикация не должна ломать отклик)
  try {
    void EventBus.publish('job.applied', {
      userId: user.id,
      jobId: job.id,
      jobTitle: job.title,
    }).catch(() => undefined);
  } catch {
    // fail-open: ошибки шины игнорируем
  }

  // FIX-06: reputation event + пересчёт IP-score одной пачкой (awardBulk)
  await ReputationService.awardBulk({
    userIds: [user.id],
    eventType: 'job_matched',
    weight: 2,
    payload: {
      jobId: job.id,
      jobTitle: job.title,
      company: job.company,
      matchConfidence: match,
    },
    impactPayload: { rating: match * 5 },
  });

  return json({ application: app, matchConfidence: match }, 201);
});
