// BizON API — POST /api/analytics/track (R5-P1-REBUILD E3: product analytics).
//
// Серверный продуктовый трекинг. Аудит R5-P1: клиентский track() (Metrica/GA4)
// был dead code без вызовов; единственным продуктовым сигналом была dwell-петля.
//
// Решение (честное, без внешних зависимостей):
//   - события хранятся в ActionEvent (type: 'product:<event>', isPublic: false —
//     НЕ попадает в публичные ленты/профессиональную память);
//   - allowlist событий = AnalyticsEvents (общий модуль с клиентом);
//   - параметры: плоский record строка|число|boolean, ≤20 ключей — структурно
//     не даёт отправить PII-поля (bio/контакты не проходят по типу/длине);
//   - авторизация обязательна: продуктовая аналитика считается по залогиненным
//     сессиям (честная метрика активности);Rate 60/мин.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/with-route';
import { AnalyticsEvents, ANALYTICS_EVENT_LABELS } from '@/lib/analytics';

export const runtime = 'nodejs';

const eventNames = Object.values(AnalyticsEvents) as [string, ...string[]];

const trackSchema = z.object({
  event: z.enum(eventNames),
  params: z
    .record(z.string(), z.union([z.string().max(200), z.number(), z.boolean()]))
    .optional(),
});

export const POST = withRoute(
  async (req, ctx) => {
    const body = trackSchema.parse(ctx.data);
    const params = body.params && Object.keys(body.params).length > 0 ? body.params : undefined;

    // ActionEvent: продуктовые события приватны (isPublic: false)
    await db.actionEvent.create({
      data: {
        userId: ctx.user!.id,
        type: `product:${body.event}`,
        title: ANALYTICS_EVENT_LABELS[body.event] ?? body.event,
        metadata: params ? JSON.stringify(params) : null,
        isPublic: false,
      },
    });

    return NextResponse.json({ ok: true });
  },
  { rateLimit: { key: 'api:analytics:track', limit: 60, windowMs: 60_000 } },
);
