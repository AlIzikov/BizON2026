// BizON API — GET /api/c/[token]
// Phase 10: Company Passport — публичный endpoint (без auth).
//
// Возвращает публичную визитку компании по непредсказуемому token:
//   { company, trust (4 индекса + overall), projects[..3], vacancies[..3], culturalSignals }
//
// Принципы приватности:
//   • Без auth — любой со ссылкой может посмотреть
//   • Token — 64 hex символа (32 байта энтропии) — неперебираемый
//   • НЕ отдаём внутренние поля (culturalScore, adTrustIndex internals, contact email/phone)
//   • Если passportEnabled=false → 404 (без раскрытия, что компания существует)
//
// Cache-Control: public, max-age=300 — кэшируется 5 минут (token в URL = приватный).
// (FIX-07/p1-residue): withRoute(auth:false) — поведение 1:1 (анонимный доступ сохранён).

import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { CompanyPassportService } from '@/lib/services/company-passport-service';

export const runtime = 'nodejs';
// Публичный endpoint — кэшируем на 5 мин (token в URL = приватный, но ответ статичен)
export const revalidate = 300;

export const GET = withRoute<{ token: string }>(
  async (req, { params }) => {
    const { token } = params;

    if (!token || typeof token !== 'string' || token.length < 16) {
      return errorJson('Company Passport не найден', 404);
    }

    const passport = await CompanyPassportService.getByToken(token);
    if (!passport) {
      // Та же ошибка что и для невалидного token — не раскрываем существование
      return errorJson('Company Passport не найден', 404);
    }

    return json(passport, 200, {
      headers: {
        'Cache-Control': 'public, max-age=300',
        'X-Content-Type-Options': 'nosniff',
      },
    });
  },
  { auth: false },
);
