// BizON API — PATCH /api/complaints/[id] (R5-P2: report-queue actions).
//
// Гэп-фикс поверх существующей очереди GET /api/complaints (Wave 1 S-019):
// в админ-панели (вкладка «Жалобы») была только очередь без действий —
// модератор не мог закрыть жалобу из UI (в UI была честная пометка об этом).
//
// Действия (директива R5-P2 «бан/предупреждение/игнорировать»):
//   status = resolved | dismissed   — закрытие очереди (обязательно)
//   moderationAction = warn | ban   — ОПЦИОНАЛЬНО, только при targetType='user':
//     warn  — in-app уведомление 'moderation.warning' целевому пользователю;
//     ban   — блокировка пользователя (те же семантики, что админ-блок
//             R5-4b: User.blockedAt + инвалидация ВСЕХ сессий, login отклоняется).
//   dismissed == «игнорировать» (жалоба не подтверждена).
//
// Честность: действие ban по жалобе НЕ выполняется, если цель — не юзер
// (422), т.к. анонимная расправа над контентом по одной жалобе против канона
// «Trust earned». Скрытие контента — путь /api/reports/[reportId] (REV-13).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute, RATE_CLASSES } from '@/lib/api-helpers';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { NotificationService } from '@/lib/services/notification-service';

export const runtime = 'nodejs';

const patchSchema = z.object({
  status: z.enum(['resolved', 'dismissed']),
  moderationAction: z.enum(['none', 'warn', 'ban']).optional().default('none'),
});

export const PATCH = withRoute<{ id: string }>(
  async (_req, ctx) => {
    // Роль admin в CSV-строке User.roles (§6: поля isAdmin у модели нет) —
    // канон существующего GET /api/complaints.
    const roles = (ctx.user.roles ?? '').split(',').map((r) => r.trim());
    if (!roles.includes('admin')) {
      return NextResponse.json({ error: 'Доступ запрещён' }, { status: 403 });
    }

    const { id } = ctx.params;
    const body = patchSchema.parse(ctx.data);

    const complaint = await db.complaint.findUnique({ where: { id } });
    if (!complaint) return NextResponse.json({ error: 'Жалоба не найдена' }, { status: 404 });
    if (complaint.status !== 'open') {
      return NextResponse.json(
        { error: 'Жалоба уже закрыта', code: 'ALREADY_CLOSED' },
        { status: 409 },
      );
    }

    // warn/ban применимы только к пользователю-цели (см. докблок)
    if (body.moderationAction !== 'none' && complaint.targetType !== 'user') {
      return NextResponse.json(
        { error: 'warn/ban применимы только к жалобам на пользователя', code: 'ACTION_REQUIRES_USER_TARGET' },
        { status: 422 },
      );
    }

    let warned = false;
    let banned = false;

    if (body.moderationAction === 'warn' || body.moderationAction === 'ban') {
      const target = await db.user.findUnique({
        where: { id: complaint.targetId },
        select: { id: true, blockedAt: true },
      });
      if (!target) return NextResponse.json({ error: 'Цель жалобы не найдена' }, { status: 404 });

      if (target.blockedAt && body.moderationAction === 'ban') {
        return NextResponse.json({ error: 'Пользователь уже заблокирован', code: 'ALREADY_BLOCKED' }, { status: 409 });
      }

      if (body.moderationAction === 'warn') {
        const created = await NotificationService.notify(target.id, {
          type: 'moderation.warning',
          title: 'Предупреждение от модерации',
          body:
            'На вашу активность поступила жалоба, модерация вынесла предупреждение. ' +
            'Пожалуйста, соблюдайте правила сообщества BizON.',
          link: '/terms',
        });
        warned = !!created;
      }

      if (body.moderationAction === 'ban') {
        // Симметрично admin users PATCH (R5-4b): блок = мгновенная
        // инвалидация ВСЕХ сессий; login отклоняется по blockedAt.
        await db.$transaction([
          db.user.update({ where: { id: target.id }, data: { blockedAt: new Date() } }),
          db.session.deleteMany({ where: { userId: target.id } }),
        ]);
        AuditLog.logSecurity('admin_user_blocked', {
          actorId: ctx.user.id,
          resource: 'User',
          resourceId: target.id,
          metadata: { via: 'complaint', complaintId: complaint.id, category: complaint.category },
        });
        banned = true;
      }
    }

    const updated = await db.complaint.update({
      where: { id: complaint.id },
      data: { status: body.status, resolvedAt: new Date() },
    });

    AuditLog.logSecurity('COMPLAINT_RESOLVED', {
      actorId: ctx.user.id,
      resource: 'Complaint',
      resourceId: complaint.id,
      metadata: {
        status: body.status,
        moderationAction: body.moderationAction,
        warned,
        banned,
        targetType: complaint.targetType,
        category: complaint.category,
      },
    });

    return NextResponse.json({
      complaint: {
        id: updated.id,
        status: updated.status,
        resolvedAt: updated.resolvedAt?.toISOString() ?? null,
      },
      warned,
      banned,
    });
  },
  // Модерационное действие — редкое и осознанное: ADMIN_WRITE-класс (30/мин).
  { rateLimit: { key: 'api:complaints/[id]:PATCH', ...RATE_CLASSES.ADMIN_WRITE } },
);
