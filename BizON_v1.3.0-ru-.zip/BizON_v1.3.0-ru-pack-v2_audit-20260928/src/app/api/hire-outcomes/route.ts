// BizON API — /api/hire-outcomes (R5-A3: закрытый цикл найма).
//
// POST — HR сообщает исход найма (90 дней после 'hired'): остался ли кандидат,
//        оценка 1–5, что сработало. AUTH_STRICT 10/мин: это редкая мутация
//        с необратимым (@unique) следом — защита от флуда и гонок.
// GET   ?applicationId= — исход отклика: кандидат-владелец или HR той же
//        компании / hiring manager; всем остальным — 403 (без утечки фактов найма).
//
// Канон: withRoute + zod + RATE_CLASSES; ошибки сервиса — BizonError
// (422/403/409) маппятся композером сами.
import { z } from 'zod';
import { withRoute, RATE_CLASSES, jsonError } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { HireOutcomeService } from '@/lib/services/hire-outcome-service';

export const runtime = 'nodejs';

const createSchema = z.object({
  applicationId: z.string().min(1),
  hireDate: z
    .string()
    .min(4)
    .max(40)
    .refine((v) => !Number.isNaN(Date.parse(v)), { message: 'hireDate: ожидается ISO-дата' }),
  stillEmployed: z.boolean(),
  rating: z.number().int().min(1).max(5),
  feedback: z.string().max(2000).optional(),
});

const getSchema = z.object({
  applicationId: z.string().min(1),
});

export const POST = withRoute(
  async (req, ctx) => {
    const input = ctx.data as z.infer<typeof createSchema>;
    const outcome = await HireOutcomeService.create(ctx.user.id, {
      applicationId: input.applicationId,
      hireDate: input.hireDate,
      stillEmployed: input.stillEmployed,
      rating: input.rating,
      feedback: input.feedback,
    });
    return Response.json({ ok: true, outcome }, { status: 201 });
  },
  { schema: createSchema, rateLimit: { key: 'hire-outcomes-create', ...RATE_CLASSES.AUTH_STRICT } },
);

export const GET = withRoute(
  async (req, ctx) => {
    const { applicationId } = ctx.data as z.infer<typeof getSchema>;

    const application = await db.jobApplication.findUnique({
      where: { id: applicationId },
      select: {
        userId: true,
        job: { select: { companyId: true, hiringManagerId: true } },
        hireOutcome: true,
      },
    });
    if (!application) return jsonError(404, 'Отклик не найден', 'APPLICATION_NOT_FOUND');

    // Владелец-кандидат или HR той же компании / hiring manager
    const isOwner = application.userId === ctx.user.id;
    const isSameCompanyHr =
      !!ctx.user.companyId &&
      !!application.job.companyId &&
      ctx.user.companyId === application.job.companyId;
    const isHiringManager = application.job.hiringManagerId === ctx.user.id;
    if (!isOwner && !isSameCompanyHr && !isHiringManager) {
      return jsonError(403, 'Доступ запрещён', 'FORBIDDEN');
    }

    return Response.json({ ok: true, outcome: application.hireOutcome });
  },
  { schema: getSchema, rateLimit: { key: 'hire-outcomes-read', ...RATE_CLASSES.USER_READ } },
);
