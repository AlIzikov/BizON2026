// BizON API — /api/email/status
// Этап 8.6 — Email re-engagement: возвращает признак «SMTP настроен на сервере».
//
// Используется в Настройках (settings-view.tsx) для показа warning'а, если
// email-уведомления недоступны на сервере. Не требует авторизации — это
// публичная конфигурационная информация (без раскрытия SMTP-учёток).
import { json, withRoute } from '@/lib/api-helpers';
import { isSmtpConfigured } from '@/lib/services/email-service';

export const runtime = 'nodejs';

export const GET = withRoute(
  async () => {
    return json({
      smtpConfigured: isSmtpConfigured(),
      // emailNotificationsEnabled — это per-user настройка, её клиент берёт из /api/auth/me
    });
  },
  { auth: false }, // публичная конфигурационная информация (без авторизации)
);
