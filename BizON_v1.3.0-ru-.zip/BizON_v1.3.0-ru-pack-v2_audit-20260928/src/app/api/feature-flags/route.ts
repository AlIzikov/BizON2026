// BizON API — GET /api/feature-flags?keys=dashboard.extended_stats,...
// (R5-P2: клиентский снапшот флагов для текущего пользователя.)
//
// Честность: отдаём только запрошенные ключи из белого списка CLIENT_KEYS —
// флаги внутренних экспериментов и будущих фич не раскрываются.
// fail-closed: неизвестный ключ → false.
import { NextResponse } from 'next/server';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { flagSnapshot, FLAG_KEYS } from '@/lib/feature-flags';

export const runtime = 'nodejs';

/** Ключи, разрешённые к выдаче клиенту (белый список, а не dump). */
const CLIENT_KEYS: string[] = Object.values(FLAG_KEYS);

export const GET = withRoute(
  async (req, ctx) => {
    const requested = (new URL(req.url).searchParams.get('keys') ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 20);

    const keys = requested.filter((k) => CLIENT_KEYS.includes(k));
    const flags = await flagSnapshot(keys.length ? keys : CLIENT_KEYS, ctx.user.id);

    return NextResponse.json(
      { flags },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  },
  { rateLimit: { key: 'api:feature-flags:GET', ...RATE_CLASSES.USER_READ } },
);
