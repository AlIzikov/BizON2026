// BizON API — GET /api/feed/thoughts (Wave C, GPT §30 «ONE SCREEN — ONE MAIN THOUGHT»)
//
// Топ-N карточек ленты по ОБЪЯСНИМОМУ детерминированному скору для режима
// «Одна мысль» (one-thought-mode.tsx). Скор считается на сервере (ThoughtScoring
// в feed-service) из уже существующих факторов платформы:
//   доверие автора (ipScore) × отклик читателей (лайки/комментарии) ×
//   свежесть (A2 decay 1/(1+days×0.1)) × совпадение тегов с навыками юзера.
// Никакой рандомизации и LLM — одинаковый вход даёт одинаковый порядок.
//
// ЧЕСТНОСТЬ:
//   - каждый элемент несёт score + why (рус., из тех же факторов) + factors[];
//   - спонсорские карточки и commercial-посты исключены (main thought ≠ ad);
//   - ответ аддитивный: форма FeedItem сохранена, поля score/why/factors
//     добавлены сверху (не ломает существующие потребители FeedItem).
//
// Контракт: GET ?limit=10 (1..20) → { items: ThoughtItem[], total }
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { ThoughtScoring } from '@/lib/services/feed-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rawLimit = Number(req.nextUrl.searchParams.get('limit') ?? 10);
  const limit = Number.isFinite(rawLimit) ? Math.floor(rawLimit) : 10;

  try {
    const result = await ThoughtScoring.getTopThoughts(user.id, { limit });
    return json(result);
  } catch (e) {
    console.error('[api/feed/thoughts] failed:', e);
    return errorJson('Не удалось собрать «Одну мысль» — попробуйте ещё раз', 500);
  }
}
