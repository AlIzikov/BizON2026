// BizON API — П4 Фаза 2.7 (ИТ-аккредитация): /api/admin/revenue.
//
// GET  — сводка доли ИТ-доходов (канон Минцифры: ≥70% за отчётный период)
//        + разбивка по закрытым периодам + последние проводки.
// POST — проводка дохода { type: 'it'|'non_it', amount, vatRate, period,
//        note? }: админ вносит факты по ЗАКРЫТЫМ периодам вручную.
//        Бухгалтерский учёт вне продукта: автоматический перенос из
//        Payments/Cashier был бы имитацией бухгалтерии (честная граница).
//        Исправление — сторно-проводкой (удаление проводок не предусмотрено).
// Доступ: staff-роль admin (requireAdmin). Мутация — AuditLog REVENUE_CREATED.
import { NextResponse } from 'next/server';
import { z } from 'zod';

import { db } from '@/lib/db';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

const createSchema = z.object({
  type: z.enum(['it', 'non_it']),
  amount: z.number().positive().max(1_000_000_000_000),
  vatRate: z.enum(['none', '0', '10', '20']).default('none'),
  period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, 'period в формате YYYY-MM'),
  note: z.string().trim().max(200).optional(),
});

/** Доля ИТ-доходов; total=0 → null (честно: данных нет — не «100%» и не «0%»). */
function itShareOf(it: number, nonIt: number): number | null {
  const total = it + nonIt;
  if (total <= 0) return null;
  return it / total;
}

export const GET = withRoute(
  async (req) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });

    const entries = await db.revenue.findMany({ orderBy: [{ period: 'desc' }, { createdAt: 'desc' }], take: 100 });
    const all = await db.revenue.groupBy({ by: ['type', 'period'], _sum: { amount: true } });

    const itTotal = all.filter((r) => r.type === 'it').reduce((a, r) => a + (r._sum.amount ?? 0), 0);
    const nonItTotal = all.filter((r) => r.type === 'non_it').reduce((a, r) => a + (r._sum.amount ?? 0), 0);
    const byPeriod = [...new Set(all.map((r) => r.period))].sort().reverse().slice(0, 24).map((period) => {
      const it = all.find((r) => r.period === period && r.type === 'it')?._sum.amount ?? 0;
      const nonIt = all.find((r) => r.period === period && r.type === 'non_it')?._sum.amount ?? 0;
      return { period, it, nonIt, total: it + nonIt, itShare: itShareOf(it, nonIt) };
    });

    return NextResponse.json({
      summary: {
        it: itTotal,
        nonIt: nonItTotal,
        total: itTotal + nonItTotal,
        itShare: itShareOf(itTotal, nonItTotal),
        // Порог Минцифры для ИТ-аккредитации: доля ИТ-доходов ≥ 70%
        threshold: 0.7,
        meets: itShareOf(itTotal, nonItTotal) === null ? null : itShareOf(itTotal, nonItTotal)! >= 0.7,
        entriesCount: entries.length,
      },
      periods: byPeriod,
      entries,
    });
  },
  { rateLimit: { key: 'api:admin:revenue:GET', ...RATE_CLASSES.ADMIN_READ } },
);

export const POST = withRoute(
  async (req, ctx) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });

    const data = ctx.data as z.infer<typeof createSchema>;
    const entry = await db.revenue.create({
      data: {
        type: data.type,
        amount: data.amount,
        vatRate: data.vatRate,
        period: data.period,
        ...(data.note ? { note: data.note } : {}),
        createdById: staff.user.id,
      },
    });
    AuditLog.logSecurity('REVENUE_CREATED', {
      actorId: staff.user.id,
      resource: 'Revenue',
      resourceId: entry.id,
      metadata: { type: entry.type, amount: entry.amount, vatRate: entry.vatRate, period: entry.period },
    });
    return NextResponse.json({ ok: true, entry }, { status: 201 });
  },
  { schema: createSchema, rateLimit: { key: 'api:admin:revenue:POST', ...RATE_CLASSES.ADMIN_WRITE } },
);
