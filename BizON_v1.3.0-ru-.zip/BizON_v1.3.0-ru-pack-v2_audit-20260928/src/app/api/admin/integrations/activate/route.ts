// BizON API — POST /api/admin/integrations/activate (П4 Фаза 1, п.1.3).
//
// «Активировать» = переключить активный порт КАТЕГОРИИ на выбранный:
// транзакционно деактивируются остальные порты категории (канон ADR-007:
// ровно 1 активный на категорию). Гейты (честные, до переключения):
//   404 PORT_NOT_FOUND · 422 ALREADY_ACTIVE · 501 ADAPTER_NOT_IMPLEMENTED ·
//   501 ENV_MISSING (список отсутствующих имён, БЕЗ значений).
// Успех — AuditLog 'INTEGRATION_ACTIVATED' (prevCode → code).
// Доступ: staff-роль admin.
import { NextResponse } from 'next/server';
import { z } from 'zod';

import { db } from '@/lib/db';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { isHubCategory } from '@/lib/hubs/core';
import { HUB_REGISTRY } from '@/lib/hubs/registry';

export const runtime = 'nodejs';

const activateSchema = z.object({
  code: z.string().trim().toLowerCase().regex(/^[a-z0-9][a-z0-9-]{1,39}$/),
});

export const POST = withRoute(
  async (req, ctx) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });

    const { code } = ctx.data as z.infer<typeof activateSchema>;
    const port = await db.externalServicePort.findUnique({ where: { code } });
    if (!port) {
      return NextResponse.json({ error: `PORT_NOT_FOUND: порт «${code}» не найден в реестре` }, { status: 404 });
    }
    if (!isHubCategory(port.category)) {
      return NextResponse.json({ error: `UNKNOWN_CATEGORY: категория «${port.category}» вне реестра хабов` }, { status: 422 });
    }
    if (port.isActive) {
      return NextResponse.json({ error: `ALREADY_ACTIVE: порт «${code}» уже активен в категории «${port.category}»` }, { status: 422 });
    }

    // Гейт 1: адаптер реализован (иначе смена провайдера = сломанная категория).
    const entry = HUB_REGISTRY[port.category];
    if (!entry.adapters[port.code]) {
      return NextResponse.json(
        {
          error: `ADAPTER_NOT_IMPLEMENTED: у порта «${code}» нет адаптера в карте хаба — активация заблокирована (подключение = файл в adapters/, ADR-007). Категория осталась на прежнем активном порте.`,
        },
        { status: 501 },
      );
    }

    // Гейт 2: env заданы (факт, без значений).
    const env = entry.requiredEnv(port);
    const missing = env.filter((name) => !process.env[name]?.trim());
    if (missing.length > 0) {
      return NextResponse.json(
        {
          error: `ENV_MISSING: порт «${code}» требует переменные окружения: ${missing.join(', ')}. Категория осталась на прежнем активном порте.`,
        },
        { status: 501 },
      );
    }

    // Гейт 2.5 (Ф2.4, честность database-категории): БД не переключается в
    // runtime — активация yandex-managed-postgres возможна ТОЛЬКО после
    // cutover-протокола ADR-004 (факт: DATABASE_URL уже postgres).
    if (port.category === 'database' && port.code === 'yandex-managed-postgres' && !process.env.DATABASE_URL?.startsWith('postgres')) {
      return NextResponse.json(
        {
          error: `CUTOVER_REQUIRED: активация возможна только после cutover-протокола ADR-004 (кластер Yandex Managed PostgreSQL → DATABASE_URL=postgres… → миграция → рестарт). Сейчас пилот на SQLite (Вариант A, Решение 8) — категория осталась на console-database.`,
        },
        { status: 422 },
      );
    }

    const previous = await db.externalServicePort.findFirst({
      where: { category: port.category, isActive: true },
      select: { code: true },
    });

    // Атомарный переключатель: деактивировать остальные + активировать целевой.
    const updated = await db.$transaction(async (tx) => {
      await tx.externalServicePort.updateMany({ where: { category: port.category, isActive: true }, data: { isActive: false } });
      return tx.externalServicePort.update({ where: { code }, data: { isActive: true } });
    });

    AuditLog.logSecurity('INTEGRATION_ACTIVATED', {
      actorId: staff.user.id,
      resource: 'ExternalServicePort',
      resourceId: updated.id,
      metadata: { code, category: updated.category, previousCode: previous?.code ?? null },
    });

    return NextResponse.json({
      ok: true,
      port: { code: updated.code, category: updated.category, isActive: updated.isActive },
      previousCode: previous?.code ?? null,
    });
  },
  { schema: activateSchema, rateLimit: RATE_CLASSES.AUTH_STRICT },
);
