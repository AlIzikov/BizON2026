// BizON API — GET /api/admin/integrations (П4 Фаза 1, п.1.3 директивы).
//
// Полный реестр интеграций по 13 категориям: порт (code/provider/kind/mode/
// priority/isActive) + ФАКТЫ готовности (адаптер реализован? env заданы?) —
// БЕЗ значений секретов. Плюс манифест-данные (INT-id, целевой адаптер,
// процедура активации/проверки).
// Доступ: staff-роль admin (канон requireAdmin).
import { NextResponse } from 'next/server';

import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { allCategorySummaries } from '@/lib/hubs/registry';
import { loadManifest, validateManifestCanon } from '@/lib/hubs/manifest';

export const runtime = 'nodejs';

export const GET = withRoute(
  async (req) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });

    const [categories, manifest] = await Promise.all([allCategorySummaries(), Promise.resolve(loadManifest())]);
    const manifestCanon = validateManifestCanon();

    const manifestByPort = new Map(manifest.integrations.map((e) => [e.port_code, e]));
    const categoriesWithManifest = categories.map((c) => ({
      ...c,
      ports: c.ports.map((p) => {
        const m = manifestByPort.get(p.code);
        return {
          ...p,
          manifest: m
            ? {
                id: m.id,
                name: m.name,
                targetAdapter: m.target_adapter,
                priority: m.priority,
                usedIn: m.used_in,
                activation: m.activation,
                verification: m.verification,
              }
            : null,
        };
      }),
    }));

    return NextResponse.json({
      categories: categoriesWithManifest,
      manifest: {
        version: manifest.version,
        updated: manifest.updated,
        entries: manifest.integrations.length,
        canonOk: manifestCanon.ok,
        canonProblems: manifestCanon.problems,
      },
    });
  },
  { rateLimit: RATE_CLASSES.USER_READ },
);
