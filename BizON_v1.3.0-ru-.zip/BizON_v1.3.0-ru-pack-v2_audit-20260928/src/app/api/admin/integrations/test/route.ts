// BizON API — POST /api/admin/integrations/test (П4 Фаза 1, п.1.3).
//
// Test endpoint: вызывает adapter.test() конкретного порта. Честные ответы:
//   404 PORT_NOT_FOUND · 501 ADAPTER_NOT_IMPLEMENTED (адаптера нет — тестировать
//   нечего, это НЕ «упавший тест») · 200 {ok, detail} — результат самопроверки
//   адаптера (stub → ok:true с описанием режима; наружный эффект stub НЕ
//   имитируется — канон ADR-007). Значения секретов не возвращаются.
// Доступ: staff-роль admin.
import { NextResponse } from 'next/server';
import { z } from 'zod';

import { db } from '@/lib/db';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { isHubCategory, requiredEnvStatus } from '@/lib/hubs/core';
import { adapterFor, HUB_REGISTRY } from '@/lib/hubs/registry';

export const runtime = 'nodejs';

const testSchema = z.object({
  code: z.string().trim().toLowerCase().regex(/^[a-z0-9][a-z0-9-]{1,39}$/),
});

interface TestableAdapter {
  test(): Promise<{ ok: boolean; detail: string }>;
}

export const POST = withRoute(
  async (req, ctx) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });

    const { code } = ctx.data as z.infer<typeof testSchema>;
    const port = await db.externalServicePort.findUnique({ where: { code } });
    if (!port) {
      return NextResponse.json({ error: `PORT_NOT_FOUND: порт «${code}» не найден в реестре` }, { status: 404 });
    }
    if (!isHubCategory(port.category)) {
      return NextResponse.json({ error: `UNKNOWN_CATEGORY: категория «${port.category}» вне реестра хабов` }, { status: 422 });
    }

    const adapter = adapterFor(port.category, port) as TestableAdapter | null;
    if (!adapter || typeof adapter.test !== 'function') {
      return NextResponse.json(
        {
          ok: false,
          status: 'ADAPTER_NOT_IMPLEMENTED',
          error: `У порта «${code}» нет адаптера в карте хаба — тестировать нечего (подключение = файл в adapters/, ADR-007).`,
          env: requiredEnvStatus(HUB_REGISTRY[port.category].requiredEnv(port)),
        },
        { status: 501 },
      );
    }

    let result: { ok: boolean; detail: string };
    try {
      result = await adapter.test();
    } catch (e) {
      result = { ok: false, detail: `test() упал: ${e instanceof Error ? e.message.slice(0, 200) : String(e)}` };
    }

    return NextResponse.json({
      ok: result.ok,
      status: result.ok ? 'PASS' : 'FAIL',
      detail: result.detail,
      port: { code: port.code, category: port.category, isActive: port.isActive },
      env: requiredEnvStatus(HUB_REGISTRY[port.category].requiredEnv(port)),
    });
  },
  { schema: testSchema, rateLimit: RATE_CLASSES.AUTH_STRICT },
);
