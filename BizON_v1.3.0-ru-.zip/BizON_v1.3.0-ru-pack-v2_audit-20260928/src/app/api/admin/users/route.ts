// BizON API — GET /api/admin/users (R5-4b, C10 admin panel).
// Список пользователей для админ-панели: поиск по ИМЕНИ (startsWith),
// фильтр блокировки, пагинация (pageSize 20).
//
// ЧЕСТНОСТЬ PII: поиск ТОЛЬКО по name — email/телефон не ищутся и не отдаются
// (email зашифрован в User.emailEncrypted; админ-лист — не PII-дамп).
// Гейт: requireStaff (admin | moderator | support), rate USER_READ.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireStaff } from '@/lib/admin-guard';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

const PAGE_SIZE = 20;

const listSchema = z.object({
  query: z.string().trim().min(1).max(100).optional(),
  blocked: z.enum(['true', 'false']).optional(),
  page: z.coerce.number().int().min(1).max(100000).default(1),
});

export const GET = withRoute(
  async (req, ctx) => {
    const staff = await requireStaff(req);
    if (!staff.ok) {
      return NextResponse.json({ error: staff.message }, { status: staff.status });
    }

    const { query, blocked, page } = listSchema.parse(ctx.data);

    const where: Record<string, unknown> = {};
    if (query) where.name = { startsWith: query };
    if (blocked === 'true') where.blockedAt = { not: null };
    if (blocked === 'false') where.blockedAt = null;

    const [users, total] = await Promise.all([
      // staff-DTO без PII: никаких email*/phone*/bio* полей в select.
      db.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * PAGE_SIZE,
        take: PAGE_SIZE,
        select: {
          id: true,
          name: true,
          title: true,
          accountType: true,
          ipScore: true,
          roles: true,
          blockedAt: true,
          deletedAt: true,
          subscriptionTier: true,
          createdAt: true,
        },
      }),
      db.user.count({ where }),
    ]);

    return NextResponse.json({ users, total, page, pageSize: PAGE_SIZE });
  },
  { rateLimit: { key: 'api:admin/users:GET', ...RATE_CLASSES.USER_READ } },
);
