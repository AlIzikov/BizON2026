// BizON API — PATCH /api/admin/users/[id] (R5-4b, C10 admin panel).
// Модерационные действия над пользователем по body.action:
//   block    (admin|moderator): blockedAt=now + ВСЕ сессии цели удаляются
//            (гейт R5-1: blockedAt → сессии недействительны, login отклонён)
//            + AuditLog 'admin_user_blocked' {reason};
//   unblock  (admin|moderator): blockedAt=null + AuditLog 'admin_user_unblocked';
//   set_role (ТОЛЬКО admin): role ∈ ['admin','moderator','support',''] — CSV
//            User.roles правится точечно (замена staff-роли, прочие роли
//            сохраняются; '' = снять staff-роль) + AuditLog 'admin_role_changed'.
// Самозащита: block/set_role над СЕБОЙ → 422 CANNOT_MODIFY_SELF.
// Иерархия: модератор не может block/set_role админа → 403 CANNOT_MODIFY_ADMIN.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireModerator, requireAdmin, hasRole, STAFF_ROLES } from '@/lib/admin-guard';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIp } from '@/lib/security/rate-limiter';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

const paramsSchema = z.object({ id: z.string().min(1).max(64) });

const actionSchema = z
  .object({
    action: z.enum(['block', 'unblock', 'set_role']),
    reason: z.string().trim().max(500).optional(),
    role: z.enum(['admin', 'moderator', 'support', '']).optional(),
  })
  .superRefine((v, issues) => {
    if (v.action === 'set_role' && v.role === undefined) {
      issues.addIssue({ code: z.ZodIssueCode.custom, path: ['role'], message: 'Для set_role обязателен role' });
    }
  });

export const PATCH = withRoute<{ id: string }>(
  async (req, ctx) => {
    const { id } = ctx.params;
    const input = actionSchema.parse(ctx.data);
    const ip = getClientIp(req);

    // set_role — exclusively admin (до moderator-гейта: support/moderator → 403).
    if (input.action === 'set_role') {
      const admin = await requireAdmin(req);
      if (!admin.ok) return NextResponse.json({ error: admin.message }, { status: admin.status });
      return setRole(admin.user, id, input.role!, ip);
    }

    // block/unblock — admin|moderator.
    const mod = await requireModerator(req);
    if (!mod.ok) return NextResponse.json({ error: mod.message }, { status: mod.status });
    const actor = mod.user;

    const target = await db.user.findUnique({ where: { id }, select: { id: true, roles: true, blockedAt: true } });
    if (!target) return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });

    if (target.id === actor.id) {
      return NextResponse.json({ error: 'Нельзя применить это действие к себе', code: 'CANNOT_MODIFY_SELF' }, { status: 422 });
    }
    // Иерархия: только admin может блокировать админа (модератор → 403).
    if (input.action === 'block' && hasRole(target.roles, ['admin']) && !hasRole(actor.roles, ['admin'])) {
      return NextResponse.json({ error: 'Модератор не может заблокировать администратора', code: 'CANNOT_MODIFY_ADMIN' }, { status: 403 });
    }

    if (input.action === 'block') {
      await db.user.update({ where: { id: target.id }, data: { blockedAt: new Date() } });
      // Блок = сессии недействительны (симметрично гейту R5-1 в auth.ts).
      await db.session.deleteMany({ where: { userId: target.id } });
      AuditLog.logSecurity('admin_user_blocked', {
        actorId: actor.id,
        resource: 'User',
        resourceId: target.id,
        ip,
        metadata: { reason: input.reason ?? null, targetWasAdmin: hasRole(target.roles, ['admin']) },
      });
      return NextResponse.json({ ok: true, blockedAt: new Date().toISOString() });
    }

    // unblock
    await db.user.update({ where: { id: target.id }, data: { blockedAt: null } });
    AuditLog.logSecurity('admin_user_unblocked', {
      actorId: actor.id,
      resource: 'User',
      resourceId: target.id,
      ip,
      metadata: { reason: input.reason ?? null },
    });
    return NextResponse.json({ ok: true, blockedAt: null });
  },
  {
    paramsSchema,
    // Модерационные мутации — строгий класс (как login): 10/мин на staff-аккаунт.
    rateLimit: { key: 'api:admin/users/[id]:PATCH', ...RATE_CLASSES.AUTH_STRICT },
  },
);

/**
 * set_role: CSV User.roles правится ТОЧЕЧНО — существующая staff-роль
 * (admin|moderator|support) заменяется, все прочие (нестафф) роли сохраняются.
 * role='' — снять staff-роль. Несколько staff-ролей в CSV (кривые данные)
 * схлопываются в одну целевую. from/to пишутся в AuditLog.
 */
async function setRole(
  actor: { id: string; roles: string },
  targetId: string,
  role: 'admin' | 'moderator' | 'support' | '',
  ip: string | null,
) {
  const target = await db.user.findUnique({ where: { id: targetId }, select: { id: true, roles: true } });
  if (!target) return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });

  if (target.id === actor.id) {
    return NextResponse.json({ error: 'Нельзя изменить собственную роль', code: 'CANNOT_MODIFY_SELF' }, { status: 422 });
  }

  const current = (target.roles ?? '').split(',').map((r) => r.trim()).filter(Boolean);
  const from = current.filter((r) => (STAFF_ROLES as readonly string[]).includes(r));
  const others = current.filter((r) => !(STAFF_ROLES as readonly string[]).includes(r));
  const next = role === '' ? others : [...others, role];

  await db.user.update({ where: { id: target.id }, data: { roles: next.join(',') } });
  AuditLog.logSecurity('admin_role_changed', {
    actorId: actor.id,
    resource: 'User',
    resourceId: target.id,
    ip,
    metadata: { from: from.join(',') || null, to: role || null },
  });
  return NextResponse.json({ ok: true, roles: next.join(',') });
}
