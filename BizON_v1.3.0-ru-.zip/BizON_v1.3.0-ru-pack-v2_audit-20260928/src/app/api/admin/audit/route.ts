// BizON API — GET /api/admin/audit (R5-4b, C10 admin panel).
// Лента AuditLog (hash-chain журнал): фильтры ?action= ?actorId=, пагинация
// (pageSize 50, orderBy createdAt desc). metadata отдаётся КАК ЕСТЬ (строка
// JSON из БД) — это админ-инструмент расследования, а не публичный API.
// Гейт: requireStaff (admin | moderator | support), rate USER_READ.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireStaff } from '@/lib/admin-guard';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

const PAGE_SIZE = 50;

const querySchema = z.object({
  action: z.string().trim().min(1).max(100).optional(),
  actorId: z.string().trim().min(1).max(64).optional(),
  page: z.coerce.number().int().min(1).max(100000).default(1),
});

export const GET = withRoute(
  async (req, ctx) => {
    const staff = await requireStaff(req);
    if (!staff.ok) {
      return NextResponse.json({ error: staff.message }, { status: staff.status });
    }

    const { action, actorId, page } = querySchema.parse(ctx.data);
    const where: Record<string, unknown> = {};
    if (action) where.action = action;
    if (actorId) where.actorId = actorId;

    const [entries, total] = await Promise.all([
      db.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * PAGE_SIZE,
        take: PAGE_SIZE,
        select: {
          id: true,
          actorId: true,
          action: true,
          resource: true,
          resourceId: true,
          ip: true,
          createdAt: true,
          metadata: true,
        },
      }),
      db.auditLog.count({ where }),
    ]);

    return NextResponse.json({ entries, total, page, pageSize: PAGE_SIZE });
  },
  { rateLimit: { key: 'api:admin/audit:GET', ...RATE_CLASSES.USER_READ } },
);
