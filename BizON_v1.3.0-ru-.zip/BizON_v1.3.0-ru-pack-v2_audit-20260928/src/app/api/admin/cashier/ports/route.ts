// BizON API — /api/admin/cashier/ports (закрытый контур, VC-2, Решение 5).
// Зародыш будущего «BizON Service»: администрирование портов кассы-хаба.
//   GET  — полный реестр (включая отключённые) с признаком готовности;
//   POST — подключить кассу существующего типа = запись реестра (НЕ правка кода).
// Доступ: только x-admin-token == BIZON_ADMIN_TOKEN; без токена — 403
// (никаких «демо-доступов»). Все действия — в AuditLog.
import { z } from 'zod';
import { timingSafeEqualString } from '@/lib/security/timing-safe'; // CRYPTO-008: constant-time сравнение секретов
import { json } from '@/lib/api-helpers';
import { withRoute } from '@/lib/with-route';
import { CashierPortsService } from '@/lib/services/cashier-ports-service';

export const runtime = 'nodejs';

function authorized(req: Request): string | null {
  const token = (process.env as Record<string, string | undefined>)['BIZON_ADMIN_TOKEN'];
  if (!token) return null; // токен не настроен — управления нет (безопасный дефолт)
  const header = req.headers.get('x-admin-token');
  return header && timingSafeEqualString(header, token) ? token : null; // CRYPTO-008
}

const createSchema = z.object({
  code: z.string().trim().toLowerCase().min(2).max(40),
  name: z.string().trim().min(2).max(120),
  kind: z.enum(['virtual-lumens', 'external-http']),
  mode: z.enum(['virtual', 'real']).optional(),
  country: z.string().trim().toUpperCase().regex(/^[A-Z]{2}$/).nullable().optional(),
  currency: z.string().trim().toUpperCase().regex(/^[A-Z]{3}$/).nullable().optional(),
  priority: z.number().int().min(0).max(10_000).optional(),
  configJson: z.string().max(4000).nullable().optional(),
});

export const GET = withRoute(
  async (req, ctx) => {
    if (!authorized(req)) {
      return json({ error: 'Управление портами кассы только с BIZON_ADMIN_TOKEN' }, 403);
    }
    const ports = await CashierPortsService.listPorts({ includeDisabled: true });
    return json({ ports, adminConfigured: Boolean((process.env as Record<string, string | undefined>)['BIZON_ADMIN_TOKEN']) });
  },
  { auth: false },
);

export const POST = withRoute(
  async (req, ctx) => {
    const actorToken = authorized(req);
    if (!actorToken) {
      return json({ error: 'Подключение касс только с BIZON_ADMIN_TOKEN' }, 403);
    }
    const input = ctx.data as z.infer<typeof createSchema>;
    // actorId для аудита: администратор действует по токену, не как пользователь
    const port = await CashierPortsService.createPort({ ...input, actorId: 'admin:token' });
    return json({ port }, 201);
  },
  { auth: false, schema: createSchema },
);
