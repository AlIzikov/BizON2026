// BizON API — /api/admin/cashier/ports/[id] (закрытый контур, VC-2).
// PATCH — управление портом: статус (вкл/выкл), приоритет роутинга, имя.
// Виртуальный порт (внутренний кошелёк) не отключается — защита от
// «отрезали единственную кассу». Доступ: только x-admin-token.
import { z } from 'zod';
import { timingSafeEqualString } from '@/lib/security/timing-safe'; // CRYPTO-008: constant-time сравнение секретов
import { json } from '@/lib/api-helpers';
import { withRoute } from '@/lib/with-route';
import { CashierPortsService } from '@/lib/services/cashier-ports-service';

export const runtime = 'nodejs';

function authorized(req: Request): boolean {
  const token = (process.env as Record<string, string | undefined>)['BIZON_ADMIN_TOKEN'];
  if (!token) return false;
  return timingSafeEqualString(req.headers.get('x-admin-token') ?? '', token); // CRYPTO-008
}

const patchSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  status: z.enum(['active', 'disabled']).optional(),
  priority: z.number().int().min(0).max(10_000).optional(),
  configJson: z.string().max(4000).nullable().optional(),
});

export const PATCH = withRoute<{ id: string }>(
  async (req, ctx) => {
    if (!authorized(req)) {
      return json({ error: 'Управление портами кассы только с BIZON_ADMIN_TOKEN' }, 403);
    }
    const input = ctx.data as z.infer<typeof patchSchema>;
    const port = await CashierPortsService.updatePort(ctx.params.id, input, 'admin:token');
    return json({ port });
  },
  { auth: false, schema: patchSchema },
);
