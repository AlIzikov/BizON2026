// BizON API — /api/admin/feature-flags (R5-P2: управление фича-флагами).
//
// GET  — staff (admin|moderator|support): список флагов с текущим состоянием.
// PATCH — только admin: upsert { key, enabled?, rolloutPercent?, description? }.
//
// Каноны: dotted-ключи (валидация в upsertFlag), fail-closed (нет строки в БД =
// выключен), кэш 60с инвалидируется при мутации. Каждый чендж — в AuditLog
// (before/after) по канону pricing-мутаций R5.5.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { listFlagsForAdmin, upsertFlag, FLAG_KEYS } from '@/lib/feature-flags';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

const patchSchema = z.object({
  key: z.string().trim().min(3).max(64),
  enabled: z.boolean().optional(),
  rolloutPercent: z.number().int().min(0).max(100).optional(),
  description: z.string().max(300).nullable().optional(),
});

export const GET = withRoute(
  async (req) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });
    const flags = await listFlagsForAdmin();
    return NextResponse.json({
      flags: flags.map((f) => ({
        key: f.key,
        enabled: f.enabled,
        rolloutPercent: f.rolloutPercent,
        description: f.description,
        updatedAt: f.updatedAt.toISOString(),
        updatedBy: f.updatedBy,
      })),
      knownKeys: Object.values(FLAG_KEYS),
    });
  },
  { rateLimit: { key: 'api:admin/feature-flags:GET', ...RATE_CLASSES.ADMIN_READ } },
);

export const PATCH = withRoute(
  async (req, ctx) => {
    const admin = await requireAdmin(req);
    if (!admin.ok) return NextResponse.json({ error: admin.message }, { status: admin.status });

    const body = patchSchema.parse(ctx.data);
    const before = await listFlagsForAdmin().then((rows) => rows.find((r) => r.key === body.key) ?? null);

    try {
      const updated = await upsertFlag({
        key: body.key,
        enabled: body.enabled,
        rolloutPercent: body.rolloutPercent,
        description: body.description ?? undefined,
        updatedBy: ctx.user.id,
      });

      AuditLog.logSecurity('feature_flag.changed', {
        actorId: ctx.user.id,
        resource: 'FeatureFlag',
        resourceId: updated.key,
        metadata: {
          before: before ? { enabled: before.enabled, rolloutPercent: before.rolloutPercent } : null,
          after: { enabled: updated.enabled, rolloutPercent: updated.rolloutPercent },
        },
      });

      return NextResponse.json({
        flag: {
          key: updated.key,
          enabled: updated.enabled,
          rolloutPercent: updated.rolloutPercent,
          description: updated.description,
          updatedAt: updated.updatedAt.toISOString(),
          updatedBy: updated.updatedBy,
        },
      });
    } catch (e) {
      if (e instanceof Error && e.message === 'FLAG_KEY_INVALID') {
        return NextResponse.json({ error: 'Ключ должен быть dotted: раздел.metric (a-z0-9_)' }, { status: 422 });
      }
      if (e instanceof Error && e.message === 'ROLLOUT_INVALID') {
        return NextResponse.json({ error: 'rolloutPercent: 0..100' }, { status: 422 });
      }
      throw e;
    }
  },
  { rateLimit: { key: 'api:admin/feature-flags:PATCH', ...RATE_CLASSES.ADMIN_WRITE } },
);
