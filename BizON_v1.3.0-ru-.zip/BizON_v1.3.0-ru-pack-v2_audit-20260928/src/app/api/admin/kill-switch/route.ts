// BizON API — /api/admin/kill-switch (Wave 6, S-136).
// Управление аварийным тормозом автономии ВНЕ AI-контура:
//   • POST { action: 'kill' | 'restore' } — создаёт/удаляет файл-флаг;
//   • GET — текущий статус (env/файл/политика).
// Доступ: только с заголовком x-admin-token == BIZON_ADMIN_TOKEN (env);
// без настроенного токена роут честно 403 (никаких «демо-доступов»).
import { NextResponse } from 'next/server';
import { timingSafeEqualString } from '@/lib/security/timing-safe'; // CRYPTO-008: constant-time сравнение секретов
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { writeFileSync, unlinkSync, existsSync } from 'node:fs';
import path from 'node:path';
import { db } from '@/lib/db';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

const FLAG = () => path.join(process.cwd(), '.bizon-ai-killed');

function authorized(req: Request): boolean {
  const token = (process.env as Record<string, string | undefined>)['BIZON_ADMIN_TOKEN'];
  if (!token) return false; // токен не настроен — управления нет (безопасный дефолт)
  return timingSafeEqualString(req.headers.get('x-admin-token') ?? '', token); // CRYPTO-008
}

const schema = z.object({ action: z.enum(['kill', 'restore']) });

export const GET = withRoute(async (req, ctx) => {
  const env = (process.env as Record<string, string | undefined>)['BIZON_AI_AUTONOMY_KILLED'] === '1';
  const file = existsSync(FLAG());
  const policy = await db.aiPolicy.findUnique({ where: { key: 'global_autonomy' } });
  return NextResponse.json({
    envKilled: env,
    fileKilled: file,
    policyKilled: policy ? policy.enabled === false : false,
    killed: env || file || (policy ? policy.enabled === false : false),
    adminConfigured: Boolean((process.env as Record<string, string | undefined>)['BIZON_ADMIN_TOKEN']),
  });
}, { auth: false });

export const POST = withRoute(async (req, ctx) => {
  if (!authorized(req)) {
    return NextResponse.json({ error: 'Управление kill-switch только с BIZON_ADMIN_TOKEN' }, { status: 403 });
  }
  const input = schema.parse(ctx.data);
  if (input.action === 'kill') {
    writeFileSync(FLAG(), new Date().toISOString(), 'utf8');
  } else {
    if (existsSync(FLAG())) unlinkSync(FLAG());
  }
  AuditLog.logSecurity(input.action === 'kill' ? 'AI_KILL_SWITCH_ON' : 'AI_KILL_SWITCH_OFF', {
    actorId: ctx.user?.id ?? 'operator', resource: 'AiPolicy', resourceId: 'global_autonomy', metadata: { via: 'file-flag' },
  });
  return NextResponse.json({ ok: true, fileKilled: input.action === 'kill' });
});
