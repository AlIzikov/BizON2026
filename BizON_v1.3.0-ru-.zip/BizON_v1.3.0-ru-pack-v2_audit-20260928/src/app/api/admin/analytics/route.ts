// BizON API — GET /api/admin/analytics (R5-P1-REBUILD E3: продуктовая сводка).
//
// Staff-only (admin|moderator|support, канон requireAdmin) продуктовая аналитика:
//   - totals за 30 дней по каждому product:*-событию (топ по убыванию);
//   - количество событий за последние 24 часа;
//   - уникальные активные пользователи за 30 дней.
// Хранилище: ActionEvent(type startsWith 'product:', isPublic: false).
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { ANALYTICS_EVENT_LABELS } from '@/lib/analytics';

export const runtime = 'nodejs';

export const GET = withRoute(
  async (req) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });

    const since30d = new Date(Date.now() - 30 * 24 * 3600 * 1000);
    const since24h = new Date(Date.now() - 24 * 3600 * 1000);

    const productWhere = { type: { startsWith: 'product:' }, createdAt: { gte: since30d } };

    const [totals, recent24h, distinctUsers] = await Promise.all([
      db.actionEvent.groupBy({
        by: ['type'],
        where: productWhere,
        _count: { _all: true },
        orderBy: { _count: { type: 'desc' } },
      }),
      db.actionEvent.count({ where: { ...productWhere, createdAt: { gte: since24h } } }),
      db.actionEvent.findMany({
        where: productWhere,
        distinct: ['userId'],
        select: { userId: true },
      }),
    ]);

    return NextResponse.json({
      window: '30d',
      totals: totals.map((t) => ({
        event: t.type.replace(/^product:/, ''),
        label: ANALYTICS_EVENT_LABELS[t.type.replace(/^product:/, '')] ?? t.type,
        count: t._count._all,
      })),
      last24h: recent24h,
      activeUsers30d: distinctUsers.length,
    });
  },
  { rateLimit: { key: 'api:admin/analytics:GET', ...RATE_CLASSES.ADMIN_READ } },
);
