// BizON API — /api/admin/ops-board (QA-бэклог владельца 2026-09-19: «Grafana-борд»).
// GET — единый срез здоровья: метрики БД, деньги (эскроу/инварианты), матрица
// логинов 10 демо-аккаунтов. Read-only, без записей.
// Доступ: D-20 opsGuard — сессия с ролью admin ИЛИ x-admin-token == BIZON_ADMIN_TOKEN.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { opsGuard } from '@/lib/admin-guard';
import { getOpsBoard } from '@/lib/services/ops-board-service';

export const runtime = 'nodejs';

export const GET = withRoute(async (req) => {
  const denied = await opsGuard(req);
  if (denied) return denied;
  return NextResponse.json(await getOpsBoard());
}, { auth: false });
