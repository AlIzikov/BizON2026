// BizON API — /api/admin/metrics (JSON dashboard summary)
// Phase 16: Performance + Monitoring — человекочитаемый JSON-снимок системы
// для админ-панели. В отличие от /api/metrics (Prometheus text) — это компактный
// JSON для UI-дашборда.
//
// Формат ответа:
//   {
//     "users":   { "total": N, "active24h": N },
//     "content": { "posts": N, "projects": N, "jobs": N, "events": N },
//     "api":     { "cacheSize": N, "cacheHitRate": 0.65, "cacheHits": N, "cacheMisses": N },
//     "system":  { "uptime": N, "memoryRssBytes": N, "memoryRssMb": "120MB", "dbStatus": "ok" },
//     "version": "2.0.0",
//     "timestamp": "2026-09-07T..."
//   }
//
// Auth: admin user (через сессию) ИЛИ METRICS_TOKEN env (Bearer).
// FIX-02 (P0-2): проверка роли — через общий requireAdmin() (src/lib/admin-guard.ts)
// вместо локального дубликата; сессия без роли admin → 403.
import { NextRequest } from 'next/server';
import { timingSafeEqualString } from '@/lib/security/timing-safe'; // CRYPTO-008: constant-time сравнение секретов
import { db } from '@/lib/db';
import { json, errorJson } from '@/lib/api-helpers';
import { requireAdmin } from '@/lib/admin-guard';
import { cache } from '@/lib/cache';

export const runtime = 'nodejs';

const START_TIME = Date.now();
const VERSION = '2.0.0';

type AuthResult = { ok: true } | { ok: false; status: 401 | 403; message: string };

async function checkAuth(req: NextRequest): Promise<AuthResult> {
  // Путь 1: METRICS_TOKEN (Bearer) — ops/scrape-доступ без пользовательской сессии.
  const metricsToken = process.env.METRICS_TOKEN;
  if (metricsToken) {
    const auth = req.headers.get('authorization');
    if (auth?.startsWith('Bearer ') && timingSafeEqualString(auth.slice(7), metricsToken)) { // CRYPTO-008
      return { ok: true };
    }
  }
  // Путь 2: сессия + роль 'admin' (FIX-02: единый requireAdmin; 401 без сессии, 403 без роли).
  const admin = await requireAdmin(req);
  if (admin.ok) return { ok: true };
  return { ok: false, status: admin.status, message: admin.status === 401 ? 'Unauthorized' : admin.message };
}

function formatMb(bytes: number): string {
  return `${Math.round(bytes / 1024 / 1024)}MB`;
}

export async function GET(req: NextRequest) {
  const auth = await checkAuth(req);
  if (!auth.ok) return errorJson(auth.message, auth.status);

  let usersTotal = 0;
  let usersActive24h = 0;
  let postsTotal = 0;
  let projectsActive = 0;
  let jobsOpen = 0;
  let eventsUpcoming = 0;
  let dbStatus: 'ok' | 'error' = 'ok';
  try {
    const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const now = new Date();
    [
      usersTotal,
      usersActive24h,
      postsTotal,
      projectsActive,
      jobsOpen,
      eventsUpcoming,
    ] = await Promise.all([
      db.user.count(),
      db.user.count({ where: { lastSeenAt: { gte: since24h } } }),
      db.post.count({ where: { isHidden: false } }),
      db.project.count({ where: { status: 'ACTIVE' } }),
      db.job.count({ where: { active: true } }),
      db.event.count({ where: { startDate: { gte: now } } }),
    ]);
  } catch (e) {
    console.error('[admin/metrics] DB query failed:', e);
    dbStatus = 'error';
  }

  const cacheStats = cache.stats();
  // Periodically sweep expired entries while we're here
  cache.sweep();

  let rssBytes = 0;
  try {
    rssBytes = process.memoryUsage().rss;
  } catch {
    rssBytes = 0;
  }

  const uptimeSeconds = Math.floor((Date.now() - START_TIME) / 1000);

  return json({
    users: {
      total: usersTotal,
      active24h: usersActive24h,
    },
    content: {
      posts: postsTotal,
      projects: projectsActive,
      jobs: jobsOpen,
      events: eventsUpcoming,
    },
    api: {
      cacheSize: cacheStats.size,
      cacheHits: cacheStats.hits,
      cacheMisses: cacheStats.misses,
      cacheHitRate: Number(cacheStats.hitRate.toFixed(4)),
    },
    system: {
      uptime: uptimeSeconds,
      memoryRssBytes: rssBytes,
      memoryRssMb: formatMb(rssBytes),
      dbStatus,
    },
    version: VERSION,
    timestamp: new Date().toISOString(),
  });
}
