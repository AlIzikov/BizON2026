// BizON API — GET /api/admin/payments (R5-4b, C10 admin panel).
// Деньги: последние 50 платежей (+ имя плательщика), последние 50 возвратов
// (с платежом), агрегаты по успешным платежам: totalSucceeded / totalAmount /
// byProvider (demo | stripe | yookassa).
//
// ЧЕСТНОСТЬ: totalSucceeded считается по ТЕКУЩЕМУ статусу платежа — платёж со
// статусом 'refunded' в сумму не входит (возвраты перечислены отдельно).
// Гейт: requireAdmin (деньги — только admin, не весь staff), rate USER_READ.
import { NextResponse } from 'next/server';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export const GET = withRoute(
  async (req) => {
    const admin = await requireAdmin(req);
    if (!admin.ok) {
      return NextResponse.json({ error: admin.message }, { status: admin.status });
    }

    const [payments, refunds, totalSucceeded, amountAgg, byProvider] = await Promise.all([
      db.payment.findMany({
        orderBy: { createdAt: 'desc' },
        take: 50,
        select: {
          id: true,
          userId: true,
          provider: true,
          status: true,
          amount: true,
          currency: true,
          externalId: true,
          description: true,
          createdAt: true,
          user: { select: { id: true, name: true } },
        },
      }),
      db.refund.findMany({
        orderBy: { createdAt: 'desc' },
        take: 50,
        select: {
          id: true,
          paymentId: true,
          amount: true,
          reason: true,
          provider: true,
          externalId: true,
          createdAt: true,
          payment: { select: { id: true, status: true, userId: true } },
        },
      }),
      db.payment.count({ where: { status: 'succeeded' } }),
      db.payment.aggregate({ _sum: { amount: true }, where: { status: 'succeeded' } }),
      db.payment.groupBy({
        by: ['provider'],
        _count: { _all: true },
        _sum: { amount: true },
        where: { status: 'succeeded' },
      }),
    ]);

    return NextResponse.json({
      payments,
      refunds,
      aggregates: {
        totalSucceeded,
        totalAmount: amountAgg._sum.amount ?? 0,
        byProvider: byProvider
          .map((row) => ({ provider: row.provider, count: row._count._all, amount: row._sum.amount ?? 0 }))
          .sort((a, b) => b.amount - a.amount),
      },
    });
  },
  { rateLimit: { key: 'api:admin/payments:GET', ...RATE_CLASSES.USER_READ } },
);
