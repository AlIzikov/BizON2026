// BizON API — GET /api/admin/audit-verify (Wave 6, S-134).
// Верификация hash-chain журнала AuditLog (tamper-evidence).
// D-20 (R2-002): доступ только админ-сессия (роль admin) ИЛИ x-admin-token.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { opsGuard } from '@/lib/admin-guard';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

export const GET = withRoute(async (req, ctx) => {
  const denied = await opsGuard(req);
  if (denied) return denied;
  const sp = new URL(req.url).searchParams;
  const limit = Number(sp.get('limit') ?? '200');
  const result = await AuditLog.verifyChain(Number.isFinite(limit) ? Math.min(1000, Math.max(2, limit)) : 200);
  return NextResponse.json(result);
}, { auth: false });
