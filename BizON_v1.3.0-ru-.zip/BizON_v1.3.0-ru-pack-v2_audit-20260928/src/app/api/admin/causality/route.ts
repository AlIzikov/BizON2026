// BizON API — GET /api/admin/causality
//
// Professional Causality Engine (doc_a §55, Task 9-f) — платформенные агрегаты:
// какие вмешательства (подтверждение инсайта / подтверждение навыка / скрытие
// темы) в среднем дают эффект. ТОЛЬКО агрегаты: публичные события (isPublic=true),
// счётчики приватных событий без чтения содержимого; без PII (никаких
// userId/имён/тем в ответе). Без LLM, детерминированно, кэш в памяти TTL 10 минут.
//
// Auth (FIX-03: dev-релаксация удалена):
//   1. Bearer-токен: METRICS_TOKEN или CAUSALITY_ADMIN_TOKEN (ops-доступ);
//   2. Сессия пользователя с ролью 'admin' (FIX-02: isAdminRole из admin-guard).
//      Никаких demo-обходов — агрегаты платформы не для любого
//      аутентифицированного пользователя.
import { NextRequest } from 'next/server';
import { timingSafeEqualString } from '@/lib/security/timing-safe'; // CRYPTO-008: constant-time сравнение секретов
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { CausalityEngine } from '@/lib/services/causality-engine-service';

export const runtime = 'nodejs';

async function checkAdminAuth(req: NextRequest): Promise<boolean> {
  // 1. Ops Bearer-токен (как в /api/admin/metrics)
  const opsToken = process.env.METRICS_TOKEN ?? process.env.CAUSALITY_ADMIN_TOKEN;
  if (opsToken) {
    const auth = req.headers.get('authorization');
    if (auth?.startsWith('Bearer ') && timingSafeEqualString(auth.slice(7), opsToken)) return true; // CRYPTO-008
  }
  try {
    // 2. Роль admin — единственный путь с сессией (FIX-03: demo-обход удалён)
    const user = await getUserFromRequest(req);
    if (user && isAdminRole(user.roles)) return true;
  } catch {
    // fall through
  }
  return false;
}

export async function GET(req: NextRequest) {
  const ok = await checkAdminAuth(req);
  if (!ok) return errorJson('Unauthorized', 401);

  try {
    const result = await CausalityEngine.getPlatformAggregates();
    return json(result);
  } catch (e) {
    console.error('[admin/causality] failed:', e);
    return errorJson('Не удалось рассчитать платформенные агрегаты', 500);
  }
}
