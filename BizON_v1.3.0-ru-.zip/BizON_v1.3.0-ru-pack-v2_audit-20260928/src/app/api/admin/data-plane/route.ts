// BizON API — /api/admin/data-plane
// Task 9-e (doc_scaling п.9 Shard-Ready + п.13 RU Data Plane / 152-ФЗ).
//
// GET — статус Data Plane для администратора:
//   • топология: плоскости (ru-primary / global-compute) + шарды (per-plane) с весами;
//   • статистика consistent-hash ring: распределение тестовых ключей по шардам,
//     проверка детерминированности (один ключ → один шард), перераспределение
//     при добавлении шарда (ожидание ≈ 1/N — свойство consistent hashing);
//   • активная residency-политика (таблица правил, fail-closed plane);
//   • последние residency-решения из in-memory журнала (TTL) — честный empty state,
//     пока фасад DataPlaneRepository не подключён к бизнес-потокам;
//   • самотест политики: чистые решения decidePlane для канонических контекстов
//     (RU класс A/B/C × storage/processing/batch, GDPR, fail-closed без обезличивания)
//     и демонстрация обезличивания через Sovereignty pseudonymize (read-only).
//
// Auth (по паттерну /api/metrics v6.1 и admin-роутов вида nft-skills/stale-check):
//   Путь 1: Bearer DATA_PLANE_TOKEN (env) — ops/cron без пользовательской сессии.
//   Путь 2: сессия + роль 'admin' из user.roles (CSV) — существующая модель ролей.
//   FIX-03: dev-релаксация (NODE_ENV !== 'production' → любой аутентифицированный)
//   удалена — доступ только admin / DATA_PLANE_TOKEN. Без сессии → 401.
//
// Модули без side effects: только чтение конфига, чистые функции shard.ts,
// чистые решения decidePlane. Журнал НЕ засоряется самотестом (diagnostic-режим
// не пишет в журнал) — журнал наполняют только реальные операции фасада.

import { NextRequest } from 'next/server';
import { timingSafeEqualString } from '@/lib/security/timing-safe'; // CRYPTO-008: constant-time сравнение секретов
import { json, errorJson } from '@/lib/api-helpers';
import { requireAdmin } from '@/lib/admin-guard';
import { DATA_PLANE_CONFIG } from '@/lib/data-plane/config';
import type { DataPlaneId, ResidencyOperation } from '@/lib/data-plane/config';
import {
  buildRing,
  resolveShard,
  shardDistribution,
  redistributeStats,
  makeShardKey,
} from '@/lib/data-plane/shard';
import type { ShardKeyKind } from '@/lib/data-plane/shard';
import { ringForPlane, planeShards, shardKeyKindForEntity, DATA_PLANE_ENTITIES } from '@/lib/data-plane/repository';
import {
  decidePlane,
  getRecentDecisions,
  decisionJournalStats,
  pseudonymizeForGlobalCompute,
  stablePseudonym,
} from '@/lib/data-plane/region-router';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ---- Auth -------------------------------------------------------------------------

// FIX-02 (P0-2): проверка роли — через общий requireAdmin() (src/lib/admin-guard.ts)
// вместо локального дубликата isAdmin().

type AuthFailure = { ok: false; status: 401 | 403; message: string };
type AuthResult = { ok: true } | AuthFailure;

async function checkAuth(req: NextRequest): Promise<AuthResult> {
  // Путь 1: DATA_PLANE_TOKEN (Bearer) — для ops/cron-доступа без сессии.
  const dpToken = process.env.DATA_PLANE_TOKEN;
  if (dpToken) {
    const auth = req.headers.get('authorization');
    if (auth?.startsWith('Bearer ') && timingSafeEqualString(auth.slice(7), dpToken)) return { ok: true }; // CRYPTO-008
  }
  // Путь 2: сессия + роль admin (FIX-02: единый requireAdmin).
  try {
    const admin = await requireAdmin(req);
    if (admin.ok) return { ok: true };
    if (admin.status === 401) {
      return { ok: false, status: 401, message: 'Не авторизован: требуется сессия (bizon_session) или Bearer DATA_PLANE_TOKEN' };
    }
    // FIX-03: dev-релаксация удалена — 403 из requireAdmin (сессия есть, роли
    // admin нет) отдаётся как есть; доступ только admin / DATA_PLANE_TOKEN.
    return { ok: false, status: 403, message: 'Только администратор (роль admin) или Bearer DATA_PLANE_TOKEN' };
  } catch {
    return { ok: false, status: 401, message: 'Не авторизован: сессия недействительна' };
  }
}

// ---- Ключи-семплы (детерминированные, без случайности) -----------------------------

const SHARD_KEY_KINDS: readonly ShardKeyKind[] = ['userId', 'companyId', 'jobId'];

function sampleKeys(kind: ShardKeyKind, count: number): string[] {
  const out: string[] = [];
  for (let i = 0; i < count; i++) {
    out.push(makeShardKey(kind, `sample-${kind}-${String(i).padStart(4, '0')}`));
  }
  return out;
}

// ---- Статистика ring --------------------------------------------------------------

type RingStats = {
  plane: DataPlaneId;
  shardCount: number;
  shardIds: string[];
  virtualNodes: number;
  keysSampled: number;
  distribution: { shardId: string; keys: number; sharePct: number }[];
  /** Максимальное отклонение доли шарда от равномерной 100/N (п.п.). */
  maxShareDeviationPct: number;
  consistencyProbe: {
    keysProbed: number;
    iterationsPerKey: number;
    /** true — каждый ключ 200 резолвов подряд дал один и тот же шард (измерено). */
    stable: boolean;
  };
};

function ringStatsForPlane(plane: DataPlaneId, keysPerKind: number): RingStats {
  const ring = ringForPlane(plane);
  const keys = SHARD_KEY_KINDS.flatMap((k) => sampleKeys(k, keysPerKind));

  const dist = shardDistribution(ring, keys);
  const total = keys.length || 1;
  const shares = ring.nodes.map((n) => ({
    shardId: n.id,
    keys: dist[n.id] ?? 0,
    sharePct: Math.round(((dist[n.id] ?? 0) / total) * 10000) / 100,
  }));
  const expected = 100 / ring.nodes.length;
  const maxDev = Math.max(...shares.map((s) => Math.abs(s.sharePct - expected)));

  // Детерминированность: 5 ключей × 200 повторных резолвов — все результаты совпадают.
  const probeKeys = keys.slice(0, 5);
  let stable = true;
  for (const key of probeKeys) {
    const first = resolveShard(ring, key);
    for (let i = 0; i < 200; i++) {
      if (resolveShard(ring, key) !== first) {
        stable = false;
        break;
      }
    }
    if (!stable) break;
  }

  return {
    plane,
    shardCount: ring.nodes.length,
    shardIds: ring.nodes.map((n) => n.id),
    virtualNodes: ring.vnodes.length,
    keysSampled: keys.length,
    distribution: shares,
    maxShareDeviationPct: Math.round(maxDev * 100) / 100,
    consistencyProbe: { keysProbed: probeKeys.length, iterationsPerKey: 200, stable },
  };
}

type RedistributionReport = {
  plane: DataPlaneId;
  fromShards: number;
  toShards: number;
  addedShardId: string;
  keysSampled: number;
  movedKeys: number;
  movedRatioPct: number;
  expectedRatioPct: number;
  /** true — movedRatio в пределах ±5 п.п. от теоретического 1/(N+1). */
  matchesTheory: boolean;
};

function redistributionForPlane(plane: DataPlaneId): RedistributionReport {
  const before = ringForPlane(plane);
  const addedShardId = `${plane}-shard-added`;
  const after = buildRing(
    [...planeShards(plane).map((s) => ({ id: s.id, weight: s.weight })), { id: addedShardId, weight: 1 }],
    DATA_PLANE_CONFIG.sharding.virtualNodesPerShard,
  );
  const keys = SHARD_KEY_KINDS.flatMap((k) => sampleKeys(k, 334)); // ≈1000 ключей
  const stats = redistributeStats(before, after, keys);
  const expectedPct = (100 / after.nodes.length);
  return {
    plane,
    fromShards: stats.fromShards,
    toShards: stats.toShards,
    addedShardId,
    keysSampled: stats.total,
    movedKeys: stats.moved,
    movedRatioPct: Math.round(stats.movedRatio * 10000) / 100,
    expectedRatioPct: Math.round(expectedPct * 100) / 100,
    matchesTheory: Math.abs(stats.movedRatio * 100 - expectedPct) <= 5,
  };
}

// ---- Самотест residency-политики (чистые решения, журнал НЕ пишется) ---------------

const DIAGNOSTIC_OWNER = { userId: 'data-plane-selftest', citizenship: 'RU', region: 'Москва' };
const GDPR_OWNER = { userId: 'data-plane-selftest', citizenship: 'DE', region: 'DE-BERLIN' };
const NO_REG_OWNER = { userId: 'data-plane-selftest', citizenship: null, region: null };

type SelfTestContext = {
  label: string;
  owner: { userId: string; citizenship?: string | null; region?: string | null } | null;
  dataClass: 'A' | 'B' | 'C';
  operation: ResidencyOperation;
  pseudonymized: boolean;
};

const SELF_TEST_CONTEXTS: readonly SelfTestContext[] = [
  { label: 'RU: класс A, хранение → 152-ФЗ ст.18 ч.5', owner: DIAGNOSTIC_OWNER, dataClass: 'A', operation: 'storage', pseudonymized: false },
  { label: 'RU: класс A, первичная обработка', owner: DIAGNOSTIC_OWNER, dataClass: 'A', operation: 'processing', pseudonymized: false },
  { label: 'RU: класс A, batch (raw PII за пределы РФ запрещено)', owner: DIAGNOSTIC_OWNER, dataClass: 'A', operation: 'batch', pseudonymized: false },
  { label: 'RU: класс B, обработка БЕЗ обезличивания → fail-closed', owner: DIAGNOSTIC_OWNER, dataClass: 'B', operation: 'processing', pseudonymized: false },
  { label: 'RU: класс B, обработка после обезличивания → global-compute', owner: DIAGNOSTIC_OWNER, dataClass: 'B', operation: 'processing', pseudonymized: true },
  { label: 'RU: класс B, тяжёлый batch после обезличивания → global-compute', owner: DIAGNOSTIC_OWNER, dataClass: 'B', operation: 'batch', pseudonymized: true },
  { label: 'RU: класс C (публичное) → global-compute', owner: DIAGNOSTIC_OWNER, dataClass: 'C', operation: 'storage', pseudonymized: false },
  { label: 'GDPR: класс A после минимизации', owner: GDPR_OWNER, dataClass: 'A', operation: 'processing', pseudonymized: true },
  { label: 'Регулятор не определён: класс A → консервативный ru-primary', owner: NO_REG_OWNER, dataClass: 'A', operation: 'storage', pseudonymized: false },
];

function selfTest() {
  return SELF_TEST_CONTEXTS.map((t) => {
    const decision = decidePlane(
      {
        dataClass: t.dataClass,
        operation: t.operation,
        owner: t.owner,
        pseudonymized: t.pseudonymized,
        shardKey: makeShardKey('userId', t.owner?.userId ?? 'unknown'),
      },
      { diagnostic: true, source: 'admin-selftest' },
    );
    return {
      label: t.label,
      dataClass: t.dataClass,
      operation: t.operation,
      pseudonymized: t.pseudonymized,
      ownerRegulation: decision.regulation,
      plane: decision.plane,
      ruleId: decision.ruleId,
      failClosed: decision.failClosed,
      crossBorder: decision.crossBorder,
      reason: decision.reason,
      // Честно: самотест выполняется чистой decidePlane и НЕ пишет в журнал.
      recorded: false,
    };
  });
}

/** Демонстрация обезличивания: синтетический payload (не данные реального пользователя). */
function pseudonymizeDemo() {
  const synthetic = {
    name: 'Иван Иванов (синтетическая демо-запись)',
    email: 'demo-pii@example.com',
    phone: '+7 000 000-00-00',
    birthday: '1990-01-01',
    ip: '192.0.2.1',
    location: 'Москва, Россия',
    bio: 'Профессиональные данные класса B: навыки и проекты остаются, PII удаляется.',
    skills: ['TypeScript', 'PostgreSQL'],
  };
  const owner = { userId: 'data-plane-selftest' };
  const result = pseudonymizeForGlobalCompute(synthetic, owner);
  return {
    note: 'Синтетический payload; обезличивание — SovereigntyGateway.minimizeForAI + pseudonymizeUser (read-only импорт из src/lib/sovereignty/gateway.ts, Task 9-d).',
    pseudonym: result.pseudonym,
    pseudonymMatchesDocFormat: /^anonymous_user_\d{5}$/.test(result.pseudonym),
    before: synthetic,
    after: result.payload,
    removedFields: ['email', 'phone', 'birthday', 'ip'].filter((f) => f in synthetic && !(f in result.payload)),
  };
}

// ---- Handler -----------------------------------------------------------------------

export async function GET(req: NextRequest) {
  const auth = await checkAuth(req);
  if (!auth.ok) return errorJson(auth.message, auth.status);

  const planes: DataPlaneId[] = DATA_PLANE_CONFIG.planes.map((p) => p.id);
  const ringStats = planes.map((p) => ringStatsForPlane(p, 200));
  const redistribution = planes.map((p) => redistributionForPlane(p));

  const recent = getRecentDecisions(10);
  const journal = decisionJournalStats();

  return json({
    ok: true,
    version: DATA_PLANE_CONFIG.version,
    timestamp: new Date().toISOString(),
    sandbox: DATA_PLANE_CONFIG.sandbox,
    topology: {
      planes: DATA_PLANE_CONFIG.planes,
      sharding: {
        algorithm: DATA_PLANE_CONFIG.sharding.algorithm,
        virtualNodesPerShard: DATA_PLANE_CONFIG.sharding.virtualNodesPerShard,
        defaultShardWeight: DATA_PLANE_CONFIG.sharding.defaultShardWeight,
        shardKeys: DATA_PLANE_CONFIG.sharding.shardKeys,
        // Все шарды sandbox указывают на одну локальную SQLite — честно ниже.
        shards: DATA_PLANE_CONFIG.sharding.shards.map((s) => ({
          id: s.id,
          weight: s.weight,
          plane: s.plane,
          virtualNodes: s.weight * DATA_PLANE_CONFIG.sharding.virtualNodesPerShard,
          target: s.target,
          sandboxLocal: true,
        })),
      },
    },
    ringStats,
    redistribution,
    residency: {
      activePolicy: {
        failClosedPlane: DATA_PLANE_CONFIG.residency.failClosedPlane,
        failClosedSemantics:
          'Нет правила / не выполнено требование обезличивания → данные маршрутизируются на ru-primary (никогда на global-compute по умолчанию).',
        rules: DATA_PLANE_CONFIG.residency.rules.map((r) => ({
          id: r.id,
          when: r.when,
          plane: r.plane,
          requiresPseudonymization: r.requiresPseudonymization,
          reason: r.reason,
        })),
      },
      journal: {
        ...journal,
        notice:
          recent.length === 0
            ? 'Журнал пуст: фасад DataPlaneRepository ещё не подключён к бизнес-потокам (миграционный путь — docs/data-plane.md). Записи появляются при реальных get/set/delete через фасад; журнал in-memory с TTL и переживает только процесс — это честное ограничение песочницы.'
            : 'Записи реальных операций фасада (source=repository); in-memory, TTL до часа.',
      },
      recentDecisions: recent,
      selfTest: selfTest(),
      pseudonymizeDemo: pseudonymizeDemo(),
    },
    repository: {
      interface: 'DataPlaneRepository (get/set/delete с контекстом entity/id/dataClass/owner)',
      binding: 'LocalSqliteBinding — единственная реализация; обе плоскости и все шарды биндятся на локальную SQLite через существующий Prisma-клиент (src/lib/db.ts)',
      entities: DATA_PLANE_ENTITIES,
      entityShardKeyKinds: Object.fromEntries(DATA_PLANE_ENTITIES.map((e) => [e, shardKeyKindForEntity(e)])),
      wiredIntoBusinessFlows: false,
      migrationNote: 'Фасад НЕ подключён к существующим API принудительно — подключение описано в docs/data-plane.md как путь миграции.',
    },
  });
}
