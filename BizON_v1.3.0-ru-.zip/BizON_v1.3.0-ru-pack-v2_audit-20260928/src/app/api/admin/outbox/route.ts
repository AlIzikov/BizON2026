// BizON API — /api/admin/outbox (Wave 6, S-143).
// POST — drain очереди Outbox→EventBus; GET — статистика.
// D-20 (R2-002): доступ только админ-сессия (роль admin) ИЛИ x-admin-token.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { opsGuard } from '@/lib/admin-guard';
import { OutboxService } from '@/lib/services/outbox-service';

export const runtime = 'nodejs';

export const GET = withRoute(async (req, ctx) => {
  const denied = await opsGuard(req);
  if (denied) return denied;
  return NextResponse.json(await OutboxService.stats());
}, { auth: false });

export const POST = withRoute(async (req, ctx) => {
  const denied = await opsGuard(req);
  if (denied) return denied;
  const result = await OutboxService.drain();
  return NextResponse.json(result);
}, { auth: false });
