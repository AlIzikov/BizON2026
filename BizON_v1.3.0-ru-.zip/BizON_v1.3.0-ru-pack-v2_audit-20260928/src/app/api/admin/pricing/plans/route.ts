// BizON API — R5.5 GET/POST /api/admin/pricing/plans (тарифный модуль).
//
// GET  — список тарифов с ТЕКУЩИМИ ценами во всех валютах + число активных
//        подписок (grandfathering-подсчёт: pricingPriceId + легаси tier-маппинг).
// POST — создать тариф (ТОЛЬКО admin: директива «изменение цены — только
//        role admin, не moderator»). Мультивалютность: цены заданы либо во
//        всех трёх валютах, либо ни в одной («по запросу»).
// Audit: pricing.plan.created (metadata currencies).
// Гейт: requireStaff (GET) / requireAdmin (POST), rate ADMIN_* (R5.5).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireStaff, requireAdmin } from '@/lib/admin-guard';
import { PricingService, CURRENCIES, INTERVALS, AUDIENCES } from '@/lib/services/pricing-service';

export const runtime = 'nodejs';

// amountMinor/trialDays — ШИРОКИЕ на схеме: границы цены (0..1M в основных
// единицах) и триала — СЕМАНТИЧЕСКИЕ правила (422 сервисом, API-007),
// не схемные 400. Ключи record проверяются на принадлежность CURRENCIES.
const priceSchema = z.object({
  amountMinor: z.number().int(),
  interval: z.enum(INTERVALS).default('month'),
  trialDays: z.number().int().optional(),
});

const createSchema = z
  .object({
    key: z.string().trim().regex(/^[a-z0-9_-]{2,64}$/, 'key: 2-64 символов a-z0-9_-'),
    name: z.string().trim().min(1).max(100),
    description: z.string().trim().max(500),
    audience: z.enum(AUDIENCES),
    features: z.array(z.string().max(200)).max(30).optional(),
    sortOrder: z.number().int().min(0).max(10_000).optional(),
    prices: z.record(z.string(), priceSchema).optional(),
  })
  .refine(
    (v) => !v.prices || Object.keys(v.prices).every((k) => (CURRENCIES as readonly string[]).includes(k)),
    { message: `Валюты: ${CURRENCIES.join(', ')}` },
  );

export const GET = withRoute(
  async (req) => {
    const staff = await requireStaff(req);
    if (!staff.ok) {
      return NextResponse.json({ error: staff.message }, { status: staff.status });
    }
    const plans = await PricingService.listAdminPlans();
    return NextResponse.json({ plans });
  },
  { rateLimit: { key: 'api:admin/pricing/plans:GET', ...RATE_CLASSES.ADMIN_READ } },
);

export const POST = withRoute(
  async (req, ctx) => {
    const admin = await requireAdmin(req);
    if (!admin.ok) {
      return NextResponse.json({ error: admin.message }, { status: admin.status });
    }
    const input = ctx.data as z.infer<typeof createSchema>;
    const plan = await PricingService.createPlan(
      {
        key: input.key,
        name: input.name,
        description: input.description,
        audience: input.audience,
        ...(input.features ? { features: input.features } : {}),
        ...(input.sortOrder !== undefined ? { sortOrder: input.sortOrder } : {}),
        ...(input.prices ? { prices: input.prices } : {}),
      },
      admin.user.id,
    );
    return NextResponse.json({ plan }, { status: 201 });
  },
  { schema: createSchema, rateLimit: { key: 'api:admin/pricing/plans:POST', ...RATE_CLASSES.ADMIN_WRITE } },
);
