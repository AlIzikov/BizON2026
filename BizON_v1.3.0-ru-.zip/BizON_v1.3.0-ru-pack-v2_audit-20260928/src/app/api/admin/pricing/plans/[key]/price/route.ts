// BizON API — R5.5 POST /api/admin/pricing/plans/[key]/price — СМЕНА ЦЕНЫ.
//
// Ядро тарифного модуля (директива): старая активная цена → validUntil = now,
// создаётся новая с validFrom = now (или с будущей даты — «за 30 дней»).
// История сохраняется; активные подписки НЕ меняются (grandfathering).
// Валидация цены: 0 ≤ amount ≤ 1 000 000 в основных единицах → иначе 422.
// Audit: pricing.price.changed (metadata before/after) — обязательно.
// Гейт: ТОЛЬКО requireAdmin (модератору менять цены запрещено — директива).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { PricingService, CURRENCIES, INTERVALS } from '@/lib/services/pricing-service';

export const runtime = 'nodejs';

const paramsSchema = z.object({
  key: z.string().regex(/^[a-z0-9_-]{2,64}$/),
});

// amountMinor/trialDays — ШИРОКИЕ на схеме: границы (0..1M основных единиц,
// trial 0..90) — СЕМАНТИЧЕСКИЕ правила (422 сервисом, API-007), не схемные 400.
const priceChangeSchema = z.object({
  currency: z.enum(CURRENCIES),
  amountMinor: z.number().int(),
  interval: z.enum(INTERVALS).default('month'),
  trialDays: z.number().int().optional(),
  // Дата вступления (default — сейчас). Будущая дата → подписчики получат
  // уведомление о грядущей смене заранее (директива: за 30 дней).
  validFrom: z.coerce.date().optional(),
});

export const POST = withRoute<{ key: string }>(
  async (req, ctx) => {
    const admin = await requireAdmin(req);
    if (!admin.ok) {
      return NextResponse.json({ error: admin.message }, { status: admin.status });
    }
    const input = ctx.data as z.infer<typeof priceChangeSchema>;
    const { previous, created } = await PricingService.changePrice(
      {
        planKey: ctx.params.key,
        currency: input.currency,
        amountMinor: input.amountMinor,
        interval: input.interval,
        ...(input.trialDays !== undefined ? { trialDays: input.trialDays } : {}),
        ...(input.validFrom ? { validFrom: input.validFrom } : {}),
      },
      admin.user.id,
    );
    return NextResponse.json(
      {
        previous: previous
          ? { id: previous.id, amountMinor: previous.amount, currency: previous.currency, closedAt: previous.validUntil }
          : null,
        created: { id: created.id, amountMinor: created.amount, currency: created.currency, interval: created.interval, validFrom: created.validFrom },
      },
      { status: 201 },
    );
  },
  { paramsSchema, schema: priceChangeSchema, rateLimit: { key: 'api:admin/pricing/plans/[key]/price:POST', ...RATE_CLASSES.ADMIN_WRITE } },
);
