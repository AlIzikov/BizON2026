// BizON API — R5.5 GET/PATCH/DELETE /api/admin/pricing/plans/[key].
//
// GET    — один тариф + ПОЛНАЯ история цен (validUntil not null = закрытые).
// PATCH  — метаданные (name/description/audience/features/sortOrder/active);
//          active=false — деактивация (скрыть тариф, подписки не трогаем).
// DELETE — удаление; ЕСТЬ АКТИВНЫЕ ПОДПИСКИ → 409 PLAN_HAS_ACTIVE_SUBSCRIPTIONS
//          (директива: только deactivate). Audit: pricing.plan.*.
// Гейт: requireStaff (GET) / requireAdmin (мутации).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireStaff, requireAdmin } from '@/lib/admin-guard';
import { PricingService, AUDIENCES } from '@/lib/services/pricing-service';

export const runtime = 'nodejs';

const paramsSchema = z.object({
  key: z.string().regex(/^[a-z0-9_-]{2,64}$/),
});

const patchSchema = z.object({
  name: z.string().trim().min(1).max(100).optional(),
  description: z.string().trim().max(500).optional(),
  audience: z.enum(AUDIENCES).optional(),
  features: z.array(z.string().max(200)).max(30).optional(),
  sortOrder: z.number().int().min(0).max(10_000).optional(),
  active: z.boolean().optional(),
});

export const GET = withRoute<{ key: string }>(
  async (req, ctx) => {
    const staff = await requireStaff(req);
    if (!staff.ok) {
      return NextResponse.json({ error: staff.message }, { status: staff.status });
    }
    const plan = await PricingService.getAdminPlan(ctx.params.key);
    return NextResponse.json({ plan });
  },
  { paramsSchema, rateLimit: { key: 'api:admin/pricing/plans/[key]:GET', ...RATE_CLASSES.ADMIN_READ } },
);

export const PATCH = withRoute<{ key: string }>(
  async (req, ctx) => {
    const admin = await requireAdmin(req);
    if (!admin.ok) {
      return NextResponse.json({ error: admin.message }, { status: admin.status });
    }
    const patch = ctx.data as z.infer<typeof patchSchema>;
    const plan = await PricingService.updatePlan(ctx.params.key, patch, admin.user.id);
    return NextResponse.json({ plan });
  },
  { paramsSchema, schema: patchSchema, rateLimit: { key: 'api:admin/pricing/plans/[key]:PATCH', ...RATE_CLASSES.ADMIN_WRITE } },
);

export const DELETE = withRoute<{ key: string }>(
  async (req, ctx) => {
    const admin = await requireAdmin(req);
    if (!admin.ok) {
      return NextResponse.json({ error: admin.message }, { status: admin.status });
    }
    const result = await PricingService.deletePlan(ctx.params.key, admin.user.id);
    return NextResponse.json(result);
  },
  { paramsSchema, rateLimit: { key: 'api:admin/pricing/plans/[key]:DELETE', ...RATE_CLASSES.ADMIN_WRITE } },
);
