// BizON API — R5.5 GET/POST /api/admin/pricing/promo — промокоды.
//
// GET  — список (staff): код, скидка, охват, использования, срок, статус.
// POST — создать (admin). Правила безопасности (директива):
//          - discountPercent > 100 → 422 PROMO_DISCOUNT_INVALID (семантика);
//          - fix-скидка требует currency;
//          - охват: planIds (JSON) или null = все тарифы.
// Audit: pricing.promo.created.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireStaff, requireAdmin } from '@/lib/admin-guard';
import { PricingService, CURRENCIES } from '@/lib/services/pricing-service';

export const runtime = 'nodejs';

// percent до 1000 на СХЕМЕ: превышение 100 — семантическое отклонение (422
// сервисом), а не схемная ошибка 400 — контракт теста директивы «150% → 422».
const createSchema = z
  .object({
    code: z.string().trim().regex(/^[A-Za-z0-9_-]{3,32}$/, 'code: 3-32 символов A-Z0-9_-'),
    discountPercent: z.number().int().min(1).max(1000).optional(),
    discountAmount: z.number().int().min(1).max(2_000_000_000).optional(),
    currency: z.enum(CURRENCIES).optional(),
    planIds: z.array(z.string().regex(/^[a-z0-9_-]{2,64}$/)).max(20).optional(),
    maxUses: z.number().int().min(1).max(100_000).optional(),
    validUntil: z.coerce.date().optional(),
  })
  .refine((v) => !(v.discountPercent !== undefined && v.discountAmount !== undefined), {
    message: 'Скидка задаётся ЛИБО percent, ЛИБО amount+currency',
  });

export const GET = withRoute(
  async (req) => {
    const staff = await requireStaff(req);
    if (!staff.ok) {
      return NextResponse.json({ error: staff.message }, { status: staff.status });
    }
    const promos = await PricingService.listPromos();
    return NextResponse.json({ promos });
  },
  { rateLimit: { key: 'api:admin/pricing/promo:GET', ...RATE_CLASSES.ADMIN_READ } },
);

export const POST = withRoute(
  async (req, ctx) => {
    const admin = await requireAdmin(req);
    if (!admin.ok) {
      return NextResponse.json({ error: admin.message }, { status: admin.status });
    }
    const input = ctx.data as z.infer<typeof createSchema>;
    const promo = await PricingService.createPromo(
      {
        code: input.code,
        ...(input.discountPercent !== undefined ? { discountPercent: input.discountPercent } : {}),
        ...(input.discountAmount !== undefined ? { discountAmount: input.discountAmount } : {}),
        ...(input.currency ? { currency: input.currency } : {}),
        ...(input.planIds ? { planIds: input.planIds } : {}),
        ...(input.maxUses !== undefined ? { maxUses: input.maxUses } : {}),
        ...(input.validUntil ? { validUntil: input.validUntil } : {}),
      },
      admin.user.id,
    );
    return NextResponse.json({ promo }, { status: 201 });
  },
  { schema: createSchema, rateLimit: { key: 'api:admin/pricing/promo:POST', ...RATE_CLASSES.ADMIN_WRITE } },
);
