// BizON API — R5.5 PATCH /api/admin/pricing/promo/[code] — вкл/выкл промокода.
// Audit: pricing.promo.toggled. Гейт: requireAdmin (мутации).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { PricingService } from '@/lib/services/pricing-service';

export const runtime = 'nodejs';

const paramsSchema = z.object({
  code: z.string().regex(/^[A-Za-z0-9_-]{3,32}$/),
});

const patchSchema = z.object({
  active: z.boolean(),
});

export const PATCH = withRoute<{ code: string }>(
  async (req, ctx) => {
    const admin = await requireAdmin(req);
    if (!admin.ok) {
      return NextResponse.json({ error: admin.message }, { status: admin.status });
    }
    const { active } = ctx.data as z.infer<typeof patchSchema>;
    const promo = await PricingService.togglePromo(ctx.params.code.toUpperCase(), active, admin.user.id);
    return NextResponse.json({ promo: { id: promo.id, code: promo.code, active: promo.active } });
  },
  { paramsSchema, schema: patchSchema, rateLimit: { key: 'api:admin/pricing/promo/[code]:PATCH', ...RATE_CLASSES.ADMIN_WRITE } },
);
