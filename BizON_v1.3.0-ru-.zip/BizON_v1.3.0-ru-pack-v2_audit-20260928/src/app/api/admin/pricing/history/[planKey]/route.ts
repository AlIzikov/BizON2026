// BizON API — R5.5 GET /api/admin/pricing/history/[planKey] — история цен.
// Дата | план | валюта | сумма | кто изменил (директива, секция 3).
// Гейт: requireStaff, rate ADMIN_READ.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { requireStaff } from '@/lib/admin-guard';
import { PricingService } from '@/lib/services/pricing-service';

export const runtime = 'nodejs';

const paramsSchema = z.object({
  planKey: z.string().regex(/^[a-z0-9_-]{2,64}$/),
});

export const GET = withRoute<{ planKey: string }>(
  async (req, ctx) => {
    const staff = await requireStaff(req);
    if (!staff.ok) {
      return NextResponse.json({ error: staff.message }, { status: staff.status });
    }
    const history = await PricingService.priceHistory(ctx.params.planKey);
    return NextResponse.json(history);
  },
  { paramsSchema, rateLimit: { key: 'api:admin/pricing/history:GET', ...RATE_CLASSES.ADMIN_READ } },
);
