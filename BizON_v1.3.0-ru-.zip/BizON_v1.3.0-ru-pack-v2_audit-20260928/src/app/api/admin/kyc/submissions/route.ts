// BizON API — GET /api/admin/kyc/submissions (R5-P1-REBUILD A1).
// Staff-роут: очередь KYC-заявок для ручного решения (пока провайдер stub).
// PII: email маскируется (канон u***@domain, maskEmail из email-service),
// документы каркас не собирает.
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { RATE_CLASSES } from '@/lib/with-route';
import { tryDecrypt } from '@/lib/security/crypto';
import { maskEmail } from '@/lib/services/email-service';

export const runtime = 'nodejs';

export const GET = withRoute(
  async (req, ctx) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });

    const url = new URL(req.url);
    const statusParam = url.searchParams.get('status');
    const status =
      statusParam && ['pending', 'approved', 'rejected', 'expired', 'canceled'].includes(statusParam)
        ? statusParam
        : undefined;

    const submissions = await db.kYCSubmission.findMany({
      where: status ? { status } : undefined,
      orderBy: { submittedAt: 'desc' },
      take: 100,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            emailEncrypted: true,
            verificationTier: true,
            accountType: true,
          },
        },
      },
    });

    // PII-минимизация: email только маскированный (u***@domain)
    const rows = submissions.map((s) => {
      let maskedEmail: string | null = null;
      if (s.user.emailEncrypted) {
        const plain = tryDecrypt(s.user.emailEncrypted);
        if (plain) maskedEmail = maskEmail(plain);
      }
      return {
        id: s.id,
        status: s.status,
        provider: s.provider,
        level: s.level,
        submittedAt: s.submittedAt.toISOString(),
        decidedAt: s.decidedAt?.toISOString() ?? null,
        decisionNote: s.decisionNote,
        user: {
          id: s.user.id,
          name: s.user.name,
          emailMasked: maskedEmail,
          verificationTier: s.user.verificationTier,
          accountType: s.user.accountType,
        },
      };
    });

    return NextResponse.json({ submissions: rows, total: rows.length, filter: status ?? 'all' });
  },
  { rateLimit: { key: 'api:admin:kyc:GET', ...RATE_CLASSES.ADMIN_READ } },
);
