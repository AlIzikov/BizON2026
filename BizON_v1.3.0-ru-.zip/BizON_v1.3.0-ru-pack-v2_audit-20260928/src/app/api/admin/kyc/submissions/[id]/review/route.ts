// BizON API — POST /api/admin/kyc/submissions/[id]/review (R5-P1-REBUILD A1).
// Admin-review KYC-заявки: approve → User.verificationTier = level
// (единственная точка повышения вместе с webhook); reject → отказ.
// AuditLog фиксирует решение (actorId = админ). Повторное решение → 409.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute, jsonError } from '@/lib/with-route';
import { requireAdmin } from '@/lib/admin-guard';
import { applyKycDecision } from '@/lib/services/kyc-service';
import { NotificationService } from '@/lib/services/notification-service';

export const runtime = 'nodejs';

const reviewSchema = z.object({
  decision: z.enum(['approved', 'rejected']),
  note: z.string().trim().max(1000).optional().nullable(),
});

export const POST = withRoute<{ id: string }>(
  async (req, ctx) => {
    const staff = await requireAdmin(req);
    if (!staff.ok) return NextResponse.json({ error: staff.message }, { status: staff.status });

    const body = reviewSchema.parse(ctx.data);

    const submission = await db.kYCSubmission.findUnique({ where: { id: ctx.params.id } });
    if (!submission) return jsonError(404, 'Заявка не найдена', 'NOT_FOUND');

    const result = await applyKycDecision({
      submissionId: submission.id,
      decision: body.decision,
      note: body.note ?? null,
      decidedById: staff.user.id,
    });
    if (result.notFound) return jsonError(404, 'Заявка не найдена', 'NOT_FOUND');
    if (result.conflict) return jsonError(409, 'Заявка уже обработана', 'ALREADY_DECIDED');

    // Уведомление пользователю о решении — fail-open
    try {
      void NotificationService.notifyMulti(submission.userId, {
        type: 'system',
        title:
          body.decision === 'approved'
            ? 'Верификация личности подтверждена'
            : 'Заявка на верификацию отклонена',
        body:
          body.decision === 'approved'
            ? `Ваш уровень верификации повышен: ${submission.level}`
            : body.note
              ? `Причина: ${body.note}`
              : 'Вы можете подать заявку повторно',
        link: '/settings',
        metadata: { kycSubmissionId: submission.id, source: 'kyc-admin-review' },
      });
    } catch {
      // fail-open
    }

    return NextResponse.json({
      ok: true,
      submission: {
        id: result.submission.id,
        status: result.submission.status,
        decidedAt: result.submission.decidedAt?.toISOString() ?? null,
      },
    });
  },
  {
    schema: reviewSchema,
    rateLimit: { key: 'api:admin:kyc:review', limit: 30, windowMs: 60_000 },
  },
);
