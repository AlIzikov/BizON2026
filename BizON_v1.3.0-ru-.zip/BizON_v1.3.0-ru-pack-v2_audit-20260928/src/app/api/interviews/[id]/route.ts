// BizON API — PATCH/DELETE /api/interviews/[id] (R5-P1-REBUILD C1).
//
// Жизненный цикл интервью (HR-сторона):
//   PATCH { status: 'completed'|'cancelled'|'no_show' } — завершить/отменить/неявка;
//   DELETE — отмена = то же, что PATCH status: 'cancelled' (синоним для UX).
// Отмена/завершение уведомляют кандидата (fail-open). IDOR-канон: чужое
// интервью → 404. Отменять/завершать можно только status='scheduled'.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute, jsonError } from '@/lib/with-route';
import { assertCompanyProfile, assertCompanyTwoFactor } from '@/lib/company-gate';
import { NotificationService } from '@/lib/services/notification-service';

export const runtime = 'nodejs';

const lifecycleSchema = z.object({
  status: z.enum(['completed', 'cancelled', 'no_show']),
});

const STATUS_TITLES: Record<string, string> = {
  completed: 'Интервью состоялось',
  cancelled: 'Интервью отменено',
  no_show: 'Интервью: неявка',
};

async function notify(
  userId: string,
  jobTitle: string,
  status: string,
  scheduledAt: Date,
): Promise<void> {
  try {
    const when = scheduledAt.toLocaleString('ru-RU', { dateStyle: 'long', timeStyle: 'short' });
    void NotificationService.notifyMulti(userId, {
      type: 'interview_scheduled',
      title: `${STATUS_TITLES[status] ?? 'Статус интервью'}: «${jobTitle}»`,
      body: `Было запланировано на ${when}`,
      link: '/jobs',
      metadata: { jobTitle, kind: status, source: 'interview-lifecycle' },
    });
  } catch {
    // fail-open
  }
}

// PATCH — завершить/отменить/no_show
export const PATCH = withRoute<{ id: string }>(
  async (req, ctx) => {
    const user = ctx.user!;
    assertCompanyProfile(user); // 422
    assertCompanyTwoFactor(user); // 403 (A2)

    const body = lifecycleSchema.parse(ctx.data);

    const interview = await db.interview.findUnique({
      where: { id: ctx.params.id },
      include: { job: { select: { id: true, title: true } } },
    });
    if (!interview) return jsonError(404, 'Интервью не найдено', 'NOT_FOUND');
    // IDOR-канон
    if (interview.companyId !== user.companyId) {
      return jsonError(404, 'Интервью не найдено', 'NOT_FOUND');
    }
    if (interview.status !== 'scheduled') {
      return jsonError(409, 'Интервью уже в финальном статусе', 'INTERVIEW_ALREADY_FINAL');
    }

    const updated = await db.interview.update({
      where: { id: interview.id },
      data: { status: body.status },
    });

    await notify(interview.userId, interview.job.title, body.status, interview.scheduledAt);

    return NextResponse.json({
      ok: true,
      interview: { id: updated.id, status: updated.status },
    });
  },
  {
    schema: lifecycleSchema,
    rateLimit: { key: 'api:interviews:PATCH', limit: 30, windowMs: 60_000 },
  },
);

// DELETE — отменить интервью (синоним PATCH status='cancelled')
export const DELETE = withRoute<{ id: string }>(
  async (req, ctx) => {
    const user = ctx.user!;
    assertCompanyProfile(user);
    assertCompanyTwoFactor(user);

    const interview = await db.interview.findUnique({
      where: { id: ctx.params.id },
      include: { job: { select: { id: true, title: true } } },
    });
    if (!interview) return jsonError(404, 'Интервью не найдено', 'NOT_FOUND');
    if (interview.companyId !== user.companyId) {
      return jsonError(404, 'Интервью не найдено', 'NOT_FOUND');
    }
    if (interview.status !== 'scheduled') {
      return jsonError(409, 'Интервью уже в финальном статусе', 'INTERVIEW_ALREADY_FINAL');
    }

    const updated = await db.interview.update({
      where: { id: interview.id },
      data: { status: 'cancelled' },
    });

    await notify(interview.userId, interview.job.title, 'cancelled', interview.scheduledAt);

    return NextResponse.json({
      ok: true,
      interview: { id: updated.id, status: updated.status },
    });
  },
  { rateLimit: { key: 'api:interviews:DELETE', limit: 30, windowMs: 60_000 } },
);
