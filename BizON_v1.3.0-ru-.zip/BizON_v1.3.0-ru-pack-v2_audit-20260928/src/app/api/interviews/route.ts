// BizON API — GET /api/interviews (R5-P1-REBUILD C1).
//
// Список интервью, ветвление по роли:
//   - company/hr_agency: интервью по вакансиям СВОЕЙ компании (422 без Company);
//   - individual: собственные интервью (кандидатская сторона).
// 2FA-гейт НЕ применяется к чтению (канон A2: мягко-обязательная — гейтится запись).
// PII-минимизация: компании видят только публичные поля кандидата.
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/with-route';
import { assertCompanyProfile, isCompanyAccount } from '@/lib/company-gate';
import { RATE_CLASSES } from '@/lib/with-route';

export const runtime = 'nodejs';

export const GET = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;
    const url = new URL(req.url);
    const scope = url.searchParams.get('scope') === 'past' ? 'past' : 'upcoming';

    if (isCompanyAccount(user.accountType)) {
      assertCompanyProfile(user); // 422 без Company-записи
      const rows = await db.interview.findMany({
        where: {
          companyId: user.companyId!,
          ...(scope === 'upcoming'
            ? { status: 'scheduled', scheduledAt: { gte: new Date() } }
            : { OR: [{ status: { not: 'scheduled' } }, { scheduledAt: { lt: new Date() } }] }),
        },
        orderBy: scope === 'upcoming' ? { scheduledAt: 'asc' } : { scheduledAt: 'desc' },
        take: 100,
        include: {
          user: {
            select: { id: true, name: true, title: true, avatarUrl: true, location: true, level: true },
          },
          job: { select: { id: true, title: true } },
        },
      });
      return NextResponse.json({
        role: 'company',
        scope,
        interviews: rows.map((i) => ({
          id: i.id,
          applicationId: i.applicationId,
          scheduledAt: i.scheduledAt.toISOString(),
          durationMin: i.durationMin,
          format: i.format,
          locationOrLink: i.locationOrLink,
          note: i.note,
          status: i.status,
          job: { id: i.job.id, title: i.job.title },
          candidate: { id: i.user.id, name: i.user.name, title: i.user.title, avatarUrl: i.user.avatarUrl, location: i.user.location, level: i.user.level },
        })),
      });
    }

    // Кандидатская сторона: свои интервью
    const rows = await db.interview.findMany({
      where: { userId: user.id },
      orderBy: { scheduledAt: 'desc' },
      take: 100,
      include: { job: { select: { id: true, title: true } } },
    });
    return NextResponse.json({
      role: 'candidate',
      scope: 'all',
      interviews: rows.map((i) => ({
        id: i.id,
        applicationId: i.applicationId,
        scheduledAt: i.scheduledAt.toISOString(),
        durationMin: i.durationMin,
        format: i.format,
        locationOrLink: i.locationOrLink,
        note: i.note,
        status: i.status,
        job: { id: i.job.id, title: i.job.title },
      })),
    });
  },
  { rateLimit: { key: 'api:interviews:GET', ...RATE_CLASSES.USER_READ } },
);
