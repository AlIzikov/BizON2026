// BizON API — POST /api/ai-co-pilot (A6, STUBS-AUDIT-2026-09-10)
//
// Плавающий ассистент «AI Co-Pilot»: раньше отвечал client-side по keyword
// includes() с фейковой задержкой 500мс — теперь реальный LLM через ЕДИНЫЙ
// шлюз AIGateway (rate limit, SHA-256 кэш, Data Sovereignty минимизация PII,
// Circuit Breaker / Backpressure, fallback-цепочка).
//
// Честность платформы (конвенция): если LLM недоступен — отдаём canned-ответ
// локальной эвристики, но помечаем provider='heuristic'; UI показывает бейдж
// «Автоответ без AI». Детерминистику нельзя выдавать за AI.
//
// SDK z-ai-web-dev-sdk инстанцируется ТОЛЬКО в src/lib/ai-core/zai-client.ts;
// здесь — только llm-колбэк гейтвея (REUSE-first, никаких новых инстансов).

import { z } from 'zod';
import { db } from '@/lib/db';
import { json, errorJson, withRoute, jsonError } from '@/lib/api-helpers';
import { buildUserContext, AIGateway } from '@/lib/ai-core';
import { getZaiClient } from '@/lib/ai-core/zai-client';

export const runtime = 'nodejs';

// --- Inline-валидация (сознательно НЕ в общем src/lib/validation.ts) ---
const copilotBodySchema = z.object({
  message: z
    .string()
    .trim()
    .min(1, 'Сообщение не может быть пустым')
    .max(2000, 'Сообщение слишком длинное (максимум 2000 символов)'),
  history: z
    .array(
      z.object({
        role: z.enum(['user', 'assistant']),
        content: z.string().max(1000),
      })
    )
    .max(12)
    .optional(),
});

type CopilotBody = z.infer<typeof copilotBodySchema>;

// --- Ответ Co-Pilot: текст + честный провайдер ---
type CopilotReply = { text: string; provider: 'llm' | 'heuristic' };

// --- Краткий профиль пользователя для промпта ---
type CopilotProfile = {
  name: string;
  title: string | null;
  roles: string[];
  level: string;
  ipScore: number;
  topSkills: { name: string; level: number; verificationLevel: string }[];
  connectionsCount: number;
};

/** Топ-скиллы: сначала подтверждённые, по уровню; максимум 8. */
function topSkills(skills: CopilotProfile['topSkills']): CopilotProfile['topSkills'] {
  const rank = (v: string) => (v === 'verified' ? 0 : v === 'endorsed' ? 1 : 2);
  return [...skills]
    .sort((a, b) => rank(a.verificationLevel) - rank(b.verificationLevel) || b.level - a.level)
    .slice(0, 8);
}

function buildSystemPrompt(profile: Record<string, unknown>, researchContext?: string): string {
  const researchBlock = researchContext
    ? [
        '',
        'РЕЗУЛЬТАТЫ ИССЛЕДОВАНИЯ ПОЛЬЗОВАТЕЛЯ (тесты-опросники: профессия, предпочтения, внутренние мотиваторы):',
        researchContext,
        'Учитывай эти данные как контрольные: они показывают, что человеку важно, чем он живёт и что ищет — в том числе нематериальные критерии.',
      ].join('\n')
    : '';
  return [
    'Ты — AI Co-Pilot платформы BizON — русскоязычной профессиональной сети доверия («Не говори, кто ты — докажи это»).',
    'Отвечай по-русски, кратко (до 120 слов), дружелюбно и по делу, на «вы».',
    'Учитывай профиль пользователя ниже (он обезличен Data Sovereignty Gateway: имя заменено псевдонимом — не упоминай его).',
    'Опирайся только на факты профиля и реальные возможности платформы BizON: IP-score и капитал доверия, подтверждение навыков (Professional Evidence), проекты, AI-Matchmaker (путь к человеку через рукопожатия), AI-Career (карьерные траектории), лента, вакансии, компании, люмены (внутренняя валюта).',
    'Не выдумывай функции платформы; если данных недостаточно — подскажи, в каком разделе BizON искать ответ.',
    'Не давай финансовых/юридических гарантий; платформа не решает за пользователя — предлагай и объясняй.',
    '',
    'ПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ (JSON):',
    JSON.stringify(profile),
    researchBlock,
  ].join('\n');
}

// --- Локальная эвристика (fallback): порт прежних canned-ответов из UI ---
function heuristicCopilotAnswer(message: string, profile: CopilotProfile): CopilotReply {
  const q = message.toLowerCase();
  let text: string;

  if (q.includes('ip-score') || q.includes('рейтинг') || q.includes('доверие')) {
    text =
      `Ваш IP-score: ${profile.ipScore}. Чтобы расти:\n` +
      '• Завершайте проекты (+8)\n' +
      '• Подтверждайте навыки через проекты (+5)\n' +
      '• Добавляйте связи (+3)\n' +
      '• Публикуйте посты (+1)';
  } else if (q.includes('найти') || q.includes('контакт') || q.includes('связь')) {
    text = 'Используйте AI-Matchmaker — он найдёт путь к нужному человеку через 5 рукопожатий. Перейдите в раздел «AI-Поиск».';
  } else if (q.includes('проект')) {
    text = 'Создайте проект в разделе «Проекты». Каждый участник подтвердит ваше участие — это поднимет ваш IP-score.';
  } else if (q.includes('карьер') || q.includes('ваканси')) {
    text = 'AI-Career-Agent построит карьерную траекторию. Перейдите в «AI-Карьера» в разделе «Ещё».';
  } else {
    text =
      'Я помогу с:\n' +
      '• Рост IP-score\n' +
      '• Поиск контактов\n' +
      '• Создание проектов\n' +
      '• Карьерные рекомендации\n\n' +
      'Что вас интересует?';
  }
  return { text, provider: 'heuristic' };
}

// --- LLM-вызов (единственное место обращения к модели — внутри llm-колбэка гейтвея) ---
async function callCopilotLlm(
  minimizedProfile: Record<string, unknown>,
  message: string,
  history: NonNullable<CopilotBody['history']>,
  researchContext?: string,
): Promise<CopilotReply | null> {
  const zai = await getZaiClient();
  if (!zai) return null; // → fallback гейтвея (heuristic)
  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: buildSystemPrompt(minimizedProfile, researchContext) },
        ...history.map((h) => ({ role: h.role, content: h.content })),
        { role: 'user', content: message },
      ],
      thinking: { type: 'disabled' },
      temperature: 0.6,
      max_tokens: 500,
    });
    const text = String(completion?.choices?.[0]?.message?.content ?? '').trim();
    if (!text) return null; // пустой ответ модели — не фейковый «успех»
    return { text: text.slice(0, 4000), provider: 'llm' };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error(`[ai-co-pilot] LLM error: ${msg.slice(0, 200)}`);
    return null; // → fallback гейтвея (heuristic)
  }
}

export const POST = withRoute(
  async (_req, ctx) => {
    const user = ctx.user!;

    // 1. Inline-валидация (400 от withRoute-схемы не подходит — контракт 422)
    const parsed = copilotBodySchema.safeParse(ctx.data);
    if (!parsed.success) {
      const summary = parsed.error.issues
        .slice(0, 3)
        .map((i) => i.message)
        .join('; ');
      return jsonError(422, `Проверьте сообщение: ${summary}`);
    }
    const { message, history } = parsed.data;

    // 2. Краткий профиль (REUSE: buildUserContext с кэшем 5 мин) + roles
    const ctxUser = await buildUserContext(user.id);
    if (!ctxUser) return errorJson('Профиль не найден', 404);
    const rolesRow = await db.user.findUnique({
      where: { id: user.id },
      select: { roles: true },
    });
    const profile: CopilotProfile = {
      name: ctxUser.name,
      title: ctxUser.title,
      roles: (rolesRow?.roles ?? '')
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 5),
      level: ctxUser.level,
      ipScore: ctxUser.ipScore,
      topSkills: topSkills(ctxUser.skills),
      connectionsCount: ctxUser.connectionsCount,
    };

    // 3. Волна D: результаты «Исследования» подмешиваем в контекст Co-Pilot
    //    (контрольные данные: что человеку нужно, чем живёт, что ищет)
    let researchContext: string | undefined;
    try {
      const research = await db.researchResult.findMany({
        // только осознанные неистёкшие сигналы (schema: consent = «явное согласие использовать в AI-контурах»)
        where: { userId: user.id, consent: true, expiresAt: { gt: new Date() } },
        orderBy: { capturedAt: 'desc' },
        select: { kind: true, score: true },
        take: 3,
      });
      if (research.length > 0) {
        researchContext = research
          .map(
            (r) =>
              `- Study "${r.kind}": score ${r.score !== null ? `${Math.round(r.score * 100)}/100` : '—'}`,
          )
          .join('\n');
      }
    } catch {
      // исследование — обогащение: сбой чтения не должен ломать Co-Pilot
    }

    // 4. Единый AI-шлюз: rate limit, кэш, Sovereignty-минимизация, fallback
    const shortHistory = (history ?? []).slice(-6);
    const result = await AIGateway.run<CopilotReply>({
      userId: user.id,
      operation: 'ai.copilot',
      fields: ['name', 'title'],
      priority: 'normal',
      cacheTtlMs: 10 * 60 * 1000,
      data: profile as unknown as Record<string, unknown>,
      payload: { message, history: shortHistory },
      llm: (minimized) => callCopilotLlm(minimized, message, shortHistory, researchContext),
      fallback: () => heuristicCopilotAnswer(message, profile),
    });
    if (!result) return errorJson('Слишком много запросов к AI Co-Pilot. Попробуйте позже.', 429);

    return json({
      reply: result.value.text,
      provider: result.value.provider, // 'llm' | 'heuristic' — UI помечает «Автоответ без AI»
      cached: result.cached,
    });
  },
  {
    // Rate limit: 10 запросов / 10 минут на пользователя (демо-сессия инжектится middleware)
    rateLimit: { key: 'ai-copilot', limit: 10, windowMs: 10 * 60 * 1000 },
  },
);
