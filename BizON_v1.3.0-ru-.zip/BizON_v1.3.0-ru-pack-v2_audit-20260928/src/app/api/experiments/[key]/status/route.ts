// BizON API — R4: статус эксперимента (GET /api/experiments/[key]/status).
// USER_READ — живая сводка для Slack /resonance status и дашборда.
import { z } from 'zod';
import { json } from '@/lib/api-helpers';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { ExperimentService } from '@/lib/services/experiment-service';

export const runtime = 'nodejs';

const paramsSchema = z.object({ key: z.string().min(1).max(80) });

export const GET = withRoute(async (_req, { params }) => {
  const { key } = params as z.infer<typeof paramsSchema>;
  const status = await ExperimentService.status(key);
  return json(status);
}, {
  paramsSchema,
  rateLimit: {
    key: 'experiments:status',
    limit: RATE_CLASSES.USER_READ.limit,
    windowMs: RATE_CLASSES.USER_READ.windowMs,
  },
});
