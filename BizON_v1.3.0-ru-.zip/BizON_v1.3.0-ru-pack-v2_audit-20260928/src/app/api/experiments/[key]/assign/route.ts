// BizON API — R4: назначение пользователя на вариант (GET /api/experiments/[key]/assign).
// GET (не мутация: назначение детерминировано хешем) — USER_READ.
import { z } from 'zod';
import { json } from '@/lib/api-helpers';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { ExperimentService } from '@/lib/services/experiment-service';

export const runtime = 'nodejs';

const paramsSchema = z.object({ key: z.string().min(1).max(80) });

export const GET = withRoute(async (_req, { user, params }) => {
  const { key } = params as z.infer<typeof paramsSchema>;
  const result = await ExperimentService.assign(key, user.id);
  return json(result);
}, {
  paramsSchema,
  rateLimit: {
    key: 'experiments:assign',
    limit: RATE_CLASSES.USER_READ.limit,
    windowMs: RATE_CLASSES.USER_READ.windowMs,
  },
});
