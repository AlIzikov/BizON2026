// BizON API — /api/auth/audit-login (AUDIT MODE, внешний аудит по запросу владельца)
//
// Назначение: вход в МАКСИМАЛЬНЫЙ аккаунт (роль admin) БЕЗ логина и пароля —
// для внешнего аудита всех открытых функций платформы.
//
// Два метода:
//   GET  → { enabled: boolean } — публичная проверка, включён ли аудит-режим
//          (AuthScreen показывает кнопку только при enabled; без PII).
//   POST → создаёт настоящую сессию admin-аккаунта и ставит HttpOnly cookie.
//
// Безопасность (честный fail-closed):
//   • POST работает ТОЛЬКО при BIZON_AUDIT_AUTH=1 (env); иначе 404
//     AUDIT_MODE_DISABLED — режим как будто не существует (без раскрытия).
//   • 2FA осознанно обходится: это и есть смысл аудит-доступа (пароль/код не
//     запрашиваются). Сессия помечена userAgent='AUDIT-MODE' — видна в списке
//     «Активные сессии» и НЕ удаляется при logout (/api/auth/logout), чтобы
//     middleware мог подставить её следующему аудитору.
//   • Каждый вход пишется в AuditLog (action 'audit-login') — проверяемый след.
//   • Включение/ротация токена: scripts/ensure-audit-admin.ts. Выключение:
//     BIZON_AUDIT_AUTH=0 в .env. В PRODUCTION включать ЗАПРЕЩЕНО.
import { db } from '@/lib/db';
import { setSessionCookie } from '@/lib/auth';
import { json, jsonError, toUserSelfView, withRoute, RATE_CLASSES } from '@/lib/api-helpers';
import { generateToken, hashSessionToken } from '@/lib/security/session-token';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

const AUDIT_TTL_HOURS = 24 * 30; // 30 дней — согласовано с TTL audit-сессии в .env-сценарии

function auditEnabled(): boolean {
  return (process.env as Record<string, string | undefined>)['BIZON_AUDIT_AUTH'] === '1';
}

export const GET = withRoute(
  async () => {
    return json({ enabled: auditEnabled() });
  },
  { auth: false, rateLimit: { key: 'auth.audit.status', ...RATE_CLASSES.PUBLIC_READ } },
);

export const POST = withRoute(
  async (req) => {
    if (!auditEnabled()) {
      // Честный fail-closed: режим выключен → 404 (как несуществующий роут).
      return jsonError(404, 'Аудит-режим выключен', 'AUDIT_MODE_DISABLED');
    }

    // Максимальный аккаунт: точный токен 'admin' в CSV roles, живой (не blocked/deleted).
    // Старейший первым — детерминированный выбор (аккаунт «Владелец BizON»).
    const candidates = await db.user.findMany({
      where: { roles: { contains: 'admin' } },
      orderBy: { createdAt: 'asc' },
    });
    const admin = candidates
      .filter((u) => !u.blockedAt && !u.deletedAt)
      .find((u) => u.roles.split(',').map((r) => r.trim()).includes('admin'));

    if (!admin) {
      // Режим включён, но admin-аккаунта нет — честная 503 (инфраструктурная
      // проблема), не маскируем под 401/404, чтобы аудит это увидел.
      return jsonError(503, 'Аудит-режим включён, но admin-аккаунт не найден. Запустите scripts/ensure-audit-admin.ts', 'AUDIT_ADMIN_MISSING');
    }

    // Осознанный обход 2FA — смысл аудит-доступа (комментарий держим честным).
    const token = generateToken();
    await db.session.create({
      data: {
        userId: admin.id,
        token: hashSessionToken(token),
        expiresAt: new Date(Date.now() + AUDIT_TTL_HOURS * 60 * 60 * 1000),
        userAgent: 'AUDIT-MODE (external audit)',
        lastUsedAt: new Date(),
      },
    });
    await setSessionCookie(token);

    AuditLog.log({
      actorId: admin.id,
      action: 'audit-login',
      resource: 'user:session',
      resourceId: admin.id,
      metadata: { method: 'audit-mode', twoFactor: 'bypassed-by-audit-mode' },
    });

    const publicUser = await toUserSelfView(admin);
    return json({ user: publicUser });
  },
  {
    auth: false,
    // 5/мин достаточно: кнопка аудита нажимается один раз за сессию браузера
    rateLimit: { key: 'auth.audit.login', ...RATE_CLASSES.AUTH_STRICT, limit: 5 },
  },
);
