// BizON API — /api/auth/forgot-password (R5-4a C25: запрос сброса пароля)
//
// POST { email } → ВСЕГДА 200 { sent: true } — существование аккаунта не
// раскрывается (no user enumeration): письмо реально уходит только
// существующему активному пользователю, для остальных ответ неотличим.
// Письмо — sendTemplateEmail('reset_password', { url: {APP_URL}/reset-password?token=… }).
// withRoute auth:false: CSRF origin-гейт действует (login-CSRF класс вектора),
// AUTH_STRICT 10/мин (канон auth-мутаций; ТЗ допускало 5/час — AUTH_STRICT ок).
import { z } from 'zod';
import { AuthService } from '@/lib/services';
import { json, withRoute, RATE_CLASSES } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const forgotPasswordSchema = z
  .object({
    email: z.string().trim().email().max(320),
  })
  .strict();

export const POST = withRoute(
  async (_req, ctx) => {
    const { email } = ctx.data as { email: string };
    // Ответ одинаковый независимо от существования email (сервис молчит)
    await AuthService.requestPasswordReset(email);
    return json({ sent: true });
  },
  {
    auth: false,
    schema: forgotPasswordSchema,
    rateLimit: { key: 'auth.forgot-password', ...RATE_CLASSES.AUTH_STRICT },
  },
);
