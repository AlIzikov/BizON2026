// BizON API — /api/auth/resend-verification (R5-4a C24: повторное письмо
// подтверждения email)
//
// POST (требуется сессия) — создаёт новый email_verify-токен (TTL 24ч) и шлёт
// шаблон 'verify_email' через sendTemplateEmail (PII: email берётся из БД по
// userId, расшифровка внутри email-service).
// Антифлуд:
//   - User.lastVerificationEmailAt: NULL или старше 1 часа, иначе
//     429 VERIFICATION_EMAIL_COOLDOWN (промышленный лимит повторов);
//   - с влагой lastVerificationEmailAt=now записывается ДО отправки (слот
//     занят честно, даже если транспорт упал — иначе гонка повторов);
//   - + withRoute AUTH_STRICT 10/мин (канон auth-мутаций).
// Ответ честный: { ok, sent } — sent=false значит транспорт не отправил.
import { db } from '@/lib/db';
import { json, jsonError, withRoute, RATE_CLASSES } from '@/lib/api-helpers';
import { createEmailVerificationToken, appUrl } from '@/lib/services/verification-token';
import { sendTemplateEmail } from '@/lib/services/email-service';

export const runtime = 'nodejs';

const RESEND_COOLDOWN_MS = 60 * 60 * 1000; // 1 час между письмами подтверждения

export const POST = withRoute(
  async (_req, ctx) => {
    const sessionUser = ctx.user;

    // Свежие значения из БД (сессия может быть выдана до последнего статуса:
    // верификация могла произойти в другом браузере/окне)
    const row = await db.user.findUnique({
      where: { id: sessionUser.id },
      select: { emailVerified: true, lastVerificationEmailAt: true },
    });
    if (!row) {
      return jsonError(404, 'Пользователь не найден', 'NOT_FOUND');
    }

    if (row.emailVerified) {
      return jsonError(400, 'Email уже подтверждён', 'EMAIL_ALREADY_VERIFIED');
    }

    const last = row.lastVerificationEmailAt ? new Date(row.lastVerificationEmailAt).getTime() : 0;
    if (last && Date.now() - last < RESEND_COOLDOWN_MS) {
      return jsonError(
        429,
        'Письмо с подтверждением уже отправлено. Повторная отправка возможна не раньше, чем через час.',
        'VERIFICATION_EMAIL_COOLDOWN',
      );
    }

    // Занимаем слот до отправки (повтор в пределах часа невозможен, даже параллельный)
    await db.user.update({
      where: { id: sessionUser.id },
      data: { lastVerificationEmailAt: new Date() },
    });

    const { token } = await createEmailVerificationToken(sessionUser.id);
    const verifyUrl = `${appUrl()}/api/auth/verify-email?token=${token}`;
    const sendRes = await sendTemplateEmail(sessionUser.id, 'verify_email', { url: verifyUrl });

    return json({ ok: true, sent: sendRes.ok });
  },
  {
    rateLimit: { key: 'auth.resend-verification', ...RATE_CLASSES.AUTH_STRICT },
  },
);
