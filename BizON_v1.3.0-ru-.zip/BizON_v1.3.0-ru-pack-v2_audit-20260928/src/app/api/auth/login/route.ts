// BizON API — /api/auth/login
// Использует AuthService + Rate Limiter (IP flood) + экспоненциальный backoff.
//
// API-003/004/027 (аудит 22-09-26, W1/29-c): роут переведён на withRoute
// ({ auth: false, schema: loginSchema, rateLimit: RATE_CLASSES.AUTH_STRICT }).
// СОХРАНЕНО 1:1 (Repository Truth, прежний route.ts):
//   - FIX-03 (P0-4): 2FA-пользователь получает { twoFactorRequired: true,
//     tempToken } (TTL 5 мин) БЕЗ создания сессии; полный cookie только на
//     /api/auth/2fa/verify;
//   - FIX-03 (P1-7): экспоненциальный backoff LoginBackoff на паре IP+email
//     (1с → 2с → 4с … кап 15 мин), reset при успехе, recordFailure при
//     «Неверный…» → 401 с сообщением о задержке;
//   - setSessionCookie(token) + AuditLog.log (H13, method: 'password' /
//     twoFactor: 'challenge-issued') + ответ { user: toUserSelfView(user) };
//   - статус-коды: 200 (успех/2FA-challenge), 401 (неверные креды),
//     429 (IP-flood и backoff), 500 (прочее).
//   - IP-flood лимит: прежний 10/мин (LOGIN_RATE_LIMIT) → пресет
//     RATE_CLASSES.AUTH_STRICT, ключ 'auth.login' (per-IP, TRUST_PROXY-aware).
// ИЗМЕНЕНО (стандартизация контракта, API-004/005/006):
//   - строгая zod-схема: email trim + ≤320, password 1..256; лишние поля
//     (strict) и неверные типы → 400 VALIDATION_ERROR (раньше отсутствующие
//     email/password давали 422 «Email и пароль обязательны», невалидный JSON
//     тихо превращался в 422 — теперь честный 400 с fieldErrors);
//   - 429 от IP-flood получает code: 'RATE_LIMITED' + retry-after заголовок;
//   - все ответы: { error: string } + code/requestId/x-request-id (аддитивно).
//
// FIX-03 (P0-4): если у пользователя включена 2FA — после проверки пароля
// сессия НЕ выдаётся. Вместо неё возвращается одноразовый short-lived
// tempToken (TTL 5 мин) → клиент обязан отправить TOTP/backup-код на
// POST /api/auth/2fa/verify, и только там создаётся настоящая сессия.
//
// FIX-03 (P1-7): вместо жёсткой блокировки аккаунта по email (5 неудач → 15 мин
// блок — атакующий мог «залочить» жертву, зная её email) — экспоненциальный
// backoff на паре IP+email: 1с → 2с → 4с → … кап 15 минут. Задержка исчезает
// сама, жертва с другого IP не страдает, brute-force всё равно невозможен.
import { z } from 'zod';
import { AuthService } from '@/lib/services';
import { setSessionCookie } from '@/lib/auth';
import { json, jsonError, toUserSelfView, withRoute, RATE_CLASSES } from '@/lib/api-helpers';
import { getClientIp, LoginBackoff, loginBackoffKey } from '@/lib/security/rate-limiter';
import { create2FATempToken } from '@/lib/services/totp-service';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { sessionMetaFromRequest } from '@/lib/security/session-meta';
import { companyNeedsTwoFactor } from '@/lib/company-gate';

export const runtime = 'nodejs';

// API-004: строгая схема логина. strict() — неизвестные поля отклоняются
// (400), email нормализуется trim'ом, пароль ограничен 1..256 (совпадает с
// ограничениями регистрации и защитой от DoS на verifyPassword).
const loginSchema = z
  .object({
    email: z.string().trim().email().max(320),
    password: z.string().min(1).max(256),
  })
  .strict();

export const POST = withRoute(
  async (req, ctx) => {
    const { email, password } = ctx.data as { email: string; password: string };
    const ip = getClientIp(req);

    // FIX-03 (P1-7): экспоненциальный backoff на паре IP+email.
    const backoffKey = loginBackoffKey(ip, email);
    const backoff = LoginBackoff.check(backoffKey);
    if (!backoff.allowed) {
      return jsonError(
        429,
        `Слишком много неудачных попыток входа. Повторите через ${backoff.retryAfterSec} секунд.`,
        'RATE_LIMITED',
      );
    }

    try {
      const user = await AuthService.login(email, password);
      // Успешный вход — сбрасываем серию неудач
      LoginBackoff.reset(backoffKey);

      // FIX-03 (P0-4): при включённой 2FA НЕ выдаём сессию по одному паролю.
      // Выдаём одноразовый tempToken (TTL 5 мин) — полный session cookie
      // создаётся только в /api/auth/2fa/verify после проверки TOTP/backup-кода.
      if (user.twoFactorEnabled) {
        const tempToken = create2FATempToken(user.id);
        AuditLog.log({
          actorId: user.id,
          action: 'login',
          resource: 'user:session',
          resourceId: user.id,
          ip,
          metadata: { method: 'password', twoFactor: 'challenge-issued' },
        });
        return json({ twoFactorRequired: true, tempToken });
      }

      const token = await AuthService.createSession(user.id, sessionMetaFromRequest(req));
      await setSessionCookie(token);

      // H13: Audit log — фиксируем факт доступа к PII (152-ФЗ ст. 19)
      AuditLog.log({
        actorId: user.id,
        action: 'login',
        resource: 'user:session',
        resourceId: user.id,
        ip,
        metadata: { method: 'password' },
      });

      const publicUser = await toUserSelfView(user);
      // A2 (R5-P1-REBUILD): обязательная 2FA для company/hr_agency — флаг для
      // клиентского баннера «Включите 2FA» до первой успешной публикации.
      // Демо-аккаунты (@bizon.demo) вне гейта (общий доступ на демонстрациях).
      const twoFactorSetupRequired = companyNeedsTwoFactor(user, email);
      return json({ user: publicUser, twoFactorSetupRequired });
    } catch (loginError: any) {
      if (loginError?.message?.includes('Неверный')) {
        // FIX-03: неудача → наращиваем backoff (1с, 2с, 4с … кап 15 мин)
        const st = LoginBackoff.recordFailure(backoffKey);
        return jsonError(
          401,
          `Неверный email или пароль. Следующая попытка через ${st.retryAfterSec} с.`,
          'AUTH_REQUIRED',
        );
      }
      throw loginError;
    }
  },
  {
    auth: false,
    schema: loginSchema,
    // API-027: класс AUTH_STRICT (10/мин) — тот же лимит, что прежний
    // checkRateLimit(req, 'login', 10, 60_000), ключ 'auth.login'.
    rateLimit: { key: 'auth.login', ...RATE_CLASSES.AUTH_STRICT },
  },
);
