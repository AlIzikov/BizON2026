// BizON API — DELETE /api/auth/sessions/[id] (R5-P1-REBUILD A3).
//
// Отзыв ОДНОЙ сессии (устройства) текущего пользователя.
// IDOR-канон: чужая/несуществующая сессия → 404 (не 403 — не раскрываем существование).
// Отзыв текущей сессии = «выйти на этом устройстве» (cookie останется, но сессия мертва).
// Каждое отзыв-событие — в AuditLog (action: session_revoke).
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { withRoute, jsonError } from '@/lib/with-route';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

export const DELETE = withRoute<{ id: string }>(
  async (req, ctx) => {
    const target = await db.session.findUnique({ where: { id: ctx.params.id } });
    if (!target || target.userId !== ctx.user!.id) {
      return jsonError(404, 'Сессия не найдена', 'NOT_FOUND');
    }

    await db.session.delete({ where: { id: target.id } });

    AuditLog.log({
      actorId: ctx.user!.id,
      action: 'session_revoke',
      resource: 'user:session',
      resourceId: target.id,
      metadata: { self: true },
    });

    return NextResponse.json({ revoked: true });
  },
  { rateLimit: { key: 'api:auth/sessions:DELETE', limit: 30, windowMs: 60_000 } },
);
