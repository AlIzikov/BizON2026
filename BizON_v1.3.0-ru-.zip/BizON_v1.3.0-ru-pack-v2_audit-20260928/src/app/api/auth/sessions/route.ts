// BizON API — /api/auth/sessions (R5-P1-REBUILD A3: session management).
//
// GET — список АКТИВНЫХ сессий текущего пользователя (device-list):
//   id, createdAt, lastUsedAt, expiresAt, userAgent, ip (маскирован), current.
//   Текущая сессия определяется по sha256(сырой токен из запроса) — сырой токен
//   в БД не хранится (канон D-21). IP маскируется (PII-минимизация): 1.2.x.x.
// Полный «выйти везде» — уже есть: POST /api/auth/logout (deleteMany по userId).
// Отзыв одной сессии — DELETE /api/auth/sessions/[id].
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { hashSessionToken } from '@/lib/security/session-token';
import { maskIp } from '@/lib/security/session-meta';

export const runtime = 'nodejs';

/** Сырой токен из запроса — та же логика, что в getUserFromRequest (bearer → cookie). */
function rawTokenFromRequest(req: Request): string | null {
  const auth = req.headers.get('authorization');
  if (auth?.startsWith('Bearer ')) return auth.slice(7);
  const match = (req.headers.get('cookie') ?? '').match(/bizon_session=([^;]+)/);
  return match ? match[1] : null;
}

export const GET = withRoute(
  async (req, ctx) => {
    const raw = rawTokenFromRequest(req);
    const currentHash = raw ? hashSessionToken(raw) : null;

    const rows = await db.session.findMany({
      where: { userId: ctx.user!.id, expiresAt: { gt: new Date() } },
      orderBy: [{ lastUsedAt: 'desc' }, { createdAt: 'desc' }],
      select: {
        id: true,
        token: true,
        createdAt: true,
        lastUsedAt: true,
        expiresAt: true,
        userAgent: true,
        ip: true,
      },
    });

    return NextResponse.json({
      sessions: rows.map((s) => ({
        id: s.id,
        createdAt: s.createdAt.toISOString(),
        lastUsedAt: (s.lastUsedAt ?? s.createdAt).toISOString(),
        expiresAt: s.expiresAt.toISOString(),
        userAgent: s.userAgent,
        ip: s.ip ? maskIp(s.ip) : null,
        current: currentHash === s.token,
      })),
    });
  },
  { rateLimit: { key: 'api:auth/sessions:GET', ...RATE_CLASSES.USER_READ } },
);
