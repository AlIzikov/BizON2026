// BizON API — /api/auth/me
// API-002 (аудит 22-09-26, W1/29-c): мигрирован на withRoute (FIX-07 composer).
//   - auth:true (по умолчанию) → ctx.user гарантированно не null, ручная
//     проверка `if (!user) return 401` больше не нужна;
//   - без сессии withRoute отдаёт 401 { error: 'Не авторизован',
//     code: 'AUTH_REQUIRED', requestId } + заголовок x-request-id
//     (поля code/requestId аддитивны — фронтенд парсит строку error);
//   - форма успешного ответа СОХРАНЕНА: { user: publicUser } (toUserSelfView).
import { json, toUserSelfView, withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export const GET = withRoute(async (_req, ctx) => {
  const publicUser = await toUserSelfView(ctx.user);
  return json({ user: publicUser });
});
