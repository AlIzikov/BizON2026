// BizON API — /api/auth/register
// Поддерживает 3 типа аккаунта + rate limiting + password policy
// FIX-08: ToS-согласие обязательно (acceptedTos:true, иначе 400) + письмо
// с одноразовой ссылкой подтверждения email (токен в БД — только sha256-хэш).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { AuthService } from '@/lib/services';
import { setSessionCookie } from '@/lib/auth';
import { json, errorJson, toUserSelfView } from '@/lib/api-helpers';
import { ReputationService } from '@/lib/services';
import { checkRateLimit, getClientIP } from '@/lib/security/rate-limiter';
import { validatePasswordPolicy } from '@/lib/security/password-policy';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { createHash } from 'node:crypto';
import { sendEmail, buildVerifyEmailHtml } from '@/lib/services/email-service';
import { createEmailVerificationToken, appUrl } from '@/lib/services/verification-token';
import { writeRegisterConsent } from '@/lib/privacy/privacy-service';
import { CURRENT_TOS_VERSION } from '@/lib/legal/versions';
import { BizonError } from '@/lib/errors';
import { sessionMetaFromRequest } from '@/lib/security/session-meta';
import { companyNeedsTwoFactor } from '@/lib/company-gate';
import type { AccountType } from '@/lib/types';

export const runtime = 'nodejs';

const REGISTER_RATE_LIMIT = 5; // 5 регистраций в час с одного IP
const REGISTER_RATE_WINDOW = 60 * 60 * 1000;

export async function POST(req: NextRequest) {
  // Rate limiting — защита от спам-регистраций
  const rateLimit = checkRateLimit(req, 'register', REGISTER_RATE_LIMIT, REGISTER_RATE_WINDOW);
  if (!rateLimit.allowed) {
    return errorJson('Слишком много регистраций. Повторите позже.', 429);
  }

  try {
    const body = await req.json();
    const { email, password, name, title, accountType, legalForm, website, specialization, acceptedTos } = body ?? {};

    // Wave 1 §8.2-2: HONEYPOT — скрытое поле, которое человек не заполнит.
    // Бот заполняет → тихий «успех» без создания аккаунта (не обучаем бота).
    if (typeof body?.websiteConfirmation === 'string' && body.websiteConfirmation.trim().length > 0) {
      return json({ ok: true, user: null });
    }

    if (!email || !password || !name) {
      return errorJson('Email, пароль и имя обязательны', 422);
    }

    // FIX-08: юридический контур люмен-программы — без согласия с условиями
    // (/legal) аккаунт не создаётся.
    if (acceptedTos !== true) {
      return errorJson('Необходимо принять условия', 400);
    }

    // H2: парольная политика через общий валидатор (blocklist + сложность + длина)
    const passwordCheck = validatePasswordPolicy(password);
    if (!passwordCheck.ok) {
      return errorJson(passwordCheck.reason, 422);
    }

    if (!email.includes('@')) {
      return errorJson('Некорректный email', 422);
    }

    const validTypes: AccountType[] = ['individual', 'company', 'hr_agency'];
    const acctType = validTypes.includes(accountType) ? accountType : 'individual';

    // Для company/hr_agency — создаём Company запись автоматически
    let companyId: string | null = null;
    if (acctType === 'company' || acctType === 'hr_agency') {
      const company = await db.company.create({
        data: {
          name,
          description: specialization ? `HR-агентство. Специализация: ${specialization}` : `Компания ${name}`,
          industry: acctType === 'hr_agency' ? 'HR Agency' : (legalForm || 'Company'),
          website: website || null,
          adTrustIndex: 0.5,
        },
      });
      companyId = company.id;
    }

    const user = await AuthService.register({
      email,
      password,
      name: acctType === 'individual' ? name : name,
      title: title || (acctType === 'company' ? legalForm : acctType === 'hr_agency' ? 'HR Agency' : null),
      accountType: acctType,
      companyId: companyId ?? undefined,
      acceptedTos: true,
      // R5-4a C1: фиксируем версию принятого ToS (re-consent гейт сверяет её
      // с CURRENT_TOS_VERSION при смене редакции)
      acceptedTosVersion: CURRENT_TOS_VERSION,
    });

    // R5-4a C1: доказательство согласия на обработку ПДн → ConsentLog
    // (kind 'processing', action 'register', версия + SHA-256, IP + UA).
    // Fail-open: телеметрия/доказательство не ломает уже созданную регистрацию
    // (регистрация подтверждается AuditLog 'register' ниже в любом случае).
    try {
      await writeRegisterConsent({
        userId: user.id,
        consentVersion: CURRENT_TOS_VERSION,
        ipAddress: getClientIP(req),
        userAgent: req.headers.get('user-agent'),
      });
    } catch (consentError) {
      console.error('[register] consent log failed (non-critical):', consentError);
    }

    // P2-4: Реферальная программа — если есть ?ref=CODE, создаём referral запись

    // Wave 1 §8.2-2: coarse device fingerprint — ТОЛЬКО хэш, без PII:
    // sha256(UA | язык | /24-подсеть IP). Пишется в AuditLog → кластеры
    // DEVICE_SHARED / будущий GNN (§8.1) видят железо-кластеры ферм.
    try {
      const ua = req.headers.get('user-agent') ?? '';
      const lang = req.headers.get('accept-language') ?? '';
      const ip = getClientIP(req);
      const ipPrefix = ip.split('.').slice(0, 3).join('.');
      const deviceHash = createHash('sha256').update(`${ua}|${lang}|${ipPrefix}`).digest('hex').slice(0, 32);
      AuditLog.logSecurity('REGISTER_DEVICE', {
        actorId: user.id,
        resource: 'User',
        resourceId: user.id,
        metadata: { deviceHash },
      });
    } catch { /* fail-open: телеметрия не ломает регистрацию */ }

    const refCode = req.nextUrl.searchParams.get('ref');
    if (refCode && refCode.length >= 8) {
      try {
        // Находим реферера по коду (первые 8 символов userId)
        const referrer = await db.user.findFirst({
          where: { id: { startsWith: refCode } },
          select: { id: true },
        });
        if (referrer && referrer.id !== user.id) {
          await db.referral.create({
            data: {
              referrerId: referrer.id,
              referredId: user.id,
              code: refCode,
            },
          }).catch(() => {}); // unique constraint — один юзер один реферал
        }
      } catch {}
    }

    const token = await AuthService.createSession(user.id, sessionMetaFromRequest(req));
    await setSessionCookie(token);
    await ReputationService.recompute(user.id);

    // FIX-08: письмо с одноразовой ссылкой подтверждения email.
    // Токен живёт только в письме (в БД — sha256-хэш); сырой токен НИКОГДА
    // не попадает в API-ответ. Отправка не должна ломать регистрацию (fail-open).
    let emailVerificationSent = false;
    try {
      const { token: verifyToken } = await createEmailVerificationToken(user.id);
      const verifyUrl = `${appUrl()}/api/auth/verify-email?token=${verifyToken}`;
      const emailPlain = user.email ?? email;
      const sendRes = await sendEmail({
        to: emailPlain,
        subject: 'BizON: подтвердите email',
        // R5-B2: инлайн-HTML вынесен в email-service (buildVerifyEmailHtml) —
        // единая точка шаблона, поведение идентично (та же ссылка, срок 24 часа).
        html: buildVerifyEmailHtml(verifyUrl),
        text: `Подтвердите email в BizON: ${verifyUrl} (ссылка действует 24 часа)`,
      });
      emailVerificationSent = sendRes.ok;
    } catch (mailError) {
      console.error('[register] verification email failed (non-critical):', mailError);
    }

    // H13: Audit log — регистрация нового пользователя
    AuditLog.log({
      actorId: user.id,
      action: 'register',
      resource: 'user',
      resourceId: user.id,
      ip: getClientIP(req),
      metadata: { accountType: acctType },
    });

    const publicUser = await toUserSelfView(user);
    // C5: token НЕ возвращаем в JSON — только HttpOnly cookie.
    // FIX-08: emailVerificationSent — флаг, что письмо отправлено (токен не отдаём).
    // A2 (R5-P1-REBUILD): company/hr_agency без 2FA → флаг баннера «Включите 2FA».
    const twoFactorSetupRequired = companyNeedsTwoFactor(user);
    return json({ user: publicUser, emailVerificationSent, twoFactorSetupRequired });
  } catch (e: any) {
    if (e?.message?.includes('уже существует')) return errorJson(e.message, 409);
    // Харденинг A3-ATK-020: сервисные BizonError (валидация email/имени) —
    // честный статус (422/400), а не обезличенный 500.
    if (e instanceof BizonError) return errorJson(e.message, e.statusCode);
    console.error('[register] error:', e);
    return errorJson('Внутренняя ошибка сервера', 500);
  }
}
