// BizON API — /api/auth/reset-password (R5-4a C25: сброс пароля по токену)
//
// POST { token, password }:
//   - политика пароля — та же, что в register (validatePasswordPolicy) → 422;
//   - токен одноразовый (sha256-lookup по purpose='password_reset', TTL 1 час);
//     невалидный/просроченный/уже использованный → 400 INVALID_TOKEN (без
//     деталей — не раскрываем причину);
//   - успех: пароль PBKDF2 (как в register), ВСЕ сессии пользователя
//     инвалидированы, AuditLog 'password_reset' → 200 { ok: true }.
import { z } from 'zod';
import { AuthService } from '@/lib/services';
import { json, withRoute, RATE_CLASSES } from '@/lib/api-helpers';
import { getClientIp } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const resetPasswordSchema = z
  .object({
    // сырой токен из письма — 64 hex-символа; min 20 отсекает мусор до БД
    token: z.string().min(20).max(256),
    password: z.string().min(1).max(256),
  })
  .strict();

export const POST = withRoute(
  async (req, ctx) => {
    const { token, password } = ctx.data as { token: string; password: string };
    await AuthService.resetPassword(token, password, { ip: getClientIp(req) });
    return json({ ok: true });
  },
  {
    auth: false,
    schema: resetPasswordSchema,
    rateLimit: { key: 'auth.reset-password', ...RATE_CLASSES.AUTH_STRICT },
  },
);
