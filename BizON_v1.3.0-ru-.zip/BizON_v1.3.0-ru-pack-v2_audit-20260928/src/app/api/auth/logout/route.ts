// BizON API — /api/auth/logout
// Использует AuthService
//
// AUDIT MODE: если текущая сессия — audit-сессия (userAgent='AUDIT-MODE'),
// при выходе удаляем ВСЕ сессии пользователя, КРОМЕ audit-сессии. Иначе
// logout уничтожил бы токен из .env (BIZON_AUDIT_SESSION_TOKEN) и следующий
// аудитор остался бы без автоподстановки сессии (middleware). Обычный logout
// работает как раньше: все сессии пользователя удаляются.
import { NextRequest } from 'next/server';
import { getUserFromRequest, SESSION_COOKIE_NAME } from '@/lib/auth';
import { AuthService } from '@/lib/services';
import { clearSessionCookie } from '@/lib/auth';
import { resolveSession } from '@/lib/security/session-token';
import { db } from '@/lib/db';
import { json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const AUDIT_UA_PREFIX = 'AUDIT-MODE';

export async function POST(_req: NextRequest) {
  try {
    const user = await getUserFromRequest(_req);
    if (user) {
      // Резолвим КОНКРЕТНУЮ текущую сессию (по cookie), чтобы понять — audit ли это.
      const cookieHeader = _req.headers.get('cookie') ?? '';
      const match = cookieHeader.match(new RegExp(`${SESSION_COOKIE_NAME}=([^;]+)`));
      const session = match ? await resolveSession(match[1]).catch(() => null) : null;

      if (session && (session.userAgent ?? '').startsWith(AUDIT_UA_PREFIX)) {
        // Аудит-выход: чистим прочие сессии, audit-сессию сохраняем (ротация —
        // только через scripts/ensure-audit-admin.ts).
        await db.session
          .deleteMany({ where: { userId: user.id, id: { not: session.id } } })
          .catch(() => {});
      } else {
        await AuthService.logout(user.id);
      }
    }
    await clearSessionCookie();
    return json({ ok: true });
  } catch (e) {
    console.error('[logout] error:', e);
    return errorJson('Ошибка выхода', 500);
  }
}
