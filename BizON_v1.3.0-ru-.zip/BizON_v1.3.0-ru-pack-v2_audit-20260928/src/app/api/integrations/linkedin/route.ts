// BizON API — /api/integrations/linkedin (Этап 5.6 — INT: Integrations Hub)
// POST — заглушка OAuth2 с LinkedIn. Возвращает 501 с понятным сообщением.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson , withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

async function __bizon_impl_post(req: Request) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // OAuth2 с LinkedIn — скоро. Возвращаем понятный статус для UI toast.
  return json(
    {
      provider: 'linkedin',
      status: 'coming_soon',
      message: 'OAuth2 с LinkedIn — скоро. Мы уже готовим интеграцию.',
    },
    501
  );
}


// DEF-16 (FIX-07): withRoute — auth 401, malformed JSON → 400, P2002 → 409, safe 500 + H11 лимит 60/мин.
export const POST = withRoute(__bizon_impl_post, {
  rateLimit: { key: 'api:integrations/linkedin:POST', limit: 60, windowMs: 60_000 },
});
