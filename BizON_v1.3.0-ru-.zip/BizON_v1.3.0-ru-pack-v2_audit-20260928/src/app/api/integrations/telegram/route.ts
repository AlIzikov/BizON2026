// BizON API — /api/integrations/telegram (Этап 5.6 — INT: Integrations Hub)
// POST — заглушка Telegram bot. Возвращает 501 с понятным сообщением.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson , withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

async function __bizon_impl_post(req: Request) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  return json(
    {
      provider: 'telegram',
      status: 'coming_soon',
      message: 'Telegram bot — скоро. Мы уже готовим интеграцию.',
    },
    501
  );
}


// DEF-16 (FIX-07): withRoute — auth 401, malformed JSON → 400, P2002 → 409, safe 500 + H11 лимит 60/мин.
export const POST = withRoute(__bizon_impl_post, {
  rateLimit: { key: 'api:integrations/telegram:POST', limit: 60, windowMs: 60_000 },
});
