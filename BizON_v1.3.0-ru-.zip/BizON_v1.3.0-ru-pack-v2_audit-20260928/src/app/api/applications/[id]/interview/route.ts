// BizON API — POST/PATCH /api/applications/[id]/interview (R5-P1-REBUILD C1).
//
// Interview scheduling: до R5-P1 существовали только статус-лейбл `interview`
// (schema:907) и мёртвый тип уведомления interview_scheduled
// (notification-service:51, никогда не эмитился). Здесь — назначение и перенос.
//
// Каноны:
//   - гейты компании: 422 COMPANY_PROFILE_INCOMPLETE (P1-фикс 4.1) → 403
//     TWO_FA_REQUIRED (A2) → 404 (чужой/несуществующий, IDOR-канон) → 409;
//   - Interview 1:1 с JobApplication (@@unique applicationId): повторное
//     назначение → 409 INTERVIEW_ALREADY_SCHEDULED, перенос — через PATCH;
//   - статус отклика переводится в `interview` + statusHistory append
//     (Professional Memory);
//   - эмиссия interview_scheduled кандидату — fail-open;
//   - заблокированные статусы отклика: draft/preparing (не подан), rejected/
//     withdrawn (терминальные), hired/accepted (оффер принят).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute, jsonError } from '@/lib/with-route';
import { assertCompanyProfile, assertCompanyTwoFactor } from '@/lib/company-gate';
import { NotificationService } from '@/lib/services/notification-service';

export const runtime = 'nodejs';

// Статусы отклика, из которых нельзя назначить интервью
const INTERVIEW_BLOCKED_STATUSES = new Set([
  'draft',
  'preparing',
  'rejected',
  'withdrawn',
  'hired',
  'accepted',
]);

const scheduleSchema = z.object({
  scheduledAt: z
    .string()
    .min(1, 'Укажите дату и время интервью')
    .refine((v) => !Number.isNaN(Date.parse(v)), 'Некорректная дата')
    .refine((v) => Date.parse(v) > Date.now() - 60_000, 'Интервью не может быть в прошлом'),
  durationMin: z.coerce.number().int().min(15).max(240).optional().default(60),
  format: z.enum(['video', 'phone', 'onsite']).optional().default('video'),
  locationOrLink: z.string().trim().max(500).optional().nullable(),
  note: z.string().trim().max(1000).optional().nullable(),
});

const rescheduleSchema = scheduleSchema.partial();

function formatLabel(format: string): string {
  return format === 'video' ? 'видео' : format === 'phone' ? 'телефон' : 'очно';
}

async function appendHistory(applicationId: string): Promise<void> {
  const application = await db.jobApplication.findUnique({
    where: { id: applicationId },
    select: { statusHistory: true },
  });
  let history: Array<{ status: string; at: string }> = [];
  try {
    const parsed = application?.statusHistory ? JSON.parse(application.statusHistory) : [];
    if (Array.isArray(parsed)) history = parsed;
  } catch {
    history = [];
  }
  history.push({ status: 'interview', at: new Date().toISOString() });
  await db.jobApplication.update({
    where: { id: applicationId },
    data: { status: 'interview', statusHistory: JSON.stringify(history) },
  });
}

function notifyCandidate(
  userId: string,
  jobTitle: string,
  interview: {
    scheduledAt: Date;
    format: string;
    locationOrLink: string | null;
    note: string | null;
  },
  kind: 'scheduled' | 'rescheduled',
): void {
  try {
    const when = interview.scheduledAt.toLocaleString('ru-RU', {
      dateStyle: 'long',
      timeStyle: 'short',
    });
    const where = interview.locationOrLink ? `. Где: ${interview.locationOrLink}` : '';
    void NotificationService.notifyMulti(userId, {
      type: 'interview_scheduled',
      title:
        kind === 'scheduled'
          ? `Назначено интервью: «${jobTitle}»`
          : `Интервью перенесено: «${jobTitle}»`,
      body: `${when} (${formatLabel(interview.format)})${where}${interview.note ? `. Комментарий: ${interview.note}` : ''}`,
      link: '/jobs',
      metadata: { jobTitle, kind, source: 'interview-scheduling' },
    });
  } catch {
    // уведомление не роняет назначение интервью
  }
}

async function loadApplicationForCompany(applicationId: string, companyId: string) {
  const application = await db.jobApplication.findUnique({
    where: { id: applicationId },
    include: { job: { select: { id: true, title: true, companyId: true } } },
  });
  if (!application) return { error: jsonError(404, 'Отклик не найден', 'NOT_FOUND') as const };
  // IDOR-канон: чужой отклик неотличим от несуществующего
  if (application.job.companyId !== companyId) {
    return { error: jsonError(404, 'Отклик не найден', 'NOT_FOUND') as const };
  }
  return { application };
}

function interviewShape(i: {
  id: string;
  applicationId: string;
  scheduledAt: Date;
  durationMin: number;
  format: string;
  locationOrLink: string | null;
  note: string | null;
  status: string;
}) {
  return {
    id: i.id,
    applicationId: i.applicationId,
    scheduledAt: i.scheduledAt.toISOString(),
    durationMin: i.durationMin,
    format: i.format,
    locationOrLink: i.locationOrLink,
    note: i.note,
    status: i.status,
  };
}

// POST — назначить интервью
export const POST = withRoute<{ id: string }>(
  async (req, ctx) => {
    const user = ctx.user!;
    assertCompanyProfile(user); // 422 (P1-фикс 4.1)
    assertCompanyTwoFactor(user); // 403 (A2)

    const body = scheduleSchema.parse(ctx.data);
    const loaded = await loadApplicationForCompany(ctx.params.id, user.companyId!);
    if ('error' in loaded) return loaded.error;
    const { application } = loaded;

    if (INTERVIEW_BLOCKED_STATUSES.has(application.status)) {
      return jsonError(409, 'Нельзя назначить интервью для отклика в этом статусе', 'INVALID_APPLICATION_STATUS');
    }
    const existing = await db.interview.findUnique({ where: { applicationId: application.id } });
    if (existing && existing.status === 'scheduled') {
      return jsonError(409, 'Интервью уже назначено — используйте перенос', 'INTERVIEW_ALREADY_SCHEDULED');
    }

    const scheduledAt = new Date(body.scheduledAt);
    const interview = await db.interview.upsert({
      where: { applicationId: application.id },
      create: {
        applicationId: application.id,
        jobId: application.jobId,
        userId: application.userId,
        companyId: user.companyId!,
        scheduledAt,
        durationMin: body.durationMin,
        format: body.format,
        locationOrLink: body.locationOrLink ?? null,
        note: body.note ?? null,
        createdById: user.id,
      },
      update: {
        scheduledAt,
        durationMin: body.durationMin,
        format: body.format,
        locationOrLink: body.locationOrLink ?? null,
        note: body.note ?? null,
        status: 'scheduled',
        createdById: user.id,
      },
    });

    await appendHistory(application.id);
    notifyCandidate(application.userId, application.job.title, interview, 'scheduled');

    return NextResponse.json({ ok: true, interview: interviewShape(interview) });
  },
  {
    schema: scheduleSchema,
    rateLimit: { key: 'api:applications:interview:POST', limit: 30, windowMs: 60_000 },
  },
);

// PATCH — перенести интервью
export const PATCH = withRoute<{ id: string }>(
  async (req, ctx) => {
    const user = ctx.user!;
    assertCompanyProfile(user);
    assertCompanyTwoFactor(user);

    const body = rescheduleSchema.parse(ctx.data);
    const loaded = await loadApplicationForCompany(ctx.params.id, user.companyId!);
    if ('error' in loaded) return loaded.error;
    const { application } = loaded;

    const interview = await db.interview.findUnique({ where: { applicationId: application.id } });
    if (!interview) return jsonError(404, 'Интервью не назначено', 'NOT_FOUND');
    if (interview.status !== 'scheduled') {
      return jsonError(409, 'Можно переносить только запланированное интервью', 'INTERVIEW_NOT_RESCHEDULABLE');
    }

    const updated = await db.interview.update({
      where: { id: interview.id },
      data: {
        ...(body.scheduledAt !== undefined ? { scheduledAt: new Date(body.scheduledAt) } : {}),
        ...(body.durationMin !== undefined ? { durationMin: body.durationMin } : {}),
        ...(body.format !== undefined ? { format: body.format } : {}),
        ...(body.locationOrLink !== undefined ? { locationOrLink: body.locationOrLink ?? null } : {}),
        ...(body.note !== undefined ? { note: body.note ?? null } : {}),
      },
    });

    notifyCandidate(application.userId, application.job.title, updated, 'rescheduled');

    return NextResponse.json({ ok: true, interview: interviewShape(updated) });
  },
  {
    schema: rescheduleSchema,
    rateLimit: { key: 'api:applications:interview:PATCH', limit: 30, windowMs: 60_000 },
  },
);
