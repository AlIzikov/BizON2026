// BizON API — POST /api/applications/[id]/reject (R5-P1-REBUILD C3).
//
// HR-сторона rejection flow с фидбеком (аудит R5-P1: существовал только
// кандидатский самоотказ; hiringManagerResponse был мёртвым полем).
//
// Каноны:
//   - гейт компании: 422 COMPANY_PROFILE_INCOMPLETE (P1-фикс 4.1) + 403
//     TWO_FA_REQUIRED (A2 — мутация компании);
//   - IDOR: чужой отклик (вакансия другой компании) → 404, не 403;
//   - идемпотентность статусов: повторный reject → 409; hired/accepted → 409;
//   - фидбек пишется в hiringManagerResponse (поле оживлено) + rejectReason;
//   - уведомление кандидату — тот же канал, что и самоотказ: NotificationService
//     .notifyMulti(application_status, «Причина отказа: …») + текст фидбека;
//   - statusHistory append (траектория для Professional Memory).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute, jsonError } from '@/lib/with-route';
import { assertCompanyProfile, assertCompanyTwoFactor } from '@/lib/company-gate';
import { NotificationService } from '@/lib/services/notification-service';

export const runtime = 'nodejs';

const rejectSchema = z.object({
  reason: z.string().trim().min(1, 'Укажите причину отказа').max(500),
  feedback: z.string().trim().max(2000).optional().nullable(),
});

export const POST = withRoute<{ id: string }>(
  async (req, ctx) => {
    const user = ctx.user!;
    // P1-фикс (4.1) + A2 (обязательная 2FA на мутациях компании)
    assertCompanyProfile(user);
    assertCompanyTwoFactor(user);

    const body = rejectSchema.parse(ctx.data);

    const application = await db.jobApplication.findUnique({
      where: { id: ctx.params.id },
      include: { job: { select: { id: true, title: true, companyId: true } } },
    });
    if (!application) return jsonError(404, 'Отклик не найден', 'NOT_FOUND');
    // IDOR-канон: чужой отклик неотличим от несуществующего
    if (application.job.companyId !== user.companyId) {
      return jsonError(404, 'Отклик не найден', 'NOT_FOUND');
    }
    if (application.status === 'rejected') {
      return jsonError(409, 'Отклик уже отклонён', 'ALREADY_REJECTED');
    }
    if (application.status === 'hired' || application.status === 'accepted') {
      return jsonError(409, 'Нельзя отклонить кандидата с принятым оффером', 'HIRED_CONFLICT');
    }

    let history: Array<{ status: string; at: string }> = [];
    try {
      const parsed = application.statusHistory ? JSON.parse(application.statusHistory) : [];
      if (Array.isArray(parsed)) history = parsed;
    } catch {
      history = [];
    }
    history.push({ status: 'rejected', at: new Date().toISOString() });

    await db.jobApplication.update({
      where: { id: application.id },
      data: {
        status: 'rejected',
        rejectReason: body.reason,
        hiringManagerResponse: body.feedback ?? null,
        statusHistory: JSON.stringify(history),
      },
    });

    // Уведомление кандидату — fail-open (канон status-роута R5-2a)
    try {
      void NotificationService.notifyMulti(application.userId, {
        type: 'application_status',
        title: `Статус отклика: «${application.job.title}» → Отклонён`,
        body: body.feedback
          ? `Причина отказа: ${body.reason}. Комментарий работодателя: ${body.feedback}`
          : `Причина отказа: ${body.reason}`,
        link: '/jobs',
        metadata: {
          applicationId: application.id,
          jobId: application.job.id,
          from: application.status,
          to: 'rejected',
          source: 'hr-rejection',
        },
      });
    } catch {
      // уведомление не роняет reject
    }

    return NextResponse.json({
      ok: true,
      application: {
        id: application.id,
        status: 'rejected',
        rejectReason: body.reason,
        feedback: body.feedback ?? null,
      },
    });
  },
  { schema: rejectSchema, rateLimit: { key: 'api:applications:reject', limit: 30, windowMs: 60_000 } },
);
