// BizON API — /api/hr-contacts/[id]/block
// Этап 4.2 — Privacy Shield: кандидат блокирует HR.
// Эффект: статус контакта становится 'blocked'. Блок действует 7 дней с момента
// блокировки — в течение этого времени HR не может инициировать новый контакт
// с этим кандидатом (проверяется в POST /api/hr-contacts).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson , withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

async function __bizon_impl_post(req: Request, ctx: { params: {  id: string  } }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const contact = await db.hrContact.findUnique({
      where: { id },
      select: { id: true, candidateId: true, hrAgencyId: true, status: true },
    });
    if (!contact) return errorJson('Контакт не найден', 404);

    // Только кандидат (получатель) может блокировать
    if (contact.candidateId !== user.id) {
      return errorJson('Только кандидат может блокировать HR', 403);
    }

    if (contact.status === 'blocked') {
      return json({
        contact: { id: contact.id, status: contact.status },
        alreadyBlocked: true,
      });
    }

    const updated = await db.hrContact.update({
      where: { id },
      data: { status: 'blocked' },
    });

    return json({
      contact: {
        id: updated.id,
        status: updated.status,
      },
      alreadyBlocked: false,
    });
  } catch (e) {
    console.error('[hr-contacts/block] error:', e);
    return errorJson('Ошибка блокировки HR', 500);
  }
}


// DEF-16 (FIX-07): withRoute — auth 401, malformed JSON → 400, P2002 → 409, safe 500 + H11 лимит 60/мин.
export const POST = withRoute<{  id: string  }>(__bizon_impl_post, {
  rateLimit: { key: 'api:hr-contacts/[id]/block:POST', limit: 60, windowMs: 60_000 },
});
