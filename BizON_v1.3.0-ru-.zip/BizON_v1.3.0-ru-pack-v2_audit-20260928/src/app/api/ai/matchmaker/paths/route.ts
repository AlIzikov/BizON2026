// BizON API — GET /api/ai/matchmaker/paths?targetId=<id>
// OWNER-UX-PLAN W3-3a: альтернативные пути «5 рукопожатий» для выбора
// посредника на чужом профиле (W3-3c: радио «через кого»).
//
// Лёгкий read-only эндпоинт (в отличие от POST /api/ai/matchmaker — тот
// пишет ReputationEvent и имеет тарифный AI-лимит; его rate-limit НЕ тронут).
// Своё ограничение: простой checkUserRateLimit 30/час на пользователя —
// перечисление путей всё же дороже одного BFS-запроса.
//
// Ответ: { paths: [{ mediatorId, mediatorName, path: [{id, name}], hops }] }
// path включает конечные точки (requester первым, target последним).
// Пути короче 2 рёбер не возвращаются — у 1 рукопожатия посредника нет.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { findHandshakePaths } from '@/lib/matchmaker';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const MAX_PATHS = 4;

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Простой per-user лимит (30/час) — задокументирован как «на всякий случай»:
  // UI вызывает этот GET один раз после основного поиска пути.
  const rl = checkUserRateLimit(user.id, 'ai:matchmaker-paths', 30, 60 * 60 * 1000);
  if (!rl.allowed) {
    return errorJson(
      `Лимит поиска путей исчерпан (30 в час). Повторите через ${rl.retryAfter} секунд.`,
      429,
    );
  }

  const targetId = new URL(req.url).searchParams.get('targetId');
  if (!targetId) return errorJson('targetId обязателен', 400);
  if (targetId === user.id) return errorJson('Нельзя искать пути к самому себе', 400);

  const target = await db.user.findUnique({ where: { id: targetId }, select: { id: true } });
  if (!target) return errorJson('Целевой пользователь не найден', 404);

  const found = await findHandshakePaths(user.id, targetId, MAX_PATHS);
  if (found.length === 0) return json({ paths: [] });

  // Имена одним запросом (пути делят узлы)
  const allIds = [...new Set(found.flatMap((p) => p.path))];
  const users = await db.user.findMany({ where: { id: { in: allIds } }, select: { id: true, name: true } });
  const nameById = new Map(users.map((u) => [u.id, u.name]));

  const paths = found.map((p) => ({
    mediatorId: p.path[1],
    mediatorName: nameById.get(p.path[1]) ?? 'Пользователь',
    path: p.path.map((id) => ({ id, name: nameById.get(id) ?? 'Пользователь' })),
    hops: p.hops,
  }));

  return json({ paths });
}
