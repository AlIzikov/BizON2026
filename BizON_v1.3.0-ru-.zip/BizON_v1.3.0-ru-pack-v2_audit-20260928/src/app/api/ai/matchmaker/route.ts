// BizON API — /api/ai/matchmaker (5 рукопожатий)
// API-001 (29-A-redux, аудит 22-09-26): withRoute — auth/CSRF/413/415/единый
// error-контракт; per-тарифный rate-limit сохранён внутри хендлера (лимит
// зависит от subscriptionTier — статический пресет withRoute не подходит).
import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { findMatch } from '@/lib/matchmaker';
import { ReputationService } from '@/lib/services';
import { checkUserRateLimit, getAiLimitKey } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export const POST = withRoute(async (req, ctx) => {
  const user = ctx.user!;

  // RT-01 / H12: AI rate limit по тарифу — защита free-tier от спама
  // (free = aiMatchmakerFree = 5/час; бакет per-user, чужой лимит не трогаем).
  const [max, windowMs] = getAiLimitKey('matchmaker', user.subscriptionTier);
  const rl = checkUserRateLimit(user.id, 'ai:matchmaker', max, windowMs);
  if (!rl.allowed) {
    return errorJson(
      `Лимит AI-Matchmaker исчерпан (${max} запросов в час для тарифа ${user.subscriptionTier}). Повторите через ${rl.retryAfter} секунд.`,
      429,
      'RATE_LIMITED'
    );
  }

  const body = (await req.json().catch(() => ({}))) as { toUserId?: string };
  const { toUserId } = body ?? {};
  if (!toUserId) return errorJson('toUserId обязателен', 422, 'VALIDATION_ERROR');

  const target = await db.user.findUnique({ where: { id: toUserId } });
  if (!target) return errorJson('Целевой пользователь не найден', 404, 'NOT_FOUND');
  if (toUserId === user.id) return errorJson('Нельзя искать путь к самому себе', 400, 'VALIDATION_ERROR');

  const result = await findMatch(user.id, toUserId);

  if (result.found) {
    // FIX-06: reputation event + пересчёт IP-score одной пачкой (awardBulk)
    await ReputationService.awardBulk({
      userIds: [user.id],
      eventType: 'intro_sent',
      weight: 1,
      payload: {
        to: target.name,
        toId: target.id,
        pathLength: result.path.length,
        confidence: result.confidence,
      },
    });
  }

  return json(result);
});
