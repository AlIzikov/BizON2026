// BizON API — /api/ai/project-match (аддендум §11.4)
// POST — AI-подборка «почему вам может быть интересен проект»: берём топ-N
// рекомендованных проектов (общий пикер с GET /api/projects/recommendations)
// и генерируем для каждого персональное объяснение через LLM
// (generateProjectMatchWhy → AIGateway → z-ai-web-dev-sdk; SDK только в ai-core/llm).
// Fallback — rule-based причины (те же, что в ленте рекомендаций).
// Лимит AI по тарифу: free 5/ч, pro 50/ч, business 500/ч (getAiLimitKey 'projectMatch').
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson, withRoute } from '@/lib/api-helpers';
import { pickRecommendedProjects } from '@/lib/projects/recommendation-picker';
import { generateProjectMatchWhy } from '@/lib/ai';
import { checkUserRateLimit, getAiLimitKey } from '@/lib/security/rate-limiter';
import { GovernanceService } from '@/lib/ai-governance';

export const runtime = 'nodejs';

const AI_LIMIT = 4; // сколько проектов объясняем за один запрос (LLM-стоимость)

async function __bizon_impl_post(req: Request) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // H12/RT-01: AI rate limit по тарифу (per-user бакет; общий H11 60/мин остаётся в withRoute)
  const [max, windowMs] = getAiLimitKey('projectMatch', user.subscriptionTier);
  const rl = checkUserRateLimit(user.id, 'ai:project-match', max, windowMs);
  if (!rl.allowed) {
    return errorJson(
      `Лимит AI-подбора проектов исчерпан (${max} запросов в час для тарифа ${user.subscriptionTier}). Повторите через ${rl.retryAfter} секунд.`,
      429
    );
  }

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const limit = Math.min(Math.max(Number(body?.limit) || AI_LIMIT, 1), AI_LIMIT);

  const { rows, signals } = await pickRecommendedProjects(user.id, limit);
  if (rows.length === 0) return json({ matches: [] });

  const topics = (csv: string) => csv.split(',').map((t) => t.trim()).filter(Boolean);
  const skillsCsv = (csv: string) => csv.split(',').map((s) => s.trim()).filter(Boolean);

  // Последовательно (гейтвей имеет backpressure-очередь maxConcurrent 4 — не занимаем всё)
  const matches = [];
  for (const row of rows) {
    const why = await generateProjectMatchWhy(
      { id: user.id, name: user.name, title: user.title, ipScore: user.ipScore },
      {
        project: {
          title: row.title,
          summary: row.summary,
          description: row.description,
          topics: topics(row.topicsCsv),
          requiredSkills: skillsCsv(row.requiredSkills),
          region: row.region,
          viewsCount: row.viewsCount,
        },
        signals,
      }
    );
    matches.push({ projectId: row.id, why });
  }

  // GAP-MATRIX P0-1: след AI-действия в governance (fail-open)
  void GovernanceService.recordDirectAction({
    agentKey: 'system',
    userId: user.id,
    actionKey: 'SEARCH_JOBS',
    inputPayload: { endpoint: 'ai/project-match', matchCount: matches.length },
  }).catch(() => undefined);
  return json({ matches, provider: 'llm-with-fallback' });
}

// DEF-16: withRoute — auth 401, malformed JSON → 400, safe 500 + H11 лимит 60/мин.
export const POST = withRoute(__bizon_impl_post, {
  rateLimit: { key: 'api:ai/project-match:POST', limit: 60, windowMs: 60_000 },
});
