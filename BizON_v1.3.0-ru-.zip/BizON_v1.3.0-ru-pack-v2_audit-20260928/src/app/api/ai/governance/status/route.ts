// BizON API — GET /api/ai/governance/status (W3.3)
// Статус governance-контура для владельца/оператора:
// агенты и их статусы, kill-switch, счётчики действий.
// PATCH — управление: pause/resume агента, global kill (без участия AI).
// D-20 (R2-005): локальный requireAdmin с хардкодом id демо-владельца УДАЛЁН —
// единая ролевая проверка isAdminRole из src/lib/admin-guard.ts; PATCH — zod.
import { NextRequest } from 'next/server';
import { z } from 'zod';
import { json, errorJson } from '@/lib/api-helpers';
import { requireAdmin } from '@/lib/admin-guard';
import { db } from '@/lib/db';
import { GovernanceService } from '@/lib/ai-governance';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const guard = await requireAdmin(req);
  if (!guard.ok) return errorJson(guard.message, guard.status);

  const agents = await db.aiAgent.findMany({ orderBy: { key: 'asc' } });
  const [actionsTotal, pendingApprovals, blocked, incidents] = await Promise.all([
    db.aiAction.count(),
    db.aiApproval.count({ where: { status: 'pending' } }),
    db.aiAction.count({ where: { status: 'policy_blocked' } }),
    db.aiIncident.count({ where: { status: 'open' } }),
  ]);
  return json({
    // D2 (Agent 7): честная витрина — персистентная политика, а не только env
    globalKill: await GovernanceService.isAutonomyKilled(),
    agents: agents.map((a) => ({
      key: a.key, name: a.name, status: a.status, autonomyLevel: a.autonomyLevel, version: a.version,
    })),
    stats: { actionsTotal, pendingApprovals, policyBlocked: blocked, openIncidents: incidents },
  });
}

export async function PATCH(req: NextRequest) {
  const guard = await requireAdmin(req);
  if (!guard.ok) return errorJson(guard.message, guard.status);
  const userId = guard.user.id;

  const schema = z
    .object({
      op: z.enum(['pause_agent', 'resume_agent', 'global_kill']),
      agentKey: z.string().trim().min(1).max(100).optional(),
      enable: z.boolean().optional(),
    })
    .strict();
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return errorJson('Некорректное тело: { op: pause_agent|resume_agent|global_kill, agentKey?, enable? }', 422);
  }
  const { op, agentKey, enable } = parsed.data;
  if ((op === 'pause_agent' || op === 'resume_agent') && !agentKey) {
    return errorJson('agentKey обязателен для pause/resume', 422);
  }
  if (op === 'global_kill' && enable === undefined) {
    return errorJson('enable обязателен для global_kill', 422);
  }

  switch (op) {
    case 'pause_agent': {
      const ok = await GovernanceService.pauseAgent(agentKey!, userId);
      return ok ? json({ ok: true }) : errorJson('Агент не найден', 404);
    }
    case 'resume_agent': {
      const ok = await GovernanceService.resumeAgent(agentKey!, userId);
      return ok ? json({ ok: true }) : errorJson('Агент не найден или не в паузе', 404);
    }
    case 'global_kill': {
      // Честный kill: env-флаг действует только до рестарта; для персистентного
      // состояния пишем системную политику enabled=false (PolicyEngine проверяет
      // оба сигнала).
      if (!enable) {
        await db.aiPolicy.upsert({
          where: { key: 'global_autonomy' },
          create: { key: 'global_autonomy', mode: 'manual', enabled: false, rules: '{}' },
          update: { enabled: false, mode: 'manual' },
        });
      } else {
        await db.aiPolicy.upsert({
          where: { key: 'global_autonomy' },
          create: { key: 'global_autonomy', mode: 'collaborative', enabled: true, rules: '{}' },
          update: { enabled: true, mode: 'collaborative' },
        });
      }
      await GovernanceService.audit({
        event: enable ? 'governance.global_kill_released' : 'governance.global_kill_engaged',
        actorType: 'user',
        actorId: userId,
        actionKey: 'GOVERNANCE',
        status: enable ? 'active' : 'killed',
        metadata: {},
      });
      return json({ ok: true, globalKill: !enable });
    }
    default:
      return errorJson('op: pause_agent | resume_agent | global_kill', 422);
  }
}
