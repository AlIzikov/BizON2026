// BizON API — POST /api/ai/governance/execute (GAP-MATRIX P0-2, executor-волна)
// Исполнение одобренного (approved) read-only AI-действия. Владелец действия
// подтверждается по audit-трейлу; re-check политики/бюджета внутри сервиса (§38).
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { GovernanceService } from '@/lib/ai-governance';

export const runtime = 'nodejs';

export const POST = withRoute(
  async (req: Request, { user }) => {
    const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
    const actionId = typeof body?.actionId === 'string' ? body.actionId : '';
    if (!actionId) return errorJson('actionId обязателен', 422);

    const res = await GovernanceService.executeApprovedAction({
      actionId,
      userId: user!.id,
    });
    if (!res.ok) {
      const status =
        res.code === 'NOT_FOUND' ? 404
        : res.code === 'FORBIDDEN' ? 403
        : res.code === 'NOT_APPROVED' || res.code === 'EXECUTOR_NOT_AVAILABLE' || res.code === 'RE_APPROVAL_REQUIRED' ? 409
        : res.code === 'POLICY_BLOCKED' || res.code === 'BUDGET_EXCEEDED' ? 422
        : 500;
      return errorJson(res.message, status);
    }

    return json({ ok: true, summary: res.summary, data: res.data ?? null });
  },
  {
    rateLimit: { key: 'api:ai/governance/execute', limit: 10, windowMs: 60_000 },
  },
);
