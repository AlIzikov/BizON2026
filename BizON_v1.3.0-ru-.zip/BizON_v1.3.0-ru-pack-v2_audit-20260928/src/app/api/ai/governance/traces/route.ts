// BizON API — GET /api/ai/governance/traces (GAP-MATRIX №12, OTel GenAI)
//
// Наблюдаемость своих AI-вызовов: последние GenAI-спаны пользователя из
// AiTrace (КТО/ЧТО/КОГДА/ПОЧЕМУ/КАКОЙ АГЕНТ/КАКАЯ МОДЕЛЬ/РЕЗУЛЬТАТ/ОШИБКА/
// ЗАТРАТЫ). Только СВОИ трейсы (userId == сессия) — чужие недоступны.
// Параметры: ?limit=1..100 (default 50), ?status=ok|fallback|rate_limited|
// error|blocked, ?operation=<подстрока>.
import { json, withRoute } from '@/lib/api-helpers';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

const ALLOWED_STATUS = new Set(['ok', 'fallback', 'rate_limited', 'error', 'blocked']);

export const GET = withRoute(
  async (req: Request, { user }) => {
    const url = new URL(req.url);
    const limitRaw = Number(url.searchParams.get('limit') ?? '50');
    const limit = Math.min(Math.max(Number.isFinite(limitRaw) ? Math.trunc(limitRaw) : 50, 1), 100);

    const statusParam = url.searchParams.get('status');
    const operationParam = url.searchParams.get('operation');

    const traces = await db.aiTrace.findMany({
      where: {
        userId: user!.id,
        ...(statusParam && ALLOWED_STATUS.has(statusParam) ? { status: statusParam } : {}),
        ...(operationParam ? { operation: { contains: operationParam } } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      select: {
        id: true,
        traceId: true,
        spanId: true,
        route: true,
        operation: true,
        agentId: true,
        actionId: true,
        genAiSystem: true,
        modelRoute: true,
        provider: true,
        autonomyMode: true,
        status: true,
        errorCode: true,
        latencyMs: true,
        inputTokens: true,
        outputTokens: true,
        costUnits: true,
        createdAt: true,
      },
    });

    return json({ ok: true, count: traces.length, traces });
  },
  {
    rateLimit: { key: 'api:ai/governance/traces', limit: 30, windowMs: 60_000 },
  },
);
