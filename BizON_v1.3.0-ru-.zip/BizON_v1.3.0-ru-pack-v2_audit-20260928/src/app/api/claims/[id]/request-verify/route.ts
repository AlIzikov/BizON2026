// BizON API — POST /api/claims/[id]/request-verify
// A-5 (быстрые победы): «Запросить подтверждение» клейма — владелец claim
// отправляет коллеге-контакту запрос подтвердить его утверждение.
// Механика: Notification верификатору (type 'claim_verify_request') со ссылкой
// в раздел «Правда», где он может подтвердить через /api/claims/[id]/verify.
// Гарды: только свой claim; только принятые связи (accepted Connection);
// дубликат непрочитанного запроса тому же верификатору → 409.
// (FIX-07/p1-residue): withRoute — auth 401, params из ctx, zod body, safe 500.
import { z } from 'zod';
import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const verifyRequestSchema = z.object({ verifierId: z.string().min(1, 'verifierId обязателен') });

export const POST = withRoute<{ id: string }>(
  async (req, { params, user, data }) => {
    const rl = checkUserRateLimit(user.id, 'claims:request-verify', 10, 60 * 60 * 1000);
    if (!rl.allowed) return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter}с`, 429);

    const { id } = params;
    const { verifierId } = verifyRequestSchema.parse(data);
    if (verifierId === user.id) return errorJson('Нельзя запросить подтверждение у себя', 422);

    // 1) Claim существует и принадлежит запросчику
    const claim = await db.claim.findUnique({ where: { id } });
    if (!claim) return errorJson('Claim не найден', 404);
    if (claim.userId !== user.id) {
      return errorJson('Запросить подтверждение можно только для своего утверждения', 403);
    }

    // 2) Верификатор существует и активен
    const verifier = await db.user.findUnique({
      where: { id: verifierId },
      select: { id: true, name: true, deletedAt: true },
    });
    if (!verifier || verifier.deletedAt) return errorJson('Коллега не найден', 404);

    // 3) Только принятые связи (Connection accepted в любую сторону)
    const connection = await db.connection.findFirst({
      where: {
        status: 'accepted',
        OR: [
          { fromUserId: user.id, toUserId: verifierId },
          { fromUserId: verifierId, toUserId: user.id },
        ],
      },
      select: { id: true },
    });
    if (!connection) {
      return errorJson('Запрашивать подтверждение можно у контактов (принятые связи)', 422);
    }

    // 4) Дубликат: непрочитанный запрос этому верификатору по этому claim
    const duplicate = await db.notification.findFirst({
      where: {
        userId: verifierId,
        type: 'claim_verify_request',
        link: `/truth?claim=${claim.id}`,
        isRead: false,
      },
      select: { id: true },
    });
    if (duplicate) return errorJson('Запрос этому коллеге уже отправлен', 409);

    // 5) Уведомление-запрос
    const notification = await db.notification.create({
      data: {
        userId: verifierId,
        type: 'claim_verify_request',
        title: 'Просят подтвердить утверждение',
        content: `${user.name} просит подтвердить: «${claim.title}». Откройте «Правду», чтобы подтвердить или отклонить.`,
        link: `/truth?claim=${claim.id}`,
      },
    });

    return json(
      {
        ok: true,
        notificationId: notification.id,
        message: `Запрос отправлен: ${verifier.name}`,
      },
      201,
    );
  },
  { schema: verifyRequestSchema },
);
