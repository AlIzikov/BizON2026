// BizON API — GET /api/dao/[id]/votes
// «Кто проголосовал» (запрос владельца, 2026-09-11): раньше предложение DAO
// показывало только числа «За / Против / Воздержались», и нельзя было увидеть
// ЛИСТ голосования. Теперь клик по счётчикам открывает список: имя голосующего,
// голос, вес (IP-score), дата. Голоса — реальные записи DaoVote.
//
// Открытость: в BizON голосование публично (голосуют живые люди с IP-score,
// вес = доверие), поэтому список голосов виден всем авторизованным.
import { db } from '@/lib/db';
import { withRoute, errorJson, json, RATE_CLASSES } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export const GET = withRoute<{ id: string }>(async (_req, ctx) => {
  const { id } = ctx.params;

  const proposal = await db.daoProposal.findUnique({
    where: { id },
    select: {
      id: true,
      title: true,
      status: true,
      forVotes: true,
      againstVotes: true,
      abstainVotes: true,
    },
  });
  if (!proposal) return errorJson('Предложение не найдено', 404);

  const votes = await db.daoVote.findMany({
    where: { proposalId: id },
    orderBy: { createdAt: 'desc' },
    include: {
      voter: {
        select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true },
      },
    },
  });

  return json({
    proposal,
    votes: votes.map((v) => ({
      id: v.id,
      vote: v.vote, // for | against | abstain
      weight: v.weight,
      createdAt: v.createdAt.toISOString(),
      voter: v.voter,
    })),
  });
}, {
  // PR #3 (волна R0.3): rate-класс для безлимитного withRoute —
  // агрегатная выборка голосов не должна быть бесплатной на завале.
  rateLimit: {
    key: 'dao:votes',
    limit: RATE_CLASSES.USER_READ.limit,
    windowMs: RATE_CLASSES.USER_READ.windowMs,
  },
});
