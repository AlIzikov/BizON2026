// BizON API — POST /api/dao/[id]/vote: голосовать (вес = IP-score).
//
// Миграция канона (PR #3, волна R0.3, §11.3): легаси → withRoute.
//   - auth 401 из обёртки; единый error-контракт {error, code?, requestId?};
//   - zod-валидация body (vote enum) + paramsSchema (API-012) — легаси 422
//     на схемную ошибку выровнен на 400 (API-007);
//   - AUTH_STRICT 10/мин (мутация, касса не при чём);
//   - P2002 (@@unique proposalId+voterId) → 409 автоматом из обёртки —
//     легаси глотал его в общий 500 «Ошибка».
//
// Семантика сохранена от легаси:
//   - вес голоса = ipScore НА МОМЕНТ голоса (история не перетирается);
//   - гейт proposal.minIpScore (Trust-Adaptive, серверный);
//   - инкремент счётчиков: дрифт допустим — DaoService.recountVotes (PR #1)
//     лечит его при lazy-close из строк DaoVote (истина).
import { z } from 'zod';
import { json } from '@/lib/api-helpers';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { BizonError } from '@/lib/errors';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

const paramsSchema = z.object({ id: z.string().min(1) });
const voteSchema = z.object({
  vote: z.enum(['for', 'against', 'abstain'], { message: 'vote: for | against | abstain' }),
});

export const POST = withRoute<{ id: string }>(async (_req, { user, data, params }) => {
  const { id } = params;
  const { vote } = data as z.infer<typeof voteSchema>;

  const proposal = await db.daoProposal.findUnique({ where: { id } });
  if (!proposal) {
    throw new BizonError('Предложение не найдено', 404, 'DAO_PROPOSAL_NOT_FOUND');
  }
  if (proposal.status !== 'active') {
    throw new BizonError('Голосование завершено', 409, 'DAO_VOTING_CLOSED');
  }
  if (proposal.endDate < new Date()) {
    // Просроченное active закроется lazy-close'ом при следующем GET списка;
    // голосовать по нему всё равно нельзя (пин PR #1 [P7] следит за этим).
    throw new BizonError('Срок истёк', 409, 'DAO_VOTING_EXPIRED');
  }

  // Trust-Adaptive: минимальный IP-score предложения
  if (user.ipScore < proposal.minIpScore) {
    throw new BizonError(
      `Требуется IP-score ${proposal.minIpScore}+. Ваш: ${user.ipScore}`,
      403,
      'DAO_IP_SCORE_REQUIRED',
    );
  }

  // Не голосовал ли уже (дружелюбное сообщение; backstop — @@unique → P2002 → 409)
  const existing = await db.daoVote.findUnique({
    where: { proposalId_voterId: { proposalId: id, voterId: user.id } },
    select: { id: true },
  });
  if (existing) {
    throw new BizonError('Вы уже голосовали', 409, 'DAO_ALREADY_VOTED');
  }

  // Голос (вес = IP-score голосующего — уникальная фича!)
  const voteRecord = await db.daoVote.create({
    data: {
      proposalId: id,
      voterId: user.id,
      vote,
      weight: user.ipScore,
    },
  });

  // Счётчики — инкрементом (истина пересчитывается из строк при lazy-close)
  const field = vote === 'for' ? 'forVotes' : vote === 'against' ? 'againstVotes' : 'abstainVotes';
  await db.daoProposal.update({
    where: { id },
    data: { [field]: { increment: user.ipScore } },
  });

  return json({ vote: voteRecord, weight: user.ipScore }, 201);
}, {
  paramsSchema,
  schema: voteSchema,
  rateLimit: {
    key: 'dao:vote',
    limit: RATE_CLASSES.AUTH_STRICT.limit,
    windowMs: RATE_CLASSES.AUTH_STRICT.windowMs,
  },
});
