// BizON API — DAO: список proposals + создание.
//
// PR #1 (волна R0.1, реставрация STUBS-AUDIT A10 / P1 §10.3):
//   1. ЛЕГИАСИ → withRoute (канон Task 29/31, P1 §11.3): auth 401 из обёртки,
//      единый error-контракт {error, code?, requestId?} + x-request-id,
//      zod-валидация body/query, CSRF origin-гейт для POST.
//   2. LAZY-CLOSE-ON-READ: GET перед выдачей списка закрывает просроченные
//      active-предложения (DaoService.closeExpiredProposals): итог passed/
//      rejected по весам, счётчики пересчитываются из строк DaoVote (дрифт
//      лечится), идемпотентно. Результат — аддитивное поле lazyClose в ответе
//      (XAI: id/title/status/reason) — dao-view.tsx читает proposals как раньше.
//   3. Rate-limit: GET — USER_READ 120/мин; POST — AUTH_STRICT 10/мин
//      (редкая мутация создания: реже обычных writes, касса не при чём).
//
// Гейты создания (Trust-Adaptive, без изменений от легаси):
//   - IP-score 31+ (семантический отказ → BizonError 403 DAO_IP_SCORE_REQUIRED);
//   - nav-гейт minLevel:'extended' остаётся в app-shell (клиентский UX-замок).
import { z } from 'zod';
import { json } from '@/lib/api-helpers';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { BizonError } from '@/lib/errors';
import { db } from '@/lib/db';
import { DaoService } from '@/lib/services/dao-service';

export const runtime = 'nodejs';

/** Минимальный IP-score для участия в DAO (создание/голосование — Trust-Adaptive). */
export const DAO_MIN_IP_SCORE = 31;

const STATUS_VALUES = ['active', 'passed', 'rejected', 'executed', 'all'] as const;

const createProposalSchema = z.object({
  title: z.string().trim().min(1, 'title обязателен').max(200),
  description: z.string().trim().min(1, 'description обязателен').max(10_000),
  type: z.enum(['governance', 'budget', 'feature', 'partnership']).default('governance'),
  durationDays: z.number().int().min(1).max(90).default(7),
});

const listQuerySchema = z.object({
  status: z.enum(STATUS_VALUES).default('active'),
});

export const GET = withRoute(async (_req, { user, data }) => {
  const { status } = data as z.infer<typeof listQuerySchema>;

  // ШАГ 1: lazy-close-on-read — просроченные active закрываются ДО выборки
  // (идемпотентно; батч-лимит в сервисе защищает чтение от завала).
  // ПОСЛЕДОВАТЕЛЬНО, не Promise.all: список в ЭТОМ ЖЕ ответе обязан отражать
  // закрытие (иначе клиент увидит active + lazyClose.closed>0 — противоречие).
  const lazyClose = await DaoService.closeExpiredProposals();

  // ШАГ 2: выдача списка — контракт dao-view.tsx сохранён 1:1 (myVote /
  // totalVotes нужны UI: бейдж «Вы проголосовали», счётчик голосов);
  // lazyClose — аддитивное поле (XAI: id/title/status/reason).
  const proposals = await db.daoProposal.findMany({
    where: status === 'all' ? {} : { status },
    orderBy: { createdAt: 'desc' },
    take: 30,
    include: {
      proposer: { select: { id: true, name: true, avatarUrl: true, ipScore: true } },
      _count: { select: { votes: true } },
      votes: { where: { voterId: user.id }, select: { id: true, vote: true } },
    },
  });

  return json({
    proposals: proposals.map((p) => ({
      ...p,
      myVote: p.votes[0]?.vote ?? null,
      totalVotes: p._count.votes,
    })),
    lazyClose,
  });
}, {
  schema: listQuerySchema,
  rateLimit: {
    key: 'dao:list',
    limit: RATE_CLASSES.USER_READ.limit,
    windowMs: RATE_CLASSES.USER_READ.windowMs,
  },
});

export const POST = withRoute(async (_req, { user, data }) => {
  // Trust-Adaptive: только IP-score 31+ могут создавать proposals.
  // Семантический отказ → BizonError (withRoute отдаст 403 + machine-код).
  if (user.ipScore < DAO_MIN_IP_SCORE) {
    throw new BizonError(
      `Требуется IP-score ${DAO_MIN_IP_SCORE}+ для создания предложений`,
      403,
      'DAO_IP_SCORE_REQUIRED',
    );
  }

  const { title, description, type, durationDays } = data as z.infer<typeof createProposalSchema>;
  const endDate = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000);

  const proposal = await db.daoProposal.create({
    data: {
      title,
      description,
      type,
      proposerId: user.id,
      endDate,
      minIpScore: DAO_MIN_IP_SCORE,
    },
  });

  return json({ proposal }, 201);
}, {
  schema: createProposalSchema,
  rateLimit: {
    key: 'dao:create',
    limit: RATE_CLASSES.AUTH_STRICT.limit,
    windowMs: RATE_CLASSES.AUTH_STRICT.windowMs,
  },
});
