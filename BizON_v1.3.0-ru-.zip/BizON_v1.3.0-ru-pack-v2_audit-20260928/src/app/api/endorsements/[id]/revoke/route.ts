// BizON API — R2: отзыв endorsement (POST /api/endorsements/[id]/revoke).
// AUTH_STRICT 10/мин; права (автор/получатель) и Trust≠Currency — в сервисе.
import { z } from 'zod';
import { json } from '@/lib/api-helpers';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { EndorsementService } from '@/lib/services/endorsement-service';

export const runtime = 'nodejs';

const paramsSchema = z.object({
  id: z.string().cuid('Некорректный id подтверждения'),
});

export const POST = withRoute(async (_req, { user, params }) => {
  const { id } = params as z.infer<typeof paramsSchema>;
  const result = await EndorsementService.revoke(id, user.id);
  return json(result);
}, {
  paramsSchema,
  rateLimit: {
    key: 'endorsements:revoke',
    limit: RATE_CLASSES.AUTH_STRICT.limit,
    windowMs: RATE_CLASSES.AUTH_STRICT.windowMs,
  },
});
