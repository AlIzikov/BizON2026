// BizON API — R2: Endorsements (GET список / POST создание).
// POST — AUTH_STRICT 10/мин (осмысленная мутация с гейтами N4/N6 в сервисе);
// GET — USER_READ (список по subjectId).
import { z } from 'zod';
import { json } from '@/lib/api-helpers';
import { withRoute, RATE_CLASSES } from '@/lib/with-route';
import { EndorsementService } from '@/lib/services/endorsement-service';

export const runtime = 'nodejs';

const createSchema = z.object({
  subjectId: z.string().cuid('Некорректный id пользователя'),
  skillName: z.string().trim().min(1, 'Навык обязателен').max(60),
  text: z.string().trim().min(100, 'Минимум 100 символов — подтверждение должно быть осмысленным').max(1000),
});

const listQuerySchema = z.object({
  subjectId: z.string().cuid('Некорректный id пользователя'),
  skillName: z.string().trim().min(1).max(60).optional(),
});

export const GET = withRoute(async (_req, { data }) => {
  const { subjectId, skillName } = data as z.infer<typeof listQuerySchema>;
  const endorsements = await EndorsementService.forRole(subjectId, skillName);
  return json({ endorsements, count: endorsements.length });
}, {
  schema: listQuerySchema,
  rateLimit: {
    key: 'endorsements:list',
    limit: RATE_CLASSES.USER_READ.limit,
    windowMs: RATE_CLASSES.USER_READ.windowMs,
  },
});

export const POST = withRoute(async (_req, { user, data }) => {
  const { subjectId, skillName, text } = data as z.infer<typeof createSchema>;
  const result = await EndorsementService.create(user.id, { subjectId, skillName, text });
  return json(result, 201);
}, {
  schema: createSchema,
  rateLimit: {
    key: 'endorsements:create',
    limit: RATE_CLASSES.AUTH_STRICT.limit,
    windowMs: RATE_CLASSES.AUTH_STRICT.windowMs,
  },
});
