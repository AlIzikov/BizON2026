// BizON API — GET /api/files/[id] (R5-P2: выдача файла с owner-гейтом).
//
// Файл НЕ публичен: читать может только владелец (или staff для модерации).
// В local-драйвере — бинарный стрим с корректным Content-Type/Content-Length
// + Content-Disposition (просмотр inline, имя = id.ext).
// Заголовок X-Content-Type-Options: nosniff — резюме/картинки не исполняются.
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { withRoute, RATE_CLASSES, jsonError } from '@/lib/with-route';
import { getFileBytes, activeDriver } from '@/lib/file-storage';

export const runtime = 'nodejs';

export const GET = withRoute<{ id: string }>(
  async (req, ctx) => {
    const file = await db.file.findUnique({ where: { id: ctx.params.id } });
    if (!file || file.deletedAt) return jsonError(404, 'Файл не найден', 'FILE_NOT_FOUND');

    const isOwner = file.ownerId === ctx.user.id;
    const staffRoles = ['admin', 'moderator', 'support'];
    const isStaff = (ctx.user.roles ?? '').split(',').some((r) => staffRoles.includes(r.trim()));
    if (!isOwner && !isStaff) {
      // 404 вместо 403 — не раскрываем существование чужого файла (IDOR-канон).
      return jsonError(404, 'Файл не найден', 'FILE_NOT_FOUND');
    }

    if (activeDriver() === 's3') {
      if (!file.url) return jsonError(501, 'S3-драйвер ещё не подключён (ждёт ключей R2)', 'S3_DRIVER_PENDING');
      return NextResponse.redirect(file.url, 302);
    }

    const bytes = await getFileBytes(file.storageKey);
    if (!bytes) return jsonError(404, 'Файл не найден (отсутствует на диске)', 'FILE_NOT_FOUND');

    return new NextResponse(new Uint8Array(bytes), {
      status: 200,
      headers: {
        'Content-Type': file.mimeType,
        'Content-Length': String(bytes.length),
        'Content-Disposition': `inline; filename="${file.id}"`,
        'X-Content-Type-Options': 'nosniff',
        'Cache-Control': 'private, max-age=0, no-store',
      },
    });
  },
  { rateLimit: { key: 'api:files/[id]:GET', limit: 120, windowMs: 60_000 } },
);
