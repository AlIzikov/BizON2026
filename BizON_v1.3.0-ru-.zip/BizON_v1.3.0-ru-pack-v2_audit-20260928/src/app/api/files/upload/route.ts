// BizON API — POST /api/files/upload (R5-P2: file storage, ЭТАП «остатки»).
//
// multipart/form-data с полем `file`; опционально `kind` = avatar | resume | generic.
// Гейты: auth (401), whitelist mime + size по kind (422), rate USER_WRITE-класс.
// Честность: файл НЕ публичен — только GET /api/files/[id] с owner-гейтом.
// S3-драйвер выбрасывает S3_DRIVER_NOT_IMPLEMENTED_YET → 501 (не имитируем успех).
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { withRoute, RATE_CLASSES, jsonError } from '@/lib/with-route';
import { putFile, validateFileMeta, activeDriver } from '@/lib/file-storage';

export const runtime = 'nodejs';

export const POST = withRoute(
  async (req, ctx) => {
    if (activeDriver() !== 'local') {
      return jsonError(501, 'S3-драйвер ещё не подключён (ждёт ключей R2)', 'S3_DRIVER_PENDING');
    }

    let form: FormData;
    try {
      form = await req.formData();
    } catch {
      return jsonError(400, 'Ожидается multipart/form-data с полем file', 'BAD_MULTIPART');
    }

    const blob = form.get('file');
    if (!(blob instanceof File)) {
      return jsonError(422, 'Поле file обязательно', 'FILE_REQUIRED');
    }
    const kindRaw = form.get('kind');
    const kind = typeof kindRaw === 'string' && ['avatar', 'resume', 'generic'].includes(kindRaw) ? kindRaw : 'generic';

    const violation = validateFileMeta(kind, blob.type, blob.size);
    if (violation === 'MIME_NOT_ALLOWED') return jsonError(422, 'Тип файла не разрешён (png/jpeg/webp/pdf)', violation);
    if (violation === 'MIME_MISMATCH_KIND') return jsonError(422, `Тип файла не соответствует kind=${kind}`, violation);
    if (violation === 'EMPTY_FILE') return jsonError(422, 'Файл пуст', violation);
    if (violation === 'FILE_TOO_LARGE') return jsonError(422, 'Файл слишком большой (лимит по kind)', violation);

    const bytes = Buffer.from(await blob.arrayBuffer());

    // Предварительная строка (id нужен для storageKey), физическое сохранение,
    // при ошибке — откат строки (не оставляем «фантомных» записей).
    const created = await db.file.create({
      data: {
        ownerId: ctx.user.id,
        kind,
        mimeType: blob.type,
        size: blob.size,
        storageKey: 'pending',
      },
    });

    try {
      const { storageKey, sha256, url } = await putFile({ id: created.id, kind, mimeType: blob.type, bytes });
      const updated = await db.file.update({
        where: { id: created.id },
        data: { storageKey, sha256, url },
      });
      return NextResponse.json(
        {
          file: {
            id: updated.id,
            kind: updated.kind,
            mimeType: updated.mimeType,
            size: updated.size,
            url: updated.url,
            downloadUrl: `/api/files/${updated.id}`,
            createdAt: updated.createdAt.toISOString(),
          },
        },
        { status: 201 },
      );
    } catch (e) {
      await db.file.delete({ where: { id: created.id } }).catch(() => undefined);
      if (e instanceof Error && e.message === 'S3_DRIVER_NOT_IMPLEMENTED_YET') {
        return jsonError(501, 'S3-драйвер ещё не подключён (ждёт ключей R2)', 'S3_DRIVER_PENDING');
      }
      return jsonError(500, 'Не удалось сохранить файл', 'FILE_STORE_FAILED');
    }
  },
  // R5-P2: multipart opt-in (withRoute канон JSON сохранён для остальных роутов);
  // maxBodyBytes 6MB — страховка до чтения formData (лимиты kind валидируются после).
  { multipart: true, maxBodyBytes: 6 * 1024 * 1024, rateLimit: { key: 'api:files/upload:POST', limit: 20, windowMs: 60_000 } },
);
