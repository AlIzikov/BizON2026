// BizON API — /api/consent/cookie (R5-P1 пункт D2: cookie consent EU).
//
// Согласие на файлы cookie (GDPR/ePrivacy). Работает ДО логина: баннер виден
// анонимному посетителю, поэтому запись в журнале доказательств ConsentLog
// честно анонимная — userId='anonymous' (явный маркер, не выдуманный uid).
//
// Доказательства (канон приватности, ConsentLog): время (occurredAt —
// серверное UTC), IP (getClientIp, TRUST_PROXY-aware), User-Agent, версия
// текста согласия и SHA-256 текста. Схема БД НЕ менялась (модель ConsentLog
// уже была; kind='cookie' — аддитивное значение существующего строкового поля).
//
// Гео-честность (canon not_configured): сервис геолокации не подключён,
// поэтому гео-дифференциация «EU-only» НЕ имитируется — эндпоинт обслуживает
// всех и баннер показывается всем (строжайшая интерпретация EU-требования).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { getClientIp } from '@/lib/security/rate-limiter';
import { writeConsentLog } from '@/lib/privacy/privacy-service';
import {
  COOKIE_CONSENT_NAME,
  COOKIE_CONSENT_MAX_AGE_SECONDS,
  COOKIE_CONSENT_TEXT_VERSION,
  cookieConsentTextHash,
  encodeConsentState,
  decodeConsentState,
  readCookieFromHeader,
  type ConsentState,
} from '@/lib/security/cookie-consent';

export const runtime = 'nodejs';

// POST: решение пользователя. action='granted' — принятие (любой набор
// категорий), action='withdrawn' — отзыв согласия (необязательные категории
// отключаются; флаги ниже передаются выключенными баннером).
const decisionSchema = z.object({
  analytics: z.boolean(),
  marketing: z.boolean(),
  action: z.enum(['granted', 'withdrawn']),
});

export const POST = withRoute(
  async (req, ctx) => {
    const body = decisionSchema.parse(ctx.data);

    const state: ConsentState = {
      necessary: true,
      analytics: body.analytics,
      marketing: body.marketing,
      decidedAt: new Date().toISOString(),
    };

    await writeConsentLog({
      userId: ctx.user?.id ?? 'anonymous',
      kind: 'cookie',
      action: body.action,
      ipAddress: getClientIp(req),
      userAgent: req.headers.get('user-agent'),
      consentVersion: COOKIE_CONSENT_TEXT_VERSION,
      consentTextHash: cookieConsentTextHash(),
    });

    // Cookie состояния — НЕ HttpOnly (баннер/диалог читают состояние с клиента;
    // секретов в значении нет), SameSite=Lax, 180 дней.
    const res = NextResponse.json({ ok: true });
    res.cookies.set(COOKIE_CONSENT_NAME, encodeConsentState(state), {
      httpOnly: false,
      sameSite: 'lax',
      maxAge: COOKIE_CONSENT_MAX_AGE_SECONDS,
      path: '/',
    });
    return res;
  },
  { auth: false, rateLimit: { key: 'api:consent:cookie:post', limit: 30, windowMs: 60_000 } },
);

// GET: текущее состояние для UI. Без PII — только агрегат флагов согласия.
// Битая/поддельная кука → decided:false (fail-closed: баннер покажется снова).
export const GET = withRoute(
  async (req) => {
    const raw = readCookieFromHeader(req.headers.get('cookie'), COOKIE_CONSENT_NAME);
    const state = decodeConsentState(raw);
    if (!state) return NextResponse.json({ decided: false });
    return NextResponse.json({ decided: true, state });
  },
  { auth: false, rateLimit: { key: 'api:consent:cookie:get', limit: 120, windowMs: 60_000 } },
);
