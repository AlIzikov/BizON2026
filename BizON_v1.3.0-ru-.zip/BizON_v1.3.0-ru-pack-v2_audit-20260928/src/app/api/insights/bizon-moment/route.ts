// BizON API — /api/insights/bizon-moment
// Phase 2 — BIZON MOMENT: AI-инсайт «BizON заметил кое-что интересное».
//
// GET — получить текущий (непрочитанный) инсайт. Если нет — пытается сгенерировать
//        новый (если прошло ≥ 7 дней с последнего). Возвращает:
//          { insight: BizonInsightResult | null, optIn: boolean }
import { json, withRoute } from '@/lib/api-helpers';
import { BizonMomentService } from '@/lib/services/bizon-moment-service';

export const runtime = 'nodejs';

export const GET = withRoute(async (req, { user }) => {
  // 1. Проверяем opt-in
  const optIn = await BizonMomentService.getOptIn(user.id);

  if (!optIn) {
    return json({ insight: null, optIn: false });
  }

  // 2. Пытаемся сгенерировать новый инсайт (если прошло ≥ 7 дней).
  //    generate() вернёт последний существующий, если неделя ещё не прошла.
  let insight = await BizonMomentService.generate(user.id).catch((e) => {
    console.error('[bizon-moment] generate error:', e);
    return null;
  });

  // 3. Если generate ничего не дал (нет паттерна) — берём текущий unread
  if (!insight) {
    insight = await BizonMomentService.getCurrent(user.id);
  }

  return json({ insight, optIn: true });
});
