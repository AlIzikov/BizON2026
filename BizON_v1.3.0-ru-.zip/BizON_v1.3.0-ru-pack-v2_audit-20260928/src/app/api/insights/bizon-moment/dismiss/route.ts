// BizON API — /api/insights/bizon-moment/dismiss
// Phase 2 — BIZON MOMENT: пометить текущий инсайт прочитанным (dismiss).
// Body: { insightId } — ID инсайта для dismiss.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson , withRoute } from '@/lib/api-helpers';
import { BizonMomentService } from '@/lib/services/bizon-moment-service';

export const runtime = 'nodejs';

async function __bizon_impl_post(req: Request) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json().catch(() => ({}));
    const { insightId } = body ?? {};

    if (insightId && typeof insightId === 'string') {
      // Dismiss конкретного инсайта
      await BizonMomentService.markRead(insightId, user.id);
    } else {
      // Dismiss всех unread инсайтов (fallback)
      await db.aiInsight.updateMany({
        where: { userId: user.id, type: 'bizon_moment', isRead: false },
        data: { isRead: true },
      });
    }

    return json({ ok: true });
  } catch (e) {
    console.error('[bizon-moment/dismiss] error:', e);
    return errorJson('Ошибка dismiss', 500);
  }
}


// DEF-16 (FIX-07): withRoute — auth 401, malformed JSON → 400, P2002 → 409, safe 500 + H11 лимит 60/мин.
export const POST = withRoute(__bizon_impl_post, {
  rateLimit: { key: 'api:insights/bizon-moment/dismiss:POST', limit: 60, windowMs: 60_000 },
});
