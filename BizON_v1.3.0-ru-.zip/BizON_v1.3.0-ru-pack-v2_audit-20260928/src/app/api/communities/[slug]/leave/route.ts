// BizON API — /api/communities/[slug]/leave
// Этап 7.2 COM: выйти из сообщества (явный POST-эндпоинт).
// (Также поддерживается DELETE /api/communities/[slug]/join для обратной совместимости.)
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson , withRoute } from '@/lib/api-helpers';
import { CommunityService } from '@/lib/services';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

async function __bizon_impl_post(req: Request, ctx: { params: {  slug: string  } }) {
  const { slug } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const community = await db.community.findUnique({
      where: { slug },
      select: { id: true, name: true, ownerId: true },
    });
    if (!community) return errorJson('Сообщество не найдено', 404);

    // Владелец не может покинуть своё сообщество (нужно передать владение или удалить)
    if (community.ownerId === user.id) {
      return errorJson('Владелец не может покинуть сообщество. Передайте владение или удалите сообщество.', 403);
    }

    const result = await CommunityService.leave(community.id, user.id);
    if (!result.left) {
      return errorJson('Вы не состоите в этом сообществе', 400);
    }
    return json({ left: true, communityName: community.name });
  } catch (e: any) {
    return errorJson(e.message ?? 'Ошибка выхода из сообщества', 400);
  }
}


// DEF-16 (FIX-07): withRoute — auth 401, malformed JSON → 400, P2002 → 409, safe 500 + H11 лимит 60/мин.
export const POST = withRoute<{  slug: string  }>(__bizon_impl_post, {
  rateLimit: { key: 'api:communities/[slug]/leave:POST', limit: 60, windowMs: 60_000 },
});
