// BizON API — /api/events/[id]/attendees
// Этап 7.1 EVT: список участников мероприятия (для блока «С кем вы пересеклись?»).
// Возвращает участников со status = 'going' и флаг isPast (мероприятие уже прошло).
//
// GET /api/events/[id]/attendees
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { EventService } from '@/lib/services';

export const runtime = 'nodejs';

export const GET = withRoute<{ id: string }>(async (req, { params, user }) => {
  const { id } = params;

  try {
    const result = await EventService.list(user.id);
    return json(result);
  } catch (e: any) {
    return errorJson(e.message ?? 'Мероприятие не найдено', 404);
  }
});
