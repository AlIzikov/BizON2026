// BizON API — /api/cashier/status (Виртуальная касса, решение владельца №4)
// GET — честный статус единого платёжного модуля: режим (virtual|real),
// комиссия платформы, «прилавки» (эскроу Store / пополнения / подписки)
// и состояние KYC-гейта реальных денег (docs/KYC-REAL-GATEWAY-GATE.md).
// Данных пользователей не содержит — но требует авторизации, чтобы статус
// платёжного контура не светился наружу.
// API-001 (29-A-redux, аудит 22-09-26): роут переведён на withRoute —
//   CSRF/413/415/единый error-контракт; rate-limit 30/мин сохранён (RATE_CLASSES-стиль).
import { withRoute, json } from '@/lib/api-helpers';
import { VirtualCashierService } from '@/lib/services/virtual-cashier-service';
import { CashierPortsService } from '@/lib/services/cashier-ports-service';

export const runtime = 'nodejs';

export const GET = withRoute(
  async (req, ctx) => {
    const status = VirtualCashierService.status();
    const ports = await CashierPortsService.statusSummary();
    return json({ ...status, ports });
  },
  { rateLimit: { key: 'cashier:status', limit: 30, windowMs: 60_000 } },
);
