// BizON chat-service — реалтайм-транспорт мессенджера (направление А) и
// live-уведомлений (направление Б).
//
// Разделение ответственности:
//  - каноничное хранение и бизнес-правила сообщений (connection/ipScore-гейт,
//    лимиты, notifications) остаются в Next REST;
//  - этот сервис — ТОЛЬКО транспорт: комнаты, авторизация handshake,
//    релей typing/read/presence, доставка новых сообщений и уведомлений;
//  - доставка инициируется Next API через internal listener (:3004, bind 127.0.0.1)
//    с общим секретом — forged-броадкасты от клиентов невозможны.
//
// Порты: 3003 — публичный сокет (Caddy форвардит по XTransformPort, путь '/'),
//        3004 — internal HTTP (только 127.0.0.1 + x-internal-secret).
import { createServer, type IncomingMessage, type ServerResponse } from 'http';
import { Server, type Socket as IoSocket } from 'socket.io';
import { timingSafeEqual } from 'crypto';

// ===== DEV-SUPERVISOR: держит Next.js dev-сервер (:3000) живым =====
// Почему здесь: session-reaper платформы прибивает ЛЮБЫЕ процессы, заспавненные
// из tool-сессий агента, сразу после завершения вызова (эксперимент 2026-09-24:
// умирает даже `sleep`); бут-процессы (этот bun, старт из start.sh) неподсудны.
// Отдельно next-server периодически добивает OOM (4 ГБ RAM, Turbopack-компиляция).
// Супервизор живёт в бут-процессе: раз в 15с проверяет /api/health на :3000 и при
// смерти спавнит detached `bun run dev` — потомок бут-дерева, недосягаемый для
// reaper'а. bun --hot reload этого файла не убивает старую версию модуля
// (проверено: даже EADDRINUSE при повторном listen не роняет процесс).
if (!(globalThis as any).__bizonDevSupervisor) {
  (globalThis as any).__bizonDevSupervisor = true;
  const ensureNextDev = async (): Promise<void> => {
    try {
      const r = await fetch('http://127.0.0.1:3000/api/health', { signal: AbortSignal.timeout(2500) });
      if (r.ok) return;
    } catch {
      // :3000 недоступен — идём спавнить
    }
    const g = globalThis as any;
    if (g.__bizonDevSpawning) return;
    g.__bizonDevSpawning = true;
    setTimeout(() => { g.__bizonDevSpawning = false; }, 60_000);
    try {
      console.log('[dev-supervisor] :3000 недоступен — спавню `bun run dev` (detached, cwd=/home/z/my-project)');
      Bun.spawn(['bun', 'run', 'dev'], {
        cwd: '/home/z/my-project',
        env: { ...process.env, BIZON_DEMO_AUTH: '1' },
        stdin: 'ignore',
        stdout: 'ignore',
        stderr: 'ignore',
      }).unref();
    } catch (e) {
      console.log('[dev-supervisor] spawn error:', e);
    }
  };
  setInterval(() => { void ensureNextDev(); }, 15_000);
  void ensureNextDev(); // немедленная первая проверка
}

const WS_PORT = 3003;       // жёстко: не PORT-env (требование окружения)
const INTERNAL_PORT = 3004; // internal, локальный bind
const NEXT_ORIGIN = 'http://127.0.0.1:3000';
const SECRET = process.env.CHAT_INTERNAL_SECRET ?? '';

const httpServer = createServer();
const io = new Server(httpServer, {
  // DO NOT change the path, it is used by Caddy to forward the request to the correct port
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
});

// ===== Утилиты =====

function getSessionToken(cookieHeader: string | undefined | null): string | null {
  if (!cookieHeader) return null;
  const m = cookieHeader.match(/bizon_session=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : null;
}

// Валидация сессии через тот же авторизационный контур, что и REST (GET /api/auth/me
// → getUserFromRequest: токен, TTL, soft-delete). БД здесь НЕ дублируется.
async function validateSession(cookieHeader: string | undefined | null): Promise<{ id: string; name: string } | null> {
  const token = getSessionToken(cookieHeader);
  if (!token || token.length < 16 || token.length > 128) return null;
  try {
    const res = await fetch(`${NEXT_ORIGIN}/api/auth/me`, {
      headers: { cookie: `bizon_session=${encodeURIComponent(token)}` },
      signal: AbortSignal.timeout(4000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { user?: { id?: unknown; name?: unknown } };
    const u = data?.user;
    if (!u || typeof u.id !== 'string' || u.id.length === 0 || u.id.length > 64) return null;
    return { id: u.id, name: typeof u.name === 'string' ? u.name.slice(0, 120) : '' };
  } catch {
    return null;
  }
}

function secretOk(given: unknown): boolean {
  if (!SECRET || typeof given !== 'string' || given.length !== SECRET.length) return false;
  try {
    return timingSafeEqual(Buffer.from(given), Buffer.from(SECRET));
  } catch {
    return false;
  }
}

const isStr = (v: unknown, min: number, max: number): v is string =>
  typeof v === 'string' && v.length >= min && v.length <= max;

// Членство в диалоге проверяется существующим Next-API авторизации
// (GET /api/messages/:id → 200 только участнику; заодно это фиксирует isRead).
async function isConversationMember(conversationId: string, cookieHeader: string | undefined | null): Promise<boolean> {
  try {
    const res = await fetch(`${NEXT_ORIGIN}/api/messages/${encodeURIComponent(conversationId)}`, {
      headers: { cookie: cookieHeader ?? '' },
      signal: AbortSignal.timeout(4000),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ===== Handshake auth: без валидной сессии коннект отклоняется =====

io.use(async (socket, next) => {
  const user = await validateSession(socket.handshake.headers.cookie);
  if (!user) {
    console.log(`[chat-service] rejected unauthorized handshake ${socket.id}`);
    return next(new Error('unauthorized'));
  }
  socket.data.user = user;
  socket.data.convs = new Set<string>();
  socket.data.lastTypingAt = 0;
  next();
});

// Presence: userId → число живых сокетов
const presence = new Map<string, number>();

io.on('connection', (socket: IoSocket) => {
  const user = socket.data.user as { id: string; name: string };
  const convs: Set<string> = socket.data.convs as Set<string>;

  socket.join(`user:${user.id}`);
  presence.set(user.id, (presence.get(user.id) ?? 0) + 1);

  const broadcastPresence = (conversationId: string, online: boolean) => {
    io.to(`conv:${conversationId}`).emit('presence:state', { conversationId, userId: user.id, online });
  };

  socket.on('conversation:join', async (payload: unknown, ack?: (r: unknown) => void) => {
    const conversationId = (payload as { conversationId?: unknown })?.conversationId;
    if (!isStr(conversationId, 1, 64)) {
      socket.emit('conversation:error', { reason: 'bad_request' });
      if (typeof ack === 'function') ack({ ok: false });
      return;
    }
    const ok = await isConversationMember(conversationId, socket.handshake.headers.cookie);
    if (!ok) {
      socket.emit('conversation:error', { conversationId, reason: 'forbidden' });
      if (typeof ack === 'function') ack({ ok: false });
      return;
    }
    socket.join(`conv:${conversationId}`);
    convs.add(conversationId);
    broadcastPresence(conversationId, true);
    // сообщить новому участнику, кто уже онлайн в комнате
    const room = io.sockets.adapter.rooms.get(`conv:${conversationId}`);
    const seen = new Set<string>([user.id]);
    if (room) {
      for (const sid of room) {
        const peer = io.sockets.sockets.get(sid);
        const peerUser = peer?.data?.user as { id: string } | undefined;
        if (peerUser && !seen.has(peerUser.id)) {
          seen.add(peerUser.id);
          socket.emit('presence:state', { conversationId, userId: peerUser.id, online: true });
        }
      }
    }
    if (typeof ack === 'function') ack({ ok: true });
  });

  socket.on('conversation:leave', (payload: unknown) => {
    const conversationId = (payload as { conversationId?: unknown })?.conversationId;
    if (!isStr(conversationId, 1, 64) || !convs.has(conversationId)) return;
    socket.leave(`conv:${conversationId}`);
    convs.delete(conversationId);
  });

  socket.on('conversation:typing', (payload: unknown) => {
    const p = (payload ?? {}) as { conversationId?: unknown; isTyping?: unknown };
    const conversationId = p.conversationId;
    if (!isStr(conversationId, 1, 64) || !convs.has(conversationId)) return; // только свои комнаты
    const isTyping = p.isTyping === true;
    // троттлинг только на true, чтобы «false» гасил индикатор мгновенно
    if (isTyping) {
      const now = Date.now();
      if (now - (socket.data.lastTypingAt as number) < 700) return;
      socket.data.lastTypingAt = now;
    }
    socket.to(`conv:${conversationId}`).emit('conversation:typing', {
      conversationId,
      userId: user.id,
      isTyping,
    });
  });

  socket.on('conversation:read', (payload: unknown) => {
    const conversationId = (payload as { conversationId?: unknown })?.conversationId;
    if (!isStr(conversationId, 1, 64) || !convs.has(conversationId)) return;
    socket.to(`conv:${conversationId}`).emit('conversation:read', {
      conversationId,
      readerId: user.id,
    });
  });

  socket.on('disconnect', () => {
    const left = (presence.get(user.id) ?? 1) - 1;
    if (left <= 0) presence.delete(user.id);
    else presence.set(user.id, left);
    for (const conversationId of convs) {
      io.to(`conv:${conversationId}`).emit('presence:state', {
        conversationId,
        userId: user.id,
        online: false,
      });
    }
  });
});

// ===== Internal listener (:3004, только 127.0.0.1 + секрет) =====

function readBody(req: IncomingMessage, limit = 16384): Promise<string | null> {
  return new Promise((resolve) => {
    let size = 0;
    const chunks: Buffer[] = [];
    req.on('data', (c: Buffer) => {
      size += c.length;
      if (size > limit) {
        resolve(null);
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', () => resolve(null));
  });
}

function reply(res: ServerResponse, code: number, body?: unknown) {
  res.writeHead(code, { 'content-type': 'application/json' });
  res.end(body === undefined ? '' : JSON.stringify(body));
}

const internal = createServer(async (req, res) => {
  const addr = req.socket.remoteAddress ?? '';
  if (addr !== '127.0.0.1' && addr !== '::1' && addr !== '::ffff:127.0.0.1') {
    return reply(res, 403, { error: 'forbidden' });
  }
  if (req.method !== 'POST') return reply(res, 404, { error: 'not_found' });
  if (!secretOk(req.headers['x-internal-secret'])) {
    return reply(res, 401, { error: 'unauthorized' });
  }

  const raw = await readBody(req);
  if (raw === null) return reply(res, 413, { error: 'too_large' });
  let body: unknown;
  try {
    body = JSON.parse(raw);
  } catch {
    return reply(res, 400, { error: 'bad_json' });
  }

  if (req.url === '/internal/broadcast') {
    const b = (body ?? {}) as Record<string, unknown>;
    const msg = b.message as Record<string, unknown> | undefined;
    const participants = b.participants;
    if (
      !isStr(b.conversationId, 1, 64) ||
      !msg ||
      !isStr(msg.id, 1, 64) ||
      typeof msg.content !== 'string' || msg.content.length > 4000 ||
      !isStr(msg.authorId, 1, 64) ||
      typeof msg.isRead !== 'boolean' ||
      !msg.createdAt ||
      !Array.isArray(participants) || participants.length !== 2 ||
      !participants.every((p) => isStr(p, 1, 64))
    ) {
      return reply(res, 400, { error: 'bad_payload' });
    }
    const payload = { conversationId: b.conversationId, message: msg };
    io.to(`conv:${b.conversationId}`).emit('message:new', payload);
    const activity = {
      conversationId: b.conversationId,
      lastMessage: { content: msg.content, authorId: msg.authorId, createdAt: msg.createdAt },
      message: msg,
    };
    for (const p of participants as string[]) io.to(`user:${p}`).emit('conversation:activity', activity);
    return reply(res, 200, { ok: true });
  }

  if (req.url === '/internal/read') {
    const b = (body ?? {}) as Record<string, unknown>;
    if (!isStr(b.conversationId, 1, 64) || !isStr(b.readerId, 1, 64)) {
      return reply(res, 400, { error: 'bad_payload' });
    }
    io.to(`conv:${b.conversationId}`).emit('conversation:read', {
      conversationId: b.conversationId,
      readerId: b.readerId,
    });
    return reply(res, 200, { ok: true });
  }

  // Направление Б: живое уведомление конкретному пользователю.
  // Канон создания — Next REST (NotificationService + точки db.notification.create);
  // здесь только доставка в личную комнату user:{id}.
  if (req.url === '/internal/notify') {
    const b = (body ?? {}) as Record<string, unknown>;
    const n = b.notification as Record<string, unknown> | undefined;
    if (
      !isStr(b.userId, 1, 64) ||
      !n ||
      !isStr(n.id, 1, 64) ||
      !isStr(n.type, 1, 40) ||
      !isStr(n.title, 1, 300) ||
      (n.content !== null && typeof n.content !== 'string') ||
      (typeof n.content === 'string' && n.content.length > 4000) ||
      (n.link !== null && typeof n.link !== 'string') ||
      (typeof n.link === 'string' && (n.link.length < 1 || n.link.length > 200)) ||
      typeof n.createdAt !== 'string' || n.createdAt.length < 4 || n.createdAt.length > 40 ||
      typeof n.isRead !== 'boolean'
    ) {
      return reply(res, 400, { error: 'bad_payload' });
    }
    io.to(`user:${b.userId}`).emit('notification:new', {
      id: n.id,
      type: n.type,
      title: n.title,
      content: n.content ?? null,
      link: n.link ?? null,
      createdAt: n.createdAt,
      isRead: n.isRead,
    });
    return reply(res, 200, { ok: true });
  }

  // Направление Б: сигнал «список уведомлений изменился» (bulk createMany,
  // где нет записей для точечного push). Клиент тихо перечитывает REST-список.
  if (req.url === '/internal/notify-refresh') {
    const b = (body ?? {}) as Record<string, unknown>;
    const userIds = b.userIds;
    if (
      !Array.isArray(userIds) || userIds.length < 1 || userIds.length > 50 ||
      !userIds.every((id) => isStr(id, 1, 64))
    ) {
      return reply(res, 400, { error: 'bad_payload' });
    }
    for (const id of new Set(userIds as string[])) {
      io.to(`user:${id}`).emit('notification:refresh', {});
    }
    return reply(res, 200, { ok: true });
  }

  return reply(res, 404, { error: 'not_found' });
});

httpServer.listen(WS_PORT, () => {
  console.log(`[chat-service] socket.io listening on :${WS_PORT}`);
});
internal.listen(INTERNAL_PORT, '127.0.0.1', () => {
  console.log(`[chat-service] internal listener on 127.0.0.1:${INTERNAL_PORT}`);
});
