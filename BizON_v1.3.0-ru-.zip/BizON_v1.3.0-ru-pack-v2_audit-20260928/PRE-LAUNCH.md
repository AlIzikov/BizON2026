# BizON — PRE-LAUNCH CHECKLIST

> 🔴 **НЕЛЬЗЯ ДЕПЛОИТЬ В PRODUCTION ПОКА НЕ ЗАКРЫТЫ ВСЕ ПУНКТЫ НИЖЕ**
>
> Этот файл — «красная линия». Каждый пункт должен быть `[x]` перед deploy.
> Источник: `/home/z/my-project/download/BizON-final-audit.md` + `TASKS.md`
>
> Обновление FIX-волны 10.09.2026 (FIX-01…FIX-09): часть пунктов закрыта и верифицирована —
> детали и проверки в `docs/AFTER-AUDIT.md`. Остальные — обязательны до deploy.

---

## 🔴 БЕЗОПАСНОСТЬ — КРИТИЧЕСКОЕ (нельзя в prod без этого)

- [ ] **C1.** В БД нет plaintext PII (`email`, `bio`, `location`, `phone` поля удалены, остались только `*Encrypted` + `emailHash`)
  - Проверка: `sqlite3 db/custom.db "SELECT email FROM User LIMIT 1"` → NULL/пусто
  - Статус W1.5 (14.09.2026): **ЗАКРЫТО** — plaintext email 0/32 (миграция `scripts/migrate-email-encrypt.ts`, верифицирована); новые регистрации НЕ пишут plaintext (auth.ts registerUser); пин `BIZON_ENCRYPTION_KEY` в `.env` (стабильный ключ), lookup по emailHash проверен runtime (register→login 200)
  - Остаток: 20 legacy QA-аккаунтов с emailHash=null (plaintext потерян историческими эфемерными ключами) — честное состояние «email не привязан», для прод-пилота не влияет (пользователи регистрируются заново)

- [x] **C2.** `BIZON_ENCRYPTION_KEY` задан в `.env`, fallback удалён *(закрыто ранее; проверено FIX-09: `src/instrumentation.ts:34` — в production без ключа сервер не стартует (throw), dev-fallback только с console.warn)*
  - Проверка: `node -e "require('./src/lib/security/crypto')"` без env → исключение в prod-режиме

- [x] **C3.** `PATCH /api/users/[id]` требует auth + ownership check *(закрыто FIX-02, верифицировано FIX-09: чужой профиль → 403 «Можно редактировать только свой профиль»; `roles` вырезан из whitelist — масс-ассайнмент невозможен)*
  - Проверка: `curl -X PATCH /api/users/ЧУЖОЙ_ID -b my-cookie -d '{"name":"хак"}'` → 403 ✅

- [ ] **C4.** `fetchLinkPreview` блокирует приватные подсети + имеет allow-list доменов
  - Проверка: пост с URL `http://169.254.169.254/` → preview не запрашивается

- [ ] **C5.** Bearer token убран из localStorage и JSON-ответа. Только HttpOnly cookie
  - Проверка: `localStorage.getItem('bizon-app-store')` → нет `token`

- [ ] **H3.** `POST /api/jobs` работает (TDZ-ошибка исправлена)
  - Проверка: company-аккаунт создаёт вакансию через UI → 201

- [ ] **H6.** CORS динамический с whitelist, без `localhost` в prod
  - Проверка: `curl -H "Origin: https://evil.com" -I /` → нет `Access-Control-Allow-Origin: https://evil.com`

- [ ] **H9.** `.env` не в git
  - Проверка: `git ls-files | grep '\.env$'` → пусто

- [ ] **H10.** `DEMO_PASSWORD` убран из production-режима
  - Проверка: production-build без токена → страница входа с пустыми полями

- [ ] **H11.** Rate limit на всех mutation-эндпоинтах *(частично: FIX-07 — withRoute+rateLimit на 21 ключевом мутирующем хендлере; остальные ~200 — при касании)*
  - Проверка: 100 запросов на `/api/posts` POST за секунду → 429

- [ ] **H12.** AI-эндпоинты с rate limit + кэш 1 час *(частично: гейты Free-лимитов есть; Redis/кэш — отложено)*
  - Проверка: 100 запросов на `/api/ai/matchmaker` за час → 429

---

## 🟡 ВХОД ДЛЯ ПОЛЬЗОВАТЕЛЕЙ (нельзя публично запускать без этого)

- [ ] **P1-1.** Landing page на `/` работает
  - Проверка: открыть `/` без токена → landing с UVP и кнопкой регистрации

- [ ] **P1-2.** Onboarding wizard для новых юзеров
  - Проверка: новый юзер после регистрации → wizard (3-4 шага)

- [x] **P1-3.** Mobile: все разделы доступны (5 + «Ещё») *(закрыто FIX-05, верифицировано FIX-09 E2E на 390px: таб-бар grid-cols-5 (4 раздела + «Ещё»), подписи 12px, FAB не перекрывает; Сообщения/Настройки/Проекты/AI-Поиск открываются из sheet)*
  - Проверка: на мобильном можно открыть Сообщения/Проекты/AI-Поиск/Настройки ✅

- [ ] **P1-4.** Mobile SubSectionBar работает
  - Проверка: на мобильном можно переключить recommended/all/mine в ленте

- [ ] **P1-13.** Retry-кнопки при ошибках API
  - Проверка: симулировать ошибку → есть «Повторить»

- [ ] **P1-16.** Friendly error messages (без `e.message`) *(частично: FIX-07 — покрытые withRoute-роуты отдают «Внутренняя ошибка сервера» на 5xx и чистые 400/403/404; остальные роуты — при касании)*
  - Проверка: ошибка → toast без технического текста

---

## 🟢 АНАЛИТИКА И КОМПЛАЕНС (нельзя маркетить без этого)

- [ ] **P2-1.** Yandex Metrica / GA4 подключена
  - Проверка: в Network видны запросы; события регистрируются

- [ ] **P2-2.** OG image + Twitter Card
  - Проверка: share ссылки в Telegram → превью с картинкой

- [ ] **H13.** AuditLog вызывается во всех routes с PII
  - Проверка: логин → запись в `auditLog`

- [ ] **M5.** `.env.example` создан с описанием всех переменных
  - Проверка: файл существует, описаны `BIZON_ENCRYPTION_KEY`, `DATABASE_URL`, etc.

---

## 🔵 ФИНАЛЬНОЕ ТЕСТИРОВАНИЕ (за 1 день до deploy)

- [ ] **T1.** `next build` без ошибок и warning'ов
- [x] **T2.** `npx tsc --noEmit` без ошибок *(верифицировано FIX-09: 0 ошибок, strict + `noImplicitAny: true`, `ignoreBuildErrors: false`)*
- [ ] **T3.** Все API-эндпоинты отвечают 200/201/204 на корректные запросы
- [ ] **T4.** Все API-эндпоинты отвечают 401 на запросы без auth
- [ ] **T5.** Lighthouse audit: Performance ≥ 80, Accessibility ≥ 90, Best Practices ≥ 90
- [ ] **T6.** Мобильная эмуляция (iPhone 12): все разделы доступны, нет горизонтального скролла *(частично проверено FIX-09 E2E 390px: разделы доступны, FAB/таб-бар без перекрытий; горизонтальный скролл не замерялся)*
- [ ] **T7.** Тёмная тема: все элементы читаемы, нет белых пятен *(частично проверено FIX-09 E2E: primary-пара ≈12:1, бейджи на `--success-text`, белые пятна profile/skip-link на токенах; полный проход экранов не делался)*
- [ ] **T8.** Logout → все cookie удалены, redirect на landing
- [ ] **T9.** Сессия истекла через 7 дней → redirect на landing (не на дашборд)
- [ ] **T10.** Backup БД создан и проверен (восстановление работает)

---

## 📋 ПОРЯДОК ДЕЙСТВИЙ ПЕРЕД DEPLOY

```
1. Пройти ВСЕ пункты выше → все [x]
2. Сделать backup БД: cp db/custom.db db/custom.db.bak.$(date +%Y%m%d)
3. Запустить тесты: npm test (если есть)
4. Запустить build: npm run build
5. Стартануть prod-сервер: NODE_ENV=production node .next/standalone/server.js
6. Прогнать smoke-тесты: регистрация → логин → пост → вакансия → logout
7. Включить аналитику в прод-конфиге
8. Настроить мониторинг (Uptime Robot / Better Stack)
9. Сообщить команде: «deploy завершён, watchers включены»
10. Фиксировать метрики первые 24 часа: 5xx errors, response time, DAU
```

---

## 🚨 ЕСЛИ ЧТО-ТО ПОШЛО НЕ ТАК ПОСЛЕ DEPLOY

1. **Откат БД:** `cp db/custom.db.bak.YYYYMMDD db/custom.db`
2. **Откат кода:** `git revert HEAD` → redeploy
3. **Уведомить команду:** в Slack/Telegram канал
4. **Post-mortem через 24 часа:** что произошло, почему, как предотвратить

---

**ПОСЛЕДНЕЕ ПРАВИЛО:** если хоть один пункт выше не закрыт — деплой отменяется. Без исключений. Без «ну почти готово». Без «потом поправим».
