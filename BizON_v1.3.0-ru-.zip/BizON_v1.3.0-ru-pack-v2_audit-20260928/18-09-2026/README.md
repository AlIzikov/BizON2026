# Резервная копия BizON — 18.09.2026

Назначение: точка отката перед стартом реализации **Плана-v2** (BIZON MASTER PLATFORM BLUEPRINT V2).

## Состав

| Файл | Что это |
|---|---|
| `План-v2.md` | Мастер-план архитектора от 18.09.2026 (BIZON MASTER PLATFORM, 48 секций) — сохранён дословно |
| `bizon-snapshot-2026-09-18_1735.tar.gz` | Полный снапшот рабочей версии проекта на момент 17:35 (3164 объекта) |
| `SHA256SUMS.txt` | Контрольные суммы архива и плана |

В снапшот включены: исходники (src, mini-services), схемы и БД (prisma, db/custom.db), конфиги (.env, Caddyfile, ключ шифрования .bizon-encryption-key), гейт-леджеры (specs), adversarial-харнесс (tools, adversarial), тесты (tests, tests/ unit 44), документация (docs, worklog.md, gpt-audit), релизы (releases), скрипты, публичные ассеты.
Исключены (восстанавливаемые/переходные): node_modules, .next, .git, tool-results, test-results, dev-логи.

## Как откатиться (если потребуется)

1. Распаковать снапшот в корень проекта с перезаписью:
   `tar -xzf 18-09-2026/bizon-snapshot-2026-09-18_1735.tar.gz -C /home/z/my-project`
2. Установить зависимости: `bun install`
3. Перезапустить dev-сервер (порт 3000) и chat-сервис (:3003) в фоне.
4. Проверить щиты: `bun run lint`, `bunx tsc --noEmit`, `bun test tests/`, `node tools/adversarial/run.mjs`.

## Триггер продолжения работ

Команда пользователя **«Возобнови работу согласно План-v2»** = начать реализацию плана
(точка входа: Wave 1 «Кольцо доверия» — Sarafan Radio × 5 Handshakes, см. docs/MASTER-PLAN-V2-OVERLAY.md).
Копия плана также лежит в `docs/План-v2.md`.
