// BizON — Playwright E2E (GAP-MATRIX V, fix-campaign-e2e).
// Smoke-сьют золотого пути: лендинг → SPA-навигация → search → публичные
// поверхности → гейты withRoute. Dev-сервер переиспользуется, если уже запущен
// (песочница/локальная разработка), иначе запускается сам.
import { defineConfig, devices } from '@playwright/test';

const PORT = Number(process.env.E2E_PORT ?? 3000);

export default defineConfig({
  testDir: './tests/e2e',
  // Суффикс .pw.ts: bun test НЕ подхватывает e2e-файлы (он ищет *.test.*/*.spec.*),
  // а Playwright находит именно их. Единица разделения юнит/э2е прогонов.
  testMatch: '**/*.pw.ts',
  fullyParallel: false, // общая SQLite-БД демо-сессии — гонки не нужны
  retries: 0,
  workers: 1,
  timeout: 60_000,
  expect: { timeout: 10_000 },
  reporter: process.env.CI ? 'github' : 'list',
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  webServer: {
    command: 'bun run dev',
    url: `http://localhost:${PORT}/api/health`,
    reuseExistingServer: true,
    timeout: 120_000,
  },
});
