// =============================================================================
// CLI: СТАТУС РЕЕСТРА ИНТЕГРАЦИЙ (П4 Фаза 1, п.1.4 директивы).
//
// Сводка по 13 категориям: активный порт, факты адаптера/env (без значений),
// канон манифеста. Exit 1 — если канон нарушен (≠1 активный порт в категории
// или манифест невалиден) — пригоден как гейт.
//
// Запуск: bun scripts/integration-status.ts
// =============================================================================
import { allCategorySummaries } from '../src/lib/hubs/registry';
import { loadManifest, validateManifestCanon } from '../src/lib/hubs/manifest';

const CATEGORY_TITLES: Record<string, string> = {
  email: 'Email',
  storage: 'Хранилище',
  push: 'Push',
  kyc: 'KYC',
  search: 'Поиск',
  observability: 'Observability',
  payments: 'Платежи',
  receipt: 'Чеки (54-ФЗ)',
  blockchain: 'Блокчейн-якорение',
  sms: 'SMS',
  notifications: 'Уведомления',
  ai: 'AI',
  analytics: 'Аналитика',
};

async function main() {
  const manifest = loadManifest();
  const canon = validateManifestCanon();
  const categories = await allCategorySummaries();

  console.log(`ИНТЕГРАЦИОННЫЙ МАНИФЕСТ v${manifest.version} · ${manifest.integrations.length} пунктов · обновлён ${manifest.updated}`);
  console.log(`Канон манифеста: ${canon.ok ? 'OK' : 'НАРУШЕН: ' + canon.problems.join('; ')}`);
  console.log('');

  let violations = 0;
  for (const { category, ports } of categories) {
    const active = ports.filter((p) => p.isActive);
    if (active.length !== 1) violations++;
    const readyCount = ports.filter((p) => p.ready).length;
    console.log(`${CATEGORY_TITLES[category] ?? category} (${category}) — портов: ${ports.length}, готовых: ${readyCount}`);
    for (const p of ports) {
      const flags = [
        p.isActive ? 'ACTIVE' : '       ',
        p.kind.padEnd(13),
        p.mode.padEnd(7),
        `prio=${String(p.priority).padStart(3)}`,
        p.adapterImplemented ? 'адаптер ✓' : 'адаптер —',
        p.envConfigured ? 'env ✓' : `env ✗ (${p.envStatus.filter((e) => !e.configured).map((e) => e.name).join(',')})`,
        p.manifestId ?? '—',
      ];
      console.log(`  ${flags.join(' │ ')} │ ${p.code} (${p.provider})`);
    }
    console.log('');
  }

  console.log(`Итого категорий: ${categories.length}, портов: ${categories.reduce((n, c) => n + c.ports.length, 0)}`);
  if (violations > 0 || !canon.ok) {
    console.error(`КАНОН НАРУШЕН: категорий с ≠1 активным портом: ${violations}`);
    process.exit(1);
  }
  console.log('Канон подтверждён: каждая категория имеет ровно один активный порт.');
  process.exit(0);
}

main();
