// =============================================================================
// P0.2 (директива владельца 2026-09-28): ПЕРЕЗАДАТЬ УЧЁТКУ ВЛАДЕЛЬЦА-ADMIN.
//
// Контекст (§11.2 аудит-пакета): emailHash/emailEncrypted админ-аккаунта
// «Владелец BizON» созданы в ЛЕГАСИ-ЭПОХУ ключа шифрования (keyfile
// .bizon-encryption-key пересоздавался песочницей) — login-lookup по
// hashEmail(email) текущим ключом НЕ НАХОДИТ аккаунт → UI-логин владельца
// невозможен. AUDIT MODE временно маскировал проблему; после его выключения
// (P0.1) вход владельца обязателен.
//
// Что перезадаём (по директиве):
//   • emailHash      = HMAC текущим ключом канон-емейла owner@bizon.test
//   • emailEncrypted = AES-256-GCM текущим ключом того же емейла
//   • passwordHash   = PBKDF2-SHA256 600k от OWNER_INITIAL_PASSWORD (.env)
//
// Канон-емейл — из реестра repair-canonical-accounts.ts (worklog, команда 29):
//   owner@bizon.test / роли: admin. Логин фиксируется и БОЛЬШЕ НЕ МЕНЯЕТСЯ
//   (правило владельца). Пароль владелец ротирует через защищённый канал
//   (значение в .env; в код/worklog/git НЕ попадает).
//
// Безопасность/честность:
//   • fail-closed: без OWNER_INITIAL_PASSWORD в .env скрипт НЕ меняет ничего;
//   • коллизия emailHash с другим живым пользователем → abort (без записи);
//   • 2FA при включённом состоянии сбрасывается (свежая идентичность = свежая
//     enrollment; без этого владелец не смог бы войти без старого TOTP);
//   • AuditLog action='owner_identity.reset' с продолжением hash-chain
//     (v2-канон data-vault/audit-log.ts, транзакция read-modify-write);
//   • идемпотентно: повторный запуск даёт то же состояние (новая audit-запись).
//
// Запуск: bun scripts/reset-owner-identity.ts
// Проверка: curl -X POST /api/auth/login {email: owner@bizon.test, …} → 200
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { encrypt, hashEmail } from '../src/lib/security/crypto';
import { canonicalizeJson, hashAuditPayload } from '../src/lib/security/canonical-json';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const db = new PrismaClient();

const OWNER_EMAIL = 'owner@bizon.test'; // канон-реестр (scripts/repair-canonical-accounts.ts)
const OWNER_NAME = 'Владелец BizON';
const V2_PREFIX = 'v2:';

/** OWNER_INITIAL_PASSWORD: окружение → .env (без вывода значения). */
function readOwnerPassword(): string {
  const fromEnv = process.env.OWNER_INITIAL_PASSWORD;
  if (fromEnv && fromEnv.length >= 12) return fromEnv;
  try {
    const envFile = readFileSync(resolve(process.cwd(), '.env'), 'utf8');
    const m = envFile.match(/^OWNER_INITIAL_PASSWORD=(.+)$/m);
    if (m) {
      const value = m[1].trim().replace(/^["']|["']$/g, '');
      if (value.length >= 12) return value;
    }
  } catch {
    /* .env не читается — обработается ниже */
  }
  console.error(
    'ОШИБКА: OWNER_INITIAL_PASSWORD не найден в .env (или короче 12 символов).\n' +
      'Скрипт fail-closed: НИЧЕГО не изменено. Задайте переменную и повторите.',
  );
  process.exit(1);
}

/** PBKDF2-SHA256 600k — та же схема, что AuthService.register (pbkdf2$iter$salt$hash). */
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, [
    'deriveBits',
  ]);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 600_000, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const saltHex = Array.from(salt)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  const hashHex = Array.from(new Uint8Array(derivedBits))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  return `pbkdf2$600000$${saltHex}$${hashHex}`;
}

/** Контроль пароля — та же схема, что verifyPassword (AuthService.login). */
async function verifyPasswordInline(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
  const iterations = Number(parts[1]);
  const salt = Uint8Array.from(parts[2].match(/.{2}/g)!.map((b) => parseInt(b, 16)));
  const expected = parts[3];
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, [
    'deriveBits',
  ]);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const actual = Array.from(new Uint8Array(derivedBits))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  if (actual.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

/** AuditLog с продолжением hash-chain (v2-канон, транзакция — см. data-vault/audit-log.ts). */
async function writeAudit(entry: {
  actorId: string;
  action: string;
  resource: string;
  resourceId: string;
  metadata: Record<string, unknown>;
}): Promise<void> {
  await db.$transaction(async (tx) => {
    const last = await tx.auditLog.findFirst({
      where: { chainHash: { not: null } },
      orderBy: { createdAt: 'desc' },
      select: { chainHash: true },
    });
    let prevHash = last?.chainHash ?? 'GENESIS';
    const nowMs = Date.now();
    const createdAt = new Date(nowMs);
    const metadataJson = canonicalizeJson(entry.metadata);
    const row = {
      actorId: entry.actorId,
      action: entry.action,
      resource: entry.resource,
      resourceId: entry.resourceId,
      ip: null,
      metadata: metadataJson,
      createdAt,
    };
    const chainHash =
      V2_PREFIX +
      hashAuditPayload({
        prevHash,
        actorId: row.actorId,
        action: row.action,
        resource: row.resource,
        resourceId: row.resourceId,
        metadata: row.metadata,
        createdAt: row.createdAt.toISOString(),
      });
    await tx.auditLog.create({ data: { ...row, chainHash } });
    void prevHash;
  });
}

async function main() {
  const password = readOwnerPassword();
  console.log('[owner-reset] P0.2: перезадача учётки владельца-admin…');

  // 1. Ровно один живой admin (точный токен 'admin' в CSV roles).
  const admins = await db.user.findMany({
    where: { roles: { contains: 'admin' }, deletedAt: null },
    select: { id: true, name: true, roles: true, emailHash: true, twoFactorEnabled: true },
  });
  const realAdmins = admins.filter((u) => u.roles.split(',').map((r) => r.trim()).includes('admin'));
  if (realAdmins.length === 0) {
    console.error('ОШИБКА: живой admin не найден — abort (ничего не изменено).');
    process.exit(1);
  }
  if (realAdmins.length > 1) {
    console.error(`ОШИБКА: найдено ${realAdmins.length} живых admin-аккаунтов — abort (нужна ручная дизамбигуация).`);
    process.exit(1);
  }
  const admin = realAdmins[0];

  const legacyEpoch = admin.emailHash !== hashEmail(OWNER_EMAIL);
  console.log(`[owner-reset] admin: ${admin.id} («${admin.name}»); идентичность легаси-эпохи: ${legacyEpoch ? 'ДА — перезадаём' : 'нет (обновляем пароль)'}`);

  // 2. Коллизия emailHash с другим живым пользователем → abort.
  const newHash = hashEmail(OWNER_EMAIL);
  const clash = await db.user.findFirst({
    where: { emailHash: newHash, id: { not: admin.id }, deletedAt: null },
    select: { id: true, name: true },
  });
  if (clash) {
    console.error(`ОШИБКА: emailHash канон-емейла уже занят пользователем ${clash.id} («${clash.name}») — abort.`);
    process.exit(1);
  }

  // 3. Перезадача идентичности + пароля (+ сброс 2FA при включённом).
  const twoFactorWasEnabled = admin.twoFactorEnabled === true;
  const passwordHash = await hashPassword(password);
  await db.user.update({
    where: { id: admin.id },
    data: {
      emailHash: newHash,
      emailEncrypted: encrypt(OWNER_EMAIL),
      passwordHash,
      name: OWNER_NAME,
      emailVerified: true,
      isVerified: true,
      ...(twoFactorWasEnabled ? { twoFactorEnabled: false, twoFactorSecret: null, backupCodes: null } : {}),
    },
  });

  // 4. AuditLog (hash-chain продолжен).
  await writeAudit({
    actorId: admin.id,
    action: 'owner_identity.reset',
    resource: 'user',
    resourceId: admin.id,
    metadata: {
      reason: 'P0.2: legacy encryption epoch — UI-логин владельца невозможен (§11.2 аудита)',
      emailMasked: 'o***@bizon.test',
      identityReset: true,
      passwordRotated: true,
      twoFactorReset: twoFactorWasEnabled,
      rotatedAt: new Date().toISOString(),
    },
  });

  // 5. Верификация: lookup по НОВОМУ emailHash + контроль пароля.
  const after = await db.user.findUnique({ where: { emailHash: newHash }, select: { id: true, passwordHash: true } });
  if (!after || after.id !== admin.id) {
    console.error('ОШИБКА: lookup по новому emailHash не находит аккаунт — НЕИСПРАВИМО, проверьте вручную.');
    process.exit(1);
  }
  const pwOk = await verifyPasswordInline(password, after.passwordHash);
  console.log(`[owner-reset] verify: lookup по emailHash → OK; пароль → ${pwOk ? 'OK' : 'НЕ СХОДИТСЯ'}`);
  if (!pwOk) process.exit(1);

  console.log(
    `[owner-reset] ГОТОВО: учётка владельца перезадана (${admin.id}); логин=${OWNER_EMAIL}; пароль — из OWNER_INITIAL_PASSWORD в .env (в логи/git не пишется); 2FA ${twoFactorWasEnabled ? 'сброшена (fresh enrollment)' : 'была выключена'}.`,
  );
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
