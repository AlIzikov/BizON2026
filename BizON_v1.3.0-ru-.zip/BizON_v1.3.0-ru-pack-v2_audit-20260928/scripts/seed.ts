// BizON — seed script
// Запуск: bun run /home/z/my-project/scripts/seed.ts
// Заполняет БД демо-данными: 10 пользователей, 6 навыков, 5 проектов, связи, события репутации, вакансии, реклама.

import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

const SKILLS = [
  { name: 'Python', category: 'Backend' },
  { name: 'TypeScript', category: 'Frontend' },
  { name: 'React', category: 'Frontend' },
  { name: 'Next.js', category: 'Frontend' },
  { name: 'PostgreSQL', category: 'Database' },
  { name: 'Machine Learning', category: 'AI/ML' },
  { name: 'PyTorch', category: 'AI/ML' },
  { name: 'Docker', category: 'DevOps' },
  { name: 'Kubernetes', category: 'DevOps' },
  { name: 'Product Management', category: 'Management' },
  { name: 'System Design', category: 'Architecture' },
  { name: 'Data Engineering', category: 'Data' },
];

const USERS = [
  { name: 'Иван Петров', email: 'ivan@bizon.ru', title: 'Data Engineer', location: 'Москва', bio: 'Работаю над AI-проектами в сфере экологии. Сооснователь GreenAI.', roles: ['Data Engineer', 'Mentor'] },
  { name: 'Алексей Смирнов', email: 'alex@bizon.ru', title: 'ML Architect', location: 'Москва', bio: '10 лет в ML. Развиваю production-ready ML-системы.', roles: ['ML Architect', 'Mentor'] },
  { name: 'Мария Иванова', email: 'maria@bizon.ru', title: 'Product Manager', location: 'Санкт-Петербург', bio: 'Запускаю B2B SaaS. Бывший Yandex.', roles: ['PM', 'Advisor'] },
  { name: 'Елена Волкова', email: 'elena@bizon.ru', title: 'Frontend Developer', location: 'Казань', bio: 'React/Next.js. Веду канал по UX.', roles: ['Frontend Dev'] },
  { name: 'Дмитрий Соколов', email: 'dmitry@bizon.ru', title: 'DevOps Engineer', location: 'Москва', bio: 'K8s, Terraform, observability. Mentor в K8s-сообществе.', roles: ['DevOps', 'Mentor'] },
  { name: 'Ольга Кузнецова', email: 'olga@bizon.ru', title: 'ML Researcher', location: 'Новосибирск', bio: 'PhD in CS. NLP, transformers, RAG.', roles: ['Researcher', 'Mentor'] },
  { name: 'Сергей Морозов', email: 'sergey@bizon.ru', title: 'Tech Lead', location: 'Екатеринбург', bio: 'Building high-load systems. Ex-VK.', roles: ['Tech Lead', 'Mentor'] },
  { name: 'Анна Лебедева', email: 'anna@bizon.ru', title: 'Data Scientist', location: 'Москва', bio: 'Time series, anomaly detection, MLOps.', roles: ['Data Scientist'] },
  { name: 'Павел Новиков', email: 'pavel@bizon.ru', title: 'Backend Developer', location: 'Самара', bio: 'Go, Python, highload. Open source contributor.', roles: ['Backend Dev'] },
  { name: 'Наталья Орлова', email: 'natalya@bizon.ru', title: 'Engineering Manager', location: 'Москва', bio: 'Building teams. Ex-Tinkoff.mentor в AI Ethics.', roles: ['EM', 'Mentor', 'Advisor'] },
];

const PROJECTS = [
  { title: 'GreenAI Platform', description: 'AI-платформа мониторинга углеродного следа. Сбор данных с IoT-датчиков, ML-прогноз, дашборды для бизнеса.', tags: 'Python,ML,Data Engineering', status: 'completed', rating: 4.8 },
  { title: 'TrustGraph SDK', description: 'Open-source библиотека для построения графов доверия. BFS, weighted edges, community detection.', tags: 'TypeScript,Graph,Algorithm', status: 'active', rating: 4.5 },
  { title: 'CareerPath AI', description: 'Сервис карьерных траекторий на базе LLM. Анализ профиля, рекомендации, симуляция развития.', tags: 'Next.js,LLM,Product', status: 'active', rating: 4.6 },
  { title: 'MentorHub', description: 'Платформа менторства с подбором пар через AI-Team-Mentor. Включает retro-инструменты.', tags: 'React,Node.js,Mentorship', status: 'recruiting', rating: 0 },
  { title: 'DataQuality Checker', description: 'CLI-инструмент для валидации пайплайнов данных. Pytest-style API, интеграция с Airflow.', tags: 'Python,Data,DevOps', status: 'completed', rating: 4.3 },
];

const JOBS = [
  { title: 'Senior ML Engineer', company: 'GreenAI', description: 'Развитие ML-инфраструктуры платформы мониторинга экологии. MLOps, model monitoring, feature store.', requiredSkills: 'Python,Machine Learning,PyTorch,Docker', salaryFrom: 350000, salaryTo: 500000, location: 'Москва (remote)', growthScore: 0.85 },
  { title: 'Tech Lead', company: 'TrustGraph', description: 'Руководство командой из 6 человек. Архитектурные решения, найм, менторство.', requiredSkills: 'TypeScript,System Design,Product Management', salaryFrom: 450000, salaryTo: 600000, location: 'Удалённо', growthScore: 0.9 },
  { title: 'Senior Frontend Engineer', company: 'CareerPath', description: 'Развитие Next.js-приложения. Design system, performance, accessibility.', requiredSkills: 'React,Next.js,TypeScript', salaryFrom: 300000, salaryTo: 450000, location: 'Москва', growthScore: 0.75 },
  { title: 'Data Engineer (Middle+)', company: 'MentorHub', description: 'Построение data-пайплайнов, ETL, data warehouse. Airflow, dbt, Snowflake.', requiredSkills: 'Python,PostgreSQL,Data Engineering,Docker', salaryFrom: 250000, salaryTo: 380000, location: 'Удалённо', growthScore: 0.7 },
  { title: 'DevOps Engineer', company: 'BizON', description: 'K8s-кластеры, CI/CD, observability. Развитие внутренней платформы.', requiredSkills: 'Docker,Kubernetes', salaryFrom: 280000, salaryTo: 420000, location: 'Москва', growthScore: 0.8 },
  { title: 'Engineering Manager', company: 'BizON', description: 'Руководство 2 командами по 5 человек. Стратегия, найм, 1:1, performance review.', requiredSkills: 'Product Management,System Design', salaryFrom: 500000, salaryTo: 700000, location: 'Москва', growthScore: 0.95 },
];

const ADS = [
  { title: 'Siberia ML Conf 2025', content: 'Главная ML-конференция Сибири. 20+ спикеров, workshop по LLM. Скидка 20% по промо BIZON20.', targetTrustSegment: 'extended', adTrustIndex: 0.92, moderationScore: 0.95 },
  { title: 'Курс "Архитектор high-load систем"', content: '6-месячный практический курс. Менторство, реальные проекты. Старт 15 октября.', targetTrustSegment: 'expert', adTrustIndex: 0.85, moderationScore: 0.88 },
  { title: 'Yandex Cloud — грант для стартапов', content: 'До 1 млн ₽ на инфраструктуру для AI-стартапов. Подача заявок до 30 ноября.', targetTrustSegment: 'all', adTrustIndex: 0.9, moderationScore: 0.92 },
];

async function main() {
  console.log('🌱 BizON seed started...');

  // D-28 (KV2, R2-010): seed НИКОГДА не стирает живые данные молча.
  // По умолчанию (и на проде) — только additively-вставка недостающих записей.
  // Полная пересидка — только осознанно: SEED_WIPE=1 bun run scripts/seed.ts
  const WIPE = (process.env as Record<string, string | undefined>)['SEED_WIPE'] === '1';
  if (!WIPE) {
    console.log('[seed] SEED_WIPE=1 не задан — destructive-очистка ПРОПУЩЕНА (защита живых данных).');
    console.log('[seed] Выходим: для полной пересидки запустите с SEED_WIPE=1.');
    return;
  }
  console.log('[seed] SEED_WIPE=1: destructive-очистка разрешена владельцем.');
  await db.adImpression.deleteMany();
  await db.ad.deleteMany();
  await db.jobApplication.deleteMany();
  await db.job.deleteMany();
  await db.reputationEvent.deleteMany();
  await db.skillConfirmation.deleteMany();
  await db.userSkill.deleteMany();
  await db.projectMember.deleteMany();
  await db.project.deleteMany();
  await db.connection.deleteMany();
  await db.session.deleteMany();
  await db.skill.deleteMany();
  await db.user.deleteMany();
  console.log('  ✓ cleaned existing data');

  // Skills
  const skills = await Promise.all(
    SKILLS.map((s) => db.skill.create({ data: s }))
  );
  console.log(`  ✓ ${skills.length} skills created`);

  // Users (password = "password" для всех, PBKDF2 hash)
  const passwordHash = await hashPwd('password');
  // C1: emailHash + emailEncrypted обязательны для логина (auth ищет по emailHash)
  const { hashEmail, encrypt } = await import('../src/lib/security/crypto');
  const users = await Promise.all(
    USERS.map((u) =>
      db.user.create({
        data: {
          ...u,
          email: u.email.toLowerCase(),
          emailHash: hashEmail(u.email.toLowerCase()),
          emailEncrypted: encrypt(u.email.toLowerCase()),
          passwordHash,
          roles: u.roles.join(','),
          ipScore: 50,
          level: 'extended',
        },
      })
    )
  );
  console.log(`  ✓ ${users.length} users created (password: "password")`);

  // UserSkills — каждому 3-5 рандомных навыков
  const userSkillMap = new Map<string, string[]>(); // userId -> [skillName]
  for (const user of users) {
    const numSkills = 3 + Math.floor(Math.random() * 3);
    const pickedSkills = [...skills].sort(() => Math.random() - 0.5).slice(0, numSkills);
    const skillNames: string[] = [];
    for (const skill of pickedSkills) {
      const confirmations = Math.floor(Math.random() * 8);
      const us = await db.userSkill.create({
        data: {
          userId: user.id,
          skillId: skill.id,
          level: 1 + Math.floor(Math.random() * 5),
          confirmationsCount: confirmations,
          nftEligible: confirmations >= 3,
        },
      });
      skillNames.push(skill.name);
      // для подтверждений нужны общие проекты — добавим позже
    }
    userSkillMap.set(user.id, skillNames);
  }
  console.log(`  ✓ user-skills assigned`);

  // Projects + Members
  const projects: Awaited<ReturnType<typeof db.project.create>>[] = [];
  for (let i = 0; i < PROJECTS.length; i++) {
    const p = PROJECTS[i];
    const owner = users[i % users.length];
    const project = await db.project.create({
      data: {
        title: p.title,
        description: p.description,
        ownerId: owner.id,
        status: p.status,
        rating: p.rating,
        tags: p.tags,
        completedAt: p.status === 'completed' ? new Date(Date.now() - i * 24 * 60 * 60 * 1000) : null,
      },
    });
    // 3-5 участников
    const members = [owner, ...users.filter((u) => u.id !== owner.id).sort(() => Math.random() - 0.5).slice(0, 3 + Math.floor(Math.random() * 2))];
    for (let j = 0; j < members.length; j++) {
      await db.projectMember.create({
        data: {
          projectId: project.id,
          userId: members[j].id,
          role: j === 0 ? 'owner' : j === 1 ? 'lead' : 'member',
        },
      });
    }
    projects.push(project);
  }
  console.log(`  ✓ ${projects.length} projects created`);

  // Connections (граф доверия)
  for (let i = 0; i < users.length; i++) {
    for (let j = i + 1; j < users.length; j++) {
      if (Math.random() < 0.4) {
        await db.connection.create({
          data: {
            fromUserId: users[i].id,
            toUserId: users[j].id,
            status: 'accepted',
          },
        });
      }
    }
  }
  // несколько pending (upsert — идемпотентно)
  await db.connection.upsert({
    where: { fromUserId_toUserId: { fromUserId: users[0].id, toUserId: users[5].id } },
    create: { fromUserId: users[0].id, toUserId: users[5].id, status: 'pending', note: 'Хочу обсудить ML-проект' },
    update: { status: 'pending' },
  });
  await db.connection.upsert({
    where: { fromUserId_toUserId: { fromUserId: users[2].id, toUserId: users[7].id } },
    create: { fromUserId: users[2].id, toUserId: users[7].id, status: 'pending', note: 'Подсказали общий проект' },
    update: { status: 'pending' },
  });
  console.log(`  ✓ connections created`);

  // Reputation events (для Trust Stream)
  const eventTypes = ['project_completed', 'skill_confirmed', 'positive_review', 'connection_accepted', 'intro_sent'];
  for (let i = 0; i < 30; i++) {
    const user = users[Math.floor(Math.random() * users.length)];
    const eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
    const project = projects[Math.floor(Math.random() * projects.length)];
    const impactScore = Math.round(Math.random() * 100) / 100;

    let payload: any = {};
    if (eventType === 'project_completed') {
      payload = { projectId: project.id, projectTitle: project.title, rating: project.rating, participantsCount: 4 };
    } else if (eventType === 'skill_confirmed') {
      payload = { skill: SKILLS[Math.floor(Math.random() * SKILLS.length)].name, by: users[Math.floor(Math.random() * users.length)].name, confirmationsCount: Math.floor(Math.random() * 8) };
    } else if (eventType === 'connection_accepted') {
      payload = { with: users[Math.floor(Math.random() * users.length)].name };
    } else if (eventType === 'positive_review') {
      payload = { from: users[Math.floor(Math.random() * users.length)].name, rating: 4 + Math.random() };
    } else {
      payload = { to: users[Math.floor(Math.random() * users.length)].name };
    }

    await db.reputationEvent.create({
      data: {
        userId: user.id,
        eventType,
        payload: JSON.stringify(payload),
        weight: Math.floor(Math.random() * 5) + 1,
        impactScore,
        createdAt: new Date(Date.now() - Math.random() * 14 * 24 * 60 * 60 * 1000),
      },
    });
  }
  console.log(`  ✓ 30 reputation events created`);

  // Пересчёт IP-score для всех
  const { recomputeIpScore } = await import('../src/lib/reputation');
  for (const u of users) {
    await recomputeIpScore(u.id);
  }
  console.log(`  ✓ IP-scores recomputed`);

  // Jobs
  for (const j of JOBS) {
    await db.job.create({ data: j });
  }
  console.log(`  ✓ ${JOBS.length} jobs created`);

  // Ads
  for (const a of ADS) {
    await db.ad.create({ data: a });
  }
  console.log(`  ✓ ${ADS.length} ads created`);

  console.log('\n✅ Seed complete.');
  console.log('   Demo users: ivan@bizon.ru, alex@bizon.ru, maria@bizon.ru ... (password: "password")');
}

async function hashPwd(password: string): Promise<string> {
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 100_000, hash: 'SHA-256' },
    keyMaterial,
    256
  );
  const saltHex = Array.from(salt).map((b) => b.toString(16).padStart(2, '0')).join('');
  const hashHex = Array.from(new Uint8Array(derivedBits)).map((b) => b.toString(16).padStart(2, '0')).join('');
  return `pbkdf2$100000$${saltHex}$${hashHex}`;
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
