// BizON — Создать свежую demo-сессию для превью
//
// Сценарий: при запуске превью нужна готовая сессия пользователя с ipScore > 50
// (для авто-входа без прохождения полного auth flow).
//
// Алгоритм:
//   1. Найти пользователя с ipScore > 50 (сортировка по убыванию ipScore).
//   2. Удалить старые истёкшие сессии этого пользователя (expiresAt < now).
//   3. Создать новую сессию (token = 32 случайных байта → hex, expiresAt = +7 дней).
//   4. Вывести USER_ID, USER_NAME, IP_SCORE, TOKEN (для инъекции в cookie превью).
//
// Запуск: node scripts/create-demo-session.js

const { PrismaClient } = require('@prisma/client');
const crypto = require('crypto');
const db = new PrismaClient();

async function main() {
  // Найти пользователя с ipScore > 50 (для авто-входа)
  const user = await db.user.findFirst({
    where: { ipScore: { gt: 50 } },
    orderBy: { ipScore: 'desc' }
  });

  if (!user) {
    console.error('No suitable user found');
    process.exit(1);
  }

  // Удалить старые сессии этого пользователя (старше 7 дней)
  await db.session.deleteMany({
    where: {
      userId: user.id,
      expiresAt: { lt: new Date() }
    }
  });

  // Создать новую сессию
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

  await db.session.create({
    data: { userId: user.id, token, expiresAt }
  });

  console.log('USER_ID=' + user.id);
  console.log('USER_NAME=' + user.name);
  console.log('IP_SCORE=' + user.ipScore);
  console.log('TOKEN=' + token);

  await db.$disconnect();
}

main().catch(e => { console.error(e); process.exit(1); });
