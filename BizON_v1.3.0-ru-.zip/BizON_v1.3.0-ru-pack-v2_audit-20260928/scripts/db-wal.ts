// R5-P2 · scalability-фикс SQLite: включение WAL-режима (journal_mode=WAL).
//
// Проблема: дефолтный journal_mode=DELETE на SQLite блокирует читателей на время
// записи — под конкурентной нагрузкой (bulk-операции awardBulk, кроны, тесты
// параллельно с dev-сервером) получаем SQLITE_BUSY и long-tail латентности.
//
// Решение: WAL позволяет читателям не блокироваться писателем (snapshot isolation).
// WAL — персистентное свойство ФАЙЛА БД: достаточно включить один раз после
// создания/восстановления БД (после restore бэкапа — перезапустить скрипт,
// это добавлено в чек-лист docs/ops/backup-restore.md владельцем директивы R5-P2).
//
// Плюс connection_limit=1 в DATABASE_URL (.env / .env.example): Prisma-пул
// на SQLite обязан быть однописателем — несколько writer-коннектов дают гонку
// prevHash при append AuditLog (урок R5.5: hash-chain разрыв 2026-09-26).
//
// Запуск: bun run scripts/db-wal.ts
// Проверка: скрипт выводит journal_mode ДО и ПОСЛЕ; должен стать `wal`.
// Пин: tests/pins/r5-p2-core.pin.test.ts (WAL активен на живой БД).
import { Database } from 'bun:sqlite';

function dbPathFromEnv(): string {
  const url = process.env.DATABASE_URL ?? '';
  // Поддержка обоих форматов: file:/abs/path.db?connection_limit=1 и file:../db/custom.db
  const raw = url.replace(/^file:/, '').split('?')[0];
  if (!raw) throw new Error('DATABASE_URL не задан или пуст');
  if (raw.startsWith('/')) return raw;
  return new URL(`file://${raw}`, `file://${process.cwd()}/`).pathname;
}

const dbFile = dbPathFromEnv();
const db = new Database(dbFile);

const before = db.query('PRAGMA journal_mode').get() as Record<string, unknown> | null;
// WAL персистентен: пишется в заголовок файла БД.
db.exec('PRAGMA journal_mode=WAL;');
const after = db.query('PRAGMA journal_mode').get() as Record<string, unknown> | null;
// busy_timeout — страховка на остаточные конкурентные кейсы (5с, не вечно).
db.exec('PRAGMA busy_timeout=5000;');
const busy = db.query('PRAGMA busy_timeout').get() as Record<string, unknown> | null;
db.close();

console.log(`[db-wal] ${dbFile}`);
console.log(`[db-wal] journal_mode: ${before?.journal_mode} -> ${after?.journal_mode}`);
console.log(`[db-wal] busy_timeout: ${busy?.timeout}ms`);
if (String(after?.journal_mode) !== 'wal') {
  console.error('[db-wal] FAIL: WAL не включился (файловая система без поддержки shared memory?)');
  process.exit(1);
}
console.log('[db-wal] OK: WAL активен, читатели больше не блокируются писателем.');
