// =============================================================================
// П4-В5 (директива владельца, «ОТВЕТЫ НА 5 ВОПРОСОВ», пункт В5): РОТАЦИЯ
// ПАРОЛЕЙ QA-АККАУНТОВ qa-01..05@bizon.test — «ротируй сейчас».
//
// Проблема: пароли QA-канон-аккаунтов были ДОКУМЕНТИРОВАНЫ в репо
// (scripts/repair-canonical-accounts.ts → 'Qa-Stable-2026!01..05').
// Любой читатель репозитория/preview знал пароли защищённого QA-периметра.
//
// Что делает скрипт (одна команда — полная ротация):
//   1. Адресаты — ровно пять qa-01..05@bizon.test (hash-lookup текущим
//      ключом, эон-фолбэк по имени 'QA 01..05' — прецедент FIX-2026-09-15c).
//   2. КРИПТОСЛУЧАЙНЫЙ пароль 32 символа каждому (crypto.getRandomValues
//      → base64url; никаких словарей и шаблонов).
//   3. Эон-ремонт идентичности (emailHash/emailEncrypted ТЕКУЩИМ ключом).
//   4. passwordHash = PBKDF2-SHA256 600k (схема AuthService.register).
//   5. РЕВОКАЦИЯ всех сессий ротированных аккаунтов (угнанная сессия
//      не переживает ротацию).
//   6. .env → BIZON_QA_PASSWORDS (base64url JSON {email: password}).
//      В коде/git/worklog/логах паролей НЕТ.
//   7. AuditLog action='qa_passwords.rotate' (hash-chain v2) — количество
//      и дата; БЕЗ паролей/email'ов.
//   8. Верификация: lookup по новому emailHash + контроль пароля
//      (та же схема, что AuthService.login) — exit 1 при расхождении.
//
// Пароль владельца owner@bizon.test НЕ трогается (В2: владелец ротирует
// OWNER_INITIAL_PASSWORD сам, защищённым каналом).
//
// После этой ротации scripts/repair-canonical-accounts.ts читает QA-пароли
// из .env (fail-closed) — хардкод удалён из репо.
//
// Запуск: bun scripts/rotate-qa-passwords.ts
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { encrypt, hashEmail } from '../src/lib/security/crypto';
import { canonicalizeJson, hashAuditPayload } from '../src/lib/security/canonical-json';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const db = new PrismaClient();
const V2_PREFIX = 'v2:';

const QA_TARGETS = [
  { email: 'qa-01@bizon.test', name: 'QA 01' },
  { email: 'qa-02@bizon.test', name: 'QA 02' },
  { email: 'qa-03@bizon.test', name: 'QA 03' },
  { email: 'qa-04@bizon.test', name: 'QA 04' },
  { email: 'qa-05@bizon.test', name: 'QA 05' },
] as const;

/** Криптослучайный пароль 32 символа (24 байта → base64url). */
function generatePassword(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/** PBKDF2-SHA256 600k — формат pbkdf2$iter$salt$hash (канон AuthService). */
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, [
    'deriveBits',
  ]);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 600_000, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const saltHex = Array.from(salt)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  const hashHex = Array.from(new Uint8Array(derivedBits))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  return `pbkdf2$600000$${saltHex}$${hashHex}`;
}

/** Контроль пароля — та же схема, что verifyPassword (AuthService.login). */
async function verifyPasswordInline(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
  const iterations = Number(parts[1]);
  const salt = Uint8Array.from(parts[2].match(/.{2}/g)!.map((b) => parseInt(b, 16)));
  const expected = parts[3];
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, [
    'deriveBits',
  ]);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const actual = Array.from(new Uint8Array(derivedBits))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  if (actual.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

/** AuditLog с продолжением hash-chain (v2-канон, транзакция — data-vault/audit-log.ts). */
async function writeAudit(entry: {
  actorId: string;
  action: string;
  resource: string;
  resourceId: string;
  metadata: Record<string, unknown>;
}): Promise<void> {
  await db.$transaction(async (tx) => {
    const last = await tx.auditLog.findFirst({
      where: { chainHash: { not: null } },
      orderBy: { createdAt: 'desc' },
      select: { chainHash: true },
    });
    const prevHash = last?.chainHash ?? 'GENESIS';
    const createdAt = new Date(Date.now());
    const metadataJson = canonicalizeJson(entry.metadata);
    const chainHash =
      V2_PREFIX +
      hashAuditPayload({
        prevHash,
        actorId: entry.actorId,
        action: entry.action,
        resource: entry.resource,
        resourceId: entry.resourceId,
        metadata: metadataJson,
        createdAt: createdAt.toISOString(),
      });
    await tx.auditLog.create({
      data: {
        actorId: entry.actorId,
        action: entry.action,
        resource: entry.resource,
        resourceId: entry.resourceId,
        ip: null,
        metadata: metadataJson,
        createdAt,
        chainHash,
      },
    });
  });
}

/** Upsert строки KEY=VALUE в .env (значение не печатается). */
function upsertEnv(key: string, value: string): void {
  const envPath = resolve(process.cwd(), '.env');
  let content = '';
  try {
    content = readFileSync(envPath, 'utf8');
  } catch {
    /* файла нет — создадим */
  }
  const lines = content.split('\n');
  const idx = lines.findIndex((l) => l.startsWith(`${key}=`));
  if (idx >= 0) lines[idx] = `${key}=${value}`;
  else lines.push(`${key}=${value}`);
  writeFileSync(envPath, lines.join('\n').replace(/\n*$/, '\n'));
}

function base64urlJson(obj: Record<string, string>): string {
  const json = JSON.stringify(obj);
  let bin = '';
  for (const ch of json) bin += String.fromCharCode(ch.charCodeAt(0));
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function main() {
  console.log('[qa-rotate] В5: ротация паролей qa-01..05@bizon.test…');
  const passwords: Record<string, string> = {};
  const rotated: string[] = [];
  const failed: string[] = [];

  for (const t of QA_TARGETS) {
    // Hash-lookup текущим ключом, эон-фолбэк по канон-имени
    let user = await db.user.findFirst({
      where: { emailHash: hashEmail(t.email), deletedAt: null },
      select: { id: true },
      orderBy: { createdAt: 'asc' },
    });
    let identityRepair = false;
    if (!user) {
      user = await db.user.findFirst({
        where: { name: t.name, deletedAt: null },
        select: { id: true },
        orderBy: { createdAt: 'asc' },
      });
      identityRepair = user !== null;
    }
    if (!user) {
      console.error(`  НЕ НАЙДЕН: ${t.email} (${t.name})`);
      failed.push(t.email);
      continue;
    }

    const pw = generatePassword();
    const data: { passwordHash: string; emailHash?: string; emailEncrypted?: string } = {
      passwordHash: await hashPassword(pw),
    };
    if (identityRepair) {
      data.emailHash = hashEmail(t.email);
      data.emailEncrypted = encrypt(t.email);
    }
    await db.user.update({ where: { id: user.id }, data });

    // Ревокация сессий: угнанная сессия не переживает ротацию
    const revoked = await db.session.deleteMany({ where: { userId: user.id } });

    passwords[t.email] = pw;
    rotated.push(t.email);
    console.log(`  ✓ ${t.email}: пароль перезадан${identityRepair ? ' + эон-ремонт идентичности' : ''}, сессий отозвано: ${revoked.count}`);
  }

  if (rotated.length > 0) {
    upsertEnv('BIZON_QA_PASSWORDS', base64urlJson(passwords));
    await writeAudit({
      actorId: 'system',
      action: 'qa_passwords.rotate',
      resource: 'User',
      resourceId: `qa-batch:${rotated.length}`,
      metadata: {
        rotated: rotated.length,
        accounts: rotated.map((e) => e.replace(/^(qa-\d+)@bizon\.test$/, '$1')),
        sessionsRevoked: true,
        directive: 'P4-В5',
      },
    });
  }

  // Верификация: контроль пароля по канону AuthService.login
  let verified = 0;
  for (const t of QA_TARGETS) {
    const pw = passwords[t.email];
    if (!pw) continue;
    const user = await db.user.findFirst({
      where: { emailHash: hashEmail(t.email), deletedAt: null },
      select: { passwordHash: true },
    });
    if (user && (await verifyPasswordInline(pw, user.passwordHash))) verified++;
    else failed.push(t.email);
  }

  console.log(`\n[qa-rotate] итого: ротировано ${rotated.length}/5, верифицировано ${verified}/5.`);
  if (failed.length > 0) {
    console.error(`[qa-rotate] ОШИБКИ: ${failed.join(', ')} — exit 1`);
    process.exit(1);
  }
  console.log('[qa-rotate] пароли записаны в .env → BIZON_QA_PASSWORDS (в репо/логах паролей нет).');
  await db.$disconnect();
}

main();
