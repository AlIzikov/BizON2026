// BizON — Seed: GPT Truth Engine
// Запуск: BIZON_ENCRYPTION_KEY=... node scripts/seed-truth-engine.js
//
// Создаёт демо-данные для Truth Engine:
//   - CareerEntry (2-3 на пользователя, разные verificationLevel)
//   - Claim (2-3 на пользователя, разные type/status)
//   - ClaimVerification (1-2 для verified claims)
//   - ReputationSnapshot (5 на пользователя, растущий ipScore за 5 дней)
//   - UserSkill: устанавливает selfAssessment + verifiedScore для первых 3 (Truth Gap)
//
// Скрипт идемпотентен в смысле «не падает, если данных уже есть»,
// но при повторном запуске будет дублировать CareerEntry/Claim/Snapshot —
// рекомендуем запускать на чистой БД (после `bun run scripts/seed.ts`).

const { PrismaClient } = require('@prisma/client');

// === Проверка BIZON_ENCRYPTION_KEY ===
// Скрипт не использует шифрование напрямую, но мы требуем ключ для соответствия
// контракту приложения (instrumentation.ts проверяет его при старте сервера).
const ENC_KEY = process.env.BIZON_ENCRYPTION_KEY;
if (!ENC_KEY) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в окружении.');
  console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
  console.error('   Запуск: BIZON_ENCRYPTION_KEY=... node scripts/seed-truth-engine.js');
  process.exit(1);
}

const prisma = new PrismaClient();

// === Конфигурация данных ===
const VERIFICATION_LEVELS = ['claimed', 'verified', 'project_verified', 'expert_verified'];

// Career entries: разные роли и компании для разнообразия
const CAREER_ENTRIES_POOL = [
  {
    company: 'Yandex',
    position: 'Junior Developer',
    yearsAgoStart: 8,
    yearsAgoEnd: 5,
    description: 'Работал над поисковой инфраструктурой. Первый production-опыт.',
    location: 'Москва',
    verificationLevel: 'expert_verified',
  },
  {
    company: 'VK',
    position: 'Middle Developer',
    yearsAgoStart: 5,
    yearsAgoEnd: 2,
    description: 'Развитие высоконагруженных сервисов. Менторство двух джуниоров.',
    location: 'Санкт-Петербург',
    verificationLevel: 'project_verified',
  },
  {
    company: 'GreenAI',
    position: 'Senior Engineer',
    yearsAgoStart: 2,
    yearsAgoEnd: null,
    description: 'Текущее место работы. Архитектура ML-платформы.',
    location: 'Москва',
    verificationLevel: 'verified',
  },
  {
    company: 'Tinkoff',
    position: 'Lead Engineer',
    yearsAgoStart: 6,
    yearsAgoEnd: 3,
    description: 'Команда из 8 человек. Запуск нового продукта.',
    location: 'Москва',
    verificationLevel: 'project_verified',
  },
  {
    company: 'Сбер AI',
    position: 'ML Engineer',
    yearsAgoStart: 3,
    yearsAgoEnd: 1,
    description: 'Production ML, MLOps. Модели в продакшене.',
    location: 'Москва',
    verificationLevel: 'verified',
  },
  {
    company: 'Avito',
    position: 'Product Manager',
    yearsAgoStart: 4,
    yearsAgoEnd: null,
    description: 'Запуск новых направлений. Команда из 12 человек.',
    location: 'Москва',
    verificationLevel: 'claimed',
  },
];

// Claims: разные type и status
const CLAIMS_POOL = [
  {
    type: 'skill',
    title: 'Уверенно владею Python 8 лет',
    description: 'Работал с Python 3.6-3.12. Asyncio, FastAPI, Django.',
    status: 'verified',
  },
  {
    type: 'experience',
    title: 'Управлял командой из 8 человек',
    description: 'В Tinkoff 2 года был тимлидом. 1:1, найм, performance review.',
    status: 'project_verified',
  },
  {
    type: 'achievement',
    title: 'Запустил ML-платформу в production',
    description: 'Полный цикл: от архитектуры до релиза. 3 модели в проде.',
    status: 'expert_verified',
  },
  {
    type: 'role',
    title: 'Tech Lead в текущем проекте',
    description: 'Архитектурные решения, code review, менторство.',
    status: 'claimed',
  },
  {
    type: 'result',
    title: 'Снизил latency API на 40%',
    description: 'За счёт оптимизации запросов и кеширования.',
    status: 'project_verified',
  },
  {
    type: 'skill',
    title: 'Умею в Kubernetes',
    description: 'Деплой, scaling, observability. CKA сертификат.',
    status: 'verified',
  },
  {
    type: 'experience',
    title: '5 лет в финтехе',
    description: 'Tinkoff, Сбер. PCI DSS, безопасность транзакций.',
    status: 'verified',
  },
  {
    type: 'achievement',
    title: 'Спикер на конференции Highload',
    description: 'Доклад про MLOps в продакшене. 200+ слушателей.',
    status: 'claimed',
  },
];

function isoDaysAgo(days) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d;
}

function isoYearsAgo(years) {
  const d = new Date();
  d.setFullYear(d.getFullYear() - years);
  return d;
}

async function main() {
  console.log('=== BizON — Seed: GPT Truth Engine ===\n');

  // Проверяем, что BIZON_ENCRYPTION_KEY действительно задан (повторная проверка для надёжности)
  console.log(`✓ BIZON_ENCRYPTION_KEY: задан (${ENC_KEY.length} символов)\n`);

  // Берём первых 5 пользователей
  const users = await prisma.user.findMany({
    take: 5,
    orderBy: { createdAt: 'asc' },
    select: { id: true, name: true, email: true, level: true },
  });

  if (users.length === 0) {
    console.error('❌ В БД нет пользователей. Сначала запустите `bun run scripts/seed.ts`.');
    process.exit(1);
  }

  console.log(`Найдено пользователей для сидинга: ${users.length}`);
  users.forEach((u, i) => console.log(`  ${i + 1}. ${u.name} (${u.email}) — level=${u.level}`));
  console.log('');

  let stats = {
    careerEntries: 0,
    claims: 0,
    claimVerifications: 0,
    reputationSnapshots: 0,
    userSkillsUpdated: 0,
  };

  for (let userIndex = 0; userIndex < users.length; userIndex++) {
    const user = users[userIndex];
    console.log(`\n--- Пользователь ${userIndex + 1}/${users.length}: ${user.name} ---`);

    // === CareerEntry: 2-3 записи на пользователя ===
    // Берём 2-3 записи из пула, начиная с разных индексов для разнообразия
    const entriesCount = 2 + (userIndex % 2); // 2 или 3
    const startIdx = (userIndex * 2) % CAREER_ENTRIES_POOL.length;
    const entries = [];
    for (let i = 0; i < entriesCount; i++) {
      const tpl = CAREER_ENTRIES_POOL[(startIdx + i) % CAREER_ENTRIES_POOL.length];
      // Сдвигаем даты, чтобы у разных пользователей были разные периоды
      const startOffset = userIndex;
      const startDate = isoYearsAgo(tpl.yearsAgoStart + startOffset);
      const endDate = tpl.yearsAgoEnd !== null
        ? isoYearsAgo(tpl.yearsAgoEnd + startOffset)
        : null;

      const entry = await prisma.careerEntry.create({
        data: {
          userId: user.id,
          company: tpl.company,
          position: tpl.position,
          startDate,
          endDate,
          description: tpl.description,
          location: tpl.location,
          verificationLevel: tpl.verificationLevel,
        },
      });
      entries.push(entry);
      stats.careerEntries++;
      console.log(`  ✓ CareerEntry: ${tpl.position} @ ${tpl.company} [${tpl.verificationLevel}]`);
    }

    // === Claim: 2-3 claims на пользователя ===
    const claimsCount = 2 + (userIndex % 2); // 2 или 3
    const claimStartIdx = (userIndex * 3) % CLAIMS_POOL.length;
    const userClaims = [];
    for (let i = 0; i < claimsCount; i++) {
      const tpl = CLAIMS_POOL[(claimStartIdx + i) % CLAIMS_POOL.length];

      const claim = await prisma.claim.create({
        data: {
          userId: user.id,
          type: tpl.type,
          title: tpl.title,
          description: tpl.description,
          status: tpl.status,
          // Для project_verified/expert_verified привяжем случайный существующий проект, если есть
          projectId: null,
          skillId: null,
        },
      });
      userClaims.push(claim);
      stats.claims++;
      console.log(`  ✓ Claim [${tpl.type}/${tpl.status}]: ${tpl.title}`);
    }

    // === ClaimVerification: 1-2 для verified claims ===
    // Выбираем claims со статусом выше claimed
    const verifiedClaims = userClaims.filter((c) => c.status !== 'claimed');
    const otherUsers = users.filter((u) => u.id !== user.id);
    for (let i = 0; i < Math.min(verifiedClaims.length, 2); i++) {
      const claim = verifiedClaims[i];
      const verifier = otherUsers[i % otherUsers.length];
      // role зависит от статуса claim
      const role =
        claim.status === 'expert_verified' ? 'expert'
          : claim.status === 'project_verified' ? 'colleague'
            : 'colleague';

      try {
        await prisma.claimVerification.create({
          data: {
            claimId: claim.id,
            verifierId: verifier.id,
            status: 'confirmed',
            role,
            comment: `Подтверждаю: ${claim.title.toLowerCase()}.`,
          },
        });
        stats.claimVerifications++;
        console.log(`    ↳ Verification by ${verifier.name} (role=${role})`);
      } catch (e) {
        // unique constraint — пропускаем
        console.log(`    ↳ пропускаем верификацию: ${e.message}`);
      }
    }

    // === ReputationSnapshot: 5 snapshots за последние 5 дней, растущий ipScore ===
    // Стартовый ipScore зависит от пользователя, финальный — выше на 8-15 пунктов
    const startScore = Math.max(10, 30 + userIndex * 8); // 30, 38, 46, 54, 62
    const totalGrowth = 8 + userIndex * 2; // 8, 10, 12, 14, 16
    for (let day = 4; day >= 0; day--) {
      // day: 4 (5 дней назад) → 0 (сегодня)
      // Рост: равномерный с лёгким шумом
      const progress = (4 - day) / 4; // 0 → 1
      const noise = (day % 2 === 0 ? 1 : -1); // ±1
      const ipScore = Math.max(0, Math.min(100, startScore + Math.round(totalGrowth * progress) + noise));
      const level = ipScore >= 71 ? 'expert' : ipScore >= 31 ? 'extended' : 'basic';

      // breakdown пропорционально
      const projectsScore = Math.round(ipScore * 0.4);
      const ratingsScore = Math.round(ipScore * 0.3);
      const skillsScore = Math.round(ipScore * 0.2);
      const activityScore = Math.round(ipScore * 0.1);
      // Evidence coverage: растёт от 0.2 до 0.8 у пользователя
      const evidenceCoverage = 0.2 + 0.15 * progress + (userIndex * 0.05);

      await prisma.reputationSnapshot.create({
        data: {
          userId: user.id,
          ipScore,
          level,
          projectsScore,
          ratingsScore,
          skillsScore,
          activityScore,
          evidenceCoverage: Number(Math.min(1, evidenceCoverage).toFixed(3)),
          createdAt: isoDaysAgo(day),
        },
      });
      stats.reputationSnapshots++;
    }
    console.log(`  ✓ 5 ReputationSnapshots (ipScore ${startScore} → ${startScore + totalGrowth})`);

    // === UserSkill: для первых 3 пользователей установим selfAssessment + verifiedScore ===
    // Truth Gap = selfAssessment - verifiedScore (демонстрация разрыва)
    if (userIndex < 3) {
      const userSkills = await prisma.userSkill.findMany({
        where: { userId: user.id },
        take: 3,
        orderBy: { confirmationsCount: 'desc' },
        include: { skill: true },
      });

      for (let i = 0; i < userSkills.length; i++) {
        const us = userSkills[i];
        // Разные паттерны Truth Gap:
        // userIndex 0: переоценка (self=80, verified=55)
        // userIndex 1: адекватная самооценка (self=70, verified=72)
        // userIndex 2: недооценка (self=50, verified=85)
        let selfAssessment, verifiedScore, verificationLevel;
        if (userIndex === 0) {
          selfAssessment = 75 + i * 5;  // 75, 80, 85
          verifiedScore = 50 + i * 3;   // 50, 53, 56
          verificationLevel = i === 0 ? 'verified' : 'claimed';
        } else if (userIndex === 1) {
          selfAssessment = 65 + i * 5;  // 65, 70, 75
          verifiedScore = 70 + i * 3;   // 70, 73, 76
          verificationLevel = i === 0 ? 'project_verified' : 'verified';
        } else {
          selfAssessment = 45 + i * 5;  // 45, 50, 55
          verifiedScore = 80 + i * 3;   // 80, 83, 86
          verificationLevel = i === 0 ? 'expert_verified' : 'project_verified';
        }

        await prisma.userSkill.update({
          where: { id: us.id },
          data: {
            selfAssessment,
            verifiedScore,
            verificationLevel,
          },
        });
        stats.userSkillsUpdated++;
        console.log(`  ✓ UserSkill [${us.skill.name}]: self=${selfAssessment}, verified=${verifiedScore}, level=${verificationLevel}`);
      }
    }
  }

  // === Итоговая статистика ===
  console.log('\n=== Итог ===');
  console.log(`  Пользователей обработано: ${users.length}`);
  console.log(`  CareerEntry создано: ${stats.careerEntries}`);
  console.log(`  Claim создано: ${stats.claims}`);
  console.log(`  ClaimVerification создано: ${stats.claimVerifications}`);
  console.log(`  ReputationSnapshot создано: ${stats.reputationSnapshots}`);
  console.log(`  UserSkill обновлено (selfAssessment + verifiedScore): ${stats.userSkillsUpdated}`);
  console.log('\n✅ Seed Truth Engine complete.');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
