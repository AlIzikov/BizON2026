// Task 9-e — одноразовая smoke-проверка LocalSqliteBinding на реальной SQLite.
// Запуск: bun scripts/dataplane-repo-smoke.ts
// Создаёт временный Skill, читает, удаляет — БД остаётся без изменений.

import { DataPlaneRepositoryFacade } from '../src/lib/data-plane/repository';
import { buildRing, makeShardKey, resolveShard } from '../src/lib/data-plane/shard';

const id = '__dataplane_selftest__';
const ref = {
  entity: 'Skill' as const,
  id,
  dataClass: 'C' as const,
  owner: { userId: 'selftest', citizenship: 'RU', region: 'Москва' },
};

// 1. Маршрут до операции (без I/O)
const route = DataPlaneRepositoryFacade.route(ref);
console.log('route:', { plane: route.plane, shardId: route.shardId, shardKey: route.shardKey, ruleId: route.decision.ruleId, failClosed: route.decision.failClosed });
if (route.plane !== 'global-compute') throw new Error('класс C должен идти на global-compute');

// Сверка резолва с прямым вызовом ring
const ring = buildRing(
  [{ id: 'shard-gc-01', weight: 1 }, { id: 'shard-gc-02', weight: 1 }],
  160,
);
if (resolveShard(ring, makeShardKey('companyId', id)) !== route.shardId) throw new Error('резолв шарда не совпал');
console.log('shard resolve совпал с прямым ring:', route.shardId);

// 2. set → create
const put = await DataPlaneRepositoryFacade.set(ref, { name: id, category: 'selftest' });
console.log('set:', { ok: put.ok, created: put.value.created, plane: put.route.plane, shard: put.route.shardId, err: put.error?.code });
if (!put.ok || !put.value.created) throw new Error('set/create не сработал');

// 3. set → update (уже существует)
const upd = await DataPlaneRepositoryFacade.set(ref, { name: id, category: 'selftest-updated' });
console.log('update:', { ok: upd.ok, created: upd.value.created });

// 4. get
const got = await DataPlaneRepositoryFacade.get(ref);
console.log('get:', { ok: got.ok, found: got.value !== null, category: (got.value as { category?: string } | null)?.category });
if (!got.ok || got.value?.category !== 'selftest-updated') throw new Error('get не сработал');

// 5. Валидация схемы: неизвестное поле → честная ошибка prisma-validation
const bad = await DataPlaneRepositoryFacade.set(ref, { name: id, totallyUnknownField: 1 });
console.log('bad payload:', { ok: bad.ok, code: bad.error?.code });
if (bad.ok || !bad.error?.code.startsWith('prisma')) throw new Error('ожидалась честная prisma-ошибка');

// 6. delete (идемпотентно)
const del1 = await DataPlaneRepositoryFacade.delete(ref);
const del2 = await DataPlaneRepositoryFacade.delete(ref);
console.log('delete:', { first: del1.value.deleted, second: del2.value.deleted });
if (!del1.ok || del1.value.deleted !== true || del2.value.deleted !== false) throw new Error('delete/идемпотентность не сработали');

// 7. get после удаления
const gone = await DataPlaneRepositoryFacade.get(ref);
console.log('get after delete:', { ok: gone.ok, value: gone.value });
if (gone.value !== null) throw new Error('запись должна быть удалена');

console.log('\nREPO SMOKE PASSED (БД очищена)');
