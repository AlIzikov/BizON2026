import { db } from '../src/lib/db';
async function main() {
  const [companies, users, jobs, newsCards, culturalSignals, companyClaims, companyReviews, employees, placements, careerEntries, projects, skillConfirmations, reputationSnapshots, actionEvents, evidence, applications, userSkills, skills] = await Promise.all([
    db.company.count(), db.user.count(), db.job.count(), db.newsCard.count(),
    db.culturalSignal.count(), db.companyClaim.count(), db.companyReview.count(), db.employee.count(),
    db.placement.count(), db.careerEntry.count(), db.project.count(), db.skillConfirmation.count(),
    db.reputationSnapshot.count(), db.actionEvent.count(), db.professionalEvidence.count(),
    db.jobApplication.count(), db.userSkill.count(), db.skill.count(),
  ]);
  console.log(JSON.stringify({ companies, users, jobs, newsCards, culturalSignals, companyClaims, companyReviews, employees, placements, careerEntries, projects, skillConfirmations, reputationSnapshots, actionEvents, evidence, applications, userSkills, skills }, null, 1));
  const comp = await db.company.findMany({ select: { id: true, name: true, industry: true, isVerified: true }, take: 5 });
  const us = await db.user.findMany({ select: { id: true, name: true, accountType: true, companyId: true }, take: 8 });
  console.log('companies:', JSON.stringify(comp));
  console.log('users:', JSON.stringify(us));
  await db.$disconnect();
}
main().catch(e => { console.error(e); process.exit(1); });
