// BizON v6 — Cron: пересчёт Professional Capital (ProfessionalCapital)
// Формула 8 компонентов (docs/v6-handover/00-FULL-CONTEXT.md, раздел 5.4,
// зеркало src/lib/services/capital-service.ts — скрипт не может импортировать TS):
//
//   verifiedExpertise*0.20 + projectCapital*0.15 + outcomeCapital*0.15 +
//   trustCapital*0.15 + networkCapital*0.10 + leadershipCapital*0.10 +
//   marketRelevance*0.10 + learningVelocity*0.05 = total (0..100)
//
// Прокси-источники (реалистичные, из доступных данных):
//   verifiedExpertise  — UserSkill с verificationLevel verified+ × 15
//   projectCapital     — завершённые проекты пользователя × 15
//   outcomeCapital     — активные ProfessionalEvidence verified+ × 20
//   trustCapital       — ipScore/5 + бонус уровня (expert +15, extended +8)
//   networkCapital     — принятые связи Connection × 2
//   leadershipCapital  — проекты, где юзер владелец × 20
//   marketRelevance    — навыки юзера, по которым >5 активных вакансий × 20
//   learningVelocity   — навыки, добавленные за последние 30 дней × 10
//
// Запуск:
//   node scripts/cron-capital.js
//
// Cron (ежедневно в 03:30, после снапшотов репутации — trustCapital зависит от ipScore):
//   crontab -e:
//     30 3 * * *  cd /home/z/my-project && /usr/bin/node scripts/cron-capital.js >> /var/log/bizon-cron.log 2>&1
//
//   pm2 (альтернатива):
//     { name: 'bizon-cron-capital', script: 'scripts/cron-capital.js', cron_restart: '30 3 * * *', autorestart: false }
//
// Идемпотентность: ProfessionalCapital.userId @unique → честный prisma upsert;
// повторный запуск просто пересчитывает те же значения.

const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const WEIGHTS = {
  verifiedExpertise: 0.20,
  projectCapital: 0.15,
  outcomeCapital: 0.15,
  trustCapital: 0.15,
  networkCapital: 0.10,
  leadershipCapital: 0.10,
  marketRelevance: 0.10,
  learningVelocity: 0.05,
};

const VERIFIED_LEVELS = ['verified', 'project_verified', 'expert_verified'];
const clamp100 = (v) => Math.max(0, Math.min(100, Math.round(v)));
const r2 = (v) => Math.round(v * 100) / 100;

/**
 * Пересчёт 8 компонентов капитала для одного пользователя.
 * Возвращает { components, total, raw } — raw содержит прокси-метрики для логов.
 */
async function recomputeForUser(userId) {
  const [skills, memberships, evidence, user, connectionCount, activeJobs] = await Promise.all([
    prisma.userSkill.findMany({
      where: { userId },
      select: { verificationLevel: true, createdAt: true },
    }),
    prisma.projectMember.findMany({
      where: { userId },
      select: { project: { select: { ownerId: true, status: true } } },
    }),
    prisma.professionalEvidence.findMany({
      where: { userId, status: 'active' },
      select: { verificationLevel: true },
    }),
    prisma.user.findUnique({
      where: { id: userId },
      select: { ipScore: true, level: true },
    }),
    prisma.connection.count({
      where: { OR: [{ fromUserId: userId }, { toUserId: userId }], status: 'accepted' },
    }),
    prisma.job.findMany({ where: { active: true }, select: { requiredSkills: true } }),
  ]);

  // 1. verifiedExpertise: verified+ навыки × 15
  const verifiedSkills = skills.filter((s) => VERIFIED_LEVELS.includes(s.verificationLevel)).length;
  const verifiedExpertise = clamp100(verifiedSkills * 15);

  // 2. projectCapital: завершённые проекты × 15
  const completedProjects = memberships.filter((m) => m.project.status === 'completed').length;
  const projectCapital = clamp100(completedProjects * 15);

  // 3. outcomeCapital: верифицированные доказательства × 20
  const verifiedEvidence = evidence.filter((e) => VERIFIED_LEVELS.includes(e.verificationLevel)).length;
  const outcomeCapital = clamp100(verifiedEvidence * 20);

  // 4. trustCapital: прокси TrustIndex — ipScore/5 + бонус уровня аккаунта
  const levelBonus = user?.level === 'expert' ? 15 : user?.level === 'extended' ? 8 : 0;
  const trustCapital = clamp100((user?.ipScore ?? 0) / 5 + levelBonus);

  // 5. networkCapital: принятые связи × 2
  const networkCapital = clamp100(connectionCount * 2);

  // 6. leadershipCapital: владение проектами × 20
  const founderRoles = memberships.filter((m) => m.project.ownerId === userId).length;
  const leadershipCapital = clamp100(founderRoles * 20);

  // 7. marketRelevance: навыки юзера, встречающиеся в requiredSkills активных вакансий >5 раз
  const demandMap = new Map();
  for (const j of activeJobs) {
    for (const s of j.requiredSkills.split(',').map((x) => x.trim().toLowerCase()).filter(Boolean)) {
      demandMap.set(s, (demandMap.get(s) ?? 0) + 1);
    }
  }
  const userSkillNames = await prisma.userSkill.findMany({
    where: { userId },
    select: { skill: { select: { name: true } } },
  });
  const inDemand = userSkillNames.filter(
    (us) => (demandMap.get(us.skill.name.toLowerCase()) ?? 0) > 5
  ).length;
  const marketRelevance = clamp100(inDemand * 20);

  // 8. learningVelocity: навыки, добавленные за последние 30 дней × 10
  const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const recentSkills = skills.filter((s) => s.createdAt >= monthAgo).length;
  const learningVelocity = clamp100(recentSkills * 10);

  const components = {
    verifiedExpertise,
    projectCapital,
    outcomeCapital,
    trustCapital,
    networkCapital,
    leadershipCapital,
    marketRelevance,
    learningVelocity,
  };

  const total = r2(
    Object.keys(components).reduce((acc, k) => acc + components[k] * WEIGHTS[k], 0)
  );

  return {
    components,
    total,
    raw: { verifiedSkills, completedProjects, verifiedEvidence, connectionCount, founderRoles, inDemand, recentSkills },
  };
}

async function main() {
  console.log('=== BizON v6 — Cron: пересчёт Professional Capital ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log(
    'Веса: verifiedExpertise 0.20, project 0.15, outcome 0.15, trust 0.15, ' +
      'network 0.10, leadership 0.10, market 0.10, learning 0.05\n'
  );

  const users = await prisma.user.findMany({
    select: { id: true, name: true },
    orderBy: { createdAt: 'asc' },
  });

  if (users.length === 0) {
    console.log('Пользователей не найдено. Выход.');
    return;
  }
  console.log(`Найдено пользователей: ${users.length}\n`);

  let recomputed = 0;
  let failed = 0;
  let totalSum = 0;
  let maxTotal = 0;
  let topUser = null;

  for (let i = 0; i < users.length; i++) {
    const user = users[i];
    try {
      const { components, total, raw } = await recomputeForUser(user.id);

      await prisma.professionalCapital.upsert({
        where: { userId: user.id },
        create: { userId: user.id, ...components, total, recomputedAt: new Date() },
        update: { ...components, total, recomputedAt: new Date() },
      });

      recomputed++;
      totalSum += total;
      if (total > maxTotal) {
        maxTotal = total;
        topUser = user.name;
      }

      console.log(
        `[${i + 1}/${users.length}] ✅ ${user.name}: total=${total} ` +
          `(verified=${raw.verifiedSkills}, projects=${raw.completedProjects}, ` +
          `evidence=${raw.verifiedEvidence}, connections=${raw.connectionCount}, ` +
          `owned=${raw.founderRoles}, inDemand=${raw.inDemand}, recent=${raw.recentSkills})`
      );
    } catch (e) {
      failed++;
      console.error(`[${i + 1}/${users.length}] ❌ ${user.name} — ${e.message}`);
    }
  }

  console.log('\n=== Итог ===');
  console.log(`  Пересчитано: ${recomputed}`);
  console.log(`  Ошибок: ${failed}`);
  console.log(`  Всего пользователей: ${users.length}`);
  console.log(
    `  Средний total: ${recomputed > 0 ? r2(totalSum / recomputed) : 0}` +
      `${topUser ? ` | Лидер: ${topUser} (${maxTotal})` : ''}`
  );
  console.log('\n✅ cron-capital complete.');
}

main()
  .catch((e) => {
    console.error('❌ cron-capital failed:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect().catch(() => {});
  });
