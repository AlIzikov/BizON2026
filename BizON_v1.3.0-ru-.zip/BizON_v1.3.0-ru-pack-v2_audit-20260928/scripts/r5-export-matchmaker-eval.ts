// R5-2c — экспорт снапшота MATCHMAKER_EVAL (закрытый цикл найма A3).
//
// Вызывает HireOutcomeService.evalAggregate() и выгружает чистый JSON
// (без PII: только счётчики/средние/бины) в docs/eval/matchmaker-eval-snapshot.json.
// Файл-снапшот с нулями — это ок и честно: реальных наймов ещё нет.
//
// Запуск: bun run scripts/r5-export-matchmaker-eval.ts
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';

// DATABASE_URL берётся из .env (bun подхватывает автоматически); на случай
// отсутствия — дефолт локальной БД проекта, чтобы скрипт не падал молча.
process.env.DATABASE_URL =
  process.env.DATABASE_URL || `file:${path.resolve(process.cwd(), 'db/custom.db')}`;

async function main() {
  const { HireOutcomeService } = await import('../src/lib/services/hire-outcome-service');
  const aggregate = await HireOutcomeService.evalAggregate();

  const outDir = path.resolve(process.cwd(), 'docs/eval');
  mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, 'matchmaker-eval-snapshot.json');
  writeFileSync(outPath, JSON.stringify(aggregate, null, 2) + '\n', 'utf8');

  console.log('[r5-export-matchmaker-eval] Снапшот MATCHMAKER_EVAL записан:', outPath);
  console.log(`  total:            ${aggregate.total}`);
  console.log(`  avgRating:        ${aggregate.avgRating}`);
  console.log(`  stillEmployedRate:${aggregate.stillEmployedRate}`);
  console.log(`  matched (бины):   ${aggregate.matchmakerBins.matched}`);
  console.log(`  бины:             ${JSON.stringify(aggregate.matchmakerBins.byBin)}`);

  process.exit(0);
}

main().catch((e) => {
  console.error('[r5-export-matchmaker-eval] Ошибка:', e);
  process.exit(1);
});
