// Task 9-e — ops-проверка consistent-hash ring (doc_scaling п.9 Shard-Ready).
// Запуск: bun scripts/dataplane-ring-check.ts
// НЕ тест-файл проекта (координатором тесты запрещены) — одноразовая
// диагностическая утилита в стиле scripts/cron-*.js, вне eslint-скоупа.

import { buildRing, resolveShard, shardDistribution, redistributeStats, makeShardKey } from '../src/lib/data-plane/shard';
import { DATA_PLANE_CONFIG } from '../src/lib/data-plane/config';
import { pseudonymizeForGlobalCompute } from '../src/lib/data-plane/region-router';

let failures = 0;
function assert(cond: boolean, label: string, detail = '') {
  if (cond) {
    console.log(`  OK   ${label}${detail ? ' — ' + detail : ''}`);
  } else {
    failures++;
    console.error(`  FAIL ${label}${detail ? ' — ' + detail : ''}`);
  }
}

console.log('== 1. Конфигурация топологии ==');
for (const plane of DATA_PLANE_CONFIG.planes) {
  const shards = DATA_PLANE_CONFIG.sharding.shards.filter((s) => s.plane === plane.id);
  console.log(`  ${plane.id}: shards=${shards.map((s) => s.id).join(',')} weight=${shards.map((s) => s.weight).join(',')}`);
}

const ringCache = new Map<string, ReturnType<typeof buildRing>>();
function ringForPlane(plane: string) {
  const hit = ringCache.get(plane);
  if (hit) return hit;
  const shards = DATA_PLANE_CONFIG.sharding.shards
    .filter((s) => s.plane === plane)
    .map((s) => ({ id: s.id, weight: s.weight }));
  const ring = buildRing(shards, DATA_PLANE_CONFIG.sharding.virtualNodesPerShard);
  ringCache.set(plane, ring);
  return ring;
}

console.log('\n== 2. Детерминизм: одинаковый ключ → одинаковый шард (1000 итераций) ==');
{
  let allStable = true;
  let distinctAcrossBuilds = true;
  const sampleKeys = [
    ...Array.from({ length: 4 }, (_, i) => makeShardKey('userId', `user-${i}`)),
    ...Array.from({ length: 3 }, (_, i) => makeShardKey('companyId', `company-${i}`)),
    ...Array.from({ length: 3 }, (_, i) => makeShardKey('jobId', `job-${i}`)),
  ];
  for (const plane of ['ru-primary', 'global-compute']) {
    const ring = ringForPlane(plane);
    const ringRebuilt = buildRing(
      DATA_PLANE_CONFIG.sharding.shards.filter((s) => s.plane === plane).map((s) => ({ id: s.id, weight: s.weight })),
      DATA_PLANE_CONFIG.sharding.virtualNodesPerShard,
    );
    for (const key of sampleKeys) {
      const first = resolveShard(ring, key);
      for (let i = 0; i < 1000; i++) {
        if (resolveShard(ring, key) !== first) allStable = false;
      }
      // Два независимо построенных кольца из той же топологии согласованы.
      if (resolveShard(ringRebuilt, key) !== first) distinctAcrossBuilds = false;
    }
    console.log(`  ${plane}: stable=${allStable}, rebuild-consistent=${distinctAcrossBuilds}`);
  }
  assert(allStable, '1000 повторных резолвов каждого из 10 ключей дают тот же шард');
  assert(distinctAcrossBuilds, 'два независимо построенных ring из одной топологии согласованы');
}

console.log('\n== 3. Равномерность распределения (10000 ключей на плоскость) ==');
{
  for (const plane of ['ru-primary', 'global-compute']) {
    const ring = ringForPlane(plane);
    const keys = Array.from({ length: 10000 }, (_, i) => makeShardKey('userId', `dist-${i}`));
    const dist = shardDistribution(ring, keys);
    const expected = 100 / ring.nodes.length;
    const shares = ring.nodes.map((n) => ({ id: n.id, pct: ((dist[n.id] ?? 0) / keys.length) * 100 }));
    const maxDev = Math.max(...shares.map((s) => Math.abs(s.pct - expected)));
    console.log(`  ${plane}: ${shares.map((s) => `${s.id}=${s.pct.toFixed(2)}%`).join(' ')} (ожидание ${expected.toFixed(2)}%, макс. отклонение ${maxDev.toFixed(2)} п.п.)`);
    assert(maxDev < 5, `${plane}: отклонение от равномерного < 5 п.п.`);
  }
}

console.log('\n== 4. Перераспределение при добавлении шарда (ожидание ≈ 1/(N+1)) ==');
{
  for (const plane of ['ru-primary', 'global-compute']) {
    const before = ringForPlane(plane);
    const after = buildRing(
      [...DATA_PLANE_CONFIG.sharding.shards.filter((s) => s.plane === plane).map((s) => ({ id: s.id, weight: s.weight })), { id: `${plane}-shard-added`, weight: 1 }],
      DATA_PLANE_CONFIG.sharding.virtualNodesPerShard,
    );
    const keys = Array.from({ length: 50000 }, (_, i) => makeShardKey('userId', `move-${i}`));
    const st = redistributeStats(before, after, keys);
    const distAfter = shardDistribution(after, keys);
    const addedShare = (((distAfter[`${plane}-shard-added`] ?? 0) / keys.length) * 100).toFixed(2);
    const expectedPct = (100 / after.nodes.length).toFixed(1);
    console.log(`  ${plane}: ${st.fromShards}→${st.toShards} шардов, переехало ${st.moved}/${st.total} = ${(st.movedRatio * 100).toFixed(2)}% (теория ≈ ${expectedPct}%); доля нового шарда ${addedShare}%`);
    // С 160 vnodes на шард доля отдельного шарда колеблется на несколько п.п. —
    // это честное свойство кольца (прод-ручка: virtualNodesPerShard выше → точнее).
    assert(Math.abs(st.movedRatio * 100 - Number(expectedPct)) <= 5, `${plane}: movedRatio ≈ 1/(N+1) (±5 п.п., разброс 160-vnode кольца)`);
  }
}

console.log('\n== 5. Веса: шард weight=2 получает ≈ 2× долю ==');
{
  const ring = buildRing([{ id: 'a', weight: 1 }, { id: 'b', weight: 2 }], 160);
  const keys = Array.from({ length: 20000 }, (_, i) => makeShardKey('userId', `w-${i}`));
  const dist = shardDistribution(ring, keys);
  const shareA = ((dist['a'] ?? 0) / keys.length) * 100;
  const shareB = ((dist['b'] ?? 0) / keys.length) * 100;
  console.log(`  a(1)=${shareA.toFixed(2)}% b(2)=${shareB.toFixed(2)}% (ожидание 33.3%/66.7%), vnodes: a=${ring.vnodes.filter((v) => v.nodeId === 'a').length} b=${ring.vnodes.filter((v) => v.nodeId === 'b').length}`);
  assert(Math.abs(shareA - 33.3) < 4 && Math.abs(shareB - 66.7) < 4, 'весовые доли соответствуют весам');
}

console.log('\n== 6. Обезличивание (pseudonymize → формат doc_scaling anonymous_user_XXXXX) ==');
{
  const res = pseudonymizeForGlobalCompute(
    { name: 'Иван Иванов', email: 'x@y.z', phone: '+70000000000', skills: ['TS'] },
    { userId: 'user-123' },
  );
  const okFormat = /^anonymous_user_\d{5}$/.test(res.pseudonym);
  const keys = Object.keys(res.payload);
  const piiGone = !keys.includes('email') && !keys.includes('phone') && !keys.includes('birthday') && !keys.includes('ip') && res.payload.name === res.pseudonym;
  console.log(`  pseudonym=${res.pseudonym} payload=${JSON.stringify(res.payload)}`);
  assert(okFormat, 'псевдоним в формате doc_scaling anonymous_user_XXXXX');
  assert(piiGone, 'PII (email/phone/имя) удалены/заменены');
  const again = pseudonymizeForGlobalCompute({ name: 'Иван Иванов' }, { userId: 'user-123' });
  assert(again.pseudonym === res.pseudonym, 'псевдоним детерминирован для одного userId');
}

console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\nFAILURES: ${failures}`);
process.exit(failures === 0 ? 0 : 1);
