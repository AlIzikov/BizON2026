// BizON v6 — Seed (TypeScript): русские и двуязычные синонимы навыков (SkillSynonym)
// Task 9-a (audit doc_agents A3/ограничение 3): «в демо-БД SkillSynonym пуста →
// synonym-тир 20% инертен до seed-skill-synonyms».
//
// Базовый датасет (119 русских синонимов, v6.0 §4.9) реиспользуется из
// scripts/seed-skill-synonyms.js БЕЗ модификации того файла — этот сид добавляет
// к нему расширенные группы (SAP, Excel, PowerPoint, Product Management, Jira,
// Confluence, Power BI, Google Analytics, Docker↔контейнеризация), чтобы тир
// синонимов покрывал и «корпоративные» направления.
//
// Схема-цель (prisma/schema.prisma — НЕ меняется):
//   model SkillSynonym { id String @id @default(cuid()); skillId String; synonym String }
//   (skillId — канонический Skill.id, synonym — lowercase-алиас; таблица «плоская»,
//    без relation — сид пишет ровно в этот формат, формат кода расширения не меняем.)
//
// Запуск (однократно; повтор безопасен — идемпотентно):
//   bun scripts/seed-skill-synonyms.ts
//
// Проверка результата:
//   sqlite3 db/custom.db 'SELECT COUNT(*) FROM SkillSynonym;'   (путь к БД — из .env)

import { createRequire } from 'module';
import { PrismaClient } from '@prisma/client';

// Базовый датасет живёт в соседнем CJS-скрипте (зона 9-a его не модифицирует).
// createRequire — надёжный мост к CommonJS-экспорту и для bun, и для tsc.
const requireCjs = createRequire(import.meta.url);
const seedModule = requireCjs('./seed-skill-synonyms.js') as { SYNONYM_GROUPS: SynonymGroup[] };

interface SynonymGroup {
  skill: string;
  category: string;
  synonyms: string[];
}

const BASE_GROUPS: SynonymGroup[] = seedModule.SYNONYM_GROUPS;

/**
 * Расширенные группы (Task 9-a). Синонимы — как их реально пишут в поиске:
 * «сап» вместо SAP, «эксель» вместо Excel, «джира» вместо Jira.
 * Группа с каноническим навыком, который уже есть в базовом датасете (Docker),
 * мержится — синонимы дополняются, дубликатов не будет (валидация ниже).
 */
const EXTRA_GROUPS: SynonymGroup[] = [
  // ===== ERP / корпоративные системы =====
  { skill: 'SAP',        category: 'ERP-системы',      synonyms: ['сап', 'sap erp', 'сап ерп'] },
  // ===== Офис и документы =====
  { skill: 'Excel',      category: 'Офис и документы', synonyms: ['эксель', 'ms excel', 'эксель таблицы'] },
  { skill: 'PowerPoint', category: 'Офис и документы', synonyms: ['паверпоинт', 'презентации'] },
  // ===== Менеджмент =====
  { skill: 'Product Management', category: 'Менеджмент', synonyms: ['продакт-менеджмент', 'продакт менеджмент', 'управление продуктом', 'продуктовый менеджер'] },
  { skill: 'Jira',       category: 'Менеджмент',       synonyms: ['джира', 'атлассиан'] },
  { skill: 'Confluence', category: 'Менеджмент',       synonyms: ['конфлюэнс', 'конфлюенс'] },
  // ===== Аналитика / маркетинг =====
  { skill: 'Power BI',        category: 'Аналитика', synonyms: ['пауэр би', 'powerbi'] },
  { skill: 'Google Analytics', category: 'Маркетинг', synonyms: ['гугл аналитика', 'ga4'] },
  // ===== Разработка (дополнение базовой группы Docker: Docker↔контейнеризация) =====
  { skill: 'Docker',     category: 'Разработка',       synonyms: ['контейнеризация', 'containers'] },
];

/** Минимум групп по задаче 9-a: «минимум 25 групп синонимов» */
const MIN_GROUPS = 25;

/**
 * Валидация ОБЪЕДИНЁННОГО датасета ДО обращения к БД:
 *  1) групп не меньше MIN_GROUPS;
 *  2) синонимы уникальны глобально (иначе семантическое расширение неоднозначно);
 *  3) синонимы нормализованы (trim + lowercase), пустых нет;
 *  4) канонические имена не встречаются среди синонимов других групп.
 */
function validateDataset(groups: SynonymGroup[]): number {
  if (groups.length < MIN_GROUPS) {
    throw new Error(`Ожидалось не меньше ${MIN_GROUPS} групп, получено ${groups.length}`);
  }
  const seen = new Map<string, string>();
  let total = 0;
  for (const group of groups) {
    if (!group.skill || !Array.isArray(group.synonyms) || group.synonyms.length === 0) {
      throw new Error(`Некорректная группа навыка: ${JSON.stringify(group).slice(0, 120)}`);
    }
    for (const raw of group.synonyms) {
      const synonym = String(raw).trim().toLowerCase();
      if (!synonym) throw new Error(`Пустой синоним у навыка "${group.skill}"`);
      if (synonym === group.skill.toLowerCase().trim()) {
        throw new Error(`Синоним "${synonym}" совпадает с каноническим именем навыка`);
      }
      total += 1;
      if (seen.has(synonym)) {
        throw new Error(
          `Дубликат синонима "${synonym}" — "${group.skill}" и "${seen.get(synonym)}"`
        );
      }
      seen.set(synonym, group.skill);
    }
  }
  return total;
}

/** Мерж групп по каноническому имени (порядок сохраняется, категории — из первой группы). */
function mergeGroups(base: SynonymGroup[], extra: SynonymGroup[]): SynonymGroup[] {
  const bySkill = new Map<string, SynonymGroup>();
  for (const g of base) {
    const key = g.skill.toLowerCase().trim();
    const existing = bySkill.get(key);
    if (existing) existing.synonyms.push(...g.synonyms);
    else bySkill.set(key, { ...g, synonyms: [...g.synonyms] });
  }
  for (const g of extra) {
    const key = g.skill.toLowerCase().trim();
    const existing = bySkill.get(key);
    if (existing) existing.synonyms.push(...g.synonyms);
    else bySkill.set(key, { ...g, synonyms: [...g.synonyms] });
  }
  return [...bySkill.values()];
}

async function main(): Promise<void> {
  const groups = mergeGroups(BASE_GROUPS, EXTRA_GROUPS);
  const total = validateDataset(groups);
  const prisma = new PrismaClient();

  console.log('=== BizON v6 — Seed TS: SkillSynonym (русские + расширенные синонимы навыков) ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log(`Групп навыков: ${groups.length} (базовых ${BASE_GROUPS.length} + добавленных ${EXTRA_GROUPS.length}), синонимов: ${total}`);
  console.log('');

  const counters = { skillsCreated: 0, skillsExisting: 0, synonymsCreated: 0, synonymsSkipped: 0, errors: 0 };

  try {
    for (const group of groups) {
      // 1. Канонический навык: Skill.name @unique → честный поиск (как в базовом сидe).
      let skill = await prisma.skill.findFirst({ where: { name: { equals: group.skill } }, select: { id: true, name: true } });
      if (!skill) {
        skill = await prisma.skill.findFirst({ where: { name: { equals: group.skill.toLowerCase() } }, select: { id: true, name: true } });
      }
      if (!skill) {
        skill = await prisma.skill.create({ data: { name: group.skill, category: group.category }, select: { id: true, name: true } });
        counters.skillsCreated += 1;
      } else {
        counters.skillsExisting += 1;
      }

      // 2. Синонимы: SkillSynonym без unique → дедупликация findFirst (идемпотентно).
      for (const synonym of group.synonyms.map((s) => s.trim().toLowerCase())) {
        const existing = await prisma.skillSynonym.findFirst({
          where: { skillId: skill.id, synonym },
          select: { id: true },
        });
        if (existing) {
          counters.synonymsSkipped += 1;
          continue;
        }
        await prisma.skillSynonym.create({ data: { skillId: skill.id, synonym } });
        counters.synonymsCreated += 1;
      }
    }

    const dbCount = await prisma.skillSynonym.count();
    console.log('\n=== Итог ===');
    console.log(`  Навыков создано:            ${counters.skillsCreated}`);
    console.log(`  Навыков уже существовало:   ${counters.skillsExisting}`);
    console.log(`  Синонимов создано:          ${counters.synonymsCreated}`);
    console.log(`  Синонимов пропущено (есть): ${counters.synonymsSkipped}`);
    console.log(`  Ошибок:                     ${counters.errors}`);
    console.log(`  Всего синонимов в датасете: ${total}`);
    console.log(`  ВСЕГО SkillSynonym в БД:    ${dbCount}`);
    if (dbCount === 0) throw new Error('После сида таблица SkillSynonym пуста');
    console.log('\n✅ seed-skill-synonyms.ts complete.');
  } finally {
    await prisma.$disconnect().catch(() => undefined);
  }
}

main()
  .then(() => process.exit(0))
  .catch((e: unknown) => {
    console.error('❌ seed-skill-synonyms.ts failed:', e instanceof Error ? e.message : e);
    process.exit(1);
  });
