// R5.5 — сид тарифного модуля (директива владельца: 5 тарифов × 3 валюты).
//
// ИДЕМПОТЕНТНО И БЕЗОПАСНО ДЛЯ ЖИВОЙ БД:
//   - тарифы upsert'ятся по key (name/description/features обновляются);
//   - цены создаются ТОЛЬКО если в БД нет текущей активной цены для этой
//     валюты/интервала. Если админ уже менял цену через /admin/pricing —
//     сид ЕЁ НЕ ПЕРЕЗАПИСЫВАЕТ (единственный источник истины — БД).
//   - createdById: null (системный сид; аудит изменений — в AuditLog).
//
// Числа совпадают с каноном Phase 13: pro=499₽, business=1499₽ — фолбэк PLANS
// и БД-цены консистентны (см. TIER_TO_PLAN_KEY в pricing-service.ts).
//
// Запуск: bun scripts/seed-pricing.ts
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

// Цены в МИНОРНЫХ единицах (копейки/центы): 499₽ = 49900 (владелец V1:
// рубли — основная валюта; USD/EUR — справочные тарифы из директивы).
const SEED = [
  {
    key: 'company_basic',
    name: 'Basic (компания)',
    description: 'Для малых команд: публикация, профиль компании, базовый подбор.',
    audience: 'company',
    sortOrder: 10,
    features: [
      'Company Page и брендирование',
      'Публикация вакансий (5 активных)',
      'AI-рекрутинг: подбор кандидатов',
      'Аналитика профиля: кто смотрел',
      'Приоритетная поддержка',
    ],
    prices: {
      RUB: { amount: 49900, interval: 'month', trialDays: 14 },
      USD: { amount: 900, interval: 'month', trialDays: 14 },
      EUR: { amount: 800, interval: 'month', trialDays: 14 },
    },
  },
  {
    key: 'company_pro',
    name: 'Pro (компания)',
    description: 'Для компаний и HR-агентств с коммерческой выгодой: безлимит, продвижение, API.',
    audience: 'company',
    sortOrder: 20,
    features: [
      'Всё из Basic',
      'Безлимитные вакансии',
      'Продвижение вакансий в топ',
      'Аналитика рынка',
      'API-доступ (1000 запросов/мес)',
      'BrandDAO: брендирование доверия',
    ],
    prices: {
      RUB: { amount: 149900, interval: 'month', trialDays: 14 },
      USD: { amount: 2500, interval: 'month', trialDays: 14 },
      EUR: { amount: 2300, interval: 'month', trialDays: 14 },
    },
  },
  {
    key: 'company_enterprise',
    name: 'Enterprise',
    description: 'Индивидуальные условия: SSO, SLA, интеграции с ATS. Цена — по запросу.',
    audience: 'company',
    sortOrder: 30,
    features: [
      'Всё из Pro',
      'SSO (SAML/OAuth)',
      'SLA и выделенная поддержка',
      'Интеграции с ATS (webhooks)',
      'Custom-лимиты API',
    ],
    prices: null, // «по запросу» — цен нет, на лендинге честное «По запросу»
  },
  {
    key: 'specialist_premium',
    name: 'Premium (специалист)',
    description: 'Для активных специалистов: безлимит AI, аналитика, скрытый режим.',
    audience: 'specialist',
    sortOrder: 40,
    features: [
      'Безлимитные ИИ-действия (люмены не тратятся)',
      'AI-Matchmaker без лимитов',
      'Аналитика: кто смотрел профиль',
      'Расширенные фильтры поиска',
      'Скрытый режим (анонимный просмотр)',
    ],
    prices: {
      RUB: { amount: 29900, interval: 'month', trialDays: 14 },
      USD: { amount: 500, interval: 'month', trialDays: 14 },
      EUR: { amount: 500, interval: 'month', trialDays: 14 },
    },
  },
  {
    key: 'hr_accreditation',
    name: 'Аккредитация HR',
    description: 'Годовая аккредитация HR-агентства: верифицированный статус и инструменты найма.',
    audience: 'hr_agency',
    sortOrder: 50,
    features: [
      'Верифицированный HR-статус',
      'Team Builder и talent pools',
      'Shared-пайплайны рекрутеров',
      'Расширенная проверка кандидатов',
      'Приоритет в выдаче вакансий',
    ],
    prices: {
      RUB: { amount: 1500000, interval: 'year', trialDays: 0 },
      USD: { amount: 20000, interval: 'year', trialDays: 0 },
      EUR: { amount: 18000, interval: 'year', trialDays: 0 },
    },
  },
] as const;

async function main() {
  console.log('=== R5.5 seed-pricing: тарифы канона Phase 13 + директивы ===');
  for (const plan of SEED) {
    const saved = await db.pricingPlan.upsert({
      where: { key: plan.key },
      create: {
        key: plan.key,
        name: plan.name,
        description: plan.description,
        audience: plan.audience,
        features: [...plan.features],
        sortOrder: plan.sortOrder,
        active: true,
      },
      update: {
        name: plan.name,
        description: plan.description,
        audience: plan.audience,
        features: [...plan.features],
        sortOrder: plan.sortOrder,
      },
    });

    if (!plan.prices) {
      console.log(`  ✓ ${plan.key} — «по запросу» (без цен)`);
      continue;
    }
    for (const [currency, price] of Object.entries(plan.prices)) {
      const current = await db.pricingPrice.findFirst({
        where: { planId: saved.id, currency, interval: price.interval, validUntil: null },
      });
      if (current) {
        // ЦЕНА УЖЕ ЕСТЬ (сид или админ) — не трогаем: БД — источник истины
        console.log(`  · ${plan.key} ${currency}: цена уже в БД (${current.amount} minor) — не перезаписываю`);
        continue;
      }
      await db.pricingPrice.create({
        data: {
          planId: saved.id,
          currency,
          amount: price.amount,
          interval: price.interval,
          trialDays: price.trialDays,
          validFrom: new Date(),
          createdById: null,
        },
      });
      console.log(`  ✓ ${plan.key} ${currency}: ${price.amount} minor (${price.interval}, trial ${price.trialDays}д)`);
    }
  }

  // A/B «pricing_v2» — каркас через готовый ExperimentService/ExperimentAssignment.
  // ЧЕСТНОСТЬ: создаётся в статусе draft — эксперимент НЕ запущен, назначений
  // нет; запуск (running) = решение владельца через БД/админку.
  await db.experiment.upsert({
    where: { key: 'pricing_v2' },
    create: {
      key: 'pricing_v2',
      title: 'A/B цен тарифного модуля (R5.5): control vs v2',
      status: 'draft',
      variantsJson: ['control', 'v2'],
      trafficPct: 50,
    },
    update: { title: 'A/B цен тарифного модуля (R5.5): control vs v2' },
  });
  console.log('  ✓ experiment pricing_v2 (status=draft — запуск по решению владельца)');

  const [plans, prices, promos] = await Promise.all([
    db.pricingPlan.count(),
    db.pricingPrice.count({ where: { validUntil: null } }),
    db.promotionCode.count(),
  ]);
  console.log(`=== Итог: ${plans} тарифов, ${prices} активных цен, ${promos} промокодов ===`);
}

main()
  .then(() => db.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await db.$disconnect();
    process.exit(1);
  });
