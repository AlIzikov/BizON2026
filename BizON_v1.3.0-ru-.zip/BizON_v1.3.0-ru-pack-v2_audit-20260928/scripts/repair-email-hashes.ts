// =============================================================================
// W1.5-REPAIR: восстановление emailHash/emailEncrypted СТАБИЛЬНЫМ ключом.
//
// Контекст: до W1.5 ключ шифрования был эфемерным (каждый процесс — свой),
// поэтому исторические emailHash/emailEncrypted невалидны для любого текущего
// ключа. План ремонта:
//   1. plaintext email'ы читаются из бэкапа db/custom.db.backup-w15 (11 QA-юзеров)
//   2. для них: emailHash=hashEmail(email) + emailEncrypted=encrypt(email) текущим ключом
//   3. для остальных legacy-аккаунтов (plaintext неизвестен): emailHash=null,
//      emailEncrypted=null — честное состояние «email не привязан»; login по
//      email для них был сломан ещё до W1.5 (эфемерные ключи), сессии/демо
//      работают; новые регистрации стабильны (ключ запинен в .env).
//
// Запуск: bun scripts/repair-email-hashes.ts   (идемпотентно)
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { encrypt, decrypt, hashEmail } from '../src/lib/security/crypto';

const db = new PrismaClient();
const backup = new PrismaClient({
  datasources: { db: { url: 'file:/home/z/my-project/db/custom.db.backup-w15' } },
});

async function main() {
  // 1) plaintext из бэкапа
  const known = await backup.user.findMany({
    where: { email: { not: null } },
    select: { id: true, email: true },
  });
  console.log(`Известных plaintext email в бэкапе: ${known.length}`);
  const knownMap = new Map(
    known
      .filter((u): u is typeof u & { email: string } => typeof u.email === 'string' && u.email.length > 0)
      .map((u) => [u.id, u.email.toLowerCase()]),
  );
  await backup.$disconnect();

  // 2) ремонт живой БД
  const users = await db.user.findMany({ select: { id: true, emailHash: true } });
  let rehashed = 0;
  let cleared = 0;
  let untouched = 0;

  for (const u of users) {
    const email = knownMap.get(u.id);
    if (email) {
      const h = hashEmail(email);
      if (u.emailHash !== h) {
        await db.user.update({
          where: { id: u.id },
          data: { emailHash: h, emailEncrypted: encrypt(email) },
        });
        rehashed++;
      } else {
        untouched++;
      }
      continue;
    }
    // email неизвестен — НЕ трогаем: hash мог быть вычислен уже на стабильном
    // ключе (регистрации после пина). Легаси-хэши (до пина) остаются stale —
    // это предсуществующее состояние, login по email для них требовал бы сброса.
    untouched++;
  }
  console.log(`Перехэшировано: ${rehashed} · уже валидны: ${untouched} · сброшено (email неизвестен): ${cleared}`);

  // 2b) Честная зачистка мёртвых записей (FIX-2026-09-15): emailEncrypted,
  // который не расшифровывается текущим ключом, криптографически мёртв
  // (ключ потерян вместе с .env при пересоздании контейнера платформы).
  // Оставлять такой шифр = имитировать наличие данных (нарушение W1-принципа
  // честности). Очищаем до состояния «email не привязан».
  let clearedDead = 0;
  const encUsers = await db.user.findMany({
    where: { emailEncrypted: { not: null } },
    select: { id: true, emailEncrypted: true },
  });
  for (const u of encUsers) {
    const dec = decrypt(u.emailEncrypted as string);
    if (!dec) {
      await db.user.update({
        where: { id: u.id },
        data: { emailEncrypted: null, emailHash: null },
      });
      clearedDead++;
    }
  }
  console.log(`Очищено мёртвых (не расшифровываются текущим ключом): ${clearedDead}`);

  // 3) runtime-проверка lookup для каждого известного email
  let ok = 0;
  for (const [, email] of knownMap) {
    const found = await db.user.findUnique({ where: { emailHash: hashEmail(email) }, select: { id: true } });
    if (found) ok++;
    else console.error(`  НЕ НАЙДЕН по lookup: ${email}`);
  }
  console.log(`Lookup OK для ${ok}/${knownMap.size} известных email`);

  if (ok !== knownMap.size) process.exit(1);
  console.log('OK: email lookup работает на стабильном ключе');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
