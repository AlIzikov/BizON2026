// BizON v6 — Миграция: бэкфилл ProfessionalEvidence из существующих данных
// v6.0 (docs/v6-handover/00-FULL-CONTEXT.md, раздел 4.9). Собирает «Тело
// Доказательств» (ProfessionalEvidence) из трёх источников:
//
//   1. UserSkill с verificationLevel verified+ (verified | project_verified |
//      expert_verified)  → source='user-skill',     type='skill'
//   2. Claim со статусом verified (и/или с подтверждением verdict='confirm')
//                                      → source='claim',          type='claim'
//   3. CareerEntry (карьерный таймлайн) → source='career-entry',   type='experience'
//
// Запуск:
//   node scripts/migrate-evidence.js
//
// Идемпотентность: ProfessionalEvidence НЕ имеет уникального constraint,
// поэтому перед созданием выполняется поиск существующей записи по
// детерминированному ключу:
//   user-skill   → (userId, source, skillId)
//   claim        → (userId, source='claim', responsibility = claim.content)
//   career-entry → (userId, source='career-entry', role = title,
//                   responsibility = company, action = период)
// Повторный запуск ничего не дублирует — только обновляет устаревшие поля.
//
// Схема-цель: ProfessionalEvidence { userId, type, source, skillId?, role?,
// responsibility?, action?, result?, verificationLevel, confidence, status, date }
//
// ВНИМАНИЕ: запускать ПОСЛЕ `prisma db push` (модели v6 должны существовать).

const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const VERIFIED_LEVELS = ['verified', 'project_verified', 'expert_verified'];

// Уровень доказательности UserSkill → verificationLevel + confidence evidence
const LEVEL_MAP = {
  verified: { verificationLevel: 'verified', confidence: 0.7 },
  project_verified: { verificationLevel: 'project_verified', confidence: 0.85 },
  expert_verified: { verificationLevel: 'expert_verified', confidence: 0.95 },
};

function fmtDate(d) {
  if (!d) return null;
  return new Date(d).toISOString().slice(0, 10);
}

/** 1. UserSkill (verified+) → evidence source='user-skill' */
async function backfillFromUserSkills() {
  const userSkills = await prisma.userSkill.findMany({
    where: { verificationLevel: { in: VERIFIED_LEVELS } },
    include: { skill: { select: { name: true } } },
  });

  const counters = { scanned: userSkills.length, created: 0, updated: 0, skipped: 0 };

  for (const us of userSkills) {
    const map = LEVEL_MAP[us.verificationLevel] ?? LEVEL_MAP.verified;
    const existing = await prisma.professionalEvidence.findFirst({
      where: { userId: us.userId, source: 'user-skill', skillId: us.skillId },
      select: { id: true, verificationLevel: true, confidence: true },
    });

    if (existing) {
      // обновляем только если уровень верификации «догнал» UserSkill
      if (existing.verificationLevel !== map.verificationLevel) {
        await prisma.professionalEvidence.update({
          where: { id: existing.id },
          data: {
            verificationLevel: map.verificationLevel,
            confidence: map.confidence,
            status: 'active',
          },
        });
        counters.updated++;
      } else {
        counters.skipped++;
      }
      continue;
    }

    await prisma.professionalEvidence.create({
      data: {
        userId: us.userId,
        type: 'skill',
        source: 'user-skill',
        skillId: us.skillId,
        role: us.skill ? `Владение навыком «${us.skill.name}»` : 'Владение навыком',
        responsibility: `Навык: ${us.skill ? us.skill.name : us.skillId}`,
        action: `Подтверждённый уровень ${us.level}/5, подтверждений: ${us.confirmationsCount}`,
        result: us.verifiedScore != null ? `Подтверждённый балл: ${us.verifiedScore}/100` : null,
        verificationLevel: map.verificationLevel,
        confidence: map.confidence,
        status: 'active',
        date: us.createdAt,
      },
    });
    counters.created++;
  }
  return counters;
}

/** 2. Claim (verified) → evidence source='claim' */
async function backfillFromClaims() {
  // «ClaimVerification=verified» трактуем шире: claim верифицирован по статусу
  // ИЛИ имеет хотя бы одно подтверждение (verdict='confirm') от сообщества.
  const claims = await prisma.claim.findMany({
    where: {
      OR: [
        { status: 'verified' },
        { verifications: { some: { verdict: 'confirm' } } },
      ],
    },
    include: { verifications: { select: { verdict: true } } },
  });

  const counters = { scanned: claims.length, created: 0, updated: 0, skipped: 0 };

  for (const claim of claims) {
    const confirms = claim.verifications.filter((v) => v.verdict === 'confirm').length;
    const refutes = claim.verifications.filter((v) => v.verdict === 'refute').length;
    const isVerified = claim.status === 'verified' || confirms > 0;
    if (!isVerified) {
      counters.skipped++;
      continue;
    }

    const confidence = Math.max(0.6, Math.min(0.95, 0.6 + confirms * 0.1 - refutes * 0.2));

    const existing = await prisma.professionalEvidence.findFirst({
      where: { userId: claim.userId, source: 'claim', responsibility: claim.content },
      select: { id: true, verificationLevel: true },
    });

    if (existing) {
      if (existing.verificationLevel !== 'verified') {
        await prisma.professionalEvidence.update({
          where: { id: existing.id },
          data: { verificationLevel: 'verified', confidence, status: 'active' },
        });
        counters.updated++;
      } else {
        counters.skipped++;
      }
      continue;
    }

    await prisma.professionalEvidence.create({
      data: {
        userId: claim.userId,
        type: 'claim',
        source: 'claim',
        role: claim.type === 'achievement' ? 'Достижение' : claim.type === 'experience' ? 'Опыт' : 'Утверждение о навыке',
        responsibility: claim.content,
        action: `Заявление пользователя, подтверждено сообществом (${confirms} за, ${refutes} против)`,
        result: claim.evidenceUrl ? `Подтверждение: ${claim.evidenceUrl}` : null,
        verificationLevel: 'verified',
        confidence,
        status: 'active',
        date: claim.createdAt,
      },
    });
    counters.created++;
  }
  return counters;
}

/** 3. CareerEntry → evidence source='career-entry' */
async function backfillFromCareerEntries() {
  const entries = await prisma.careerEntry.findMany();

  const counters = { scanned: entries.length, created: 0, updated: 0, skipped: 0 };

  for (const entry of entries) {
    const period = `${entry.startDate ? fmtDate(entry.startDate) : '—'} — ${
      entry.isCurrent ? 'наст. время' : entry.endDate ? fmtDate(entry.endDate) : '—'
    }`;
    const action = `Период: ${period}${entry.isCurrent ? ' (текущее место)' : ''}`;

    const existing = await prisma.professionalEvidence.findFirst({
      where: {
        userId: entry.userId,
        source: 'career-entry',
        role: entry.title,
        responsibility: entry.company ?? null,
        action,
      },
      select: { id: true },
    });

    if (existing) {
      counters.skipped++;
      continue;
    }

    await prisma.professionalEvidence.create({
      data: {
        userId: entry.userId,
        type: 'experience',
        source: 'career-entry',
        role: entry.title,
        responsibility: entry.company ?? null,
        action,
        result: entry.isCurrent ? 'Актуальная занятость подтверждена профилем' : null,
        verificationLevel: 'claimed', // карьерная запись заявлена, но не верифицирована
        confidence: 0.5,
        status: 'active',
        date: entry.startDate ?? entry.createdAt,
      },
    });
    counters.created++;
  }
  return counters;
}

async function main() {
  console.log('=== BizON v6 — Миграция: бэкфилл ProfessionalEvidence ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log('');

  const bySkill = await backfillFromUserSkills();
  console.log('1) UserSkill (verified+):');
  console.log(`   просканировано: ${bySkill.scanned}, создано: ${bySkill.created}, обновлено: ${bySkill.updated}, пропущено: ${bySkill.skipped}`);

  const byClaim = await backfillFromClaims();
  console.log('2) Claim (verified / verdict=confirm):');
  console.log(`   просканировано: ${byClaim.scanned}, создано: ${byClaim.created}, обновлено: ${byClaim.updated}, пропущено: ${byClaim.skipped}`);

  const byCareer = await backfillFromCareerEntries();
  console.log('3) CareerEntry:');
  console.log(`   просканировано: ${byCareer.scanned}, создано: ${byCareer.created}, обновлено: ${byCareer.updated}, пропущено: ${byCareer.skipped}`);

  const totalCreated = bySkill.created + byClaim.created + byCareer.created;
  const totalSkipped = bySkill.skipped + byClaim.skipped + byCareer.skipped;

  console.log('\n=== Итог ===');
  console.log(`  Evidence создано:  ${totalCreated}`);
  console.log(`  Evidence обновлено: ${bySkill.updated + byClaim.updated}`);
  console.log(`  Пропущено (уже есть): ${totalSkipped}`);

  const total = await prisma.professionalEvidence.count();
  console.log(`  Всего ProfessionalEvidence в БД: ${total}`);
  console.log('\n✅ migrate-evidence complete.');
}

main()
  .catch((e) => {
    console.error('❌ migrate-evidence failed:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect().catch(() => {});
  });
