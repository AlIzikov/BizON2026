// Временный сервисный скрипт верификации Task 10-b (удалить после прогона).
// Контекст: shell-песочница изолирована от :3000 (worklog 9-b/9-c) — HTTP-ветки
// build-talent/team-builder/workforce уже live-верифицированы 9-g, company/intelligence — 9-b.
// Здесь доверифицируются ДАННЫЕ-контракты, которые читают UI-панели 10-b.
import { BuildTalentService } from '../src/lib/services/build-talent-service';
import { TeamBuilderService } from '../src/lib/services/team-builder-service';
import { WorkforceService } from '../src/lib/services/workforce-service';
import { CompanyIntelligenceService } from '../src/lib/services/company-intelligence-service';
import { db } from '../src/lib/db';

const QA3_COMPANY = 'cmtoxx1yp0021l5cgviknpipu';
const BIZON = 'cmtlwo7hw00amme6uxof0jjii';

let failures = 0;
function check(label: string, ok: boolean, detail = '') {
  if (!ok) failures += 1;
  console.log(`${ok ? 'OK ' : 'FAIL'} ${label}${detail ? ' — ' + detail : ''}`);
}

async function main() {
  console.log('=== 1. BuildTalentService.buildTalentPool (UI: build-talent-panel) ===');
  const pool = await BuildTalentService.buildTalentPool({
    requiredSkills: [
      { name: 'Python', level: 6 },
      { name: 'Docker', level: null },
    ],
    companyId: QA3_COMPANY,
    limit: 10,
  });
  check('totalCandidates:number', typeof pool.totalCandidates === 'number', String(pool.totalCandidates));
  check('formulaVersion:v1', pool.formulaVersion === 'v1');
  check('privacy.note:string', typeof pool.privacy?.note === 'string', pool.privacy?.note.slice(0, 60));
  const c = pool.candidates[0];
  if (c) {
    check('candidate поля панели', (
      typeof c.score === 'number' && Array.isArray(c.matchedSkills) && Array.isArray(c.missingSkills)
      && Array.isArray(c.why) && typeof c.ipScore === 'number' && typeof c.level === 'string'
      && (c.trust === null || typeof c.trust.score === 'number')
      && (c.activity === null || typeof c.activity.status === 'string')
    ), `${c.name} score=${c.score} matched=${c.matchedSkills.length} missing=${c.missingSkills.length} why=${c.why.length}`);
    const m = c.matchedSkills[0];
    if (m) check('matchedSkill поля', ['name', 'requiredLevel', 'candidateLevel', 'ok', 'verificationLevel'].every((k) => k in m), JSON.stringify(m));
  } else {
    check('empty-pool честный note', typeof pool.note === 'string' && pool.note.length > 0, pool.note ?? 'нет note');
  }

  console.log('=== 2. TeamBuilderService.compose ×2 (UI: team-builder-panel, детерминизм) ===');
  const roles = [
    { title: 'Backend Engineer', skills: ['TypeScript:8', 'Node.js:7'] },
    { title: 'DevOps Engineer', skills: ['Docker:7', 'Kubernetes:6'] },
  ];
  const r1 = await TeamBuilderService.compose({ companyId: QA3_COMPANY, roles, maxSize: null });
  const r2 = await TeamBuilderService.compose({ companyId: QA3_COMPANY, roles, maxSize: null });
  check('детерминизм: байт-идентичный результат', JSON.stringify(r1) === JSON.stringify(r2));
  check('поля панели: team/coverage/gaps/overlaps/successProbability/rolesReport', (
    Array.isArray(r1.team) && typeof r1.coverage.percent === 'number'
    && Array.isArray(r1.gaps) && Array.isArray(r1.overlaps)
    && typeof r1.successProbability.value === 'number' && typeof r1.successProbability.explanation === 'string'
    && Array.isArray(r1.rolesReport)
  ), `team=${r1.team.length} coverage=${r1.coverage.percent}%`);
  check('persisted:false + persistNote', r1.persisted === false && typeof r1.persistNote === 'string', r1.persistNote.slice(0, 70));
  const mem = r1.team[0];
  if (mem) check('member поля панели', (
    ['userId', 'name', 'avatarUrl', 'ipScore', 'level', 'roleTitle', 'roleFit', 'coveredSkills', 'why'].every((k) => k in mem)
  ), `${mem.name} roleFit=${mem.roleFit}`);

  console.log('=== 3. WorkforceService.getOverview (UI: workforce-gates-panel) ===');
  const ov = await WorkforceService.getOverview(QA3_COMPANY);
  check('chain 5 звеньев', JSON.stringify(ov.chain) === JSON.stringify(['demand', 'gap', 'training', 'mentoring', 'pipeline']));
  check('demand {activeJobs,gapSkills,criticalGaps}', (
    typeof ov.demand.activeJobs === 'number' && typeof ov.demand.gapSkills === 'number' && typeof ov.demand.criticalGaps === 'number'
  ), JSON.stringify(ov.demand));
  check('gap severity-enum панели', ov.gap.every((g) => ['low', 'medium', 'high', 'critical'].includes(g.severity)), `${ov.gap.length} гэпов`);
  check('training-поля панели', Array.isArray(ov.training.recommendations) && Array.isArray(ov.training.employeeEnrollments) && typeof ov.training.catalogSize === 'number', `recs=${ov.training.recommendations.length} catalog=${ov.training.catalogSize}`);
  check('mentoring-поля панели', Array.isArray(ov.mentoring.activeMentorships) && Array.isArray(ov.mentoring.recommendations) && typeof ov.mentoring.note === 'string', `active=${ov.mentoring.activeMentorships.length} recs=${ov.mentoring.recommendations.length}`);
  check('pipeline-поля панели (не null при companyId; конверсии number|null)', ov.pipeline !== null && typeof ov.pipeline.stages.source === 'number' && (ov.pipeline.conversions.screenRate === null || typeof ov.pipeline.conversions.screenRate === 'number') && typeof ov.pipeline.placements.total === 'number', `source=${ov.pipeline?.stages.source} screenRate=${ov.pipeline?.conversions.screenRate} (0 откликов → конверсии null, UI показывает % только для not-null)`);
  // Содержательные данные по BizON (у QA3 пусто — честные empty states)
  const ovBizon = await WorkforceService.getOverview(BIZON);
  check('BizON: demand.gapSkills>0', ovBizon.demand.gapSkills > 0, JSON.stringify(ovBizon.demand));
  check('BizON: гэп-ноты explainable', ovBizon.gap.every((g) => g.note.length > 0), ovBizon.gap.slice(0, 2).map((g) => `${g.skill}(${g.severity})`).join(', '));
  const rec = ovBizon.mentoring.recommendations[0];
  if (rec) {
    check('mentoring-rec поля панели', (
      ['menteeId', 'menteeName', 'skillName', 'currentLevel', 'targetLevel', 'mentors'].every((k) => k in rec)
    ), `${rec.menteeName}: ${rec.skillName} ${rec.currentLevel}→${rec.targetLevel}, наставников ${rec.mentors.length}`);
  }

  console.log('=== 4. CompanyIntelligenceService.getIntelligence (UI: company-intelligence-panel) ===');
  const ci = await CompanyIntelligenceService.getIntelligence(BIZON);
  check('company не null + поля', ci !== null && ['id', 'name', 'isVerified', 'industry'].every((k) => k in (ci as { company: Record<string, unknown> }).company), ci?.company.name);
  check('dataFootprint 8 счётчиков', ci !== null && ['employeesCurrent', 'employeesFormer', 'reviews', 'culturalSignals', 'claims', 'openJobs', 'news', 'placements'].every((k) => typeof (ci as { dataFootprint: Record<string, unknown> }).dataFootprint[k] === 'number'), JSON.stringify(ci?.dataFootprint));
  const ts = ci?.trustSignals;
  check('trustSignals 4 индекса + reviews/claims/culture', ts !== undefined && (
    typeof ts.employerTrust === 'number' && typeof ts.businessTrust === 'number'
    && typeof ts.deliveryTrust === 'number' && typeof ts.transparency === 'number'
    && Array.isArray(ts.claims.items) && typeof ts.reviews.count === 'number'
    && (ts.reviews.avgRating === null || typeof ts.reviews.avgRating === 'number')
    && typeof ts.dataNote === 'string'
  ), `employer=${ts?.employerTrust} reviews=${ts?.reviews.count} dataNote="${ts?.dataNote.slice(0, 50)}"`);
  const cn = ci?.currentNeeds;
  check('currentNeeds: openJobs/topSkills/hiredRoles/dataNote', cn !== undefined && (
    Array.isArray(cn.openJobs) && Array.isArray(cn.topSkills) && Array.isArray(cn.hiredRoles) && typeof cn.dataNote === 'string'
  ), `jobs=${cn?.openJobs.length} topSkills=${JSON.stringify(cn?.topSkills.slice(0, 3))}`);
  const cm = ci?.competencyMemory;
  check('competencyMemory: now/appearing/disappearing/positions/dataNote', cm !== undefined && (
    Array.isArray(cm.skillsNow) && Array.isArray(cm.skillsAppearing) && Array.isArray(cm.skillsDisappearing) && Array.isArray(cm.employeePositions) && typeof cm.dataNote === 'string'
  ), `appearing=${JSON.stringify(cm?.skillsAppearing.slice(0, 4))}`);
  const tl = ci?.timeline;
  check('timeline: items[{kind,at,title,detail,meta}] + total + dataNote', tl !== undefined && (
    Array.isArray(tl.items) && tl.items.every((i) => typeof i.kind === 'string' && typeof i.at === 'string' && typeof i.title === 'string' && ('detail' in i) && typeof i.meta === 'object')
  ), `total=${tl?.total} kinds=${[...new Set(tl?.items.map((i) => i.kind) ?? [])].join(',')}`);
  // UI-таймлайн ключи: `${item.kind}-${item.at}-${i}` — уникальность
  const keys = new Set(tl?.items.map((i, idx) => `${i.kind}-${i.at}-${idx}`));
  check('timeline React-keys уникальны', keys.size === tl?.items.length);
  // Сортировка таймлайна по дате (свежие сверху — UI не сортирует, доверяет API)
  const dates = tl?.items.map((i) => new Date(i.at).getTime()) ?? [];
  check('timeline отсортирован по дате desc', dates.every((d, i) => i === 0 || dates[i - 1] >= d));

  console.log('=== 5. Ветки пустых состояний ===');
  const emptyPool = await BuildTalentService.buildTalentPool({
    requiredSkills: [{ name: 'КвантоваяХиромантия', level: 9 }],
    companyId: QA3_COMPANY,
    limit: 10,
  });
  check('несуществующий навык → 0 кандидатов + note', emptyPool.totalCandidates === 0 && typeof emptyPool.note === 'string' && emptyPool.note.length > 0, emptyPool.note?.slice(0, 80));

  console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECKS FAILED`);
  await db.$disconnect();
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error('SCRIPT ERROR:', e);
  process.exit(1);
});
