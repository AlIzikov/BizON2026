#!/usr/bin/env node
// Оракул-верификатор ledger-а specs/adopt-emil-skills/GATES.md (эталон №16, unlazy §6.1).
// Правило автора гейтов (unlazy references/gates.md): скрипт делает все ассерты сам,
// печатает success-only маркер ТОЛЬКО после того, как каждый ассерт прошёл, иначе exit 1.
import { readFileSync } from "node:fs";

const root = process.cwd();
const read = (p) => readFileSync(`${root}/${p}`, "utf8");
const assert = (cond, msg) => {
  if (!cond) {
    console.error(`FAIL: ${msg}`);
    process.exit(1);
  }
};

const cmd = process.argv[2];

if (cmd === "doc") {
  const d = read("docs/UI-CRAFT.md");
  for (const s of [
    "Десять неоспоримых стандартов",
    "Таблица частот",
    "ease-out",
    "ease-in",
    "300ms",
    "scale(0)",
    "transform-origin",
    "prefers-reduced-motion",
    "hover: hover",
    "Virtuoso",
    "sonner",
    "zustand",
    "Мобильный натив-baseline",
    "@starting-style",
    "clip-path",
    "Stagger",
    "useSpring",
    "WAAPI",
  ]) {
    assert(d.includes(s), `docs/UI-CRAFT.md missing: ${s}`);
  }
  console.log("EMIL_DOC_GATE_OK");
} else if (cmd === "css") {
  const c = read("src/app/globals.css");
  for (const s of [
    "-webkit-tap-highlight-color: transparent",
    "-webkit-text-size-adjust: 100%",
    "touch-action: manipulation",
    "user-select: none",
    "--ease-out-strong: cubic-bezier(0.23, 1, 0.32, 1)",
    "--ease-in-out-strong: cubic-bezier(0.77, 0, 0.175, 1)",
    "--ease-drawer: cubic-bezier(0.32, 0.72, 0, 1)",
    "pointer: coarse",
  ]) {
    assert(c.includes(s), `src/app/globals.css missing: ${s}`);
  }
  console.log("MOBILE_BASELINE_GATE_OK");
} else if (cmd === "layout") {
  const l = read("src/app/layout.tsx");
  for (const s of [
    "export const viewport",
    'viewportFit: "cover"',
    'interactiveWidget: "resizes-content"',
    "themeColor",
    "#0b2545",
  ]) {
    assert(l.includes(s), `src/app/layout.tsx missing: ${s}`);
  }
  console.log("VIEWPORT_GATE_OK");
} else if (cmd === "footer") {
  const f = read("src/components/landing/landing-page.tsx");
  assert(
    f.includes("env(safe-area-inset-bottom)"),
    "landing footer missing env(safe-area-inset-bottom)",
  );
  console.log("FOOTER_SAFEAREA_GATE_OK");
} else if (cmd === "button") {
  const b = read("src/components/ui/button.tsx");
  for (const s of [
    "active:scale-[0.97]",
    "transition-[color,background-color,border-color,box-shadow,transform]",
  ]) {
    assert(b.includes(s), `src/components/ui/button.tsx missing: ${s}`);
  }
  console.log("BUTTON_PRESS_GATE_OK");
} else {
  console.error("usage: verify-emil-adoption.mjs doc|css|layout|footer|button");
  process.exit(2);
}
