#!/usr/bin/env node
/* eslint-disable @typescript-eslint/no-require-imports */
// BizON — dev-prod.js
// Запускает BizON в production-режиме (next start) вместо dev (next dev)
// Причина: dev-режим с Turbopack + Chrome в sandbox 4GB = OOM kill.
// Production-режим потребляет 122MB вместо 800MB и работает стабильно.
//
// Если .next/ отсутствует или устарел — сначала собирает (next build).
// Затем запускает `next start` и пишет логи в dev.log (как и bun run dev).

const { spawn, execSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const PROJECT_DIR = '/home/z/my-project';
const NEXT_DIR = path.join(PROJECT_DIR, '.next');
const BUILD_MARKER = path.join(NEXT_DIR, 'BUILD-V2-LIGHTHOUSE.txt');
const SRC_DIR = path.join(PROJECT_DIR, 'src');
const ENV_FILE = path.join(PROJECT_DIR, '.env');
const CONFIG_ENV_FILE = path.join(PROJECT_DIR, 'bizon-config.env');

// Standalone Next.js server (.next/standalone/server.js) НЕ загружает .env
// автоматически (в отличие от next dev/start). Поэтому читаем env-файлы
// вручную и прокидываем в child process.
function parseEnvFile(filePath) {
  const out = {};
  if (!fs.existsSync(filePath)) return out;
  const content = fs.readFileSync(filePath, 'utf8');
  for (const rawLine of content.split('\n')) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eqIdx = line.indexOf('=');
    if (eqIdx === -1) continue;
    const key = line.slice(0, eqIdx).trim();
    let val = line.slice(eqIdx + 1).trim();
    // Убираем обёртывающие кавычки
    if ((val.startsWith('"') && val.endsWith('"')) ||
        (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (key) out[key] = val;
  }
  return out;
}

function loadEnv() {
  // Сначала bizon-config.env (базовые значения), затем .env (локальные переопределения)
  const fromConfig = parseEnvFile(CONFIG_ENV_FILE);
  const fromEnv = parseEnvFile(ENV_FILE);
  return { ...fromConfig, ...fromEnv };
}

function log(msg) {
  console.log(`[dev-prod] ${msg}`);
}

function needsBuild() {
  // Нет .next → нужен build
  if (!fs.existsSync(NEXT_DIR)) return true;
  if (!fs.existsSync(path.join(NEXT_DIR, 'BUILD_ID'))) return true;
  // Нет маркера новой версии → нужен build
  if (!fs.existsSync(BUILD_MARKER)) return true;
  // Любой файл в src новее маркера → нужен build
  const markerMtime = fs.statSync(BUILD_MARKER).mtimeMs;
  function walkDir(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (e.name === 'node_modules' || e.name === '.next') continue;
        if (walkDir(full)) return true;
      } else if (e.isFile() && (e.name.endsWith('.ts') || e.name.endsWith('.tsx') || e.name.endsWith('.css'))) {
        if (fs.statSync(full).mtimeMs > markerMtime) return true;
      }
    }
    return false;
  }
  return walkDir(SRC_DIR);
}

function doBuild() {
  log('Building production bundle (next build)...');
  execSync('cd /home/z/my-project && bun run build', { stdio: 'inherit' });
  // marker
  fs.writeFileSync(BUILD_MARKER, new Date().toISOString());
  log('Build complete.');
}

function startServer() {
  log('Starting production server (node standalone)...');
  // Загружаем env из .env и bizon-config.env — standalone server сам этого не делает
  const loadedEnv = loadEnv();
  if (!loadedEnv.BIZON_ENCRYPTION_KEY) {
    log('WARNING: BIZON_ENCRYPTION_KEY not found in .env or bizon-config.env — server will crash in production!');
  } else {
    log(`Loaded env: BIZON_ENCRYPTION_KEY=**${String(loadedEnv.BIZON_ENCRYPTION_KEY).slice(-6)} (${String(loadedEnv.BIZON_ENCRYPTION_KEY).length} chars)`);
  }
  // Запускаем node standalone server (не next start, не bun — это нестабильно в sandbox)
  const child = spawn(
    process.platform === 'win32' ? 'node.exe' : 'node',
    ['.next/standalone/server.js'],
    {
      cwd: PROJECT_DIR,
      env: {
        ...process.env,
        ...loadedEnv,
        NODE_ENV: 'production',
        PORT: '3000',
        // Ограничиваем heap чтобы Node не разрастался и не убивал sandbox
        // (переопределяет NODE_OPTIONS из env-файлов)
        NODE_OPTIONS: '--max-old-space-size=384',
      },
      stdio: 'inherit',
    }
  );
  child.on('exit', (code) => {
    log(`Server exited with code ${code}. Restarting in 3s...`);
    setTimeout(startServer, 3000); // авто-рестарт
  });
}

try {
  if (needsBuild()) {
    doBuild();
  } else {
    log('Using existing build (.next/BUILD_ID up-to-date).');
  }
  startServer();
} catch (e) {
  console.error('[dev-prod] FATAL:', e);
  process.exit(1);
}
