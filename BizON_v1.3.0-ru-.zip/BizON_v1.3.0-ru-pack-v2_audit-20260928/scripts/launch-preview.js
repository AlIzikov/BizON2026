#!/usr/bin/env node
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const PROJECT_DIR = '/home/z/my-project';
const ENV_FILE = path.join(PROJECT_DIR, '.env');
const CONFIG_FILE = path.join(PROJECT_DIR, 'bizon-config.env');
const SERVER_JS = path.join(PROJECT_DIR, '.next/standalone/server.js');
const LOG_FILE = '/tmp/bizon-server.log';

function parseEnvFile(file) {
  if (!fs.existsSync(file)) return {};
  const raw = fs.readFileSync(file, 'utf8');
  const out = {};
  for (const line of raw.split('\n')) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
      v = v.slice(1, -1);
    }
    out[m[1]] = v;
  }
  return out;
}

function buildEnv() {
  const cfgEnv = parseEnvFile(CONFIG_FILE);
  const dotEnv = parseEnvFile(ENV_FILE);
  return {
    ...cfgEnv,
    ...dotEnv,
    NODE_ENV: 'production',
    PORT: '3000',
    HOSTNAME: '0.0.0.0',
    NEXT_TELEMETRY_DISABLED: '1',
  };
}

function start() {
  const env = buildEnv();
  console.log(`[launch] BIZON_ENCRYPTION_KEY: ${env.BIZON_ENCRYPTION_KEY ? env.BIZON_ENCRYPTION_KEY.slice(0,8) + '...' : 'MISSING'}`);

  const child = spawn('node', [SERVER_JS], {
    cwd: PROJECT_DIR,
    env: { ...process.env, ...env },
    stdio: 'inherit',
  });

  child.on('exit', (code) => {
    console.log(`[launch] server exited code=${code}, restarting in 3s...`);
    setTimeout(start, 3000);
  });

  child.on('error', (err) => {
    console.error(`[launch] error: ${err.message}`);
    setTimeout(start, 5000);
  });
}

if (!fs.existsSync(SERVER_JS)) {
  console.error('[launch] FATAL: server.js not found. Run build first.');
  process.exit(1);
}

start();
