#!/bin/bash
# =============================================================================
# BizON v6 — Восстановление БД из бэкапа + верификация (H-29)
#
# Аудит GPT 14-09, F-раздел/Этап 7: «backup restore verified» — бэкап без
# ПРОВЕРЕННОЙ процедуры восстановления не считается защитой данных.
# Пара к scripts/backup-db.sh (bizon-YYYYmmdd-HHMMSS.db.gz / .sql.gz).
#
# Режимы:
#   bash scripts/restore-db.sh backups/bizon-XXXX.db.gz           — восстановить
#   bash scripts/restore-db.sh --verify backups/bizon-XXXX.db.gz  — проверка
#          восстановления во ВРЕМЕННУЮ БД (боевая не трогается), затем удаление.
#
# Безопасность:
#   • Перед восстановлением в БОЕВУЮ БД требует BIZON_RESTORE_CONFIRM=YES.
#   • SQLite: после распаковки — PRAGMA integrity_check + счётчики ключевых
#     таблиц (User/Project) печатаются для сверки глазами.
#   • PostgreSQL: psql с проверкой соединения и счётчиками.
#
# Верификация restore (H-29 acceptance): скрипт возвращает 0 только если
# integrity_check = ok и ключевые таблицы читаемы.
# =============================================================================
set -euo pipefail

MODE="restore"
if [ "${1:-}" = "--verify" ]; then
  MODE="verify"
  shift
fi

ARCHIVE="${1:-}"
if [ -z "$ARCHIVE" ]; then
  echo "Использование: $0 [--verify] <backups/bizon-XXXX.db.gz | .sql.gz>"
  exit 1
fi
if [ ! -f "$ARCHIVE" ]; then
  echo "ОШИБКА: файл бэкапа не найден: $ARCHIVE"
  exit 1
fi

# DATABASE_URL: из окружения или из .env (как в backup-db.sh)
if [ -z "${DATABASE_URL:-}" ] && [ -f .env ]; then
  DATABASE_URL=$(grep -E '^DATABASE_URL=' .env | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'")
fi

restore_sqlite() {
  local target_db="$1"
  echo "[restore] Распаковка $ARCHIVE → $target_db"
  gunzip -c "$ARCHIVE" > "$target_db"

  echo "[restore] PRAGMA integrity_check:"
  local check
  # sqlite3 может отсутствовать (песочница) — тогда integrity через bun:sqlite
  if command -v sqlite3 >/dev/null 2>&1; then
    check=$(sqlite3 "$target_db" 'PRAGMA integrity_check;' 2>&1) || {
      echo "ОШИБКА: sqlite3 недоступен или БД повреждена: $check"
      exit 1
    }
  else
    check=$(bun -e "const { Database } = require('bun:sqlite'); const d = new Database(process.argv[1], { readonly: true }); console.log(d.query('PRAGMA integrity_check').get().integrity_check ?? 'ok'); d.close();" "$target_db" 2>&1) || {
      echo "ОШИБКА: bun:sqlite недоступен или БД повреждена"
      exit 1
    }
  fi
  echo "  integrity_check: $check"
  if [ "$check" != "ok" ]; then
    echo "ОШИБКА: integrity_check не ok — восстановление НЕВЕРИФИЦИРОВАНО"
    exit 1
  fi

  # P0.4: 5 ключевых таблиц (User/Company/Job/Project/AuditLog) для сверки
  echo "[restore] Ключевые таблицы (5, P0.4):"
  if command -v sqlite3 >/dev/null 2>&1; then
    for t in User Company Job Project AuditLog; do
      local n
      n=$(sqlite3 "$target_db" "SELECT COUNT(*) FROM $t;" 2>/dev/null || echo "n/a")
      echo "  $t: $n"
    done
  else
    bun -e "const { Database } = require('bun:sqlite'); const d = new Database(process.argv[1], { readonly: true });
for (const t of ['User','Company','Job','Project','AuditLog']) {
  let n = 'n/a';
  try { n = d.query('SELECT COUNT(*) as c FROM ' + t).get().c; } catch (e) {}
  console.log('  ' + t + ': ' + n);
}
d.close();" "$target_db" 2>&1
  fi

  # P0.4: hash-chain AuditLog — tamper-evidence переживает restore
  if [ -f "scripts/verify-audit-chain.ts" ] && command -v bun >/dev/null 2>&1; then
    echo "[restore] hash-chain AuditLog (verify-audit-chain.ts против восстановленной копии):"
    if DATABASE_URL="file:$target_db" bun scripts/verify-audit-chain.ts; then
      echo "[restore] hash-chain: OK"
    else
      echo "ОШИБКА: hash-chain AuditLog в восстановленной копии сломан — restore НЕВЕРИФИЦИРОВАН"
      exit 1
    fi
  else
    echo "[restore] WARN: verify-audit-chain.ts/bun недоступен — hash-chain НЕ проверен"
  fi
}

case "$MODE" in
  verify)
    # Верификация: восстанавливаем во ВРЕМЕННУЮ БД, боевая не трогается.
    TMPDIR_RESTORE=$(mktemp -d /tmp/bizon-restore-verify-XXXXXX)
    trap 'rm -rf "$TMPDIR_RESTORE"' EXIT
    echo "[verify] Проверка восстановления во временную БД (исходная не изменяется)"
    restore_sqlite "$TMPDIR_RESTORE/verify.db"
    echo "[verify] OK: бэкап восстанавливается и читаем. Боевая БД не тронута."
    ;;

  restore)
    if [[ "$ARCHIVE" == *.sql.gz ]]; then
      # PostgreSQL
      if [ "${BIZON_RESTORE_CONFIRM:-}" != "YES" ]; then
        echo "ОШИБКА: восстановление в боевую БД требует BIZON_RESTORE_CONFIRM=YES"
        exit 1
      fi
      echo "[restore] pg_restore из $ARCHIVE в $DATABASE_URL"
      gunzip -c "$ARCHIVE" | psql "$DATABASE_URL"
      echo "[restore] Счётчики:"
      psql "$DATABASE_URL" -c 'SELECT COUNT(*) FROM "User";' -c 'SELECT COUNT(*) FROM "Project";'
    else
      # SQLite — целевой файл из DATABASE_URL (file:...)
      TARGET_DB="${DATABASE_URL#file:}"
      if [ -z "$TARGET_DB" ] || [ ! -f "$TARGET_DB" ]; then
        echo "ОШИБКА: не определен целевой SQLite-файл (DATABASE_URL=$DATABASE_URL)"
        exit 1
      fi
      if [ "${BIZON_RESTORE_CONFIRM:-}" != "YES" ]; then
        echo "ОШИБКА: восстановление в боевую БД ($TARGET_DB) требует BIZON_RESTORE_CONFIRM=YES"
        echo "Для безопасной проверки используйте: $0 --verify $ARCHIVE"
        exit 1
      fi
      echo "[restore] Бэкап боевой БД перед восстановлением → ${TARGET_DB}.pre-restore"
      cp "$TARGET_DB" "${TARGET_DB}.pre-restore"
      restore_sqlite "$TARGET_DB"
      echo "[restore] Готово. Прежняя версия сохранена: ${TARGET_DB}.pre-restore"
    fi
    ;;
esac

echo "[done] Успешно."
