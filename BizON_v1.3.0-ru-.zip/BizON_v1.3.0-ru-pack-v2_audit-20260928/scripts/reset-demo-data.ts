// ЭТАП 1.2 · reset демо-данных пред-пилота (директива: «восстановление
// демо-данных перед каждой демонстрацией»).
//
// Сносит ВСЁ демо-наследие пред-пилота в безопасном порядке (FK) и
// перезасевает чистый контур scripts/seed-demo-pilot.ts:
//   1. резонанс-матчи демо-вакансий/кандидатов
//   2. endorsements на демо-кандидатов И от демо-референса
//   3. NFTSkill + UserSkill (+осиротевшие Skill 'demo') кандидатов
//   4. резонанс-профили/ответы кандидатов
//   5. вакансии с тегом [DEMO-PILOT]
//   6. юзеры @bizon.demo (кроме тех, что созданы другими фичами — по emailHash)
//   7. FeatureFlag demo-флаги НЕ трогает (админское состояние)
//
// P0.5 (директива владельца 2026-09-28, §11.2 аудита) — защита от гонки:
//   • ADVISORY LOCK (PID-файл db/demo-reset.lock): второй запуск при живом
//     первом — abort; залежавшийся (процесс мёртв) — честно подхватывается;
//   • при живом dev-сервере :3000 — предупреждение «остановите dev-сервер
//     перед reset» (WAL-изолированное чтение сервера может кэшировать снесённый
//     батч — наблюдение R5-P1-REBUILD-P0: reset #1 оставил 6 вакансий);
//   • контрольная зачистка после первого прохода (второй sweep по остаткам);
//   • финальный счётчик «Вакансии (3) после reset» — канон демо-контура;
//   • напоминание: пароли после пересева — временные сид-пароли, ОБЯЗАТЕЛЬНО
//     bun scripts/reset-demo-passwords.ts (P0.3).
//
// Запуск: bun run scripts/reset-demo-data.ts           # снос + пересев
//         bun run scripts/reset-demo-data.ts --wipe-only  # только снос
import { PrismaClient } from '@prisma/client';
import { execSync } from 'node:child_process';
import { openSync, closeSync, readFileSync, writeFileSync, unlinkSync } from 'node:fs';

const db = new PrismaClient();

const LOCK_PATH = 'db/demo-reset.lock';
const DEMO_TAG = '[DEMO-PILOT]';
const CANON_DEMO_JOBS = 3;

/** P0.5: advisory lock через PID-файл (O_EXCL — атомарное создание). */
function acquireLock(): boolean {
  try {
    const fd = openSync(LOCK_PATH, 'wx');
    writeFileSync(fd, String(process.pid));
    closeSync(fd);
    return true;
  } catch {
    // Файл уже есть: жив ли владелец?
    try {
      const pid = Number.parseInt(readFileSync(LOCK_PATH, 'utf8').trim(), 10);
      if (Number.isFinite(pid) && pid > 0) {
        try {
          process.kill(pid, 0); // сигнал 0 = проверка живости (убивать не убивает)
          return false; // живой конкурент — честный abort
        } catch {
          /* процесс мёртв — stale lock */
        }
      }
    } catch {
      /* не читается — stale */
    }
    unlinkSync(LOCK_PATH);
    return acquireLock(); // подхватили stale lock
  }
}

function releaseLock(): void {
  try {
    unlinkSync(LOCK_PATH);
  } catch {
    /* уже снят */
  }
}

/** P0.5: живой dev-сервер на :3000? (для предупреждения, не блокировки) */
async function devServerAlive(): Promise<boolean> {
  try {
    const res = await fetch('http://localhost:3000/api/health', { signal: AbortSignal.timeout(1500) });
    return res.ok;
  } catch {
    return false;
  }
}

async function main() {
  const wipeOnly = process.argv.includes('--wipe-only');
  if (!acquireLock()) {
    console.error(
      `[demo-reset] ABORT: другой reset уже выполняется (pid ${readFileSync(LOCK_PATH, 'utf8').trim()}). ` +
        'Если это не так и процесса нет — удалите db/demo-reset.lock вручную.',
    );
    process.exit(1);
  }
  try {
    if (await devServerAlive()) {
      console.warn(
        '[demo-reset] ⚠ ВНИМАНИЕ: dev-сервер :3000 ЖИВ. Остановите dev-сервер перед reset — ' +
          'живой сервер может удерживать кэш/WAL-снимок снесённого батча (наблюдение §11.2: reset #1 оставил 6 вакансий). ' +
          'Продолжаю с контрольной зачисткой.',
      );
    }
    console.log('[demo-reset] снос демо-данных пред-пилота…');

  // Демо-юзеры: @bizon.demo
  const demoUsers = await db.user.findMany({
    where: { emailEncrypted: { not: null } },
    select: { id: true, emailEncrypted: true, roles: true },
  });
  const { decrypt, hashEmail } = await import('../src/lib/security/crypto');
  const demoIds: string[] = [];
  for (const u of demoUsers) {
    try {
      const email = decrypt(u.emailEncrypted as string);
      if (email.endsWith('@bizon.demo')) demoIds.push(u.id);
    } catch {
      /* чужой keyfile-эон — не наш юзер */
    }
  }
  console.log(`[demo-reset] демо-юзеров найдено: ${demoIds.length}`);
  if (demoIds.length === 0) {
    console.log('[demo-reset] нечего сносить.');
  } else {
    // Вакансии по тегу (и по hiringManagerId на всякий случай)
    const jobs = await db.job.findMany({
      where: { OR: [{ title: { contains: '[DEMO-PILOT]' } }, { hiringManagerId: { in: demoIds } }] },
      select: { id: true },
    });
    const jobIds = jobs.map((j) => j.id);
    console.log(`[demo-reset] демо-вакансий: ${jobIds.length}`);

    if (jobIds.length) await db.resonanceMatch.deleteMany({ where: { jobId: { in: jobIds } } });
    await db.resonanceMatch.deleteMany({ where: { userId: { in: demoIds } } });

    await db.endorsement.deleteMany({
      where: { OR: [{ subjectId: { in: demoIds } }, { authorId: { in: demoIds } }] },
    });

    await db.nFTSkill.deleteMany({ where: { userId: { in: demoIds } } });
    const userSkills = await db.userSkill.findMany({ where: { userId: { in: demoIds } }, select: { skillId: true } });
    await db.userSkill.deleteMany({ where: { userId: { in: demoIds } } });

    await db.resonanceProfile.deleteMany({ where: { userId: { in: demoIds } } });

    // Отклики демо-кандидатов / на демо-вакансии (до удаления юзеров/вакансий)
    if (jobIds.length) {
      await db.jobApplication.deleteMany({
        where: { OR: [{ jobId: { in: jobIds } }, { userId: { in: demoIds } }] },
      });
    }

    if (jobIds.length) await db.job.deleteMany({ where: { id: { in: jobIds } } });

    // Сироты-skill категории demo
    if (userSkills.length) {
      const orphanSkillIds = (
        await db.skill.findMany({ where: { id: { in: userSkills.map((s) => s.skillId) }, category: 'demo' }, select: { id: true } })
      )
        .map((s) => s.id)
        .filter(async (id) => (await db.userSkill.count({ where: { skillId: id } })) === 0);
      if (orphanSkillIds.length) await db.skill.deleteMany({ where: { id: { in: orphanSkillIds } } });
    }

    // Юзеры: сами по себе (Session/File/etc. — onDelete: Cascade по схеме)
    await db.user.deleteMany({ where: { id: { in: demoIds } } });

    // Company-запись демо-компании (если на неё больше никто не ссылается)
    const companyName = 'ООО «Демо-Компания» (пред-пилот)';
    const demoCompany = await db.company.findFirst({ where: { name: companyName }, select: { id: true } });
    if (demoCompany) {
      const stillLinked = await db.user.count({ where: { companyId: demoCompany.id } });
      const stillJobs = await db.job.count({ where: { companyId: demoCompany.id } });
      if (stillLinked === 0 && stillJobs === 0) {
        await db.company.delete({ where: { id: demoCompany.id } }).catch(() => undefined);
      }
    }
    console.log('[demo-reset] снос завершён.');

    // === P0.5: контрольная зачистка — второй sweep по остаткам гонки ===
    // Живой dev-сервер может между findMany и deleteMany создать/отдать
    // запись из старого батча — проверяем фактический остаток и дочищаем.
    const leftoverUsers = await db.user.findMany({
      where: { emailEncrypted: { not: null } },
      select: { id: true, emailEncrypted: true },
    });
    const leftoverIds: string[] = [];
    for (const u of leftoverUsers) {
      try {
        const email = decrypt(u.emailEncrypted as string);
        if (email.endsWith('@bizon.demo')) leftoverIds.push(u.id);
      } catch {
        /* чужой эон */
      }
    }
    if (leftoverIds.length > 0) {
      console.warn(`[demo-reset] ⚠ контрольная зачистка: остаток демо-юзеров ${leftoverIds.length} — дочищаю`);
      await db.user.deleteMany({ where: { id: { in: leftoverIds } } });
    }
    const leftoverJobs = await db.job.count({ where: { title: { contains: DEMO_TAG } } });
    if (leftoverJobs > 0) {
      console.warn(`[demo-reset] ⚠ контрольная зачистка: остаток демо-вакансий ${leftoverJobs} — дочищаю`);
      await db.job.deleteMany({ where: { title: { contains: DEMO_TAG } } });
    }
    console.log('[demo-reset] контрольная зачистка: остатков нет.');
  }

  if (wipeOnly) {
    console.log('[demo-reset] --wipe-only: пересев не выполнялся.');
    return;
  }
  console.log('[demo-reset] пересев…');
  execSync('bun run scripts/seed-demo-pilot.ts', { stdio: 'inherit', cwd: process.cwd() });

  // === P0.5: финальный чеклист «Вакансии (3) после reset» ===
  const canonJobs = await db.job.count({ where: { title: { contains: DEMO_TAG } } });
  if (canonJobs === CANON_DEMO_JOBS) {
    console.log(`[demo-reset] Вакансии (${CANON_DEMO_JOBS}) после reset: ${canonJobs} ✓ канон`);
  } else {
    console.error(
      `[demo-reset] ✗ Вакансии (${CANON_DEMO_JOBS}) после reset: ${canonJobs} — ОТКЛОНЕНИЕ ОТ КАНОНА! ` +
        'Остановите dev-сервер и повторите reset (убедитесь, что нет второго запуска — lock в db/demo-reset.lock).',
    );
    process.exitCode = 1;
  }
  console.log('[demo-reset] ГОТОВО: демо-контур восстановлен (company_demo@bizon.demo).');
  // P0.3: пересев кладёт ВРЕМЕННЫЕ сид-пароли — ротация обязательна до демо.
  console.warn(
    '[demo-reset] ⚠ ОБЯЗАТЕЛЬНО перед демонстрацией: bun scripts/reset-demo-passwords.ts ' +
      '(пересев создал аккаунты с временным сид-паролем; ротация → .env + revoke сессий).',
  );
  } finally {
    releaseLock();
  }
}

main()
  .then(() => db.$disconnect())
  .catch(async (e) => {
    console.error('[demo-reset] FAIL:', e);
    releaseLock();
    await db.$disconnect();
    process.exit(1);
  });
