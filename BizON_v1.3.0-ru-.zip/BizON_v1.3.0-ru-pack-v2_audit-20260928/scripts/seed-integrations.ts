// =============================================================================
// П4 Фаза 1 (директива владельца «П4 RU-PACK v2 + Hub-архитектура»):
// СИД РЕЕСТРА ВНЕШНИХ СЕРВИСОВ — 44 порта / 14 категорий (ADR-007; database — Ф2.4).
//
// Канон: каждая категория = stub + 1-3 real; активен честный текущий
// носитель (stub — если внешний провайдер требует ключей/договора,
// in-house — если локальная реализация уже работает).
//
// Идемпотентность: create-if-missing по code @unique. Существующие строки
// НЕ перезаписываются — решения админа (isActive/приоритеты) не затрагиваются.
// Секреты в БД не пишутся — только env (ADR-007, §2).
//
// Запуск: bun scripts/seed-integrations.ts
// Проверка реестра: bun scripts/integration-status.ts
// =============================================================================
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

interface PortSeed {
  code: string;
  category: string;
  provider: string;
  kind: 'stub' | 'in-house' | 'external-http';
  mode: 'virtual' | 'real';
  priority: number;
  isActive: boolean;
  description: string;
}

const P_INHOUSE = 10; // работающая локальная реализация
const P_STUB = 50; // fallback-заглушка
const P_REAL = 100; // внешний провайдер (порядок регистрации)

const SEED: PortSeed[] = [
  // --- email (4) ---
  { code: 'console-email', category: 'email', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: true, description: 'Заглушка: пишет письмо в журнал сервера. Активна, пока не заданы SMTP_* (честный не-успех наружной доставки не имитирует).' },
  { code: 'smtp', category: 'email', provider: 'SMTP (generic)', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Любой SMTP-провайдер. Env: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM.' },
  { code: 'yandex-360-smtp', category: 'email', provider: 'Яндекс 360 (SMTP)', kind: 'external-http', mode: 'real', priority: P_REAL + 10, isActive: false, description: 'Почта Яндекса для 152-ФЗ-локализации (П4 Фаза 2). Env: SMTP_HOST/PORT/USER/PASSWORD/FROM (smtp.yandex.ru:465).' },
  { code: 'mailru-email', category: 'email', provider: 'Mail.ru (SMTP)', kind: 'external-http', mode: 'real', priority: P_REAL + 20, isActive: false, description: 'Альтернатива РФ-контур. Env: SMTP_HOST/PORT/USER/PASSWORD/FROM (smtp.mail.ru:465).' },

  // --- storage (4) ---
  { code: 'local-disk', category: 'storage', provider: 'Локальный диск', kind: 'in-house', mode: 'virtual', priority: P_INHOUSE, isActive: true, description: 'Текущая реализация file-storage (песочница/разработка). Offsite-надёжности НЕ даёт — см. docs/ops/backup-location.md.' },
  { code: 'console-storage', category: 'storage', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: false, description: 'Заглушка: только журнал операций с объектами.' },
  { code: 's3-compatible', category: 'storage', provider: 'S3/R2 (generic)', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Offsite-бэкап и файлы (Б1: ключи — у владельца). Env: S3_ENDPOINT, S3_BUCKET, S3_ACCESS_KEY, S3_SECRET_KEY.' },
  { code: 'yandex-object-storage', category: 'storage', provider: 'Yandex Object Storage', kind: 'external-http', mode: 'real', priority: P_REAL + 10, isActive: false, description: 'Целевое хранилище Yandex Cloud (152-ФЗ, П4 Фаза 2.4). Env: YS3_ENDPOINT, YS3_BUCKET, YS3_ACCESS_KEY_ID, YS3_SECRET_ACCESS_KEY.' },

  // --- push (2) ---
  { code: 'console-push', category: 'push', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: true, description: 'Заглушка браузерных push: события в журнал.' },
  { code: 'web-push-api', category: 'push', provider: 'Web Push (VAPID)', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Браузерные push через VAPID. Env: VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY.' },

  // --- kyc (3) ---
  { code: 'local-review', category: 'kyc', provider: 'Админ-ревью BizON', kind: 'in-house', mode: 'virtual', priority: P_INHOUSE, isActive: true, description: 'Текущий канон KYC: ручное одобрение админом (единственная точка повышения tier), авто-повышений нет.' },
  { code: 'console-kyc', category: 'kyc', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: false, description: 'Заглушка KYC-провайдера: события в журнал, решений не принимает.' },
  { code: 'sumsub', category: 'kyc', provider: 'Sumsub', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'По триггеру Enterprise (решение владельца). Env: SUMSUB_APP_TOKEN, SUMSUB_SECRET_KEY, SUMSUB_LEVEL_NAME.' },

  // --- search (3) ---
  { code: 'sqlite-fts5', category: 'search', provider: 'SQLite FTS5', kind: 'in-house', mode: 'virtual', priority: P_INHOUSE, isActive: true, description: 'Текущий полнотекстовый поиск (R5-P1 B1). Потолок ~10k записей — триггер пересмотра.' },
  { code: 'console-search', category: 'search', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: false, description: 'Заглушка поискового провайдера.' },
  { code: 'pg-fulltext', category: 'search', provider: 'PostgreSQL FTS', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Полнотекст на PG после cutover (Решение 8, Вариант A). Env: DATABASE_URL (PG).' },

  // --- observability (3) ---
  { code: 'console-observability', category: 'observability', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: true, description: 'Ошибки/метрики в журнал сервера (Sentry без DSN не инициализируется — канон честности).' },
  { code: 'sentry', category: 'observability', provider: 'Sentry', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Env: SENTRY_DSN (после выбора self-hosted/SaaS).' },
  { code: 'yandex-monitoring', category: 'observability', provider: 'Yandex Monitoring', kind: 'external-http', mode: 'real', priority: P_REAL + 10, isActive: false, description: 'Мониторинг РФ-контура. Env: YC_API_KEY, YC_FOLDER_ID.' },

  // --- payments (4) ---
  { code: 'demo-virtual', category: 'payments', provider: 'Демо-касса (люмены)', kind: 'in-house', mode: 'virtual', priority: P_INHOUSE, isActive: true, description: 'Виртуальная касса на люменах (Решение 5) — текущий платёжный канон. Реальные деньги — только через realMoneyGate.' },
  { code: 'console-payments', category: 'payments', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: false, description: 'Заглушка платёжного порта: только журнал.' },
  { code: 'yookassa-ru', category: 'payments', provider: 'ЮKassa (YooKassa)', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'П4 Фаза 2.1: адаптер PaymentPort + webhook. Договор/бюджет — стоп-граница владельца (>$5k). Env: YOOKASSA_SHOP_ID, YOOKASSA_SECRET_KEY.' },
  { code: 'tinkoff-ru', category: 'payments', provider: 'Т-Банк (Tinkoff)', kind: 'external-http', mode: 'real', priority: P_REAL + 10, isActive: false, description: 'П4 Фаза 2.1: адаптер PaymentPort + webhook. Env: TINKOFF_TERMINAL_KEY, TINKOFF_PASSWORD.' },

  // --- receipt (3) ---
  { code: 'console-receipt', category: 'receipt', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: true, description: '54-ФЗ: чеки не создаются, попытка = честный отказ (dry-run). Реальная касса — Фаза 2.2.' },
  { code: 'yookassa-receipt', category: 'receipt', provider: 'ЮKassa Чеки', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Фискализация через ЮKassa (54-ФЗ). Env: YOOKASSA_SHOP_ID, YOOKASSA_SECRET_KEY.' },
  { code: 'atol-online', category: 'receipt', provider: 'АТОЛ Онлайн', kind: 'external-http', mode: 'real', priority: P_REAL + 10, isActive: false, description: 'Облачная касса АТОЛ (54-ФЗ). Env: ATOL_LOGIN, ATOL_PASSWORD, ATOL_GROUP_CODE.' },

  // --- blockchain (3) ---
  { code: 'console-blockchain', category: 'blockchain', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: true, description: 'Якорение в журнал (offline-режим). Ончейн-вызовы не имитируются.' },
  { code: 'polygon-anchor', category: 'blockchain', provider: 'Polygon (anchor)', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Якорение репутации (onchain-anchor-service). Env: POLYGON_RPC_URL, POLYGON_ANCHOR_PRIVATE_KEY.' },
  { code: 'eth-anchor', category: 'blockchain', provider: 'Ethereum (anchor)', kind: 'external-http', mode: 'real', priority: P_REAL + 10, isActive: false, description: 'Резервная цепь якорения. Env: ETH_RPC_URL, ETH_ANCHOR_PRIVATE_KEY.' },

  // --- sms (4) ---
  { code: 'console-sms', category: 'sms', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: true, description: 'SMS в журнал (2FA/уведомления — до подключения провайдера).' },
  { code: 'smsaero-ru', category: 'sms', provider: 'SMS Aero', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'РФ SMS-провайдер. Env: SMSAERO_EMAIL, SMSAERO_API_KEY.' },
  { code: 'mts-exolve', category: 'sms', provider: 'МТС Exolve', kind: 'external-http', mode: 'real', priority: P_REAL + 10, isActive: false, description: 'РФ SMS/voice API. Env: MTS_EXOLVE_API_KEY.' },
  { code: 'smsru', category: 'sms', provider: 'SMS.ru', kind: 'external-http', mode: 'real', priority: P_REAL + 20, isActive: false, description: 'РФ SMS-провайдер. Env: SMSRU_API_KEY.' },

  // --- notifications (3) ---
  { code: 'in-app-db', category: 'notifications', provider: 'In-app (БД)', kind: 'in-house', mode: 'virtual', priority: P_INHOUSE, isActive: true, description: 'Текущие in-app уведомления (notification-service) — работают.' },
  { code: 'console-notifications', category: 'notifications', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: false, description: 'Заглушка доставщика уведомлений.' },
  { code: 'email-digest', category: 'notifications', provider: 'Email-дайджест', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Дайджесты поверх email-порта. Env: SMTP_HOST, SMTP_PORT (наследует email-категорию).' },

  // --- ai (3) ---
  { code: 'console-ai', category: 'ai', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: true, description: 'AI-вызовы в журнал. Миграция ai-core в hub — отдельная итерация (не Фаза 1).' },
  { code: 'zai-glm', category: 'ai', provider: 'Z.ai GLM', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Текущий LLM-бэкенд платформы (ai-core, z-ai-web-dev-sdk). Env: не требует — SDK читает своё окружение. Перевод ai-core на hub — отдельная итерация.' },
  { code: 'openai-compatible', category: 'ai', provider: 'OpenAI-compatible', kind: 'external-http', mode: 'real', priority: P_REAL + 10, isActive: false, description: 'Резервный generic-провайдер. Env: OPENAI_BASE_URL, OPENAI_API_KEY.' },

  // --- analytics (3) ---
  { code: 'in-house-actions', category: 'analytics', provider: 'ActionEvent (БД)', kind: 'in-house', mode: 'virtual', priority: P_INHOUSE, isActive: true, description: 'Продуктовая аналитика на ActionEvent (R5-P1 E3) — работает, isPublic=false.' },
  { code: 'console-analytics', category: 'analytics', provider: 'Console (stub)', kind: 'stub', mode: 'virtual', priority: P_STUB, isActive: false, description: 'События аналитики в журнал.' },
  { code: 'yandex-metrica', category: 'analytics', provider: 'Яндекс Метрика', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Веб-аналитика РФ-контура. Env: YANDEX_METRICA_COUNTER_ID.' },

  // --- database (2, П4 Фаза 2.4) ---
  // Особенность категории: БД не переключается в runtime — активация
  // yandex-managed-postgres = cutover-протокол ADR-004 (гейт 422 CUTOVER_REQUIRED).
  { code: 'console-database', category: 'database', provider: 'Runtime (Prisma/DATABASE_URL)', kind: 'in-house', mode: 'virtual', priority: P_INHOUSE, isActive: true, description: 'Диагностика текущего контура: факт провайдера из DATABASE_URL + проба SELECT 1 (пилот SQLite — Вариант A, Решение 8).' },
  { code: 'yandex-managed-postgres', category: 'database', provider: 'Yandex Managed PostgreSQL', kind: 'external-http', mode: 'real', priority: P_REAL, isActive: false, description: 'Целевая инфраструктура РФ (П4/Yandex Cloud, 152-ФЗ). Активация = cutover-протокол ADR-004: кластер → DATABASE_URL=postgres… → миграция → рестарт → «Активировать».' },
];

async function main() {
  console.log(`[integrations-seed] канон ADR-007: ${SEED.length} портов / ${new Set(SEED.map((s) => s.category)).size} категорий`);
  let created = 0;
  let kept = 0;
  const byCategory = new Map<string, number>();

  for (const port of SEED) {
    const existing = await db.externalServicePort.findUnique({ where: { code: port.code } });
    if (existing) {
      kept++;
      byCategory.set(port.category, (byCategory.get(port.category) ?? 0) + 1);
      continue;
    }
    await db.externalServicePort.create({ data: { ...port } });
    created++;
    byCategory.set(port.category, (byCategory.get(port.category) ?? 0) + 1);
  }

  // Контроль канона: ровно один активный порт в каждой категории
  const categories = [...byCategory.keys()];
  const violations: string[] = [];
  for (const category of categories) {
    const active = await db.externalServicePort.count({ where: { category, isActive: true } });
    if (active !== 1) violations.push(`${category}: активных = ${active} (канон: ровно 1)`);
  }

  console.log(`[integrations-seed] создано: ${created}, уже было: ${kept}`);
  for (const [category, count] of [...byCategory.entries()].sort()) {
    console.log(`  ${category}: ${count}`);
  }
  if (violations.length > 0) {
    console.error(`[integrations-seed] НАРУШЕНИЕ КАНОНА (ровно 1 активный на категорию):\n  ${violations.join('\n  ')}`);
    process.exit(1);
  }
  console.log('[integrations-seed] канон подтверждён: 14 категорий × ровно 1 активный порт.');
  await db.$disconnect();
}

main();
