// =============================================================================
// W1.5 (PRE-LAUNCH C1 / DEF-20): миграция plaintext email → только emailHash +
// emailEncrypted. Модель безопасности: AES-256-GCM через src/lib/security/crypto.
//
// Безопасность:
//  • Для каждого пользователя с plaintext email проверяется, что
//    decrypt(emailEncrypted) === email (или восстановление из plaintext, если
//    enc отсутствует) — записи без верифицируемого шифра НЕ трогаются.
//  • Идемпотентно: повторный запуск находит 0 plaintext и завершается.
//  • После миграции login/lookup работают по emailHash (все читатели email
//    в коде уже decrypt-first: api-helpers, 2fa, export-data, data-vault).
//
// Запуск: bun scripts/migrate-email-encrypt.ts
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { encrypt, decrypt, hashEmail } from '../src/lib/security/crypto';

const db = new PrismaClient();

async function main() {
  const users = await db.user.findMany({
    where: { email: { not: null } },
    select: { id: true, email: true, emailEncrypted: true, emailHash: true },
  });

  console.log(`Пользователей с plaintext email: ${users.length}`);

  let migrated = 0;
  let restoredEnc = 0;
  let skipped = 0;

  for (const u of users) {
    const email = (u.email ?? '').toLowerCase();
    if (!email) {
      skipped++;
      continue;
    }

    // 1) Верифицируем/восстанавливаем зашифрованную копию
    let encryptedOk = false;
    if (u.emailEncrypted) {
      const dec = decrypt(u.emailEncrypted);
      encryptedOk = !!dec && dec.toLowerCase() === email;
      if (!encryptedOk) {
        // Шифр не совпадает (другой ключ?) — безопасный вариант: перешифровать
        // из текущего plaintext (он есть в руках) и перезаписать enc.
        console.warn(`  [${u.id}] decrypt(emailEncrypted) != email — перешифровка`);
      }
    }
    if (!u.emailEncrypted || !encryptedOk) {
      restoredEnc++;
    }

    // 2) Верифицируем/восстанавливаем hash
    const expectedHash = hashEmail(email);
    const hashOk = u.emailHash === expectedHash;
    if (!hashOk) {
      console.warn(`  [${u.id}] emailHash не совпадает — пересчёт`);
    }

    // 3) Пишем: enc (при необходимости перезапись), hash (при необходимости),
    //    plaintext → null
    await db.user.update({
      where: { id: u.id },
      data: {
        email: null,
        ...(u.emailEncrypted && encryptedOk ? {} : { emailEncrypted: encrypt(email) }),
        ...(!u.emailHash || !hashOk ? { emailHash: expectedHash } : {}),
      },
    });
    migrated++;
  }

  // 4) Проверка результата
  const remaining = await db.user.count({ where: { email: { not: null } } });
  console.log(
    `Мигрировано: ${migrated} (перешифровано enc: ${restoredEnc}, пропущено пустых: ${skipped}). ` +
      `Осталось plaintext email: ${remaining}`,
  );

  if (remaining > 0) {
    console.error('ОШИБКА: остались plaintext email — миграция не завершена');
    process.exit(1);
  }
  console.log('OK: 0 plaintext email в БД');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
