// R1 (Task 40) — seed item bank резонанса: 40 калиброванных вопросов
// (8 traits × 5 уровней, IRT 2PL). ИДЕМПОТЕНТНЫЙ АДДИТИВНЫЙ сид:
// только upsert по стабильным слагам, никаких wipe (канон Task 38 —
// wipe-сиды запрещены при доменных данных).
//
// Источник значений: src/lib/resonance/item-bank.ts (константы, детерминизм).
// Офлайн-калибровка EM (simulations/irt_calibration.py) предлагает значения
// отдельным PR — сид всегда синхронен с item-bank.ts.
//
// Запуск: bun run scripts/r40-seed-resonance-items.ts
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

async function main() {
  const { RESONANCE_ITEM_BANK, assertBankIntegrity } = await import(
    '../src/lib/resonance/item-bank'
  );
  assertBankIntegrity();

  let created = 0;
  let updated = 0;
  for (const item of RESONANCE_ITEM_BANK) {
    const existing = await db.resonanceItem.findUnique({ where: { slug: item.slug } });
    if (!existing) created += 1;
    else updated += 1;
    await db.resonanceItem.upsert({
      where: { slug: item.slug },
      create: item,
      update: {
        traitId: item.traitId,
        level: item.level,
        text: item.text,
        aSlope: item.aSlope,
        bDifficulty: item.bDifficulty,
        active: true,
      },
    });
  }
  const total = await db.resonanceItem.count();
  console.log(
    `[r40-seed] item bank: создано ${created}, обновлено ${updated}, всего в БД ${total} (ожидалось 40)`,
  );
  if (total < RESONANCE_ITEM_BANK.length) {
    throw new Error(`Банк не добит: ${total} < 40`);
  }
}

main()
  .then(() => db.$disconnect())
  .catch(async (e) => {
    console.error('[r40-seed] FAIL:', e);
    await db.$disconnect();
    process.exit(1);
  });
