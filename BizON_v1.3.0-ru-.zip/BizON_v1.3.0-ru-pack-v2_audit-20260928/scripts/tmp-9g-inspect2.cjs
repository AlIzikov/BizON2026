const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();
(async () => {
  const s = await db.session.findMany({ where: { token: { in: ['demo-token', '8a4be271d397c02c84b17fe8d4edaa5a1d3fe9c60b9ad232c34459ad2900e758'] } }, include: { user: { select: { id: true, name: true, accountType: true, companyId: true } } } });
  console.log('SESSIONS:', JSON.stringify(s, null, 1));
  // userSkills for candidate pool
  const us = await db.userSkill.findMany({ select: { userId: true, skill: { select: { name: true } }, level: true, currentLevel: true, peakLevel: true, verificationLevel: true, confidence: true }, take: 100 });
  console.log('USERSKILLS:', JSON.stringify(us, null, 0));
  await db.$disconnect();
})().catch(e => { console.error(e); process.exit(1); });
