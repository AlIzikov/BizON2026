// E2E-пир B: реалтайм-проверка чата (не тест-сьют — ручная E2E-проверка направления А).
// Использование: bun scripts/rt-peer-b.mjs
import { io } from 'socket.io-client';

const ORIGIN = 'http://127.0.0.1:3000';
const env = Object.fromEntries(
  (await Bun.file('/tmp/rt_env').text()).split('\n').filter(Boolean).map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1)]),
);
const A_ID = env.A_ID;
const B_TOKEN = env.B_TOKEN;
const log = (...a) => console.log(new Date().toISOString().slice(11, 23), '[B]', ...a);

const api = async (path, init = {}) => {
  const res = await fetch(`${ORIGIN}${path}`, {
    ...init,
    headers: { 'content-type': 'application/json', cookie: `bizon_session=${B_TOKEN}`, ...(init.headers ?? {}) },
  });
  const text = await res.text();
  let body = null;
  try { body = JSON.parse(text); } catch {}
  return { status: res.status, body };
};

// 1) B отправляет первое сообщение A через REST (каноничный путь) → создаётся диалог
const send = await api('/api/messages', {
  method: 'POST',
  body: JSON.stringify({ toUserId: A_ID, content: 'Привет из скрипта B — проверка реалтайма' }),
});
log('REST send →', send.status, 'conversationId:', send.body?.conversationId);
if (send.status !== 201) {
  log('FAIL: сообщение не создано', send.body);
  process.exit(1);
}
const convId = send.body.conversationId;

// 2) B подключается к чат-сервису со своей сессией
// Сокет — только через прокси :81 (XTransformPort), как из браузера; REST — напрямую на :3000.
const socket = io('http://127.0.0.1:81/?XTransformPort=3003', {
  extraHeaders: { cookie: `bizon_session=${B_TOKEN}` },
  transports: ['polling', 'websocket'],
  reconnection: true,
  timeout: 10000,
});

socket.on('connect', () => {
  log('socket connected', socket.id);
  socket.emit('conversation:join', { conversationId: convId }, (r) => log('join ack:', JSON.stringify(r)));
});
socket.on('connect_error', (e) => log('CONNECT_ERROR:', e.message));
socket.on('conversation:error', (e) => log('conversation:error', JSON.stringify(e)));
socket.on('presence:state', (p) => log('presence:state', JSON.stringify(p)));
socket.on('conversation:typing', (p) => {
  log('TYPING from A:', p.isTyping ? 'печатает…' : 'остановился');
});
socket.on('conversation:read', (p) => log('READ receipt: A прочитал мои сообщения', JSON.stringify(p)));
socket.on('message:new', async (p) => {
  log('MESSAGE from A live:', JSON.stringify(p.message?.content));
  if (!p.message?.content?.includes('Ответ от B')) {
    setTimeout(async () => {
      const r = await api('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ toUserId: A_ID, content: 'Ответ от B — виден ли в браузере A без перезагрузки?' }),
      });
      log('REST reply →', r.status);
    }, 1500);
  }
});

setTimeout(() => {
  log('DONE, exit');
  socket.disconnect();
  process.exit(0);
}, 90000);
