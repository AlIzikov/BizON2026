// BizON — Этап 8.6: Test email script
// Отправляет тестовое письмо на указанный адрес для проверки SMTP.
//
// Запуск:
//   node scripts/test-email.js <email>
//   SMTP_HOST=smtp.yandex.ru SMTP_PORT=465 SMTP_USER=... SMTP_PASSWORD=... SMTP_FROM="BizON <no-reply@bizon.ru>" \
//     node scripts/test-email.js user@example.com
//
// Если SMTP_* переменные не заданы — письмо будет залогировано в консоль (dev-stub).

const EMAIL = process.argv[2];

if (!EMAIL) {
  console.error('Использование: node scripts/test-email.js <email>');
  console.error('Пример:');
  console.error('  SMTP_HOST=smtp.yandex.ru SMTP_PORT=465 SMTP_USER=... SMTP_PASSWORD=... \\');
  console.error('  SMTP_FROM="BizON <no-reply@bizon.ru>" node scripts/test-email.js user@example.com');
  process.exit(1);
}

(async () => {
  let nodemailer;
  try {
    nodemailer = require('nodemailer');
  } catch (e) {
    console.error('❌ nodemailer не установлен. Запустите: npm install nodemailer');
    process.exit(1);
  }

  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT;
  const user = process.env.SMTP_USER;
  const password = process.env.SMTP_PASSWORD;
  const from = process.env.SMTP_FROM;

  console.log('=== BizON — Test Email ===');
  console.log(`To: ${EMAIL}`);
  console.log(`SMTP_HOST: ${host || '(не задан)'}`);
  console.log(`SMTP_PORT: ${port || '(не задан)'}`);
  console.log(`SMTP_USER: ${user ? '(задан)' : '(не задан)'}`);
  console.log(`SMTP_FROM: ${from || '(не задан)'}`);
  console.log('');

  const html = `<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><title>BizON — тестовое письмо</title></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#0f172a;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:24px 0;">
    <tr><td align="center">
      <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(15,23,42,0.08);">
        <tr>
          <td style="background:#1e3a8a;padding:20px 28px;">
            <table role="presentation" width="100%"><tr>
              <td style="font-size:20px;font-weight:700;color:#ffffff;letter-spacing:0.5px;">
                <span style="color:#34d399;">B</span>izON
              </td>
              <td align="right" style="font-size:12px;color:#cbd5e1;">Индекс доверия</td>
            </tr></table>
          </td>
        </tr>
        <tr>
          <td style="padding:28px;">
            <h1 style="font-size:18px;font-weight:600;margin:0 0 16px;color:#1e3a8a;">Тестовое письмо</h1>
            <p style="font-size:15px;line-height:1.55;margin:0 0 14px;color:#334155;">
              Если вы видите это письмо — SMTP-настройки BizON работают корректно.
              Re-engagement уведомления (рост IP-score, новые вакансии, подтверждение навыков)
              будут приходить автоматически раз в день.
            </p>
            <p style="font-size:13px;color:#64748b;margin:0;">
              Время отправки: ${new Date().toISOString()}
            </p>
          </td>
        </tr>
        <tr>
          <td style="padding:16px 28px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:12px;color:#94a3b8;line-height:1.5;">
            Это тестовое письмо. Re-engagement cron: <code>scripts/cron-email-reengagement.js</code>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

  const text = 'Тестовое письмо BizON. Если вы его получили — SMTP работает корректно.';

  // Если SMTP не задан — dev-stub
  if (!host || !port || !user || !password || !from) {
    console.log('⚠️  SMTP не настроен — режим dev-заглушки (письмо НЕ отправлено).');
    console.log('   Чтобы реально отправить письмо, задайте все 5 переменных:');
    console.log('   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM');
    console.log('');
    console.log('--- Письмо (preview) ---');
    console.log(`Subject: BizON — тестовое письмо`);
    console.log(`To: ${EMAIL}`);
    console.log(text);
    process.exit(0);
  }

  // Реальная отправка
  try {
    const transporter = nodemailer.createTransport({
      host,
      port: Number(port),
      secure: Number(port) === 465,
      auth: { user, pass: password },
    });

    console.log('Отправка...');
    const info = await transporter.sendMail({
      from,
      to: EMAIL,
      subject: 'BizON — тестовое письмо',
      html,
      text,
    });
    console.log('\n✅ Письмо отправлено!');
    console.log(`   Message-ID: ${info.messageId}`);
    console.log(`   Response: ${info.response}`);
    process.exit(0);
  } catch (e) {
    console.error('\n❌ Ошибка отправки:', e?.message ?? e);
    if (e?.code) console.error('   Code:', e.code);
    process.exit(1);
  }
})();
