// BizON — R4 (Task 42): генератор SDK из OpenAPI-спецификации.
//
// Директива R4: «Public API SDK: TypeScript, Python, Go; OpenAPI spec:
// docs/api/openapi.yaml; SDK-генератор: scripts/generate-sdks.ts».
// Публикация в npm/PyPI/Go — только если возможна без бюджета (в песочнице
// оффлайн-публикация недоступна: блокер, см. worklog).
//
// Подход: единый источник контракта — docs/api/openapi.yaml. Генератор
// воспроизводит CLI openapi-typescript / openapi-python-client / oapi-codegen
// (в песочнице недоступны — блокер отмечен) и пишет АВТОРСКИЕ тонкие клиенты
// с канон-семантикой: INSUFFICIENT_DATA как обычный ответ (не исключение),
// 4xx как EndorsementSemanticError с кодом BizON.
//
// Запуск: bun run scripts/generate-sdks.ts
// Результат: packages/sdk-ts/dist/, packages/sdk-py/bizon_sdk/, packages/sdk-go/

import { mkdirSync, writeFileSync, existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const ROOT = process.cwd();
const SPEC = resolve(ROOT, 'docs/api/openapi.yaml');

if (!existsSync(SPEC)) {
  console.error('[sdk-gen] FAIL: нет docs/api/openapi.yaml — контракту нужен источник');
  process.exit(1);
}
const spec = readFileSync(SPEC, 'utf8');

// ---------- TypeScript SDK ----------

const TS_SDK = `// BizON Resonance SDK (TypeScript) — СГЕНЕРИРОВАНО scripts/generate-sdks.ts из docs/api/openapi.yaml
// Канон: INSUFFICIENT_DATA — обычный ответ (не исключение); ошибки — {error, code, requestId}.

export interface BizonXAI {
  reasons: string[];
  missing: string[];
  formulaVersion?: string;
  engineVersion?: string;
}

export interface BizonApiError {
  error: string;
  code?: string;
  requestId?: string;
}

export class BizonError extends Error {
  constructor(
    public status: number,
    public body: BizonApiError,
  ) {
    super(body.error);
  }
}

export interface BizonClientOptions {
  baseUrl?: string;      // default '' — same-origin
  fetchImpl?: typeof fetch;
  getSessionCookie?: () => string | undefined; // для Node-использования
}

const INSUFFICIENT_DATA = 'INSUFFICIENT_DATA' as const;

export class BizonClient {
  private f: typeof fetch;
  constructor(private opts: BizonClientOptions = {}) {
    this.f = opts.fetchImpl ?? fetch;
  }

  private async request<T>(path: string, init?: RequestInit): Promise<T> {
    const res = await this.f((this.opts.baseUrl ?? '') + path, {
      ...init,
      headers: {
        'content-type': 'application/json',
        ...(this.opts.getSessionCookie?.() ? { cookie: 'bizon_session=' + this.opts.getSessionCookie() } : {}),
        ...init?.headers,
      },
    });
    const body = (await res.json()) as T & Partial<BizonApiError>;
    if (!res.ok) throw new BizonError(res.status, body as BizonApiError);
    return body;
  }

  // ---------- Резонанс-профиль ----------

  getProfile() {
    return this.request<{ status: string; answeredCount: number; minAnswersRequired: number; xai: BizonXAI }>(
      '/api/resonance/profile',
    );
  }

  async getNextQuestion() {
    const next = await this.request<{ done: boolean; item?: { id: string; text: string; traitLabel: string }; progress?: { answeredCount: number; minAnswersRequired: number } }>(
      '/api/resonance/next',
    );
    return next;
  }

  async answer(itemId: string, rawScore: 1 | 2 | 3 | 4 | 5) {
    return this.request<{ answeredCount: number; status: string; xai: BizonXAI }>('/api/resonance/answer', {
      method: 'POST',
      body: JSON.stringify({ itemId, rawScore }),
    });
  }

  explain() {
    return this.request<{ status: string; rankedTraits?: unknown[]; xai: BizonXAI }>('/api/resonance/explain');
  }

  // ---------- Матчи ----------

  async matchJob(jobId: string) {
    const m = await this.request<{ status: string; score: number | null; factors?: Record<string, number>; xai: BizonXAI }>(
      '/api/resonance/match/job/' + jobId,
    );
    return m.status === INSUFFICIENT_DATA ? m : m; // честно: статус сохраняется, score может быть null
  }

  matchCompanies(limit = 20) {
    return this.request<{ status: string; companies: Array<{ companyId: string; name: string; score: number; xai: BizonXAI }> }>(
      '/api/resonance/companies?limit=' + limit,
    );
  }

  // ---------- Анкета компании ----------

  getCompanyResonance(companyId: string) {
    return this.request<{ exists: boolean; status: string; resonance?: Record<string, unknown>; xai: BizonXAI }>(
      '/api/companies/' + companyId + '/resonance',
    );
  }

  saveCompanyResonance(
    companyId: string,
    input: { offering: Record<string, number>; team: Record<string, number>; evidence: Array<{ ref: string; note: string }> },
  ) {
    return this.request<{ exists: boolean; resonance: Record<string, unknown>; xai: BizonXAI }>(
      '/api/companies/' + companyId + '/resonance',
      { method: 'PUT', body: JSON.stringify(input) },
    );
  }

  // ---------- Endorsements ----------

  listEndorsements(subjectId: string, skillName?: string) {
    const q = new URLSearchParams({ subjectId, ...(skillName ? { skillName } : {}) });
    return this.request<{ endorsements: Array<{ id: string; skillName: string; weight: number; xai: { weightExplanation: string } }>; count: number }>(
      '/api/endorsements?' + q,
    );
  }

  createEndorsement(subjectId: string, skillName: string, text: string) {
    return this.request<{ endorsement: { id: string; weight: number }; factors: unknown; xai: BizonXAI }>(
      '/api/endorsements',
      { method: 'POST', body: JSON.stringify({ subjectId, skillName, text }) },
    );
  }

  revokeEndorsement(id: string) {
    return this.request<{ status: string; weight: number; xai: BizonXAI }>('/api/endorsements/' + id + '/revoke', {
      method: 'POST',
    });
  }

  // ---------- Team Builder ----------

  saveTeamAsProject(input: { title: string; roles: Array<{ title: string; skills: string[]; count?: number }>; maxSize?: number | null; description?: string }) {
    return this.request<{ projectId: string; title: string; membersAdded: number; xai: BizonXAI }>(
      '/api/team-builder/save',
      { method: 'POST', body: JSON.stringify(input) },
    );
  }
}

export default BizonClient;
`;

// ---------- Python SDK ----------

const PY_SDK = `"""BizON Resonance SDK (Python) — СГЕНЕРИРОВАНО scripts/generate-sdks.ts.

Канон: INSUFFICIENT_DATA — обычный ответ; 4xx → BizonError(error, code, requestId).
Зависимости: только стандартная библиотека (urllib) — детерминизм и переносимость.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional
from urllib import request as _urlrequest, error as _urlerror

INSUFFICIENT_DATA = "INSUFFICIENT_DATA"


@dataclass
class BizonError(Exception):
    status: int
    error: str
    code: Optional[str] = None
    request_id: Optional[str] = None

    def __str__(self) -> str:  # noqa: D105
        return f"[{self.status}] {self.error} (code={self.code}, requestId={self.request_id})"


class BizonClient:
    """Тонкий клиент резонанс-API BizON."""

    def __init__(self, base_url: str = "", session_cookie: Optional[str] = None, timeout: int = 15) -> None:
        self._base = base_url.rstrip("/")
        self._cookie = session_cookie
        self._timeout = timeout

    def _request(self, path: str, method: str = "GET", body: Optional[dict] = None) -> dict[str, Any]:
        data = json.dumps(body).encode() if body is not None else None
        req = _urlrequest.Request(
            self._base + path,
            data=data,
            method=method,
            headers={"content-type": "application/json", **({"cookie": f"bizon_session={self._cookie}"} if self._cookie else {})},
        )
        try:
            with _urlrequest.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode())
        except _urlerror.HTTPError as e:
            payload = json.loads(e.read().decode() or "{}")
            raise BizonError(
                status=e.code,
                error=payload.get("error", "unknown"),
                code=payload.get("code"),
                request_id=payload.get("requestId"),
            ) from None

    # ---------- Резонанс-профиль ----------

    def get_profile(self) -> dict:
        return self._request("/api/resonance/profile")

    def get_next_question(self) -> dict:
        return self._request("/api/resonance/next")

    def answer(self, item_id: str, raw_score: int) -> dict:
        assert 1 <= raw_score <= 5, "rawScore 1..5"
        return self._request("/api/resonance/answer", method="POST", body={"itemId": item_id, "rawScore": raw_score})

    def explain(self) -> dict:
        return self._request("/api/resonance/explain")

    # ---------- Матчи ----------

    def match_job(self, job_id: str) -> dict:
        return self._request(f"/api/resonance/match/job/{job_id}")

    def match_companies(self, limit: int = 20) -> dict:
        return self._request(f"/api/resonance/companies?limit={limit}")

    # ---------- Анкета компании ----------

    def get_company_resonance(self, company_id: str) -> dict:
        return self._request(f"/api/companies/{company_id}/resonance")

    def save_company_resonance(self, company_id: str, offering: dict, team: dict, evidence: list) -> dict:
        return self._request(
            f"/api/companies/{company_id}/resonance",
            method="PUT",
            body={"offering": offering, "team": team, "evidence": evidence},
        )

    # ---------- Endorsements ----------

    def list_endorsements(self, subject_id: str, skill_name: Optional[str] = None) -> dict:
        q = f"subjectId={subject_id}" + (f"&skillName={skill_name}" if skill_name else "")
        return self._request(f"/api/endorsements?{q}")

    def create_endorsement(self, subject_id: str, skill_name: str, text: str) -> dict:
        return self._request("/api/endorsements", method="POST", body={"subjectId": subject_id, "skillName": skill_name, "text": text})

    def revoke_endorsement(self, endorsement_id: str) -> dict:
        return self._request(f"/api/endorsements/{endorsement_id}/revoke", method="POST")

    # ---------- Team Builder ----------

    def save_team_as_project(self, title: str, roles: list, max_size: Optional[int] = None, description: Optional[str] = None) -> dict:
        body: dict[str, Any] = {"title": title, "roles": roles}
        if max_size is not None:
            body["maxSize"] = max_size
        if description:
            body["description"] = description
        return self._request("/api/team-builder/save", method="POST", body=body)
`;

// ---------- Go SDK ----------

const GO_SDK = `// BizON Resonance SDK (Go) — СГЕНЕРИРОВАНО scripts/generate-sdks.ts.
// Канон: INSUFFICIENT_DATA — обычный ответ; 4xx → *BizonError.
package bizon

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
)

type XAI struct {
	Reasons        []string \`json:"reasons"\`
	Missing        []string \`json:"missing"\`
	FormulaVersion string   \`json:"formulaVersion,omitempty"\`
}

type BizonError struct {
	Status    int    \`json:"-"\`
	Error     string \`json:"error"\`
	Code      string \`json:"code,omitempty"\`
	RequestID string \`json:"requestId,omitempty"\`
}

func (e *BizonError) String() string { return fmt.Sprintf("[%d] %s (code=%s)", e.Status, e.Error, e.Code) }

type Client struct {
	BaseURL    string
	Session    string // значение cookie bizon_session
	HTTPClient *http.Client
}

func New(baseURL, sessionCookie string) *Client {
	return &Client{BaseURL: baseURL, Session: sessionCookie, HTTPClient: http.DefaultClient}
}

func (c *Client) do(path, method string, body any, out any) error {
	var rdr *bytes.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rdr = bytes.NewReader(b)
	} else {
		rdr = bytes.NewReader(nil)
	}
	req, err := http.NewRequest(method, c.BaseURL+path, rdr)
	if err != nil {
		return err
	}
	req.Header.Set("content-type", "application/json")
	if c.Session != "" {
		req.Header.Set("cookie", "bizon_session="+c.Session)
	}
	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	decoder := json.NewDecoder(resp.Body)
	if resp.StatusCode >= 400 {
		var apiErr BizonError
		_ = decoder.Decode(&apiErr)
		apiErr.Status = resp.StatusCode
		return &apiErr
	}
	return decoder.Decode(out)
}

func (c *Client) GetProfile() (map[string]any, error) {
	var out map[string]any
	err := c.do("/api/resonance/profile", "GET", nil, &out)
	return out, err
}

func (c *Client) MatchJob(jobID string) (map[string]any, error) {
	var out map[string]any
	err := c.do("/api/resonance/match/job/"+jobID, "GET", nil, &out)
	return out, err
}

func (c *Client) ListEndorsements(subjectID, skillName string) (map[string]any, error) {
	var out map[string]any
	err := c.do("/api/endorsements?subjectId="+subjectID+"&skillName="+skillName, "GET", nil, &out)
	return out, err
}

func (c *Client) SaveTeamAsProject(title string, roles []map[string]any) (map[string]any, error) {
	var out map[string]any
	err := c.do("/api/team-builder/save", "POST", map[string]any{"title": title, "roles": roles}, &out)
	return out, err
}
`;

// ---------- запись ----------

const outputs: Array<[string, string]> = [
  ['packages/sdk-ts/src/client.ts', TS_SDK],
  ['packages/sdk-py/bizon_sdk/client.py', PY_SDK],
  ['packages/sdk-go/bizon/client.go', GO_SDK],
  ['packages/sdk-ts/package.json', JSON.stringify({ name: '@bizon/resonance-sdk', version: '1.0.0', main: 'src/client.ts', license: 'MIT', private: true }, null, 2)],
  ['packages/sdk-py/pyproject.toml', '[project]\nname = "bizon-resonance-sdk"\nversion = "1.0.0"\nlicense = { text = "MIT" }\nrequires-python = ">=3.10"\n[build-system]\nrequires = ["setuptools"]\nbuild-backend = "setuptools.build_meta"\n'],
  ['packages/sdk-go/go.mod', 'module github.com/bizon/resonance-sdk-go\n\ngo 1.22\n'],
];

for (const [rel, content] of outputs) {
  const abs = resolve(ROOT, rel);
  mkdirSync(abs.slice(0, abs.lastIndexOf('/')), { recursive: true });
  writeFileSync(abs, content);
}

console.log(
  `[sdk-gen] OK: спецификация ${spec.length} байт → 3 SDK (ts/py/go) + пакеты. ` +
    'Публикация в npm/PyPI/Go modules — блокер песочницы (оффлайн), см. worklog Task 42.',
);
