// =============================================================================
// CLI: ПРОВЕРКА ИНТЕГРАЦИИ (П4 Фаза 1, п.1.4 директивы).
//
// Аргумент: код порта ('yookassa-ru') или INT-id манифеста ('INT-022').
// Проверки: порт в реестре → манифест-запись → факты env (имена, без значений)
// → адаптер реализован → adapter.test(). Exit 0 — READY, exit 1 — нет.
//
// Запуск: bun scripts/verify-integration.ts <code|INT-id>
// =============================================================================
import { db } from '../src/lib/db';
import { loadManifest } from '../src/lib/hubs/manifest';
import { isHubCategory, requiredEnvStatus } from '../src/lib/hubs/core';
import { HUB_REGISTRY, adapterFor } from '../src/lib/hubs/registry';

interface TestableAdapter {
  test(): Promise<{ ok: boolean; detail: string }>;
}

async function main() {
  const arg = process.argv[2]?.trim();
  if (!arg) {
    console.error('Использование: bun scripts/verify-integration.ts <code|INT-id>   (например: yookassa-ru | INT-022)');
    process.exit(1);
  }

  const manifest = loadManifest();
  const byId = manifest.integrations.find((e) => e.id.toUpperCase() === arg.toUpperCase());
  const code = byId ? byId.port_code : arg.toLowerCase();

  const port = await db.externalServicePort.findUnique({ where: { code } });
  if (!port) {
    console.error(`[verify] 404: порт «${code}» не найден в реестре ExternalServicePort`);
    process.exit(1);
  }
  if (!isHubCategory(port.category)) {
    console.error(`[verify] категория «${port.category}» вне реестра хабов`);
    process.exit(1);
  }

  const entry = manifest.integrations.find((e) => e.port_code === code);
  console.log(`[verify] ${code} (${port.provider}) · категория ${port.category}${entry ? ` · ${entry.id} «${entry.name}» · приоритет: ${entry.priority}` : ' · манифест-запись не найдена'}`);
  console.log(`[verify] kind=${port.kind} mode=${port.mode} isActive=${port.isActive}`);

  const envStatus = requiredEnvStatus(HUB_REGISTRY[port.category].requiredEnv(port));
  const missing = envStatus.filter((e) => !e.configured);
  console.log(`[verify] env: ${envStatus.length === 0 ? 'не требуются' : missing.length === 0 ? 'все заданы ✓' : `НЕ заданы: ${missing.map((e) => e.name).join(', ')}`}`);

  const adapter = adapterFor(port.category, port) as TestableAdapter | null;
  if (!adapter || typeof adapter.test !== 'function') {
    console.error(`[verify] адаптер: НЕ РЕАЛИЗОВАН — активация заблокирована (подключение = файл в src/lib/hubs/${port.category}/adapters/, ADR-007)`);
    process.exit(1);
  }
  console.log('[verify] адаптер: реализован ✓ — запуск self-test()…');

  let result: { ok: boolean; detail: string };
  try {
    result = await adapter.test();
  } catch (e) {
    console.error(`[verify] test() упал: ${e instanceof Error ? e.message.slice(0, 200) : String(e)}`);
    process.exit(1);
  }

  console.log(`[verify] test(): ${result.ok ? 'PASS' : 'FAIL'} — ${result.detail}`);
  if (entry) {
    console.log(`[verify] процедура активации: ${entry.activation}`);
    console.log(`[verify] проверка после активации: ${entry.verification}`);
  }
  await db.$disconnect();
  process.exit(result.ok && missing.length === 0 ? 0 : 1);
}

main();
