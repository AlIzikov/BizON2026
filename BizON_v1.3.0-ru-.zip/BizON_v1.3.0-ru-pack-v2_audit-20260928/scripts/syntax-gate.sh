#!/usr/bin/env bash
# BizON синтаксис-гейт — Wave-7 гигиена конвейера (урок RangeError -23: битый JSX
# маскировался крашем форматтера Next.js и блокировал весь app).
# Usage: bash scripts/syntax-gate.sh <изменённые файлы...>   (после КАЖДОЙ партии правок)
# Проверяет: 1) ESLint по файлам (parse-ошибки мгновенно); 2) tsc --noEmit по временному
# скоупу. FAIL только если ошибки в ПЕРЕЧИСЛЕННЫХ файлах (pre-existing в транзитивных
# импортах — базлайн, не блокирует; см. company-passport-service.ts).
set -u
[ $# -eq 0 ] && { echo "usage: syntax-gate.sh <files...>"; exit 2; }
cd "$(dirname "$0")/.."
abs_files=()
for f in "$@"; do
  case "$f" in /*) abs_files+=("$f");; *) abs_files+=("$PWD/${f#./}");; esac
done
fail=0

echo "== syntax-gate: ESLint (${#abs_files[@]} files) =="
if ! bunx eslint "${abs_files[@]}"; then
  echo "syntax-gate: ESLint FAIL"
  fail=1
fi

echo "== syntax-gate: tsc по скоупу =="
tsconfig=$(mktemp /tmp/bizon-gate-XXXXXX.json)
{
  printf '{ "extends": "%s/tsconfig.json", "include": [' "$PWD"
  first=1
  for f in "${abs_files[@]}"; do
    [ $first -eq 1 ] || printf ','
    printf '"%s"' "$f"
    first=0
  done
  printf '] }'
} > "$tsconfig"
tsc_out=$(mktemp /tmp/bizon-gate-out-XXXXXX.txt)
if ! bunx tsc --noEmit -p "$tsconfig" > "$tsc_out" 2>&1; then
  # FAIL только для перечисленных файлов; ошибки в прочих (транзитивных) — базлайн
  scope_fail=0
  for f in "${abs_files[@]}"; do
    if grep -q "^${f}(" "$tsc_out"; then
      echo "syntax-gate: ошибка в своём файле: ${f#$PWD/}"
      grep "^${f}(" "$tsc_out" | head -5
      scope_fail=1
    fi
  done
  [ $scope_fail -eq 1 ] && fail=1
fi
rm -f "$tsconfig" "$tsc_out"

if [ $fail -eq 0 ]; then
  echo "syntax-gate: PASS (${#abs_files[@]} files)"
else
  echo "syntax-gate: FAIL — чини до следующего шага"
  exit 1
fi
