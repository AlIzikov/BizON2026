// REC-DOC-01: автоматическая проверка соответствия каталога документации коду.
// Падает, если числа моделей/роутов расходятся со снапшотом релиза
// (docs/audits/catalog-snapshot.json). Снапшот генерируется: bun scripts/check-audit-catalog.mjs --update
// Использование: bun scripts/check-audit-catalog.mjs [--update]
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const schema = fs.readFileSync(path.join(root, 'prisma/schema.prisma'), 'utf8');
const models = [...schema.matchAll(/^model\s+(\w+)/gm)].map((m) => m[1]);

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const name of fs.readdirSync(dir)) {
    const p = path.join(dir, name);
    const s = fs.statSync(p);
    if (s.isDirectory()) walk(p, out);
    else out.push(p);
  }
  return out;
}
const routes = walk(path.join(root, 'src/app/api')).filter((p) => p.endsWith('route.ts'));

const snapshotPath = path.join(root, 'docs/audits/catalog-snapshot.json');

if (process.argv.includes('--update')) {
  fs.mkdirSync(path.dirname(snapshotPath), { recursive: true });
  fs.writeFileSync(
    snapshotPath,
    JSON.stringify({ models: models.length, modelsList: models, routes: routes.length, generatedAt: new Date().toISOString() }, null, 2),
  );
  console.log(`Снапшот обновлён: ${models.length} моделей, ${routes.length} роутов → ${snapshotPath}`);
  process.exit(0);
}

if (!fs.existsSync(snapshotPath)) {
  console.error(`Снапшот не найден: ${snapshotPath}. Сгенерируйте: bun scripts/check-audit-catalog.mjs --update`);
  process.exit(1);
}
const snap = JSON.parse(fs.readFileSync(snapshotPath, 'utf8'));
const errors = [];
if (snap.models !== models.length) {
  errors.push(`Prisma models: в снапшоте ${snap.models}, фактически ${models.length}. Обновите снапшот (--update) и документацию.`);
}
if (snap.routes !== routes.length) {
  errors.push(`API routes: в снапшоте ${snap.routes}, фактически ${routes.length}. Обновите снапшот (--update) и документацию.`);
}
if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}
console.log(`OK: ${models.length} моделей, ${routes.length} роутов — соответствует снапшоту`);
