// R5.5 (находка верификации) — ремонт hash-chain журнала AuditLog.
//
// КОНТЕКСТ: при верификации R5.5 обнаружен разрыв цепочки в dev-БД
// (строка login 2026-09-26T22:24:35.137Z): два процесса (dev-сервер и
// bun-тест) читали один tail цепочки и писали параллельно — гонка
// read-modify-write. Корневой фикс уже внесён в src/lib/data-vault/
// audit-log.ts (flushUnlocked обёрнут в db.$transaction — SQLite
// сериализует межпроцессуально). Этот скрипт — ОДНОРАЗОВАЯ
// документированная «хирургия» существующей цепочки:
//
//   1. Верифицирует цепочку от GENESIS, находит ПЕРВЫЙ разрыв.
//   2. Дописывает запись 'audit_chain.repaired' (вставляется ХРОНОЛОГИЧЕСКИ
//      в промежуток между последней целой строкой и первой битой — факт
//      о ремонте предшествует пересшивке; содержимое метки: причина, точка
//      разрыва, число перешитых строк).
//   3. Пересчитывает chainHash всех строк от разрыва до конца (v2-формула).
//      Содержимое строк и их createdAt НЕ меняются — меняется только
//      «сшивка» prevHash, утраченная в гонке.
//
// Прозрачность: разрыв и ремонт видны в AuditLog навсегда (action
// 'audit_chain.repaired'); ретроспективная подмена СОДЕРЖИМОГО строк
// по-прежнему детектируется (tamper-evidence сохранён). Владелец
// уведомлён в отчёте R5.5.
//
// Запуск: bun scripts/repair-audit-chain.ts [--dry]
import { PrismaClient } from '@prisma/client';
import { createHash } from 'node:crypto';

const db = new PrismaClient();
const DRY = process.argv.includes('--dry');

const V2_PREFIX = 'v2:';
const REPAIR_ACTION = 'audit_chain.repaired';

/**
 * v2-формула из audit-log.ts (CRYPTO-012): SHA256 от канонического JSON
 * { prevHash, actorId, action, resource, resourceId, metadata, createdAt }.
 */
function expectedChainHashV2(
  prevHash: string,
  row: {
    actorId: string;
    action: string;
    resource: string;
    resourceId: string | null;
    metadata: string | null;
    createdAt: Date;
  },
): string {
  const payload = {
    prevHash,
    actorId: row.actorId,
    action: row.action,
    resource: row.resource,
    resourceId: row.resourceId ?? '',
    metadata: row.metadata ?? '',
    createdAt: row.createdAt.toISOString(),
  };
  const canonical = canonicalize(payload);
  return V2_PREFIX + createHash('sha256').update(canonical).digest('hex');
}

/** Канонизация JSON (сортировка ключей, рекурсивно) — паритет canonical-json.ts. */
function canonicalize(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(',')}]`;
  const entries = Object.entries(value as Record<string, unknown>).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalize(v)}`).join(',')}}`;
}

interface Row {
  id: string;
  actorId: string;
  action: string;
  resource: string;
  resourceId: string | null;
  metadata: string | null;
  createdAt: Date;
  chainHash: string;
}

async function main() {
  const rows: Row[] = await db.auditLog.findMany({
    where: { chainHash: { not: null } },
    orderBy: { createdAt: 'asc' },
  });
  console.log(`audit chain rows: ${rows.length}`);

  // --- 1. Первый разрыв ---
  let prevHash = 'GENESIS';
  let breakAt = -1;
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i]!;
    const expected = expectedChainHashV2(prevHash, r);
    if (expected !== r.chainHash) {
      breakAt = i;
      break;
    }
    prevHash = r.chainHash!;
  }
  if (breakAt === -1) {
    console.log('Цепочка целостна — ремонт не требуется.');
    process.exit(0);
  }
  const broken = rows[breakAt]!;
  const lastGoodHash = breakAt === 0 ? 'GENESIS' : rows[breakAt - 1]!.chainHash!;
  const lastGoodTs = breakAt === 0 ? 0 : rows[breakAt - 1]!.createdAt.getTime();
  console.log(`разрыв: #${breakAt} id=${broken.id} action=${broken.action} createdAt=${broken.createdAt.toISOString()}`);

  const rowsToRehash = rows.slice(breakAt);

  // --- 2. Запись-факт о ремонте ---
  const repairMeta = canonicalize({
    marker: 'audit-chain-repair-r55',
    reason: 'cross-process read-modify-write race (dev server + bun test); root fix: transactional flushUnlocked in audit-log.ts',
    breakAtId: broken.id,
    breakAtAction: broken.action,
    breakAtCreatedAt: broken.createdAt.toISOString(),
    rowsRehashed: rowsToRehash.length,
    repairedBy: 'scripts/repair-audit-chain.ts (R5.5; владелец уведомлён в отчёте)',
  });

  // Хронология: запись встаёт между lastGood и первой битой строкой.
  // Если промежуток < 2мс — невозможно; тогда честно падаем (оператор
  // принимает решение вручную; автозамена истории не делаем).
  const gapHigh = broken.createdAt.getTime();
  if (gapHigh - lastGoodTs < 2) {
    console.error('Промежуток между последней целой и первой битой строкой < 2мс — вставка записи о ремонте невозможна. Авто-ремонт отменён (история не тронута).');
    process.exit(1);
  }
  const repairTs = gapHigh - 1;
  const repairRow = {
    actorId: 'system',
    action: REPAIR_ACTION,
    resource: 'audit_log',
    resourceId: broken.id,
    metadata: repairMeta,
    createdAt: new Date(repairTs),
  };
  const repairHash = expectedChainHashV2(lastGoodHash, repairRow);
  console.log(`запись о ремонте: ts=${repairRow.createdAt.toISOString()} (вставляется в разрыв)`);

  if (DRY) {
    console.log(`--dry: было бы перешито ${rowsToRehash.length} строк после записи о ремонте.`);
    process.exit(0);
  }

  // --- 3. Пересшивка: [repairRow, ...rowsToRehash] по createdAt asc ---
  await db.auditLog.create({
    data: {
      actorId: repairRow.actorId,
      action: repairRow.action,
      resource: repairRow.resource,
      resourceId: repairRow.resourceId,
      metadata: repairRow.metadata,
      createdAt: repairRow.createdAt,
      chainHash: repairHash,
    },
  });

  let prev = repairHash;
  let rehashed = 0;
  for (const r of rowsToRehash) {
    const h = expectedChainHashV2(prev, r);
    if (h !== r.chainHash) {
      await db.auditLog.update({ where: { id: r.id }, data: { chainHash: h } });
      rehashed += 1;
    }
    prev = h;
  }
  console.log(`перешито строк: ${rehashed}`);

  // --- 4. Финальная верификация ---
  const check: Row[] = await db.auditLog.findMany({
    where: { chainHash: { not: null } },
    orderBy: { createdAt: 'asc' },
  });
  let p = 'GENESIS';
  for (const r of check) {
    const h = expectedChainHashV2(p, r);
    if (h !== r.chainHash) {
      console.error(`ПОСЛЕ РЕМОНТА РАЗРЫВ: id=${r.id} action=${r.action}`);
      process.exit(1);
    }
    p = h;
  }
  console.log(`верификация после ремонта: OK (${check.length} строк, цепочка целостна).`);
  process.exit(0);
}

main()
  .then(() => db.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await db.$disconnect();
    process.exit(1);
  });
