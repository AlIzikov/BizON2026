#!/usr/bin/env node
// W2.5 (DEF-16) — кодмод: обёртка mutation-роутов в withRoute.
// Безопасная стратегия: тело обработчика НЕ трогается. Только:
//   1. `export async function POST(req: NextRequest, ctx: { params: Promise<...> })`
//      → `async function __bizon_impl_POST(req: Request, ctx: { params: <resolved> })`
//   2. В конец файла: `export const POST = withRoute(__bizon_impl_POST, { rateLimit })`
//      (function declarations hoisted — порядок не важен)
//   3. `req.nextUrl.searchParams` → `new URL(req.url).searchParams`
//   4. Импорт withRoute из '@/lib/api-helpers'
import { readFileSync, writeFileSync } from 'node:fs';
import { relative } from 'node:path';

const FILES = readFileSync('/tmp/codemod-files.txt', 'utf8')
  .split('\n')
  .map((s) => s.trim())
  .filter(Boolean);

const MUTATION_RE =
  /^export async function (POST|PATCH|PUT|DELETE)\s*\((.+?)\)\s*(?::[^{]+)?\{\s*$/;
const HELPERS_IMPORT_RE =
  /import\s*\{([^}]*)\}\s*from\s*'@\/lib\/api-helpers';/;

let okCount = 0;
const failures = [];

for (const file of FILES) {
  const src = readFileSync(file, 'utf8');
  const lines = src.split('\n');
  const out = [];
  const wrappers = [];
  let changed = false;

  for (const line of lines) {
    const m = line.match(MUTATION_RE);
    if (!m) {
      out.push(line);
      continue;
    }
    const method = m[1];
    const paramsRaw = m[2];
    // парсим параметры: req + опциональный ctx
    // варианты: "req: NextRequest" | "req: Request" | "_req: NextRequest"
    //           + ", ctx: { params: Promise<{ id: string }> }"
    //           + ", { params }: { params: Promise<{ id: string }> }"
    const parts = paramsRaw.split(',').map((s) => s.trim());
    if (parts.length < 1 || !/^[A-Za-z_$][\w$]*\s*:\s*(NextRequest|Request)$/.test(parts[0])) {
      failures.push([file, `params unparsable: ${paramsRaw}`]);
      out.push(line);
      continue;
    }
    const reqName = parts[0].split(':')[0].trim();
    let paramsType = null;
    let ctxDecl = '';
    if (parts.length === 2) {
      const pm = parts[1].match(/^(?:ctx|_ctx)\s*:\s*\{\s*params\s*:\s*Promise<\{(.+)\}>\s*\}$/);
      const dm = parts[1].match(/^\{\s*params\s*\}\s*:\s*\{\s*params\s*:\s*Promise<\{(.+)\}>\s*\}$/);
      if (pm) {
        paramsType = pm[1];
        ctxDecl = `ctx: { params: { ${paramsType} } }`;
      } else if (dm) {
        paramsType = dm[1];
        ctxDecl = `{ params }: { params: { ${paramsType} } }`;
      } else {
        failures.push([file, `ctx unparsable: ${parts[1]}`]);
        out.push(line);
        continue;
      }
    } else if (parts.length > 2) {
      failures.push([file, `too many params: ${paramsRaw}`]);
      out.push(line);
      continue;
    }

    const implName = `__bizon_impl_${method.toLowerCase()}`;
    const newDecl = ctxDecl
      ? `async function ${implName}(${reqName}: Request, ${ctxDecl}) {`
      : `async function ${implName}(${reqName}: Request) {`;
    out.push(newDecl);

    const generic = paramsType ? `withRoute<{ ${paramsType} }>` : 'withRoute';
    // rate-key: путь роута без src/app/api и /route.ts
    const routePath = relative('src/app/api', file).replace(/\/route\.ts$/, '');
    wrappers.push(
      `// DEF-16 (FIX-07): withRoute — auth 401, malformed JSON → 400, P2002 → 409, safe 500 + H11 лимит 60/мин.`,
      `export const ${method} = ${generic}(${implName}, {`,
      `  rateLimit: { key: 'api:${routePath}:${method}', limit: 60, windowMs: 60_000 },`,
      `});`
    );
    changed = true;
  }

  if (!changed) {
    failures.push([file, 'no mutation methods matched']);
    continue;
  }

  let result = out.join('\n');

  // nextUrl → URL(req.url)
  result = result.replace(/req\.nextUrl\.searchParams/g, 'new URL(req.url).searchParams');

  // импорт withRoute
  if (HELPERS_IMPORT_RE.test(result)) {
    result = result.replace(HELPERS_IMPORT_RE, (full, names) => {
      if (names.includes('withRoute')) return full;
      return `import {${names.replace(/,\s*$/, '')}, withRoute } from '@/lib/api-helpers';`;
    });
  } else {
    // вставляем новый импорт после последнего import
    const idx = result.lastIndexOf('\nimport ');
    if (idx === -1) {
      failures.push([file, 'no import section found']);
      continue;
    }
    const lineEnd = result.indexOf('\n', idx + 1);
    result =
      result.slice(0, lineEnd + 1) +
      "import { withRoute } from '@/lib/api-helpers';\n" +
      result.slice(lineEnd + 1);
  }

  result += '\n\n' + wrappers.join('\n') + '\n';
  writeFileSync(file, result);
  okCount += 1;
  console.log(`OK ${file}`);
}

console.log(`\nCodemod done: ${okCount} files patched, ${failures.length} failures`);
for (const [f, r] of failures) console.log(`FAIL ${f}: ${r}`);
