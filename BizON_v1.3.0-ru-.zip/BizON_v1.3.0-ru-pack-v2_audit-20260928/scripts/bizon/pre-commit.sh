#!/bin/bash
# BizON — pre-commit hook: обнаружение секретов в коде
# H9: защита от случайного коммита секретов (API keys, пароли, токены)
#
# Установка: ln -sf ../../scripts/pre-commit.sh .git/hooks/pre-commit
#            chmod +x scripts/pre-commit.sh

set -e

echo "🔍 BizON pre-commit: проверка на секреты..."

# Паттерны секретов (regex)
PATTERNS=(
  # API keys (общие)
  '[sS][kK]-[a-zA-Z0-9]{20,}'
  # AWS keys
  'AKIA[0-9A-Z]{16}'
  'aws_secret_access_key.*=.*[a-zA-Z0-9/+=]{40}'
  # Google API keys
  'AIza[0-9a-zA-Z_-]{35}'
  # GitHub tokens
  'gh[pousr]_[A-Za-z0-9_]{36,}'
  # JWT secrets (явные)
  'JWT_SECRET.*=.*[a-zA-Z0-9]{16,}'
  # BIZON_ENCRYPTION_KEY с реальным значением (64 hex)
  'BIZON_ENCRYPTION_KEY=[0-9a-f]{64}'
  # Общие password/secret с реальными значениями
  'password.*=.*["\x27][^"\x27]{8,}["\x27]'
  # Private keys
  '-----BEGIN [A-Z ]*PRIVATE KEY-----'
  # Slack tokens
  'xox[baprs]-[0-9a-zA-Z-]{10,}'
)

# Файлы которые НЕ нужно проверять
SKIP_FILES=(
  'node_modules/'
  '.next/'
  'package-lock.json'
  'yarn.lock'
  '.env.example'      # пример — тут могут быть placeholder'ы
  'TASKS.md'          # может содержать упоминания секретов в документации
  'PRE-LAUNCH.md'
  'download/'         # отчёты аудита
  'scripts/pre-commit.sh'  # сам скрипт
  'tool-results/'
)

# Получаем staged файлы
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM | grep -v '\.lock$' || true)

if [ -z "$STAGED_FILES" ]; then
  echo "✅ Нет staged файлов для проверки"
  exit 0
fi

FOUND_SECRETS=0

for file in $STAGED_FILES; do
  # Проверка skip-списка
  skip=false
  for skip_pattern in "${SKIP_FILES[@]}"; do
    if [[ "$file" == *"$skip_pattern"* ]]; then
      skip=true
      break
    fi
  done
  if $skip; then continue; fi

  # Проверяем только текстовые файлы
  if ! file "$file" 2>/dev/null | grep -qi "text\|json\|javascript\|typescript\|yaml\|xml\|markdown"; then
    continue
  fi

  # Получаем staged содержимое файла
  content=$(git diff --cached -- "$file" 2>/dev/null || true)
  if [ -z "$content" ]; then continue; fi

  # Проверяем каждый паттерн
  for pattern in "${PATTERNS[@]}"; do
    if echo "$content" | grep -qE "$pattern"; then
      echo "❌ Возможный секрет найден в $file:"
      echo "   Паттерн: $pattern"
      echo "   Строка: $(echo "$content" | grep -E "$pattern" | head -1 | cut -c1-100)"
      FOUND_SECRETS=$((FOUND_SECRETS + 1))
    fi
  done
done

# Проверка что .env не добавлен в staged
if git diff --cached --name-only | grep -qE "^\.env$"; then
  echo "❌ .env файл добавлен в staged! Это файл с секретами — НЕ коммитить."
  echo "   .env должен быть в .gitignore и никогда не попадать в git."
  FOUND_SECRETS=$((FOUND_SECRETS + 1))
fi

if [ $FOUND_SECRETS -gt 0 ]; then
  echo ""
  echo "🚨 Найдено $FOUND_SECRETS проблем. Коммит отменён."
  echo ""
  echo "Если это false-positive (например, тестовые данные):"
  echo "  1. Убедитесь что реальный секрет не утёк"
  echo "  2. Закоммитьте с флагом: git commit --no-verify"
  echo ""
  exit 1
fi

echo "✅ Секретов не найдено. Коммит разрешён."
exit 0
