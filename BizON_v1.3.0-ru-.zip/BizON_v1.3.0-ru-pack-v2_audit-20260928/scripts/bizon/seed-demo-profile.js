// Доработка demo-пользователя: заполнить профиль реалистичными данными
const { PrismaClient } = require('@prisma/client');
const crypto = require('node:crypto');
const db = new PrismaClient();

async function main() {
  const user = await db.user.findFirst({ where: { email: 'demo@bizon.app' } });
  if (!user) {
    console.error('Demo user not found! Run create-demo-session.js first.');
    process.exit(1);
  }
  
  console.log('Updating demo user profile...');
  await db.user.update({
    where: { id: user.id },
    data: {
      name: 'Алексей Демидов',
      title: 'Senior Product Designer · ex-Yandex',
      bio: 'Дизайнер продуктов с 8-летним опытом. Запускал мобильные приложения для 5M+ пользователей. Сейчас строю карьеру в AI-продуктах.',
      location: 'Москва',
      ipScore: 87,
      level: 'Senior',
      roles: 'user',
      accountType: 'personal',
      isVerified: true,
      subscriptionTier: 'pro',
    }
  });
  
  // Создаём сессию (свежую)
  const existingSession = await db.session.findFirst({ where: { userId: user.id } });
  if (!existingSession) {
    const token = '8a4be271d397c02c84b17fe8d4edaa5a1d3fe9c60b9ad232c34459ad2900e758';
    const expiresAt = new Date(Date.now() + 24 * 7 * 60 * 60 * 1000);
    await db.session.create({ data: { userId: user.id, token, expiresAt } });
    console.log('Session created with token:', token);
  } else {
    // Обновляем token на нужный
    await db.session.update({
      where: { id: existingSession.id },
      data: { token: '8a4be271d397c02c84b17fe8d4edaa5a1d3fe9c60b9ad232c34459ad2900e758', expiresAt: new Date(Date.now() + 24 * 7 * 60 * 60 * 1000) }
    });
    console.log('Session updated');
  }
  
  console.log('Done');
  await db.$disconnect();
}

main().catch(e => { console.error(e); process.exit(1); });
