#!/bin/bash
# BizON preview watchdog — restarts server on crash
cd /home/z/my-project

while true; do
  set -a
  source .env 2>/dev/null
  set +a
  source bizon-config.env 2>/dev/null
  export NODE_ENV=production PORT=3000 HOSTNAME=127.0.0.1 NEXT_TELEMETRY_DISABLED=1
  echo "[$(date +%T)] Starting BizON server..." >> /tmp/bizon-preview.log
  node --trace-warnings .next/standalone/server.js >> /tmp/bizon-preview.log 2>&1
  EXIT_CODE=$?
  echo "[$(date +%T)] Server exited (code=$EXIT_CODE), restarting in 3s..." >> /tmp/bizon-preview.log
  sleep 3
done
