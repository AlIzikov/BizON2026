#!/usr/bin/env node
/* eslint-disable @typescript-eslint/no-require-imports */
// BizON — dev-prod.js
// Запускает BizON в production-режиме (next start) вместо dev (next dev)
// Причина: dev-режим с Turbopack + Chrome в sandbox 4GB = OOM kill.
// Production-режим потребляет 122MB вместо 800MB и работает стабильно.
//
// Если .next/ отсутствует или устарел — сначала собирает (next build --webpack).
// Затем запускает `node .next/standalone/server.js` и пишет логи в dev.log.
//
// ВАЖНО: Загружает env из .env И bizon-config.env (sandbox при boot
// перезаписывает .env только DATABASE_URL, без BIZON_ENCRYPTION_KEY).

const { spawn, execSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const PROJECT_DIR = '/home/z/my-project';
const NEXT_DIR = path.join(PROJECT_DIR, '.next');
const BUILD_MARKER = path.join(NEXT_DIR, 'BUILD-V2-LIGHTHOUSE.txt');
const SRC_DIR = path.join(PROJECT_DIR, 'src');
const ENV_FILE = path.join(PROJECT_DIR, '.env');
const CONFIG_FILE = path.join(PROJECT_DIR, 'bizon-config.env');
const DEV_LOG = path.join(PROJECT_DIR, 'dev.log');

function log(msg) {
  console.log(`[dev-prod] ${msg}`);
}

function parseEnvFile(file) {
  if (!fs.existsSync(file)) return {};
  const out = {};
  try {
    const raw = fs.readFileSync(file, 'utf8');
    for (const line of raw.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let v = m[2];
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1);
      }
      out[m[1]] = v;
    }
  } catch {
    // ignore
  }
  return out;
}

function buildEnv() {
  // .env имеет приоритет, bizon-config.env — fallback
  const cfgEnv = parseEnvFile(CONFIG_FILE);
  const dotEnv = parseEnvFile(ENV_FILE);
  const merged = {
    ...cfgEnv,
    ...dotEnv, // .env перебивает bizon-config.env
    NODE_ENV: 'production',
    PORT: '3000',
    HOSTNAME: '0.0.0.0',
    NEXT_TELEMETRY_DISABLED: '1',
  };
  // Обязательно BIZON_ENCRYPTION_KEY
  if (!merged.BIZON_ENCRYPTION_KEY) {
    log('FATAL: BIZON_ENCRYPTION_KEY не найден ни в .env, ни в bizon-config.env');
    process.exit(1);
  }
  return merged;
}

function needsBuild() {
  // Нет .next → нужен build
  if (!fs.existsSync(NEXT_DIR)) return true;
  if (!fs.existsSync(path.join(NEXT_DIR, 'BUILD_ID'))) return true;
  // Нет маркера новой версии → нужен build
  if (!fs.existsSync(BUILD_MARKER)) return true;
  // Любой файл в src новее маркера → нужен build
  const markerMtime = fs.statSync(BUILD_MARKER).mtimeMs;
  function walkDir(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (e.name === 'node_modules' || e.name === '.next') continue;
        if (walkDir(full)) return true;
      } else if (e.isFile() && (e.name.endsWith('.ts') || e.name.endsWith('.tsx') || e.name.endsWith('.css'))) {
        if (fs.statSync(full).mtimeMs > markerMtime) return true;
      }
    }
    return false;
  }
  return walkDir(SRC_DIR);
}

function doBuild() {
  log('Building production bundle (next build --webpack)...');
  // Turbopack падает по OOM в sandbox 4GB. Webpack стабилен.
  execSync('cd /home/z/my-project && npx --no-install next build --webpack', { stdio: 'inherit' });
  // копируем ассеты для standalone
  execSync('cp -r /home/z/my-project/.next/static /home/z/my-project/.next/standalone/.next/', { stdio: 'inherit' });
  execSync('cp -r /home/z/my-project/public /home/z/my-project/.next/standalone/', { stdio: 'inherit' });
  // marker
  fs.writeFileSync(BUILD_MARKER, new Date().toISOString());
  log('Build complete.');
}

function startServer() {
  log('Starting production server (node standalone)...');
  const env = buildEnv();
  log(`BIZON_ENCRYPTION_KEY: ${env.BIZON_ENCRYPTION_KEY.slice(0, 8)}...`);
  log(`DATABASE_URL: ${env.DATABASE_URL}`);
  log(`PORT: ${env.PORT}`);

  const child = spawn(
    process.platform === 'win32' ? 'node.exe' : 'node',
    ['.next/standalone/server.js'],
    {
      cwd: PROJECT_DIR,
      env: {
        ...env,
        // Ограничиваем heap чтобы Node не разрастался и не убивал sandbox
        NODE_OPTIONS: '--max-old-space-size=384',
      },
      stdio: 'inherit',
    }
  );
  child.on('exit', (code) => {
    log(`Server exited with code ${code}. Restarting in 3s...`);
    setTimeout(startServer, 3000); // авто-рестарт
  });
  child.on('error', (err) => {
    log(`Server error: ${err.message}. Restarting in 5s...`);
    setTimeout(startServer, 5000);
  });
}

try {
  if (needsBuild()) {
    doBuild();
  } else {
    log('Using existing build (.next/BUILD_ID up-to-date).');
  }
  startServer();
} catch (e) {
  console.error('[dev-prod] FATAL:', e);
  process.exit(1);
}
