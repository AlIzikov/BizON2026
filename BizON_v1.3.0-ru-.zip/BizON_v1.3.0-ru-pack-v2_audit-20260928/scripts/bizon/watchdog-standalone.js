#!/usr/bin/env node
/**
 * BizON — watchdog-standalone.js
 *
 * Запускает .next/standalone/server.js с переменными из .env
 * и авто-рестартит при падении (sandbox часто убивает процесс по таймауту).
 *
 * Запуск:
 *   nohup node scripts/watchdog-standalone.js > dev.log 2>&1 &
 */

const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const PROJECT_DIR = '/home/z/my-project';
const ENV_FILE = path.join(PROJECT_DIR, '.env');
const SERVER_JS = path.join(PROJECT_DIR, '.next/standalone/server.js');

function loadEnv() {
  const raw = fs.readFileSync(ENV_FILE, 'utf8');
  const env = { ...process.env };
  for (const line of raw.split('\n')) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    let v = m[2];
    // убираем кавычки
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
      v = v.slice(1, -1);
    }
    env[m[1]] = v;
  }
  return env;
}

let attempts = 0;
let lastStart = 0;

function start() {
  attempts++;
  lastStart = Date.now();
  const env = loadEnv();
  console.log(`[watchdog] attempt #${attempts} starting standalone server...`);

  const child = spawn('node', [SERVER_JS], {
    cwd: PROJECT_DIR,
    env: {
      ...env,
      NODE_ENV: 'production',
      PORT: '3000',
      HOSTNAME: '0.0.0.0',
    },
    stdio: 'inherit',
  });

  child.on('exit', (code, signal) => {
    const uptime = ((Date.now() - lastStart) / 1000).toFixed(1);
    console.log(`[watchdog] server exited code=${code} signal=${signal} uptime=${uptime}s`);
    // Если жил меньше 5 секунд — что-то не так, подождём подольше
    const delay = uptime < 5 ? 10000 : 2000;
    setTimeout(start, delay);
  });

  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('[watchdog] SIGTERM received, killing child...');
    child.kill('SIGTERM');
    setTimeout(() => process.exit(0), 1000);
  });
  process.on('SIGINT', () => {
    child.kill('SIGINT');
    setTimeout(() => process.exit(0), 1000);
  });
}

// Проверка наличия server.js
if (!fs.existsSync(SERVER_JS)) {
  console.error(`[watchdog] FATAL: ${SERVER_JS} not found. Run 'next build' first.`);
  process.exit(1);
}
if (!fs.existsSync(ENV_FILE)) {
  console.error(`[watchdog] FATAL: ${ENV_FILE} not found.`);
  process.exit(1);
}

start();
