#!/usr/bin/env bash
# BizON — авто-рестарт сервера при падении
# Запускает standalone-server.js и перезапускает его, если процесс умер

cd /home/z/my-project

while true; do
  echo "[$(date '+%H:%M:%S')] Starting BizON standalone server..."
  NODE_OPTIONS="--max-old-space-size=384" NODE_ENV=production PORT=3000 bun .next/standalone/server.js > dev.log 2>&1
  EXIT_CODE=$?
  echo "[$(date '+%H:%M:%S')] Server exited with code $EXIT_CODE. Restarting in 3s..."
  sleep 3
done
