// Быстрый скрипт: создать demo-пользователя без пароля и получить token
const { PrismaClient } = require('@prisma/client');
const crypto = require('node:crypto');
const db = new PrismaClient();

async function main() {
  // Создаём или находим demo пользователя
  let user = await db.user.findFirst({ where: { email: 'demo@bizon.app' } });
  
  if (!user) {
    console.log('Creating demo user...');
    // Псевдо-пароль (никто не сможет залогиниться, но сессию создадим сами)
    const fakeHash = 'pbkdf2$600000$00000000000000000000000000000000$0000000000000000000000000000000000000000000000000000000000000000';
    user = await db.user.create({
      data: {
        email: 'demo@bizon.app',
        emailHash: 'demo_hash_placeholder',
        emailEncrypted: 'demo_encrypted_placeholder',
        passwordHash: fakeHash,
        name: 'Demo User',
        title: 'Product Designer',
        bio: 'Demo account for AI evaluation',
        ipScore: 87,
        level: 'Senior',
        roles: 'user',
        accountType: 'personal',
        isVerified: false,
        subscriptionTier: 'free',
      }
    });
  }
  
  console.log('User:', user.id, user.email, user.name);
  
  // Создаём сессию
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 24 * 7 * 60 * 60 * 1000);
  await db.session.create({ data: { userId: user.id, token, expiresAt } });
  
  console.log('TOKEN=' + token);
  
  await db.$disconnect();
}

main().catch(e => { console.error(e); process.exit(1); });
