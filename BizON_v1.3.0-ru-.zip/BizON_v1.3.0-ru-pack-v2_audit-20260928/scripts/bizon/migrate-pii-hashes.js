// BizON — Миграция PII: заполнить emailHash + emailEncrypted для всех существующих юзеров
// C1: первый этап миграции — перевод с plaintext email на emailHash + emailEncrypted
//
// Запуск: node scripts/migrate-pii-hashes.js
// После проверки — следующий этап: убрать plaintext email из схемы

const { PrismaClient } = require('@prisma/client');
const crypto = require('crypto');

// Импортируем encrypt/hashEmail из src/lib/security/crypto.ts
// PrismaClient не может импортировать .ts напрямую, поэтому дублируем логику здесь
const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12;

const ENCRYPTION_KEY_HEX = process.env.BIZON_ENCRYPTION_KEY;
if (!ENCRYPTION_KEY_HEX) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в .env');
  console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
  process.exit(1);
}

function encrypt(plaintext) {
  if (!plaintext) return '';
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, Buffer.from(ENCRYPTION_KEY_HEX, 'hex'), iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, encrypted, authTag]).toString('base64');
}

function hashEmail(email) {
  return crypto.createHmac('sha256', ENCRYPTION_KEY_HEX).update(email.toLowerCase()).digest('hex');
}

async function main() {
  const prisma = new PrismaClient();

  console.log('=== Миграция PII: заполнение emailHash + emailEncrypted ===\n');

  const users = await prisma.user.findMany({
    select: { id: true, email: true, bio: true, location: true, phone: true, bioEncrypted: true, locationEncrypted: true, phoneEncrypted: true, emailEncrypted: true, emailHash: true },
  });

  console.log(`Найдено пользователей: ${users.length}`);

  let updated = 0;
  let skipped = 0;
  let errors = 0;

  for (const u of users) {
    try {
      const updateData = {};

      // emailHash + emailEncrypted
      if (!u.emailHash) {
        updateData.emailHash = hashEmail(u.email);
      }
      if (!u.emailEncrypted) {
        updateData.emailEncrypted = encrypt(u.email);
      }

      // bioEncrypted (если есть plaintext bio и нет encrypted)
      if (u.bio && !u.bioEncrypted) {
        updateData.bioEncrypted = encrypt(u.bio);
      }

      // locationEncrypted
      if (u.location && !u.locationEncrypted) {
        updateData.locationEncrypted = encrypt(u.location);
      }

      // phoneEncrypted
      if (u.phone && !u.phoneEncrypted) {
        updateData.phoneEncrypted = encrypt(u.phone);
      }

      if (Object.keys(updateData).length === 0) {
        skipped++;
        continue;
      }

      await prisma.user.update({ where: { id: u.id }, data: updateData });
      updated++;
      console.log(`  ✅ ${u.email} → hash + ${Object.keys(updateData).length} полей зашифровано`);
    } catch (e) {
      errors++;
      console.error(`  ❌ ${u.email}: ${e.message}`);
    }
  }

  console.log(`\n=== Итог ===`);
  console.log(`  Обновлено: ${updated}`);
  console.log(`  Пропущено (уже было): ${skipped}`);
  console.log(`  Ошибок: ${errors}`);

  // Проверка
  const withHash = await prisma.user.count({ where: { emailHash: { not: null } } });
  const withEncrypted = await prisma.user.count({ where: { emailEncrypted: { not: null } } });
  console.log(`\nПроверка:`);
  console.log(`  Пользователей с emailHash: ${withHash}/${users.length}`);
  console.log(`  Пользователей с emailEncrypted: ${withEncrypted}/${users.length}`);

  await prisma.$disconnect();
}

main().catch(e => {
  console.error(e);
  process.exit(1);
});
