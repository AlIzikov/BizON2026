// BizON — Этап 8.6: Email re-engagement cron
// Запускать ежедневно в 10:00 (или по требованию).
//
// crontab:
//   0 10 * * *  cd /home/z/my-project && BIZON_ENCRYPTION_KEY=... /usr/bin/node scripts/cron-email-reengagement.js >> /var/log/bizon-email-reengagement.log 2>&1
//
// Что делает:
//   1. Берёт всех пользователей с emailNotificationsEnabled=true (и не удалённых).
//   2. Для каждого — расшифровывает emailEncrypted, проверяет 3 триггера:
//      - reputation_growth: IP-score вырос > 5 за 7 дней (по ReputationSnapshot)
//      - new_jobs: есть активные вакансии с match% > 70 (топ-3)
//      - skill_confirmed: есть новые SkillConfirmation за последние 24ч
//   3. Отправляет re-engagement письмо через email-service (nodemailer или dev-stub).
//   4. Идемпотентность: если lastReengagementEmailAt < 24ч назад — пропускаем.
//      После отправки обновляем lastReengagementEmailAt = now().
//
// Внимание: cron отправляет максимум 1 письмо на пользователя в сутки.
// Если сработало несколько триггеров — отправляем письмо по приоритету:
//   1) skill_confirmed (самое персональное)
//   2) reputation_growth (мотивация)
//   3) new_jobs (utility)
// В будущем можно отправлять несколько писем или объединять в дайджест.

const { PrismaClient } = require('@prisma/client');
const crypto = require('crypto');

// === Проверка BIZON_ENCRYPTION_KEY ===
const ENC_KEY = process.env.BIZON_ENCRYPTION_KEY;
if (!ENC_KEY) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в окружении.');
  console.error('   Запуск: BIZON_ENCRYPTION_KEY=... node scripts/cron-email-reengagement.js');
  process.exit(1);
}

const prisma = new PrismaClient();

// === Параметры ===
const REPUTATION_GROWTH_THRESHOLD = 5; // IP-score вырос > 5 за неделю
const NEW_JOBS_MATCH_THRESHOLD = 0.7; // matchConfidence > 0.7 (0..1)
const DEDUP_WINDOW_HOURS = 24; // не чаще 1 письма в сутки на пользователя
const SKILL_CONFIRMATION_WINDOW_HOURS = 24; // новые подтверждения за последние 24ч

// === Константы алгоритма шифрования (должны совпадать с src/lib/security/crypto.ts) ===
const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12;

function decrypt(encryptedBase64) {
  if (!encryptedBase64) return '';
  try {
    const data = Buffer.from(encryptedBase64, 'base64');
    const iv = data.subarray(0, IV_LENGTH);
    const authTag = data.subarray(data.length - 16);
    const encrypted = data.subarray(IV_LENGTH, data.length - 16);
    const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(ENC_KEY, 'hex'), iv);
    decipher.setAuthTag(authTag);
    return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
  } catch (e) {
    console.error('[decrypt] error:', e?.message ?? e);
    return '';
  }
}

// === SMTP / nodemailer ===
let nodemailer = null;
let _transporter = null;
let _smtpChecked = false;

function isSmtpConfigured() {
  if (_smtpChecked) return _transporter !== null;
  _smtpChecked = true;

  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT;
  const user = process.env.SMTP_USER;
  const password = process.env.SMTP_PASSWORD;
  const from = process.env.SMTP_FROM;

  if (!host || !port || !user || !password || !from) {
    _transporter = null;
    return false;
  }

  try {
    nodemailer = require('nodemailer');
    _transporter = nodemailer.createTransport({
      host,
      port: Number(port),
      secure: Number(port) === 465,
      auth: { user, pass: password },
    });
    return true;
  } catch (e) {
    console.error('[cron-email] SMTP transporter init failed:', e?.message ?? e);
    _transporter = null;
    return false;
  }
}

function getFrom() {
  return process.env.SMTP_FROM || 'BizON <no-reply@bizon.local>';
}

function getAppUrl() {
  return process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatSalary(from, to, currency) {
  if (!from && !to) return null;
  const cur = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : '';
  const fmt = (n) => n.toLocaleString('ru-RU');
  let range = '';
  if (from && to) range = `${fmt(from)}–${fmt(to)}`;
  else if (from) range = `от ${fmt(from)}`;
  else if (to) range = `до ${fmt(to)}`;
  return `${range} ${cur}`.trim();
}

// ============================================================================
// Шаблоны писем
// ============================================================================

function emailShell(opts) {
  return `<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(opts.title)}</title>
</head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#0f172a;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:24px 0;">
    <tr><td align="center">
      <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(15,23,42,0.08);">
        <tr>
          <td style="background:#1e3a8a;padding:20px 28px;">
            <table role="presentation" width="100%"><tr>
              <td style="font-size:20px;font-weight:700;color:#ffffff;letter-spacing:0.5px;">
                <span style="color:#34d399;">B</span>izON
              </td>
              <td align="right" style="font-size:12px;color:#cbd5e1;">Индекс доверия</td>
            </tr></table>
          </td>
        </tr>
        <tr>
          <td style="padding:28px;">
            <h1 style="font-size:18px;font-weight:600;margin:0 0 16px;color:#1e3a8a;">${escapeHtml(opts.greeting)},</h1>
            <p style="font-size:15px;line-height:1.55;margin:0 0 16px;color:#334155;">${opts.title}</p>
            ${opts.bodyHtml}
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:24px 0 8px;">
              <tr><td align="center">
                <a href="${escapeHtml(opts.ctaHref)}" style="display:inline-block;background:#10b981;color:#ffffff;font-weight:600;font-size:14px;padding:12px 28px;border-radius:8px;text-decoration:none;">
                  ${escapeHtml(opts.ctaText)}
                </a>
              </td></tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="padding:16px 28px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:12px;color:#94a3b8;line-height:1.5;">
            Вы получили это письмо, потому что включили email-уведомления в BizON.<br>
            <a href="${escapeHtml(getAppUrl())}/settings" style="color:#64748b;">Настройки уведомлений</a> ·
            <a href="${escapeHtml(getAppUrl())}" style="color:#64748b;">BizON</a>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

function buildReputationGrowth(user, data) {
  const bodyHtml = `
    <p style="font-size:15px;line-height:1.55;margin:0 0 12px;color:#334155;">
      За последнюю неделю ваш <strong>IP-score вырос на +${data.delta}</strong> пункта(ов).
      Ваш текущий индекс доверия — <strong style="color:#10b981;">${data.currentScore}/100</strong>
      (неделю назад: ${data.weekAgoScore}).
    </p>
    <p style="font-size:14px;line-height:1.5;margin:0;color:#64748b;">
      Так держать! Коллеги замечают ваш рост — это ваша профессиональная валюта в BizON.
    </p>`;
  return {
    subject: `BizON: ваш IP-score вырос на +${data.delta}`,
    html: emailShell({
      greeting: user.name,
      title: `📈 Ваш IP-score вырос на +${data.delta} за неделю`,
      bodyHtml,
      ctaText: 'Открыть профиль',
      ctaHref: `${getAppUrl()}/profile/${user.id}`,
    }),
    text: `Ваш IP-score вырос на +${data.delta} за неделю (текущий: ${data.currentScore}/100).`,
  };
}

function buildNewJobs(user, data) {
  const items = data.jobs
    .map((j, i) => {
      const salary = formatSalary(j.salaryFrom ?? null, j.salaryTo ?? null, j.currency ?? null);
      return `
        <tr>
          <td style="padding:14px 0;border-top:${i === 0 ? 'none' : '1px solid #e2e8f0'};">
            <div style="font-size:15px;font-weight:600;color:#0f172a;">${escapeHtml(j.title)}</div>
            <div style="font-size:13px;color:#64748b;margin:2px 0 6px;">${escapeHtml(j.company)}${j.location ? ' · ' + escapeHtml(j.location) : ''}${salary ? ' · ' + escapeHtml(salary) : ''}</div>
            <div style="display:inline-block;background:#dcfce7;color:#15803d;font-size:12px;font-weight:600;padding:3px 8px;border-radius:6px;">match ${j.matchPercent}%</div>
          </td>
        </tr>`;
    })
    .join('');
  const bodyHtml = `
    <p style="font-size:15px;line-height:1.55;margin:0 0 14px;color:#334155;">
      Мы подобрали <strong>${data.jobs.length}</strong> новые вакансии, которые подходят вам по навыкам и уровню доверия.
    </p>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:8px;">${items}</table>`;
  return {
    subject: `BizON: ${data.jobs.length} новые вакансии для вас`,
    html: emailShell({
      greeting: user.name,
      title: `💼 ${data.jobs.length} новые вакансии подходят вам`,
      bodyHtml,
      ctaText: 'Смотреть вакансии',
      ctaHref: `${getAppUrl()}/jobs`,
    }),
    text: `Подобрали ${data.jobs.length} новые вакансии, подходящих вам.`,
  };
}

function buildSkillConfirmed(user, data) {
  const projectNote = data.projectName
    ? ` в рамках проекта «<strong>${escapeHtml(data.projectName)}</strong>»`
    : '';
  const bodyHtml = `
    <p style="font-size:15px;line-height:1.55;margin:0 0 14px;color:#334155;">
      <strong>${escapeHtml(data.confirmerName)}</strong> подтвердил ваш навык
      <strong style="color:#1e3a8a;">${escapeHtml(data.skillName)}</strong>${projectNote}.
    </p>
    <p style="font-size:14px;line-height:1.5;margin:0;color:#64748b;">
      Подтверждения от коллег — ключевой фактор вашего IP-score. Чем больше подтверждённых навыков, тем выше доверие платформы.
    </p>`;
  return {
    subject: `BizON: ${data.confirmerName} подтвердил ваш навык`,
    html: emailShell({
      greeting: user.name,
      title: `✅ ${data.confirmerName} подтвердил ваш навык «${data.skillName}»`,
      bodyHtml,
      ctaText: 'Открыть профиль навыков',
      ctaHref: `${getAppUrl()}/profile/${user.id}`,
    }),
    text: `${data.confirmerName} подтвердил ваш навык ${data.skillName}.`,
  };
}

// ============================================================================
// Отправка письма
// ============================================================================

async function sendEmail(to, subject, html, text) {
  if (!isSmtpConfigured()) {
    console.log(
      `  📧 [DEV STUB] To: ${to}\n     Subject: ${subject}`
    );
    return { ok: true, mode: 'console' };
  }
  try {
    const info = await _transporter.sendMail({
      from: getFrom(),
      to,
      subject,
      html,
      text: text || html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 1000),
    });
    return { ok: true, mode: 'smtp', messageId: info.messageId };
  } catch (e) {
    console.error('  ❌ sendMail error:', e?.message ?? e);
    return { ok: false, mode: 'smtp', error: e?.message ?? 'send failed' };
  }
}

// ============================================================================
// Триггеры: проверка условий и подготовка данных
// ============================================================================

// Эвристика match (должна совпадать с computeJobMatch в src/lib/ai.ts)
function computeJobMatch(userSkills, userIpScore, job) {
  const requiredSkills = job.requiredSkills || [];
  if (requiredSkills.length === 0) return 0.3;
  const userSkillsLower = userSkills.map((s) => s.toLowerCase());
  const requiredLower = requiredSkills.map((s) => s.toLowerCase());
  const overlap = requiredLower.filter((s) => userSkillsLower.includes(s)).length;
  const skillMatch = overlap / requiredLower.length;
  const trustBoost = userIpScore / 100;
  const growth = job.growthScore;
  return Number((skillMatch * 0.6 + trustBoost * 0.25 + growth * 0.15).toFixed(3));
}

async function checkReputationGrowth(userId, currentIpScore) {
  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  try {
    const snapshots = await prisma.reputationSnapshot.findMany({
      where: { userId, createdAt: { gte: weekAgo } },
      orderBy: { createdAt: 'asc' },
      take: 50,
      select: { ipScore: true, createdAt: true },
    });
    if (snapshots.length === 0) {
      // Если нет снапшотов — используем разницу между текущим и оценкой неделю назад
      // через самое старое ReputationEvent (грубая эвристика)
      return null;
    }
    const weekAgoScore = snapshots[0].ipScore;
    const delta = currentIpScore - weekAgoScore;
    if (delta > REPUTATION_GROWTH_THRESHOLD) {
      return { delta, currentScore: currentIpScore, weekAgoScore };
    }
    return null;
  } catch {
    return null;
  }
}

async function checkNewJobs(userId, userIpScore) {
  // Берём навыки пользователя
  const userSkills = await prisma.userSkill.findMany({
    where: { userId },
    include: { skill: { select: { name: true } } },
  });
  const userSkillNames = userSkills.map((us) => us.skill.name);

  if (userSkillNames.length === 0) return null;

  // Только вакансии за последние 7 дней (новые)
  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const jobs = await prisma.job.findMany({
    where: { active: true, createdAt: { gte: weekAgo } },
    take: 100,
  });

  const ranked = jobs
    .map((j) => {
      const requiredSkills = j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [];
      const match = computeJobMatch(userSkillNames, userIpScore, {
        requiredSkills,
        growthScore: j.growthScore,
      });
      return {
        id: j.id,
        title: j.title,
        company: j.company,
        matchConfidence: match,
        matchPercent: Math.round(match * 100),
        salaryFrom: j.salaryFrom ?? j.salaryMin ?? null,
        salaryTo: j.salaryTo ?? j.salaryMax ?? null,
        currency: j.currency,
        location: j.location,
      };
    })
    .filter((j) => j.matchConfidence > NEW_JOBS_MATCH_THRESHOLD)
    .sort((a, b) => b.matchConfidence - a.matchConfidence)
    .slice(0, 3);

  if (ranked.length === 0) return null;
  return { jobs: ranked };
}

async function checkSkillConfirmed(userId) {
  const since = new Date(Date.now() - SKILL_CONFIRMATION_WINDOW_HOURS * 60 * 60 * 1000);
  // Берём последние подтверждения навыков этого пользователя
  const userSkills = await prisma.userSkill.findMany({
    where: { userId },
    select: { id: true, skill: { select: { name: true } } },
  });
  if (userSkills.length === 0) return null;

  const userSkillIds = userSkills.map((us) => us.id);
  const skillNameById = Object.fromEntries(userSkills.map((us) => [us.id, us.skill.name]));

  const confirmation = await prisma.skillConfirmation.findFirst({
    where: { userSkillId: { in: userSkillIds }, createdAt: { gte: since } },
    orderBy: { createdAt: 'desc' },
    include: {
      confirmer: { select: { name: true } },
      project: { select: { title: true } },
    },
  });

  if (!confirmation) return null;
  return {
    confirmerName: confirmation.confirmer?.name ?? 'Коллега',
    skillName: skillNameById[confirmation.userSkillId] ?? 'навык',
    projectName: confirmation.project?.title ?? null,
  };
}

// ============================================================================
// Process user
// ============================================================================

async function processUser(user) {
  const now = Date.now();
  // Идемпотентность: не чаще 1 письма в DEDUP_WINDOW_HOURS
  if (user.lastReengagementEmailAt) {
    const lastSent = user.lastReengagementEmailAt.getTime();
    const hoursSince = (now - lastSent) / (60 * 60 * 1000);
    if (hoursSince < DEDUP_WINDOW_HOURS) {
      return { skipped: true, reason: 'recent email sent' };
    }
  }

  // Расшифровываем email
  const email = user.emailEncrypted ? decrypt(user.emailEncrypted) : (user.email || '');
  if (!email || !email.includes('@')) {
    return { skipped: true, reason: 'no valid email' };
  }

  // Проверяем все 3 триггера параллельно
  const [growthData, newJobsData, skillData] = await Promise.all([
    checkReputationGrowth(user.id, user.ipScore),
    checkNewJobs(user.id, user.ipScore),
    checkSkillConfirmed(user.id),
  ]);

  // Приоритет: skill_confirmed → reputation_growth → new_jobs
  let type, data, buildFn;
  if (skillData) {
    type = 'skill_confirmed';
    data = skillData;
    buildFn = buildSkillConfirmed;
  } else if (growthData) {
    type = 'reputation_growth';
    data = growthData;
    buildFn = buildReputationGrowth;
  } else if (newJobsData) {
    type = 'new_jobs';
    data = newJobsData;
    buildFn = buildNewJobs;
  } else {
    return { skipped: true, reason: 'no triggers fired' };
  }

  const rengUser = { id: user.id, name: user.name, email };
  const built = buildFn(rengUser, data);
  const result = await sendEmail(email, built.subject, built.html, built.text);

  if (!result.ok) {
    return { skipped: false, sent: false, type, error: result.error };
  }

  // Обновляем lastReengagementEmailAt
  await prisma.user.update({
    where: { id: user.id },
    data: { lastReengagementEmailAt: new Date() },
  });

  return { skipped: false, sent: true, type, mode: result.mode };
}

// ============================================================================
// main
// ============================================================================

async function main() {
  console.log('=== BizON — Email Re-engagement Cron ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log(`BIZON_ENCRYPTION_KEY: задан (${ENC_KEY.length} символов)`);
  console.log(`SMTP: ${isSmtpConfigured() ? 'настроен (' + process.env.SMTP_HOST + ':' + process.env.SMTP_PORT + ')' : 'не настроен (режим dev-заглушки)'}\n`);

  let offset = 0;
  const BATCH = 100;
  let processed = 0;
  let sentCount = 0;
  let skippedRecent = 0;
  let skippedNoEmail = 0;
  let skippedNoTrigger = 0;
  let errors = 0;
  const byType = { reputation_growth: 0, new_jobs: 0, skill_confirmed: 0 };

  while (true) {
    const users = await prisma.user.findMany({
      where: {
        emailNotificationsEnabled: true,
        deletedAt: null,
      },
      select: {
        id: true,
        name: true,
        email: true,
        emailEncrypted: true,
        ipScore: true,
        lastReengagementEmailAt: true,
      },
      take: BATCH,
      skip: offset,
    });
    if (users.length === 0) break;

    for (const u of users) {
      try {
        const result = await processUser(u);
        processed++;
        if (result.skipped) {
          if (result.reason === 'recent email sent') skippedRecent++;
          else if (result.reason === 'no valid email') skippedNoEmail++;
          else if (result.reason === 'no triggers fired') skippedNoTrigger++;
        } else if (result.sent) {
          sentCount++;
          byType[result.type] = (byType[result.type] || 0) + 1;
          console.log(`  📧 ${u.name} (${u.id}): ${result.type} [${result.mode}]`);
        } else {
          errors++;
          console.error(`  ❌ ${u.name} (${u.id}): send failed: ${result.error}`);
        }
      } catch (e) {
        console.error(`  ❌ ${u.name} (${u.id}): error:`, e?.message ?? e);
        errors++;
      }
    }

    offset += BATCH;
  }

  console.log('\n=== Итог ===');
  console.log(`  Всего обработано:        ${processed}`);
  console.log(`  Отправлено писем:        ${sentCount}`);
  console.log(`    - skill_confirmed:     ${byType.skill_confirmed}`);
  console.log(`    - reputation_growth:   ${byType.reputation_growth}`);
  console.log(`    - new_jobs:            ${byType.new_jobs}`);
  console.log(`  Пропущено (недавнее):    ${skippedRecent}`);
  console.log(`  Пропущено (нет email):   ${skippedNoEmail}`);
  console.log(`  Пропущено (нет тригг.):  ${skippedNoTrigger}`);
  console.log(`  Ошибок:                  ${errors}`);
  console.log('\n✅ Email re-engagement cron complete.');
}

main()
  .catch((e) => {
    console.error('❌ Email re-engagement cron failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
