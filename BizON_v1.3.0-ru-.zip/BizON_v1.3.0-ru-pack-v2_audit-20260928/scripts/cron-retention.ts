// R5-P2 · retention-крон: минимизация данных (GDPR Art.5(1)(e) + 152-ФЗ).
//
// Политика — docs/legal/data-retention.md. Скрипт БЕЗОПАСЕН по умолчанию:
//   bun run scripts/cron-retention.ts            # dry-run: только показывает план
//   bun run scripts/cron-retention.ts --apply    # выполнить удаления
//
// Правила (аддитивно к существующему cron-cleanup-deleted.js, который не трогаем):
//   1. File (soft-deleted > 30 дней)  → физическое удаление с диска + строки.
//   2. Session (expiresAt < now)      → удаление просроченных сессий.
//   3. Notification старше 90 дней    → удаление (in-app журнал не «вечный»).
//   4. EmailLog старше 180 дней       → удаление (PII-минимизация адресатов).
//
// Запуск по расписанию — crontab.bizon (см. docs/ops/backup-restore.md).
// Каждый запуск печатает сводку; AuditLog пишется ТОЛЬКО при --apply.
import { db } from '../src/lib/db';
import { deletePhysicalFile } from '../src/lib/file-storage';

const APPLY = process.argv.includes('--apply');

const FILE_RETENTION_DAYS = 30;
const SESSION_GRACE = 0; // просроченные — сразу
const NOTIFICATION_DAYS = 90;
const EMAILLOG_DAYS = 180;

function cutoff(days: number): Date {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000);
}

async function main() {
  const report: Record<string, number> = {};

  // 1. Files: мягко удалённые >30д — физически.
  const staleFiles = await db.file.findMany({
    where: { deletedAt: { lt: cutoff(FILE_RETENTION_DAYS) } },
    select: { id: true, storageKey: true },
    take: 500,
  });
  let filesRemoved = 0;
  for (const f of staleFiles) {
    await deletePhysicalFile(f.storageKey).catch(() => false);
    if (APPLY) await db.file.delete({ where: { id: f.id } }).catch(() => undefined);
    filesRemoved++;
  }
  report['files_purged'] = filesRemoved;

  // 2. Sessions: просроченные.
  if (APPLY) {
    const res = await db.session.deleteMany({ where: { expiresAt: { lt: new Date() } } });
    report['sessions_purged'] = res.count;
  } else {
    report['sessions_purged'] = await db.session.count({ where: { expiresAt: { lt: new Date() } } });
  }

  // 3. Notifications: >90д.
  if (APPLY) {
    const res = await db.notification.deleteMany({ where: { createdAt: { lt: cutoff(NOTIFICATION_DAYS) } } });
    report['notifications_purged'] = res.count;
  } else {
    report['notifications_purged'] = await db.notification.count({
      where: { createdAt: { lt: cutoff(NOTIFICATION_DAYS) } },
    });
  }

  // 4. EmailLog: >180д (PII-минимизация адресатов; поле времени — sentAt).
  try {
    const emailLog = (db as unknown as {
      emailLog?: { deleteMany: (a: unknown) => Promise<{ count: number }>; count: (a: unknown) => Promise<number> };
    }).emailLog;
    if (emailLog) {
      report['emaillog_purged'] = APPLY
        ? (await emailLog.deleteMany({ where: { sentAt: { lt: cutoff(EMAILLOG_DAYS) } } })).count
        : await emailLog.count({ where: { sentAt: { lt: cutoff(EMAILLOG_DAYS) } } });
    }
  } catch {
    report['emaillog_purged'] = -1; // модели нет — правило не применяется
  }

  console.log(`[retention] mode=${APPLY ? 'APPLY' : 'DRY-RUN'} at ${new Date().toISOString()}`);
  for (const [k, v] of Object.entries(report)) console.log(`[retention] ${k}: ${v}`);
  if (!APPLY) console.log('[retention] dry-run: ничего не удалено. Для применения: --apply');
  process.exit(0);
}

main().catch((e) => {
  console.error('[retention] FAILED:', e);
  process.exit(1);
});
