const http = require('http');
/* eslint-disable @typescript-eslint/no-require-imports */
const { execSync } = require('child_process');

const PORT = 3000;
const HTML = `<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>BizON — Маяк в цифровом мире</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:#0B2545;color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center}
.card{background:#fff;color:#0B2545;border-radius:16px;padding:40px;max-width:500px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.3)}
h1{font-size:32px;margin-bottom:8px}
p{color:#455a75;font-size:14px;line-height:1.6;margin-bottom:16px}
.badge{display:inline-block;background:#0E7C86;color:#fff;padding:4px 12px;border-radius:20px;font-size:12px;margin:4px}
.btn{display:inline-block;background:#0B2545;color:#fff;padding:12px 32px;border-radius:8px;text-decoration:none;font-weight:600;margin-top:16px}
</style>
</head>
<body>
<div class="card">
<img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%230B2545'/%3E%3Ctext x='50' y='65' font-size='40' text-anchor='middle' fill='white'%3E💡%3C/text%3E%3C/svg%3E" style="width:80px;height:80px;border-radius:16px;margin-bottom:16px">
<h1>BizON</h1>
<p style="font-size:18px;color:#0B2545;font-weight:600">Маяк в цифровом мире</p>
<br>
<p><strong>BizON запущен в лёгком режиме</strong></p>
<p>Полный сервер требует больше памяти (4GB sandbox). Превью работает через панель Z.ai.</p>
<br>
<div>
<span class="badge">IP-Score</span>
<span class="badge">AI-Matchmaker</span>
<span class="badge">Trust Graph</span>
<span class="badge">NFT Skills</span>
<span class="badge">DAO</span>
</div>
<br>
<p style="font-size:12px;color:#999">v10.0 · Фаза 1+2 · © BizON Systems 2025</p>
</div>
</body>
</html>`;

const server = http.createServer((req, res) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  
  if (req.url === '/' || req.url === '/index.html') {
    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
    res.end(HTML);
    return;
  }
  
  if (req.url.startsWith('/api/')) {
    res.writeHead(200, {'Content-Type': 'application/json'});
    res.end(JSON.stringify({status: 'ok', message: 'BizON API is running'}));
    return;
  }
  
  res.writeHead(404, {'Content-Type': 'text/html'});
  res.end('<h1>404</h1><p>Страница не найдена</p>');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[BizON Ultra-Light] Running on port ${PORT}`);
  console.log(`Memory: ${Math.round(process.memoryUsage().rss / 1024 / 1024)}MB`);
});

// Auto-restart on crash
process.on('uncaughtException', (err) => {
  console.error('[FATAL]', err.message);
  setTimeout(() => process.exit(1), 1000);
});
