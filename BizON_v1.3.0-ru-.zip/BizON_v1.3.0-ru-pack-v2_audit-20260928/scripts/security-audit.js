// BizON — Security Audit Script (Phase 14)
// Запуск: node scripts/security-audit.js
//
// Проходит по всем src/app/api/**/route.ts и проверяет:
//   1. Наличие getUserFromRequest / requireUser (auth-проверка)
//   2. Ownership-проверку (user.id) для PATCH/DELETE-маршрутов
//   3. Пропускает public/health-эндпоинты
//
// Возвращает:
//   - checked: сколько route.ts проверено
//   - passed: сколько прошло проверку
//   - warnings: список подозрительных маршрутов
//   - failures: список критических нарушений
const fs = require('fs');
const path = require('path');

// Проверить все route.ts на наличие getUserFromRequest
function auditRoutes() {
  const apiDir = path.join(__dirname, '..', 'src', 'app', 'api');
  const results = { checked: 0, passed: 0, warnings: [], failures: [] };

  function walk(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) { walk(full); continue; }
      if (e.name !== 'route.ts') continue;
      results.checked++;
      const content = fs.readFileSync(full, 'utf8');
      // Пропустить public routes
      if (content.includes('health') || content.includes('public')) { results.passed++; continue; }
      // Проверить auth
      if (content.includes('getUserFromRequest') || content.includes('requireUser')) {
        results.passed++;
      } else {
        results.warnings.push(`No auth check: ${path.relative(apiDir, full)}`);
      }
      // Проверить ownership для PATCH/DELETE
      if ((content.includes('PATCH') || content.includes('DELETE')) && !content.includes('user.id')) {
        results.warnings.push(`No ownership check: ${path.relative(apiDir, full)}`);
      }
    }
  }
  walk(apiDir);
  return results;
}

const results = auditRoutes();
console.log('=== BIZON SECURITY AUDIT ===');
console.log(`Checked: ${results.checked}`);
console.log(`Passed: ${results.passed}`);
console.log(`Warnings: ${results.warnings.length}`);
results.warnings.forEach(w => console.log(`  ⚠️ ${w}`));
console.log(`Failures: ${results.failures.length}`);
results.failures.forEach(f => console.log(`  ❌ ${f}`));

// Non-zero exit code если есть failures (но не на warnings —
// warnings могут быть легитимными (public endpoints, webhooks и т.д.)).
if (results.failures.length > 0) {
  process.exit(1);
}
