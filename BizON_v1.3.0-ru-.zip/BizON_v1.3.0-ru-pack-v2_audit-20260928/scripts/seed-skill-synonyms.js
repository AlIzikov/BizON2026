// BizON v6 — Seed: русские синонимы навыков для семантического поиска (SkillSynonym)
// v6.0 (docs/v6-handover/00-FULL-CONTEXT.md, раздел 4.9): ровно 119 русских
// профессиональных синонимов, сгруппированных по сферам: разработка, дизайн,
// маркетинг, финансы, юриспруденция, медицина, стройка, педагогика и др.
//
// Запуск:
//   node scripts/seed-skill-synonyms.js
//
// Идемпотентность: SkillSynonym НЕ имеет уникального constraint в схеме
// (только @@index), поэтому дедупликация выполняется вручную — перед созданием
// ищется существующая запись по паре (skillId, synonym). Повторный запуск
// ничего не дублирует: всё, что уже есть, помечается как skipped.
//
// Канонические навыки (Skill) создаются при необходимости (upsert по name @unique),
// чтобы seed можно было запускать на пустой БД после `prisma db push`.
//
// Схема-цель (prisma/schema.prisma):
//   model SkillSynonym { id String @id @default(cuid()); skillId String; synonym String }
//   model Skill        { id String @id @default(cuid()); name String @unique; category String? }

const { PrismaClient } = require('@prisma/client');

const EXPECTED_SYNONYMS = 119;

/**
 * Группы: канонический навык → категория → список русских синонимов (lowercase).
 * Синонимы реалистичные — так, как их пишут в поиске живые люди:
 * «питон» вместо Python, «фигма» вместо Figma, «одинэс» вместо 1С.
 */
const SYNONYM_GROUPS = [
  // ===== Разработка =====
  { skill: 'JavaScript',    category: 'Разработка', synonyms: ['js', 'эс6', 'джаваскрипт'] },
  { skill: 'TypeScript',    category: 'Разработка', synonyms: ['тайпскрипт', 'тс'] },
  { skill: 'React',         category: 'Разработка', synonyms: ['реакт', 'reactjs'] },
  { skill: 'Vue.js',        category: 'Разработка', synonyms: ['вью'] },
  { skill: 'Angular',       category: 'Разработка', synonyms: ['ангуляр'] },
  { skill: 'Node.js',       category: 'Разработка', synonyms: ['нода'] },
  { skill: 'Python',        category: 'Разработка', synonyms: ['питон', 'пайтон'] },
  { skill: 'Django',        category: 'Разработка', synonyms: ['джанго'] },
  { skill: 'PHP',           category: 'Разработка', synonyms: ['пхп'] },
  { skill: 'Laravel',       category: 'Разработка', synonyms: ['ларавель'] },
  { skill: 'Java',          category: 'Разработка', synonyms: ['джава'] },
  { skill: 'Kotlin',        category: 'Разработка', synonyms: ['котлин'] },
  { skill: 'Swift',         category: 'Разработка', synonyms: ['свифт'] },
  { skill: 'Go',            category: 'Разработка', synonyms: ['golang'] },
  { skill: 'Rust',          category: 'Разработка', synonyms: ['раст'] },
  { skill: 'C#',            category: 'Разработка', synonyms: ['си шарп'] },
  { skill: 'C++',           category: 'Разработка', synonyms: ['си плюс плюс'] },
  { skill: 'SQL',           category: 'Разработка', synonyms: ['сиквел', 'скуль'] },
  { skill: 'PostgreSQL',    category: 'Разработка', synonyms: ['постгрес'] },
  { skill: 'MySQL',         category: 'Разработка', synonyms: ['мускул'] },
  { skill: 'MongoDB',       category: 'Разработка', synonyms: ['монго'] },
  { skill: 'Redis',         category: 'Разработка', synonyms: ['редис'] },
  { skill: 'Docker',        category: 'Разработка', synonyms: ['докер'] },
  { skill: 'Kubernetes',    category: 'Разработка', synonyms: ['кубер', 'k8s'] },
  { skill: 'Git',           category: 'Разработка', synonyms: ['гит'] },
  { skill: 'CI/CD',         category: 'Разработка', synonyms: ['cicd'] },
  { skill: 'DevOps',        category: 'Разработка', synonyms: ['девопс'] },
  { skill: 'HTML',          category: 'Разработка', synonyms: ['html5'] },
  { skill: 'CSS',           category: 'Разработка', synonyms: ['css3', 'ксс'] },
  { skill: '1С',            category: 'Разработка', synonyms: ['1с:предприятие', 'одинэс', '1с бухгалтерия'] },
  { skill: 'Android',       category: 'Разработка', synonyms: ['андроид'] },
  { skill: 'iOS',           category: 'Разработка', synonyms: ['айос'] },
  { skill: 'Flutter',       category: 'Разработка', synonyms: ['флаттер'] },
  { skill: 'React Native',  category: 'Разработка', synonyms: ['reactnative', 'реакт натив'] },
  { skill: 'Machine Learning', category: 'Разработка', synonyms: ['мл', 'машинное обучение'] },
  { skill: 'Frontend',      category: 'Разработка', synonyms: ['фронтенд', 'фронтэнд'] },
  { skill: 'Backend',       category: 'Разработка', synonyms: ['бэкенд', 'бэкэнд'] },

  // ===== Дизайн =====
  { skill: 'Figma',         category: 'Дизайн', synonyms: ['фигма'] },
  { skill: 'Photoshop',     category: 'Дизайн', synonyms: ['фотошоп'] },
  { skill: 'Illustrator',   category: 'Дизайн', synonyms: ['иллюстратор'] },
  { skill: 'UI Design',     category: 'Дизайн', synonyms: ['ui', 'юай'] },
  { skill: 'UX Design',     category: 'Дизайн', synonyms: ['ux', 'юкс'] },
  { skill: 'Web Design',    category: 'Дизайн', synonyms: ['веб-дизайн'] },
  { skill: 'Graphic Design', category: 'Дизайн', synonyms: ['графдизайн', 'графика'] },
  { skill: 'Motion Design', category: 'Дизайн', synonyms: ['моушн'] },
  { skill: '3D',            category: 'Дизайн', synonyms: ['3д'] },
  { skill: 'Sketch',        category: 'Дизайн', synonyms: ['скетч'] },
  { skill: 'Prototyping',   category: 'Дизайн', synonyms: ['прототипирование'] },

  // ===== Маркетинг =====
  { skill: 'Marketing',     category: 'Маркетинг', synonyms: ['диджитал маркетинг', 'интернет-маркетинг'] },
  { skill: 'SEO',           category: 'Маркетинг', synonyms: ['сео', 'поисковое продвижение'] },
  { skill: 'SMM',           category: 'Маркетинг', synonyms: ['смм', 'соцсети'] },
  { skill: 'Context Ads',   category: 'Маркетинг', synonyms: ['контекстная реклама', 'яндекс директ'] },
  { skill: 'Targeting',     category: 'Маркетинг', synonyms: ['таргет'] },
  { skill: 'Copywriting',   category: 'Маркетинг', synonyms: ['копирайт'] },
  { skill: 'Email Marketing', category: 'Маркетинг', synonyms: ['рассылки', 'имейл-маркетинг'] },
  { skill: 'Content Marketing', category: 'Маркетинг', synonyms: ['контент-маркетинг', 'контент'] },
  { skill: 'CRM',           category: 'Маркетинг', synonyms: ['сиэрэм'] },
  { skill: 'Branding',      category: 'Маркетинг', synonyms: ['брендинг'] },

  // ===== Финансы =====
  { skill: 'Accounting',    category: 'Финансы', synonyms: ['бухгалтерия', 'бухучет'] },
  { skill: 'Finance',       category: 'Финансы', synonyms: ['финансовое планирование'] },
  { skill: 'Audit',         category: 'Финансы', synonyms: ['внутренний аудит'] },
  { skill: 'Taxes',         category: 'Финансы', synonyms: ['налоги', 'налогообложение'] },
  { skill: 'Investing',     category: 'Финансы', synonyms: ['инвестирование'] },
  { skill: 'Financial Analysis', category: 'Финансы', synonyms: ['финансовый анализ'] },

  // ===== Юриспруденция =====
  { skill: 'Law',           category: 'Юриспруденция', synonyms: ['право', 'юриспруденция'] },
  { skill: 'Lawyer',        category: 'Юриспруденция', synonyms: ['юрист', 'юрисконсульт'] },
  { skill: 'Contracts',     category: 'Юриспруденция', synonyms: ['договорная работа', 'договоры'] },

  // ===== Медицина =====
  { skill: 'Medicine',      category: 'Медицина', synonyms: ['медицина'] },
  { skill: 'Nursing',       category: 'Медицина', synonyms: ['сестринское дело', 'медсестра'] },
  { skill: 'Therapy',       category: 'Медицина', synonyms: ['терапия', 'терапевт'] },
  { skill: 'Dentistry',     category: 'Медицина', synonyms: ['стоматология'] },
  { skill: 'Pharmacy',      category: 'Медицина', synonyms: ['фармация', 'фармацевтика'] },

  // ===== Стройка =====
  { skill: 'Construction',  category: 'Стройка', synonyms: ['стройка', 'строительство'] },
  { skill: 'Electrical',    category: 'Стройка', synonyms: ['электрика', 'электромонтаж'] },
  { skill: 'Welding',       category: 'Стройка', synonyms: ['сварка', 'сварщик'] },
  { skill: 'Estimating',    category: 'Стройка', synonyms: ['смета', 'сметное дело'] },

  // ===== Педагогика =====
  { skill: 'Teaching',      category: 'Педагогика', synonyms: ['педагогика', 'преподавание'] },
  { skill: 'Tutoring',      category: 'Педагогика', synonyms: ['репетиторство', 'репетитор'] },
  { skill: 'Mentoring',     category: 'Педагогика', synonyms: ['наставничество', 'менторство'] },
  { skill: 'Training',      category: 'Педагогика', synonyms: ['тренинги', 'мастер-классы'] },
];

/**
 * Валидация датасета ДО обращения к БД:
 * 1) ровно EXPECTED_SYNONYMS синонимов;
 * 2) синонимы уникальны глобально (иначе семантический поиск станет неоднозначным);
 * 3) синонимы нормализованы (trim + lowercase).
 */
function validateDataset() {
  const seen = new Map();
  let total = 0;
  for (const group of SYNONYM_GROUPS) {
    if (!group.skill || !Array.isArray(group.synonyms) || group.synonyms.length === 0) {
      throw new Error(`Некорректная группа навыка: ${JSON.stringify(group).slice(0, 120)}`);
    }
    for (const raw of group.synonyms) {
      const synonym = String(raw).trim().toLowerCase();
      if (!synonym) throw new Error(`Пустой синоним у навыка "${group.skill}"`);
      total++;
      if (seen.has(synonym)) {
        throw new Error(
          `Дубликат синонима "${synonym}" — "${group.skill}" и "${seen.get(synonym)}"`
        );
      }
      seen.set(synonym, group.skill);
    }
  }
  if (total !== EXPECTED_SYNONYMS) {
    throw new Error(
      `Ожидалось ровно ${EXPECTED_SYNONYMS} синонимов, в датасете — ${total}. ` +
        `Проверьте SYNONYM_GROUPS.`
    );
  }
  return total;
}

async function main() {
  const total = validateDataset();
  const prisma = new PrismaClient();

  console.log('=== BizON v6 — Seed: SkillSynonym (русские синонимы навыков) ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log(`Групп навыков: ${SYNONYM_GROUPS.length}, синонимов: ${total}/${EXPECTED_SYNONYMS}`);
  console.log('');

  const counters = {
    skillsCreated: 0,
    skillsExisting: 0,
    synonymsCreated: 0,
    synonymsSkipped: 0,
    errors: 0,
  };

  let currentGroup = '?';
  try {
    for (const group of SYNONYM_GROUPS) {
      currentGroup = group.skill;
      // 1. Канонический навык: Skill.name имеет @unique → честный upsert.
      let skill = await prisma.skill.findFirst({
        where: { name: { equals: group.skill } },
        select: { id: true, name: true },
      });
      if (!skill) {
        // регистронезависимый повторный поиск (name @unique чувствителен к регистру)
        skill = await prisma.skill.findFirst({
          where: { name: { equals: group.skill.toLowerCase() } },
          select: { id: true, name: true },
        });
      }
      if (!skill) {
        skill = await prisma.skill.create({
          data: { name: group.skill, category: group.category },
          select: { id: true, name: true },
        });
        counters.skillsCreated++;
      } else {
        counters.skillsExisting++;
      }

      // 2. Синонимы: SkillSynonym без unique → дедупликация findFirst (idempotent).
      for (const synonym of group.synonyms.map((s) => s.trim().toLowerCase())) {
        const existing = await prisma.skillSynonym.findFirst({
          where: { skillId: skill.id, synonym },
          select: { id: true },
        });
        if (existing) {
          counters.synonymsSkipped++;
          continue;
        }
        await prisma.skillSynonym.create({
          data: { skillId: skill.id, synonym },
        });
        counters.synonymsCreated++;
      }

      console.log(
        `✅ ${group.skill} (${group.category}): +${counters.synonymsCreated} новых, ` +
          `${counters.synonymsSkipped} пропущено (уже есть)`
      );
    }
  } catch (e) {
    counters.errors++;
    console.error(`❌ Ошибка на группе "${currentGroup}": ${e.message}`);
    throw e;
  } finally {
    await prisma.$disconnect().catch(() => {});
  }

  console.log('\n=== Итог ===');
  console.log(`  Навыков создано:            ${counters.skillsCreated}`);
  console.log(`  Навыков уже существовало:   ${counters.skillsExisting}`);
  console.log(`  Синонимов создано:          ${counters.synonymsCreated}`);
  console.log(`  Синонимов пропущено (есть): ${counters.synonymsSkipped}`);
  console.log(`  Ошибок:                     ${counters.errors}`);
  console.log(`  Всего синонимов в датасете: ${total}`);
  console.log('\n✅ seed-skill-synonyms complete.');
}

if (require.main === module) {
  main()
    .then(() => process.exit(0))
    .catch((e) => {
      console.error('❌ seed-skill-synonyms failed:', e);
      process.exit(1);
    });
}

module.exports = { SYNONYM_GROUPS, EXPECTED_SYNONYMS, validateDataset };
