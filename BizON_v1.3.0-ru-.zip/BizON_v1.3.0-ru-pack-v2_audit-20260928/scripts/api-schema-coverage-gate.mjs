#!/usr/bin/env node
// BizON — API-034 (аудит 22-09-26): измеряемый schema-coverage гейт.
//
// scripts/api-schema-coverage.mjs (29-c) печатает таблицу; этот гейт —
// ЕГО ОГРАНИЧЕНИЕ: CI падает, если покрытие откатилось ниже рампы.
// Рампа: старт с фактического покрытия волны 29-A-redux, +5%/волна —
// порог поднимается вручную по мере миграций (см. docs/audit/MATRIX-22-09-26-RESIDUE.md).
//
// Использование:
//   node scripts/api-schema-coverage-gate.mjs            # сравнить с порогом
//   node scripts/api-schema-coverage-gate.mjs --bump N   # поднять порог до N% (записать)
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const GATE_FILE = path.join(ROOT, 'scripts/.api-schema-coverage-threshold.json');

// Стартовый порог: фактическое покрытие withRoute на момент 29-A-redux.
// withRoute 213/359 ≈ 59.3% — рампа +5%/волна.
const DEFAULT_THRESHOLD = {
  withRoutePct: 59,
  withSchemaPct: 0, // zod-схемы: рампа включается следующей волной
  updatedAt: '29-A-redux',
};

function readThreshold() {
  try {
    return JSON.parse(readFileSync(GATE_FILE, 'utf8'));
  } catch {
    return DEFAULT_THRESHOLD;
  }
}

// === Пересчёт покрытия (та же эвристика, что api-schema-coverage.mjs) ===
function walk(dir, out = []) {
  for (const e of readdirSync(dir)) {
    const p = path.join(dir, e);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, out);
    else if (e === 'route.ts') out.push(p);
  }
  return out;
}
import { readdirSync, statSync } from 'node:fs';

const apiDir = path.join(ROOT, 'src/app/api');
const files = walk(apiDir);
let withRoute = 0;
let withSchema = 0;
for (const f of files) {
  const src = readFileSync(f, 'utf8');
  // та же эвристика, что api-schema-coverage.mjs: withRoute( или withRoute<Generic>(
  const hasWithRoute = /withRoute\s*[<(]/.test(src);
  if (hasWithRoute) withRoute += 1;
  if (hasWithRoute && /(^|[^\w])schema\s*:/.test(src)) withSchema += 1;
}
const routePct = Math.floor((withRoute / files.length) * 100);
const schemaPct = Math.floor((withSchema / files.length) * 100);

const threshold = readThreshold();

// --bump: поднять порог и выйти (используется вручную по итогам волны)
if (process.argv.includes('--bump')) {
  const idx = process.argv.indexOf('--bump');
  const v = Number(process.argv[idx + 1]);
  const next = {
    withRoutePct: Number.isFinite(v) ? v : routePct,
    withSchemaPct: threshold.withSchemaPct ?? 0,
    updatedAt: new Date().toISOString().slice(0, 10),
  };
  writeFileSync(GATE_FILE, JSON.stringify(next, null, 2) + '\n');
  console.log(`порог обновлён: withRoute >= ${next.withRoutePct}%`);
  process.exit(0);
}

console.log(`withRoute: ${withRoute}/${files.length} (${routePct}%) — порог >= ${threshold.withRoutePct}%`);
console.log(`schema:    ${withSchema}/${files.length} (${schemaPct}%) — порог >= ${threshold.withSchemaPct}%`);

let fail = false;
if (routePct < threshold.withRoutePct) {
  console.error(`::error::API-034: покрытие withRoute ${routePct}% ниже порога ${threshold.withRoutePct}% (регресс миграции)`);
  fail = true;
}
if (schemaPct < threshold.withSchemaPct) {
  console.error(`::error::API-034: schema-покрытие ${schemaPct}% ниже порога ${threshold.withSchemaPct}%`);
  fail = true;
}
if (fail) process.exit(1);
console.log('API-034 gate: PASS');
