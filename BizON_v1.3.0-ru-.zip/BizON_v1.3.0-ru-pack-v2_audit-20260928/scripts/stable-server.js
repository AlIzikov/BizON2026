#!/usr/bin/env node
const { spawn } = require('child_process');
const http = require('http');
const PORT = 3000;
const MAX_CONCURRENT = 2;
let activeRequests = 0;
const queue = [];

// Запускаем Next.js на порту 3001
const next = spawn('./node_modules/.bin/next', ['start', '-p', '3001'], {
  cwd: '/home/z/my-project',
  env: { ...process.env, NODE_ENV: 'production', NODE_OPTIONS: '--max-old-space-size=256' },
  stdio: 'pipe',
});
next.stdout.on('data', (d) => process.stdout.write(`[next] ${d}`));
next.stderr.on('data', (d) => process.stderr.write(`[next-err] ${d}`));
next.on('exit', (code) => {
  console.log(`[stable] Next.js exited ${code}, restarting in 3s...`);
  setTimeout(() => process.exit(1), 3000);
});

setTimeout(() => {
  const proxy = http.createServer((req, res) => {
    // ДОБАВЛЯЕМ ЗАГОЛОВКИ для iframe (Z.ai превью)
    res.setHeader('X-Frame-Options', 'ALLOWALL');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Content-Security-Policy', 'frame-ancestors *');

    // Handle OPTIONS preflight
    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    const processRequest = () => {
      activeRequests++;
      const options = {
        hostname: 'localhost',
        port: 3001,
        path: req.url,
        method: req.method,
        headers: { ...req.headers, host: 'localhost:3001' },
      };
      const proxyReq = http.request(options, (proxyRes) => {
        // Копируем заголовки от Next.js, но заменяем проблемные
        const headers = { ...proxyRes.headers };
        headers['x-frame-options'] = 'ALLOWALL';
        headers['access-control-allow-origin'] = '*';
        headers['content-security-policy'] = 'frame-ancestors *';
        
        res.writeHead(proxyRes.statusCode, headers);
        proxyRes.pipe(res);
        proxyRes.on('end', () => {
          activeRequests--;
          if (queue.length > 0) queue.shift()();
        });
      });
      proxyReq.on('error', (e) => {
        console.error('[proxy] error:', e.message);
        res.writeHead(502);
        res.end('Server temporarily unavailable');
        activeRequests--;
        if (queue.length > 0) queue.shift()();
      });
      req.pipe(proxyReq);
    };

    if (activeRequests >= MAX_CONCURRENT) {
      queue.push(processRequest);
    } else {
      processRequest();
    }
  });

  proxy.listen(PORT, '0.0.0.0', () => {
    console.log(`[stable] Proxy on ${PORT} -> Next.js on 3001 (max ${MAX_CONCURRENT} concurrent)`);
  });
}, 5000);
