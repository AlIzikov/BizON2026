// R38 — ONE-OFF (аддитивный, идемпотентный): витрина доверия для QA-аккаунта владельца.
//
// ЗАДАЧА ВЛАДЕЛЬЦА (25-09-26): «раскрой в аккаунте тестирования, что у него есть
// несколько навыков — чтобы проверить, как работает система со стороны работодателя
// и со стороны обычного пользователя».
//
// ЧТО ДЕЛАЕТ:
//   Тест-аккаунт Ивана Петрова (ivan@bizon.ru / password) получает 6 навыков
//   во ВСЕХ жизненных состояниях NFT-навыка:
//     React        — minted, вес 1.0  (прямая связь + общий проект, x1.5 → потолок 1.0)
//     TypeScript   — minted, вес 1.0  (прямая связь)
//     Python       — minted, вес 0.3  (рукопожатие: коллеги вышли из проекта — связь ослабла)
//     Next.js      — eligible, НЕ сминчен (владелец сам проходит минт в UI: «Токенизировать»)
//     PostgreSQL   — 2/3 подтверждений (инкубатор: нужно ещё подтверждение от работодателя)
//     Machine Learning — 0 подтверждений (claimed: только самооценка)
//
// КАНОН-ГАРАНТИИ:
//   • АДДИТИВНОСТЬ: ничего не удаляет и не пересеивает (wipe-сиды при доменных
//     данных запрещены — канон Task 36). Повторный запуск безопасен.
//   • МИНТ ЧЕРЕЗ СЕРВИСЫ: NftSkillsService.requestNftMint → finalizeNftMint,
//     антифрод N1/N2/N4/N5/N6 прогоняется ЧЕСТНО (без обхода).
//   • FR-4: каждое SkillConfirmation ссылается на общий проект обоих.
//   • Честная история рукопожатия: конфирмеры Python вышли из проекта ПОСЛЕ
//     подтверждений (Three States of Exit) — вес ослаб до 0.3, что видно в UI.
//
// ГДЕ СМОТРЕТЬ (см. docs/product/nft-skill-explained.md):
//   • Иван → «NFT-навыки» (вью nft-skills) — записи с весами/статусами.
//   • Наталья/Мария (работодатели) → профиль Ивана — бейджи NFT на навыках.
//   • Наталья → «Найти специалиста» → поиск по навыку «React» → Иван в выдаче.
import { PrismaClient } from '@prisma/client';

// Prisma-клиент приложения резолвится только из корня проекта: создаём свой
// экземпляр (скрипт запускается bun'ом из корня, schema уже сгенерирована).
const db = new PrismaClient();

// === Участники (ID стабильны, из a10-seed-dao.ts / seed.ts) ===
const IVAN = 'cmtlwo7cr000ome6uscm1ipkt';    // Иван Петров, ipScore 26 — ТЕСТ-АККАУНТ (ivan@bizon.ru)
const ELENA = 'cmtlwo7ct000rme6uqv029h4d';   // Елена Волкова, 56 — прямая связь
const DMITRY = 'cmtlwo7ct000sme6u9q92qufb';  // Дмитрий Соколов, 68 — прямая связь
const MARIA = 'cmtlwo7cs000pme6uv7cq0x8k';   // Мария Иванова, 20 — работодатель B (общий проект)
const ALEX = 'cmtlwo7cs000qme6uwusarvfy';    // Алексей Смирнов, 23 — прямая связь
const NATALYA = 'cmtlwo7cx0010me6ur5ca5ubd'; // Наталья Орлова, 64 — работодатель A (прямая связь, уже accepted)
const OLGA = 'cmtlwo7ct000tme6uy3hofs6u';    // Ольга Кузнецова, 15 — НЕ конфирмер (общий «MentorHub» с Иваном → вес был бы 1.0)
const PAVEL = 'cmtlwo7cx000yme6ukrr3cypp';   // Павел Новиков, 20 — рукопожатие (нет общих проектов/связей с Иваном)
const ANNA = 'cmtlwo7cv000vme6uvj0sk0s4';    // Анна Лебедева, 78 — НЕ конфирмер (GreenAI/DataQuality с Иваном → вес был бы 1.0)
const ITRECRUIT = 'cmtlwo7cy0011me6uzwigccty'; // IT Recruiting Pro, 14 — рукопожатие (через Марию/Дмитрия)
const ARHANGEL = 'cmtlwo7cy0012me6u262y48k1';  // Дмитрий Архангельский, 20 — рукопожатие (через Марию/Ольгу)
// Сергей Морозов (cmtlwo7cv000ume6ue1i60c14, ipScore 9) СОЗДАТЕЛЬНО не конфирмер:
// ipScore 9 ≤ 10 → N6 отказал бы; живой кейс антифрода описан в гайде.

const DEMO_PROJECT_TITLE = 'R38 DEMO — Research Sprint';
const CONF_TAG = 'R38 DEMO: подтверждение навыка по итогам совместной работы.';

async function ensureConnection(a: string, b: string, note: string) {
  const existing = await db.connection.findFirst({
    where: { OR: [{ fromUserId: a, toUserId: b }, { fromUserId: b, toUserId: a }] },
  });
  if (!existing) {
    await db.connection.create({
      data: { fromUserId: a, toUserId: b, status: 'accepted' },
    });
    console.log(`  [conn] created accepted ${note}`);
  } else if (existing.status !== 'accepted') {
    await db.connection.update({ where: { id: existing.id }, data: { status: 'accepted' } });
    console.log(`  [conn] pending → accepted ${note}`);
  } else {
    console.log(`  [conn] already accepted ${note}`);
  }
}

async function main() {
  console.log('=== R38 seed: витрина доверия (аддитивно, идемпотентно) ===');

  const ivan = await db.user.findUnique({ where: { id: IVAN }, select: { id: true, name: true, ipScore: true } });
  if (!ivan) throw new Error('Иван не найден — БД не та?');
  console.log(`Тест-аккаунт: ${ivan.name} (ipScore ${ivan.ipScore})`);

  // --- ШАГ 1. Прямые связи Ивана с конфирмерами (N2 direct = 1.0) ---
  console.log('\n[1] Прямые связи (Trust Graph):');
  for (const [id, note] of [
    [ELENA, 'Иван<->Елена'], [DMITRY, 'Иван<->Дмитрий'], [MARIA, 'Иван<->Мария (работодатель B)'],
    [ALEX, 'Иван<->Алексей'],
  ] as const) {
    await ensureConnection(IVAN, id, note);
  }
  // Наталья уже связана с Иваном (исторический accepted) — не трогаем, проверяем:
  const nat = await db.connection.findFirst({
    where: { OR: [{ fromUserId: IVAN, toUserId: NATALYA }, { fromUserId: NATALYA, toUserId: IVAN }], status: 'accepted' },
  });
  console.log(`  [conn] Иван<->Наталья (работодатель A): ${nat ? 'accepted ✓' : 'ОТСУТСТВУЕТ — создам'}`);
  if (!nat) await ensureConnection(IVAN, NATALYA, 'Иван<->Наталья (работодатель A)');
  // ВАЖНО: Иван<->Ольга/Павел/Анна НЕ создаём — они рукопожатия (0.3).

  // --- ШАГ 2. Общие проекты (FR-4 + N5 boost) ---
  console.log('\n[2] Общие проекты:');
  const greenai = await db.project.findFirst({ where: { title: 'GreenAI Platform' } });
  if (!greenai) throw new Error('GreenAI Platform не найден');
  for (const [id, role] of [
    [ELENA, 'Frontend Dev'], [DMITRY, 'DevOps'], [MARIA, 'Product Manager'], [ALEX, 'ML Architect'], [NATALYA, 'Engineering Manager'],
  ] as const) {
    const m = await db.projectMember.findFirst({ where: { projectId: greenai.id, userId: id } });
    if (!m) {
      await db.projectMember.create({ data: { projectId: greenai.id, userId: id, role: 'member', exitState: 'completed', participantRole: role } });
      console.log(`  [proj] ${greenai.title}: + участник (${role})`);
    } else {
      console.log(`  [proj] ${greenai.title}: уже участник (${role})`);
    }
  }

  // Демо-проект для рукопожатий: конфирмеры Python подтвердят навык в нём,
  // затем ВЫЙДУТ (строки ProjectMember удаляются) — «связь ослабла до рукопожатия».
  let sprint = await db.project.findFirst({ where: { title: DEMO_PROJECT_TITLE } });
  if (!sprint) {
    sprint = await db.project.create({
      data: {
        title: DEMO_PROJECT_TITLE,
        description: 'R38 DEMO: краткий исследовательский спринт Ивана с Павлом, IT Recruiting Pro и Дмитрием Архангельским. Участники подтвердили навыки и вышли из проекта (Three States of Exit) — подтверждения остались, граф ослаб до рукопожатий.',
        ownerId: IVAN,
        status: 'completed',
        tags: 'demo,research',
        startedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        completedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      },
    });
    console.log(`  [proj] создан «${DEMO_PROJECT_TITLE}»`);
  } else {
    console.log(`  [proj] «${DEMO_PROJECT_TITLE}» уже существует`);
  }
  // Члены спринта — будущие рукопожатия (на момент подтверждения они ЧЛЕНЫ: честный FR-4).
  for (const id of [PAVEL, ITRECRUIT, ARHANGEL]) {
    const m = await db.projectMember.findFirst({ where: { projectId: sprint.id, userId: id } });
    if (!m) {
      await db.projectMember.create({ data: { projectId: sprint.id, userId: id, role: 'member', exitState: 'completed' } });
    }
  }

  // --- ШАГ 2b. Приватность QA-аккаунта (ТОЛЬКО Иван) ---
  // Канон «privacy by default» (ТЗ «Настройки персональных данных») не трогаем:
  // у новых пользователей профиль скрыт. Но тест-аккаунт владельца должен быть
  // виден работодателю — иначе сторону найма не проверить (privacyBlocked,
  // «Частный профиль»). Это настройка самого пользователя, а не дефолт продукта.
  // email/phone остаются hidden — PII в демо не раскрываем.
  console.log('\n[2b] Приватность Ивана (QA-аккаунт, не дефолт продукта):');
  const { ensurePrivacySettings } = await import('../src/lib/privacy/privacy-service');
  await ensurePrivacySettings(IVAN);
  await db.privacySettings.updateMany({
    where: { userId: IVAN },
    data: {
      showProfileToOthers: true,
      visibilityName: 'registered',
      visibilityTitle: 'registered',
      visibilityEmail: 'hidden',
      visibilityPhone: 'hidden',
    },
  });
  console.log('  [privacy] showProfileToOthers=true, name/title=registered, email/phone=hidden');

  // Чистка тест-мусора QA-аккаунта: навык «ааа» (создан при тестировании
  // «добавить навык») портит витрину. Удаляем только userSkill Ивана.
  const junk = await db.skill.findFirst({ where: { name: 'ааа' } });
  if (junk) {
    const gone = await db.userSkill.deleteMany({ where: { userId: IVAN, skillId: junk.id } });
    if (gone.count > 0) console.log('  [clean] удалён тест-мусор «ааа» из профиля Ивана');
  }

  // HEALING владельцев проектов: продуктовое правило — при создании проекта
  // владелец получает ProjectMember (role 'FOUNDER', projects/route.ts:233).
  // Легаси-сиды создали проекты Ивана без строки членства → recomputeIpScore
  // видел projects=0 (A-компонент обнулён). Восстанавливаем по правилу продукта.
  console.log('\n[2c] Healing членства владельцев проектов Ивана:');
  const ownedProjects = await db.project.findMany({ where: { ownerId: IVAN }, select: { id: true, title: true } });
  for (const p of ownedProjects) {
    const m = await db.projectMember.findFirst({ where: { projectId: p.id, userId: IVAN } });
    if (!m) {
      await db.projectMember.create({ data: { projectId: p.id, userId: IVAN, role: 'FOUNDER', exitState: 'completed' } });
      console.log(`  [heal] «${p.title}»: + ProjectMember FOUNDER (владелец)`);
    }
  }

  // --- ШАГ 3. Навыки Ивана (6 состояний жизненного цикла) ---
  console.log('\n[3] Навыки Ивана:');
  const CATALOG: Record<string, { level: number }> = {
    'React': { level: 4 },
    'TypeScript': { level: 5 },
    'Python': { level: 3 },
    'Next.js': { level: 4 },
    'PostgreSQL': { level: 2 },
    'Machine Learning': { level: 1 },
  };
  const us = new Map<string, string>(); // skillName -> userSkillId
  for (const [name, { level }] of Object.entries(CATALOG)) {
    const skill = await db.skill.findFirst({ where: { name } });
    if (!skill) throw new Error(`Навык «${name}» отсутствует в каталоге`);
    const row = await db.userSkill.upsert({
      where: { userId_skillId: { userId: IVAN, skillId: skill.id } },
      create: { userId: IVAN, skillId: skill.id, level },
      update: { level },
    });
    us.set(name, row.id);
    console.log(`  [skill] ${name} L${level} (${row.id})`);
  }

  // --- ШАГ 4. Подтверждения (FR-4: только через общий проект) ---
  console.log('\n[4] Подтверждения (SkillConfirmation):');
  type Conf = { skill: string; confirmer: string; project: string; comment: string };
  const CONFIRMATIONS: Conf[] = [
    // React — 3 прямых конфирмера (minted 1.0)
    { skill: 'React', confirmer: ELENA, project: greenai.title, comment: CONF_TAG + ' React-фронтенд GreenAI.' },
    { skill: 'React', confirmer: DMITRY, project: greenai.title, comment: CONF_TAG + ' код-ревью компонентов.' },
    { skill: 'React', confirmer: MARIA, project: greenai.title, comment: CONF_TAG + ' поставлял спринты вовремя.' },
    // TypeScript — 3 прямых (minted 1.0)
    { skill: 'TypeScript', confirmer: DMITRY, project: greenai.title, comment: CONF_TAG + ' строгая типизация в проде.' },
    { skill: 'TypeScript', confirmer: MARIA, project: greenai.title, comment: CONF_TAG + ' типизировал API-слой.' },
    { skill: 'TypeScript', confirmer: NATALYA, project: greenai.title, comment: CONF_TAG + ' менторил джунов по TS.' },
    // Next.js — 3 прямых (eligible, минтит владелец сам в UI)
    { skill: 'Next.js', confirmer: ELENA, project: greenai.title, comment: CONF_TAG + ' App Router, SSR.' },
    { skill: 'Next.js', confirmer: DMITRY, project: greenai.title, comment: CONF_TAG + ' деплой и кэширование.' },
    { skill: 'Next.js', confirmer: ALEX, project: greenai.title, comment: CONF_TAG + ' архитектура страниц.' },
    // Python — 3 рукопожатия (minted 0.3 после выхода из спринта).
    // Ольга/Анна НЕ годятся: у них общие проекты с Иваном → вес был бы 1.0.
    { skill: 'Python', confirmer: PAVEL, project: DEMO_PROJECT_TITLE, comment: CONF_TAG + ' ETL-скрипты.' },
    { skill: 'Python', confirmer: ITRECRUIT, project: DEMO_PROJECT_TITLE, comment: CONF_TAG + ' парсинг данных вакансий.' },
    { skill: 'Python', confirmer: ARHANGEL, project: DEMO_PROJECT_TITLE, comment: CONF_TAG + ' автоматизация отчётности.' },
    // PostgreSQL — 2 подтверждения (инкубатор: до NFT не хватает одного)
    { skill: 'PostgreSQL', confirmer: DMITRY, project: greenai.title, comment: CONF_TAG + ' миграции и индексы.' },
    { skill: 'PostgreSQL', confirmer: ELENA, project: greenai.title, comment: CONF_TAG + ' оптимизация запросов.' },
    // Machine Learning — 0 подтверждений (claimed)
  ];

  const projectIdByTitle = new Map<string, string>([
    [greenai.title, greenai.id],
    [DEMO_PROJECT_TITLE, sprint.id],
  ]);

  for (const c of CONFIRMATIONS) {
    const userSkillId = us.get(c.skill)!;
    const projectId = projectIdByTitle.get(c.project)!;
    const existing = await db.skillConfirmation.findFirst({
      where: { userSkillId, confirmerId: c.confirmer, projectId },
    });
    if (!existing) {
      await db.skillConfirmation.create({ data: { userSkillId, confirmerId: c.confirmer, projectId, comment: c.comment } });
      const who: Record<string, string> = {
        [ELENA]: 'Елена', [DMITRY]: 'Дмитрий', [MARIA]: 'Мария', [ALEX]: 'Алексей',
        [NATALYA]: 'Наталья', [PAVEL]: 'Павел', [ITRECRUIT]: 'IT Recruiting Pro', [ARHANGEL]: 'Дм. Архангельский',
      };
      console.log(`  [conf] ${c.skill} <- ${who[c.confirmer] ?? c.confirmer} (${c.project})`);
    }
  }

  // КОРРЕКЦИЯ v2: первый прогон сида ошибочно ставил Python-подтверждения от
  // Ольги и Анны (у них общие проекты с Иваном → минт дал вес 1.0 вместо
  // рукопожатия 0.3). Удаляем ТОЛЬКО свои R38-строки — доменные данные не трогаем.
  const pyId = us.get('Python')!;
  const fixed = await db.skillConfirmation.deleteMany({
    where: { userSkillId: pyId, confirmerId: { in: [OLGA, ANNA] }, comment: { startsWith: 'R38 DEMO:' } },
  });
  if (fixed.count > 0) console.log(`  [fix] удалены ошибочные Python-подтверждения v1: ${fixed.count} (Ольга/Анна → заменены на чистые рукопожатия)`);

  // --- ШАГ 5. Синхронизация счётчиков (как делает confirm-роут) ---
  console.log('\n[5] Синхронизация confirmationsCount / nftEligible:');
  for (const [name, id] of us) {
    const count = await db.skillConfirmation.count({ where: { userSkillId: id } });
    const row = await db.userSkill.update({
      where: { id },
      data: { confirmationsCount: count, nftEligible: count >= 3 },
    });
    console.log(`  [us] ${name}: confirmationsCount=${row.confirmationsCount}, nftEligible=${row.nftEligible}`);
  }

  // HEALING легаси-дрейфа (канон PR #2: «легаси-данные лечатся на лету»):
  // wipe-сиды снесли строки SkillConfirmation, но счётчики confirmationsCount
  // остались (класс дрейфа как в DAO-голосах до PR #1). У тест-аккаунта это
  // «Графический дизайн conf=6» и «Docker conf=4» при 0 реальных подтверждений —
  // UI показывает их «Доступны для минта», а антифрод честно отклоняет.
  // Лечим ВСЕ навыки Ивана пересчётом из фактических строк (не только демо-набор).
  console.log('\n[5b] Healing дрейфа счётчиков Ивана (пересчёт из фактических строк):');
  const allIvanSkills = await db.userSkill.findMany({ where: { userId: IVAN }, select: { id: true, confirmationsCount: true, skill: { select: { name: true } } } });
  for (const s of allIvanSkills) {
    const real = await db.skillConfirmation.count({ where: { userSkillId: s.id } });
    if (real !== s.confirmationsCount) {
      await db.userSkill.update({ where: { id: s.id }, data: { confirmationsCount: real, nftEligible: real >= 3 } });
      console.log(`  [heal] ${s.skill.name}: ${s.confirmationsCount} → ${real} (по факту строк)`);
    }
  }

  // --- ШАГ 6. Выход рукопожатий из демо-проекта (ослаб связи до 0.3) ---
  // Честная история: подтверждения остались, участники вышли (Three States of Exit).
  // После этого canMintNftSkill не видит общего проекта → вес по графу = рукопожатие
  // (общий контакт: Павел↔Алексей/Мария/Дмитрий, IT Recruit↔Мария/Дмитрий, Архангельский↔Мария).
  console.log('\n[6] Выход участников из «Research Sprint» (ослабление до рукопожатия):');
  const exited = await db.projectMember.deleteMany({
    where: { projectId: sprint.id, userId: { in: [PAVEL, ITRECRUIT, ARHANGEL] } },
  });
  console.log(`  [proj] вышло участников: ${exited.count} (подтверждения Python остались как исторический факт)`);

  // КОРРЕКЦИЯ v2: первый прогон сминтил Python с весом 1.0 (Ольга/Анна имели
  // общие проекты). Удаляем СВОЙ артефакт — минт ниже пройдёт заново и честно
  // покажет рукопожатие 0.3.
  const stalePy = await db.nFTSkill.findFirst({ where: { userSkillId: pyId, status: { in: ['pending', 'minted'] } } });
  if (stalePy && stalePy.weight >= 1) {
    await db.nFTSkill.delete({ where: { id: stalePy.id } });
    console.log('  [fix] удалён артефакт v1: Python NFT с весом 1.0 → перезаминчен как рукопожатие');
  }

  // --- ШАГ 7. Минт через СЕРВИСЫ (антифрод N1/N2/N4/N5/N6 честно) ---
  console.log('\n[7] Минт NFT через NftSkillsService (двухшаговый, с антифродом):');
  const { NftSkillsService } = await import('../src/lib/services/nft-skills-service');
  const MINT_TARGETS = ['React', 'TypeScript', 'Python'];
  for (const name of MINT_TARGETS) {
    const userSkillId = us.get(name)!;
    const existingNft = await db.nFTSkill.findFirst({
      where: { userSkillId, status: { in: ['pending', 'minted'] } },
    });
    if (existingNft) {
      console.log(`  [nft] ${name}: уже ${existingNft.status} (weight=${existingNft.weight}) — пропуск`);
      continue;
    }
    const req = await NftSkillsService.requestNftMint(userSkillId, IVAN);
    if (!req.ok) {
      console.error(`  [nft] ${name}: ШАГ 1 отказ — ${req.code}: ${req.reason}`);
      continue;
    }
    console.log(`  [nft] ${name}: pending создан, weight=${req.weight}, confirmer=${req.confirmerId}`);
    console.log(`        XAI: ${req.reason}`);
    const fin = await NftSkillsService.finalizeNftMint(req.nft.id, IVAN);
    if (!fin.ok) {
      console.error(`  [nft] ${name}: ШАГ 2 отказ — ${fin.code}: ${fin.reason}`);
      continue;
    }
    console.log(`  [nft] ${name}: MINTED ✓ tokenId=${fin.nft?.tokenId?.slice(0, 12)}… weight=${fin.weight}`);
  }
  console.log('  [nft] Next.js намеренно НЕ сминчен — владелец проходит минт сам (UI: «Токенизировать»).');
  console.log('  [nft] PostgreSQL на 2/3 — инкубатор: работодателю нужно подтвердить ещё раз.');
  console.log('  [nft] Machine Learning 0/3 — claimed: только самооценка.');

  // --- ШАГ 7b. Пересчёт IP-score по канон-формуле (reputation.ts, FIX-06) ---
  // Сид создал подтверждения напрямую — confirm-роут не запускался, поэтому
  // пересчитываем ipScore/level из агрегатов ЧЕСТНОЙ формулой ТЗ 3.3.1
  // (A проекты ×0.4 + B рейтинг ×0.3 + C подтверждения ×0.2 + D активность ×0.1).
  // При 14 подтверждениях и завершённых проектах Иван выходит на level 'extended'
  // → меню «NFT-навыки» и «DAO» разблокируются (minLevel extended, app-shell).
  console.log('\n[7b] Пересчёт IP-score Ивана (канон-формула):');
  const { recomputeIpScore } = await import('../src/lib/reputation');
  const rep = await recomputeIpScore(IVAN);
  console.log(`  [rep] ipScore=${rep.ipScore}, level=${rep.level}, breakdown=${JSON.stringify(rep.breakdown)}`);
  if (rep.ipScore < 31) {
    console.warn('  [rep] ВНИМАНИЕ: < 31 — меню NFT-навыков останется заблокированным (нужен extended)');
  }

  // --- Итоговая таблица ---
  console.log('\n=== ИТОГ: NFT-навыки Ивана ===');
  const nfts = await db.nFTSkill.findMany({ where: { userId: IVAN }, orderBy: { createdAt: 'asc' } });
  for (const n of nfts) {
    console.log(`  ${n.skillName.padEnd(14)} ${n.status.padEnd(7)} weight=${n.weight}  conf=${n.endorsementsCount}  decay=${n.decayStatus}`);
  }
  console.log('\nГотово. Где смотреть: docs/product/nft-skill-explained.md (раздел «Как проверить вживую»).');
}

main()
  .catch((e) => { console.error('[r38-seed] failed:', e); process.exit(1); })
  .finally(() => db.$disconnect());
