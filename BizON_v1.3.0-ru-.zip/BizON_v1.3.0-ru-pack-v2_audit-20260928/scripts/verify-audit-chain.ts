// =============================================================================
// P0.4 (директива владельца 2026-09-28): стендalone-верификатор hash-chain
// журнала AuditLog. Главный потребитель — restore-тест (restore-db.sh --verify):
// «восстановить из бэкапа в test-БД, проверить целостность (5 таблиц +
// hash-chain AuditLog)».
//
// Логика = верифицирующая часть scripts/repair-audit-chain.ts и
// src/lib/data-vault/audit-log.ts:
//   • v2-записи (prefix 'v2:') — SHA256 от канонического JSON
//     { prevHash, actorId, action, resource, resourceId, metadata, createdAt };
//   • legacy-записи — sha256(join('|')) (Wave 6/S-134);
//   • GENESIS = начало цепочки (первая запись с chainHash).
//
// БД: DATABASE_URL из окружения/.env (PrismaClient) — для проверки
// восстановленной КОПИИ укажите DATABASE_URL на копию:
//   DATABASE_URL="file:/tmp/restore-verify.db" bun scripts/verify-audit-chain.ts
//
// Exit: 0 — цепочка цела; 1 — разрыв/ошибка (restore-тест провален).
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { createHash } from 'node:crypto';

const db = new PrismaClient();
const V2_PREFIX = 'v2:';

function canonicalize(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(',')}]`;
  const entries = Object.entries(value as Record<string, unknown>).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalize(v)}`).join(',')}}`;
}

function expectedChainHashV2(
  prevHash: string,
  row: { actorId: string; action: string; resource: string; resourceId: string | null; metadata: string | null; createdAt: Date },
): string {
  const payload = {
    prevHash,
    actorId: row.actorId,
    action: row.action,
    resource: row.resource,
    resourceId: row.resourceId ?? '',
    metadata: row.metadata ?? '',
    createdAt: row.createdAt.toISOString(),
  };
  return V2_PREFIX + createHash('sha256').update(canonicalize(payload)).digest('hex');
}

function expectedChainHashLegacy(
  prevHash: string,
  row: { actorId: string; action: string; resource: string; resourceId: string | null; metadata: string | null; createdAt: Date },
): string {
  const canonical = [
    prevHash,
    row.actorId,
    row.action,
    row.resource,
    row.resourceId ?? '',
    row.metadata ?? '',
    row.createdAt.toISOString(),
  ].join('|');
  return createHash('sha256').update(canonical).digest('hex');
}

async function main() {
  const total = await db.auditLog.count();
  const rows = await db.auditLog.findMany({
    where: { chainHash: { not: null } },
    orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
  });

  console.log(`[audit-chain] записей в AuditLog: ${total}; с chainHash: ${rows.length}`);
  if (rows.length === 0) {
    console.log('[audit-chain] FAIL: цепочка пуста — верифицировать нечего (бэкап пустой/битый?)');
    process.exit(1);
  }

  let prevHash = 'GENESIS';
  let checked = 0;
  for (const row of rows) {
    const r = {
      actorId: row.actorId,
      action: row.action,
      resource: row.resource,
      resourceId: row.resourceId,
      metadata: row.metadata,
      createdAt: row.createdAt,
    };
    const ok =
      row.chainHash === expectedChainHashV2(prevHash, r) || row.chainHash === expectedChainHashLegacy(prevHash, r);
    if (!ok) {
      console.error(`[audit-chain] FAIL: разрыв цепочки на записи ${row.id} (action=${row.action}, createdAt=${row.createdAt.toISOString()})`);
      console.error(`[audit-chain] ожидался хэш продолжения после ${checked} целых записей; цепочка tamper-evidenced.`);
      process.exit(1);
    }
    prevHash = row.chainHash as string;
    checked++;
  }
  console.log(`[audit-chain] OK: цепочка цела, проверено ${checked}/${rows.length} записей (GENESIS → tail).`);
}

main()
  .catch((e) => {
    console.error('[audit-chain] ОШИБКА:', e instanceof Error ? e.message : e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
