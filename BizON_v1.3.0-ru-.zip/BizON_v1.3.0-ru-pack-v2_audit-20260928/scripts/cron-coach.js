// BizON v6 — Cron: Bizon Coach «вопрос дня» (CoachQuestion)
// Для каждого активного пользователя создаёт CoachQuestion на сегодня,
// если его ещё нет. Вопрос выбирается детерминированно из фиксированного пула:
//   index = hash(userId + 'YYYY-MM-DD') % QUESTIONS.length
// — один и тот же день даёт один и тот же вопрос (стабильно при перезапуске),
// разные дни и пользователи получают разные вопросы.
//
// Запуск:
//   node scripts/cron-coach.js [--active-only]
//
// Cron (ежедневно в 08:00 по серверному времени):
//   crontab -e:
//     0 8 * * *  cd /home/z/my-project && /usr/bin/node scripts/cron-coach.js >> /var/log/bizon-cron.log 2>&1
//
//   pm2 (альтернатива):
//     { name: 'bizon-cron-coach', script: 'scripts/cron-coach.js', cron_restart: '0 8 * * *', autorestart: false }
//
// Активность: флаг --active-only ограничивает рассылку пользователями, у которых
// есть хотя бы одна сессия (Session). По умолчанию обрабатываются все юзеры —
// в текущей схеме User нет поля активности (lastActive/isBlocked отсутствуют).
//
// Идемпотентность: проверяется наличие CoachQuestion за сегодня (UTC) у юзера;
// при повторном запуске в тот же день ничего не создаётся.

const crypto = require('crypto');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

// Фиксированный пул вопросов дня (категории: career | skills | projects | goals)
const QUESTIONS = [
  { category: 'skills',   question: 'Какой навык вы использовали вчера и можете подтвердить примером из работы?' },
  { category: 'skills',   question: 'Какую технологию вы освоили за последний месяц?' },
  { category: 'skills',   question: 'Есть ли навык, который вы заявляете, но давно не применяли?' },
  { category: 'projects', question: 'Какой результат последнего проекта вы можете измерить в цифрах?' },
  { category: 'projects', question: 'Над какой задачей вы работали вчера и что получилось?' },
  { category: 'projects', question: 'Есть ли проект, который вы хотите начать в этом месяце?' },
  { category: 'career',   question: 'Какое карьерное событие последних недель повлияло на вас сильнее всего?' },
  { category: 'career',   question: 'Кого из коллег вы бы назвали подтверждением вашей экспертизы?' },
  { category: 'career',   question: 'Какая роль вам интересна через год — и чего для неё не хватает?' },
  { category: 'goals',    question: 'Какая цель на эту неделю приближает вас к большой цели?' },
  { category: 'goals',    question: 'Что вы сделаете в ближайшие 7 дней для роста профессионального капитала?' },
  { category: 'goals',    question: 'Какой «слепой зоной» в своём развитии вы готовы заняться сейчас?' },
  { category: 'skills',   question: 'Чем вы можете помочь коллеге на этой неделе — и это войдёт в доказательства?' },
  { category: 'projects', question: 'Какой незавершённый проект стоит закрыть или честно поставить на паузу?' },
  { category: 'career',   question: 'Какой отзыв о вашей работе вы хотели бы получить в этом месяце?' },
];

/** Стабильный хеш строки → неотрицательное число (32 бита) */
function stableHash(str) {
  const h = crypto.createHash('sha256').update(str).digest();
  return h.readUInt32BE(0);
}

function todayUTC() {
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setUTCDate(end.getUTCDate() + 1);
  return { start, end };
}

async function main() {
  const activeOnly = process.argv.includes('--active-only');
  const { start, end } = todayUTC();
  const dayKey = start.toISOString().slice(0, 10);

  console.log('=== BizON v6 — Cron: Bizon Coach «вопрос дня» ===');
  console.log(`Время: ${new Date().toISOString()} | День (UTC): ${dayKey}`);
  console.log(`Активные юзеры только (по сессиям): ${activeOnly ? 'да' : 'нет (все)'}`);
  console.log('');

  const users = await prisma.user.findMany({
    where: activeOnly ? { sessions: { some: {} } } : undefined,
    select: { id: true, name: true },
    orderBy: { createdAt: 'asc' },
  });

  if (users.length === 0) {
    console.log('Пользователей не найдено. Выход.');
    return;
  }
  console.log(`Найдено пользователей: ${users.length}\n`);

  let created = 0;
  let skipped = 0;
  let failed = 0;

  for (let i = 0; i < users.length; i++) {
    const user = users[i];
    try {
      // Уже есть вопрос за сегодня?
      const existing = await prisma.coachQuestion.findFirst({
        where: { userId: user.id, createdAt: { gte: start, lt: end } },
        select: { id: true },
      });
      if (existing) {
        skipped++;
        continue;
      }

      // Детерминированный выбор из пула: hash(userId + день)
      const idx = stableHash(`${user.id}|${dayKey}`) % QUESTIONS.length;
      const picked = QUESTIONS[idx];

      await prisma.coachQuestion.create({
        data: {
          userId: user.id,
          question: picked.question,
          category: picked.category,
        },
      });
      created++;
      if (process.env.VERBOSE) {
        console.log(`[${i + 1}/${users.length}] ✅ ${user.name}: (${picked.category}) ${picked.question}`);
      }
    } catch (e) {
      failed++;
      console.error(`[${i + 1}/${users.length}] ❌ ${user.name} — ${e.message}`);
    }
  }

  console.log('\n=== Итог ===');
  console.log(`  Вопросов создано: ${created}`);
  console.log(`  Пропущено (уже есть за ${dayKey}): ${skipped}`);
  console.log(`  Ошибок: ${failed}`);
  console.log(`  Всего пользователей: ${users.length}`);
  console.log(`  Размер пула вопросов: ${QUESTIONS.length}`);
  console.log('\n✅ cron-coach complete.');
}

main()
  .catch((e) => {
    console.error('❌ cron-coach failed:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect().catch(() => {});
  });
