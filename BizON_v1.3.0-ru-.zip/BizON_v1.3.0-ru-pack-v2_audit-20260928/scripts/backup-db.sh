#!/bin/bash
# BizON v6 — Бэкап базы данных (SQLite или PostgreSQL)
#
# Что делает:
#   1. Читает DATABASE_URL из .env (или принимает из окружения).
#   2. SQLite (file:...): sqlite3 .backup (консистентный снапшот, если есть
#      sqlite3) или cp, затем gzip → backups/bizon-YYYYmmdd-HHMMSS.db.gz
#   3. PostgreSQL (postgres://...): pg_dump | gzip → backups/bizon-YYYYmmdd-HHMMSS.sql.gz
#   4. Retention: удаляет бэкапы старше 30 дней (R5-B9: было 7 — расширено до 30,
#      RPO=24ч, хранение 30 дней; см. docs/ops/backup-restore.md).
#
# Запуск:
#   bash scripts/backup-db.sh
#
# Cron (ежедневно в 02:00):
#   crontab -e:
#     0 2 * * *  cd /home/z/my-project && bash scripts/backup-db.sh >> /var/log/bizon-backup.log 2>&1
#
# Восстановление:
#   SQLite:     gunzip -c backups/bizon-XXXX.db.gz > db/custom.db
#   PostgreSQL: gunzip -c backups/bizon-XXXX.sql.gz | psql "$DATABASE_URL"

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

BACKUP_DIR="${BACKUP_DIR:-$PROJECT_DIR/backups}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
ENV_FILE="$PROJECT_DIR/.env"

# --- 1. DATABASE_URL: окружение приоритетнее .env -------------------------
if [ -z "${DATABASE_URL:-}" ] && [ -f "$ENV_FILE" ]; then
  # берём последнюю непустую строку KEY=VALUE (без eval — безопасно)
  DATABASE_URL="$(grep -E '^DATABASE_URL=' "$ENV_FILE" | tail -n 1 | cut -d '=' -f 2- | tr -d '"' | tr -d "'" )"
fi

if [ -z "${DATABASE_URL:-}" ]; then
  echo "ERROR: DATABASE_URL не найден (ни в окружении, ни в $ENV_FILE)" >&2
  exit 1
fi

mkdir -p "$BACKUP_DIR"

# --- 2a. SQLite ------------------------------------------------------------
if [[ "$DATABASE_URL" == file:* ]]; then
  DB_FILE="${DATABASE_URL#file:}"
  # относительный путь — относительно корня проекта
  if [[ "$DB_FILE" != /* ]]; then
    DB_FILE="$PROJECT_DIR/$DB_FILE"
  fi
  DB_FILE="${DB_FILE%%\?*}"   # отрезаем query-параметры (file:./db/custom.db?connection_limit=1)

  if [ ! -f "$DB_FILE" ]; then
    echo "ERROR: SQLite-файл не найден: $DB_FILE" >&2
    exit 1
  fi

  OUT="$BACKUP_DIR/bizon-$TIMESTAMP.db"
  if command -v sqlite3 >/dev/null 2>&1; then
    # .backup даёт консистентный снапшот даже при работающем сервере
    sqlite3 "$DB_FILE" ".backup '$OUT'"
  else
    # P0.4 (2026-09-28): sqlite3 в песочнице нет; cp при активной записи в WAL
    # даёт нецелостную копию. bun:sqlite «VACUUM INTO» = консистентный снапшот
    # (включая WAL-транзакции) тем же механизмом, что и .backup.
    if command -v bun >/dev/null 2>&1; then
      bun -e "const { Database } = require('bun:sqlite');
const src = new Database(process.argv[1], { readonly: true });
src.exec(\"VACUUM INTO '\" + process.argv[2] + \"'\");
src.close();" "$DB_FILE" "$OUT"
    else
      # последний рубеж: cp (ПРИ АКТИВНОЙ ЗАПИСИ ВОЗМОЖНА НЕЦЕЛОСТНАЯ КОПИЯ —
      # не используйте для прод-бэкапов; поставьте sqlite3 или bun)
      cp "$DB_FILE" "$OUT"
    fi
  fi
  gzip -f "$OUT"
  FINAL="$OUT.gz"

  # --- 3. Retention: старше 30 дней (R5-B9: хранение расширено с 7 до 30) ---
  find "$BACKUP_DIR" -name 'bizon-*.db.gz' -type f -mtime +"$RETENTION_DAYS" -delete 2>/dev/null || true
  find "$BACKUP_DIR" -name 'bizon_*.db'   -type f -mtime +"$RETENTION_DAYS" -delete 2>/dev/null || true

  SIZE="$(du -h "$FINAL" | cut -f 1)"
  echo "OK: SQLite-бэкап создан: $FINAL ($SIZE)"
  exit 0
fi

# --- 2b. PostgreSQL --------------------------------------------------------
if [[ "$DATABASE_URL" == postgres://* || "$DATABASE_URL" == postgresql://* ]]; then
  if ! command -v pg_dump >/dev/null 2>&1; then
    echo "ERROR: pg_dump не найден (apt-get install postgresql-client / apk add postgresql-client)" >&2
    exit 1
  fi
  OUT="$BACKUP_DIR/bizon-$TIMESTAMP.sql"
  # NO_OWNER — бэкап восстанавливается без привязки к роли (удобно для контейнеров)
  pg_dump --no-owner --no-privileges --dbname="$DATABASE_URL" > "$OUT"
  gzip -f "$OUT"
  FINAL="$OUT.gz"

  find "$BACKUP_DIR" -name 'bizon-*.sql.gz' -type f -mtime +"$RETENTION_DAYS" -delete 2>/dev/null || true

  SIZE="$(du -h "$FINAL" | cut -f 1)"
  echo "OK: PostgreSQL-бэкап создан: $FINAL ($SIZE)"
  exit 0
fi

echo "ERROR: Неподдерживаемый DATABASE_URL (ожидается file: или postgres://): $DATABASE_URL" >&2
exit 1
