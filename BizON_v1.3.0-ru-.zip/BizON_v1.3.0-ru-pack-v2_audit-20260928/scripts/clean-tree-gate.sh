#!/bin/bash
# =============================================================================
# BizON — clean-tree gate (P1.3, директива владельца 2026-09-28).
#
# «Незакоммиченные изменения блокируют отчёт» — системное правило после потери
# R5-P1/R5-P2 при ролловере песочницы. git log = единственный источник истины.
#
# Использование:
#   bash scripts/clean-tree-gate.sh          # exit 1, если дерево грязное
#   bash scripts/clean-tree-gate.sh --quiet  # только итоговая строка
#
# CI-зеркало: .github/workflows/clean-tree.yml (тот же git status --porcelain).
# Предкоммитный вызов можно добавить в .git/hooks/pre-commit (см. pre-commit.sh).
# =============================================================================
set -uo pipefail
QUIET="${1:-}"

STATUS="$(git status --porcelain 2>/dev/null || true)"

# db/custom.db[-shm|-wal] — средовой шум (SQLite WAL), в правило не входит.
FILTERED="$(printf '%s\n' "$STATUS" | rg -v '^\s*[AM?]+\s+db/custom\.db(-shm|-wal)?$' || true)"

if [ -n "$FILTERED" ]; then
  if [ "$QUIET" != "--quiet" ]; then
    echo "✗ ДЕРЕВО НЕ ЧИСТОЕ — незакоммиченные изменения блокируют отчёт:" >&2
    echo "$FILTERED" >&2
    echo "  → закоммитьте (git add … && git commit) или отбросьте осознанно." >&2
  fi
  exit 1
fi

echo "✓ Дерево чистое — git log = источник истины (правило «commit до отчёта»)."
exit 0
