// W3.1: seed governance-агентов (идемпотентно).
// Запуск: bun scripts/seed-ai-agents.ts
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

const AGENTS = [
  { key: 'co-pilot', name: 'BizON Co-Pilot', autonomyLevel: 1, ownerType: 'system' },
  { key: 'matchmaker', name: 'Matchmaker Agent', autonomyLevel: 1, ownerType: 'system' },
  { key: 'news-scout', name: 'News Scout', autonomyLevel: 1, ownerType: 'system' },
  { key: 'system', name: 'System Agent', autonomyLevel: 1, ownerType: 'system' },
];

async function main() {
  for (const a of AGENTS) {
    await db.aiAgent.upsert({
      where: { key: a.key },
      create: { ...a, version: '1', status: 'active' },
      update: {}, // статус/уровень не перетираем — оператор мог менять
    });
    console.log(`agent ok: ${a.key}`);
  }
  // системная политика автономии: включена (kill-switch выключен)
  await db.aiPolicy.upsert({
    where: { key: 'global_autonomy' },
    create: { key: 'global_autonomy', mode: 'collaborative', enabled: true, rules: '{}' },
    update: { enabled: true },
  });
  console.log('policy ok: global_autonomy (enabled=true)');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
