#!/usr/bin/env bash
# ============================================================================
# BizON → GitHub: зеркало проекта с ЧИСТОЙ историей и БЕЗ секретов.
#
# Зачем зеркало: локальный git содержит старую историю платформы (271 МБ),
# в которой есть секреты (.env, bizon-config.env). В GitHub уходит только
# актуальное состояние проекта — одним снапшот-коммитом и далее синками.
#
# ИСПОЛЬЗОВАНИЕ:
#   bash scripts/github-sync.sh <GITHUB_TOKEN> <REPO_URL>      # пуш/синк
#   CRED_FILE=... bash scripts/github-sync.sh                  # данные из файла
#   DRY_RUN=1 bash scripts/github-sync.sh                      # репетиция без пуша
#
# Файл учётных данных (создаётся ВНЕ проекта, чтобы никогда не закоммититься):
#   /home/z/.bizon-github-credentials   →   GITHUB_TOKEN=ghp_xxx
#                                           REPO_URL=https://github.com/user/bizon.git
# Токен: GitHub → Settings → Developer settings → Fine-grained tokens
#        (Repository access: только bizon; Permissions: Contents = Read and write)
# ============================================================================
set -euo pipefail

SRC="/home/z/my-project"
STAGE="${STAGE_DIR:-/home/z/.bizon-github-stage}"
FILTERS="$SRC/scripts/github-filters.txt"
CRED="${CRED_FILE:-/home/z/.bizon-github-credentials}"
DRY="${DRY_RUN:-0}"

TOKEN="${1:-}"; REPO="${2:-}"
if [[ -z "${TOKEN}" || -z "${REPO}" ]]; then
  if [[ -f "$CRED" ]]; then
    # shellcheck disable=SC1090
    source "$CRED"
    TOKEN="${TOKEN:-${GITHUB_TOKEN:-}}"
    REPO="${REPO:-${REPO_URL:-}}"
  fi
fi
# SSH-режим (git@github.com:...) токена не требует — используется deploy-ключ
if [[ "$DRY" != "1" ]]; then
  if [[ -z "${REPO}" ]]; then
    echo "Ошибка: не задан URL репозитория ($CRED или аргумент)."; exit 1
  fi
  if [[ "$REPO" != git@* && -z "${TOKEN}" ]]; then
    echo "Ошибка: для HTTPS-режима нужен токен (аргумент или GITHUB_TOKEN в $CRED)."; exit 1
  fi
fi

[[ -f "$FILTERS" ]] || { echo "Нет файла фильтров: $FILTERS"; exit 1; }

# 1. Синхронизация зеркала (только то, что разрешено фильтрами)
mkdir -p "$STAGE"
rsync -a --delete --filter="merge $FILTERS" "$SRC/" "$STAGE/"

# 2. Страховка: секретов в зеркале быть не должно даже случайно
find "$STAGE" -maxdepth 4 \( -name ".env" -o -name "bizon-config.env" \
  -o -name "*.tar.gz" -o -name "*.tgz" \) -not -path "*/.git/*" -delete 2>/dev/null || true

# 3. Коммит
cd "$STAGE"
if [[ ! -d .git ]]; then
  git init -q -b main
  git config user.name  "${GIT_AUTHOR_NAME:-BizON Dev}"
  git config user.email "${GIT_AUTHOR_EMAIL:-dev@bizon.local}"
fi
git add -A
if [[ -n "$(git rev-parse -q --verify HEAD)" ]] && git diff --cached --quiet; then
  echo "Изменений с прошлого пуша нет — отправлять нечего."
  exit 0
fi
git commit -qm "BizON sync $(date -u '+%Y-%m-%d %H:%M UTC')"

# 4. Репетиция — дальше не идём
if [[ "$DRY" == "1" ]]; then
  echo "── DRY-RUN: зеркало собрано, пуш НЕ выполнен ──"
  echo "Каталог зеркала: $STAGE"
  echo "Файлов в репозитории: $(git ls-files | wc -l)"
  du -sh "$STAGE" | awk '{print "Размер: " $1}'
  echo "Секреты в зеркале: $( (find . -name '.env' -o -name 'bizon-config.env' | grep -v .git | wc -l) ) (должно быть 0)"
  exit 0
fi

# 5. Пуш (SSH по deploy-ключу или HTTPS по токену)
git remote remove origin 2>/dev/null || true
if [[ "$REPO" == git@* ]]; then
  export GIT_SSH_COMMAND="ssh -i /home/z/.ssh/bizon_github -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new"
  git remote add origin "$REPO"
else
  git remote add origin "https://x-access-token:${TOKEN}@${REPO#https://}"
fi
git push -qu origin main
echo "✅ BizON отправлен в $REPO (ветка main). Файлов: $(git ls-files | wc -l)"
