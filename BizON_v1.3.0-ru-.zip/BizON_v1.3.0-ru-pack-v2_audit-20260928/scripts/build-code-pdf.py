#!/usr/bin/env python3
"""Собрать весь исходный код BizON в один PDF-файл."""
import os
import sys
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor, black, white, grey
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak,
    Preformatted, Table, TableStyle, KeepTogether
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Регистрируем моноширинный шрифт для кода
try:
    pdfmetrics.registerFont(TTFont('DejaVuMono', '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))
    MONO_FONT = 'DejaVuMono'
except:
    MONO_FONT = 'Courier'

try:
    pdfmetrics.registerFont(TTFont('DejaVuSans', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
    SANS_FONT = 'DejaVuSans'
except:
    SANS_FONT = 'Helvetica'

PROJECT_DIR = '/home/z/my-project'
OUTPUT = '/home/z/my-project/download/BizON-source-code.pdf'

# Список файлов — только оригинальные (не shadcn/ui)
FILES_TO_INCLUDE = [
    # Конфигурация
    ('package.json', 'package.json'),
    ('next.config.ts', 'next.config.ts'),
    ('tsconfig.json', 'tsconfig.json'),
    ('.env', '.env'),
    # Prisma
    ('prisma/schema.prisma', 'prisma/schema.prisma'),
    # Lib
    ('src/lib/types.ts', 'src/lib/types.ts'),
    ('src/lib/auth.ts', 'src/lib/auth.ts'),
    ('src/lib/reputation.ts', 'src/lib/reputation.ts'),
    ('src/lib/ai.ts', 'src/lib/ai.ts'),
    ('src/lib/matchmaker.ts', 'src/lib/matchmaker.ts'),
    ('src/lib/api-helpers.ts', 'src/lib/api-helpers.ts'),
    ('src/lib/db.ts', 'src/lib/db.ts'),
    ('src/lib/utils.ts', 'src/lib/utils.ts'),
    # Stores
    ('src/stores/app-store.ts', 'src/stores/app-store.ts'),
    # App
    ('src/app/layout.tsx', 'src/app/layout.tsx'),
    ('src/app/page.tsx', 'src/app/page.tsx'),
    ('src/app/globals.css', 'src/app/globals.css'),
    # API routes
    ('src/app/api/auth/register/route.ts', 'API: /api/auth/register'),
    ('src/app/api/auth/login/route.ts', 'API: /api/auth/login'),
    ('src/app/api/auth/logout/route.ts', 'API: /api/auth/logout'),
    ('src/app/api/auth/me/route.ts', 'API: /api/auth/me'),
    ('src/app/api/users/[id]/route.ts', 'API: /api/users/[id]'),
    ('src/app/api/users/[id]/reputation/route.ts', 'API: /api/users/[id]/reputation'),
    ('src/app/api/users/search/route.ts', 'API: /api/users/search'),
    ('src/app/api/feed/route.ts', 'API: /api/feed'),
    ('src/app/api/posts/route.ts', 'API: /api/posts'),
    ('src/app/api/posts/[id]/like/route.ts', 'API: /api/posts/[id]/like'),
    ('src/app/api/posts/[id]/comment/route.ts', 'API: /api/posts/[id]/comment'),
    ('src/app/api/projects/route.ts', 'API: /api/projects'),
    ('src/app/api/projects/[id]/route.ts', 'API: /api/projects/[id]'),
    ('src/app/api/skills/route.ts', 'API: /api/skills'),
    ('src/app/api/skills/confirm/route.ts', 'API: /api/skills/confirm'),
    ('src/app/api/jobs/route.ts', 'API: /api/jobs'),
    ('src/app/api/jobs/match/route.ts', 'API: /api/jobs/match'),
    ('src/app/api/jobs/[id]/apply/route.ts', 'API: /api/jobs/[id]/apply'),
    ('src/app/api/ai/matchmaker/route.ts', 'API: /api/ai/matchmaker'),
    ('src/app/api/ai/career/route.ts', 'API: /api/ai/career'),
    ('src/app/api/ads/route.ts', 'API: /api/ads'),
    ('src/app/api/connections/route.ts', 'API: /api/connections'),
    ('src/app/api/subscriptions/route.ts', 'API: /api/subscriptions'),
    ('src/app/api/reputation/recalculate/route.ts', 'API: /api/reputation/recalculate'),
    # Components
    ('src/components/theme-provider.tsx', 'theme-provider.tsx'),
    ('src/components/common/trust-badge.tsx', 'common/trust-badge.tsx'),
    ('src/components/common/user-avatar.tsx', 'common/user-avatar.tsx'),
    ('src/components/auth/auth-screen.tsx', 'auth/auth-screen.tsx'),
    ('src/components/shell/app-shell.tsx', 'shell/app-shell.tsx'),
    ('src/components/feed/post-composer.tsx', 'feed/post-composer.tsx'),
    ('src/components/feed/trust-stream.tsx', 'feed/trust-stream.tsx'),
    ('src/components/profile/profile-view.tsx', 'profile/profile-view.tsx'),
    ('src/components/projects/projects-view.tsx', 'projects/projects-view.tsx'),
    ('src/components/jobs/jobs-view.tsx', 'jobs/jobs-view.tsx'),
    ('src/components/ai/matchmaker-view.tsx', 'ai/matchmaker-view.tsx'),
    ('src/components/ai/career-agent-view.tsx', 'ai/career-agent-view.tsx'),
    ('src/components/network/network-view.tsx', 'network/network-view.tsx'),
    ('src/components/settings/settings-view.tsx', 'settings/settings-view.tsx'),
    ('src/components/settings/subscription-view.tsx', 'settings/subscription-view.tsx'),
    # Scripts
    ('scripts/seed.ts', 'scripts/seed.ts'),
    ('scripts/dev-prod.js', 'scripts/dev-prod.js'),
]

# Стили
styles = getSampleStyleSheet()
title_style = ParagraphStyle(
    'CustomTitle', parent=styles['Title'],
    fontName=SANS_FONT, fontSize=24, leading=30,
    alignment=TA_CENTER, spaceAfter=20, textColor=HexColor('#101820')
)
subtitle_style = ParagraphStyle(
    'CustomSubtitle', parent=styles['Normal'],
    fontName=SANS_FONT, fontSize=14, leading=18,
    alignment=TA_CENTER, spaceAfter=10, textColor=HexColor('#555555')
)
section_style = ParagraphStyle(
    'Section', parent=styles['Heading1'],
    fontName=SANS_FONT, fontSize=18, leading=22,
    alignment=TA_LEFT, spaceBefore=10, spaceAfter=10,
    textColor=HexColor('#F59E0B'),
    keepWithNext=True,
)
file_header_style = ParagraphStyle(
    'FileHeader', parent=styles['Heading2'],
    fontName=SANS_FONT, fontSize=12, leading=16,
    alignment=TA_LEFT, spaceBefore=12, spaceAfter=6,
    textColor=HexColor('#101820'),
    backColor=HexColor('#FFF7E6'),
    borderPadding=6,
    keepWithNext=True,
)
code_style = ParagraphStyle(
    'Code', parent=styles['Code'],
    fontName=MONO_FONT, fontSize=7, leading=9,
    leftIndent=6, rightIndent=6,
    backColor=HexColor('#F5F5F5'),
    borderPadding=8,
    spaceBefore=4, spaceAfter=8,
    textColor=HexColor('#101820'),
)
small_style = ParagraphStyle(
    'Small', parent=styles['Normal'],
    fontName=SANS_FONT, fontSize=10, leading=14,
    textColor=HexColor('#666666'),
    alignment=TA_CENTER,
)

def escape_xml(text):
    """Экранировать XML-символы для ReportLab Paragraph."""
    text = text.replace('&', '&amp;')
    text = text.replace('<', '&lt;')
    text = text.replace('>', '&gt;')
    return text

def add_footer(canvas, doc):
    """Подвал с номером страницы."""
    canvas.saveState()
    canvas.setFont(SANS_FONT, 9)
    canvas.setFillColor(HexColor('#999999'))
    canvas.drawRightString(A4[0] - 2*cm, 1*cm, f'Стр. {doc.page}')
    canvas.drawString(2*cm, 1*cm, 'BizON — Маяк в цифровом мире · v10.0 MVP')
    canvas.setStrokeColor(HexColor('#EEEEEE'))
    canvas.line(2*cm, 1.5*cm, A4[0] - 2*cm, 1.5*cm)
    canvas.restoreState()

def get_file_emoji(rel_path):
    """Иконка-эмодзи по типу файла (текстом, не emoji)."""
    if rel_path.endswith('.prisma'):
        return '[DB]'
    if rel_path.endswith('.css'):
        return '[CSS]'
    if rel_path.endswith('.json'):
        return '[JSON]'
    if rel_path.endswith('.ts') and '/api/' in rel_path:
        return '[API]'
    if rel_path.endswith('.ts'):
        return '[TS]'
    if rel_path.endswith('.tsx'):
        return '[TSX]'
    if rel_path.endswith('.js'):
        return '[JS]'
    return '[FILE]'

def build_pdf():
    doc = SimpleDocTemplate(
        OUTPUT, pagesize=A4,
        leftMargin=1.5*cm, rightMargin=1.5*cm,
        topMargin=1.8*cm, bottomMargin=2*cm,
        title='BizON — Исходный код',
        author='BizON Systems',
        subject='Исходный код приложения BizON v10.0 MVP',
        creator='Z.ai',
    )

    story = []

    # Cover
    story.append(Spacer(1, 4*cm))
    story.append(Paragraph('BizON', title_style))
    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph('Маяк в цифровом мире', subtitle_style))
    story.append(Spacer(1, 2*cm))
    story.append(Paragraph('Полный исходный код приложения', subtitle_style))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph('v10.0 MVP · Фаза 1 · © BizON Systems 2025', small_style))
    story.append(PageBreak())

    # Оглавление
    story.append(Paragraph('Содержание', section_style))
    story.append(Spacer(1, 0.5*cm))
    toc_data = [['#', 'Файл', 'Тип']]
    for i, (rel_path, display_name) in enumerate(FILES_TO_INCLUDE, 1):
        emoji = get_file_emoji(rel_path)
        toc_data.append([str(i), display_name, emoji])
    toc_table = Table(toc_data, colWidths=[1*cm, 12*cm, 3*cm])
    toc_table.setStyle(TableStyle([
        (('FONT', (0, 0), (-1, 0), SANS_FONT, 10)),
        ('BACKGROUND', (0, 0), (-1, 0), HexColor('#F59E0B')),
        ('FONT', (0, 1), (-1, -1), SANS_FONT, 9),
        ('TEXTCOLOR', (0, 1), (-1, -1), HexColor('#333333')),
        ('ALIGN', (0, 0), (0, -1), 'CENTER'),
        ('ALIGN', (2, 0), (2, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, HexColor('#FFF7E6')]),
        ('GRID', (0, 0), (-1, -1), 0.25, HexColor('#CCCCCC')),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
    ]))
    story.append(toc_table)
    story.append(PageBreak())

    # Содержимое
    story.append(Paragraph('Исходный код', section_style))
    story.append(Spacer(1, 0.3*cm))

    total_lines = 0
    for i, (rel_path, display_name) in enumerate(FILES_TO_INCLUDE, 1):
        full_path = os.path.join(PROJECT_DIR, rel_path)
        if not os.path.exists(full_path):
            story.append(Paragraph(f'[{i}] {display_name} (файл не найден)', file_header_style))
            continue
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            content = f'// Ошибка чтения файла: {e}'

        line_count = content.count('\n') + 1
        total_lines += line_count

        # Заголовок файла
        size_kb = os.path.getsize(full_path) / 1024
        header_text = f'[{i}] {display_name} · {line_count} строк · {size_kb:.1f} КБ'
        story.append(Paragraph(escape_xml(header_text), file_header_style))

        # Код (Preformatted — сохраняет форматирование)
        # Делим длинные файлы на части по ~150 строк
        lines = content.split('\n')
        chunk_size = 200
        for chunk_start in range(0, len(lines), chunk_size):
            chunk = '\n'.join(lines[chunk_start:chunk_start + chunk_size])
            story.append(Preformatted(chunk, code_style))

        story.append(Spacer(1, 0.4*cm))

    # Итоги
    story.append(PageBreak())
    story.append(Paragraph('Итоги', section_style))
    story.append(Spacer(1, 0.5*cm))
    summary = f'''
    <para align="center">
    <b>Всего файлов:</b> {len(FILES_TO_INCLUDE)}<br/>
    <b>Всего строк кода:</b> {total_lines:,}<br/>
    <b>Стек:</b> Next.js 16 · TypeScript · Prisma · shadcn/ui · Tailwind CSS 4<br/>
    <b>AI:</b> z-ai-web-dev-sdk (LLM карьерный агент, модерация)<br/>
    <b>БД:</b> SQLite (для MVP; готова к миграции на PostgreSQL)<br/><br/>
    <b>Структура:</b><br/>
    • API routes: 25 endpoints<br/>
    • React components: 16 (без shadcn/ui)<br/>
    • Prisma models: 15 таблиц<br/>
    • Library functions: 7 модулей<br/><br/>
    <b>Философия:</b> BizON — не сеть контактов, а сеть правды.<br/>
    Маяк в цифровом море, который освещает реальные действия<br/>
    и согревает теплом подлинного доверия.
    </para>
    '''
    story.append(Paragraph(summary, ParagraphStyle(
        'Summary', parent=styles['Normal'],
        fontName=SANS_FONT, fontSize=11, leading=18,
        alignment=TA_CENTER, textColor=HexColor('#333333'),
    )))

    doc.build(story, onFirstPage=add_footer, onLaterPages=add_footer)
    print(f'✓ PDF создан: {OUTPUT}')
    print(f'  Размер: {os.path.getsize(OUTPUT) / 1024:.1f} КБ')
    print(f'  Файлов: {len(FILES_TO_INCLUDE)}')
    print(f'  Строк кода: {total_lines:,}')

if __name__ == '__main__':
    build_pdf()
