// =============================================================================
// CLI: АКТИВАЦИЯ ИНТЕГРАЦИИ (П4 Фаза 1, п.1.4 директивы).
//
// Тот же контракт, что POST /api/admin/integrations/activate: гейты
// (адаптер реализован, env заданы) → атомарный переключатель ровно-1-активный
// → AuditLog INTEGRATION_ACTIVATED. Отказ — честная причина, exit 1.
//
// Запуск: bun scripts/activate-integration.ts <code>
// =============================================================================
import { db } from '../src/lib/db';
import { AuditLog } from '../src/lib/data-vault/audit-log';
import { isHubCategory } from '../src/lib/hubs/core';
import { HUB_REGISTRY } from '../src/lib/hubs/registry';

async function main() {
  const code = process.argv[2]?.trim().toLowerCase();
  if (!code) {
    console.error('Использование: bun scripts/activate-integration.ts <code>   (например: console-analytics)');
    process.exit(1);
  }

  const port = await db.externalServicePort.findUnique({ where: { code } });
  if (!port) {
    console.error(`[activate] 404: порт «${code}» не найден в реестре`);
    process.exit(1);
  }
  if (!isHubCategory(port.category)) {
    console.error(`[activate] категория «${port.category}» вне реестра хабов`);
    process.exit(1);
  }
  if (port.isActive) {
    console.error(`[activate] 422: порт «${code}» уже активен в категории «${port.category}»`);
    process.exit(1);
  }

  const entry = HUB_REGISTRY[port.category];
  if (!entry.adapters[port.code]) {
    console.error(`[activate] 501 ADAPTER_NOT_IMPLEMENTED: у порта «${code}» нет адаптера в карте хаба — активация заблокирована (ADR-007). Категория осталась на прежнем активном порте.`);
    process.exit(1);
  }
  const missing = entry.requiredEnv(port).filter((name) => !process.env[name]?.trim());
  if (missing.length > 0) {
    console.error(`[activate] 501 ENV_MISSING: не заданы ${missing.join(', ')} (секреты — только env, ADR-007). Категория осталась на прежнем активном порте.`);
    process.exit(1);
  }

  const previous = await db.externalServicePort.findFirst({
    where: { category: port.category, isActive: true },
    select: { code: true },
  });

  const updated = await db.$transaction(async (tx) => {
    await tx.externalServicePort.updateMany({ where: { category: port.category, isActive: true }, data: { isActive: false } });
    return tx.externalServicePort.update({ where: { code }, data: { isActive: true } });
  });

  AuditLog.logSecurity('INTEGRATION_ACTIVATED', {
    actorId: 'admin:cli',
    resource: 'ExternalServicePort',
    resourceId: updated.id,
    metadata: { code, category: updated.category, previousCode: previous?.code ?? null, via: 'cli' },
  });

  console.log(`[activate] OK: «${code}» активен в категории «${updated.category}» (был активен: ${previous?.code ?? '—'})`);
  await db.$disconnect();
  process.exit(0);
}

main();
