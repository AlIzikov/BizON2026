#!/usr/bin/env bash
# BizON dev-server watchdog — Wave-7 гигиена конвейера.
# Протокол v2 §3/§19 конкурс: A (simplest: bash-цикл) / B (pm2-supervisor: новая зависимость,
# §14 запрещает без нужды) / C (systemd-docker: недоступно в песочнице). ВЫБРАН A:
# операционная сложность минимальна, закрывает ~80% инцидентов (краш/зависание процесса).
# ЧЕСТНАЯ ГРАНИЦА: сам watchdog не переживает rollover сессии песочницы — тогда ручной рестарт.
# Правило рестарта: ДВА подряд неуспешных probe с интервалом 30с (не убивать долгую компиляцию);
# 500 (ошибка компиляции) НЕ рестартует — рестарт не чинит код, только логирует.
cd "$(dirname "$0")/.."
fails=0
while true; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --noproxy '*' --max-time 10 http://localhost:3000/ 2>/dev/null)
  exit=$?
  if [ "$exit" -ne 0 ] || [ "$code" = "000" ]; then
    fails=$((fails + 1))
    echo "[$(date '+%F %T')] watchdog: probe failed (exit=$exit code=$code, streak=$fails)" >> dev.log
    if [ "$fails" -ge 2 ]; then
      echo "[$(date '+%F %T')] watchdog: restarting dev server" >> dev.log
      pkill -f "next dev" 2>/dev/null; pkill -f "bun run dev" 2>/dev/null; sleep 2
      (nohup bun run dev >> dev.log 2>&1 &)
      fails=0
    fi
  elif [ "$code" = "500" ]; then
    echo "[$(date '+%F %T')] watchdog: 500 (ошибка компиляции/кода — рестарт не поможет, смотри dev.log)" >> dev.log
    fails=0
  else
    fails=0
  fi
  sleep 30
done
