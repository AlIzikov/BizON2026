// FIX-08 — ONE-OFF: пометить все СУЩЕСТВУЮЩИЕ пользователи как emailVerified=true.
//
// Зачем: колонка User.emailVerified добавлена с default(false). Демо-пользователи
// (Ivan Petrov и др.) созданы до появления верификации — без этого скрипта они бы
// получили 403 «Подтвердите email» на пополнении люменов, что ломает demo UX.
// Все новые пользователи проходят реальную верификацию через письмо
// (/api/auth/verify-email) и создаются с emailVerified=false.
//
// Запуск: bun scripts/mark-existing-verified.ts  (идемпотентен: updateMany)
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

async function main() {
  const res = await db.user.updateMany({
    where: { emailVerified: false },
    data: { emailVerified: true },
  });
  console.log(`[mark-existing-verified] users marked emailVerified=true: ${res.count}`);
}

main()
  .catch((e) => {
    console.error('[mark-existing-verified] failed:', e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
