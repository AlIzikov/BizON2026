// =============================================================================
// P0.3 (директива владельца 2026-09-28): РОТАЦИЯ ПАРОЛЕЙ ДЕМО-АККАУНТОВ.
//
// Проблема (§10 аудит-пакета): пароли всех демо-точек входа были
// документированы в репо (@bizon.ru → «password», @bizon.demo →
// «Pilot-2026!Demo»). Если preview-URL где-то засветился — вход во все демо.
//
// Что делает скрипт (одна команда — полная ротация):
//   1. Собирает адресатов: реестр DEMO_ACCOUNTS (@bizon.ru) + все живые
//      пользователи @bizon.demo из БД (email дешифруется текущим ключом).
//   2. Генерирует для каждого КРИПТОСЛУЧАЙНЫЙ пароль (32 символа,
//      crypto.getRandomValues → base64url; никаких словарей и шаблонов).
//   3. Эон-ремонт: если emailHash от легаси-ключа — восстанавливает
//      идентичность (emailHash/emailEncrypted текущим ключом) по email
//      из реестра/дешифровки (прецедент: FIX-2026-09-15c).
//   4. Ставит passwordHash (PBKDF2-SHA256 600k — схема AuthService.register).
//   5. РЕВОКУЕТ все активные сессии каждого ротированного аккаунта —
//      угнанная сессия не переживает ротацию (суть ротации, не опция).
//   6. Пишет пароли в .env → BIZON_DEMO_PASSWORDS (base64url JSON
//      {email: password}). В коде/git/worklog/логах паролей НЕТ.
//   7. AuditLog action='demo_passwords.rotate' (hash-chain v2) — количество
//      и дата; WITHOUT passwords/emails.
//   8. Верифицирует: lookup по emailHash текущего ключа + контроль пароля
//      (та же схема, что AuthService.login) — exit 1 при любом расхождении.
//
// Канал передачи HR-компаниям: НЕ preview-URL и НЕ почта — защищённый канал
// (см. docs/pilot/demo-access.md). После reset-demo-data/re-seed запустить
// ротацию ЗАНОВО (seed создаёт аккаунты с временным сид-паролем).
//
// Запуск: bun scripts/reset-demo-passwords.ts
// Проверка: bun scripts/ops-board.ts (матрица логинов из .env)
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { encrypt, hashEmail, tryDecrypt } from '../src/lib/security/crypto';
import { DEMO_ACCOUNTS } from '../src/lib/demo-accounts';
import { canonicalizeJson, hashAuditPayload } from '../src/lib/security/canonical-json';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const db = new PrismaClient();
const V2_PREFIX = 'v2:';

interface Target {
  email: string;
  name: string;
  userId: string;
  repaired: boolean; // идентичность восстановлена текущим ключом в этом прогоне
}

/** Криптослучайный пароль 32 символа (24 байта → base64url). */
function generatePassword(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/** PBKDF2-SHA256 600k — формат pbkdf2$iter$salt$hash (канон AuthService). */
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, [
    'deriveBits',
  ]);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 600_000, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const saltHex = Array.from(salt)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  const hashHex = Array.from(new Uint8Array(derivedBits))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  return `pbkdf2$600000$${saltHex}$${hashHex}`;
}

/** Контроль пароля — та же схема, что verifyPassword (AuthService.login). */
async function verifyPasswordInline(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
  const iterations = Number(parts[1]);
  const salt = Uint8Array.from(parts[2].match(/.{2}/g)!.map((b) => parseInt(b, 16)));
  const expected = parts[3];
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, [
    'deriveBits',
  ]);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const actual = Array.from(new Uint8Array(derivedBits))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  if (actual.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

/** AuditLog с продолжением hash-chain (v2-канон, транзакция — data-vault/audit-log.ts). */
async function writeAudit(entry: {
  actorId: string;
  action: string;
  resource: string;
  resourceId: string;
  metadata: Record<string, unknown>;
}): Promise<void> {
  await db.$transaction(async (tx) => {
    const last = await tx.auditLog.findFirst({
      where: { chainHash: { not: null } },
      orderBy: { createdAt: 'desc' },
      select: { chainHash: true },
    });
    const prevHash = last?.chainHash ?? 'GENESIS';
    const createdAt = new Date(Date.now());
    const metadataJson = canonicalizeJson(entry.metadata);
    const chainHash =
      V2_PREFIX +
      hashAuditPayload({
        prevHash,
        actorId: entry.actorId,
        action: entry.action,
        resource: entry.resource,
        resourceId: entry.resourceId,
        metadata: metadataJson,
        createdAt: createdAt.toISOString(),
      });
    await tx.auditLog.create({
      data: {
        actorId: entry.actorId,
        action: entry.action,
        resource: entry.resource,
        resourceId: entry.resourceId,
        ip: null,
        metadata: metadataJson,
        createdAt,
        chainHash,
      },
    });
  });
}

/** Upsert строки KEY=VALUE в .env (значение не печатается). */
function upsertEnv(key: string, value: string): void {
  const envPath = resolve(process.cwd(), '.env');
  let content = '';
  try {
    content = readFileSync(envPath, 'utf8');
  } catch {
    /* файла нет — создадим */
  }
  const lines = content.split('\n');
  const idx = lines.findIndex((l) => l.startsWith(`${key}=`));
  if (idx >= 0) lines[idx] = `${key}=${value}`;
  else lines.push(`${key}=${value}`);
  writeFileSync(envPath, lines.join('\n').replace(/\n*$/, '\n'));
}

function base64urlJson(obj: Record<string, string>): string {
  const json = JSON.stringify(obj);
  let bin = '';
  for (const ch of json) bin += String.fromCharCode(ch.charCodeAt(0));
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function main() {
  console.log('[demo-rotate] P0.3: ротация паролей демо-аккаунтов…');
  const passwords: Record<string, string> = {};
  const targets = new Map<string, Target>();
  const failed: string[] = [];

  // --- 1. Реестр @bizon.ru: hash-lookup текущим ключом, эон-фолбэк по имени ---
  for (const acc of DEMO_ACCOUNTS) {
    let user = await db.user.findFirst({
      where: { emailHash: hashEmail(acc.email), deletedAt: null },
      select: { id: true, name: true },
      orderBy: { createdAt: 'asc' },
    });
    let repaired = false;
    if (!user) {
      const candidates = await db.user.findMany({
        where: { name: acc.name, deletedAt: null },
        select: { id: true, name: true },
        orderBy: { createdAt: 'asc' },
      });
      if (candidates.length > 1) {
        console.warn(`  ⚠ дубликат имени «${acc.name}» (${candidates.length}) — берём самый старый`);
      }
      user = candidates[0] ?? null;
      repaired = user !== null;
    }
    if (!user) {
      console.error(`  НЕ НАЙДЕН: ${acc.email} (${acc.name})`);
      failed.push(acc.email);
      continue;
    }
    targets.set(acc.email, { email: acc.email, name: acc.name, userId: user.id, repaired });
  }

  // --- 2. Все живые @bizon.demo из БД (дешифровка текущим ключом) ---
  const allUsers = await db.user.findMany({
    where: { emailEncrypted: { not: null }, deletedAt: null },
    select: { id: true, name: true, emailEncrypted: true },
  });
  for (const u of allUsers) {
    const email = tryDecrypt(u.emailEncrypted as string);
    if (!email || !email.endsWith('@bizon.demo')) continue;
    if (targets.has(email)) continue;
    targets.set(email, { email, name: u.name, userId: u.id, repaired: false });
  }

  console.log(`[demo-rotate] адресатов: ${targets.size} (@bizon.ru реестр + @bizon.demo из БД)`);

  // --- 3. Ротация: новый пароль + эон-ремонт идентичности + revoke сессий ---
  for (const t of targets.values()) {
    const pw = generatePassword();
    const data: { passwordHash: string; emailHash?: string; emailEncrypted?: string } = {
      passwordHash: await hashPassword(pw),
    };
    if (t.repaired) {
      data.emailHash = hashEmail(t.email);
      data.emailEncrypted = encrypt(t.email);
    }
    await db.user.update({ where: { id: t.userId }, data });
    // Ревокация сессий: угнанная/оставленная сессия не переживает ротацию.
    const revoked = await db.session.deleteMany({ where: { userId: t.userId } });
    passwords[t.email] = pw;
    void revoked;
  }

  // --- 4. .env: BIZON_DEMO_PASSWORDS (значения только здесь) ---
  upsertEnv('BIZON_DEMO_PASSWORDS', base64urlJson(passwords));
  console.log(`[demo-rotate] .env: BIZON_DEMO_PASSWORDS обновлён (${Object.keys(passwords).length} записей); значения НЕ печатаются`);

  // --- 5. AuditLog (hash-chain продолжен) ---
  await writeAudit({
    actorId: 'system',
    action: 'demo_passwords.rotate',
    resource: 'user',
    resourceId: 'demo-batch',
    metadata: {
      reason: 'P0.3: документированные пароли демо-аккаунтов ротированы (§10 аудита)',
      count: Object.keys(passwords).length,
      sessionsRevoked: true,
      rotatedAt: new Date().toISOString(),
    },
  });

  // --- 6. Верификация: lookup по текущему ключу + контроль пароля ---
  let verified = 0;
  for (const [email, pw] of Object.entries(passwords)) {
    const u = await db.user.findUnique({
      where: { emailHash: hashEmail(email) },
      select: { id: true, passwordHash: true },
    });
    if (u && targets.get(email)?.userId === u.id && (await verifyPasswordInline(pw, u.passwordHash))) {
      verified++;
    } else {
      failed.push(`${email} (verify после ротации)`);
    }
  }
  console.log(`[demo-rotate] верифицировано: ${verified}/${targets.size}`);

  // --- 7. Контроль: демонстрационные входы работоспособны (живой API, если поднят) ---
  if (verified === targets.size && targets.size > 0) {
    console.log('[demo-rotate] ГОТОВО. Передача паролей HR — ТОЛЬКО защищённым каналом (docs/pilot/demo-access.md).');
    console.log('[demo-rotate] Напоминание: после reset-demo-data/re-seed запустить ротацию заново.');
  } else {
    console.error(`[demo-rotate] ПРОБЛЕМЫ: ${failed.join(', ')}`);
    process.exit(1);
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
