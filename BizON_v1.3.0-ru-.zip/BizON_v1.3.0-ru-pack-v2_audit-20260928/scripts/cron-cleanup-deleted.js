// BizON — Cron: cleanup soft-deleted users (Этап 8.2 — DEL)
//
// Запуск:
//   BIZON_ENCRYPTION_KEY=... node scripts/cron-cleanup-deleted.js
//
// Рекомендуется ежедневный запуск через cron или pm2:
//   crontab -e:
//     0 3 * * *  cd /home/z/my-project && BIZON_ENCRYPTION_KEY=... /usr/bin/node scripts/cron-cleanup-deleted.js >> /var/log/bizon-cleanup.log 2>&1
//
//   pm2 ecosystem.config.cjs:
//     {
//       name: 'bizon-cron-cleanup',
//       script: 'scripts/cron-cleanup-deleted.js',
//       cron_restart: '0 3 * * *',
//       autorestart: false,
//       env: { BIZON_ENCRYPTION_KEY: '...' },
//     }
//
// Что делает:
//   1. Находит всех пользователей с deletedAt < (now - 30 дней)
//   2. Физически удаляет их запись (каскад через onDelete: Cascade на связанных
//      моделях — skills, posts, comments, connections, и т.д.)
//   3. Логирует удаление в AuditLog (152-ФЗ ст. 19 — факт обработки PII)
//
// Принципы:
//   - FAIL-OPEN: ошибка удаления одного пользователя не прерывает других
//   - Идемпотентность: повторный запуск безопасен (нет записей — нет действий)
//   - Сухой запуск (DRY_RUN=1): только логирует, не удаляет — для тестирования
//
// Примечание по связям/подтверждениям:
//   После удаления User-записи срабатывают onDelete правила:
//     • Cascade — все записи, где user — автор/владелец, удаляются
//     • SetNull — все записи, где user — ссылка, но не критичная, обнуляются
//   Это сохраняет целостность графа доверия (другие пользователи сохраняют
//   свои подтверждения, но без автора).
//
// === R5-C3 (tombstone) ===
//   Дефект (инвентаризация R5-1): Endorsement.author/subject — required-связи
//   БЕЗ onDelete → дефолт Restrict → prisma.user.delete падал P2003 для любого,
//   кто давал/получал endorsements. JobApplication.user — Cascade (отклик пропал
//   бы вместе с аккаунтом), но по директиве отклики СОХРАНЯЮТСЯ для компании.
//   РЕШЕНИЕ: перед user.delete выполняются те же шаги, что и в
//   DeletionService.anonymizeForPurge (src/lib/services/deletion-service.ts):
//     • Endorsement (author/subject) → репойнт на системного юзера-надгробие
//     • JobApplication.userId → надгробие (отклик жив, author → «Удалённый»)
//     • ResonanceProfile (θ) → deleteMany
//     • NFTSkill → status='revoked' + revokedAt (SBT-пометка; burn on-chain —
//       R3-runtime)
//   + запись в DeletedAccount (mode='hard_purge', summaryJson).
//   Скрипт standalone (CommonJS, не импортирует TS-сервисы) — шаги ДУБЛИРУЮТСЯ
//   здесь: изменения держать СИНХРОННО в deletion-service.ts и этом файле
//   (константы tombstone — посимвольный паритет).

const { PrismaClient } = require('@prisma/client');
const crypto = require('node:crypto');

// === R5-C3: tombstone-константы — ПАРИТЕТ с deletion-service.ts ===
const TOMBSTONE_SEED = 'tombstone@deleted.bizon.internal';
const TOMBSTONE_HMAC_KEY = 'bizon:deletion-tombstone:v1'; // фиксированный ключ (не секрет) — стабилен между окружениями
const TOMBSTONE_NAME = 'Удалённый пользователь';
const TOMBSTONE_PASSWORD = 'tombstone-no-login';

function tombstoneEmailHash() {
  return crypto.createHmac('sha256', TOMBSTONE_HMAC_KEY).update(TOMBSTONE_SEED).digest('hex');
}

let tombstoneId = null;

/** Надгробие: находит/создаёт системного юзера (идемпотентно, паритет с DeletionService.getTombstoneUserId). */
async function ensureTombstone() {
  if (tombstoneId) return tombstoneId;
  const emailHash = tombstoneEmailHash();
  const existing = await prisma.user.findUnique({ where: { emailHash }, select: { id: true } });
  if (existing) {
    tombstoneId = existing.id;
    return tombstoneId;
  }
  const created = await prisma.user.create({
    data: {
      emailHash,
      email: null,
      name: TOMBSTONE_NAME,
      passwordHash: TOMBSTONE_PASSWORD,
      accountType: 'individual',
    },
    select: { id: true },
  });
  tombstoneId = created.id;
  return tombstoneId;
}

// === Проверка BIZON_ENCRYPTION_KEY ===
// Скрипт не использует шифрование напрямую, но мы требуем ключ для соответствия
// контракту приложения (instrumentation.ts проверяет его при старте сервера).
const ENC_KEY = process.env.BIZON_ENCRYPTION_KEY;
if (!ENC_KEY) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в окружении.');
  console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
  console.error('   Запуск: BIZON_ENCRYPTION_KEY=... node scripts/cron-cleanup-deleted.js');
  process.exit(1);
}

const prisma = new PrismaClient();

const DRY_RUN = process.env.DRY_RUN === '1' || process.env.DRY_RUN === 'true';
const PURGE_AFTER_DAYS = 30;
const PURGE_AFTER_MS = PURGE_AFTER_DAYS * 24 * 60 * 60 * 1000;
const BATCH_SIZE = 50; // удаляем по 50 за итерацию, чтобы не перегружать БД

function isoNow() {
  return new Date().toISOString();
}

/**
 * Найти всех пользователей, у которых deletedAt < threshold (30 дней назад).
 * Берём по BATCH_SIZE за раз.
 */
async function findExpiredUsers(threshold, skip = 0) {
  return prisma.user.findMany({
    where: { deletedAt: { lt: threshold } },
    select: { id: true, name: true, deletedAt: true, createdAt: true },
    orderBy: { deletedAt: 'asc' },
    skip,
    take: BATCH_SIZE,
  });
}

/**
 * R5-C3: tombstone-шаги перед физическим удалением — ПАРИТЕТ с
 * DeletionService.anonymizeForPurge (src/lib/services/deletion-service.ts).
 * DRY_RUN=true: только считает counts, НИЧЕГО не пишет.
 */
async function anonymizeForPurge(userId, { dryRun = false } = {}) {
  if (dryRun) {
    const asAuthor = await prisma.endorsement.count({ where: { authorId: userId } });
    const asSubject = await prisma.endorsement.count({ where: { subjectId: userId } });
    const applications = await prisma.jobApplication.count({ where: { userId } });
    const theta = await prisma.resonanceProfile.count({ where: { userId } });
    const nfts = await prisma.nFTSkill.count({ where: { userId, status: { not: 'revoked' } } });
    return {
      endorsementsRepointed: asAuthor + asSubject,
      applicationsKept: applications,
      thetaDeleted: theta,
      nftsRevoked: nfts,
      dryRun: true,
    };
  }
  const tomb = await ensureTombstone();
  const now = new Date();
  const asAuthor = await prisma.endorsement.updateMany({ where: { authorId: userId }, data: { authorId: tomb } });
  const asSubject = await prisma.endorsement.updateMany({ where: { subjectId: userId }, data: { subjectId: tomb } });
  const applications = await prisma.jobApplication.updateMany({ where: { userId }, data: { userId: tomb } });
  const theta = await prisma.resonanceProfile.deleteMany({ where: { userId } });
  const nfts = await prisma.nFTSkill.updateMany({ where: { userId }, data: { status: 'revoked', revokedAt: now } });
  return {
    endorsementsRepointed: asAuthor.count + asSubject.count,
    applicationsKept: applications.count,
    thetaDeleted: theta.count,
    nftsRevoked: nfts.count,
  };
}

/** R5-C3: реестр удалённых аккаунтов (паритет с DeletionService.recordDeletedAccount). */
async function recordDeletedAccount(userId, mode, summary) {
  const data = { mode, summaryJson: JSON.stringify(summary) };
  await prisma.deletedAccount.upsert({
    where: { userId },
    create: { userId, ...data },
    update: { ...data, deletedAt: new Date() },
  });
}

/**
 * Удалить пользователя физически. Каскад через Prisma schema:
 *   • onDelete: Cascade — все owned/created записи (posts, comments, projects и т.д.)
 *   • onDelete: SetNull — ссылки в чужих записях (если есть)
 *   • Связи, где этот user — confirmer/connection — могут иметь CASCADE или SetNull
 *     в зависимости от конкретной модели (см. schema.prisma).
 *
 * AuditLog пишем ДО удаления (после — некому привязать actorId).
 */
async function purgeUser(user) {
  const userId = user.id;
  const startedAt = isoNow();

  try {
    // Логируем ДО удаления — actorId ещё валиден.
    await prisma.auditLog.create({
      data: {
        actorId: userId, // сам пользователь — «инициатор»
        action: 'account_hard_delete',
        resource: 'user',
        resourceId: userId,
        metadata: JSON.stringify({
          startedAt,
          deletedAt: user.deletedAt?.toISOString() ?? null,
          gracePeriodDays: PURGE_AFTER_DAYS,
          cronJob: 'cron-cleanup-deleted.js',
          dryRun: DRY_RUN,
          // НЕ сохраняем PII (email/name) — у soft-deleted они уже null,
          // но на всякий случай их здесь нет.
        }),
      },
    });

    if (DRY_RUN) {
      const summary = await anonymizeForPurge(userId, { dryRun: true });
      console.log(
        `  [DRY RUN] user=${userId}: tombstone-шаги (не выполнены) — ` +
        `endorsements→tombstone: ${summary.endorsementsRepointed}, ` +
        `отклики→tombstone (сохранены): ${summary.applicationsKept}, ` +
        `θ-профилей удалено бы: ${summary.thetaDeleted}, ` +
        `NFTSkill→revoked: ${summary.nftsRevoked}`
      );
      console.log(`  [DRY RUN] пропускаю физическое удаление user=${userId}`);
      return { userId, status: 'dry_run_skipped' };
    }

    // R5-C3: перенос связей на надгробие ДО user.delete (иначе P2003 Restrict
    // на Endorsement.author/subject; отклики сохраняются для компании).
    // Идемпотентно: повторный прогон после сбоя — updateMany/deleteMany с 0.
    const summary = await anonymizeForPurge(userId);
    if (summary.endorsementsRepointed || summary.applicationsKept || summary.thetaDeleted || summary.nftsRevoked) {
      console.log(
        `  ↳ tombstone: endorsements=${summary.endorsementsRepointed}, ` +
        `отклики сохранены=${summary.applicationsKept}, θ=${summary.thetaDeleted}, NFT revoked=${summary.nftsRevoked}`
      );
    }

    // Физическое удаление. Каскад сделает остальное.
    await prisma.user.delete({ where: { id: userId } });

    // R5-C3: реестр удалённых аккаунтов (после успешного delete; без FK — переживает purge)
    await recordDeletedAccount(userId, 'hard_purge', summary);

    console.log(`  ✓ удалён user=${userId} (deletedAt=${user.deletedAt?.toISOString()})`);
    return { userId, status: 'purged' };
  } catch (e) {
    console.error(`  ✗ ошибка удаления user=${userId}:`, e?.message || e);
    return { userId, status: 'error', error: String(e?.message || e) };
  }
}

async function main() {
  console.log(`\n=== BizON cron-cleanup-deleted — ${isoNow()} ===`);
  console.log(`  PURGE_AFTER_DAYS = ${PURGE_AFTER_DAYS}`);
  console.log(`  DRY_RUN          = ${DRY_RUN}`);

  const threshold = new Date(Date.now() - PURGE_AFTER_MS);
  console.log(`  threshold        = ${threshold.toISOString()}`);
  console.log('');

  let totalFound = 0;
  let totalPurged = 0;
  let totalErrors = 0;
  let skip = 0;

  // Пагинация: обрабатываем по BATCH_SIZE за итерацию
  // ВАЖНО: после каждой итерации skip НЕ увеличиваем, т.к. удалённые записи
  // «исчезают» из выборки. Если DRY_RUN — увеличиваем skip.
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const batch = await findExpiredUsers(threshold, DRY_RUN ? skip : 0);
    if (batch.length === 0) break;

    totalFound += batch.length;
    console.log(`  → найдено ${batch.length} записей (skip=${skip})`);

    for (const user of batch) {
      const result = await purgeUser(user);
      if (result.status === 'purged' || result.status === 'dry_run_skipped') {
        totalPurged++;
      } else if (result.status === 'error') {
        totalErrors++;
      }
    }

    if (DRY_RUN) {
      skip += batch.length;
    }
    // Если получили меньше, чем BATCH_SIZE — это последняя страница
    if (batch.length < BATCH_SIZE) break;
  }

  console.log('');
  console.log(`=== Готово ===`);
  console.log(`  Найдено к удалению: ${totalFound}`);
  console.log(`  Удалено:            ${totalPurged}`);
  console.log(`  Ошибок:             ${totalErrors}`);
  console.log('');

  // Финальная запись в AuditLog — сводка по запуску.
  // FIX (R5-4c): было actorId: null — модель AuditLog.actorId NOT NULL,
  // финальная сводка падала P2019/ValidationError после каждого прогона.
  // Канон data-vault/audit-log.ts: null → 'system'.
  await prisma.auditLog.create({
    data: {
      actorId: 'system', // система
      action: 'cron_cleanup_deleted_run',
      resource: 'cron',
      resourceId: 'cron-cleanup-deleted',
      metadata: JSON.stringify({
        runAt: isoNow(),
        threshold: threshold.toISOString(),
        purgeAfterDays: PURGE_AFTER_DAYS,
        dryRun: DRY_RUN,
        totalFound,
        totalPurged,
        totalErrors,
      }),
    },
  });
}

main()
  .catch((e) => {
    console.error('FATAL:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
