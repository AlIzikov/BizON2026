// =============================================================================
// AUDIT-MODE (внешний аудит, запрос владельца 2026-02): вход в МАКСИМАЛЬНЫЙ
// аккаунт (роль admin, «Владелец BizON») БЕЗ логина и пароля.
//
// Что делает скрипт (идемпотентно, можно запускать повторно):
//   1. Находит admin-аккаунт (roles содержит точный токен 'admin', не
//      blocked/deleted). Приоритет — «Владелец BizON», иначе старейший admin.
//   2. Дотягивает аккаунт до «максимального» состояния:
//      emailVerified=true, acceptedTosAt/Version (ToS 1.1), isVerified.
//   3. Создаёт СВЕЖУЮ audit-сессию (TTL 30 дней, userAgent='AUDIT-MODE'),
//      удаляя прежние audit-сессии этого пользователя (ротация токена).
//   4. Прописывает в .env:
//        BIZON_AUDIT_AUTH=1
//        BIZON_AUDIT_SESSION_TOKEN=<raw token>
//      — middleware подставляет эту cookie каждому посетителю БЕЗ своей
//        сессии → внешний аудитор открывает сайт и уже внутри admin-аккаунта.
//
// БЕЗОПАСНОСТЬ (честно, как требовано регламентом):
//   • Режим управляется одним флагом: BIZON_AUDIT_AUTH=0 в .env → middleware
//     и /api/auth/audit-login закрываются (fail-closed, 404).
//   • Сессия помечена userAgent='AUDIT-MODE' — видна в «Активных сессиях»,
//     не удаляется при logout (см. /api/auth/logout) и пишется в AuditLog.
//   • В PRODUCTION включать ЗАПРЕЩЕНО: это осознанный backdoor для аудита.
//
// Запуск:  bun scripts/ensure-audit-admin.ts
// Выключить: BIZON_AUDIT_AUTH=0 в .env (токен можно заодно удалить)
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { createHash, randomBytes } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';

const db = new PrismaClient();

const AUDIT_SESSION_TTL_DAYS = 30;
const AUDIT_UA = 'AUDIT-MODE (external audit)';
const ENV_PATH = new URL('../.env', import.meta.url).pathname;

function sha256hex(input: string): string {
  return createHash('sha256').update(input).digest('hex');
}

function rawToken(): string {
  return randomBytes(32).toString('hex'); // 256 бит, как generateToken() в lib
}

function upsertEnvLine(env: string, key: string, value: string): string {
  const re = new RegExp(`^${key}=.*$`, 'm');
  if (re.test(env)) return env.replace(re, `${key}=${value}`);
  const nl = env.length > 0 && !env.endsWith('\n') ? '\n' : '';
  return `${env}${nl}${key}=${value}\n`;
}

async function main() {
  // --- 1. Найти максимальный аккаунт ---
  const candidates = await db.user.findMany({
    where: { roles: { contains: 'admin' } },
    orderBy: { createdAt: 'asc' },
  });
  const admins = candidates
    .filter((u) => !u.blockedAt && !u.deletedAt)
    .filter((u) => u.roles.split(',').map((r) => r.trim()).includes('admin'));

  if (admins.length === 0) {
    console.error('FAIL: admin-аккаунт не найден (roles содержит точный токен admin).');
    process.exit(1);
  }
  const admin = admins.find((u) => u.name === 'Владелец BizON') ?? admins[0];
  console.log(`ADMIN: ${admin.name} (${admin.id}) | roles="${admin.roles}" | accountType=${admin.accountType}`);

  // --- 2. Максимальное состояние аккаунта (идемпотентно) ---
  await db.user.update({
    where: { id: admin.id },
    data: {
      emailVerified: true,
      isVerified: true,
      verifiedAt: admin.verifiedAt ?? new Date(),
      acceptedTosAt: admin.acceptedTosAt ?? new Date(),
      acceptedTosVersion: admin.acceptedTosVersion ?? '1.1',
    },
  });
  console.log('USER_STATE: emailVerified=true, isVerified=true, ToS 1.1 принят');

  // --- 3. Свежая audit-сессия (ротация: старые AUDIT-MODE сессии удаляем) ---
  const removed = await db.session.deleteMany({ where: { userId: admin.id, userAgent: AUDIT_UA } });
  if (removed.count > 0) console.log(`ROTATION: удалено прежних audit-сессий: ${removed.count}`);

  const token = rawToken();
  const expiresAt = new Date(Date.now() + AUDIT_SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);
  await db.session.create({
    data: {
      userId: admin.id,
      token: sha256hex(token), // в БД только sha256 (инвариант D-21)
      expiresAt,
      userAgent: AUDIT_UA,
      lastUsedAt: new Date(),
    },
  });
  console.log(`SESSION: создана, TTL ${AUDIT_SESSION_TTL_DAYS} дней (до ${expiresAt.toISOString()})`);

  // --- 4. .env ---
  if (!existsSync(ENV_PATH)) {
    console.error(`FAIL: .env не найден: ${ENV_PATH}`);
    process.exit(1);
  }
  let env = readFileSync(ENV_PATH, 'utf8');
  env = upsertEnvLine(env, 'BIZON_AUDIT_AUTH', '1');
  env = upsertEnvLine(env, 'BIZON_AUDIT_SESSION_TOKEN', token);
  writeFileSync(ENV_PATH, env, 'utf8');
  console.log('ENV: BIZON_AUDIT_AUTH=1, BIZON_AUDIT_SESSION_TOKEN записан (ротация)');

  console.log('\nOK: audit-mode включён. Аудитор открывает сайт — уже в максимальном аккаунте (без логина/пароля).');
  console.log('Выключение: BIZON_AUDIT_AUTH=0 в .env, затем перезапуск dev-сервера.');
  await db.$disconnect();
}

main().catch(async (e) => {
  console.error('FAIL:', e);
  await db.$disconnect();
  process.exit(1);
});
