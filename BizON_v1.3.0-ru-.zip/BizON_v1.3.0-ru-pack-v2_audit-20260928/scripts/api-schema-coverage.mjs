#!/usr/bin/env node
// API-034 (аудит 22-09-26): инвентарь покрытия API-роутов композером withRoute
// и zod-схемами.
//
// Запуск:  node scripts/api-schema-coverage.mjs   (или: bun scripts/api-schema-coverage.mjs)
//
// Эвристики (по исходнику route.ts):
//   - method exports   — `export async function GET|POST|...` и `export const GET|POST|... =`;
//   - withRoute-обёртка — `export const METHOD = withRoute` (композер FIX-07);
//   - schema           — внутри вызова withRoute есть opts со `schema:` (body/query);
//   - paramsSchema     — opts с `paramsSchema:` (динамические сегменты, API-012);
//   - rateLimit        — opts с `rateLimit:` (API-027);
//   - legacy method    — method export БЕЗ withRoute (ручной try/catch, errorJson и т.п.).
//
// Эвристика по исходнику, не по AST: сознательный компромисс скрипта-инвентаря
// (ложных срабатываний «schema:» вне withRoute-opts в src/app/api не найдено).

import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';

const API_DIR = 'src/app/api';
const METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'];

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir).sort()) {
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) out.push(...walk(p));
    else if (name === 'route.ts') out.push(p);
  }
  return out;
}

function analyze(file) {
  const src = readFileSync(file, 'utf8');
  const methodExports = [
    ...src.matchAll(new RegExp(`export\\s+async\\s+function\\s+(${METHODS.join('|')})\\b`, 'g')),
    ...src.matchAll(new RegExp(`export\\s+const\\s+(${METHODS.join('|')})\\s*=?\\s*[=:]`, 'g')),
  ].map((m) => m[1]);
  const wrapped = [...src.matchAll(new RegExp(`export\\s+const\\s+(${METHODS.join('|')})\\s*=\\s*withRoute\\b`, 'g'))].map((m) => m[1]);
  // opts внутри withRoute(...): берём хвост каждого вызова — грубо: наличие
  // `schema:` / `paramsSchema:` / `rateLimit:` в файле с withRoute-вызовами.
  const hasWithRoute = wrapped.length > 0 || /withRoute\s*[<(]/.test(src);
  const hasSchema = hasWithRoute && /(^|[^\w])schema\s*:/.test(src);
  const hasParamsSchema = hasWithRoute && /paramsSchema\s*:/.test(src);
  const hasRateLimit = hasWithRoute && /rateLimit\s*:/.test(src);
  const legacyMethods = methodExports.filter((m) => !wrapped.includes(m));
  return {
    file,
    methods: methodExports.length,
    withRoute: wrapped.length,
    hasSchema,
    hasParamsSchema,
    hasRateLimit,
    legacy: legacyMethods,
  };
}

const files = walk(API_DIR);
const rows = files.map(analyze);

// Группировка по секции: src/app/api/<section>/... (route.ts прямо в api — '<root>')
function sectionOf(file) {
  const rel = relative(API_DIR, file);
  const parts = rel.split(sep);
  return parts.length === 1 ? '<root>' : parts[0];
}

const groups = new Map();
for (const r of rows) {
  const key = sectionOf(r.file);
  if (!groups.has(key)) {
    groups.set(key, { routes: 0, withRouteFiles: 0, withSchema: 0, withParamsSchema: 0, withRateLimit: 0, legacyMethods: 0, legacyFiles: 0 });
  }
  const g = groups.get(key);
  g.routes += 1;
  if (r.withRoute > 0) g.withRouteFiles += 1;
  if (r.hasSchema) g.withSchema += 1;
  if (r.hasParamsSchema) g.withParamsSchema += 1;
  if (r.hasRateLimit) g.withRateLimit += 1;
  if (r.legacy.length > 0) {
    g.legacyFiles += 1;
    g.legacyMethods += r.legacy.length;
  }
}

const total = {
  routes: rows.length,
  withRouteFiles: 0,
  withSchema: 0,
  withParamsSchema: 0,
  withRateLimit: 0,
  legacyFiles: 0,
  legacyMethods: 0,
};
for (const g of groups.values()) {
  total.withRouteFiles += g.withRouteFiles;
  total.withSchema += g.withSchema;
  total.withParamsSchema += g.withParamsSchema;
  total.withRateLimit += g.withRateLimit;
  total.legacyFiles += g.legacyFiles;
  total.legacyMethods += g.legacyMethods;
}

const pct = (a, b) => (b === 0 ? '0.0' : ((a / b) * 100).toFixed(1));

console.log('\nAPI-034: schema/withRoute coverage (src/app/api/**/route.ts)\n');
console.log(
  'section'.padEnd(28) +
    'routes'.padStart(7) +
    'withRoute'.padStart(10) +
    'schema'.padStart(8) +
    'params'.padStart(8) +
    'rateLim'.padStart(9) +
    'legacy*'.padStart(9) +
    'cover%'.padStart(8)
);
console.log('-'.repeat(87));
for (const [key, g] of [...groups.entries()].sort((a, b) => b[1].routes - a[1].routes)) {
  console.log(
    key.padEnd(28) +
      String(g.routes).padStart(7) +
      String(g.withRouteFiles).padStart(10) +
      String(g.withSchema).padStart(8) +
      String(g.withParamsSchema).padStart(8) +
      String(g.withRateLimit).padStart(9) +
      `${g.legacyFiles}/${g.legacyMethods}`.padStart(9) +
      pct(g.withRouteFiles, g.routes).padStart(8)
  );
}
console.log('-'.repeat(87));
console.log(
  'TOTAL'.padEnd(28) +
    String(total.routes).padStart(7) +
    String(total.withRouteFiles).padStart(10) +
    String(total.withSchema).padStart(8) +
    String(total.withParamsSchema).padStart(8) +
    String(total.withRateLimit).padStart(9) +
    `${total.legacyFiles}/${total.legacyMethods}`.padStart(9) +
    pct(total.withRouteFiles, total.routes).padStart(8)
);
console.log(
  `\n* legacy = файлы/методы без withRoute (ручные обработчики); cover% = доля route.ts с withRoute.\n` +
    `Итого: withRoute ${total.withRouteFiles}/${total.routes} (${pct(total.withRouteFiles, total.routes)}%), ` +
    `schema ${total.withSchema} (${pct(total.withSchema, total.routes)}%), ` +
    `paramsSchema ${total.withParamsSchema}, rateLimit ${total.withRateLimit}, legacy-методов ${total.legacyMethods} в ${total.legacyFiles} файлах.`
);

// Список legacy-файлов (для миграционной дорожной карты API-001)
const legacyList = rows.filter((r) => r.legacy.length > 0);
if (process.argv.includes('--list-legacy')) {
  console.log('\nLegacy-файлы (methods без withRoute):');
  for (const r of legacyList) console.log(`  ${r.file}: ${r.legacy.join(', ')}`);
}
