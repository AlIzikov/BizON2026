// FIX-09 one-off DB helpers (verification only)
import { PrismaClient } from '@prisma/client';
import { hashEmail } from '../src/lib/security/crypto';

const db = new PrismaClient();

async function main() {
  const cmd = process.argv[2];

  if (cmd === 'user-by-email') {
    const pattern = process.argv[3] ?? '%@bizon.ru';
    const u = await db.user.findFirst({ where: { email: { contains: pattern.replace('%', '') } }, select: { id: true, name: true, email: true, roles: true, emailVerified: true, acceptedTosAt: true, lumenBalance: true, lumenAccruedAt: true } });
    console.log(JSON.stringify(u, null, 2));
  } else if (cmd === 'demo-email') {
    const u = await db.user.findFirst({ where: { name: 'Иван Петров' }, select: { id: true, email: true, roles: true } });
    console.log(JSON.stringify(u));
  } else if (cmd === 'set-2fa') {
    const email = process.argv[3];
    const u = await db.user.update({ where: { emailHash: hashEmail(email.toLowerCase()) }, data: { twoFactorEnabled: true }, select: { id: true, email: true, twoFactorEnabled: true } });
    console.log(JSON.stringify(u));
  } else if (cmd === 'del-user') {
    const email = process.argv[3];
    const u = await db.user.delete({ where: { emailHash: hashEmail(email.toLowerCase()) } });
    console.log(JSON.stringify({ deleted: u.id, email: u.email }));
  } else if (cmd === 'roles') {
    const email = process.argv[3];
    const u = await db.user.findUnique({ where: { emailHash: hashEmail(email.toLowerCase()) }, select: { id: true, roles: true } });
    console.log(JSON.stringify(u));
  } else if (cmd === 'indexes') {
    const rows = await db.$queryRawUnsafe<{ name: string; tbl_name: string; sql: string }[]>(
      `SELECT name, tbl_name, sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL`,
    );
    const needles: Array<[string, string[]]> = [
      ['Post', ['authorId', 'createdAt']],
      ['JobApplication', ['userId', 'createdAt']],
      ['AuditLog', ['ip']],
      ['Ad', ['active', 'moderationScore']],
      ['CoachInsight', ['userId', 'createdAt']],
      ['LumenTransaction', ['refundOf']],
    ];
    for (const [tbl, cols] of needles) {
      const hit = rows.filter((r) => r.tbl_name === tbl && cols.every((c) => r.sql.includes(c)));
      console.log(`${tbl}(${cols.join(',')}) ->`, hit.length ? hit.map((h) => h.name) : 'NOT FOUND');
    }
    const uniqRefund = rows.find((r) => r.tbl_name === 'LumenTransaction' && r.sql.includes('refundOf'));
    console.log('LumenTransaction.refundOf unique ->', uniqRefund ? /UNIQUE/i.test(uniqRefund.sql) : false);
    const userCols = await db.$queryRawUnsafe<{ name: string }[]>(`PRAGMA table_info(User)`);
    console.log('User.emailVerified ->', userCols.some((c) => c.name === 'emailVerified'));
    console.log('User.acceptedTosAt ->', userCols.some((c) => c.name === 'acceptedTosAt'));
    const tables = await db.$queryRawUnsafe<{ name: string }[]>(`SELECT name FROM sqlite_master WHERE type='table'`);
    console.log('VerificationToken table ->', tables.some((t) => t.name === 'VerificationToken'));
  } else {
    console.log('unknown cmd');
  }
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
