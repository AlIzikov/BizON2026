// BizON v6 — Cron: консолидация памяти (Professional Memory)
// Архивирует AiInsight старше 30 дней и консолидирует их в ProfessionalNarrative.
//
// Что делает:
//   1. Находит AiInsight с createdAt < now-30д и isSeen=false.
//   2. «Архивирует» их: isSeen=true. В схеме AiInsight НЕТ поля status/archived —
//      единственный доступный флаг состояния это isSeen, поэтому «архив» = isSeen
//      (см. prisma/schema.prisma: model AiInsight — isSeen Boolean @default(false)).
//   3. Консолидирует архив в нарратив: на каждого пользователя с архивом
//      создаётся НОВАЯ версия ProfessionalNarrative (version = prev+1) с
//      кратким(summary) текстом и sourceData = JSON { archivedInsightIds, byType }.
//
// Запуск:
//   node scripts/cron-memory.js [--dry-run]
//
// Cron (еженедельно, воскресенье 04:00):
//   crontab -e:
//     0 4 * * 0  cd /home/z/my-project && /usr/bin/node scripts/cron-memory.js >> /var/log/bizon-cron.log 2>&1
//
//   pm2 (альтернатива):
//     { name: 'bizon-cron-memory', script: 'scripts/cron-memory.js', cron_restart: '0 4 * * 0', autorestart: false }
//
// Идемпотентность: после первого запуска все инсайты старше 30 дней уже имеют
// isSeen=true, повторный запуск не находит кандидатов и ничего не меняет.
// Флаг --dry-run только показывает, что будет сделано, без записи в БД.

const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const RETENTION_DAYS = 30;
const INSIGHT_TYPE_LABELS = {
  signal: 'Сигнал',
  moment: 'Момент',
  blind_spot: 'Слепая зона',
  next_action: 'Следующее действие',
  opportunity: 'Возможность',
  scenario: 'Сценарий',
};

function buildNarrative(user, insights, byType) {
  const typeLines = Object.entries(byType)
    .map(([type, list]) => {
      const label = INSIGHT_TYPE_LABELS[type] ?? type;
      const titles = list.slice(0, 3).map((i) => `«${i.title}»`).join(', ');
      const more = list.length > 3 ? ` и ещё ${list.length - 3}` : '';
      return `- ${label} (${list.length}): ${titles}${more}`;
    })
    .join('\n');

  return [
    `Архив AI-инсайтов за период до ${new Date().toISOString().slice(0, 10)} ` +
      `(консолидировано cron-memory).`,
    ``,
    `За последние месяцы BizonAICore зафиксировал ${insights.length} наблюдений, ` +
      `которые переведены в архив памяти:`,
    typeLines,
    ``,
    `Эти наблюдения больше не показываются в ленте инсайтов, но остаются частью ` +
      `профессиональной памяти и учитываются при построении нарратива.`,
  ].join('\n');
}

async function main() {
  const dryRun = process.argv.includes('--dry-run');
  const cutoff = new Date(Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000);

  console.log('=== BizON v6 — Cron: консолидация AiInsight → ProfessionalNarrative ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log(`Глубина архива: инсайты старше ${RETENTION_DAYS} дн. (до ${cutoff.toISOString()})`);
  if (dryRun) console.log('РЕЖИМ: dry-run (записи в БД не будет)');
  console.log('');

  // 1. Кандидаты на архив: старше cutoff и ещё не просмотрены
  const stale = await prisma.aiInsight.findMany({
    where: { createdAt: { lt: cutoff }, isSeen: false },
    include: { user: { select: { id: true, name: true } } },
    orderBy: { createdAt: 'asc' },
  });

  if (stale.length === 0) {
    console.log('Инсайтов старше 30 дней для архивации не найдено. Выход.');
    return;
  }
  console.log(`Кандидатов на архив: ${stale.length}\n`);

  // 2. Группируем по пользователю
  const byUser = new Map();
  for (const insight of stale) {
    if (!byUser.has(insight.userId)) {
      byUser.set(insight.userId, { user: insight.user, insights: [] });
    }
    byUser.get(insight.userId).insights.push(insight);
  }
  console.log(`Пользователей с архивом: ${byUser.size}\n`);

  if (dryRun) {
    for (const [userId, { user, insights }] of byUser) {
      console.log(`[dry-run] ${user.name} (${userId}): ${insights.length} инсайтов → новая версия нарратива`);
    }
    console.log('\n[dry-run] Ничего не записано. ✅ cron-memory complete.');
    return;
  }

  let archived = 0;
  let narrativesCreated = 0;
  let usersProcessed = 0;
  let failed = 0;

  for (const [userId, { user, insights }] of byUser) {
    try {
      // 3. Архивация (isSeen=true — «архив» в рамках текущей схемы)
      await prisma.aiInsight.updateMany({
        where: { id: { in: insights.map((i) => i.id) } },
        data: { isSeen: true },
      });
      archived += insights.length;

      // 4. Консолидация в ProfessionalNarrative — новая версия
      const byType = {};
      for (const i of insights) {
        (byType[i.type] ??= []).push({ id: i.id, title: i.title });
      }
      const last = await prisma.professionalNarrative.findFirst({
        where: { userId },
        orderBy: { version: 'desc' },
        select: { version: true },
      });
      const nextVersion = (last?.version ?? 0) + 1;

      await prisma.professionalNarrative.create({
        data: {
          userId,
          narrative: buildNarrative(user, insights, byType),
          version: nextVersion,
          sourceData: JSON.stringify({
            kind: 'memory-consolidation',
            archivedCount: insights.length,
            archivedInsightIds: insights.map((i) => i.id),
            byType: Object.fromEntries(Object.entries(byType).map(([k, v]) => [k, v.length])),
            consolidatedAt: new Date().toISOString(),
          }),
        },
      });
      narrativesCreated++;
      usersProcessed++;

      console.log(
        `✅ ${user.name}: архивировано ${insights.length} инсайтов → нарратив v${nextVersion}`
      );
    } catch (e) {
      failed++;
      console.error(`❌ ${user.name} (${userId}) — ${e.message}`);
    }
  }

  console.log('\n=== Итог ===');
  console.log(`  Инсайтов архивировано: ${archived}`);
  console.log(`  Нарративов создано: ${narrativesCreated}`);
  console.log(`  Пользователей обработано: ${usersProcessed}`);
  console.log(`  Ошибок: ${failed}`);
  console.log('\n✅ cron-memory complete.');
}

main()
  .catch((e) => {
    console.error('❌ cron-memory failed:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect().catch(() => {});
  });
