// R5-P2 · rotate-secrets: аудит «возраста» секретов + чек-лист ротации (90д-канон).
//
// ЧЕСТНАЯ ГРАНИЦА: скрипт НЕ может сам ротировать ключи внешних провайдеров
// (Stripe/Resend/Upstash/Sentry — это действия в их дашбордах). Он:
//   1) находит секреты в .env и bizon-config.env;
//   2) сверяет дату последней ротации из .secrets-rotation.json (если ведётся);
//   3) для секретов старше 90 дней печатает пошаговую ротацию
//      (источники шагов — docs/ci-cd.md Secrets-лист и .env.example-гайд);
//   4) опционально --mark KEY отмечает дату ротации (владелец после смены).
//
// Запуск: bun run scripts/rotate-secrets.ts
// Отметка: bun run scripts/rotate-secrets.ts --mark STRIPE_SECRET_KEY
import { readFileSync, writeFileSync, existsSync } from 'node:fs';

const ROTATION_LOG = '.secrets-rotation.json';
const NINETY_DAYS = 90 * 24 * 60 * 60 * 1000;

/** Секреты, подлежащие ротации (ключи .env с фактическими значениями). */
const ROTATABLE: Array<{ envKey: string; provider: string; steps: string[] }> = [
  {
    envKey: 'STRIPE_SECRET_KEY',
    provider: 'Stripe',
    steps: [
      'Dashboard → Developers → API keys → Create restricted key (test/live по потребности)',
      'Обновить STRIPE_SECRET_KEY в .env И в GitHub Secrets (docs/ci-cd.md)',
      'Старый ключ revoke ТОЛЬКО после успешного checkout-смока',
      'Webhook secret (whsec_) ротируется отдельно: Webhook endpoints → rotating secret',
    ],
  },
  {
    envKey: 'RESEND_API_KEY',
    provider: 'Resend',
    steps: [
      'Dashboard → API Keys → Create API Key',
      'Обновить RESEND_API_KEY в .env / GitHub Secrets',
      'DKIM/SPF не зависят от API-ключа — DNS не трогаем (docs/ops/email-dns.md)',
    ],
  },
  {
    envKey: 'SENTRY_DSN',
    provider: 'Sentry',
    steps: [
      'Sentry не требует регулярной ротации DSN; при компрометации: Settings → Client Keys → Rotate',
    ],
  },
  {
    envKey: 'SLACK_WEBHOOK_URL',
    provider: 'Slack',
    steps: [
      'Slack App → Incoming Webhooks → удалить старый → создать новый',
      'Обновить SLACK_WEBHOOK_URL в .env / GitHub Secrets',
    ],
  },
  {
    envKey: 'UPSTASH_REDIS_URL',
    provider: 'Upstash',
    steps: [
      'Console → Database → REST/Redis token → Reset password',
      'Обновить UPSTASH_REDIS_URL/UPSTASH_REDIS_TOKEN',
    ],
  },
  {
    envKey: 'BIZON_ENCRYPTION_KEY',
    provider: 'Внутренний (PII)',
    steps: [
      'ОСТОРОЖНО: ротация требует re-encryption данных (emailHash/emailEncrypted)',
      'Без процедуры миграции НЕ менять — иначе PII всех пользователей станет нечитаемой',
      'Процедура: сгенерировать новый ключ → dual-key decrypt (старый+новый) → перезапись',
      'До внедрения dual-key: ключ НЕ ротируется автоматически, помечаем исключение',
    ],
  },
];

function parseEnvFile(path: string): Record<string, string> {
  const out: Record<string, string> = {};
  if (!existsSync(path)) return out;
  for (const line of readFileSync(path, 'utf8').split('\n')) {
    const m = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (m && m[2] && !m[2].startsWith('"') && m[1] !== 'DATABASE_URL') {
      out[m[1]] = m[2].slice(0, 8) + '…'; // маска: печать только префикса
    } else if (m && m[2]) {
      out[m[1]] = '"…"';
    }
  }
  return out;
}

function loadRotationLog(): Record<string, string> {
  if (!existsSync(ROTATION_LOG)) return {};
  try {
    return JSON.parse(readFileSync(ROTATION_LOG, 'utf8'));
  } catch {
    return {};
  }
}

const env = { ...parseEnvFile('.env'), ...parseEnvFile('bizon-config.env') };
const log = loadRotationLog();
const markArg = process.argv.indexOf('--mark');
if (markArg > -1 && process.argv[markArg + 1]) {
  const key = process.argv[markArg + 1];
  log[key] = new Date().toISOString();
  writeFileSync(ROTATION_LOG, JSON.stringify(log, null, 2) + '\n');
  console.log(`[rotate] отмечена ротация ${key}: ${log[key]}`);
  process.exit(0);
}

console.log('=== Аудит секретов (канон 90 дней) ===\n');
let stale = 0;
for (const secret of ROTATABLE) {
  const present = !!process.env[secret.envKey] || env[secret.envKey] !== undefined;
  const rotatedAt = log[secret.envKey] ? new Date(log[secret.envKey]) : null;
  const ageDays = rotatedAt ? Math.floor((Date.now() - rotatedAt.getTime()) / 86400000) : null;
  // Ротация требуется ТОЛЬКО заданным секретам (не задан — нечего ротировать).
  const isStale = present && (ageDays === null || ageDays > 90);
  if (isStale) stale++;
  console.log(
    `${present ? '●' : '○'} ${secret.envKey} (${secret.provider})` +
      `\n    значение: ${present ? env[secret.envKey] ?? 'задан в process.env' : 'НЕ задан'}` +
      `\n    последняя ротация: ${rotatedAt ? `${ageDays} дн. назад` : 'не отмечена'} → ${isStale ? 'ТРЕБУЕТ РОТАЦИИ' : 'ок'}`,
  );
  if (present && isStale) {
    for (const s of secret.steps) console.log(`      - ${s}`);
  }
  console.log('');
}
console.log(
  stale === 0
    ? '[rotate] все заданные секреты свежи (≤90 дн).'
    : `[rotate] ${stale} секрет(ов) требуют ротации. После смены: --mark ENV_KEY`,
);
console.log('[rotate] исключение: BIZON_ENCRYPTION_KEY — только по процедуре dual-key (см. выше).');
