// =============================================================================
// KV2 D-14 (+D-17) — cleanup-demo-data.ts
//
// Что делает: удаляет из ЖИВОЙ БД тест-артефакты ленты (Feed).
//   1) посты с content LIKE паттернами QA/E2E-сессий;
//   2) посты фейк-авторов:
//      а) email (plaintext или расшифрованный emailEncrypted) попадает в
//         явные тест-паттерны: 'e2e', '@bizon.test', '@example',
//         'cashier-hub-e2e';
//      б) имя автора содержит QA/E2E/Tester-маркеры (QA3 User A, E2E Buyer W2,
//         Cashier Tester, ...) — это пользователи, созданные QA/E2E-сессиями
//         (проверено: 0 реальной активности, email-plaintext зачищен и
//         не расшифровывается legacy-ключом, поэтому имя — единственный
//         надёжный маркер).
//   ВАЖНО: юзеров НЕ удаляет — только посты. Комментарии/лайки/сохранения/
//   голоса/доступы удалённых постов чистятся по postId до удаления постов
//   (PostLike / PostComment / SavedPost / PostPollVote / PostAccess).
//
// Идемпотентен: повторный запуск находит 0 артефактов и удаляет 0 записей.
//
// Запуск: bun run scripts/cleanup-demo-data.ts
// =============================================================================
import { db } from '../src/lib/db';
import { decrypt } from '../src/lib/security/crypto';

// Паттерны content (заданы приказом D-14; '%X%' → 'X', LIKE без учёта регистра в SQLite)
const CONTENT_PATTERNS = [
  'QA3 User',
  'QA Limit',
  'W4 E2E Project',
  'W5 E2E',
  'E2E', // '%E2E%'
  'QA Test', // '%QA Test%'
] as const;

// Явные тест-паттерны email авторов (D-14)
const EMAIL_PATTERNS = [/e2e/i, /@bizon\.test/i, /@example/i, /cashier-hub-e2e/i];

// Маркеры QA/E2E-фейк-авторов в имени (qa3, "QA Test", E2E Buyer, W4E2E, Tester, ...)
// Проверено на живой БД: совпадают только тестовые аккаунты, реальных — 0.
const NAME_PATTERN = /qa\d|(^|[^a-zа-я0-9])qa|e2e|tester/i;

async function main() {
  console.log('[cleanup-demo-data] старт: подсчёт артефактов (SELECT, без удаления)');

  // ---- ШАГ 1. SELECT-count постов по content-паттернам ---------------------
  const contentCounts = new Map<string, number>();
  const contentLikeIds = new Set<string>();
  for (const p of CONTENT_PATTERNS) {
    const rows = await db.post.findMany({ where: { content: { contains: p } }, select: { id: true } });
    contentCounts.set(p, rows.length);
    for (const r of rows) contentLikeIds.add(r.id);
  }
  console.log('[cleanup-demo-data] content-паттерны:');
  for (const [p, c] of contentCounts) console.log(`  - content LIKE '%${p}%': ${c}`);
  console.log(`  = уникальных постов по content: ${contentLikeIds.size}`);

  // ---- ШАГ 2. Фейк-авторы (email-паттерны + QA/E2E/Tester-имена) -----------
  const users = await db.user.findMany({
    select: { id: true, name: true, email: true, emailEncrypted: true },
  });
  const fakeByEmail: string[] = [];
  const fakeByName: string[] = [];
  for (const u of users) {
    // plaintext email зачищен миграцией (nullable); читаем через decrypt(*Encrypted)
    let email = (u.email ?? '').toLowerCase();
    if (!email && u.emailEncrypted) {
      try {
        email = decrypt(u.emailEncrypted).toLowerCase();
      } catch {
        // legacy-ключ: email не восстанавливается — маркер имени ниже
      }
    }
    if (email && EMAIL_PATTERNS.some((re) => re.test(email))) fakeByEmail.push(u.id);
    if (NAME_PATTERN.test(u.name)) fakeByName.push(u.id);
  }
  const fakeAuthorIds = [...new Set([...fakeByEmail, ...fakeByName])];
  console.log(
    `[cleanup-demo-data] фейк-авторы: по email-паттернам=${fakeByEmail.length}, ` +
      `по имени (QA/E2E/Tester)=${fakeByName.length}, всего=${fakeAuthorIds.length} (юзеры не удаляются)`
  );
  if (fakeByName.length > 0) {
    const names = users
      .filter((u) => fakeByName.includes(u.id))
      .map((u) => `"${u.name}"`)
      .slice(0, 25);
    console.log(`[cleanup-demo-data] имена фейк-авторов: ${names.join(', ')}`);
  }

  const postsByFakeAuthors = await db.post.findMany({
    where: { authorId: { in: fakeAuthorIds } },
    select: { id: true },
  });
  console.log(`[cleanup-demo-data] постов фейк-авторов: ${postsByFakeAuthors.length}`);

  // ---- ШАГ 3. Итоговый список постов к удалению ----------------------------
  const postIds = [...new Set([...contentLikeIds, ...postsByFakeAuthors.map((p) => p.id)])];
  console.log(`[cleanup-demo-data] ИТОГО постов к удалению: ${postIds.length}`);

  if (postIds.length === 0) {
    console.log('[cleanup-demo-data] артефактов не найдено — БД уже чиста (идемпотентный запуск: 0 удалений)');
    await db.$disconnect();
    return;
  }

  // ---- ШАГ 4. Связанные записи по postId in [...] --------------------------
  const [likes, comments, saved, pollVotes, access] = await Promise.all([
    db.postLike.deleteMany({ where: { postId: { in: postIds } } }),
    db.postComment.deleteMany({ where: { postId: { in: postIds } } }),
    db.savedPost.deleteMany({ where: { postId: { in: postIds } } }),
    db.postPollVote.deleteMany({ where: { postId: { in: postIds } } }),
    db.postAccess.deleteMany({ where: { postId: { in: postIds } } }),
  ]);
  console.log(
    `[cleanup-demo-data] связанные записи удалены: PostLike=${likes.count}, ` +
      `PostComment=${comments.count}, SavedPost=${saved.count}, ` +
      `PostPollVote=${pollVotes.count}, PostAccess=${access.count}`
  );

  // ---- ШАГ 5. Сами посты ---------------------------------------------------
  const deleted = await db.post.deleteMany({ where: { id: { in: postIds } } });
  console.log(`[cleanup-demo-data] постов удалено: ${deleted.count}`);

  // ---- ШАГ 6. Верификация идемпотентности ----------------------------------
  const recheck = await db.post.count({ where: { OR: CONTENT_PATTERNS.map((p) => ({ content: { contains: p } })) } });
  const remainingFake = await db.post.count({ where: { authorId: { in: fakeAuthorIds } } });
  console.log(
    `[cleanup-demo-data] верификация: постов по content-паттернам=${recheck}, постов фейк-авторов=${remainingFake} (ожидается 0/0)`
  );
  console.log('[cleanup-demo-data] готово');
}

main()
  .catch((e) => {
    console.error('[cleanup-demo-data] ОШИБКА:', e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
