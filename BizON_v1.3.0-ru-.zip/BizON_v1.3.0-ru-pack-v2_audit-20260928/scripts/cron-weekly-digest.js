// BizON — Этап 6.3 NOT: Weekly Digest cron
// Запускать каждый понедельник 09:00 (или по требованию).
//
// crontab:
//   0 9 * * 1  cd /home/z/my-project && BIZON_ENCRYPTION_KEY=... /usr/bin/node scripts/cron-weekly-digest.js >> /var/log/bizon-weekly-digest.log 2>&1
//
// Что делает:
//   1. Берёт всех пользователей, у которых weekly_digest != 'off'
//   2. Для каждого — собирает агрегированную сводку за последние 7 дней
//      (новые подтверждения, отклики, сообщения, упоминания, контакты, IP-score delta)
//   3. Создаёт Notification type='weekly_digest' с summary
//
// Идемпотентность: для каждого пользователя не создаём больше 1 дайджеста
// в понедельник (проверяем — нет ли уже weekly_digest за последние 6 дней).

const { PrismaClient } = require('@prisma/client');

// === Проверка BIZON_ENCRYPTION_KEY ===
const ENC_KEY = process.env.BIZON_ENCRYPTION_KEY;
if (!ENC_KEY) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в окружении.');
  console.error('   Запуск: BIZON_ENCRYPTION_KEY=... node scripts/cron-weekly-digest.js');
  process.exit(1);
}

const prisma = new PrismaClient();

const WEEKLY_DIGEST_TYPES = ['daily']; // настройки, при которых шлём дайджест
const DEDUP_WINDOW_HOURS = 6 * 24; // не создаём дайджест если за 6 дней уже был

// === Утилиты ===

function safeParseSettings(raw) {
  const defaults = {
    confirmation: 'instant',
    application: 'instant',
    message: 'instant',
    mention: 'instant',
    weekly_digest: 'daily',
    dnd: { enabled: true, from: '22:00', to: '08:00' },
  };
  if (!raw) return defaults;
  try {
    const p = JSON.parse(raw);
    return {
      confirmation: p.confirmation ?? 'instant',
      application: p.application ?? 'instant',
      message: p.message ?? 'instant',
      mention: p.mention ?? 'instant',
      weekly_digest: p.weekly_digest ?? 'daily',
      dnd: {
        enabled: p.dnd?.enabled ?? true,
        from: p.dnd?.from ?? '22:00',
        to: p.dnd?.to ?? '08:00',
      },
    };
  } catch {
    return defaults;
  }
}

async function buildDigestForUser(userId) {
  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const [confirmations, applications, messages, mentions, newConnections, topProject] = await Promise.all([
    prisma.notification.count({
      where: { userId, type: 'confirmation', createdAt: { gte: since } },
    }),
    prisma.notification.count({
      where: { userId, type: 'application', createdAt: { gte: since } },
    }),
    prisma.notification.count({
      where: { userId, type: 'message', createdAt: { gte: since } },
    }),
    prisma.notification.count({
      where: { userId, type: 'mention', createdAt: { gte: since } },
    }),
    prisma.connection.count({
      where: {
        OR: [{ fromUserId: userId }, { toUserId: userId }],
        status: 'accepted',
        updatedAt: { gte: since },
      },
    }),
    prisma.projectMember.findFirst({
      where: { userId },
      include: { project: { select: { title: true, rating: true } } },
      orderBy: { joinedAt: 'desc' },
    }),
  ]);

  // IP-score delta
  let ipScoreDelta = 0;
  try {
    const snapshots = await prisma.reputationSnapshot.findMany({
      where: { userId, createdAt: { gte: since } },
      orderBy: { createdAt: 'asc' },
      take: 50,
      select: { ipScore: true, createdAt: true },
    });
    if (snapshots.length > 0) {
      ipScoreDelta = snapshots[snapshots.length - 1].ipScore - snapshots[0].ipScore;
    }
  } catch {
    // ReputationSnapshot может не быть — игнорируем
  }

  const lines = [];
  if (confirmations > 0) lines.push(`подтверждений навыков: ${confirmations}`);
  if (applications > 0) lines.push(`откликов: ${applications}`);
  if (messages > 0) lines.push(`новых сообщений: ${messages}`);
  if (mentions > 0) lines.push(`упоминаний: ${mentions}`);
  if (newConnections > 0) lines.push(`новых контактов: ${newConnections}`);
  if (ipScoreDelta !== 0) lines.push(`IP-score ${ipScoreDelta > 0 ? '+' : ''}${ipScoreDelta}`);

  const summary =
    lines.length === 0
      ? 'На этой неделе активности не зафиксировано. Поделитесь постом или попросите коллегу подтвердить навык.'
      : `За неделю: ${lines.join(', ')}.`;

  return {
    confirmations,
    applications,
    messages,
    mentions,
    newConnections,
    ipScoreDelta,
    topProjectTitle: topProject?.project.title ?? null,
    summary,
  };
}

async function hasRecentDigest(userId) {
  const since = new Date(Date.now() - DEDUP_WINDOW_HOURS * 60 * 60 * 1000);
  const existing = await prisma.notification.findFirst({
    where: { userId, type: 'weekly_digest', createdAt: { gte: since } },
    select: { id: true },
  });
  return !!existing;
}

async function processUser(user) {
  const settings = safeParseSettings(user.notificationSettings);
  if (!WEEKLY_DIGEST_TYPES.includes(settings.weekly_digest)) {
    return { skipped: true, reason: 'weekly_digest is off' };
  }

  // Дедупликация
  const hasRecent = await hasRecentDigest(user.id);
  if (hasRecent) {
    return { skipped: true, reason: 'recent digest exists' };
  }

  const digest = await buildDigestForUser(user.id);

  // Пропускаем пользователей с нулевой активностью и без IP-score изменений,
  // чтобы не плодить «пустые» уведомления (только если была хоть какая-то активность).
  const hasActivity =
    digest.confirmations +
      digest.applications +
      digest.messages +
      digest.mentions +
      digest.newConnections >
    0;
  if (!hasActivity && digest.ipScoreDelta === 0) {
    return { skipped: true, reason: 'no activity this week' };
  }

  const title = `📊 Ваш недельный дайджест BizON`;
  const body = digest.summary;

  await prisma.notification.create({
    data: {
      userId: user.id,
      type: 'weekly_digest',
      title,
      content: body,
      link: '/me',
      metadata: JSON.stringify({
        confirmations: digest.confirmations,
        applications: digest.applications,
        messages: digest.messages,
        mentions: digest.mentions,
        newConnections: digest.newConnections,
        ipScoreDelta: digest.ipScoreDelta,
        topProjectTitle: digest.topProjectTitle,
      }),
    },
  });

  return { skipped: false, digest };
}

async function main() {
  console.log('=== BizON — Weekly Digest Cron ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log(`BIZON_ENCRYPTION_KEY: задан (${ENC_KEY.length} символов)\n`);

  // Берём всех пользователей пачками по 100
  let offset = 0;
  const BATCH = 100;
  let processed = 0;
  let digestsCreated = 0;
  let skippedOff = 0;
  let skippedRecent = 0;
  let skippedNoActivity = 0;
  const errors = [];

  while (true) {
    const users = await prisma.user.findMany({
      select: { id: true, name: true, notificationSettings: true },
      take: BATCH,
      skip: offset,
    });
    if (users.length === 0) break;

    for (const u of users) {
      try {
        const result = await processUser(u);
        processed++;
        if (result.skipped) {
          if (result.reason === 'weekly_digest is off') skippedOff++;
          else if (result.reason === 'recent digest exists') skippedRecent++;
          else if (result.reason === 'no activity this week') skippedNoActivity++;
        } else {
          digestsCreated++;
          console.log(`  📊 ${u.name} (${u.id}): digest создан`);
        }
      } catch (e) {
        console.error(`  ❌ ${u.name} (${u.id}): error:`, e.message);
        errors.push({ userId: u.id, error: e.message });
      }
    }

    offset += BATCH;
  }

  console.log('\n=== Итог ===');
  console.log(`  Всего пользователей обработано: ${processed}`);
  console.log(`  Дайджестов создано:             ${digestsCreated}`);
  console.log(`  Пропущено (off):                ${skippedOff}`);
  console.log(`  Пропущено (недавний дайджест):  ${skippedRecent}`);
  console.log(`  Пропущено (нет активности):     ${skippedNoActivity}`);
  console.log(`  Ошибок:                         ${errors.length}`);
  console.log('\n✅ Weekly digest cron complete.');
}

main()
  .catch((e) => {
    console.error('❌ Weekly digest cron failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
