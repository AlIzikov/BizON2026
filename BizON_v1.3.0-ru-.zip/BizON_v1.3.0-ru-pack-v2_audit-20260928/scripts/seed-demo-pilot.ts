// ЭТАП 1.2 директивы «ПРЕД-ПИЛОТ» · demo-аккаунт пилотной компании + демо-данные.
//
// Цель: за 3 дня к kick-off у нас есть готовый демо-контур, на котором HR
// компании обучается БЕЗ риска для боевых данных:
//   company_demo@bizon.demo / Pilot-2026!Demo (пароль выдаётся HR отдельно)
// Засеяно по директиве:
//   • 20+ кандидатов с NFT-навыками (NFTSkill status='minted')
//   • 3 вакансии демо-компании
//   • 10+ endorsements (тексты ≥100 символов — гейт N4/N6)
//   • 5+ резонанс-матчей (score ≥70, XAI reasons/missing/factors)
//
// ИДЕМПОТЕНТНО: upsert по стабильным email/названиям; повторный запуск
// дозаполняет недостающее, не дублирует.
//
// Reset: scripts/reset-demo-data.ts — сносит демо-данные и зовёт этот сид заново.
//
// Запуск: bun run scripts/seed-demo-pilot.ts
import { PrismaClient } from '@prisma/client';
import { encrypt, hashEmail } from '../src/lib/security/crypto';

const db = new PrismaClient();

const DEMO_EMAIL = 'company_demo@bizon.demo';
const DEMO_PASSWORD = 'Pilot-2026!Demo';
const DEMO_TAG = '[DEMO-PILOT]';

async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 600_000, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const saltHex = Array.from(salt).map((b) => b.toString(16).padStart(2, '0')).join('');
  const hashHex = Array.from(new Uint8Array(derivedBits)).map((b) => b.toString(16).padStart(2, '0')).join('');
  return `pbkdf2$600000$${saltHex}$${hashHex}`;
}

// 22 демо-кандидата: имя, должность, 3 навыка (первый — «NFT-якорь»)
const CANDIDATES: Array<{ name: string; title: string; skills: [string, string, string]; city: string }> = [
  { name: 'Анна Ковалёва', title: 'Senior Frontend Developer', skills: ['React', 'TypeScript', 'CSS3'], city: 'Москва' },
  { name: 'Дмитрий Соколов', title: 'Backend Developer', skills: ['Node.js', 'PostgreSQL', 'Docker'], city: 'Санкт-Петербург' },
  { name: 'Марина Лебедева', title: 'Product Manager', skills: ['Product Discovery', 'A/B тесты', 'Roadmapping'], city: 'Москва' },
  { name: 'Игорь Петухов', title: 'DevOps Engineer', skills: ['Kubernetes', 'Terraform', 'CI/CD'], city: 'Новосибирск' },
  { name: 'Ольга Морозова', title: 'UX/UI Designer', skills: ['Figma', 'Design System', 'User Research'], city: 'Казань' },
  { name: 'Сергей Носов', title: 'Data Analyst', skills: ['SQL', 'Python', 'Tableau'], city: 'Екатеринбург' },
  { name: 'Елена Громова', title: 'QA Lead', skills: ['Test Automation', 'Playwright', 'API Testing'], city: 'Москва' },
  { name: 'Павел Орлов', title: 'ML Engineer', skills: ['PyTorch', 'MLOps', 'NLP'], city: 'Москва' },
  { name: 'Ксения Белова', title: 'HR Business Partner', skills: ['Recruiting', 'OKR', '1:1 Interviews'], city: 'Самара' },
  { name: 'Артём Волков', title: 'Go Developer', skills: ['Go', 'gRPC', 'Kafka'], city: 'Воронеж' },
  { name: 'Наталья Стрелкова', title: 'Financial Analyst', skills: ['FP&A', 'Excel', 'Power BI'], city: 'Краснодар' },
  { name: 'Виктор Крылов', title: 'Security Engineer', skills: ['Pentest', 'SOC 2', 'SIEM'], city: 'Москва' },
  { name: 'Дарья Зорина', title: 'Content Manager', skills: ['Copywriting', 'SEO', 'Analytics'], city: 'Тверь' },
  { name: 'Максим Юдин', title: 'Mobile Developer', skills: ['Kotlin', 'Swift', 'Flutter'], city: 'Сочи' },
  { name: 'Алина Светлова', title: 'Business Analyst', skills: ['BPMN', 'Requirements', 'SQL'], city: 'Пермь' },
  { name: 'Роман Гуров', title: 'Site Reliability Engineer', skills: ['SRE', 'Prometheus', 'Grafana'], city: 'Москва' },
  { name: 'Юлия Тихонова', title: 'Project Manager', skills: ['Agile', 'Scrum', 'Jira'], city: 'Челябинск' },
  { name: 'Кирилл Лапин', title: 'System Architect', skills: ['Microservices', 'Event Sourcing', 'DDD'], city: 'Москва' },
  { name: 'Полина Ежова', title: 'Customer Success Manager', skills: ['Onboarding', 'Churn Analysis', 'CRM'], city: 'Уфа' },
  { name: 'Никита Буров', title: 'Rust Developer', skills: ['Rust', 'WebAssembly', 'Tokio'], city: 'Омск' },
  { name: 'Светлана Ясная', title: 'Marketing Analyst', skills: ['GA4', 'Performance Marketing', 'SQL'], city: 'Ростов-на-Дону' },
  { name: 'Глеб Стальной', title: 'Technical Writer', skills: ['Docs as Code', 'API Docs', 'Markdown'], city: 'Владивосток' },
];

const VACANCIES = [
  {
    title: 'Senior Frontend Developer (React)',
    description:
      'Ищем сильного фронтендера в продуктовую команду. Стек: React + TypeScript, дизайн-система, микрофронтенды. Важна самостоятельность и внимание к качеству интерфейсов. Команда 8 человек, продуктовая разработка без аутстаффа.',
    requiredSkills: 'React,TypeScript,CSS3',
    salaryFrom: 280000,
    salaryTo: 380000,
    location: 'Москва',
    level: 'Senior',
    workFormat: 'hybrid',
  },
  {
    title: 'Backend Developer (Node.js)',
    description:
      'Разработка core-сервисов платформы найма: API, события, интеграции. Стек: Node.js, PostgreSQL, Docker. Ожидаем опыт проектирования API и работы с очередями. Команда небольшая, влияния на архитектуру много.',
    requiredSkills: 'Node.js,PostgreSQL,Docker',
    salaryFrom: 250000,
    salaryTo: 340000,
    location: 'Санкт-Петербург',
    level: 'Middle',
    workFormat: 'remote',
  },
  {
    title: 'Product Manager (B2B)',
    description:
      'B2B-продукт для HR-команд: discovery, метрики, гипотезы. Нужен опыт B2B SaaS, работа с enterprise-клиентами, умение приоритизировать в условиях ограниченных ресурсов. В подчинении аналитик и дизайнер.',
    requiredSkills: 'Product Discovery,A/B тесты,Roadmapping',
    salaryFrom: 300000,
    salaryTo: 420000,
    location: 'Москва',
    level: 'Lead',
    workFormat: 'hybrid',
  },
];

const ENDORSEMENT_TEXTS = [
  'Работал с этим человеком два года в одной команде: закрывала самые сложные фронтенд-задачи спринта,_Code review оставлял(а) подробным и полезным для коллег.',
  'Отличный специалист и надёжный коллега. В кризисный релиз взял(а) на себя коммуникацию с продакшеном и довёл(а) миграцию до конца без единой потери данных.',
  'Подтверждаю экспертизу: проектирует архитектуру так, что новые люди включаются в проект за дни, а не недели. Наставлял(а) двух джунов — оба выросли до мидлов.',
  'Строит процессы так, что команда перестала пропускать дедлайны. Ввёл(а) ретро и понятный статус-флоу. Рекомендую как сильного организатора и профессионала.',
  'Вместе запускали продукт с нуля: снаружи — чистый и предсказуемый интерфейс, внутри — аккуратный код и тесты. Претензий по качеству не было ни одного релиза.',
  'Регулярно приносил(а) решения, которые экономили недели работы: автоматизация ручного деплоя, единый логгер, переиспользуемая дизайн-система. Ценный человек в команде.',
  'Проверял(а) его(её) аналитику в проекте для клиента: расчёты воспроизводимы, выводы понятны бизнесу без перевода. Редкое сочетание строгости и ясности.',
  'Лучший наставник из тех, с кем я работал(а): разворачивал(а) новичков, писал(а) гайды, терпеливо объяснял(а) архитектуру. Профессионал с человеческим подходом.',
];

const ENDORSE_SKILLS_BY_INDEX = [
  'React', 'Node.js', 'Kubernetes', 'Product Discovery', 'Figma', 'SQL',
  'Test Automation', 'PyTorch', 'Recruiting', 'Go', 'FP&A', 'Pentest',
];

const MATCH_REASONS = [
  'Высокий резонанс по стилю работы: совпадают предпочтения в самостоятельности и обратной связи.',
  'Совпадение по навыкам: ядро стека вакансии подтверждено коллегами.',
  'Совпадение по темпу и формату работы: комфортны и удалённые, и гибридные сессии.',
];

const MATCH_MISSING = [
  'Нет подтверждений по одному из вторичных навыков вакансии.',
  'Мало совместных наблюдений по стресс-сценариям (нет evidence от прошлых команд).',
];

const TRAITS = ['decision_making', 'feedback_style', 'autonomy', 'pace', 'exploration', 'structure', 'collaboration', 'conflict'];

async function ensureUser(email: string, name: string, title: string, opts: { accountType: string; password: string; roles?: string }) {
  const emailHash = hashEmail(email);
  let user = await db.user.findFirst({ where: { emailHash, deletedAt: null } });
  if (user) return { user, created: false };
  user = await db.user.create({
    data: {
      name,
      title,
      emailHash,
      emailEncrypted: encrypt(email),
      passwordHash: await hashPassword(opts.password),
      roles: opts.roles ?? '',
      accountType: opts.accountType,
      subscriptionTier: 'free',
      ipScore: 65,
      level: '3',
      emailVerified: true,
      acceptedTosAt: new Date(),
      hrInvisible: false,
    },
  });
  return { user, created: true };
}

async function main() {
  console.log(`[demo-pilot] сид демо-данных ${DEMO_TAG}`);

  // 1. Демо-компания: Company-запись (иначе /api/jobs для company-юзера без
  // companyId отдаёт ВСЕ вакансии платформы — found live-пробой 27-09) + юзер-владелец
  const companyName = 'ООО «Демо-Компания» (пред-пилот)';
  let companyRow = await db.company.findFirst({ where: { name: companyName } });
  if (!companyRow) {
    companyRow = await db.company.create({
      data: {
        name: companyName,
        description:
          'Демо-контур пред-пилота BizON: 3 вакансии, 22 кандидата с подтверждёнными навыками. Данные учебные, обезличены и пересоздаются reset-скриптом.',
        industry: 'IT',
        size: '11-50',
        location: 'Москва',
        foundedYear: 2024,
      },
    });
  }

  const { user: company, created: companyCreated } = await ensureUser(
    DEMO_EMAIL,
    'HR-команда демо-компании',
    'HR-менеджер демо-компании',
    { accountType: 'company', password: DEMO_PASSWORD, roles: '' },
  );
  // привязка юзера к Company (главный гейт семантики «свои вакансии»)
  if (company.companyId !== companyRow.id) {
    await db.user.update({ where: { id: company.id }, data: { companyId: companyRow.id } });
  }
  company.companyId = companyRow.id;
  console.log(`[demo-pilot] компания: ${company.id} ${companyCreated ? '(создана)' : '(уже есть)'}, Company row: ${companyRow.id}`);

  const { user: candidateOwner, created: candOwnerCreated } = await ensureUser(
    'demo.endorser@bizon.demo',
    'Мария Референс (демо)',
    'Коллега демо-кандидатов',
    { accountType: 'individual', password: 'Pilot-2026!Demo' },
  );
  console.log(`[demo-pilot] референс-юзер: ${candidateOwner.id} ${candOwnerCreated ? '(создан)' : '(уже есть)'}`);

  // 2. Кандидаты + UserSkill + NFTSkill
  const candidateIds: string[] = [];
  let nftCount = 0;
  for (const [i, c] of CANDIDATES.entries()) {
    const { user } = await ensureUser(
      `demo.candidate.${String(i + 1).padStart(2, '0')}@bizon.demo`,
      c.name,
      c.title,
      { accountType: 'individual', password: 'Pilot-2026!Demo' },
    );
    candidateIds.push(user.id);

    for (const [j, skillName] of c.skills.entries()) {
      const skill = await db.skill.upsert({
        where: { name: skillName },
        create: { name: skillName, category: 'demo' },
        update: {},
      });
      const level = 3 + ((i + j) % 3); // 3..5
      const us = await db.userSkill.upsert({
        where: { userId_skillId: { userId: user.id, skillId: skill.id } },
        create: {
          userId: user.id,
          skillId: skill.id,
          level,
          confirmationsCount: 3,
          nftEligible: true,
          verificationLevel: 'verified',
          selfAssessment: level * 20,
          verifiedScore: level * 20 - 5,
        },
        update: {
          confirmationsCount: 3,
          nftEligible: true,
          verificationLevel: 'verified',
        },
      });
      // Первый навык каждого кандидата — NFT (minted) → «20+ кандидатов с NFT-навыками»
      if (j === 0) {
        const nft = await db.nFTSkill.findFirst({ where: { userId: user.id, skillName, status: { not: 'revoked' } } });
        if (!nft) {
          await db.nFTSkill.create({
            data: {
              userSkillId: us.id,
              userId: user.id,
              tokenId: `demo-token-${i + 1}`,
              skillName,
              level,
              endorsementsCount: 3,
              mintedAt: new Date(),
              status: 'minted',
              metadataUri: `demo://skills/${skillName.toLowerCase()}/${user.id}`,
            },
          });
          nftCount++;
        }
      }
    }
  }
  const totalNft = await db.nFTSkill.count({ where: { userId: { in: candidateIds }, status: 'minted' } });
  console.log(`[demo-pilot] кандидатов: ${candidateIds.length}, NFT-навыков (minted): ${totalNft} (+${nftCount} новых)`);

  // 3. Резонанс-профили кандидатам (completed) — чтобы матчи были честными по схеме
  for (const uid of candidateIds) {
    const theta = Object.fromEntries(
      TRAITS.map((t, k) => [t, { theta: +(((uid.length + k) % 9) - 4) / 2, se: 0.35, answeredCount: 2 }]),
    );
    const existing = await db.resonanceProfile.findUnique({ where: { userId: uid } });
    if (existing) {
      if (existing.status !== 'completed') {
        await db.resonanceProfile.update({
          where: { userId: uid },
          data: { status: 'completed', thetaJson: theta, completedAt: new Date(), minAnswersRequired: 16 },
        });
      }
    } else {
      await db.resonanceProfile.create({
        data: { userId: uid, status: 'completed', thetaJson: theta, completedAt: new Date(), minAnswersRequired: 16 },
      });
    }
  }
  console.log('[demo-pilot] резонанс-профили: completed у всех кандидатов');

  // 4. 3 вакансии демо-компании (title с DEMO-тегом для reset-детекта)
  const jobIds: string[] = [];
  for (const [i, v] of VACANCIES.entries()) {
    const title = `${DEMO_TAG} ${v.title}`;
    let job = await db.job.findFirst({ where: { title, hiringManagerId: company.id } });
    if (!job) {
      job = await db.job.create({
        data: {
          title,
          company: 'ООО «Демо-Компания»',
          description: v.description,
          requiredSkills: v.requiredSkills,
          salaryFrom: v.salaryFrom,
          salaryTo: v.salaryTo,
          salaryMin: v.salaryFrom,
          salaryMax: v.salaryTo,
          location: v.location,
          level: v.level,
          workFormat: v.workFormat,
          growthScore: 0.7,
          active: true,
          vacancyStatus: 'active',
          hiringManagerId: company.id,
          companyId: company.companyId,
        },
      });
    } else if (job.companyId !== company.companyId) {
      // дозаполнение при повторном сиде: вакансия должна принадлежать Company
      await db.job.update({ where: { id: job.id }, data: { companyId: company.companyId } });
    }
    jobIds.push(job.id);
  }
  console.log(`[demo-pilot] вакансий: ${jobIds.length}`);

  // 5. 10+ endorsements (автор — референс-юзер; текст ≥100 символов)
  let endorsementsCreated = 0;
  for (let i = 0; i < candidateIds.length && endorsementsCreated < 12; i++) {
    const subjectId = candidateIds[i];
    const skillName = ENDORSE_SKILLS_BY_INDEX[i % ENDORSE_SKILLS_BY_INDEX.length];
    const text = `${ENDORSEMENT_TEXTS[i % ENDORSEMENT_TEXTS.length]} Навык: ${skillName}.`.replace('_Code', 'Код');
    const exists = await db.endorsement.findFirst({ where: { authorId: candidateOwner.id, subjectId, skillName, status: 'active' } });
    if (!exists) {
      await db.endorsement.create({
        data: {
          authorId: candidateOwner.id,
          subjectId,
          skillName,
          text,
          weight: 0.7 + (i % 3) * 0.1,
          status: 'active',
          lastWeightComputedAt: new Date(),
        },
      });
      endorsementsCreated++;
    }
  }
  const totalEndorsements = await db.endorsement.count({
    where: { subjectId: { in: candidateIds }, status: 'active' },
  });
  console.log(`[demo-pilot] endorsements: +${endorsementsCreated} новых, всего активных на кандидатов: ${totalEndorsements}`);

  // 6. 5+ резонанс-матчей (score ≥70, XAI) на первые две вакансии
  const formulaVersion = 'resonance-v1.2-demo';
  let matchesCreated = 0;
  for (const [vi, jobId] of jobIds.slice(0, 2).entries()) {
    for (let k = 0; k < 4; k++) {
      const userId = candidateIds[(vi * 4 + k) % candidateIds.length];
      const score = 74 + ((vi * 4 + k) % 6) * 4; // 74..94
      const existing = await db.resonanceMatch.findUnique({ where: { userId_jobId: { userId, jobId } } });
      if (!existing) {
        await db.resonanceMatch.create({
          data: {
            userId,
            jobId,
            score,
            factorsJson: { skill: 0.82, value: 0.74, culture: 0.79, growth: 0.7, warmBonus: 0.05 },
            reasonsJson: [
              MATCH_REASONS[(vi + k) % MATCH_REASONS.length],
              `Порог просмотра 70+ пройден: score ${score}.`,
            ],
            missingJson: [MATCH_MISSING[(k + vi) % MATCH_MISSING.length]],
            formulaVersion,
          },
        });
        matchesCreated++;
      }
    }
  }
  const totalMatches = await db.resonanceMatch.count({ where: { jobId: { in: jobIds } } });
  console.log(`[demo-pilot] резонанс-матчи: +${matchesCreated} новых, всего: ${totalMatches}`);

  // 7. Отклики демо-кандидатов на демо-вакансии (пайплайн дашборда компании:
  //    «кандидатов в пайплайне» = applications, не матчи). Статусы разнообразим.
  const APP_STATUSES = ['submitted', 'viewed', 'reviewed', 'interview', 'interview', 'submitted'];
  let applicationsCreated = 0;
  for (const [vi, jobId] of jobIds.entries()) {
    for (let k = 0; k < 4; k++) {
      const userId = candidateIds[(vi * 4 + k) % candidateIds.length];
      const exists = await db.jobApplication.findUnique({ where: { jobId_userId: { jobId, userId } } });
      if (exists) continue;
      await db.jobApplication.create({
        data: {
          jobId,
          userId,
          status: APP_STATUSES[(vi * 4 + k) % APP_STATUSES.length],
          matchConfidence: 0.72 + ((vi + k) % 5) * 0.05,
          coverLetter: '[DEMO-PILOT] Демо-отклик для обучения HR-команды. Создан сид-скриптом пред-пилота.',
          responseStatus: 'new',
        },
      });
      applicationsCreated++;
    }
  }
  const totalApplications = await db.jobApplication.count({ where: { jobId: { in: jobIds } } });
  console.log(`[demo-pilot] отклики кандидатов: +${applicationsCreated} новых, всего: ${totalApplications}`);

  // Итог
  const ok =
    candidateIds.length >= 20 &&
    totalNft >= 20 &&
    jobIds.length === 3 &&
    totalEndorsements >= 10 &&
    totalMatches >= 5 &&
    totalApplications >= 10;
  console.log(
    ok
      ? `[demo-pilot] OK: критерии директивы выполнены (20+ кандидатов/NFT, 3 вакансии, 10+ endorsements, 5+ матчей, 10+ откликов).`
      : `[demo-pilot] ВНИМАНИЕ: критерии не добиты — проверь вывод выше.`,
  );
  if (!ok) process.exit(1);
}

main()
  .then(() => db.$disconnect())
  .catch(async (e) => {
    console.error('[demo-pilot] FAIL:', e);
    await db.$disconnect();
    process.exit(1);
  });
