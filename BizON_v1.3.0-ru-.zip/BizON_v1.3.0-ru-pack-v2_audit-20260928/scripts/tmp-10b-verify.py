#!/usr/bin/env python3
# Временный скрипт верификации Task 10-b (удалить после прогона).
import json
import urllib.request

BASE = 'http://21.0.3.2:81'
DEMO = '8a4be271d397c02c84b17fe8d4edaa5a1d3fe9c60b9ad232c34459ad2900e758'  # individual (ivan)
COMPANY = 'cd85af379580f950610fcf07997c96ad63347bfeaa6d9f29'  # QA3 Company C (company)
HR = '2c2d204cc8dba8cc84676a35b3d32c78e734863b4384c369'  # IT Recruiting Pro (hr_agency)
BIZON = 'cmtlwo7hw00amme6uxof0jjii'
QA3 = 'cmtoxx1yp0021l5cgviknpipu'


def req(method, path, token=None, body=None):
    headers = {'Content-Type': 'application/json'}
    if token:
        headers['Cookie'] = f'bizon_session={token}'
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            raw = resp.read().decode()
            try:
                payload = json.loads(raw) if raw else None
            except Exception:
                payload = raw[:120]
            return resp.status, payload
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try:
            payload = json.loads(raw) if raw else None
        except Exception:
            payload = raw[:120]
        return e.code, payload


def show(label, status, payload, keys=None):
    extra = ''
    if keys and isinstance(payload, dict):
        extra = ' | ' + ', '.join(f'{k}={json.dumps(payload.get(k), ensure_ascii=False)[:110]}' for k in keys)
    print(f'{label}: {status}{extra}')


print('=== 1. GET / (страница жива) ===')
r = urllib.request.Request(BASE + '/')
with urllib.request.urlopen(r, timeout=30) as resp:
    print('GET /:', resp.status)

print('=== 2. demo-token (individual) на company-API → 403/401 ===')
s, p = req('GET', '/api/build-talent/candidates?skills=Python', DEMO)
show('build-talent individual', s, p, ['error'])
s, p = req('POST', '/api/team-builder/compose', DEMO, {'roles': [{'title': 'X', 'skills': ['Python']}]})
show('team-builder individual', s, p, ['error'])
s, p = req('GET', '/api/workforce/overview', DEMO)
show('workforce individual', s, p, ['error'])

print('=== 3. bogus token → 401 ===')
s, p = req('GET', '/api/build-talent/candidates?skills=Python', 'bogus-token-000')
show('build-talent bogus', s, p, ['error'])

print('=== 4. company-сессия QA3 Company C ===')
s, p = req('GET', '/api/build-talent/candidates?skills=Python:6,Docker&limit=10', COMPANY)
show('build-talent company GET', s, p, ['totalCandidates', 'formulaVersion', 'privacy'])
if isinstance(p, dict) and p.get('candidates'):
    top = p['candidates'][0]
    print('  top:', top['name'], 'score', top['score'], '| why[0]:', (top['why'] or ['-'])[0][:90])

roles = [
    {'title': 'Backend Engineer', 'skills': ['TypeScript:8', 'Node.js:7']},
    {'title': 'DevOps Engineer', 'skills': ['Docker:7', 'Kubernetes:6']},
]
s1, p1 = req('POST', '/api/team-builder/compose', COMPANY, {'roles': roles})
s2, p2 = req('POST', '/api/team-builder/compose', COMPANY, {'roles': roles})
show('team-builder compose #1', s1, p1, ['coverage', 'deterministic', 'persisted'])
show('team-builder compose #2', s2, p2, ['coverage', 'deterministic', 'persisted'])
t1 = json.dumps(p1.get('team') if isinstance(p1, dict) else None, sort_keys=True, ensure_ascii=False)
t2 = json.dumps(p2.get('team') if isinstance(p2, dict) else None, sort_keys=True, ensure_ascii=False)
print('  DETERMINISM team identical:', t1 == t2, '| team size:', len(p1.get('team', [])) if isinstance(p1, dict) else 'n/a')

s, p = req('GET', f'/api/workforce/overview?companyId={QA3}', COMPANY)
show('workforce company QA3', s, p, ['demand', 'companyName', 'chain'])

s, p = req('GET', f'/api/company/intelligence?companyId={BIZON}', COMPANY)
show('company-intelligence BizON', s, p, ['generatedAt'])
if isinstance(p, dict):
    print('  footprint:', p.get('dataFootprint'))
    print('  timeline items:', len(p.get('timeline', {}).get('items', [])), '| topSkills:', p.get('currentNeeds', {}).get('topSkills'))

print('=== 5. hr_agency-сессия IT Recruiting Pro ===')
s, p = req('GET', '/api/build-talent/candidates?skills=Docker,Python', HR)
show('build-talent hr GET', s, p, ['totalCandidates', 'note'])
s, p = req('GET', f'/api/workforce/overview?companyId={BIZON}', HR)
show('workforce hr BizON', s, p, ['demand', 'companyName', 'hrAgencyOutreach'])
s, p = req('POST', '/api/team-builder/compose', HR, {'roles': [{'title': 'Data Engineer', 'skills': ['Python:8', 'PostgreSQL:6']}]})
show('team-builder hr POST', s, p, ['coverage', 'successProbability'])

print('=== 6. company-intelligence доступен individual-сессии (публичная аналитика) ===')
s, p = req('GET', f'/api/company/intelligence?companyId={BIZON}', DEMO)
show('company-intelligence demo(individual)', s, p, ['generatedAt'])

print('=== 7. Ошибочные ветки ===')
s, p = req('GET', '/api/company/intelligence', COMPANY)
show('company-intelligence без companyId', s, p, ['error'])
s, p = req('GET', '/api/company/intelligence?companyId=nonexistent-id-xyz', COMPANY)
show('company-intelligence 404', s, p, ['error'])
s, p = req('GET', '/api/build-talent/candidates', COMPANY)
show('build-talent без skills', s, p, ['error'])
