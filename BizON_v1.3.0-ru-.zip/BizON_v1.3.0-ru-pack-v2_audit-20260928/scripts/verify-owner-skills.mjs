#!/usr/bin/env node
// Оракул целостности реестра навыков владельца (docs/OWNER-SKILLS.md).
// Правило (урок design-16-audit): навык без проверяемого артефакта = не внедрён;
// артефакты проверяются ФАКТОМ существования, а не по памяти.
import { existsSync, statSync } from "node:fs";

const root = process.cwd();
const assertFile = (p) => {
  if (!existsSync(`${root}/${p}`)) {
    console.error(`FAIL: отсутствует артефакт навыка: ${p}`);
    process.exit(1);
  }
};
const assertGte = (p, bytes) => {
  assertFile(p);
  const size = statSync(`${root}/${p}`).size;
  if (size < bytes) {
    console.error(`FAIL: артефакт подозрительно мал (${size}B < ${bytes}B): ${p}`);
    process.exit(1);
  }
};

// --- A. Эталонные проекты ---
[
  "docs/BENCHMARK-STUDY.md",
  "docs/AGENT-WORKFLOW.md",
  "docs/BIZON-GAP-MATRIX.md",
  "src/lib/ai-governance/governance-service.ts",
  "src/lib/ai-governance/action-registry.ts",
  "src/components/settings/decision-inbox.tsx",
  "src/lib/security/prompt-sanitizer.ts",
  "src/lib/ai-core/gateway.ts",
  "src/lib/with-route.ts",
].forEach((p) => assertGte(p, 400));

// eval-suite (№09)
["src/lib/ai-eval/suite.ts", "src/lib/ai-eval/generators.ts", "docs/ai-eval/REPORT-latest.md"].forEach((p) => assertFile(p));

// unlazy (№15, вендоринг)
["tools/unlazy/scripts/gate-check.mjs", "tools/unlazy/scripts/gate-lint.mjs", "specs/adopt-unlazy/GATES.md", "specs/adopt-emil-skills/GATES.md"].forEach((p) => assertFile(p));

// --- B. REPO-LEARNING + Rocq ---
["docs/knowledge/REPO-LEARNING-2026-09-19.md", "docs/knowledge/ROCQ-DEEP-STUDY-2026-09-19.md", "docs/knowledge/rocq/BizonInvariants.v"].forEach((p) => assertFile(p));
assertGte("docs/knowledge/rocq/BizonInvariants.v", 1000);

// --- Реестр существует и описывает себя ---
assertFile("docs/OWNER-SKILLS.md");
assertGte("docs/OWNER-SKILLS.md", 2000);

console.log("OWNER_SKILLS_GATE_OK");
