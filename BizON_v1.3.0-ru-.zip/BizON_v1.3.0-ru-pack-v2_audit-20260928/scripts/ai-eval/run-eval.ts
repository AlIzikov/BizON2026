// BizON — CLI-раннер BIZON AI EVALUATION SUITE (№09 Promptfoo-паттерн).
//
// Запуск:  bun run scripts/ai-eval/run-eval.ts
// С LLM:   BIZON_AI_EVAL_LLM=1 bun run scripts/ai-eval/run-eval.ts
//
// Пишет отчёт в docs/ai-eval/REPORT-latest.json и печатает сводку.
// Exit code 1 — если есть FAIL (гейт для CI/локальных прогонов).

import { mkdirSync, writeFileSync } from 'fs';
import { buildSuite, runSuite } from '../../src/lib/ai-eval/suite';

async function main() {
  const cases = buildSuite();
  console.log(`BIZON AI EVALUATION SUITE — ${cases.length} сценариев`);
  const report = await runSuite(cases, { includeResults: true });

  const outDir = new URL('../../docs/ai-eval/', import.meta.url).pathname;
  mkdirSync(outDir, { recursive: true });
  writeFileSync(`${outDir}REPORT-latest.json`, JSON.stringify(report, null, 2), 'utf-8');

  // Markdown-сводка
  const md: string[] = [
    `# BIZON AI EVALUATION SUITE — отчёт ${report.ranAt}`,
    '',
    `Всего: **${report.total}** · PASS: **${report.pass}** · FAIL: **${report.fail}** · SKIP: **${report.skip}** · ${report.durationMs}ms · LLM: ${report.llmBacked ? 'задействован' : 'off (SKIP)'}`,
    '',
    '| Категория | Всего | PASS | FAIL | SKIP |',
    '|---|---|---|---|---|',
    ...report.byCategory.map((s) => `| ${s.category} | ${s.total} | ${s.pass} | ${s.fail} | ${s.skip} |`),
    '',
  ];
  if (report.failures.length > 0) {
    md.push('## Провалы', '');
    for (const f of report.failures.slice(0, 50)) {
      md.push(`- **${f.id}** — ${f.name}: ${f.detail}`);
    }
  }
  writeFileSync(`${outDir}REPORT-latest.md`, md.join('\n'), 'utf-8');

  console.table(report.byCategory.map((s) => ({ category: s.category, total: s.total, pass: s.pass, fail: s.fail, skip: s.skip })));
  if (report.failures.length > 0) {
    console.error(`FAIL: ${report.failures.length}`);
    for (const f of report.failures.slice(0, 20)) {
      console.error(`  ${f.id}: ${f.detail}`);
    }
  } else {
    console.log('PASS: все сценарии зелёные (SKIP = LLM-сценарии без BIZON_AI_EVAL_LLM=1)');
  }
  process.exit(report.fail > 0 ? 1 : 0);
}

main();
