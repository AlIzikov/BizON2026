// BizON v6 — Smoke-тест Event Bus (Task 4-e: «Оживление Event Bus»)
//
// Запуск: bun run scripts/test-event-bus.ts
//
// Проверяет:
//   1. Синглтон шины импортируется и работает вне Next.js (bun runtime).
//   2. Подписчики из src/lib/event-bus/subscribers.ts регистрируются ровно один раз
//      (через bootstrap шины + самозапуск модуля — globalThis-guard отсекает дубли).
//   3. Публикация job.applied доставляет событие хендлеру, подписанному ДО публикации.
//   4. Полный пайплайн: доменный подписчик job.applied вызывается и через
//      NotificationService пытается создать уведомление (для тестового userId
//      пользователя нет в БД → notify вернёт null — это штатный fail-open путь).
import { EventBus } from '../src/lib/event-bus';
import '../src/lib/event-bus/subscribers';

async function main(): Promise<void> {
  console.log('--- BizON Event Bus smoke test (Task 4-e) ---');

  // Подписчики из subscribers.ts уже зарегистрированы при импорте модуля:
  console.log('listeners on job.applied (доменный подписчик):', EventBus.listenerCount('job.applied'));

  let executed = false;

  // Тестовый хендлер — подписывается ДО публикации
  const unsubscribe = EventBus.subscribe('job.applied', (event) => {
    executed = true;
    console.log(
      `[test] handler executed: type=${event.type} seq=${event.seq} payload=${JSON.stringify(event.payload)}`
    );
  });

  const result = await EventBus.publish('job.applied', {
    userId: 'event-bus-smoke-user',
    jobId: 'event-bus-smoke-job',
    jobTitle: 'Тестовая вакансия (Event Bus smoke)',
  });

  unsubscribe(); // снимаем тестовый хендлер
  console.log('[test] publish result:', JSON.stringify(result));
  console.log('[test] DLQ size:', EventBus.getDLQ().length);

  if (executed && result.delivered >= 1) {
    console.log('EVENT BUS OK: handler executed');
  } else {
    console.error('EVENT BUS FAIL: handler was not executed');
    process.exit(1);
  }
}

void main();
