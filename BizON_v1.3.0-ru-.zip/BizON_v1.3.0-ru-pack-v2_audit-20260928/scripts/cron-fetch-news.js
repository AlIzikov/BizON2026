// BizON — Этап 5.1 + doc_a §15 — Cron: NB (News Barter) RSS fetcher
//
// Архитектура (doc_a §15 «Company News Source»):
//   Company → свой RSS → News Bridge → AI extraction → BizON Stream → Traffic Back
//   (компания подключает свои RSS в /api/news/sources → этот крон забирает ленты →
//    AI-резюме → карточки BizON Stream → трафик возвращается на платформу)
//
// Источники (в порядке приоритета):
//   1. Company.newsSources — RSS-ленты, подключённые компаниями (/api/news/sources)
//   2. User.newsSources    — RSS-ленты, подключённые пользователями (individual)
//   3. Fallback-пул: vc.ru, habr.com, rb.ru (hardcoded ниже)
//
// Формат поля newsSources — JSON-массив строк-URL (так сохраняет POST /api/news/sources:
// JSON.stringify(['https://example.com/rss', ...]), до 5 URL на владельца).
//
// Для каждой статьи:
//   1. fetch og:title, og:description, og:image (через safe HTTP)
//   2. AI-резюме через z-ai-web-dev-sdk (50-100 символов на русском)
//   3. Дедупликация по url (findFirst по url перед create)
//   4. Сохраняет в NewsCard со status='pending' (ждёт модератора)
//   5. Лимит 100 карточек/день
//
// Отказоустойчивость:
//   - try/catch на КАЖДЫЙ источник: один битый RSS не роняет крон
//   - rate limit: 500ms пауза между фетчами источников
//   - FAIL-OPEN: ошибки в одном источнике не прерывают другие
//   - Идемпотентность: повторный запуск безопасен (дедупликация по url)
//   - SSRF protection: используем validateUrlSafety из lib/security/ssrf (inlined)
//   - Лимит 100 карточек/день: не создаём более 100 новых записей в сутки
//
// Запуск:
//   BIZON_ENCRYPTION_KEY=... ZAI_API_KEY=... node scripts/cron-fetch-news.js
//
// Cron (ежечасно):
//   0 * * * *  cd /home/z/my-project && BIZON_ENCRYPTION_KEY=... ZAI_API_KEY=... /usr/bin/node scripts/cron-fetch-news.js >> /var/log/bizon-news.log 2>&1

const { PrismaClient } = require('@prisma/client');

// === Проверка BIZON_ENCRYPTION_KEY (контракт приложения) ===
const ENC_KEY = process.env.BIZON_ENCRYPTION_KEY;
if (!ENC_KEY) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в окружении.');
  console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
  console.error('   Запуск: BIZON_ENCRYPTION_KEY=... node scripts/cron-fetch-news.js');
  process.exit(1);
}

const prisma = new PrismaClient();

// === Константы ===

const DAILY_LIMIT = 100; // максимум новых карточек в сутки
const FETCH_TIMEOUT_MS = 8000;
const USER_AGENT = 'Mozilla/5.0 (compatible; BizON-NewsBot/1.0; +https://bizon.ru/bot)';
const MAX_ITEMS_PER_FEED = 15; // берём максимум 15 свежих статей из каждой ленты

// RSS-источники (fallback-пул этапа 5.1 — vc.ru, habr.com, rb.ru).
// Приоритет — источники компаний/пользователей (Company.newsSources / User.newsSources),
// загружаемые из БД в loadCustomSources() ниже.
const RSS_FEEDS = [
  { url: 'https://vc.ru/rss/all', domain: 'vc.ru', category: 'industry' },
  { url: 'https://habr.com/ru/rss/hubs/all/', domain: 'habr.com', category: 'industry' },
  { url: 'https://rb.ru/rss/', domain: 'rb.ru', category: 'industry' },
];

// === Rate limit между фетчами источников ===
const FETCH_PAUSE_MS = 500; // пауза между источниками (не бьём по всем сразу)
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// === Custom sources: Company.newsSources + User.newsSources (doc_a §15) ===
// Формат — JSON-массив URL-строк (сохраняет /api/news/sources), до 5 URL на владельца.
const MAX_SOURCES_PER_OWNER = 5;

function parseNewsSources(raw) {
  if (!raw) return [];
  try {
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return [];
    return arr
      .filter((u) => typeof u === 'string' && u.trim().startsWith('http'))
      .map((u) => u.trim())
      .slice(0, MAX_SOURCES_PER_OWNER);
  } catch {
    return [];
  }
}

/**
 * Собирает источники из БД: сначала компании, затем пользователи.
 * Дедуп URL между владельцами (один и тот же RSS не фетчим дважды).
 * Ошибки БД не роняют крон — возвращаем то, что успели собрать (или []).
 */
async function loadCustomSources() {
  const sources = [];
  const seen = new Set();

  try {
    const companies = await prisma.company.findMany({
      where: { newsSources: { not: null } },
      select: { id: true, name: true, newsSources: true },
    });
    for (const c of companies) {
      for (const url of parseNewsSources(c.newsSources)) {
        if (seen.has(url)) continue;
        seen.add(url);
        sources.push({
          url,
          domain: extractDomain(url),
          category: 'industry',
          ownerType: 'company',
          ownerName: c.name,
        });
      }
    }
  } catch (e) {
    console.warn('[loadCustomSources] companies failed:', e?.message || e);
  }

  try {
    const users = await prisma.user.findMany({
      where: { newsSources: { not: null }, deletedAt: null },
      select: { id: true, name: true, newsSources: true },
    });
    for (const u of users) {
      for (const url of parseNewsSources(u.newsSources)) {
        if (seen.has(url)) continue;
        seen.add(url);
        sources.push({
          url,
          domain: extractDomain(url),
          category: 'industry',
          ownerType: 'user',
          ownerName: u.name,
        });
      }
    }
  } catch (e) {
    console.warn('[loadCustomSources] users failed:', e?.message || e);
  }

  // Без домена источник бесполезен (не заполнить sourceDomain)
  return sources.filter((s) => s.domain);
}

// === SSRF protection (inlined — т.к. скрипт не проходит через webpack) ===
const { lookup } = require('node:dns/promises');
const { isIP } = require('node:net');

const PRIVATE_IP_RANGES = [
  { start: '10.0.0.0', end: '10.255.255.255' },
  { start: '172.16.0.0', end: '172.31.255.255' },
  { start: '192.168.0.0', end: '192.168.255.255' },
  { start: '127.0.0.0', end: '127.255.255.255' },
  { start: '169.254.0.0', end: '169.254.255.255' },
  { start: '100.64.0.0', end: '100.127.255.255' },
  { start: '0.0.0.0', end: '0.255.255.255' },
  { start: '224.0.0.0', end: '239.255.255.255' },
  { start: '240.0.0.0', end: '255.255.255.255' },
];

function ipv4ToLong(ip) {
  const parts = ip.split('.');
  if (parts.length !== 4) return null;
  const nums = parts.map((p) => parseInt(p, 10));
  if (nums.some((n) => isNaN(n) || n < 0 || n > 255)) return null;
  return ((nums[0] << 24) >>> 0) + (nums[1] << 16) + (nums[2] << 8) + nums[3];
}

function isPrivateIPv4(ip) {
  const long = ipv4ToLong(ip);
  if (long === null) return false;
  for (const r of PRIVATE_IP_RANGES) {
    const s = ipv4ToLong(r.start);
    const e = ipv4ToLong(r.end);
    if (long >= s && long <= e) return true;
  }
  return false;
}

function isPrivateIPv6(ip) {
  const lower = ip.toLowerCase();
  if (lower === '::1') return true;
  if (lower.startsWith('fc') || lower.startsWith('fd')) return true;
  if (lower.startsWith('fe8') || lower.startsWith('fe9') || lower.startsWith('fea') || lower.startsWith('feb')) return true;
  if (lower === '::') return true;
  const v4Mapped = lower.match(/::ffff:(\d+\.\d+\.\d+\.\d+)/);
  if (v4Mapped) return isPrivateIPv4(v4Mapped[1]);
  return false;
}

function isPrivateIP(ip) {
  if (isIP(ip) === 4) return isPrivateIPv4(ip);
  if (isIP(ip) === 6) return isPrivateIPv6(ip);
  return true; // непонятный — блокируем
}

async function validateUrlSafety(rawUrl) {
  if (rawUrl.length > 2048) return { ok: false, reason: 'URL слишком длинный' };
  let parsed;
  try { parsed = new URL(rawUrl); } catch { return { ok: false, reason: 'невалидный URL' }; }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return { ok: false, reason: 'протокол не разрешён' };
  const port = parsed.port || (parsed.protocol === 'https:' ? '443' : '80');
  if (!['80', '443', '8080', '8443'].includes(port)) return { ok: false, reason: `порт ${port} не разрешён` };
  const hostname = parsed.hostname;
  if (isIP(hostname)) {
    if (isPrivateIP(hostname)) return { ok: false, reason: `IP ${hostname} приватный` };
    return { ok: true };
  }
  let resolvedIp;
  try {
    const result = await lookup(hostname, { all: true });
    if (result.length === 0) return { ok: false, reason: `DNS не дал результатов для ${hostname}` };
    const v4 = result.find((r) => r.family === 4);
    const v6 = result.find((r) => r.family === 6);
    resolvedIp = v4?.address || v6?.address || result[0].address;
  } catch (e) {
    return { ok: false, reason: `DNS resolve failed: ${e?.code || e?.message}` };
  }
  if (isPrivateIP(resolvedIp)) return { ok: false, reason: `${hostname} → приватный IP ${resolvedIp}` };
  return { ok: true };
}

async function safeFetch(url, opts = {}) {
  const { timeoutMs = FETCH_TIMEOUT_MS, userAgent = USER_AGENT } = opts;
  const safety = await validateUrlSafety(url);
  if (!safety.ok) {
    console.warn(`[safeFetch] blocked ${url}: ${safety.reason}`);
    return null;
  }
  try {
    return await fetch(url, {
      signal: AbortSignal.timeout(timeoutMs),
      headers: { 'User-Agent': userAgent },
      redirect: 'manual',
    });
  } catch (e) {
    console.warn(`[safeFetch] fetch failed for ${url}:`, e?.message || e);
    return null;
  }
}

// === RSS parser (минимальный — без зависимостей) ===
// Извлекает <item> / <entry> и их поля: title, link, pubDate, category.
// Поддерживает RSS 2.0 и Atom.

function decodeEntities(s) {
  return String(s || '')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)))
    .replace(/&amp;/g, '&');
}

function extractTag(xml, tag) {
  // Совпадает <tag>...</tag> или <tag attrs>...</tag>
  const re = new RegExp(`<${tag}(?:\\s[^>]*)?>([^<]*)</${tag}>`, 'i');
  const m = xml.match(re);
  return m ? decodeEntities(m[1].trim()) : '';
}

function parseRss(xml, sourceDomain) {
  const items = [];
  // RSS 2.0: <item>...</item>
  const itemMatches = xml.match(/<item[\s\S]*?<\/item>/gim) || [];
  for (const itemXml of itemMatches.slice(0, MAX_ITEMS_PER_FEED)) {
    const title = extractTag(itemXml, 'title');
    const link = extractTag(itemXml, 'link');
    const pubDateStr = extractTag(itemXml, 'pubDate');
    let pubDate;
    try { pubDate = pubDateStr ? new Date(pubDateStr) : new Date(); if (isNaN(pubDate.getTime())) pubDate = new Date(); } catch { pubDate = new Date(); }
    if (link && title) {
      items.push({ title, link, pubDate, sourceDomain });
    }
  }
  // Atom: <entry>...</entry>
  const entryMatches = xml.match(/<entry[\s\S]*?<\/entry>/gim) || [];
  for (const entryXml of entryMatches.slice(0, MAX_ITEMS_PER_FEED)) {
    const title = extractTag(entryXml, 'title');
    // <link href="..."/> или <link>...</link>
    let link = '';
    const linkHrefMatch = entryXml.match(/<link[^>]*\shref=["']([^"']+)["'][^>]*>/i);
    if (linkHrefMatch) link = decodeEntities(linkHrefMatch[1]);
    else link = extractTag(entryXml, 'link');
    const updatedStr = extractTag(entryXml, 'updated') || extractTag(entryXml, 'published');
    let pubDate;
    try { pubDate = updatedStr ? new Date(updatedStr) : new Date(); if (isNaN(pubDate.getTime())) pubDate = new Date(); } catch { pubDate = new Date(); }
    if (link && title) {
      items.push({ title, link, pubDate, sourceDomain });
    }
  }
  return items;
}

// === OG metadata extraction (для каждой статьи) ===

async function fetchOgMetadata(url) {
  const res = await safeFetch(url);
  if (!res || !res.ok) {
    // fallback: RSS-метаданные
    return { title: '', description: '', imageUrl: null };
  }
  // Не следуем редиректу — но если сервер вернул 3xx, попробуем Location
  if (res.status >= 300 && res.status < 400) {
    const loc = res.headers.get('location');
    if (loc) {
      try {
        const abs = new URL(loc, url).toString();
        // Рекурсивно, но только один раз (защита от циклов)
        const safety = await validateUrlSafety(abs);
        if (safety.ok) {
          return fetchOgMetadata(abs);
        }
      } catch {}
    }
    return { title: '', description: '', imageUrl: null };
  }
  // Ограничиваем размер — берём первые 64КБ
  const text = (await res.text()).slice(0, 65536);
  const titleMatch =
    text.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i) ||
    text.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']/i);
  const descMatch =
    text.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i) ||
    text.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:description["']/i) ||
    text.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i);
  const imageMatch =
    text.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
    text.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);
  const titleTag = text.match(/<title[^>]*>([^<]+)<\/title>/i);

  let title = titleMatch ? titleMatch[1] : (titleTag ? titleTag[1] : '');
  let description = descMatch ? descMatch[1] : '';
  let imageUrl = imageMatch ? imageMatch[1] : null;

  title = decodeEntities(title).trim().slice(0, 300);
  description = decodeEntities(description).trim().slice(0, 500);

  // Если og:image — относительный URL, делаем абсолютным
  if (imageUrl) {
    try {
      imageUrl = new URL(imageUrl, url).toString();
    } catch {
      imageUrl = null;
    }
  }

  return { title, description, imageUrl };
}

// === AI-резюме через z-ai-web-dev-sdk ===
// ВАЖНО: dynamic import — SDK может не быть установлен в окружении cron-скрипта
// (если запуск идёт без node_modules). При ошибке — fallback на title.

async function generateSummary(title, description) {
  try {
    const ZAI = (require('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();
    const response = await zai.chat.completions.create({
      messages: [
        {
          role: 'user',
          content: `Сделай краткое резюме этой статьи в 50-100 символов на русском: ${title} ${description || ''}`.slice(0, 1500),
        },
      ],
      thinking: { type: 'disabled' },
      temperature: 0.3,
      max_tokens: 120,
    });
    const content = (response.choices?.[0]?.message?.content || '').trim();
    if (!content) return (title || '').slice(0, 100);
    const truncated = content.slice(0, 100);
    const lastSpace = truncated.lastIndexOf(' ');
    let summary = lastSpace > 40 ? truncated.slice(0, lastSpace) : truncated;
    if (summary.length < 50) {
      summary = (summary + ' ' + (title || '')).slice(0, 100).trim();
    }
    return summary;
  } catch (e) {
    console.warn('[generateSummary] AI error:', e?.message || e);
    // Fallback: title + description, усечённое
    const fb = `${title || ''} ${description || ''}`.trim();
    return fb.slice(0, 100) || (title || 'Резюме недоступно').slice(0, 100);
  }
}

// === Извлечение домена из URL ===

function extractDomain(url) {
  try {
    const u = new URL(url);
    return u.hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

// === Основная логика ===

async function main() {
  console.log(`[${new Date().toISOString()}] BizON NB cron-fetch-news started`);
  let totalCreated = 0;
  let totalSkipped = 0;
  let totalErrors = 0;

  // 1. Проверяем дневной лимит: считаем сколько карточек создано сегодня
  const dayStart = new Date();
  dayStart.setHours(0, 0, 0, 0);
  const createdToday = await prisma.newsCard.count({
    where: { createdAt: { gte: dayStart } },
  });
  if (createdToday >= DAILY_LIMIT) {
    console.log(`Daily limit reached (${createdToday}/${DAILY_LIMIT}). Skipping.`);
    await prisma.$disconnect();
    return;
  }
  const remaining = DAILY_LIMIT - createdToday;
  console.log(`Daily limit: ${createdToday}/${DAILY_LIMIT} — can create up to ${remaining} more`);

  // 2. Источники: (а) newsSources компаний/пользователей (doc_a §15), (б) fallback-пул
  const customSources = await loadCustomSources();
  console.log(`Sources: ${customSources.length} custom (Company/User newsSources) + ${RSS_FEEDS.length} fallback`);
  const feeds = [...customSources, ...RSS_FEEDS];

  // 3. Собираем все элементы из всех RSS-лент (rate limit 500ms между фетчами,
  //    try/catch на каждый источник — один битый RSS не роняет крон)
  const allItems = [];
  for (let i = 0; i < feeds.length; i++) {
    const feed = feeds[i];
    if (i > 0) await sleep(FETCH_PAUSE_MS);
    try {
      const ownerLabel = feed.ownerType ? ` [${feed.ownerType}: ${feed.ownerName}]` : '';
      console.log(`Fetching RSS: ${feed.url}${ownerLabel}`);
      const res = await safeFetch(feed.url, { timeoutMs: 10000 });
      if (!res || !res.ok) {
        console.warn(`RSS fetch failed: ${feed.url} (status=${res?.status ?? 'null'})`);
        totalErrors++;
        continue;
      }
      const xml = await res.text();
      const items = parseRss(xml, feed.domain);
      console.log(`  parsed ${items.length} items from ${feed.domain}`);
      // Категория каждой карточки — feed.category
      for (const item of items) {
        item.category = feed.category;
      }
      allItems.push(...items);
    } catch (e) {
      console.warn(`RSS parse error (${feed.url}):`, e?.message || e);
      totalErrors++;
    }
  }

  // Сортируем по свежести (новые первыми)
  allItems.sort((a, b) => b.pubDate - a.pubDate);

  // 4. Для каждого элемента: проверяем дедупликацию, fetch OG, AI-резюме, сохраняем
  for (const item of allItems) {
    if (totalCreated >= remaining) {
      console.log(`Reached daily limit (${DAILY_LIMIT}). Stopping.`);
      break;
    }

    // Дедупликация по URL (findFirst перед create — NewsCard.url @unique)
    const existing = await prisma.newsCard.findFirst({ where: { url: item.link } });
    if (existing) {
      totalSkipped++;
      continue;
    }

    try {
      // Fetch OG metadata
      const og = await fetchOgMetadata(item.link);
      const title = (og.title || item.title || '').slice(0, 300);
      if (!title) {
        console.warn(`Skip (no title): ${item.link}`);
        totalSkipped++;
        continue;
      }
      const description = og.description || null;
      const imageUrl = og.imageUrl || null;
      const sourceDomain = item.sourceDomain || extractDomain(item.link);

      // AI-резюме
      const aiSummary = await generateSummary(title, description);

      // Теги — пустой массив по умолчанию (можно расширить парсингом RSS <category>)
      const tags = JSON.stringify([]);

      await prisma.newsCard.create({
        data: {
          url: item.link,
          title,
          description,
          imageUrl,
          aiSummary,
          tags,
          sourceDomain,
          publishedAt: item.pubDate,
          category: item.category || 'news',
          status: 'pending', // ждёт модератора
        },
      });
      totalCreated++;
      console.log(`  + created: ${title.slice(0, 60)}... (${sourceDomain})`);
    } catch (e) {
      console.warn(`Failed to process ${item.link}:`, e?.message || e);
      totalErrors++;
    }
  }

  console.log(`[${new Date().toISOString()}] Done. Created: ${totalCreated}, Skipped (dup/no-data): ${totalSkipped}, Errors: ${totalErrors}`);
  await prisma.$disconnect();
}

main().catch((e) => {
  console.error('FATAL:', e);
  prisma.$disconnect().finally(() => process.exit(1));
});
