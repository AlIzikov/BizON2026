// A9 (Task 2-e) — ONE-OFF: curl-матрица кворум-завершения проекта + cleanup.
// Создаёт 3 тестовых пользователя (founder A, member B, outsider C) с сессиями,
// прогоняет матрицу переходов/подтверждений через живой dev-сервер (:3000),
// проверяет DB-эффекты и УДАЛЯЕТ все тестовые записи (каскад).
//
// Запуск: bun scripts/a9-confirm-test.ts
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();
const BASE = 'http://localhost:3000';
const HASH_PREFIX = 'a9test-';

let failures = 0;
function check(name: string, cond: boolean, detail?: unknown) {
  const mark = cond ? 'PASS' : 'FAIL';
  console.log(`[${mark}] ${name}${cond ? '' : ` :: ${JSON.stringify(detail)?.slice(0, 400)}`}`);
  if (!cond) failures++;
}

type Ctx = { cookie: string };
async function call(
  ctx: Ctx,
  method: string,
  path: string,
  body?: unknown
): Promise<{ status: number; json: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      'content-type': 'application/json',
      cookie: ctx.cookie,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json: any = null;
  try {
    json = await res.json();
  } catch {
    json = null;
  }
  return { status: res.status, json };
}

async function main() {
  // ---------- 0. Setup: тестовые пользователи + сессии ----------
  const runId = Date.now().toString(36);
  const mk = (tag: string) => ({
    emailHash: `${HASH_PREFIX}${runId}-${tag}`,
    name: `A9 Test ${tag.toUpperCase()}`,
    passwordHash: 'a9-test-not-used-for-login',
  });
  const [userA, userB, userC] = await Promise.all([
    db.user.create({ data: mk('founder') }),
    db.user.create({ data: mk('member') }),
    db.user.create({ data: mk('outsider') }),
  ]);
  const mkSession = (userId: string, tag: string) =>
    db.session.create({
      data: { userId, token: `${HASH_PREFIX}${runId}-${tag}-session`, expiresAt: new Date(Date.now() + 86400_000) },
    });
  await Promise.all([mkSession(userA.id, 'a'), mkSession(userB.id, 'b'), mkSession(userC.id, 'c')]);
  const A: Ctx = { cookie: `bizon_session=${HASH_PREFIX}${runId}-a-session` };
  const B: Ctx = { cookie: `bizon_session=${HASH_PREFIX}${runId}-b-session` };
  const C: Ctx = { cookie: `bizon_session=${HASH_PREFIX}${runId}-c-session` };
  console.log(`[setup] users A/B/C created (${runId})`);

  const testProjectIds: string[] = [];

  try {
    // ---------- 1. Проект с 2 участниками ----------
    const created = await call(A, 'POST', '/api/projects', {
      title: `A9 Кворум-тест ${runId}`,
      description: 'Тестовый проект для проверки кворум-завершения (A9).',
      tags: ['a9test'],
    });
    check('POST /api/projects (A) → 201', created.status === 201, created);
    const projectId = created.json?.project?.id as string;
    testProjectIds.push(projectId);
    check('project id получен', !!projectId, created.json);

    const join = await call(B, 'PATCH', `/api/projects/${projectId}`, { action: 'join' });
    check('PATCH join (B) → 200', join.status === 200, join);

    // ---------- 2. Активация: PROPOSAL(recruiting) → ACTIVE ----------
    const forbidden = await call(B, 'POST', `/api/projects/${projectId}/transition`, { status: 'ACTIVE' });
    check('transition (B, не founder) → 403', forbidden.status === 403, forbidden);

    const activate = await call(A, 'POST', `/api/projects/${projectId}/transition`, { status: 'ACTIVE' });
    check('transition active (A) → 200', activate.status === 200, activate);

    // Толерантность к нижнему регистру ('active' → ACTIVE)
    const activateLower = await call(A, 'POST', `/api/projects/${projectId}/transition`, { status: 'on_hold' });
    check('transition принимает нижний регистр (on_hold → ON_HOLD)', activateLower.status === 200, activateLower);
    await call(A, 'POST', `/api/projects/${projectId}/transition`, { status: 'ACTIVE' }); // вернём в ACTIVE

    // ---------- 3. Confirm до волны → 422 ----------
    const earlyConfirm = await call(A, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('confirm до волны (A) → 422', earlyConfirm.status === 422, earlyConfirm);
    check('текст «нет открытой волны»', /волны подтверждения не открыта|не запрошено/.test(earlyConfirm.json?.error ?? ''), earlyConfirm.json);

    // GET /confirm до волны: member видит состояние, волна не открыта
    const earlyGet = await call(B, 'GET', `/api/projects/${projectId}/confirm`);
    check('GET confirm (B) до волны → 200', earlyGet.status === 200, earlyGet);
    check('GET confirm: waveOpen=false, total=2', earlyGet.json?.waveOpen === false && earlyGet.json?.total === 2, earlyGet.json);

    // ---------- 4. Волна: transition completed → 202 ----------
    const wave = await call(A, 'POST', `/api/projects/${projectId}/transition`, {
      status: 'COMPLETED',
      rating: 5,
      outcome: 'Доставили MVP в срок',
    });
    check('transition completed (A) → 202', wave.status === 202, wave);
    check('202: pendingConfirmation=true', wave.json?.pendingConfirmation === true, wave.json);
    check('202: confirmed=0, pending=2, total=2', wave.json?.confirmed === 0 && wave.json?.pending === 2 && wave.json?.total === 2, wave.json);
    check('202: сообщение «подтверждено 0 из 2»', wave.json?.message === 'Завершение требует подтверждения всех участников: подтверждено 0 из 2', wave.json);
    check('202: статус проекта НЕ изменился', wave.json?.projectStatus === 'ACTIVE', wave.json);

    const waveCount = await db.projectConfirmation.count({ where: { projectId } });
    check('ProjectConfirmation создано 2 записи', waveCount === 2, { waveCount });

    // ---------- 5. Повторный transition completed → 409 со счётчиками ----------
    const repeat = await call(A, 'POST', `/api/projects/${projectId}/transition`, { status: 'COMPLETED' });
    check('повторный transition completed → 409', repeat.status === 409, repeat);
    check('409: confirmed=0/pending=2/total=2', repeat.json?.confirmed === 0 && repeat.json?.pending === 2 && repeat.json?.total === 2, repeat.json);
    check('409: сообщение с счётчиками', typeof repeat.json?.message === 'string' && repeat.json.message.includes('0 из 2'), repeat.json);

    const waveCountAfterRepeat = await db.projectConfirmation.count({ where: { projectId } });
    check('повтор не дублирует записи', waveCountAfterRepeat === 2, { waveCountAfterRepeat });

    // ---------- 6. GET /confirm ----------
    const getA = await call(A, 'GET', `/api/projects/${projectId}/confirm`);
    check('GET confirm (A) → 200 waveOpen=true myPending=true', getA.status === 200 && getA.json?.waveOpen === true && getA.json?.myPending === true, getA.json);

    const getC = await call(C, 'GET', `/api/projects/${projectId}/confirm`);
    check('GET confirm (C, чужой) → 403', getC.status === 403, getC);

    // ---------- 7. Confirm чужим → 403 ----------
    const confirmC = await call(C, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('confirm (C, не участник) → 403', confirmC.status === 403, confirmC);

    // ---------- 8. Первый confirm (B) → 200, не завершён ----------
    const confirmB = await call(B, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('confirm (B) → 200', confirmB.status === 200, confirmB);
    check('confirm (B): completed=false, confirmed=1/total=2', confirmB.json?.completed === false && confirmB.json?.confirmed === 1 && confirmB.json?.total === 2, confirmB.json);

    const stillActive = await db.project.findUnique({ where: { id: projectId }, select: { status: true } });
    check('после 1-го confirm проект ещё ACTIVE', stillActive?.status === 'ACTIVE', stillActive);

    // ---------- 9. Повторный confirm (B) → 409 ----------
    const confirmB2 = await call(B, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('повторный confirm (B) → 409', confirmB2.status === 409, confirmB2);
    check('текст «уже подтвердили»', /уже подтвердили/.test(confirmB2.json?.error ?? ''), confirmB2.json);

    // ---------- 10. Финальный confirm (A) → кворум, completed ----------
    const confirmA = await call(A, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('confirm (A) → 200 completed=true', confirmA.status === 200 && confirmA.json?.completed === true, confirmA);
    check('confirm (A): confirmed=2/2, pending=0', confirmA.json?.confirmed === 2 && confirmA.json?.pending === 0, confirmA.json);

    const finished = await db.project.findUnique({ where: { id: projectId } });
    check('проект status=completed', finished?.status === 'completed', finished?.status);
    check('completedAt проставлен', !!finished?.completedAt, finished?.completedAt);
    check('рейтинг основателя сохранён (5)', finished?.rating === 5, finished?.rating);
    check('outcome сохранён', finished?.outcome === 'Доставили MVP в срок', finished?.outcome);

    // ---------- 11. DB-эффекты: репутация/уведомления/аудит ----------
    const repEvents = await db.reputationEvent.findMany({
      where: { eventType: 'project_completed', payload: { contains: projectId } },
    });
    check('ReputationEvent ×2 (project_completed, viaQuorum)', repEvents.length === 2 && repEvents.every((e) => e.weight === 5 && e.payload.includes('viaQuorum')), repEvents.length);

    const [aAfter, bAfter] = await Promise.all([
      db.user.findUnique({ where: { id: userA.id }, select: { ipScore: true, level: true } }),
      db.user.findUnique({ where: { id: userB.id }, select: { ipScore: true, level: true } }),
    ]);
    check('IP-score участников пересчитан (>0)', (aAfter?.ipScore ?? 0) > 0 && (bAfter?.ipScore ?? 0) > 0, { a: aAfter, b: bAfter });

    const notifs = await db.notification.findMany({ where: { userId: { in: [userA.id, userB.id] }, type: 'project_completed' } });
    check('Notification ×2 «Проект … завершён»', notifs.length === 2 && notifs.every((n) => n.title.includes('завершён')), notifs.map((n) => n.title));

    const audits = await db.auditLog.findMany({ where: { resourceId: projectId }, select: { action: true } });
    const actions = audits.map((a) => a.action).sort();
    check('AuditLog: requested/transition/confirmed', JSON.stringify(actions) === JSON.stringify(['project_completion_requested', 'project_completed_confirmed', 'project_transition']), actions);

    const confirms = await db.projectConfirmation.findMany({ where: { projectId } });
    // 29-g: confirmedAt не существует в схеме — «подтвердил» = decidedAt (decidedBy)
    check('ProjectConfirmation: обе с decidedAt', confirms.length === 2 && confirms.every((c) => !!c.decidedAt), confirms.length);

    const getAfter = await call(A, 'GET', `/api/projects/${projectId}/confirm`);
    check('GET confirm после завершения: waveOpen=false', getAfter.json?.waveOpen === false && getAfter.json?.confirmed === 2, getAfter.json);

    // ---------- 12. Соло-кворум: ACTIVE-проект с 1 активным → мгновенное завершение ----------
    const solo = await call(A, 'POST', '/api/projects', {
      title: `A9 Соло-кворум ${runId}`,
      description: 'Соло-проект: кворум 1 — завершается сразу.',
    });
    const soloId = solo.json?.project?.id as string;
    testProjectIds.push(soloId);
    await call(B, 'PATCH', `/api/projects/${soloId}`, { action: 'join' });
    await call(A, 'POST', `/api/projects/${soloId}/transition`, { status: 'ACTIVE' });
    // B выходит (graceful) → остаётся 1 активный участник.
    // NB: POST /api/projects/[id]/leave у таких участников падает 400
    // «уже покинули с состоянием active» (pre-existing баг: exitState по умолчанию
    // 'active' трактуется как «уже вышел») — поэтому эмулируем выход напрямую в БД.
    const soloMemberB = await db.projectMember.findFirst({ where: { projectId: soloId, userId: userB.id } });
    await db.projectMember.update({ where: { id: soloMemberB!.id }, data: { exitState: 'graceful', exitedAt: new Date() } });
    const soloComplete = await call(A, 'POST', `/api/projects/${soloId}/transition`, { status: 'COMPLETED', rating: 4 });
    check('соло ACTIVE → completed сразу (200, без волны)', soloComplete.status === 200 && !soloComplete.json?.pendingConfirmation, soloComplete);
    const soloRow = await db.project.findUnique({ where: { id: soloId }, select: { status: true } });
    check('соло-проект завершён', soloRow?.status === 'completed', soloRow);
    const soloConfirms = await db.projectConfirmation.count({ where: { projectId: soloId } });
    check('соло-кворум не создаёт записей волны', soloConfirms === 0, { soloConfirms });

    // ---------- 13. Совместимость: recruiting-проект → transition 422, PATCH complete работает ----------
    const fresh = await call(A, 'POST', '/api/projects', {
      title: `A9 Совместимость ${runId}`,
      description: 'Рекрутинг-проект: прежний прямой путь завершения.',
    });
    const freshId = fresh.json?.project?.id as string;
    testProjectIds.push(freshId);
    const freshTransition = await call(A, 'POST', `/api/projects/${freshId}/transition`, { status: 'COMPLETED' });
    check('recruiting → transition completed → 422 (state machine)', freshTransition.status === 422, freshTransition);
    const freshPatch = await call(A, 'PATCH', `/api/projects/${freshId}`, { action: 'complete', rating: 5 });
    check('PATCH complete (прежний путь) → 200', freshPatch.status === 200, freshPatch.status);
    const freshRow = await db.project.findUnique({ where: { id: freshId }, select: { status: true } });
    check('recruiting-проект завершён прежним путём', freshRow?.status === 'completed', freshRow);
  } finally {
    // ---------- 14. Cleanup: тестовые записи проекта/уведомлений/reputation ----------
    const pre = {
      projects: await db.project.count({ where: { id: { in: testProjectIds } } }),
      confirms: await db.projectConfirmation.count({ where: { projectId: { in: testProjectIds } } }),
      notifs: await db.notification.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
      rep: await db.reputationEvent.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
      actions: await db.actionEvent.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
    };
    const auditDel = await db.auditLog.deleteMany({ where: { resourceId: { in: testProjectIds } } });
    await db.user.deleteMany({ where: { emailHash: { startsWith: HASH_PREFIX } } }); // каскад: sessions/projects/members/confirmations/notifications/reputation/actionEvents
    const post = {
      projects: await db.project.count({ where: { id: { in: testProjectIds } } }),
      confirms: await db.projectConfirmation.count({ where: { projectId: { in: testProjectIds } } }),
      notifs: await db.notification.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
      rep: await db.reputationEvent.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
      users: await db.user.count({ where: { emailHash: { startsWith: HASH_PREFIX } } }),
      sessions: await db.session.count({ where: { token: { startsWith: HASH_PREFIX } } }),
    };
    console.log(`[cleanup] pre: ${JSON.stringify(pre)}; auditLogs removed: ${auditDel.count}`);
    console.log(`[cleanup] post: ${JSON.stringify(post)}`);
    check('cleanup: проекты удалены', post.projects === 0, post);
    check('cleanup: волны подтверждений удалены', post.confirms === 0, post);
    check('cleanup: уведомления удалены', post.notifs === 0, post);
    check('cleanup: reputation-события удалены', post.rep === 0, post);
    check('cleanup: пользователи/сессии удалены', post.users === 0 && post.sessions === 0, post);
  }

  console.log(failures === 0 ? '\n=== ALL CHECKS PASSED ===' : `\n=== ${failures} CHECK(S) FAILED ===`);
  if (failures > 0) process.exit(1);
}

main()
  .catch((e) => {
    console.error('[a9-confirm-test] failed:', e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
