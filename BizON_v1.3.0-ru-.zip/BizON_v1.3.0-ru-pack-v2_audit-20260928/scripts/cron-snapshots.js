// BizON — Cron: ежедневные снапшоты репутации (ReputationSnapshot)
// GPT Truth Engine (B1): снимает IP-score для каждого пользователя раз в сутки,
// чтобы строить график динамики (Reputation Timeline) и хранить историю breakdown.
//
// Запуск:
//   BIZON_ENCRYPTION_KEY=... node scripts/cron-snapshots.js
//
// Рекомендуется ежедневный запуск через cron или pm2:
//   crontab -e:
//     0 3 * * *  cd /home/z/my-project && BIZON_ENCRYPTION_KEY=... /usr/bin/node scripts/cron-snapshots.js >> /var/log/bizon-cron.log 2>&1
//
//   pm2 ecosystem.config.cjs:
//     {
//       name: 'bizon-cron-snapshots',
//       script: 'scripts/cron-snapshots.js',
//       cron_restart: '0 3 * * *',
//       autorestart: false,
//       env: { BIZON_ENCRYPTION_KEY: '...' },
//     }
//
// Логика:
//   Для каждого пользователя:
//     1. Считает IP-score breakdown (A*0.4 + B*0.3 + C*0.2 + D*0.1)
//        - A: completed / max(3, total) проектов
//        - B: avg rating completed / 5
//        - C: log1p(confirmations) / log1p(20)
//        - D: min(events_7d / 7, 1)
//     2. Считает evidenceCoverage = verifiedClaims / totalClaims (0..1)
//     3. Обновляет user.ipScore + user.level
//     4. Создаёт ReputationSnapshot со всеми значениями
//
// Идемпотентность: при повторном запуске в тот же день создаётся ещё один snapshot
// (на графике это просто дополнительная точка). При желании можно включить
// дедупликацию по дате через флаг --dedupe.

const { PrismaClient } = require('@prisma/client');

// === Проверка BIZON_ENCRYPTION_KEY ===
// Скрипт не использует шифрование напрямую, но мы требуем ключ для соответствия
// контракту приложения (instrumentation.ts проверяет его при старте сервера).
const ENC_KEY = process.env.BIZON_ENCRYPTION_KEY;
if (!ENC_KEY) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в окружении.');
  console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
  console.error('   Запуск: BIZON_ENCRYPTION_KEY=... node scripts/cron-snapshots.js');
  process.exit(1);
}

const prisma = new PrismaClient();

// Пороги уровней доверия (ТЗ 2.3.2):
// 0–30 → basic, 31–70 → extended, 71–100 → expert
function levelFromScore(score) {
  if (score >= 71) return 'expert';
  if (score >= 31) return 'extended';
  return 'basic';
}

/**
 * Рассчитать IP-score breakdown для пользователя.
 * Возвращает { ipScore, level, projectsScore, ratingsScore, skillsScore, activityScore, components }
 */
function computeBreakdown({ projects, ratings, skills, activity }) {
  const totalProjects = projects.length;
  const completedProjects = projects.filter((p) => p.project.status === 'completed').length;
  const A = totalProjects === 0 ? 0 : completedProjects / Math.max(3, totalProjects);

  const ratingValues = ratings
    .map((r) => r.project.rating)
    .filter((r) => typeof r === 'number' && r > 0);
  const avgRating =
    ratingValues.length === 0
      ? 0
      : ratingValues.reduce((a, b) => a + b, 0) / ratingValues.length;
  const B = avgRating / 5;

  const totalConfirmations = skills.reduce((sum, s) => sum + (s.confirmationsCount || 0), 0);
  const C = Math.log1p(totalConfirmations) / Math.log1p(20);

  const D = Math.min(activity / 7, 1);

  const ipScore = Math.max(0, Math.min(100, Math.round((A * 0.4 + B * 0.3 + C * 0.2 + D * 0.1) * 100)));
  const level = levelFromScore(ipScore);

  return {
    ipScore,
    level,
    // В схеме ReputationSnapshot эти поля хранятся как Int 0..100
    projectsScore: Math.round(A * 100),
    ratingsScore: Math.round(B * 100),
    skillsScore: Math.round(C * 100),
    activityScore: Math.round(D * 100),
    // Сырые компоненты 0..1 — для отладки/логов
    components: { A, B, C, D, totalProjects, completedProjects, totalConfirmations, activity },
  };
}

/**
 * Считает evidenceCoverage = verifiedClaims / totalClaims (0..1).
 * verified = claims со статусом выше "claimed".
 */
async function computeEvidenceCoverage(userId) {
  const claims = await prisma.claim.findMany({
    where: { userId },
    select: { status: true },
  });
  const total = claims.length;
  if (total === 0) return 0;
  const verified = claims.filter((c) => c.status !== 'claimed').length;
  return Number((verified / total).toFixed(3));
}

/**
 * Проверить, есть ли уже snapshot за сегодня (UTC) для пользователя.
 * Используется только при --dedupe.
 */
async function hasTodaySnapshot(userId) {
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);
  const existing = await prisma.reputationSnapshot.findFirst({
    where: { userId, createdAt: { gte: startOfDay } },
    select: { id: true },
  });
  return existing !== null;
}

async function snapshotUser(user, opts) {
  const { dedupe } = opts;

  // 1. Загружаем всё необходимое одним батчем
  const [projects, ratings, skills, activity] = await Promise.all([
    prisma.projectMember.findMany({
      where: { userId: user.id },
      include: { project: { select: { status: true, rating: true } } },
    }),
    prisma.projectMember.findMany({
      where: { userId: user.id, project: { status: 'completed' } },
      select: { project: { select: { rating: true } } },
    }),
    prisma.userSkill.findMany({
      where: { userId: user.id },
      select: { confirmationsCount: true },
    }),
    prisma.reputationEvent.count({
      where: {
        userId: user.id,
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
    }),
  ]);

  // 2. Считаем breakdown + IP-score
  const breakdown = computeBreakdown({ projects, ratings, skills, activity });

  // 3. Считаем evidenceCoverage
  const evidenceCoverage = await computeEvidenceCoverage(user.id);

  // 4. Дедупликация (опционально)
  if (dedupe) {
    const already = await hasTodaySnapshot(user.id);
    if (already) {
      return { skipped: true, user, breakdown, evidenceCoverage };
    }
  }

  // 5. Обновляем user.ipScore + level (чтобы топбар и другие UI показывали актуальное значение)
  await prisma.user.update({
    where: { id: user.id },
    data: { ipScore: breakdown.ipScore, level: breakdown.level },
  });

  // 6. Создаём ReputationSnapshot
  const snapshot = await prisma.reputationSnapshot.create({
    data: {
      userId: user.id,
      ipScore: breakdown.ipScore,
      level: breakdown.level,
      projectsScore: breakdown.projectsScore,
      ratingsScore: breakdown.ratingsScore,
      skillsScore: breakdown.skillsScore,
      activityScore: breakdown.activityScore,
      evidenceCoverage,
    },
  });

  return { skipped: false, user, breakdown, evidenceCoverage, snapshot };
}

async function main() {
  const args = process.argv.slice(2);
  const dedupe = args.includes('--dedupe');

  console.log('=== BizON — Cron: Reputation Snapshots ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log(`BIZON_ENCRYPTION_KEY: задан (${ENC_KEY.length} символов)`);
  console.log(`Dedupe (1 snapshot/user/day): ${dedupe ? 'ON' : 'OFF'}`);
  console.log('');

  // Берём всех пользователей (для продакшена — батчинг через курсор при большом объёме)
  const users = await prisma.user.findMany({
    select: { id: true, name: true, email: true, ipScore: true, level: true },
    orderBy: { createdAt: 'asc' },
  });

  if (users.length === 0) {
    console.log('Пользователей не найдено. Выход.');
    return;
  }

  console.log(`Найдено пользователей: ${users.length}\n`);

  let created = 0;
  let skipped = 0;
  let failed = 0;

  for (let i = 0; i < users.length; i++) {
    const user = users[i];
    try {
      const result = await snapshotUser(user, { dedupe });
      if (result.skipped) {
        skipped++;
        console.log(
          `[${i + 1}/${users.length}] ⏭️  ${user.name} — пропущен (snapshot за сегодня уже есть)`,
        );
      } else {
        created++;
        const b = result.breakdown;
        console.log(
          `[${i + 1}/${users.length}] ✅ ${user.name} — ipScore=${b.ipScore} (${b.level}), ` +
            `A=${b.components.A.toFixed(2)} B=${b.components.B.toFixed(2)} ` +
            `C=${b.components.C.toFixed(2)} D=${b.components.D.toFixed(2)}, ` +
            `coverage=${(result.evidenceCoverage * 100).toFixed(0)}%`,
        );
      }
    } catch (e) {
      failed++;
      console.error(`[${i + 1}/${users.length}] ❌ ${user.name} — ошибка: ${e.message}`);
    }
  }

  console.log('\n=== Итог ===');
  console.log(`  Создано snapshot: ${created}`);
  console.log(`  Пропущено (дедупликация): ${skipped}`);
  console.log(`  Ошибок: ${failed}`);
  console.log(`  Всего пользователей: ${users.length}`);
  console.log('\n✅ Cron-snapshots complete.');
}

main()
  .catch((e) => {
    console.error('❌ Cron-snapshots failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
