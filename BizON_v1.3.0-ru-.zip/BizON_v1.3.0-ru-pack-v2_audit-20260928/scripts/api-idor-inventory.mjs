#!/usr/bin/env node
// BizON — API-014 (аудит 22-09-26): инвентарь IDOR-поверхности динамических роутов.
//
// Для каждого route.ts с динамическим сегментом ([id], [applicationId], …)
// скрипт классифицирует по исходнику:
//   auth      — есть ли авторизация (withRoute auth / getUserFromRequest / requireUser);
//   ownerGate — есть ли сверка владения ресурса (ownerId/userId/fromUserId/
//               employerId/decidedBy/authorId === user.id и т.п. либо
//               DB-conditional updateMany/update where) или ServiceError/BizonError
//               из доменного сервиса;
//   verdict   — OK (гейт найден) / MANUAL (гейт не опознан — ручное ревью) / OPEN (нет auth).
//
// Эвристический инвентарь (по исходнику, не AST): цель — НАПРАВЛЯТЬ ревью и
// red-team (adversarial), а не заменять их. Exit-код всегда 0 (инвентарь);
// жёсткий гейт — на OPEN-список при --strict.
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const API_DIR = 'src/app/api';
const METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];

function walk(dir, out = []) {
  for (const name of readdirSync(dir).sort()) {
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, out);
    else if (name === 'route.ts') out.push(p);
  }
  return out;
}

// Маркеры owner-гейта (честная эвристика: сверка id-полей с user.id или
// условная мутация по владельцу, или делегирование сервису с ServiceError)
const OWNER_PATTERNS = [
  /ownerId\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /(user|ctx\.user|viewer|me)\.id\s*!==?\s*\w*\.?ownerId/,
  /userId\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /(user|ctx\.user|viewer|me)\.id\s*!==?\s*\w*\.?userId/,
  /authorId\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /fromUserId\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /employerId\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /buyerId\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /sellerId\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /decidedBy\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /requesterId\s*[:=!]==?\s*(user|ctx\.user|viewer|me)\b/,
  /(user|ctx\.user|viewer|me)\.id\s*!==?\s*\w+\.id\b/,
  /updateMany\(\s*\{[^}]*where:\s*\{[^}]*ownerId/,
  /updateMany\(\s*\{[^}]*where:\s*\{[^}]*userId/,
  /ServiceError\(/,
  /BizonError\(/,
  /canViewProfileSync|isOwner|requireAdmin|adminGuard|opsGuard/,
];

const rows = [];
for (const f of walk(API_DIR)) {
  const rel = relative(API_DIR, f).split(join('-')).join('/');
  const dynamic = /\[([a-zA-Z0-9_]+)\]/.test(rel);
  if (!dynamic) continue;
  const src = readFileSync(f, 'utf8');

  const hasAuth =
    /withRoute\s*[<(]/.test(src) ||
    /getUserFromRequest|requireUser/.test(src);
  const ownerGate = OWNER_PATTERNS.some((re) => re.test(src));

  const verdict = !hasAuth ? 'OPEN' : ownerGate ? 'OK' : 'MANUAL';
  rows.push({ route: rel, verdict, hasAuth, ownerGate });
}

const counts = { OK: 0, MANUAL: 0, OPEN: 0 };
for (const r of rows) counts[r.verdict] += 1;

console.log(`API-014 IDOR-инвентарь: ${rows.length} динамических route.ts`);
console.log(`  OK (auth + owner-гейт распознан): ${counts.OK}`);
console.log(`  MANUAL (auth есть, гейт не опознан — ручное ревью/red-team): ${counts.MANUAL}`);
console.log(`  OPEN (нет auth — проверить публичность): ${counts.OPEN}\n`);

const manual = rows.filter((r) => r.verdict !== 'OK');
if (manual.length > 0) {
  console.log('Требуют внимания:');
  for (const r of manual) {
    console.log(`  [${r.verdict}] ${r.route}`);
  }
}

if (process.argv.includes('--strict') && counts.OPEN > 0) {
  console.error(`::error::API-014: ${counts.OPEN} динамических роутов без авторизации`);
  process.exit(1);
}
