#!/usr/bin/env node
// Оракул-верификатор ledger-а specs/fix-campaign-17-09/GATES.md.
// Правило unlazy (references/gates.md): все ассерты внутри, success-only маркер
// печатается ТОЛЬКО после того, как каждый ассерт прошёл; иначе exit 1.
import { readFileSync, existsSync } from "node:fs";
import { execSync } from "node:child_process";

const root = process.cwd();
const read = (p) => readFileSync(`${root}/${p}`, "utf8");
const assert = (cond, msg) => {
  if (!cond) {
    console.error(`FAIL: ${msg}`);
    process.exit(1);
  }
};
const noMatch = (cmd) => {
  // Возвращает true, если rg не находит совпадений (или файловый grep пуст)
  try {
    const out = execSync(cmd, { encoding: "utf8", stdio: ["pipe", "pipe", "pipe"] });
    return out.trim().length === 0;
  } catch {
    return true;
  }
};

const cmd = process.argv[2];

if (cmd === "rating") {
  // Схема: поля удалены
  const schema = read("prisma/schema.prisma");
  assert(!/model Project \{[\s\S]*?^\s*rating\s+Float/m.test(schema), "Project.rating всё ещё в схеме");
  assert(!/mentorRating\s+Int\?/.test(schema), "Mentorship.mentorRating всё ещё в схеме");
  // Код: нет обращений к полю rating проектов/менторства (отзывы о компаниях — легитимны)
  assert(
    noMatch(`rg -n "project\\.rating|m\\.project\\.rating|p\\.rating\\.toFixed|updated\\.rating|mentorRating" src --iglob "*.ts" --iglob "*.tsx" | rg -v "review|Review|signal|Signal|CompanyReview|CulturalSignal"`),
    "остались обращения к project.rating/mentorRating в коде",
  );
  // UI: звёзды рейтинга проектов удалены
  assert(
    noMatch(`rg -n "fill-yellow-400.*rating|rating\\\\.toFixed\\\\(1\\\\)" src --iglob "*.tsx" | rg -v "Review|review|signal|Signal|company\\.rating|company\\.avg|item\\.rating|positive_review"`),
    "остался UI-рендер звёздного рейтинга",
  );
  console.log("RATING_REMOVED_GATE_OK");
} else if (cmd === "ipscore") {
  const h = read("src/lib/api-helpers.ts");
  const liteIface = h.slice(
    h.indexOf("export interface UserPublicLite"),
    h.indexOf("export async function toUserPublicLite"),
  );
  assert(!/ipScore:/.test(liteIface), "UserPublicLite всё ещё содержит ipScore");
  const liteFn = h.slice(
    h.indexOf("export async function toUserPublicLite"),
    h.indexOf("// FIX-07: route composer"),
  );
  assert(!/ipScore: user\.ipScore/.test(liteFn), "toUserPublicLite всё ещё отдаёт ipScore");
  const search = read("src/app/api/search/route.ts");
  assert(!/orderBy: \{ ipScore: 'desc' \}/.test(search), "поиск всё ещё сортирует по ipScore (утечка)");
  const pv = read("src/components/profile/profile-view.tsx");
  assert(/showScore=\{isOwn\}/.test(pv), "профиль всё ещё показывает точный ipScore чужого профиля");
  console.log("IPSCORE_HIDDEN_GATE_OK");
} else if (cmd === "chains") {
  const route = read("src/app/api/users/[id]/route.ts");
  assert(/getUserChains/.test(route), "chains не подключён в API профиля");
  assert(/chains,/.test(route), "chains не в ответе API профиля");
  const pv = read("src/components/profile/profile-view.tsx");
  assert(/Цепочки результатов/.test(pv), "в profile-view нет секции цепочек");
  assert(/data\.chains && data\.chains\.length > 0/.test(pv), "секция цепочек не рендерится по условию");
  console.log("CHAINS_WIRED_GATE_OK");
} else if (cmd === "demotoken") {
  const m = read("src/middleware.ts");
  assert(!/const DEMO_TOKEN = '[0-9a-f]{64}'/.test(m), "DEMO_TOKEN всё ещё захардкожен");
  assert(/BIZON_DEMO_TOKEN/.test(m), "DEMO_TOKEN не читается из env");
  assert(/DEMO_TOKEN\.length > 0/.test(m), "demo-режим не fail-closed без токена");
  console.log("DEMO_TOKEN_GATED_GATE_OK");
} else if (cmd === "sanitizer") {
  const n = read("src/lib/services/news-relevance-service.ts");
  assert(/sanitizeExternalText\(news\.title/.test(n), "title новости не санитайзится");
  assert(/sanitizeExternalText\(news\.description/.test(n), "description новости не санитайзится");
  assert(/sanitizeExternalText\(news\.aiSummary/.test(n), "aiSummary новости не санитайзится");
  assert(/wrapUntrusted\(/.test(n), "нет untrusted-обёртки блока новости");
  console.log("NEWS_SANITIZED_GATE_OK");
} else if (cmd === "outbox") {
  const i = read("src/instrumentation.ts");
  assert(/setInterval/.test(i), "нет периодического drain outbox");
  assert(/outboxTimer\.unref/.test(i), "таймер держит процесс (нет unref)");
  console.log("OUTBOX_CRON_GATE_OK");
} else if (cmd === "killswitch") {
  const r = read("src/app/api/ai/decisions/route.ts");
  assert(/isAdmin/.test(r), "decisions API не отдаёт флаг оператора");
  const ui = read("src/components/settings/decision-inbox.tsx");
  assert(/toggleGlobalKill/.test(ui), "нет функции kill-switch в UI");
  assert(/op: 'global_kill'/.test(ui), "UI не вызывает PATCH global_kill");
  assert(/AlertDialog/.test(ui), "нет подтверждения перед остановкой автономии");
  assert(/\{isAdmin && autonomy && \(/.test(ui), "kill-switch виден не-оператору");
  console.log("KILLSWITCH_UI_GATE_OK");
} else if (cmd === "a11y") {
  const g = read("src/app/globals.css");
  assert(/--input: oklch\(0\.70 0\.01 240\)/.test(g), "light --input контраст не поднят");
  assert(/--input: oklch\(1 0 0 \/ 35%\)/.test(g), "dark --input контраст не поднят");
  const av = read("src/components/common/user-avatar.tsx");
  assert(/role="img"/.test(av) && /Сейчас онлайн/.test(av), "online-точка без роли/текста для скринридера");
  console.log("A11Y_WAVE_GATE_OK");
} else if (cmd === "guard") {
  const r = read("src/app/api/recommendations/route.ts");
  assert(/сарафанного радио/.test(r), "нет guard-комментария идеологии");
  assert(/status: 'accepted'/.test(r), "guard не проверяет принятую связь");
  assert(/укажите совместный проект или установите связь/.test(r), "нет честного сообщения об отказе");
  console.log("REC_GUARD_GATE_OK");
} else if (cmd === "gptaudit") {
  const p = "docs/gpt-audit/16-09-2026/GPT-AUDIT-PROMPT.md";
  assert(existsSync(`${root}/${p}`), "файл брифа отсутствует");
  const d = read(p);
  for (const s of ["ТЕКСТ ДЛЯ АУДИТОРА", "Вопросы аудитора", "Требуемый формат отчёта", "AUD-", "Приложение"]) {
    assert(d.includes(s), `в брифе нет раздела: ${s}`);
  }
  console.log("GPT_AUDIT_DOC_GATE_OK");
} else {
  console.error("usage: verify-fix-campaign.mjs rating|ipscore|chains|demotoken|sanitizer|outbox|killswitch|a11y|guard|gptaudit");
  process.exit(2);
}
