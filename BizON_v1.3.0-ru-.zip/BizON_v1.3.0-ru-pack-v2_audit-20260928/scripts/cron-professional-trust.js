// BizON v6 — Cron: пересчёт Professional Trust (TrustIndex, dimension='professional')
// 6-факторная формула doc_a §41 (зеркало src/lib/services/professional-trust-service.ts —
// скрипт не может импортировать TS, логика продублирована 1:1):
//
//   Professional Trust = EvidenceQuality × Verification × Outcome ×
//                        × Recency × Independence × Consistency   (0..100)
//
//   Все факторы в 0..1, score = произведение × 100 (каждый фактор — «гейт»:
//   слабое звено обрушивает итог). Activity и Network Influence В ФОРМУЛУ
//   НЕ ВХОДЯТ — «человек много сидит в BizON» ≠ «человек доказал компетентность».
//
//   1. evidenceQuality = avg(0.6 × starShare + 0.4 × confidence) по активным
//      ProfessionalEvidence; starShare = заполнено (role, responsibility, action, result)/4
//   2. verification = maxLevelWeight × shareVerified (+ при наличии Claims:
//      0.8×evidenceVer + 0.2×(verified claims / all claims));
//      уровни: claimed 0.10 → verified 0.45 → project_verified 0.75 → expert_verified 1.00
//   3. outcome = 0.6 × (доля доказательств с result) + 0.4 × min(1, завершённые проекты / 2)
//   4. recency = средняя свежесть по кривой §D.7 (≤12 мес → 1.0; 12–24 → 1.0→0.8;
//      >24 → max(0.4, 0.8 − 0.02×(мес−24)))
//   5. independence = min(1, |уникальные верификаторы| / 3), где верификаторы =
//      SkillConfirmation.confirmerId ∪ ClaimVerification.verifierId
//   6. consistency = 0.5 × (1 − 0.25×противоречия) + 0.5 × (доля навыков с 2+ подтверждениями);
//      противоречия = rejected claims + ClaimVerification verdict='refute'
//
// Edge case: нет активных доказательств → все факторы 0, score 0.
//
// «Активные пользователи» = есть Session за последние 90 дней, ИЛИ есть
// ProfessionalEvidence, ИЛИ есть SkillConfirmation их навыков.
// Флаг --all пересчитывает всех пользователей без исключения.
//
// Запуск:
//   node scripts/cron-professional-trust.js [--all]
//
// Cron (ежедневно в 03:40, после cron-capital):
//   crontab -e:
//     40 3 * * *  cd /home/z/my-project && /usr/bin/node scripts/cron-professional-trust.js >> /var/log/bizon-cron.log 2>&1
//
//   pm2 (альтернатива):
//     { name: 'bizon-cron-professional-trust', script: 'scripts/cron-professional-trust.js', cron_restart: '40 3 * * *', autorestart: false }
//
// Идемпотентность: TrustIndex.userId @unique → честный prisma upsert;
// повторный запуск просто пересчитывает те же значения.

const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const FORMULA_VERSION = 'v1';
const INDEPENDENCE_TARGET = 3;
const ACTIVE_WINDOW_DAYS = 90;

const VERIFICATION_LEVEL_WEIGHTS = {
  claimed: 0.1,
  verified: 0.45,
  project_verified: 0.75,
  expert_verified: 1.0,
};

const MONTH_MS = 1000 * 60 * 60 * 24 * 30;
const clamp01 = (v) => (Number.isNaN(v) ? 0 : Math.min(1, Math.max(0, v)));
const r2 = (v) => Math.round(v * 100) / 100;
const isFilled = (s) => Boolean(s && String(s).trim().length > 0);

/** Кривая свежести — как recencyFactor в src/lib/skills/level-formula.ts (Spec §D.7). */
function recencyFactor(date, now) {
  const months = (now.getTime() - date.getTime()) / MONTH_MS;
  if (months <= 12) return 1.0;
  if (months <= 24) return 1.0 - 0.2 * ((months - 12) / 12);
  return Math.max(0.4, 0.8 - 0.02 * (months - 24));
}

const buildExplanation = (key, ctx) => {
  switch (key) {
    case 'evidenceQuality':
      return `Доказательств: ${ctx.evidenceCount}; средняя полнота STAR ${Math.round(ctx.starFilledAvg * 100)}%, средняя уверенность AI ${ctx.confidenceAvg.toFixed(2)} → фактор ${ctx.factors.evidenceQuality.toFixed(2)}.`;
    case 'verification':
      return `Лучший уровень верификации — «${ctx.bestLevelName}», верифицировано ${ctx.verifiedCount} из ${ctx.evidenceCount} доказательств${ctx.claimsTotal > 0 ? `, утверждений подтверждено ${ctx.claimsVerified} из ${ctx.claimsTotal}` : ''} → фактор ${ctx.factors.verification.toFixed(2)}.`;
    case 'outcome':
      return `Измеримый результат указан в ${ctx.evidenceWithResult} из ${ctx.evidenceCount} доказательств; завершённых проектов: ${ctx.completedProjects} → фактор ${ctx.factors.outcome.toFixed(2)}.`;
    case 'recency':
      return `Возраст доказательств: от ${ctx.newestMonths} до ${ctx.oldestMonths} мес.; средняя свежесть по кривой затухания = ${ctx.factors.recency.toFixed(2)}.`;
    case 'independence':
      return `Независимых верификаторов: ${ctx.distinctVerifiers} (максимум при ${INDEPENDENCE_TARGET} разных людях) → фактор ${ctx.factors.independence.toFixed(2)}.`;
    case 'consistency':
      return `Противоречий: ${ctx.contradictions}; навыков с 2+ подтверждениями: ${ctx.skillsMultiConfirmed} из ${ctx.skillsTotal} → фактор ${ctx.factors.consistency.toFixed(2)}.`;
    default:
      return '';
  }
};

/**
 * Пересчёт 6 факторов Professional Trust для одного пользователя.
 * Возвращает { score, factors, explanations, metrics } для логов.
 */
async function recomputeForUser(userId) {
  const now = new Date();

  const [evidence, claims, userSkills, memberships, skillConfirmations, claimVerifications] =
    await Promise.all([
      prisma.professionalEvidence.findMany({
        where: { userId, status: 'active' },
        select: { role: true, responsibility: true, action: true, result: true, verificationLevel: true, confidence: true, date: true },
      }),
      prisma.claim.findMany({ where: { userId }, select: { status: true } }),
      prisma.userSkill.findMany({ where: { userId }, select: { id: true, confirmationsCount: true } }),
      prisma.projectMember.findMany({ where: { userId }, select: { project: { select: { status: true } } } }),
      prisma.skillConfirmation.findMany({ where: { userSkill: { userId } }, select: { confirmerId: true } }),
      prisma.claimVerification.findMany({ where: { claim: { userId } }, select: { verifierId: true, verdict: true } }),
    ]);

  const verifierIds = new Set([
    ...skillConfirmations.map((c) => c.confirmerId),
    ...claimVerifications.map((v) => v.verifierId),
  ]);
  const claimsTotal = claims.length;
  const claimsVerified = claims.filter((c) => c.status === 'verified').length;
  const claimsRejected = claims.filter((c) => c.status === 'rejected').length;
  const completedProjects = memberships.filter((m) => m.project.status === 'completed').length;
  const refuted = claimVerifications.filter((v) => v.verdict === 'refute').length;
  const contradictions = claimsRejected + refuted;
  const skillsTotal = userSkills.length;
  const skillsMultiConfirmed = userSkills.filter((s) => s.confirmationsCount >= 2).length;

  const metrics = {
    evidenceCount: evidence.length,
    starFilledAvg: 0,
    confidenceAvg: 0,
    bestLevelName: 'claimed',
    verifiedCount: 0,
    claimsTotal,
    claimsVerified,
    claimsRejected,
    evidenceWithResult: 0,
    completedProjects,
    oldestMonths: null,
    newestMonths: null,
    distinctVerifiers: verifierIds.size,
    skillsTotal,
    skillsMultiConfirmed,
    contradictions,
  };

  // Edge case: нет активных доказательств → все факторы 0, score 0.
  if (evidence.length === 0) {
    const factors = { evidenceQuality: 0, verification: 0, outcome: 0, recency: 0, independence: 0, consistency: 0 };
    const explanations = {};
    for (const key of Object.keys(factors)) {
      explanations[key] = 'Нет профессиональных доказательств — фактор не определяется.';
    }
    return { score: 0, factors, explanations, metrics };
  }

  // 1. Evidence Quality: полнота STAR + уверенность AI
  const starShares = evidence.map(
    (e) => [e.role, e.responsibility, e.action, e.result].filter(isFilled).length / 4
  );
  metrics.starFilledAvg = starShares.reduce((a, b) => a + b, 0) / evidence.length;
  metrics.confidenceAvg = evidence.reduce((a, e) => a + clamp01(e.confidence), 0) / evidence.length;

  // 2. Verification: лучший уровень × доля верифицированных (+ Claims)
  const levelWeights = evidence.map((e) => VERIFICATION_LEVEL_WEIGHTS[e.verificationLevel] ?? 0.1);
  const bestLevelWeight = Math.max(...levelWeights);
  metrics.bestLevelName =
    Object.entries(VERIFICATION_LEVEL_WEIGHTS).sort((a, b) => b[1] - a[1]).find(
      ([, w]) => w <= bestLevelWeight + 1e-9
    )?.[0] ?? 'claimed';
  metrics.verifiedCount = evidence.filter((e) => e.verificationLevel !== 'claimed').length;
  const evidenceVer = clamp01(bestLevelWeight * (metrics.verifiedCount / evidence.length));
  const claimsVer = claimsTotal > 0 ? clamp01(claimsVerified / claimsTotal) : null;

  // 3. Outcome: результаты + завершённые проекты
  metrics.evidenceWithResult = evidence.filter((e) => isFilled(e.result)).length;
  const resultShare = metrics.evidenceWithResult / evidence.length;
  const completedShare = Math.min(1, completedProjects / 2);

  // 4. Recency: средняя свежесть
  const recencies = evidence.map((e) => recencyFactor(e.date, now));
  const ages = evidence.map((e) => Math.round((now.getTime() - e.date.getTime()) / MONTH_MS));
  metrics.oldestMonths = Math.max(...ages);
  metrics.newestMonths = Math.min(...ages);

  // 6. Consistency: без противоречий + многократные подтверждения навыков
  const noContradictions = clamp01(1 - 0.25 * contradictions);
  const multiShare = skillsTotal > 0 ? skillsMultiConfirmed / skillsTotal : 0;

  const factors = {
    evidenceQuality: r2(clamp01(0.6 * metrics.starFilledAvg + 0.4 * metrics.confidenceAvg)),
    verification: r2(claimsVer !== null ? clamp01(0.8 * evidenceVer + 0.2 * claimsVer) : evidenceVer),
    outcome: r2(clamp01(0.6 * resultShare + 0.4 * completedShare)),
    recency: r2(clamp01(recencies.reduce((a, b) => a + b, 0) / recencies.length)),
    independence: r2(clamp01(verifierIds.size / INDEPENDENCE_TARGET)),
    consistency: r2(clamp01(0.5 * noContradictions + 0.5 * multiShare)),
  };

  const explanations = {};
  for (const key of Object.keys(factors)) {
    explanations[key] = buildExplanation(key, { ...metrics, factors });
  }

  const product =
    factors.evidenceQuality * factors.verification * factors.outcome *
    factors.recency * factors.independence * factors.consistency;
  const score = Math.round(clamp01(product) * 100 * 10) / 10;

  return { score, factors, explanations, metrics };
}

async function main() {
  const forceAll = process.argv.includes('--all');
  console.log('=== BizON v6 — Cron: пересчёт Professional Trust (6 факторов, doc_a §41) ===');
  console.log(`Время: ${new Date().toISOString()}`);
  console.log(
    'Формула v1: EvidenceQuality × Verification × Outcome × Recency × Independence × Consistency × 100\n'
  );

  // «Активные»: сессия за последние 90 дней ИЛИ есть доказательства ИЛИ есть подтверждения навыков.
  let users;
  if (forceAll) {
    users = await prisma.user.findMany({ select: { id: true, name: true }, orderBy: { createdAt: 'asc' } });
    console.log('Режим: --all (все пользователи)');
  } else {
    const cutoff = new Date(Date.now() - ACTIVE_WINDOW_DAYS * 24 * 60 * 60 * 1000);
    const [recentSessionUsers, evidenceUsers, confirmedUsers] = await Promise.all([
      prisma.session.findMany({ where: { createdAt: { gte: cutoff } }, select: { userId: true }, distinct: ['userId'] }),
      prisma.professionalEvidence.findMany({ where: { status: 'active' }, select: { userId: true }, distinct: ['userId'] }),
      prisma.skillConfirmation.findMany({ select: { userSkill: { select: { userId: true } } } }),
    ]);
    const ids = new Set([
      ...recentSessionUsers.map((s) => s.userId),
      ...evidenceUsers.map((e) => e.userId),
      ...confirmedUsers.map((c) => c.userSkill.userId),
    ]);
    users = await prisma.user.findMany({
      where: { id: { in: [...ids] } },
      select: { id: true, name: true },
      orderBy: { createdAt: 'asc' },
    });
    console.log(`Критерий активности: сессия за ${ACTIVE_WINDOW_DAYS} дн. / есть доказательства / есть подтверждения навыков`);
  }

  if (users.length === 0) {
    console.log('Активных пользователей не найдено (или используйте --all). Выход.');
    return;
  }
  console.log(`Найдено пользователей: ${users.length}\n`);

  let recomputed = 0;
  let failed = 0;
  let scoreSum = 0;
  let maxScore = 0;
  let topUser = null;

  for (let i = 0; i < users.length; i++) {
    const user = users[i];
    try {
      const { score, factors, explanations, metrics } = await recomputeForUser(user.id);

      const summary =
        score === 0
          ? 'Нет профессиональных доказательств'
          : `Professional Trust ${score >= 66 ? 'высокий' : score >= 33 ? 'средний' : 'низкий'} (${score}/100)`;

      await prisma.trustIndex.upsert({
        where: { userId: user.id },
        create: {
          userId: user.id,
          score,
          dimension: 'professional',
          factors: {
            ...factors,
            formulaVersion: FORMULA_VERSION,
            explanations,
            summary,
            metrics,
          },
          computedAt: new Date(),
        },
        update: {
          score,
          dimension: 'professional',
          factors: {
            ...factors,
            formulaVersion: FORMULA_VERSION,
            explanations,
            summary,
            metrics,
          },
          computedAt: new Date(),
        },
      });

      recomputed++;
      scoreSum += score;
      if (score > maxScore) {
        maxScore = score;
        topUser = user.name;
      }

      console.log(
        `[${i + 1}/${users.length}] ✅ ${user.name}: score=${score} ` +
          `(EQ=${factors.evidenceQuality}, V=${factors.verification}, O=${factors.outcome}, ` +
          `R=${factors.recency}, I=${factors.independence}, C=${factors.consistency}; ` +
          `доказательств=${metrics.evidenceCount}, верификаторов=${metrics.distinctVerifiers})`
      );
    } catch (e) {
      failed++;
      console.error(`[${i + 1}/${users.length}] ❌ ${user.name} — ${e.message}`);
    }
  }

  console.log('\n=== Итог ===');
  console.log(`  Пересчитано: ${recomputed}`);
  console.log(`  Ошибок: ${failed}`);
  console.log(`  Всего пользователей: ${users.length}`);
  console.log(
    `  Средний score: ${recomputed > 0 ? r2(scoreSum / recomputed) : 0}` +
      `${topUser ? ` | Лидер: ${topUser} (${maxScore})` : ''}`
  );
  console.log('\n✅ cron-professional-trust complete.');
}

main()
  .catch((e) => {
    console.error('❌ cron-professional-trust failed:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect().catch(() => {});
  });
