// BizON — P1-c: Чиним обрыв фразы в описании компании BizON
//
// Проблема: в seed-данных у компании "BizON" описание заканчивается фразой
// «Маяк в цифровом мире.» (или «Маск в цифровом мире.» — опечатка/typo),
// которая выглядит как обрыв более длинной мысли.
//
// Решение: заменяем описание на корректное полное:
//   «BizON — это профессиональная социальная сеть нового поколения,
//    объединяющая людей, команды и организации на основе доверия
//    и подтверждённых действий, а не лайков и фолловеров.
//    Мы строим инфраструктуру профессиональной жизни, где каждый
//    может доказать свою экспертизу через реальные проекты и
//    подтверждения коллег.»
//
// Запуск: node scripts/fix-company-description.js
// (Prisma подхватывает DATABASE_URL из .env автоматически)

const { PrismaClient } = require('@prisma/client');

const db = new PrismaClient();

// Эталонное описание (полный текст без обрывов)
const CORRECT_DESCRIPTION =
  'BizON — это профессиональная социальная сеть нового поколения, ' +
  'объединяющая людей, команды и организации на основе доверия и подтверждённых действий, ' +
  'а не лайков и фолловеров. Мы строим инфраструктуру профессиональной жизни, ' +
  'где каждый может доказать свою экспертизу через реальные проекты и подтверждения коллег.';

// Маркеры обрыва — ищем по подстроке в description
const BROKEN_MARKERS = ['Маяк в цифровом мире', 'Маск в цифровом мире'];

async function main() {
  console.log('=== P1-c: fix-company-description.js — чиним обрыв фразы ===\n');

  // Ищем компании, в описании которых есть один из маркеров обрыва
  const companies = await db.company.findMany({
    where: {
      OR: BROKEN_MARKERS.map(marker => ({
        description: { contains: marker },
      })),
    },
    select: { id: true, name: true, description: true },
  });

  console.log(`  Найдено компаний с обрывом фразы: ${companies.length}`);

  if (companies.length === 0) {
    // Проверим — возможно, описание уже исправлено
    const alreadyFixed = await db.company.findFirst({
      where: { description: { contains: CORRECT_DESCRIPTION.slice(0, 60) } },
      select: { id: true, name: true },
    });
    if (alreadyFixed) {
      console.log(`  ✅ Описание уже исправлено у компании "${alreadyFixed.name}" (id=${alreadyFixed.id}).`);
    } else {
      console.log('  ⚠️  Компании с обрывом фразы не найдено. Ничего не делаем.');
    }
    await db.$disconnect();
    return;
  }

  // Обновляем каждую найденную компанию (обычно одна — BizON)
  for (const c of companies) {
    console.log(`\n  → Обновляем компанию "${c.name}" (id=${c.id})`);
    console.log(`     Было: ${JSON.stringify(c.description)}`);
    await db.company.update({
      where: { id: c.id },
      data: { description: CORRECT_DESCRIPTION },
    });
    console.log(`     Стало: ${JSON.stringify(CORRECT_DESCRIPTION)}`);
  }

  console.log(`\n  ✅ Обновлено компаний: ${companies.length}`);
  console.log('\n=== Готово ===');
  await db.$disconnect();
}

main().catch(async (e) => {
  console.error('❌ Ошибка:', e);
  await db.$disconnect();
  process.exit(1);
});
