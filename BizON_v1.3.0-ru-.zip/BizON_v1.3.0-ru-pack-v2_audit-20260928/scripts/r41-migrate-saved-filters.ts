// R2 (Task 41) — миграция SavedFilter → ResonanceFilter БЕЗ ПОТЕРЬ.
//
// Канон директивы R2: «SavedFilter миграция без потерь». Правила:
//   1. SavedFilter НЕ удаляется и НЕ мутируется (аддитивная миграция).
//   2. Каждый SavedFilter получает ResonanceFilter-пару с sourceFilterId
//      (трассируемость), target==='jobs' дополнительно получает traitsJson
//      из params (если там были skill-подобные ключи — честно переносим
//      только то, что есть; ничего не выдумываем).
//   3. Идемпотентность: повторный запуск не создаёт дублей
//      (проверка по sourceFilterId).
//   4. Верификация: после миграции counts(source) === counts(migrated).
//
// Запуск: bun run scripts/r41-migrate-saved-filters.ts [--dry-run]
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();
const dryRun = process.argv.includes('--dry-run');

async function main() {
  const saved = await db.savedFilter.findMany({ orderBy: { createdAt: 'asc' } });
  console.log(`[r41-migrate] SavedFilter к переносу: ${saved.length} (dry-run: ${dryRun})`);

  let created = 0;
  let skipped = 0;

  for (const f of saved) {
    const existing = await db.resonanceFilter.findFirst({ where: { sourceFilterId: f.id } });
    if (existing) {
      skipped += 1;
      continue;
    }

    // Resonance-семантика: params SavedFilter — строка JSON произвольных
    // параметров поиска. Переносим без потерь: offиngJson = исходные params
    // как есть (они про поиск работы), traitsJson — null (честно: в SavedFilter
    // резонанс-бандов не было, выдумывать нельзя).
    let paramsJson: unknown = null;
    try {
      paramsJson = JSON.parse(f.params || '{}');
    } catch {
      paramsJson = { _raw: f.params }; // битый JSON не теряем — кладём as-is
    }

    if (!dryRun) {
      await db.resonanceFilter.create({
        data: {
          userId: f.userId,
          name: f.name.slice(0, 60),
          offeringJson: paramsJson as object,
          traitsJson: null,
          sourceFilterId: f.id,
          monitoring: f.monitoring,
          lastRunAt: f.lastRunAt,
        },
      });
    }
    created += 1;
  }

  const totalSource = await db.savedFilter.count();
  const totalMigrated = await db.resonanceFilter.count({ where: { sourceFilterId: { not: null } } });

  console.log(`[r41-migrate] создано: ${created}, пропущено (уже есть): ${skipped}`);
  console.log(`[r41-migrate] верификация: source=${totalSource}, migrated=${totalMigrated}`);
  if (totalMigrated < totalSource) {
    throw new Error(`Миграция НЕПОЛНАЯ: ${totalMigrated}/${totalSource} — запрещено «без потерь»`);
  }
  console.log('[r41-migrate] OK: миграция без потерь подтверждена');
}

main()
  .then(() => db.$disconnect())
  .catch(async (e) => {
    console.error('[r41-migrate] FAIL:', e);
    await db.$disconnect();
    process.exit(1);
  });
