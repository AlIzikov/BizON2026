// BizON — Этап 6.2 N v2: Cron NFT decay (раз в неделю)
//
// Запуск:
//   BIZON_ENCRYPTION_KEY=... node scripts/cron-nft-decay.js
//
// Рекомендуется еженедельный запуск через cron или pm2:
//   crontab -e:
//     0 3 * * 1  cd /home/z/my-project && BIZON_ENCRYPTION_KEY=... /usr/bin/node scripts/cron-nft-decay.js >> /var/log/bizon-nft-decay.log 2>&1
//
//   pm2 ecosystem.config.cjs:
//     {
//       name: 'bizon-cron-nft-decay',
//       script: 'scripts/cron-nft-decay.js',
//       cron_restart: '0 3 * * 1',
//       autorestart: false,
//       env: { BIZON_ENCRYPTION_KEY: '...' },
//     }
//
// Задачи cron:
//   1. Для каждого NFT-навыка проверить last SkillConfirmation date:
//      - если > 2 лет → UserSkill.decayed = true
//      - иначе → UserSkill.decayed = false (реактуализация)
//   2. Обновить NFTSkill.decayStatus (fresh | stale | decayed) на основе
//      даты последнего подтверждения.
//
// Принципы:
//   - FAIL-OPEN: ошибки в одной записи не прерывают обработку остальных
//   - Идемпотентность: повторный запуск безопасен
//   - Все действия логируются в stdout

const { PrismaClient } = require('@prisma/client');

// === Проверка BIZON_ENCRYPTION_KEY ===
const ENC_KEY = process.env.BIZON_ENCRYPTION_KEY;
if (!ENC_KEY) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в окружении.');
  console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
  console.error('   Запуск: BIZON_ENCRYPTION_KEY=... node scripts/cron-nft-decay.js');
  process.exit(1);
}

const prisma = new PrismaClient();

// === Константы (должны совпадать с nft-skills-service.ts) ===
const DECAY_STALE_MS = 2 * 365 * 24 * 60 * 60 * 1000; // 2 года
const DECAY_DECAYED_MS = 3 * 365 * 24 * 60 * 60 * 1000; // 3 года
const BATCH_SIZE = 500;

function isoNow() {
  return new Date().toISOString();
}

// === Задача 1: обновить UserSkill.decayed для всех UserSkill, у которых есть NFT ===
async function decayUserSkills() {
  console.log('\n--- Задача 1: decay UserSkill (last confirmation > 2 лет) ---');
  const cutoff = new Date(Date.now() - DECAY_STALE_MS);
  console.log(`Cutoff (2 года назад): ${cutoff.toISOString()}`);

  // Берём все уникальные userSkillId из NFTSkill
  const nftsWithSkills = await prisma.nFTSkill.findMany({
    distinct: ['userSkillId'],
    select: { userSkillId: true },
  });
  console.log(`Уникальных UserSkill с NFT: ${nftsWithSkills.length}`);

  let checked = 0;
  let markedDecayed = 0;
  let reactivated = 0;
  let unchanged = 0;
  let errors = 0;

  for (const { userSkillId } of nftsWithSkills) {
    try {
      // Берём последнее подтверждение
      const latestConf = await prisma.skillConfirmation.findFirst({
        where: { userSkillId },
        orderBy: { createdAt: 'desc' },
        select: { createdAt: true },
      });

      const userSkill = await prisma.userSkill.findUnique({
        where: { id: userSkillId },
        select: { id: true, decayed: true, createdAt: true },
      });
      if (!userSkill) {
        errors++;
        continue;
      }

      const lastConfirmedAt = latestConf?.createdAt ?? userSkill.createdAt;
      const sinceLast = Date.now() - lastConfirmedAt.getTime();
      const shouldDecay = sinceLast > DECAY_STALE_MS;
      checked++;

      if (userSkill.decayed !== shouldDecay) {
        await prisma.userSkill.update({
          where: { id: userSkillId },
          data: { decayed: shouldDecay },
        });
        if (shouldDecay) {
          markedDecayed++;
          console.log(`  🕰️  ${userSkillId} → decayed=true (last: ${lastConfirmedAt.toISOString()})`);
        } else {
          reactivated++;
          console.log(`  ✅ ${userSkillId} → decayed=false (реактуализация)`);
        }
      } else {
        unchanged++;
      }
    } catch (e) {
      console.error(`  ❌ Ошибка для ${userSkillId}:`, e.message);
      errors++;
    }
  }

  console.log(
    `Итог: проверено=${checked}, помечено decayed=${markedDecayed}, реактуализировано=${reactivated}, без изменений=${unchanged}, ошибок=${errors}`,
  );
  return { checked, markedDecayed, reactivated, unchanged, errors };
}

// === Задача 2: обновить NFTSkill.decayStatus (fresh | stale | decayed) ===
async function decayNftStatuses() {
  console.log('\n--- Задача 2: decay NFTSkill.decayStatus ---');

  const staleCutoff = new Date(Date.now() - DECAY_STALE_MS);
  const decayedCutoff = new Date(Date.now() - DECAY_DECAYED_MS);
  console.log(
    `Stale cutoff (2 года): ${staleCutoff.toISOString()}, decayed cutoff (3 года): ${decayedCutoff.toISOString()}`,
  );

  let checked = 0;
  let updated = 0;
  const summary = { fresh: 0, stale: 0, decayed: 0 };

  // Берём все NFT партиями
  let cursor = undefined;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const batch = await prisma.nFTSkill.findMany({
      take: BATCH_SIZE,
      ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
      orderBy: { id: 'asc' },
      select: { id: true, userSkillId: true, decayStatus: true, createdAt: true },
    });
    if (batch.length === 0) break;

    for (const nft of batch) {
      try {
        const latestConf = await prisma.skillConfirmation.findFirst({
          where: { userSkillId: nft.userSkillId },
          orderBy: { createdAt: 'desc' },
          select: { createdAt: true },
        });

        const lastConfirmedAt = latestConf?.createdAt ?? nft.createdAt;
        const sinceLast = Date.now() - lastConfirmedAt.getTime();

        let newStatus = 'fresh';
        if (sinceLast > DECAY_DECAYED_MS) newStatus = 'decayed';
        else if (sinceLast > DECAY_STALE_MS) newStatus = 'stale';

        checked++;

        if (newStatus !== nft.decayStatus) {
          await prisma.nFTSkill.update({
            where: { id: nft.id },
            data: {
              decayStatus: newStatus,
              lastConfirmedAt,
            },
          });
          updated++;
        }

        if (newStatus === 'fresh') summary.fresh++;
        else if (newStatus === 'stale') summary.stale++;
        else summary.decayed++;
      } catch (e) {
        console.error(`  ❌ Ошибка для NFT ${nft.id}:`, e.message);
      }
    }

    cursor = batch[batch.length - 1].id;
    if (batch.length < BATCH_SIZE) break;
  }

  console.log(
    `Итог: проверено=${checked}, обновлено=${updated}. fresh=${summary.fresh}, stale=${summary.stale}, decayed=${summary.decayed}`,
  );
  return { checked, updated, summary };
}

// === Main ===

async function main() {
  console.log('=== BizON — Этап 6.2 N v2: Cron NFT Decay ===');
  console.log(`Время: ${isoNow()}`);
  console.log(`BIZON_ENCRYPTION_KEY: задан (${ENC_KEY.length} символов)`);

  const results = {
    userSkillDecay: null,
    nftDecayStatus: null,
    errors: [],
  };

  try {
    results.userSkillDecay = await decayUserSkills();
  } catch (e) {
    console.error('❌ decayUserSkills failed:', e);
    results.errors.push({ task: 'decayUserSkills', error: e.message });
  }

  try {
    results.nftDecayStatus = await decayNftStatuses();
  } catch (e) {
    console.error('❌ decayNftStatuses failed:', e);
    results.errors.push({ task: 'decayNftStatuses', error: e.message });
  }

  console.log('\n=== Итог ===');
  console.log(`  UserSkill decay: ${JSON.stringify(results.userSkillDecay)}`);
  console.log(`  NFT decayStatus: ${JSON.stringify(results.nftDecayStatus)}`);
  console.log(`  Errors: ${results.errors.length}`);
  console.log('\n✅ Cron-nft-decay complete.');
}

main()
  .catch((e) => {
    console.error('❌ Cron-nft-decay failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
