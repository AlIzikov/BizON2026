#!/usr/bin/env node
// BizON — DB-021 (аудит 22-09-26): guard на `prisma db push --accept-data-loss`.
//
// Раньше package.json:11 давал `bun run db:push` с --accept-data-loss БЕЗ
// каких-либо преград: в production-окружении однократный запуск по привычке
// мог молча дропнуть колонки/таблицы, которых нет в schema.prisma.
// Канон миграций: production — ТОЛЬКО `prisma migrate deploy`; db:push —
// dev-инструмент быстрых итераций (волна 12/13 вела схему именно им).
//
// Политика:
//   NODE_ENV=production                → жёсткий отказ (exit 1);
//   BIZON_ALLOW_DB_PUSH=1 (любая среда)→ явный осознанный обход отказа.
// Прогон скрипта с NODE_ENV=production — сам тест гейта (exit-код).
if (process.env.NODE_ENV === 'production' && process.env.BIZON_ALLOW_DB_PUSH !== '1') {
  console.error(
    '[DB-021] ЗАПРЕЩЕНО: `db:push --accept-data-loss` в production.\n' +
      '  Используйте `bun run db:migrate` / `prisma migrate deploy`.\n' +
      '  Если вы ТОЧНО понимаете последствия (dev/тестовый контур) — BIZON_ALLOW_DB_PUSH=1.'
  );
  process.exit(1);
}
const { execSync } = require('node:child_process');
try {
  execSync('npx prisma db push --accept-data-loss', { stdio: 'inherit' });
} catch (e) {
  process.exit(e.status ?? 1);
}
