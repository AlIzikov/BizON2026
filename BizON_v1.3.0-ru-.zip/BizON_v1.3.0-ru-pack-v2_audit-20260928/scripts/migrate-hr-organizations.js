// BizON — Миграция HR Organizations (Phase 2)
// Для существующих hr_agency users без HrOrganization — создаёт организацию
// по умолчанию (имя = имя пользователя) и recruiter-запись.
//
// Запуск: node scripts/migrate-hr-organizations.js
//
// Idempotent: повторный запуск не создаёт дубликаты (проверка по Recruiter.userId @unique).

const { PrismaClient } = require('@prisma/client');

async function main() {
  const prisma = new PrismaClient();

  console.log('=== Миграция HR Organizations ===\n');

  // 1. Найти всех hr_agency users без Recruiter-записи
  const hrUsers = await prisma.user.findMany({
    where: { accountType: 'hr_agency' },
    select: { id: true, name: true, createdAt: true },
  });

  console.log(`HR-агентств найдено: ${hrUsers.length}`);

  let created = 0;
  let skipped = 0;
  let errors = 0;

  for (const u of hrUsers) {
    try {
      // Проверяем, есть ли уже recruiter-запись
      const existing = await prisma.recruiter.findUnique({
        where: { userId: u.id },
        select: { id: true, organizationId: true },
      });

      if (existing) {
        skipped++;
        continue;
      }

      // Создаём организацию + recruiter в одной транзакции
      const org = await prisma.$transaction(async (tx) => {
        const newOrg = await tx.hrOrganization.create({
          data: {
            name: u.name || 'HR Agency',
            // isVerified наследуем из user.isVerified (если был верифицирован)
            // — но мы не знаем наверняка, оставляем false (верификация — отдельный процесс)
          },
        });

        await tx.recruiter.create({
          data: {
            userId: u.id,
            organizationId: newOrg.id,
          },
        });

        return newOrg;
      });

      created++;
      console.log(`  ✓ Создана организация «${org.name}» для ${u.name} (${u.id})`);
    } catch (e) {
      errors++;
      console.error(`  ✗ Ошибка для ${u.name} (${u.id}):`, e.message);
    }
  }

  console.log(`\n=== Итого ===`);
  console.log(`Создано организаций: ${created}`);
  console.log(`Пропущено (уже есть): ${skipped}`);
  console.log(`Ошибок: ${errors}`);

  await prisma.$disconnect();
}

main().catch((e) => {
  console.error('Fatal error:', e);
  process.exit(1);
});
