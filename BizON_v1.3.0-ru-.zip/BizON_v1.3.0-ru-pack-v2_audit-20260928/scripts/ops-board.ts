// =============================================================================
// BizON — OPS-БОРД (CLI): «Grafana-борд» из бэклога владельца (2026-09-19).
//
// Grafana-стек в sandbox не поднимается — тот же срез здоровья отдаёт:
//   • этот CLI: живая проверка GET / + ЖИВАЯ матрица логинов 10 демо-аккаунтов
//     (POST /api/auth/login — честный end-to-end) + метрики через
//     /api/admin/ops-board при заданном BIZON_ADMIN_TOKEN;
//   • GET /api/admin/ops-board — тот же JSON для админ-сессии/токена
//     (сервис src/lib/services/ops-board-service.ts).
//
// Запуск: bun scripts/ops-board.ts [BaseUrl]
//   BaseUrl по умолчанию: http://localhost:3000
// Exit 1 — если сервер недоступен или матрица логинов не 10/10.
// =============================================================================
import { DEMO_ACCOUNTS, getDemoPassword } from '../src/lib/demo-accounts';

const BASE = process.argv[2] ?? 'http://localhost:3000';

function line(ch = '─', n = 74): string {
  return ch.repeat(n);
}

async function main(): Promise<number> {
  console.log(line('━'));
  console.log('  BizON OPS-БОРД — ' + new Date().toISOString());
  console.log(line('━'));

  // 1) Живой сервер
  let serverOk = false;
  let t0 = Date.now();
  try {
    const res = await fetch(`${BASE}/`, { signal: AbortSignal.timeout(8000) });
    const ms = Date.now() - t0;
    serverOk = res.status === 200;
    console.log(`  GET /            → ${res.status} (${ms}ms) ${serverOk ? '✓ ALIVE' : '✗ НЕ 200'}`);
  } catch (e) {
    console.log(`  GET /            → ✗ НЕДОСТУПЕН (${e instanceof Error ? e.message : e})`);
  }

  // 2) Живая матрица логинов демо-аккаунтов (end-to-end через боевой API)
  // P0.3: пароли ротированы, живут в .env (BIZON_DEMO_PASSWORDS). Аккаунты без
  // записи в .env честно помечаются «—» (не считаются фейлом здоровья).
  console.log(line());
  console.log('  ДЕМО-ЛОГИНЫ (POST /api/auth/login, пароль — из .env BIZON_DEMO_PASSWORDS):');
  let ok = 0;
  let checked = 0;
  for (const acc of DEMO_ACCOUNTS) {
    const password = getDemoPassword(acc.email);
    if (!password) {
      console.log(`    — ${acc.email.padEnd(20)} → ротирован, пароля нет в .env (run reset-demo-passwords)`);
      continue;
    }
    checked++;
    t0 = Date.now();
    try {
      const res = await fetch(`${BASE}/api/auth/login`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email: acc.email, password }),
        signal: AbortSignal.timeout(8000),
      });
      const ms = Date.now() - t0;
      const mark = res.status === 200 ? '✓' : '✗';
      if (res.status === 200) ok++;
      console.log(`    ${mark} ${acc.email.padEnd(20)} → ${res.status} (${ms}ms)  ${acc.name}`);
    } catch (e) {
      console.log(`    ✗ ${acc.email.padEnd(20)} → СБОЙ: ${e instanceof Error ? e.message : e}`);
    }
  }
  console.log(`  ИТОГО: ${ok}/${checked} логинов OK (всего демо-аккаунтов: ${DEMO_ACCOUNTS.length})`);
  console.log(line());

  // 3) Системные метрики — через админ-API (если настроен BIZON_ADMIN_TOKEN)
  const token = process.env.BIZON_ADMIN_TOKEN;
  if (token) {
    try {
      const res = await fetch(`${BASE}/api/admin/ops-board`, {
        headers: { 'x-admin-token': token },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const board = (await res.json()) as {
          db: Record<string, number>;
          money: { totalBalance: number; escrowHeld: number; negativeBalances: number };
          server: { node: string; uptimeSec: number; memoryMB: number };
          demoLoginsOk: number;
          demoLoginsTotal: number;
        };
        console.log('  СИСТЕМА (GET /api/admin/ops-board):');
        const d = board.db;
        console.log(
          `    users=${d.users} (deleted=${d.usersDeleted}) · posts=${d.posts} · conversations=${d.conversations} · messages=${d.messages}`,
        );
        console.log(
          `    storeActive=${d.storeItemsActive} · bookingsOpen=${d.bookingsOpen} · outboxPending=${d.outboxPending} · sessions=${d.sessionsActive}`,
        );
        console.log(
          `    ДЕНЬГИ: баланс=${board.money.totalBalance} Л · эскроу held=${board.money.escrowHeld} Л · отрицательных=${board.money.negativeBalances} ${board.money.negativeBalances === 0 ? '✓ I3' : '✗ НАРУШЕНИЕ I3'}`,
        );
        console.log(
          `    node=${board.server.node} · uptime=${board.server.uptimeSec}s · rss=${board.server.memoryMB}MB`,
        );
      } else {
        console.log(`  GET /api/admin/ops-board → ${res.status} (токен отклонён?)`);
      }
    } catch {
      console.log('  GET /api/admin/ops-board → недоступен');
    }
  } else {
    console.log('  Системные метрики: задайте BIZON_ADMIN_TOKEN (или сессия admin) → GET /api/admin/ops-board');
  }

  console.log(line('━'));
  const demoOk = checked > 0 && ok === checked; // ротированные без .env честно исключаются
  const verdict = serverOk && demoOk ? 'ЗДОРОВ' : 'ТРЕБУЕТ ВНИМАНИЯ';
  console.log(`  ВЕРДИКТ: система ${verdict}`);
  console.log(line('━'));
  return serverOk && demoOk ? 0 : 1;
}

main()
  .then((code) => process.exit(code))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
