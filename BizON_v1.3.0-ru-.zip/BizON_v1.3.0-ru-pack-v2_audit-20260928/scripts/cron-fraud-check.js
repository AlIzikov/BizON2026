// BizON — SEC-5: Cron fraud check (раз в час)
//
// Запуск:
//   BIZON_ENCRYPTION_KEY=... node scripts/cron-fraud-check.js
//
// Рекомендуется ежечасный запуск через cron или pm2:
//   crontab -e:
//     0 * * * *  cd /home/z/my-project && BIZON_ENCRYPTION_KEY=... /usr/bin/node scripts/cron-fraud-check.js >> /var/log/bizon-fraud.log 2>&1
//
//   pm2 ecosystem.config.cjs:
//     {
//       name: 'bizon-cron-fraud',
//       script: 'scripts/cron-fraud-check.js',
//       cron_restart: '0 * * * *',
//       autorestart: false,
//       env: { BIZON_ENCRYPTION_KEY: '...' },
//     }
//
// Задачи cron:
//   1. SHARED_IP_BAN — найти IP, используемые 3+ пользователями (за 24ч),
//      пометить как IP_BANNED в AuditLog. Пользователи, использовавшие такой IP
//      в последние 24ч, получают ACCOUNT_FROZEN на 24ч.
//   2. HEAVY_CONFIRMER — пользователи с >100 подтверждениями за час
//      получают ACCOUNT_FROZEN на 24ч.
//   3. CLEANUP_OLD_LOGS — удаление старых audit-записей:
//      security events — 3 года, PII events — 2 года (ТЗ 3.7).
//
// Принципы:
//   - FAIL-OPEN: ошибки в одной задаче не прерывают другие
//   - Идемпотентность: повторный запуск безопасен (не дублирует freeze)
//   - Все действия логируются в AuditLog

const { PrismaClient } = require('@prisma/client');

// === Проверка BIZON_ENCRYPTION_KEY ===
// Скрипт не использует шифрование напрямую, но мы требуем ключ для соответствия
// контракту приложения (instrumentation.ts проверяет его при старте сервера).
const ENC_KEY = process.env.BIZON_ENCRYPTION_KEY;
if (!ENC_KEY) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в окружении.');
  console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
  console.error('   Запуск: BIZON_ENCRYPTION_KEY=... node scripts/cron-fraud-check.js');
  process.exit(1);
}

const prisma = new PrismaClient();

// === Константы (должны совпадать с anti-fraud.ts) ===

const SHARED_IP_THRESHOLD = 3; // 1 IP на 3+ пользователей
const HEAVY_CONFIRMER_THRESHOLD = 100; // >100 подтверждений/час
const HEAVY_CONFIRMER_WINDOW_MS = 60 * 60 * 1000; // 1 час
const FREEZE_DURATION_MS = 24 * 60 * 60 * 1000; // 24 часа
const SHARED_IP_LOOKBACK_MS = 24 * 60 * 60 * 1000; // 24 часа

const SECURITY_EVENT_TYPES = [
  'FRAUD_SUSPECTED',
  'ACCOUNT_FROZEN',
  'ACCOUNT_UNFROZEN',
  'ANOMALY_DETECTED',
  'BOT_DETECTED',
  'IP_BANNED',
  'FRAUD_REVIEW',
  'FRAUD_APPEAL',
];

const SECURITY_RETENTION_MS = 3 * 365 * 24 * 60 * 60 * 1000;
const PII_RETENTION_MS = 2 * 365 * 24 * 60 * 60 * 1000;

// === Утилиты ===

function isoNow() {
  return new Date().toISOString();
}

function isoIn(ms) {
  return new Date(Date.now() + ms).toISOString();
}

/**
 * Проверить, есть ли уже активная заморозка (ACCOUNT_FROZEN без ACCOUNT_UNFROZEN)
 * в течение последних 24ч. Используется для идемпотентности — не дублируем freeze.
 */
async function hasActiveFreeze(userId) {
  const since = new Date(Date.now() - FREEZE_DURATION_MS);
  const frozenEvent = await prisma.auditLog.findFirst({
    where: {
      action: 'ACCOUNT_FROZEN',
      resourceId: userId,
      createdAt: { gte: since },
    },
    orderBy: { createdAt: 'desc' },
    select: { id: true, createdAt: true },
  });
  if (!frozenEvent) return false;

  const unfrozenEvent = await prisma.auditLog.findFirst({
    where: {
      action: 'ACCOUNT_UNFROZEN',
      resourceId: userId,
      createdAt: { gt: frozenEvent.createdAt },
    },
    select: { id: true },
  });
  return !unfrozenEvent;
}

/**
 * Заморозить пользователя: записать ACCOUNT_FROZEN в AuditLog.
 * Идемпотентно: если уже заморожен — не дублирует.
 *
 * @param userId — кого замораживаем
 * @param reason — причина (для metadata)
 * @param score — suspicion score (0-100)
 * @returns true если создана новая заморозка, false если уже заморожен
 */
async function freezeUser(userId, reason, score) {
  try {
    const alreadyFrozen = await hasActiveFreeze(userId);
    if (alreadyFrozen) return false;

    await prisma.auditLog.create({
      data: {
        actorId: null,
        action: 'ACCOUNT_FROZEN',
        resource: 'user',
        resourceId: userId,
        ip: null,
        metadata: JSON.stringify({
          reason,
          score,
          frozenAt: isoNow(),
          frozenUntil: isoIn(FREEZE_DURATION_MS),
          source: 'cron_fraud_check',
        }),
      },
    });
    return true;
  } catch (e) {
    console.error(`[freezeUser] error for ${userId}:`, e.message);
    return false;
  }
}

// === Задача 1: SHARED_IP_BAN ===

/**
 * Найти IP, используемые 3+ уникальными пользователями за последние 24ч.
 * Для каждого такого IP:
 *   - Записать IP_BANNED в AuditLog (если ещё не забанен за последние 24ч)
 *   - Заморозить всех пользователей, использовавших этот IP (если не заморожены)
 */
async function banSharedIPs() {
  console.log('\n--- Задача 1: SHARED_IP_BAN ---');
  const since = new Date(Date.now() - SHARED_IP_LOOKBACK_MS);

  // Берём все audit-записи с IP за 24ч, группируем по IP
  const logs = await prisma.auditLog.findMany({
    where: {
      ip: { not: null },
      createdAt: { gte: since },
    },
    select: { ip: true, actorId: true },
  });

  // Группируем: ip → set(actorId)
  const ipToUsers = new Map();
  for (const l of logs) {
    if (!l.ip || !l.actorId) continue;
    if (!ipToUsers.has(l.ip)) ipToUsers.set(l.ip, new Set());
    ipToUsers.get(l.ip).add(l.actorId);
  }

  // Фильтруем IP с 3+ уникальными пользователями
  const sharedIPs = [];
  for (const [ip, users] of ipToUsers) {
    if (users.size >= SHARED_IP_THRESHOLD) {
      sharedIPs.push({ ip, userCount: users.size, users: [...users] });
    }
  }

  console.log(`Найдено shared IP (3+ users за 24ч): ${sharedIPs.length}`);

  let banned = 0;
  let frozenUsers = 0;
  let skippedAlreadyBanned = 0;

  for (const { ip, userCount, users } of sharedIPs) {
    // Проверяем, не забанен ли уже этот IP за последние 24ч
    const existingBan = await prisma.auditLog.findFirst({
      where: {
        action: 'IP_BANNED',
        ip,
        createdAt: { gte: since },
      },
      select: { id: true },
    });

    if (existingBan) {
      skippedAlreadyBanned++;
      continue;
    }

    // Записываем IP_BANNED
    await prisma.auditLog.create({
      data: {
        actorId: null,
        action: 'IP_BANNED',
        resource: 'ip',
        resourceId: ip,
        ip,
        metadata: JSON.stringify({
          ip,
          userCount,
          detectedAt: isoNow(),
          source: 'cron_fraud_check',
        }),
      },
    });
    banned++;
    console.log(`  🚫 IP ${ip} забанен (использовали ${userCount} пользователей)`);

    // Замораживаем всех пользователей, использовавших этот IP
    for (const userId of users) {
      const frozen = await freezeUser(
        userId,
        `shared_ip_ban:${ip} (${userCount} users)`,
        90,
      );
      if (frozen) {
        frozenUsers++;
        console.log(`    ❄️ Пользователь ${userId} заморожен на 24ч`);
      }
    }
  }

  console.log(`Итог: забанено IP=${banned}, пропущено (уже забанены)=${skippedAlreadyBanned}, заморожено пользователей=${frozenUsers}`);
  return { banned, skippedAlreadyBanned, frozenUsers };
}

// === Задача 2: HEAVY_CONFIRMER ===

/**
 * Найти пользователей с >100 подтверждениями за последний час.
 * Заморозить каждого на 24ч (идемпотентно).
 */
async function freezeHeavyConfirmers() {
  console.log('\n--- Задача 2: HEAVY_CONFIRMER ---');
  const since = new Date(Date.now() - HEAVY_CONFIRMER_WINDOW_MS);

  // Подсчёт подтверждений навыков и клеймов за час, сгруппированных по confirmerId
  const [skillConfs, claimConfs] = await Promise.all([
    prisma.skillConfirmation.groupBy({
      by: ['confirmerId'],
      where: { createdAt: { gte: since } },
      _count: { _all: true },
    }),
    prisma.claimVerification.groupBy({
      by: ['verifierId'],
      where: { createdAt: { gte: since } },
      _count: { _all: true },
    }),
  ]);

  // Объединяем счётчики
  const counters = new Map();
  for (const s of skillConfs) {
    counters.set(s.confirmerId, (counters.get(s.confirmerId) || 0) + s._count._all);
  }
  for (const c of claimConfs) {
    counters.set(c.verifierId, (counters.get(c.verifierId) || 0) + c._count._all);
  }

  // Фильтруем >100
  const heavy = [];
  for (const [userId, count] of counters) {
    if (count > HEAVY_CONFIRMER_THRESHOLD) {
      heavy.push({ userId, count });
    }
  }

  console.log(`Найдено heavy confirmers (>100/час): ${heavy.length}`);

  let frozen = 0;
  let skipped = 0;
  for (const { userId, count } of heavy) {
    const ok = await freezeUser(
      userId,
      `heavy_confirmer:${count}_per_hour`,
      95,
    );
    if (ok) {
      frozen++;
      console.log(`  ❄️ ${userId} заморожен (${count} подтверждений/час)`);
    } else {
      skipped++;
    }
  }

  console.log(`Итог: заморожено=${frozen}, пропущено (уже заморожены)=${skipped}`);
  return { frozen, skipped };
}

// === Задача 3: CLEANUP_OLD_LOGS ===

/**
 * Удалить старые audit-записи:
 *   - security events (FRAUD_*, ANOMALY_DETECTED, BOT_DETECTED, IP_BANNED, ACCOUNT_*) — 3 года
 *   - PII events (login, register, read_pii, ...) — 2 года (ТЗ 3.7)
 */
async function cleanupOldLogs() {
  console.log('\n--- Задача 3: CLEANUP_OLD_LOGS ---');
  const now = Date.now();
  const securityCutoff = new Date(now - SECURITY_RETENTION_MS);
  const piiCutoff = new Date(now - PII_RETENTION_MS);

  let deletedSecurity = 0;
  let deletedPii = 0;

  try {
    const secResult = await prisma.auditLog.deleteMany({
      where: {
        action: { in: SECURITY_EVENT_TYPES },
        createdAt: { lt: securityCutoff },
      },
    });
    deletedSecurity = secResult.count;
  } catch (e) {
    console.error('  Ошибка cleanup security events:', e.message);
  }

  try {
    const piiResult = await prisma.auditLog.deleteMany({
      where: {
        action: { notIn: SECURITY_EVENT_TYPES },
        createdAt: { lt: piiCutoff },
      },
    });
    deletedPii = piiResult.count;
  } catch (e) {
    console.error('  Ошибка cleanup PII events:', e.message);
  }

  console.log(`  Удалено security-событий старше ${securityCutoff.toISOString()}: ${deletedSecurity}`);
  console.log(`  Удалено PII-событий старше ${piiCutoff.toISOString()}: ${deletedPii}`);
  return { deletedSecurity, deletedPii };
}

// === Main ===

async function main() {
  console.log('=== BizON — SEC-5 Cron: Fraud Check ===');
  console.log(`Время: ${isoNow()}`);
  console.log(`BIZON_ENCRYPTION_KEY: задан (${ENC_KEY.length} символов)`);

  const results = {
    sharedIpBan: null,
    heavyConfirmer: null,
    cleanup: null,
    errors: [],
  };

  // Задача 1: SHARED_IP_BAN
  try {
    results.sharedIpBan = await banSharedIPs();
  } catch (e) {
    console.error('❌ banSharedIPs failed:', e);
    results.errors.push({ task: 'banSharedIPs', error: e.message });
  }

  // Задача 2: HEAVY_CONFIRMER
  try {
    results.heavyConfirmer = await freezeHeavyConfirmers();
  } catch (e) {
    console.error('❌ freezeHeavyConfirmers failed:', e);
    results.errors.push({ task: 'freezeHeavyConfirmers', error: e.message });
  }

  // Задача 3: CLEANUP_OLD_LOGS
  try {
    results.cleanup = await cleanupOldLogs();
  } catch (e) {
    console.error('❌ cleanupOldLogs failed:', e);
    results.errors.push({ task: 'cleanupOldLogs', error: e.message });
  }

  console.log('\n=== Итог ===');
  console.log(`  Shared IP ban: ${JSON.stringify(results.sharedIpBan)}`);
  console.log(`  Heavy confirmer: ${JSON.stringify(results.heavyConfirmer)}`);
  console.log(`  Cleanup: ${JSON.stringify(results.cleanup)}`);
  console.log(`  Errors: ${results.errors.length}`);
  console.log('\n✅ Cron-fraud-check complete.');
}

main()
  .catch((e) => {
    console.error('❌ Cron-fraud-check failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
