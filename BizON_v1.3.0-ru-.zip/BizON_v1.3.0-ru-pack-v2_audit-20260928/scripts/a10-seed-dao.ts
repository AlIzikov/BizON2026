// A10 — ONE-OFF: seed тестовых DAO proposals для проверки lazy-close-on-read.
// P1: просрочено, голоса За(56)+За(68) vs Против(20), счётчики изначально сбиты (drift) → должен стать passed, счётчики синхронизироваться (124/20/0)
// P2: просрочено, голосов нет → rejected
// P3: активное (endDate в будущем) → остаётся active
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

const HELENA = 'cmtlwo7ct000rme6uqv029h4d'; // ipScore 56
const DMITRY = 'cmtlwo7ct000sme6u9q92qufb'; // ipScore 68
const MARIA  = 'cmtlwo7cs000pme6uv7cq0x8k'; // ipScore 20
const IVAN   = 'cmtlwo7cr000ome6uscm1ipkt'; // демо, ipScore 26

async function main() {
  const now = Date.now();
  const day = 24 * 60 * 60 * 1000;

  // Убираем возможные остатки прошлых прогонов
  await db.daoProposal.deleteMany({ where: { title: { startsWith: 'A10 TEST —' } } });

  const p1 = await db.daoProposal.create({
    data: {
      title: 'A10 TEST — принято (for > against)',
      description: 'Тест lazy-close: просроченное голосование с перевесом «за».',
      type: 'governance',
      proposerId: HELENA,
      endDate: new Date(now - 1 * day),
      status: 'active',
      // Счётчики сознательно сбиты (drift) — close должен пересчитать из DaoVote
      forVotes: 0,
      againstVotes: 0,
      abstainVotes: 0,
    },
  });
  await db.daoVote.createMany({
    data: [
      { proposalId: p1.id, voterId: HELENA, vote: 'for', weight: 56 },
      { proposalId: p1.id, voterId: DMITRY, vote: 'for', weight: 68 },
      { proposalId: p1.id, voterId: MARIA, vote: 'against', weight: 20 },
    ],
  });

  await db.daoProposal.create({
    data: {
      title: 'A10 TEST — отклонено (0 голосов)',
      description: 'Тест lazy-close: просроченное голосование без голосов.',
      type: 'feature',
      proposerId: DMITRY,
      endDate: new Date(now - 2 * day),
      status: 'active',
    },
  });

  await db.daoProposal.create({
    data: {
      title: 'A10 TEST — ещё активное',
      description: 'Тест: не просрочено — должно остаться active.',
      type: 'budget',
      proposerId: HELENA,
      endDate: new Date(now + 3 * day),
      status: 'active',
      forVotes: 26,
    },
  });
  await db.daoVote.create({
    data: { proposalId: (await db.daoProposal.findFirst({ where: { title: 'A10 TEST — ещё активное' } }))!.id, voterId: IVAN, vote: 'for', weight: 26 },
  });

  console.log('[a10-seed] seeded 3 proposals');
}

main()
  .catch((e) => { console.error('[a10-seed] failed:', e); process.exit(1); })
  .finally(() => db.$disconnect());
