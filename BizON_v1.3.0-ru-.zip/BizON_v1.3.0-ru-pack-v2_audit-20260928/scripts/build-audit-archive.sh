#!/usr/bin/env bash
# =============================================================================
# Сборка аудиторского архива BizON (воспроизводимая).
# Использование: bash scripts/build-audit-archive.sh <OUT_DIR> <STAMP>
#   <OUT_DIR> — куда положить zip (по умолчанию gpt-audit/audit-14-09-26)
#   <STAMP>   — дата-штамп в имени (по умолчанию 20260914)
# Результат: BizON_v<версия>_audit-<STAMP>.zip + .sha256
# =============================================================================
set -euo pipefail

cd "$(dirname "$0")/.."
PROJECT="$(pwd)"

OUT_DIR="${1:-gpt-audit/audit-14-09-26}"
STAMP="${2:-20260914}"
FILTERS="scripts/audit-archive-filters.txt"
STAGE="$(mktemp -d /tmp/bizon-audit-stage.XXXXXX)"

VERSION="$(grep -oP '(?<=^VERSION: ).*' VERSION | head -1)"
[ -z "$VERSION" ] && VERSION="1.0.0-rc.1"
NAME="BizON_v${VERSION}_audit-${STAMP}"

echo "==> Версия: $VERSION"
echo "==> Зеркалирование проекта в $STAGE (фильтры: $FILTERS)"
rsync -a --delete \
  --filter="merge $FILTERS" \
  "$PROJECT/" "$STAGE/project/"

# страховка: секреты и мусор не должны попасть в зеркало
LEAKS=$(cd "$STAGE/project" && ls -1 .env bizon-config.env node_modules .next .git 2>/dev/null || true)
if [ -n "$LEAKS" ]; then
  echo "ОШИБКА: в зеркале обнаружены исключённые пути: $LEAKS" >&2
  rm -rf "$STAGE"
  exit 1
fi

mkdir -p "$OUT_DIR"
echo "==> Архивация: $OUT_DIR/$NAME.zip"
rm -f "$OUT_DIR/$NAME.zip" "$OUT_DIR/$NAME.zip.sha256"   # zip обновляет существующий архив, а не пересоздаёт
cd "$STAGE/project"
zip -qr "$PROJECT/$OUT_DIR/$NAME.zip" .
cd "$PROJECT"

echo "==> SHA-256"
( cd "$OUT_DIR" && sha256sum "$NAME.zip" > "$NAME.zip.sha256" )

FILES=$(unzip -l "$OUT_DIR/$NAME.zip" | tail -1 | awk '{print $2}')
SIZE=$(du -h "$OUT_DIR/$NAME.zip" | cut -f1)
echo "==> Готово: $OUT_DIR/$NAME.zip — $FILES файлов, $SIZE"
rm -rf "$STAGE"
