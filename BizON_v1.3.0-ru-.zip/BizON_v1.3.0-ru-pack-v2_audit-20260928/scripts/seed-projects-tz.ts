// BizON — seed-обогащение модуля «Проекты» (ТЗ-ПР-4.9 §10, контракт §10)
//
// Запуск: bun run scripts/seed-projects-tz.ts
//
// ВАЖНО: это НЕ scripts/seed.ts (тот стирает БД). Здесь только идемпотентное
// обогащение: upsert/findFirst-else-create — повторный запуск НЕ создаёт дублей.
//
// Состав:
//   1. TaxonomyItem (topics/regions/roles) — upsert по [type,name]
//   2. Первым 5 проектам: summary/promoAnnotation/topics/region, publishedAt,
//      детерминированные viewsCount (40..500), 2-3 ProjectContributor
//   3. ProjectComment: к 3 проектам по 1-2 комментария + 1 ответ (depth 1)
//   4. ProjectApplication: к recruiting-проектам 1-2 заявки
//   5. Лоты (3 шт, все 9 блоков detailsJson) + 2 LotResponse к первому
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

// ---------- справочники (контракт §10) ----------
const TOPICS = [
  'Здравоохранение', 'Промышленность', 'Спорт', 'Дизайн', 'Разработка ПО',
  'Строительство', 'Образование', 'Культура', 'Маркетинг', 'Логистика',
];
const REGIONS = [
  'Москва', 'Санкт-Петербург', 'Самара', 'Петропавловск-Камчатский',
  'Чувашская республика', 'Российская Федерация', 'Республика Беларусь', 'Online',
];
const ROLES = [
  'Автор', 'Заказчик', 'Дизайнер', 'Разработка', 'Верстка и печать',
  'Информационная и рекламная поддержка', 'Ментор',
];

// ---------- утилиты ----------
/** Детерминированный hash строки (для стабильных viewsCount между запусками). */
function hashString(s: string): number {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h;
}

const counters = { taxonomy: 0, projectsUpdated: 0, contributors: 0, comments: 0, replies: 0, applications: 0, lots: 0, lotResponses: 0 };

// ---------- 1. Таксономия ----------
async function seedTaxonomy() {
  for (const name of TOPICS) {
    const existing = await db.taxonomyItem.findFirst({ where: { type: 'topic', name } });
    if (!existing) {
      await db.taxonomyItem.create({ data: { type: 'topic', name } });
      counters.taxonomy++;
    }
  }
  for (const name of REGIONS) {
    const existing = await db.taxonomyItem.findFirst({ where: { type: 'region', name } });
    if (!existing) {
      await db.taxonomyItem.create({ data: { type: 'region', name } });
      counters.taxonomy++;
    }
  }
  for (const name of ROLES) {
    const existing = await db.taxonomyItem.findFirst({ where: { type: 'role', name } });
    if (!existing) {
      await db.taxonomyItem.create({ data: { type: 'role', name } });
      counters.taxonomy++;
    }
  }
}

// ---------- 2. Обогащение первых 5 проектов ----------
// Контент по смыслу title (ключ — точное имя проекта из scripts/seed.ts)
const PROJECT_CONTENT: Record<string, { summary: string; promo: string; topics: string[]; region: string; experienceShare: string }> = {
  'GreenAI Platform': {
    summary: 'AI-платформа мониторинга углеродного следа предприятий',
    promo: 'Экологичный ИТ-продукт: считаем и снижаем выбросы CO₂ с помощью машинного обучения',
    topics: ['Разработка ПО', 'Промышленность'],
    region: 'Москва',
    experienceShare: 'Готовы поделиться опытом и знаниями по: машинному обучению на временных рядах, интеграциям с промышленными датчиками и практике отчётности по ESG.',
  },
  'TrustGraph SDK': {
    summary: 'SDK для построения графов доверия и проверки репутации участников',
    promo: 'Открытая библиотека верификации: графы доверия для децентрализованных сервисов',
    topics: ['Разработка ПО'],
    region: 'Санкт-Петербург',
    experienceShare: 'Готовы поделиться опытом и знаниями по: алгоритмам графов, проектированию публичных SDK и проверке репутации без раскрытия личных данных.',
  },
  'CareerPath AI': {
    summary: 'AI-навигатор карьерных траекторий: от текущих навыков к целевой позиции',
    promo: 'Персональные маршруты развития на основе анализа рынка труда и вакансий',
    topics: ['Разработка ПО', 'Образование'],
    region: 'Online',
    experienceShare: 'Готовы поделиться опытом и знаниями по: карьерному менторству, анализу рынка труда и построению персональных планов развития.',
  },
  MentorHub: {
    summary: 'Платформа мэтчинга менторов и подопечных для профессионального роста',
    promo: 'Находим ментора под задачу: сессии, треки развития и измеримый прогресс',
    topics: ['Образование'],
    region: 'Самара',
    experienceShare: 'Готовы поделиться опытом и знаниями по: организации наставничества, проведению менторских сессий и измерению прогресса подопечных.',
  },
  'DataQuality Checker': {
    summary: 'Сервис автоматической проверки качества корпоративных данных',
    promo: 'Находим дубли, пробелы и аномалии в данных до того, как они попадут в отчёты',
    topics: ['Разработка ПО'],
    region: 'Москва',
    experienceShare: 'Готовы поделиться опытом и знаниями по: качеству данных, ETL-процессам и практике внедрения data-quality-практик в компании.',
  },
};

// Внешние участники «Над проектом работали» (§7.2 ТЗ): displayOrder с 1, роли из справочника
const PROJECT_CONTRIBUTORS: Record<string, Array<{ name: string; role: string; phone?: string; email?: string }>> = {
  'GreenAI Platform': [
    { name: 'ООО «Экоград Инжиниринг»', role: 'Заказчик', phone: '+7 (495) 120-45-67', email: 'info@ecograd-demo.ru' },
    { name: 'Кирилл Орлов', role: 'Разработка', email: 'k.orlov@ecograd-demo.ru' },
    { name: 'Полина Мельник', role: 'Информационная и рекламная поддержка' },
  ],
  'TrustGraph SDK': [
    { name: 'Антон Верещагин', role: 'Автор', phone: '+7 (812) 774-19-03' },
    { name: 'Студия «Графит»', role: 'Дизайнер', email: 'hello@grafit-demo.ru' },
  ],
  'CareerPath AI': [
    { name: 'HR-агентство «Вектор»', role: 'Заказчик', phone: '+7 (846) 231-88-40', email: 'team@vector-demo.ru' },
    { name: 'Дарья Климова', role: 'Ментор' },
  ],
  MentorHub: [
    { name: 'НКО «Наставники будущего»', role: 'Заказчик', email: 'hi@mentors-demo.ru' },
    { name: 'Игорь Сазонов', role: 'Разработка', phone: '+7 (927) 300-11-22' },
    { name: 'Вера Титова', role: 'Автор' },
  ],
  'DataQuality Checker': [
    { name: 'АО «Самарские данные»', role: 'Заказчик', phone: '+7 (846) 955-30-10' },
    { name: 'Марк Гущин', role: 'Разработка', email: 'm.gushin@smd-demo.ru' },
  ],
};

async function seedProjects() {
  const projects = await db.project.findMany({
    orderBy: { createdAt: 'asc' },
    take: 5,
    select: { id: true, title: true, summary: true, promoAnnotation: true, topicsCsv: true, region: true, publishedAt: true, viewsCount: true, experienceShare: true },
  });

  for (const p of projects) {
    const content = PROJECT_CONTENT[p.title] ?? {
      // фолбэк для незнакомого проекта (идемпотентность сохраняется: только пустые поля)
      summary: p.title.slice(0, 100),
      promo: `Проект «${p.title}» — витрина кейса на BizON`.slice(0, 150),
      topics: ['Разработка ПО'],
      region: 'Российская Федерация',
      experienceShare: `Готовы поделиться опытом и знаниями по тематике проекта «${p.title}» — спросите нас о деталях реализации.`,
    };

    const data: Record<string, unknown> = {};
    if (!p.summary) data.summary = content.summary.slice(0, 100);
    if (!p.promoAnnotation) data.promoAnnotation = content.promo.slice(0, 150);
    if (!p.topicsCsv) data.topicsCsv = content.topics.join(',');
    if (!p.region) data.region = content.region;
    if (!p.experienceShare) data.experienceShare = content.experienceShare.slice(0, 500);
    if (!p.publishedAt) data.publishedAt = new Date();
    if (p.viewsCount === 0) {
      // детерминированные просмотры 40..500 — стабильны между запусками (hash от id)
      data.viewsCount = 40 + (hashString(p.id) % 461);
    }
    if (Object.keys(data).length > 0) {
      await db.project.update({ where: { id: p.id }, data });
      counters.projectsUpdated++;
    }

    // Внешние участники: findFirst-else-create по (projectId, name)
    const contributors = PROJECT_CONTRIBUTORS[p.title] ?? [];
    let order = 1;
    for (const c of contributors) {
      const exists = await db.projectContributor.findFirst({
        where: { projectId: p.id, name: c.name },
        select: { id: true },
      });
      if (!exists) {
        await db.projectContributor.create({
          data: {
            projectId: p.id,
            name: c.name,
            role: c.role,
            phone: c.phone ?? null,
            email: c.email ?? null,
            displayOrder: order,
          },
        });
        counters.contributors++;
      }
      order++;
    }
  }
}

// ---------- 3. Комментарии к проектам (§5.3) ----------
const COMMENTS: Array<{ project: string; text: string }> = [
  { project: 'GreenAI Platform', text: 'Внушительный кейс! Как считаете точность прогнозов выбросов по отраслям?' },
  { project: 'GreenAI Platform', text: 'Интересно было бы увидеть интеграцию с датчиками IoT на производстве.' },
  { project: 'TrustGraph SDK', text: 'Использовали SDK в прототипе — документация понятная, спасибо команде.' },
  { project: 'CareerPath AI', text: 'Подскажите, планируется ли публичное API для карьерных маршрутов?' },
];

async function seedComments(users: Array<{ id: string }>) {
  if (users.length === 0) return;
  const projects = await db.project.findMany({
    orderBy: { createdAt: 'asc' },
    take: 3,
    select: { id: true, title: true, ownerId: true },
  });

  let commentIdx = 0;
  for (const project of projects) {
    // авторы комментария — не владелец проекта
    const candidates = users.filter((u) => u.id !== project.ownerId);
    const perProject = commentIdx === 0 ? 2 : 1; // к первому проекту — 2 комментария
    const authors = candidates.slice(0, perProject);
    let firstRootId: string | null = null;

    for (const author of authors) {
      const text = COMMENTS[commentIdx % COMMENTS.length].text;
      commentIdx++;
      const exists = await db.projectComment.findFirst({
        where: { projectId: project.id, authorId: author.id, text },
        select: { id: true },
      });
      if (exists) {
        firstRootId = firstRootId ?? exists.id;
        continue;
      }
      const created = await db.projectComment.create({
        data: { projectId: project.id, authorId: author.id, text },
      });
      counters.comments++;
      firstRootId = firstRootId ?? created.id;
    }

    // 1 ответ (depth 1) на первый корневой комментарий — от следующего юзера
    if (firstRootId) {
      const replier = candidates.find((u) => !authors.some((a) => a.id === u.id)) ?? candidates[0];
      const replyText = 'Спасибо за вопрос! Поделимся метриками в следующем обновлении проекта.';
      if (replier) {
        const replyExists = await db.projectComment.findFirst({
          where: { projectId: project.id, authorId: replier.id, parentId: firstRootId, text: replyText },
          select: { id: true },
        });
        if (!replyExists) {
          await db.projectComment.create({
            data: { projectId: project.id, authorId: replier.id, parentId: firstRootId, text: replyText },
          });
          counters.replies++;
        }
      }
    }
  }
}

// ---------- 4. Заявки на участие (UC-03) ----------
async function seedApplications(users: Array<{ id: string }>) {
  if (users.length === 0) return;
  // recruiting-проекты (ТЗ-статус); фолбэк — PROPOSAL/ACTIVE среди первых 5
  let targets = await db.project.findMany({
    where: { status: 'recruiting', deletedAt: null },
    orderBy: { createdAt: 'asc' },
    take: 2,
    select: { id: true, title: true, ownerId: true },
  });
  if (targets.length === 0) {
    targets = await db.project.findMany({
      where: { status: { in: ['PROPOSAL', 'ACTIVE', 'proposal', 'active'] }, deletedAt: null },
      orderBy: { createdAt: 'asc' },
      take: 2,
      select: { id: true, title: true, ownerId: true },
    });
  }

  const covers = [
    { coverLetter: 'Готов присоединиться к команде: 4 года в product-разработке, могу закрыть бэкенд и интеграции.', city: 'г. Самара', specialization: 'Специализация: Backend-разработка' },
    { coverLetter: 'Занимаюсь UX-исследованиями и интерфейсами, хочу прокачаться в продуктовом проекте с ментором.', city: 'г. Москва', specialization: 'Специализация: UX Дизайн' },
  ];

  let coverIdx = 0;
  for (const project of targets) {
    const applicants = users.filter((u) => u.id !== project.ownerId).slice(0, 2);
    for (const applicant of applicants) {
      const cover = covers[coverIdx % covers.length];
      coverIdx++;
      const exists = await db.projectApplication.findFirst({
        where: { projectId: project.id, userId: applicant.id },
        select: { id: true },
      });
      if (!exists) {
        await db.projectApplication.create({
          data: {
            projectId: project.id,
            userId: applicant.id,
            coverLetter: cover.coverLetter,
            city: cover.city,
            specialization: cover.specialization,
            status: 'new',
            isRead: false,
          },
        });
        counters.applications++;
      }
    }
  }
}

// ---------- 5. Лоты Биржи (§8) ----------
interface LotSeedSpec {
  title: string;
  budget: number | null;
  budgetNegotiable: boolean;
  duration: string;
  workFormat: 'remote' | 'onsite';
  region: string;
  requiredRole: string;
  userIndex: number;
  details: Record<string, string>;
}

const LOT_SPECS: LotSeedSpec[] = [
  {
    title: 'Разработка технического проекта АСУТП',
    budget: 9000000,
    budgetNegotiable: false,
    duration: '16 месяцев',
    workFormat: 'onsite',
    region: 'Москва',
    requiredRole: 'Разработка',
    userIndex: 1,
    details: {
      what_to_do:
        'Разработать технический проект автоматизированной системы управления технологическим процессом (АСУТП) производственной линии: обследование объекта, описание функций управления, алгоритмов блокировок, архитектуры контроллеров и SCADA, схемы сигналов и кабельных журналов.',
      essence:
        'Нужен полный комплект технической документации по ГОСТ 34: технорабочий проект, описание алгоритмов, спецификация оборудования и план пусконаладки. Система должна обеспечивать управление 12 технологическими узлами с резервированием контроллеров.',
      background:
        'Предприятие модернирует участок фасовки и упаковки; существующая система на базе устаревших контроллеров не поддерживается производителем. Запущена программа цифровой трансформации, АСУТП — первый этап.',
      result:
        'Согласованный и утверждённый технический проект АСУТП, готовый к стадии рабочего проектирования: комплект документации по ГОСТ 34.601, таблицы сигналов, спецификация ПЛК и SCADA, план миграции без остановки производства.',
      criteria:
        '1) Полнота разделов по ГОСТ 34.601; 2) прохождение внутренней экспертизы заказчика без критических замечаний; 3) резервирование: отказ одного контроллера не останавливает линию; 4) время реакции системы не более 100 мс.',
      workload:
        'Оценочная трудоёмкость — 16 месяцев с этапами: обследование (2 мес), эскизный и технический проект (8 мес), согласование и защита (4 мес), сопровождение опытной эксплуатации (2 мес).',
      interaction_format:
        'Работа на площадке заказчика в Москве 2-3 дня в неделю, остальное — удалённо. Еженедельные статус-встречи по средам, демонстрация разделов документации в конце каждого этапа.',
      requirements:
        'Опыт промышленной автоматизации от 5 лет, знание ГОСТ 34 серии и ПНАЭ, практический опыт с ПЛК Siemens S7/Овен и SCADA (WinCC, MasterSCADA), умение готовить документацию, прошедшую экспертизу. Желателен опыт в пищевой или фармацевтической отрасли.',
      tips:
        'Приложите к отклику пример технического проекта (обезличенный) и укажите роль в нём. Условия оплаты обсуждаем после технического интервью.',
    },
  },
  {
    title: 'Дизайн сайта для клиники',
    budget: null,
    budgetNegotiable: true,
    duration: '7 месяцев',
    workFormat: 'remote',
    region: 'Санкт-Петербург',
    requiredRole: 'Дизайнер',
    userIndex: 2,
    details: {
      what_to_do:
        'Спроектировать и оформить дизайн многостраничного сайта многопрофильной клиники: главная, услуги (30+ направлений), врачи, прайс, онлайн-запись, блог, контакты. Подготовить UI-kit и передать макеты в разработку.',
      essence:
        'Нужен дизайн, который повышает конверсию в запись на приём: понятная навигация по услугам, карточки врачей с расписанием, адаптив для мобильных (60% трафика — смартфоны).',
      background:
        'Клиника растёт, текущий сайт устарел морально и технически: низкая конверсия, жалобы пациентов на неудобную запись. Запускаем редизайн параллельно с открытием нового филиала.',
      result:
        'Готовые макеты всех ключевых страниц в Figma (desktop/tablet/mobile), UI-kit с компонентами и состояниями, гайдлайн по бренду для подрядчика вёрстки.',
      criteria:
        '1) Концепция принята с первого-второго iterations; 2) покрытие всех шаблонов страниц; 3) доступность по WCAG AA (контраст, размеры шрифтов); 4) скорость передачи макетов в вёрстку без потерь.',
      workload:
        'Длительность — 7 месяцев: исследование и CJM (1 мес), концепция (1 мес), дизайн страниц (4 мес), UI-kit и сопровождение вёрстки (1 мес). Ожидаемая загрузка — частичная, 15-20 часов в неделю.',
      interaction_format:
        'Полностью удалённо: задачи в трекере, созвоны дважды в неделю, демо через Figma. Обратная связь от врачей и маркетинга собираем асинхронно.',
      requirements:
        'Портфолио с медицинскими или сервисными проектами, уверенный Figma, понимание UX-исследований и веб-доступности, аккуратная работа с компонентами. Плюс — опыт с формами записи и календарями.',
      tips:
        'В отклике покажите 2-3 кейса, где дизайн повлиял на конверсию, и коротко опишите ваш процесс исследования перед дизайном.',
    },
  },
  {
    title: 'Конкурс на лучший рецепт пиццы',
    budget: 30000,
    budgetNegotiable: false,
    duration: '2 недели',
    workFormat: 'remote',
    region: 'Online',
    requiredRole: 'Автор',
    userIndex: 3,
    details: {
      what_to_do:
        'Разработать авторский рецепт пиццы для сезонного меню сети пекарен: описание ингредиентов с пропорциями, технологию приготовления и фудстайл-съёмку финального блюда (3-5 фото).',
      essence:
        'Ищем необычный, но воспроизводимый рецепт: начинка из доступных в РФ ингредиентов, время приготовления до 20 минут после расстойки, яркий вкус и презентабельный вид для соцсетей.',
      background:
        'Сеть пекарен запускает осеннее меню и хочет привлечь домашних кулинаров: победивший рецепт появится в меню с указанием автора и станет основой спецпредложения.',
      result:
        'Один авторский рецепт: технологическая карта в свободной форме, список ингредиентов с граммовками, 3-5 качественных фото готовой пиццы.',
      criteria:
        '1) Вкус и баланс (пробная готовка жюри); 2) воспроизводимость в домашней и профессиональной печи; 3) себестоимость порции не выше 350 ₽; 4) качество фотографий.',
      workload:
        'Две недели: 1 неделя на разработку и тесты рецепта, 1 неделя на финальную съёмку и оформление материалов. Легкая нагрузка, подходит как дополнительный проект.',
      interaction_format:
        'Полностью заочно: материалы принимаем в ответе на отклик/на почту, обратная связь в течение 3 дней, финалисты получают комментарии жюри.',
      requirements:
        'Опыт домашней или профессиональной кулинарии, умение готовить тесто и работать с печами (домашняя/каменная/конвекционная), базовые навыки предметной съёмки. Кулинарное образование не обязательно.',
      tips:
        'Расскажите в сопроводительном письме про 1-2 ваших фирменных блюда и приложите фото. Победителю — публикация рецепта в меню с указанием авторства и призовой фонд.',
    },
  },
];

const LOT_RESPONSE_COVERS = [
  'Более 8 лет проектирую АСУТП на пищевых производствах: от обследования до ПНР. Готов показать комплект документации по ГОСТ 34 из прошлого проекта.',
  'Работал ведущим инженером по автоматизации на двух модернизациях линий фасовки. Знаю специфику резервирования SCADA, могу начать с обследования уже на следующей неделе.',
];

async function seedLots(users: Array<{ id: string; name: string }>) {
  if (users.length === 0) return;
  const acceptUntil = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // +30 дней (§10)

  const createdLots: Array<{ id: string; title: string }> = [];

  for (const spec of LOT_SPECS) {
    const employer = users[spec.userIndex % users.length];
    // идемпотентность: (employerId, title) — естественный ключ лота в seed
    let lot = await db.lot.findFirst({
      where: { employerId: employer.id, title: spec.title },
    });
    if (!lot) {
      lot = await db.lot.create({
        data: {
          employerId: employer.id,
          title: spec.title,
          budget: spec.budget,
          budgetNegotiable: spec.budgetNegotiable,
          duration: spec.duration,
          acceptUntil,
          workFormat: spec.workFormat,
          requiredRole: spec.requiredRole,
          region: spec.region,
          detailsJson: JSON.stringify(spec.details),
          status: 'open',
        },
      });
      counters.lots++;
    }
    createdLots.push({ id: lot.id, title: lot.title });
  }

  // 2 отклика на первый лот от других юзеров (не заказчик)
  const firstLot = createdLots[0];
  const firstSpec = LOT_SPECS[0];
  const employerId = users[firstSpec.userIndex % users.length].id;
  const respondents = users.filter((u) => u.id !== employerId).slice(0, 2);

  for (let i = 0; i < respondents.length; i++) {
    const exists = await db.lotResponse.findFirst({
      where: { lotId: firstLot.id, userId: respondents[i].id },
      select: { id: true },
    });
    if (!exists) {
      await db.lotResponse.create({
        data: {
          lotId: firstLot.id,
          userId: respondents[i].id,
          coverLetter: LOT_RESPONSE_COVERS[i % LOT_RESPONSE_COVERS.length],
          roleApplied: firstSpec.requiredRole,
          status: 'new',
          isRead: false,
        },
      });
      counters.lotResponses++;
    }
  }

  // Синхронизация денормализованного responsesCount с фактическим числом откликов
  const actual = await db.lotResponse.count({ where: { lotId: firstLot.id } });
  await db.lot.update({ where: { id: firstLot.id }, data: { responsesCount: actual } });
}

// ---------- main ----------
async function main() {
  console.log('▶ Seed-обогащение модуля «Проекты» (ТЗ-ПР-4.9 §10)…');

  await seedTaxonomy();
  console.log(`  ✓ Таксономия: +${counters.taxonomy} новых записей (topics/regions/roles)`);

  await seedProjects();
  console.log(`  ✓ Проекты: обновлено ${counters.projectsUpdated} из 5, внешних участников +${counters.contributors}`);

  const users = await db.user.findMany({
    orderBy: { createdAt: 'asc' },
    take: 5,
    select: { id: true, name: true },
  });
  console.log(`  ✓ Пользователей для контента: ${users.length}`);

  await seedComments(users);
  console.log(`  ✓ Комментарии: +${counters.comments}, ответов (depth 1): +${counters.replies}`);

  await seedApplications(users);
  console.log(`  ✓ Заявки на участие: +${counters.applications}`);

  await seedLots(users);
  console.log(`  ✓ Лоты: +${counters.lots} (создано), откликов: +${counters.lotResponses}`);

  // Итоговые количества — для проверки идемпотентности между запусками
  const [tax, contrib, comm, app, lots, resp] = await Promise.all([
    db.taxonomyItem.count(),
    db.projectContributor.count(),
    db.projectComment.count(),
    db.projectApplication.count(),
    db.lot.count(),
    db.lotResponse.count(),
  ]);
  console.log('— Сводка (всего в БД) —');
  console.log(`  TaxonomyItem: ${tax} | ProjectContributor: ${contrib} | ProjectComment: ${comm}`);
  console.log(`  ProjectApplication: ${app} | Lot: ${lots} | LotResponse: ${resp}`);
  console.log('✅ Готово. Повторный запуск не создаёт дублей (upsert / findFirst-else-create).');
}

main()
  .catch((e) => {
    console.error('Seed failed:', e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
