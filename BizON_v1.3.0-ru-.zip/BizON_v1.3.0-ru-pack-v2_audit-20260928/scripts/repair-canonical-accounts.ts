// =============================================================================
// Ремонт/создание канон-аккаунтов владельца и QA (22-09-26, команда 29).
//
// Контекст: keyfile .bizon-encryption-key пересоздан песочницей 22-09 20:22 —
// все emailHash в БД стали невалидными (эон-проблема, 2-й случай; первый
// закрыт scripts/reset-demo-passwords.ts для 10 демо-аккаунтов @bizon.ru).
// Канон-аккаунты (owner@bizon.test, qa-01..05@bizon.test) восстанавливаются
// этим скриптом: идентичность (emailHash/emailEncrypted) — ТЕКУЩИМ ключом,
// пароль — PBKDF2-SHA256 600k (как AuthService.register).
//
// Идемпотентно: если пользователь с emailHash(email) уже есть — только
// проверка/ремонт пароля; иначе создаётся заново.
//
// ПАРОЛИ — ТОЛЬКО ИЗ .env (П4-В5, директива владельца: хардкод удалён из репо):
//   owner@bizon.test   ← OWNER_INITIAL_PASSWORD (пароль НЕ трогаем, если нет
//                        в .env — владелец им управляет, В2);
//   qa-01..05@bizon.test ← BIZON_QA_PASSWORDS (base64url JSON, ротатор —
//                        scripts/rotate-qa-passwords.ts);
//   test.private@bizon.demo ← BIZON_DEMO_PASSWORDS (base64url JSON,
//                        scripts/reset-demo-passwords.ts).
// Отсутствует переменная → аккаунт пропускается С ПРЕДУПРЕЖДЕНИЕМ (fail-closed:
// скрипт НИКОГДА не возвращает пароль из репо).
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { encrypt, hashEmail } from '../src/lib/security/crypto';

const db = new PrismaClient();

/** Читает base64url JSON {email: password} из переменной .env; null — нет/битое. */
function envPasswords(key: string): Record<string, string> | null {
  const raw = process.env[key]?.trim();
  if (!raw) return null;
  try {
    const b64 = raw.replace(/-/g, '+').replace(/_/g, '/');
    const bin = atob(b64 + '='.repeat((4 - (b64.length % 4)) % 4));
    return JSON.parse(bin) as Record<string, string>;
  } catch {
    return null;
  }
}

const OWNER_PASSWORD = process.env.OWNER_INITIAL_PASSWORD?.trim() || null;
const QA_PASSWORDS = envPasswords('BIZON_QA_PASSWORDS');
const DEMO_PASSWORDS = envPasswords('BIZON_DEMO_PASSWORDS');

if (!OWNER_PASSWORD) console.warn('⚠ OWNER_INITIAL_PASSWORD отсутствует — пароль владельца НЕ трогаем (В2).');
if (!QA_PASSWORDS) console.warn('⚠ BIZON_QA_PASSWORDS отсутствует — qa-01..05 пропущены (запусти scripts/rotate-qa-passwords.ts).');
if (!DEMO_PASSWORDS) console.warn('⚠ BIZON_DEMO_PASSWORDS отсутствует — test.private пропущен (запусти scripts/reset-demo-passwords.ts).');

const CANON: Array<{ email: string; password: string | null; name: string; roles: string }> = [
  { email: 'owner@bizon.test', password: OWNER_PASSWORD, name: 'Владелец BizON', roles: 'admin' },
  ...['01', '02', '03', '04', '05'].map((n) => ({
    email: `qa-${n}@bizon.test`,
    password: QA_PASSWORDS?.[`qa-${n}@bizon.test`] ?? null,
    name: `QA ${n}`,
    roles: '',
  })),
  { email: 'test.private@bizon.demo', password: DEMO_PASSWORDS?.['test.private@bizon.demo'] ?? null, name: 'Иван Тестов (частное лицо)', roles: '' },
];

async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 600_000, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const saltHex = Array.from(salt).map((b) => b.toString(16).padStart(2, '0')).join('');
  const hashHex = Array.from(new Uint8Array(derivedBits)).map((b) => b.toString(16).padStart(2, '0')).join('');
  return `pbkdf2$600000$${saltHex}$${hashHex}`;
}

async function verifyPasswordInline(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
  const iterations = Number(parts[1]);
  const salt = Uint8Array.from(parts[2].match(/.{2}/g)!.map((b) => parseInt(b, 16)));
  const expected = parts[3];
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const derivedBits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  const actual = Array.from(new Uint8Array(derivedBits)).map((b) => b.toString(16).padStart(2, '0')).join('');
  if (actual.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

let created = 0;
let repaired = 0;
let skipped = 0;

for (const acc of CANON) {
  const emailHash = hashEmail(acc.email);
  let user = await db.user.findFirst({ where: { emailHash, deletedAt: null } });

  if (user) {
    // Идентичность уже валидна — пароль трогаем ТОЛЬКО если он известен из .env.
    if (!acc.password) {
      console.log(`SKIP-PASSWORD: ${acc.email} (пароля нет в .env — не трогаем)`);
      continue;
    }
    if (!(await verifyPasswordInline(acc.password, user.passwordHash))) {
      await db.user.update({ where: { id: user.id }, data: { passwordHash: await hashPassword(acc.password) } });
      repaired++;
      console.log(`REPAIR-PASSWORD: ${acc.email}`);
    } else {
      console.log(`OK: ${acc.email} (пароль канона валиден)`);
    }
    continue;
  }

  // Фолбэк: пользователь существует под другим emailHash (эон) — ищем по имени,
  // чиним идентичность; иначе создаём нового.
  user = await db.user.findFirst({ where: { name: acc.name, deletedAt: null } });
  const identity = { emailHash, emailEncrypted: encrypt(acc.email) };
  // Пароль неизвестен → создаём/чиним с НЕВОССТАНОВИМЫМ паролем нельзя —
  // аккаунт пропускается честно (fail-closed): сначала ротатор кладёт пароль в .env.
  if (!acc.password) {
    console.warn(`SKIP: ${acc.email} — нет пароля в .env, создание/ремонт невозможен (запусти ротатор)`);
    skipped++;
    continue;
  }
  const passwordHash = await hashPassword(acc.password);

  if (user) {
    await db.user.update({ where: { id: user.id }, data: { ...identity, passwordHash, roles: acc.roles } });
    repaired++;
    console.log(`REPAIR-IDENTITY: ${acc.email} → существующий user ${user.id} (${acc.name})`);
  } else {
    await db.user.create({
      data: {
        name: acc.name,
        title: acc.roles === 'admin' ? 'Владелец платформы' : 'QA-аккаунт',
        ...identity,
        passwordHash,
        roles: acc.roles,
        accountType: 'individual',
        subscriptionTier: 'free',
        ipScore: 0,
        level: '1',
        emailVerified: true,
        acceptedTosAt: new Date(),
      },
    });
    created++;
    console.log(`CREATE: ${acc.email} (${acc.name})`);
  }
}

console.log(`\nИтого: создано ${created}, отремонтировано ${repaired}, пропущено (нет пароля в .env) ${skipped} из ${CANON.length}.`);
await db.$disconnect();
