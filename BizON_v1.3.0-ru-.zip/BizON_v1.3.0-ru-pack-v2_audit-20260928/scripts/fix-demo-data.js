// BizON — P0-4: Исправить несогласованность demo-пользователя
//
// Сценарий: demo user имеет ipScore > 50, но при этом 0 проектов / 0 навыков / 0 связей.
// Это несогласованное состояние: высокий IP-score ничем не подтверждён.
//
// Решение: СОЗДАТЬ реальные данные (4 проекта, 5 навыков, 8 связей),
// чтобы ipScore был обоснован. Альтернатива (снизить ipScore до 0) — отбрасывается,
// т.к. теряем ценного demo-пользователя.
//
// Запуск: node scripts/fix-demo-data.js
//
// Алгоритм:
//   1. Найти demo user по emailHash (поиск по demo@bizon.app, фолбэк на ivan@bizon.ru —
//      dev-режим авто-входа).
//   2. Подсчитать текущие projects/skills/connections.
//   3. Если ipScore > 50 И (projects=0 И skills=0 И connections=0) — СОЗДАТЬ данные.
//   4. Иначе — пропустить (состояние согласовано).
//
// НЕ трогает ядро (Trust Engine, Auth, PII encryption).

const { PrismaClient } = require('@prisma/client');
const crypto = require('crypto');

const db = new PrismaClient();

const ENCRYPTION_KEY_HEX = process.env.BIZON_ENCRYPTION_KEY;
if (!ENCRYPTION_KEY_HEX) {
  console.error('❌ BIZON_ENCRYPTION_KEY не задан в .env');
  console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
  process.exit(1);
}

function hashEmail(email) {
  return crypto.createHmac('sha256', ENCRYPTION_KEY_HEX).update(email.toLowerCase()).digest('hex');
}

// Имена skills для создания (если не существуют — создаются)
const SKILL_NAMES = ['Python', 'TypeScript', 'React', 'System Design', 'Machine Learning'];

// Шаблоны 4 проектов (startedAt/completedAt — реальные поля из schema)
const PROJECT_TEMPLATES = [
  {
    title: 'Demo: AI Career Path',
    description: 'Demo-проект: сервис карьерных траекторий на базе LLM. Анализ профиля, рекомендации, симуляция развития карьеры.',
    tags: 'Next.js,LLM,Product',
    status: 'active',
    rating: 4.6,
  },
  {
    title: 'Demo: TrustGraph SDK',
    description: 'Demo-проект: open-source библиотека для построения графов доверия. BFS, weighted edges, community detection.',
    tags: 'TypeScript,Graph,Algorithm',
    status: 'completed',
    rating: 4.5,
  },
  {
    title: 'Demo: GreenAI Platform',
    description: 'Demo-проект: AI-платформа мониторинга углеродного следа. Сбор данных с IoT-датчиков, ML-прогноз, дашборды.',
    tags: 'Python,ML,Data Engineering',
    status: 'completed',
    rating: 4.8,
  },
  {
    title: 'Demo: MentorHub',
    description: 'Demo-проект: платформа менторства с подбором пар через AI. Включает retro-инструменты и оценку командной синергии.',
    tags: 'React,Node.js,Mentorship',
    status: 'recruiting',
    rating: 0,
  },
];

async function findDemoUser() {
  // Пробуем demo@bizon.app (canonical demo email из ТЗ)
  const candidates = ['demo@bizon.app', 'ivan@bizon.ru'];
  for (const email of candidates) {
    const hash = hashEmail(email);
    const user = await db.user.findUnique({ where: { emailHash: hash } });
    if (user) {
      console.log(`  ✓ Demo user найден по email ${email}: id=${user.id} name="${user.name}" ipScore=${user.ipScore}`);
      return user;
    }
  }
  return null;
}

async function getStats(userId) {
  const [projectsOwned, projectsMember, skills, connections, posts] = await Promise.all([
    db.project.count({ where: { ownerId: userId } }),
    db.projectMember.count({ where: { userId } }),
    db.userSkill.count({ where: { userId } }),
    db.connection.count({
      where: { OR: [{ fromUserId: userId }, { toUserId: userId }] },
    }),
    db.post.count({ where: { authorId: userId } }),
  ]);
  return { projectsOwned, projectsMember, skills, connections, posts };
}

async function createRealData(demoUser, otherUsers) {
  console.log('\n  → Создаём реальные данные для demo user...');

  // 1. Создаём 4 проекта — demo user владелец, первые 3 других юзера — участники
  const createdProjects = [];
  for (const tpl of PROJECT_TEMPLATES) {
    const startedAt = new Date(Date.now() - Math.floor(Math.random() * 90) * 24 * 60 * 60 * 1000);
    const completedAt = tpl.status === 'completed'
      ? new Date(startedAt.getTime() + 30 * 24 * 60 * 60 * 1000)
      : null;

    const project = await db.project.create({
      data: {
        title: tpl.title,
        description: tpl.description,
        ownerId: demoUser.id,
        status: tpl.status,
        rating: tpl.rating,
        tags: tpl.tags,
        startedAt,
        completedAt,
      },
    });
    createdProjects.push(project);
    console.log(`    ✓ Project: "${tpl.title}" (status=${tpl.status})`);

    // Demo user — owner-участник
    await db.projectMember.create({
      data: { projectId: project.id, userId: demoUser.id, role: 'owner' },
    }).catch(() => {});

    // 2 других пользователя — участники
    for (let i = 0; i < Math.min(2, otherUsers.length); i++) {
      const other = otherUsers[i];
      await db.projectMember.create({
        data: { projectId: project.id, userId: other.id, role: 'member' },
      }).catch(() => {}); // уникальность [projectId, userId]
    }
  }

  // 2. Создаём 5 навыков (если skill не существует — создаём; связываем с demo user)
  for (const skillName of SKILL_NAMES) {
    const skill = await db.skill.upsert({
      where: { name: skillName },
      update: {},
      create: { name: skillName, category: 'IT' },
    });

    await db.userSkill.upsert({
      where: { userId_skillId: { userId: demoUser.id, skillId: skill.id } },
      update: {},
      create: {
        userId: demoUser.id,
        skillId: skill.id,
        level: 1 + Math.floor(Math.random() * 5),
        confirmationsCount: Math.floor(Math.random() * 5),
        nftEligible: false,
        verificationLevel: 'claimed',
      },
    });
    console.log(`    ✓ Skill: "${skillName}"`);
  }

  // 3. Создаём 8 связей (accepted) с другими пользователями
  let connectionsCreated = 0;
  for (const other of otherUsers) {
    if (connectionsCreated >= 8) break;

    // Проверяем, нет ли уже связи (в любом направлении)
    const existing = await db.connection.findFirst({
      where: {
        OR: [
          { fromUserId: demoUser.id, toUserId: other.id },
          { fromUserId: other.id, toUserId: demoUser.id },
        ],
      },
      select: { id: true },
    });
    if (existing) continue;

    await db.connection.create({
      data: {
        fromUserId: demoUser.id,
        toUserId: other.id,
        status: 'accepted',
        note: 'Demo connection (auto-generated by fix-demo-data.js)',
      },
    });
    connectionsCreated++;
  }
  console.log(`    ✓ ${connectionsCreated} connections (accepted)`);

  return { projects: createdProjects.length, skills: SKILL_NAMES.length, connections: connectionsCreated };
}

async function main() {
  console.log('=== P0-4: fix-demo-data.js — проверка согласованности demo user ===\n');

  const demoUser = await findDemoUser();
  if (!demoUser) {
    console.log('\n  ⚠️  Demo user не найден (пробовали: demo@bizon.app, ivan@bizon.ru).');
    console.log('     Скрипт завершён без изменений.');
    await db.$disconnect();
    return;
  }

  const before = await getStats(demoUser.id);
  console.log(`  До:  ipScore=${demoUser.ipScore} level=${demoUser.level}`);
  console.log(`       ownedProjects=${before.projectsOwned} memberProjects=${before.projectsMember}`);
  console.log(`       skills=${before.skills} connections=${before.connections} posts=${before.posts}`);

  // Условие: ipScore > 50 И 0 проектов/навыков/связей
  const isInconsistent =
    demoUser.ipScore > 50 &&
    before.projectsOwned === 0 &&
    before.projectsMember === 0 &&
    before.skills === 0 &&
    before.connections === 0;

  if (!isInconsistent) {
    console.log('\n  ✅ Состояние demo user согласовано (нет паттерна "высокий ipScore при 0 данных").');
    console.log('     Ничего не делаем.');
    await db.$disconnect();
    return;
  }

  console.log('\n  ⚠️  Обнаружена несогласованность: ipScore > 50 но нет проектов/навыков/связей.');
  console.log('     Создаём реальные данные (4 проекта, 5 навыков, 8 связей)...');

  // Находим других пользователей для участников и связей
  const otherUsers = await db.user.findMany({
    where: { id: { not: demoUser.id } },
    select: { id: true, name: true },
    take: 20,
    orderBy: { ipScore: 'desc' },
  });

  if (otherUsers.length < 8) {
    console.log(`  ⚠️  В БД только ${otherUsers.length} других пользователей — нужно минимум 8 для связей.`);
    console.log('     Создаём что сможем.');
  }

  const result = await createRealData(demoUser, otherUsers);

  const after = await getStats(demoUser.id);
  console.log(`\n  После: ownedProjects=${after.projectsOwned} memberProjects=${after.projectsMember}`);
  console.log(`         skills=${after.skills} connections=${after.connections}`);

  console.log('\n  ✅ Demo user данные созданы:');
  console.log(`     • ${result.projects} проектов (демо user — владелец)`);
  console.log(`     • ${result.skills} навыков`);
  console.log(`     • ${result.connections} связей (accepted)`);
  console.log(`     • ipScore=${demoUser.ipScore} теперь обоснован реальными данными`);

  console.log('\n=== Готово ===');
  await db.$disconnect();
}

main().catch(async (e) => {
  console.error('❌ Ошибка:', e);
  await db.$disconnect();
  process.exit(1);
});
