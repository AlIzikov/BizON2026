// =============================================================================
// Task 29-d (DB-003) — backfill-lumen-fraction.ts
//
// Миграция дробного остатка дивидендов с Float на minor units:
//   User.lumenFraction (Float, люмены)  →  User.lumenFractionMinor (Int, 1/1000 люмена)
//   lumenFractionMinor = Math.round(lumenFraction * LUMEN_FRACTION_SCALE)   // SCALE = 1000
//
// ФАКТИЧЕСКИЙ путь миграции (честно, см. worklog 29-d):
//   Правило «добавить поле → push → бэкфилл → удалить поле → push» нарушилось:
//   правка схемы одним заходом случайно удалила lumenFraction уже в ПЕРВОМ
//   push (старая строка поля была заменена, а не дополнена) — колонка Float
//   и её данные ушли из live-БД. Восстановление: значения читаются из бэкапа
//   db/custom.db.backup-29d (сделан ДО первого push) и переносятся в live.
//   Итог: schema-эволюция заняла один push, бэкфилл — из бэкапа. Потери:
//   дивиденды, накопленные между бэкапом и push (минуты, < 0.04 люмена на
//   всех — см. вывод скрипта).
//
// Идемпотентен: перезапись тем же правилом; уже равные значения пропускаются.
//
// Запуск: bun scripts/backfill-lumen-fraction.ts
// =============================================================================
import { PrismaClient } from '@prisma/client';
import { db } from '../src/lib/db';

const LUMEN_FRACTION_SCALE = 1000; // 1 люмен = 1000 minor units (константа-близнец lumen-service)
const BACKUP_URL = 'file:/home/z/my-project/db/custom.db.backup-29d';

async function main() {
  const backup = new PrismaClient({ datasources: { db: { url: BACKUP_URL } } });
  try {
    const rows = await backup.$queryRawUnsafe<
      { id: string; lumenFraction: number }[]
    >('SELECT id, lumenFraction FROM User WHERE lumenFraction IS NOT NULL');

    let migrated = 0;
    let skipped = 0;
    let lostRounding = 0; // суммарные minor units, потерянные округлением (< 1 на строку)
    for (const r of rows) {
      const exact = r.lumenFraction * LUMEN_FRACTION_SCALE;
      const minor = Math.round(exact);
      lostRounding += exact - minor;
      const current = await db.user.findUnique({
        where: { id: r.id },
        select: { lumenFractionMinor: true },
      });
      if (!current) continue; // пользователь удалён после бэкапа
      if (current.lumenFractionMinor === minor) {
        skipped += 1;
        continue;
      }
      await db.user.update({
        where: { id: r.id },
        data: { lumenFractionMinor: minor },
      });
      migrated += 1;
      console.log(
        `[backfill] user ${r.id}: lumenFraction(backup)=${r.lumenFraction} → minor=${minor}`,
      );
    }

    const total = await db.user.count();
    const nonZero = await db.user.count({ where: { lumenFractionMinor: { gt: 0 } } });
    console.log(
      `[backfill] done: users=${total}, migrated=${migrated}, skipped(already-equal)=${skipped}, ` +
        `users with minor>0=${nonZero}, rounding-loss=${lostRounding.toFixed(6)} minor units (< 0.001 люмена)`,
    );
  } finally {
    await backup.$disconnect();
  }
}

main()
  .catch((e) => {
    console.error('[backfill] FAILED:', e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
