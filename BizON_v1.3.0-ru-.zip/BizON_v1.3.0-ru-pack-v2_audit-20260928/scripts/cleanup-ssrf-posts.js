// BizON — P0-5: Очистка постов с SSRF-паттернами
//
// Удаляет посты, содержащие тестовые SSRF-паттерны:
//   - 169.254.169.254  (AWS/GCP metadata endpoint)
//   - 10.0.0.5         (private IP)
//   - 127.0.0.1        (loopback)
//   - localhost        (loopback hostname)
//   - "Private IP test"
//   - "SSRF test"
//
// Проверяются поля: content, imageUrl, ctaUrl, linkPreview.
//
// Запуск: node scripts/cleanup-ssrf-posts.js
//
// НЕ трогает ядро (Trust Engine, Auth, PII encryption).

const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();

const SSRF_PATTERNS = [
  '169.254.169.254',
  '10.0.0.5',
  '127.0.0.1',
  'localhost',
  'Private IP test',
  'SSRF test',
];

function isSSRFPost(post) {
  const haystack = [
    post.content,
    post.imageUrl,
    post.ctaUrl,
    post.linkPreview,
  ]
    .filter(Boolean)
    .join(' \n ')
    .toLowerCase();

  return SSRF_PATTERNS.some((p) => haystack.includes(p.toLowerCase()));
}

async function main() {
  console.log('=== P0-5: cleanup-ssrf-posts.js — удаление SSRF-постов ===\n');
  console.log(`  Паттерны: ${SSRF_PATTERNS.join(', ')}\n`);

  const allPosts = await db.post.findMany({
    select: { id: true, content: true, imageUrl: true, ctaUrl: true, linkPreview: true, createdAt: true, authorId: true },
  });

  console.log(`  Всего постов в БД: ${allPosts.length}`);

  const matched = allPosts.filter(isSSRFPost);
  console.log(`  Найдено SSRF-постов: ${matched.length}`);

  if (matched.length === 0) {
    console.log('\n  ✅ Нечего удалять. База чиста от SSRF-паттернов.');
    await db.$disconnect();
    return;
  }

  // Логируем найденные посты (превью контента)
  for (const p of matched) {
    const preview = (p.content || '').slice(0, 100).replace(/\s+/g, ' ');
    console.log(`    • ${p.id} | "${preview}"`);
  }

  // Удаляем каскадно: лайки, комменты, saved-записи удалятся автоматически
  // (по схеме @relation onDelete: Cascade у PostLike, PostComment, SavedPost).
  const ids = matched.map((p) => p.id);
  const result = await db.post.deleteMany({ where: { id: { in: ids } } });
  console.log(`\n  ✅ Удалено постов: ${result.count}`);

  // Дополнительно: проверим, что нет «осиротевших» saved-записей и лайков
  // (на случай, если каскад не сработал — для SQLite-миграций иногда бывает)
  const orphanedLikes = await db.postLike.deleteMany({
    where: { postId: { in: ids } },
  }).catch(() => ({ count: 0 }));
  const orphanedComments = await db.postComment.deleteMany({
    where: { postId: { in: ids } },
  }).catch(() => ({ count: 0 }));
  const orphanedSaved = await db.savedPost.deleteMany({
    where: { postId: { in: ids } },
  }).catch(() => ({ count: 0 }));

  if (orphanedLikes.count || orphanedComments.count || orphanedSaved.count) {
    console.log(`  ✅ Дочитаны каскадные осиротевшие записи:`);
    if (orphanedLikes.count) console.log(`    • PostLike: ${orphanedLikes.count}`);
    if (orphanedComments.count) console.log(`    • PostComment: ${orphanedComments.count}`);
    if (orphanedSaved.count) console.log(`    • SavedPost: ${orphanedSaved.count}`);
  }

  // Финальная проверка
  const remaining = await db.post.findMany({
    select: { id: true, content: true, imageUrl: true, ctaUrl: true, linkPreview: true },
  });
  const stillThere = remaining.filter(isSSRFPost);
  if (stillThere.length > 0) {
    console.error(`\n  ⚠️  Внимание: ${stillThere.length} SSRF-постов осталось после очистки!`);
    process.exit(1);
  }

  console.log('\n=== Готово ===');
  await db.$disconnect();
}

main().catch(async (e) => {
  console.error('❌ Ошибка:', e);
  await db.$disconnect();
  process.exit(1);
});
