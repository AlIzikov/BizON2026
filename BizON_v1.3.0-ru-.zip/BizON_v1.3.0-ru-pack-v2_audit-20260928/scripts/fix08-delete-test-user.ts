// FIX-08 — ONE-OFF: удалить тестового пользователя, созданного при верификации
// email-верификации + люмен-гейта. Связанные записи (Session, LumenTransaction,
// VerificationToken, ReputationEvent/Snapshot, ActionEvent, Notification и т.д.)
// удаляются каскадом (onDelete: Cascade в схеме).
//
// Запуск: bun scripts/fix08-delete-test-user.ts <userId|email>
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

async function main() {
  const key = process.argv[2];
  if (!key) throw new Error('Usage: bun scripts/fix08-delete-test-user.ts <userId|email>');

  const user = await db.user.findFirst({
    where: key.includes('@') ? { email: key.toLowerCase() } : { id: key },
    select: { id: true, email: true, name: true, emailVerified: true, acceptedTosAt: true },
  });
  if (!user) {
    console.log(`[fix08-delete-test-user] user not found: ${key}`);
    return;
  }

  const counts = await db.$transaction([
    db.session.count({ where: { userId: user.id } }),
    db.lumenTransaction.count({ where: { userId: user.id } }),
    db.verificationToken.count({ where: { userId: user.id } }),
  ]);

  await db.user.delete({ where: { id: user.id } });

  const orphanTokens = await db.verificationToken.count({ where: { userId: user.id } });

  console.log(
    `[fix08-delete-test-user] deleted user ${user.id} (${user.email}), ` +
      `cascade removed: sessions=${counts[0]}, lumenTxns=${counts[1]}, verifyTokens=${counts[2]}; ` +
      `orphan verifyTokens after delete: ${orphanTokens}`,
  );
}

main()
  .catch((e) => {
    console.error('[fix08-delete-test-user] failed:', e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
