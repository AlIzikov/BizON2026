// BizON v6 — Cron: суточная генерация AI-инсайтов (CoachInsight)
// Task 9-a, B14 — doc_agents (стр. 34 «Шаг 1. Сбор данных (Крон/Событие)»,
// стр. 37 «АЛГОРИТМ ГЕНЕРАЦИИ ГИПОТЕЗ (Cron-задача)»):
//   «Ответственный: Алгоритм (Cron-задача, запускаемая раз в сутки)».
//
// В отличие от scripts/cron-coach.js (вопрос дня, пишет напрямую в БД через
// PrismaClient), здесь логика генерации не дублируется, а вызывается ЧЕРЕЗ API:
//   POST {BIZON_BASE_URL}/api/cron/insights  c заголовком x-cron-secret
// Весь детерминированный алгоритм discoverHiddenPotential (эвристики,
// лимиты 3/сутки, дедуп 7 дней, карантин) живёт на сервере в одном экземпляре.
//
// Запуск (node 18+ — глобальный fetch):
//   BIZON_CRON_SECRET=... node scripts/cron-insights.js
//
// Cron (ежедневно в 05:10 по серверному времени, до cron-coach в 08:00):
//   crontab -e:
//     10 5 * * *  cd /home/z/my-project && BIZON_CRON_SECRET=... /usr/bin/node scripts/cron-insights.js >> /var/log/bizon-cron.log 2>&1
//
//   pm2 (альтернатива):
//     { name: 'bizon-cron-insights', script: 'scripts/cron-insights.js', cron_restart: '10 5 * * *', autorestart: false, env: { BIZON_CRON_SECRET: '...' } }
//
// Переменные окружения:
//   BIZON_CRON_SECRET — секрет совпадает с process.env.BIZON_CRON_SECRET сервера
//                       (сгенерировать: python3 -c "import secrets; print(secrets.token_hex(32))")
//   BIZON_BASE_URL    — базовый URL сервера (по умолчанию http://127.0.0.1:3000)
//
// Идемпотентность: повторный запуск в тот же день ничего не создаёт
// (на сервере: дедуп по CoachInsight.createdAt >= начала UTC-суток +
// суточный лимит 3/сутки внутри discoverHiddenPotential).
//
// Внешние планировщики (systemd timers, celery и т.п.) НЕ требуются —
// достаточно crontab/pm2, как у соседних cron-скриптов.

const BASE_URL = (process.env.BIZON_BASE_URL || 'http://127.0.0.1:3000').replace(/\/+$/, '');
const SECRET = process.env.BIZON_CRON_SECRET;

async function main() {
  console.log('=== BizON v6 — Cron: суточная генерация AI-инсайтов (coach insights) ===');
  console.log(`Время: ${new Date().toISOString()} | Цель: POST ${BASE_URL}/api/cron/insights`);

  if (!SECRET) {
    console.error('❌ BIZON_CRON_SECRET не задан в окружении.');
    console.error('   Сгенерируйте: python3 -c "import secrets; print(secrets.token_hex(32))"');
    console.error('   Задайте тот же секрет на сервере Next.js (env BIZON_CRON_SECRET).');
    console.error('   Запуск: BIZON_CRON_SECRET=... node scripts/cron-insights.js');
    process.exit(1);
  }

  let res;
  try {
    res = await fetch(`${BASE_URL}/api/cron/insights`, {
      method: 'POST',
      headers: {
        'x-cron-secret': SECRET,
        'content-type': 'application/json',
      },
      body: JSON.stringify({}),
    });
  } catch (e) {
    console.error(`❌ Сервер недоступен (${BASE_URL}): ${e.message}`);
    console.error('   Убедитесь, что Next.js сервер запущен и BIZON_BASE_URL указан верно.');
    process.exit(1);
  }

  const text = await res.text();
  let payload = null;
  try {
    payload = JSON.parse(text);
  } catch {
    // не-JSON ответ (например, HTML-страница ошибки) — покажем как есть
  }

  if (!res.ok) {
    console.error(`❌ HTTP ${res.status}: ${payload && payload.error ? payload.error : text.slice(0, 300)}`);
    process.exit(1);
  }

  console.log('✅ Ответ сервера:');
  console.log(`   обработано пользователей: ${payload.processed}`);
  console.log(`   пропущено (уже есть инсайты за сегодня): ${payload.skipped}`);
  console.log(`   создано инсайтов: ${payload.created}`);
  console.log(`   ошибок: ${payload.failed}`);
  console.log(`   окно активности: ${payload.activeDays} дн. | лимит прогона: ${payload.maxUsersPerRun} юзеров`);
  console.log('\n✅ cron-insights complete.');
}

main().catch((e) => {
  console.error('❌ cron-insights failed:', e);
  process.exit(1);
});
