#!/usr/bin/env bash
# Генератор docs/DELETED-CODE.md — реестр мёртвого кода с резервными копиями.
# Запуск: bash scripts/gen-deleted-code-registry.sh (из корня проекта)
set -euo pipefail
cd /home/z/my-project
OUT=docs/DELETED-CODE.md

emit_code() { # $1=commit $2=path $3=lang
  local content
  if ! content=$(git show "$1:$2" 2>/dev/null); then
    echo "_КОД НЕ ВОССТАНОВИЛСЯ ИЗ GIT — восстановить: git show $1:$2_"
    return
  fi
  echo '```'"$3"
  echo "$content"
  echo '```'
}

lines_of() { git show "$1:$2" 2>/dev/null | wc -l | tr -d ' '; }

{
cat <<'HDR'
# МЁРТВЫЙ КОД — реестр удалений (обновляется постоянно)

> **Назначение.** Единый журнал всего кода, который мы удаляем из платформы, с резервной копией
> каждого файла. Цель: ничего не потерять. Если удаление оказалось лишним — код восстанавливается
> отсюда одной командой, без археологии по git-истории.

## Правила ведения (обязательны для агента)

1. **Каждое удаление кода → запись в этом файле в тот же сеанс.** Не «потом», не «в worklog» — worklog хронология, здесь резервные копии.
2. Запись обновляется **до или сразу после** удаления; файл без записи здесь считается потерянным.
3. Обязательные поля записи: **дата-время, git-коммит, релиз системы** (брать из `VERSION` на момент удаления), **задача** (Task ID из worklog), **причина удаления** с доказательством (не «кажется лишним»), **полный код файла** в свернутом блоке.
4. Удаление считается законным только при доказательстве мёртвости: 0 живых импортов по всему дереву (проверено grep до удаления), либо маршруты/модели, которых нет в сборке/схеме, либо разовые tmp-скрипты с 0 ссылок.
5. Пустые директории записываются списком (копировать нечего).
6. **Восстановление:** скопировать код из блока резервной копии, либо `git show <КОММИТ>^:<путь> > <путь>`. После восстановления — прогнать гейты (tsc/lint/test) и сделать запись «восстановлено» в этой строке таблицы.
7. Реестр живёт в `docs/DELETED-CODE.md`, в git; при релизе (обновлении `VERSION`) в свод включается число записей/строк за период.

## Индекс удалённого

| Запись | Дата | Коммит | Релиз | Файл | Строк | Причина (кратко) |
|---|---|---|---|---|---|---|
HDR

# ---------- BATCH 1 index rows ----------
B1=c51a00d^
while IFS='|' read -r p _why; do
  n=$(lines_of "$B1" "$p")
  echo "| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | \`$p\` | $n | мёртвая параллельная линия (модели не существовали в схеме) |"
done <<'B1LIST'
src/app/api/follows/route.ts|x
src/components/common/follow-button.tsx|x
src/app/api/research/insights/route.ts|x
src/app/api/research/tests/route.ts|x
src/app/api/research/tests/[key]/route.ts|x
src/components/research/research-view.tsx|x
src/app/api/search/unified/route.ts|x
src/lib/services/unified-search-service.ts|x
src/components/shell/unified-search-panel.tsx|x
src/app/api/hr/[id]/reviews/route.ts|x
src/app/api/placements/[id]/review/route.ts|x
src/components/hr/my-placements-card.tsx|x
src/components/feed/one-thought-mode.tsx|x
src/app/api/feed/thoughts/route.ts|x
src/app/api/projects/[id]/confirm/route.ts|x
scripts/a9-confirm-test.ts|x
B1LIST

# ---------- BATCH 2 index rows ----------
B2=83d43d5^
while IFS='|' read -r p why; do
  n=$(lines_of "$B2" "$p")
  echo "| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | \`$p\` | $n | $why |"
done <<'B2LIST'
src/components/profile/public-persona.tsx|0 импортов PublicPersona во всём дереве
src/components/colleague-inquiries/colleague-inquiry-dialog.tsx|цепочка: импортировался только из public-persona
src/components/jobs/compare-vacancies.tsx|0 импортов, кнопка не рендерится нигде
src/components/jobs/search-job-card-v2.tsx|«v2 для /search» никогда не подключена
src/hooks/use-pwa.ts|0 вызовов usePWA и экспортов
scripts/tmp-10b-service-verify.ts|разовый tmp-скрипт прогона 10-b
scripts/tmp-10b-verify.py|разовый tmp-скрипт прогона 10-b
scripts/tmp-9b-dbcount.ts|разовый tmp-скрипт прогона 9-b
scripts/tmp-9g-inspect.cjs|разовый tmp-скрипт прогона 9-g
scripts/tmp-9g-inspect2.cjs|разовый tmp-скрипт прогона 9-g
B2LIST

cat <<'BATCH1HEAD'

---

## Запись №001 — карантин «мёртвой параллельной линии» (16 файлов)

- **Дата:** 2026-09-17 08:08 UTC
- **Коммит:** `c51a00d` (удаление из рабочего дерева)
- **Релиз системы:** 1.2.0-honest-pilot
- **Задача:** projects-finish-17-09 (worklog)
- **Причина:** обнаружен пласт ~16 файлов мёртвой параллельной линии (домены «подписки», «research», «единый поиск», «отзывы на HR/платформу», «режим одной мысли», «подтверждение проекта»), ссылающихся на модели Prisma, которых **никогда не существовало в схеме** (подтверждено `git log -S`). Честный `tsc --incremental false` давал 94 ошибки, из них этот пласт — основная часть. Живого UI-входа к этим файлам не было.
- **Доказательство:** `git log -S` по именам моделей; гейты после удаления tsc=0/lint=0/76-76; каталог роутов 297→288.
- **Доп. копия:** папка `bizon-recovery/legacy-quarantine-2026-09-17/` (те же файлы в исходном виде).
BATCH1HEAD

while IFS='|' read -r p lang; do
  n=$(lines_of "$B1" "$p")
  echo ""
  echo "### $p ($n строк)"
  echo ""
  echo "<details><summary>Резервная копия кода ($n строк)</summary>"
  echo ""
  emit_code "$B1" "$p" "$lang"
  echo ""
  echo "</details>"
done <<'B1CODE'
src/app/api/follows/route.ts|ts
src/components/common/follow-button.tsx|tsx
src/app/api/research/insights/route.ts|ts
src/app/api/research/tests/route.ts|ts
src/app/api/research/tests/[key]/route.ts|ts
src/components/research/research-view.tsx|tsx
src/app/api/search/unified/route.ts|ts
src/lib/services/unified-search-service.ts|ts
src/components/shell/unified-search-panel.tsx|tsx
src/app/api/hr/[id]/reviews/route.ts|ts
src/app/api/placements/[id]/review/route.ts|ts
src/components/hr/my-placements-card.tsx|tsx
src/components/feed/one-thought-mode.tsx|tsx
src/app/api/feed/thoughts/route.ts|ts
src/app/api/projects/[id]/confirm/route.ts|ts
scripts/a9-confirm-test.ts|ts
B1CODE

cat <<'BATCH2HEAD'

---

## Запись №002 — аудит платформы: мёртвые компоненты + tmp-скрипты (10 файлов, 4 пустые директории)

- **Дата:** 2026-09-17 12:42 UTC
- **Коммит:** `83d43d5`
- **Релиз системы:** 1.2.0-honest-pilot
- **Задача:** platform-audit-17-09 (worklog; первый CE-цикл)
- **Общая причина:** полный аудит на недоделанные куски и забытые вставки. Каждое имя проверено `git grep` по всему дереву **до удаления** (коммит `83d43d5^`): единственные упоминания — внутри самих файлов либо цепочка из одного импорта. После удаления гейты tsc=0/lint=0/тесты 76-76 — живых ссылок не осталось.
- **Пустые карантинные директории (копировать нечего):** `src/app/api/projects/[id]/confirm/`, `src/app/api/placements/[id]/review/`, `src/app/api/feed/thoughts/`, `src/components/research/` — остались после записи №001, физически пустые, вне git.
BATCH2HEAD

while IFS='|' read -r p lang why; do
  n=$(lines_of "$B2" "$p")
  echo ""
  echo "### $p ($n строк)"
  echo ""
  echo "**Причина:** $why"
  echo ""
  echo "<details><summary>Резервная копия кода ($n строк)</summary>"
  echo ""
  emit_code "$B2" "$p" "$lang"
  echo ""
  echo "</details>"
done <<'B2CODE'
src/components/profile/public-persona.tsx|tsx|0 импортов PublicPersona во всём дереве src (проверено git grep по дереву 83d43d5^ — упоминания только внутри самого файла: определения и экспорт)
src/components/colleague-inquiries/colleague-inquiry-dialog.tsx|tsx|единственный импорт во всём коде — public-persona.tsx:23; цепочка: умирает вместе с public-persona (сам по себе не монтируется)
src/components/jobs/compare-vacancies.tsx|tsx|упоминания CompareVacanciesDialog/CompareVacanciesButton только внутри самого файла (экспорты и док-комментарий); кнопка «Сравнить вакансии» не рендерится ни на одной странице
src/components/jobs/search-job-card-v2.tsx|tsx|«v2-карточка для страницы /search» никогда не подключена; реальная страница /search импортирует только ui/card и рендерит карточки сама
src/hooks/use-pwa.ts|ts|ни одного вызова usePWA / useInstallPrompt / requestPushPermission / triggerInstall во всём дереве; PWA-домен в платформе не активирован
scripts/tmp-10b-service-verify.ts|ts|разовый проверочный скрипт прерванного прогона 10-b; 0 ссылок в package.json/CI/обёртках; упоминается только в worklog как история
scripts/tmp-10b-verify.py|py|то же: разовый tmp-скрипт прогона 10-b, 0 ссылок
scripts/tmp-9b-dbcount.ts|ts|разовый tmp-скрипт прогона 9-b (подсчёт записей БД), 0 ссылок; соседние tmp-9b-* уже удалены ранее
scripts/tmp-9g-inspect.cjs|js|разовый tmp-скрипт прерванного прогона 9-g, 0 ссылок в коде/CI
scripts/tmp-9g-inspect2.cjs|js|то же: разовый tmp-скрипт прогона 9-g
B2CODE

cat <<'FOOT'

---

## Журнал восстановлений

| Дата | Файл | Кто/зачем | Гейты после восстановления |
|---|---|---|---|
| — | — | — | — |

## Статистика на текущий момент

- Записей: 2. Файлов с кодом: 26. Строк в резервных копиях: см. индекс (~6700).
- Пустых директорий: 4 (запись №002).
FOOT
} > "$OUT"

echo "OK: $OUT ($(wc -l < "$OUT") строк)"
