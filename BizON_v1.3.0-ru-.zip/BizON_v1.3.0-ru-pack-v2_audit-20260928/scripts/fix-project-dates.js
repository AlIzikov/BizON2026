// BizON — P1-b: DataQuality Checker для дат проектов
//
// Проблема: в БД могут существовать проекты, у которых startedAt > completedAt
// (например, из-за ручного ввода, миграций или seed-скриптов с багом).
// Это нарушает инвариант «проект не может быть завершён до того, как начался».
//
// Решение: проходим по всем проектам, у которых completedAt IS NOT NULL,
// и если startedAt > completedAt — меняем местами.
//
// Использует реальные поля из Prisma-схемы: startedAt / completedAt
// (НЕ startDate / endDate — таких полей в схеме нет).
//
// Запуск: node scripts/fix-project-dates.js
// (Prisma подхватывает DATABASE_URL из .env автоматически)

const { PrismaClient } = require('@prisma/client');

const db = new PrismaClient();

async function main() {
  console.log('=== P1-b: fix-project-dates.js — проверка startedAt/completedAt ===\n');

  // Подсчёт общего числа проектов и числа проектов с completedAt
  const [total, completedTotal] = await Promise.all([
    db.project.count(),
    db.project.count({ where: { completedAt: { not: null } } }),
  ]);
  console.log(`  Всего проектов: ${total}`);
  console.log(`  С completedAt (не null): ${completedTotal}`);

  if (completedTotal === 0) {
    console.log('\n  ✅ Нет проектов с completedAt — проверка не требуется.');
    await db.$disconnect();
    return;
  }

  // Загружаем все проекты с completedAt для проверки инварианта
  const projects = await db.project.findMany({
    where: { completedAt: { not: null } },
    select: { id: true, title: true, startedAt: true, completedAt: true, status: true },
  });

  // Находим «гнилые» записи: startedAt > completedAt
  const broken = projects.filter(p => p.startedAt > p.completedAt);
  console.log(`  Найдено с инвертированными датами (startedAt > completedAt): ${broken.length}`);

  if (broken.length === 0) {
    console.log('\n  ✅ Все даты проектов согласованы.');
    await db.$disconnect();
    return;
  }

  // Логируем «гнилые» записи и чиним — меняем местами startedAt и completedAt
  console.log('\n  → Чиним (меняем местами startedAt ↔ completedAt):');
  let fixed = 0;
  for (const p of broken) {
    await db.project.update({
      where: { id: p.id },
      data: {
        startedAt: p.completedAt,
        completedAt: p.startedAt,
      },
    });
    fixed++;
    console.log(
      `    ✓ "${p.title}" (id=${p.id}, status=${p.status})` +
      ` было startedAt=${p.startedAt.toISOString()} → completedAt=${p.completedAt.toISOString()};` +
      ` поменяли местами.`
    );
  }

  console.log(`\n  ✅ Починено проектов: ${fixed}`);
  console.log('\n=== Готово ===');
  await db.$disconnect();
}

main().catch(async (e) => {
  console.error('❌ Ошибка:', e);
  await db.$disconnect();
  process.exit(1);
});
