#!/usr/bin/env node
// =============================================================================
// W2.5 (H13, гейт 7.1 отчёта GPT) — «inventory all PII routes».
//
// Что делает:
//   1. Сканирует ВСЕ route.ts под src/app/api, строит инвентарь маршрутов.
//   2. Классифицирует PII-маркеры (email/phone/bio/birthday/location/password/
//      2fa/session/delete/forget/consent...).
//   3. MUST-AUDIT классы (необратимые PII-операции и security-critical):
//      каждое такое обслуживание ОБЯЗАНО иметь AuditLog-покрытие
//      (прямо в роуте или в вызываемом сервисе — проверяем grep'ом по файлу
//      и его прямым сервис-зависимостям).
//   4. Сверяет инвентарь со снапшотом docs/audits/pii-routes-inventory.json:
//      появление/исчезновение PII-маршрута = ошибка гейта (требует обновления
//      снапшота осознанно, коммитом).
//
// Выход: печатает сводку; exit 1 — если MUST-AUDIT без AuditLog или drift
// против снапшота. Используется в CI (см. .github/workflows/ci.yml).
// =============================================================================
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { execSync } from 'node:child_process';
import { relative } from 'node:path';

const ROOT = process.cwd();
const SNAP_PATH = 'docs/audits/pii-routes-inventory.json';
// Обновление снапшота осознанным коммитом: BIZON_PII_SNAPSHOT_REFRESH=1
const REFRESH = process.env.BIZON_PII_SNAPSHOT_REFRESH === '1';

// --- 1. Инвентарь маршрутов -----------------------------------------------
const routeFiles = execSync(
  `rg --files src/app/api --glob '**/route.ts'`,
  { cwd: ROOT, encoding: 'utf8' },
)
  .split('\n')
  .filter(Boolean);

// --- 2. PII-маркеры --------------------------------------------------------
const PII_MARKERS = [
  'emailEncrypted', 'emailHash', 'email', 'phoneEncrypted', 'phone',
  'bioEncrypted', 'bio', 'locationEncrypted', 'location', 'birthday',
  'password', 'twoFactor', 'backupCode', 'session', 'delete-account',
  'forget-me', 'deletedAt', 'consent', 'profile_view', 'passport',
];

const MUST_AUDIT_PATTERNS = [
  // необратимые PII-операции (152-ФЗ ст. 19 — фиксация фактов обработки)
  /me\/delete-account/, /me\/forget-me/,
  // security-critical auth
  /auth\/login/, /auth\/register/, /auth\/verify-email/, /auth\/2fa\//,
];

function routeOf(file) {
  return '/' + relative('src/app/api', file).replace(/\/route\.ts$/, '').replace(/\[(\w+)\]/g, ':$1');
}

const inventory = [];
const mustAudit = [];

for (const file of routeFiles) {
  const src = readFileSync(`${ROOT}/${file}`, 'utf8');
  const markers = PII_MARKERS.filter((m) => src.includes(m));
  const route = routeOf(file);
  const isMust = MUST_AUDIT_PATTERNS.some((re) => re.test(route));
  if (markers.length > 0) inventory.push({ route, markers });

  if (isMust) {
    // AuditLog-покрытие: в самом роуте или в его прямых импортах-сервисах.
    let covered = /AuditLog|auditLog\./.test(src);
    if (!covered) {
      // ищем сервис-зависимости и проверяем в них
      const imports = [...src.matchAll(/from '(@\/lib\/[^']+)'/g)].map((m) => m[1]);
      for (const imp of imports) {
        try {
          const rel = imp.replace('@/', 'src/') + '.ts';
          const depSrc = readFileSync(`${ROOT}/${rel}`, 'utf8');
          if (/AuditLog/.test(depSrc)) {
            covered = true;
            break;
          }
        } catch {
          // индексные реэкспорты — не критично
        }
      }
    }
    mustAudit.push({ route, covered });
  }
}

// --- 3. Снапшот ------------------------------------------------------------
let drift = [];
if (existsSync(SNAP_PATH)) {
  const snap = JSON.parse(readFileSync(SNAP_PATH, 'utf8'));
  const snapKeys = snap.routes.map((r) => r.route).sort().join('|');
  const invKeys = inventory.map((r) => r.route).sort().join('|');
  if (snapKeys !== invKeys) {
    const snapSet = new Set(snap.routes.map((r) => r.route));
    const invSet = new Set(inventory.map((r) => r.route));
    const added = [...invSet].filter((r) => !snapSet.has(r));
    const removed = [...snapSet].filter((r) => !invSet.has(r));
    drift = { added, removed };
  }
}

// --- 4. Вердикт ------------------------------------------------------------
const uncovered = mustAudit.filter((m) => !m.covered);
console.log(`H13 PII inventory: ${inventory.length}/${routeFiles.length} routes помечены как PII`);
console.log(`MUST-AUDIT маршрутов: ${mustAudit.length}, без AuditLog: ${uncovered.length}`);

if (REFRESH) {
  writeFileSync(
    SNAP_PATH,
    JSON.stringify({ generatedAt: new Date().toISOString(), routes: inventory }, null, 2) + '\n',
  );
  console.log(`Снапшот обновлён: ${SNAP_PATH}`);
} else if (drift.length && (drift.added?.length || drift.removed?.length)) {
  console.error(`PII-DRIFT против снапшота: +${drift.added?.length ?? 0} / -${drift.removed?.length ?? 0}`);
  console.error('added:', drift.added);
  console.error('removed:', drift.removed);
  console.error('Обновите снапшот осознанно: BIZON_PII_SNAPSHOT_REFRESH=1 node scripts/pii-inventory.mjs');
}

if (uncovered.length > 0) {
  console.error('MUST-AUDIT без AuditLog-покрытия:');
  for (const m of uncovered) console.error(' -', m.route);
}

const ok = uncovered.length === 0 && !(drift.length && (drift.added?.length || drift.removed?.length));
console.log(ok ? 'OK' : 'FAIL');
process.exit(ok ? 0 : 1);
