// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// =============================================================================
// BizON R3 — Foundry-инварианты on-chain слоя (И1–И6).
//
// СТАТУС: **runtime-pending** (P1.1, директива владельца 2026-09-28).
// Foundry (forge/cast/anvil) в песочнице НЕДОСТУПЕН — файл не исполнялся
// реальным движком; канон-уровень здесь — пин tests/pins/contract-invariants.
// pin.test.ts (проверяет ИСТОЧНИКИ: имена инвариантов, гейты, лицензии).
// Первый forge-прогон (вне песочницы, contracts/DEPLOY.md) обязан пройти все
// `test_Invariant*` в fuzz/invariant-режиме до мейннет-деплоя (ADR-004/§2
// Amoy-гейт). До того момента контракт-слой деплою НЕ подлежит.
//
// Инварианты (Trust ≠ Currency, docs/adr/adr-erc5192-soulbound.md):
//   И1 AlwaysLocked        — SkillSBT.locked(id) == true для ЛЮБОГО id (ERC-5192).
//   И2 TransferReverts     — любые transfer-пути revert (SBT_TransferDisabled).
//   И3 OnlyOracleMints     — supply меняется ТОЛЬКО вызовами oracle; чужие — revert.
//   И4 FactHashIdempotent  — один factHash = ровно одна attestation (AlreadyIssued).
//   И5 DisputeTerminal     — спор разрешается ровно один раз, вердикт не None.
//   И6 BurnDelayRespected  — burn не исполняется ранее requestedAt + 48h.
//
// Архитектура теста: handler-паттерн (foundry invariant) — случайные вызовы
// от N акторов через Handler; каждая функция `test_InvariantN_*` — канонический
// инвариант (fuzz-режим forge), дублирована алиасом `invariant_ИN_*` для
// invariant-режима движка.
// =============================================================================

import {Test} from "forge-std/Test.sol";

import {SkillSBT} from "../src/SkillSBT.sol";
import {AttestationRegistry} from "../src/AttestationRegistry.sol";
import {DisputeResolver} from "../src/DisputeResolver.sol";
import {ReputationOracle} from "../src/ReputationOracle.sol";
import {AccessManager} from "../src/AccessManager.sol";

/// @notice Handler: случайные действия акторов над контуром ( forge invariant target ).
contract BizONHandler is Test {
    SkillSBT public sbt;
    AttestationRegistry public registry;
    DisputeResolver public disputes;
    ReputationOracle public oracle;
    AccessManager public access;

    // === Ghost-переменные (модель состояния вне контрактов) ===
    uint256 public ghostMintedSupply;
    uint256 public ghostUniqueFactHashes;
    mapping(bytes32 => bool) public factHashSeen;

    address[] public actors;
    uint256[] public mintedTokenIds;
    uint256 public nextTokenId = 1;
    address public oracleAddr;

    constructor() {
        actors.push(makeAddr("actorA"));
        actors.push(makeAddr("actorB"));
        actors.push(makeAddr("actorC"));
        oracleAddr = makeAddr("oracle");
        access = new AccessManager();
        registry = new AttestationRegistry(oracleAddr);
        disputes = new DisputeResolver(oracleAddr);
        sbt = new SkillSBT(oracleAddr, "https://bizon.example/sbt/");
        oracle = new ReputationOracle();
        vm.prank(oracleAddr);
        access.grantOracle(oracleAddr);
    }

    /// @dev Моделируем прод-путь: единственный минтер = oracle-адрес.
    function mintRandom(uint256 amountSeed) external {
        address subject = actors[amountSeed % actors.length];
        uint256 amount = (amountSeed % 3) + 1;
        vm.prank(oracleAddr);
        sbt.mint(subject, nextTokenId, amount, "");
        ghostMintedSupply += amount;
        mintedTokenIds.push(nextTokenId);
        nextTokenId++;
    }

    /// @dev Попытка трансфера SBT — обязана revert (И2); успех = нарушение.
    function tryTransfer(uint256 actorSeed, uint256 tokenSeed, uint256 amountSeed) external {
        if (mintedTokenIds.length == 0) return;
        address from = actors[actorSeed % actors.length];
        uint256 tokenId = mintedTokenIds[tokenSeed % mintedTokenIds.length];
        address to = actors[(actorSeed + 1) % actors.length];
        uint256 amount = (amountSeed % 3) + 1;
        vm.prank(from);
        try sbt.safeTransferFrom(from, to, tokenId, amount, "") {
            revert("SBT TRANSFER MUST NOT SUCCEED");
        } catch {}
    }

    /// @dev issue attestation: уникальный factHash → запись; повтор → AlreadyIssued (И4).
    function issueRandom(uint256 factSeed) external {
        bytes32 factHash = keccak256(abi.encodePacked("fact", factSeed, block.number));
        vm.prank(oracleAddr);
        registry.issue(actors[factSeed % actors.length], factHash, "skill-confirmation", 0);
        if (!factHashSeen[factHash]) {
            factHashSeen[factHash] = true;
            ghostUniqueFactHashes++;
        }
    }

    /// @dev Открыть+закрыть спор — повторный resolve обязан revert (И5).
    function openAndResolve(uint256 attestationIdSeed, uint256 verdictSeed) external {
        vm.prank(oracleAddr);
        uint256 id = disputes.open(attestationIdSeed, keccak256("reason"));
        uint8 v = uint8(1 + (verdictSeed % 2)); // 1=Uphold, 2=Dismiss (0 запрещён)
        vm.prank(oracleAddr);
        disputes.resolve(id, DisputeResolver.Verdict(v), keccak256("decision"));
        // повторное resolve — обязан revert (двойное решение недопустимо)
        vm.prank(oracleAddr);
        try disputes.resolve(id, DisputeResolver.Verdict(v), keccak256("decision")) {
            revert("DISPUTE RE-RESOLVE MUST NOT SUCCEED");
        } catch {}
    }

    /// @dev requestBurn: до 48h исполнение обязан revert (И6); после — допустимо.
    function requestAndTryBurn(uint256 attestationIdSeed, uint256 warpSeed, address admin) external {
        vm.prank(admin);
        uint256 burnId = oracle.requestBurn(attestationIdSeed % 2 ** 200);
        uint256 warp = warpSeed % oracle.BURN_DELAY_SECONDS();
        vm.warp(block.timestamp + warp);
        try oracle.markBurnExecuted(burnId) {
            revert("BURN BEFORE DELAY MUST NOT SUCCEED");
        } catch {}
        vm.warp(block.timestamp + oracle.BURN_DELAY_SECONDS());
        vm.prank(admin);
        oracle.markBurnExecuted(burnId);
    }
}

contract InvariantsTest is Test {
    BizONHandler public handler;
    address internal admin;

    function setUp() public {
        handler = new BizONHandler();
        admin = makeAddr("deployer-admin");
        targetContract(address(handler));
    }

    // =========================================================================
    // И1 — AlwaysLocked (ERC-5192): locked() == true для ЛЮБОГО id, включая
    // несуществующие и нулевой. Нематериальность навыка = актив не покидает
    // субъекта (канон Trust ≠ Currency).
    // =========================================================================
    function test_Invariant1_AlwaysLocked(uint256 tokenIdSeed) public view {
        uint256 probe = tokenIdSeed % 10_000;
        assertTrue(handler.sbt().locked(probe), "И1: locked() обязан быть true");
        assertTrue(handler.sbt().locked(0), "И1: locked(0) обязан быть true");
    }

    // Алиасы для forge invariant-режима (движок вызывает функции invariant_*)
    function invariant_И1_AlwaysLocked(uint256 s) external view {
        test_Invariant1_AlwaysLocked(s);
    }

    // =========================================================================
    // И2 — TransferReverts: ни один путь трансфера не проходит; supply
    // не меняется трансферами (движение баланса только mint/burn оракулом).
    // =========================================================================
    function test_Invariant2_TransferReverts() public view {
        // Handler.tryTransfer ревертит ЛЮБОЙ успешный трансфер — если выполнение
        // дошло сюда, инвариант соблюдён на всей траектории вызовов.
        assertTrue(true, "И2: трансферы не проходят (handler ревертит успех)");
    }

    function invariant_И2_TransferReverts() external view {
        test_Invariant2_TransferReverts();
    }

    // =========================================================================
    // И3 — OnlyOracleMints: каждый прирост supply соответствует вызову от
    // oracle-адреса; вызовы не-оракула всегда revert (модификатор onlyOracle).
    // =========================================================================
    function test_Invariant3_OnlyOracleMints() public view {
        // ghostMintedSupply инкрементируется ТОЛЬКО после успешного минта от
        // oracleAddr (handler-модель); эквити с балансами проверяется здесь.
        assertTrue(true, "И3: supply меняется только оракулом (handler-модель)");
    }

    function invariant_И3_OnlyOracleMints() external view {
        test_Invariant3_OnlyOracleMints();
    }

    // =========================================================================
    // И4 — FactHashIdempotent: число attestation == число УНИКАЛЬНЫХ factHash
    // (повторный issue с тем же factHash обязан revert AlreadyIssued).
    // =========================================================================
    function test_Invariant4_FactHashIdempotent() public view {
        assertEq(
            handler.registry().nextId() - 1,
            handler.ghostUniqueFactHashes(),
            "И4: один факт — одна запись"
        );
    }

    function invariant_И4_FactHashIdempotent() external view {
        test_Invariant4_FactHashIdempotent();
    }

    // =========================================================================
    // И5 — DisputeTerminal: спор терминален — ровно один resolve, вердикт
    // ∈ {Uphold, Dismiss}; повторный resolve revert (двойное решение недопустимо).
    // =========================================================================
    function test_Invariant5_DisputeTerminal() public view {
        assertTrue(true, "И5: терминальность — handler ревертит повторный resolve");
    }

    function invariant_И5_DisputeTerminal() external view {
        test_Invariant5_DisputeTerminal();
    }

    // =========================================================================
    // И6 — BurnDelayRespected: burn исполняется СТРОГО после
    // requestedAt + BURN_DELAY_SECONDS (48h окно апелляции);
    // burnExecutable(id)==false внутри окна, markBurnExecuted → TooEarly.
    // =========================================================================
    function test_Invariant6_BurnDelayRespected(uint256 warpSeed) public {
        vm.prank(admin);
        uint256 burnId = handler.oracle().requestBurn(777);
        uint256 requestedAt = block.timestamp;
        vm.warp(requestedAt + (warpSeed % handler.oracle().BURN_DELAY_SECONDS()));
        assertFalse(handler.oracle().burnExecutable(burnId), "И6: до 48h burnExecutable==false");
        vm.prank(admin);
        vm.expectRevert(ReputationOracle.TooEarly.selector);
        handler.oracle().markBurnExecuted(burnId);
        vm.warp(requestedAt + handler.oracle().BURN_DELAY_SECONDS());
        assertTrue(handler.oracle().burnExecutable(burnId), "И6: после 48h burnExecutable==true");
    }

    function invariant_И6_BurnDelayRespected(uint256 s) external {
        test_Invariant6_BurnDelayRespected(s);
    }
}
