// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title ReputationOracle — связь оффчейн-состояния BizON с цепочкой.
 *
 * Единственный адрес, которому SkillSBT/AttestationRegistry доверяют минт/отзыв.
 * Оффчейн-ядро (антифрод N1–N6, резонанс, decay) вычисляет ДЕРЕТМЕНИРОВАННЫЙ
 * canonical-json хеш факта → оракул публикует проекцию. Мультизапись подписей
 * (мультиоракул) — осознанно НЕ в R3: единый сервер BizON контролируется
 * владельцем, усложнение отложено до децентрализации (R5+).
 */
contract ReputationOracle {
    address public admin;
    /// @notice Размер минимального аудиторского окна: пауза между инцидентом и burn
    uint64 public constant BURN_DELAY_SECONDS = 48 hours;

    struct BurnRequest {
        uint256 attestationId;
        uint64 requestedAt;
        bool executed;
    }

    mapping(uint256 => BurnRequest) public burnRequests;
    uint256 public nextBurnId = 1;

    event OracleAdminTransferred(address indexed previous, address indexed current);
    event BurnRequested(uint256 indexed burnId, uint256 indexed attestationId, uint64 executableAt);
    event BurnExecuted(uint256 indexed burnId, uint256 indexed attestationId);

    error NotAdmin();
    error TooEarly();
    error AlreadyExecuted();

    constructor() {
        admin = msg.sender;
        emit OracleAdminTransferred(address(0), msg.sender);
    }

    modifier onlyAdmin() {
        if (msg.sender != admin) revert NotAdmin();
        _;
    }

    function transferAdmin(address next) external onlyAdmin {
        require(next != address(0), "Oracle: zero admin");
        emit OracleAdminTransferred(admin, next);
        admin = next;
    }

    /// @notice Запрос на гашение attestation — исполняем не раньше 48ч (окно апелляции)
    function requestBurn(uint256 attestationId) external onlyAdmin returns (uint256 id) {
        id = nextBurnId++;
        burnRequests[id] = BurnRequest({
            attestationId: attestationId,
            requestedAt: uint64(block.timestamp),
            executed: false
        });
        emit BurnRequested(id, attestationId, uint64(block.timestamp) + BURN_DELAY_SECONDS);
    }

    /// @notice Чекап исполняемости (view для keeper'а)
    function burnExecutable(uint256 id) external view returns (bool) {
        BurnRequest memory r = burnRequests[id];
        return !r.executed && block.timestamp >= r.requestedAt + BURN_DELAY_SECONDS;
    }

    function markBurnExecuted(uint256 id) external onlyAdmin {
        BurnRequest storage r = burnRequests[id];
        if (r.executed) revert AlreadyExecuted();
        if (block.timestamp < r.requestedAt + BURN_DELAY_SECONDS) revert TooEarly();
        r.executed = true;
        emit BurnExecuted(id, r.attestationId);
    }
}
