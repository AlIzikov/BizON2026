// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title AttestationRegistry — реестр attestations (хеш-проекций оффчейн-фактов).
 *
 * Канон: Attestation = ХЕШ-ПРОЕКЦИЯ SkillConfirmation (canonical-json), НЕ второй
 * источник истины. В событии — только хеши/адреса (PII запрещён).
 * Форма: subject (адрес кошелька), factHash (keccak256 canonical-json оффчейн-факта),
 * schema (тип факта: skill-confirmation / endorsement / project-completion).
 */
contract AttestationRegistry {
    struct Attestation {
        bytes32 factHash;
        uint64 issuedAt;
        uint64 expiresAt; // 0 = бессрочно (decay живёт оффчейн)
        bool revoked;
    }

    address public immutable oracle;

    event AttestationIssued(address indexed subject, uint256 indexed attestationId, bytes32 indexed factHash, bytes32 schema);
    event AttestationRevoked(address indexed subject, uint256 indexed attestationId, string reason);

    mapping(uint256 => Attestation) public attestations;
    /// @notice factHash → attestationId (идемпотентность: один факт — одна запись)
    mapping(bytes32 => uint256) public factToAttestation;

    uint256 public nextId = 1;

    error AlreadyIssued(bytes32 factHash);

    modifier onlyOracle() {
        require(msg.sender == oracle, "Registry: not oracle");
        _;
    }

    constructor(address oracle_) {
        require(oracle_ != address(0), "Registry: zero oracle");
        oracle = oracle_;
    }

    function issue(
        address subject,
        bytes32 factHash,
        bytes32 schema,
        uint64 expiresAt
    ) external onlyOracle returns (uint256 id) {
        if (factToAttestation[factHash] != 0) revert AlreadyIssued(factHash);
        id = nextId++;
        attestations[id] = Attestation({
            factHash: factHash,
            issuedAt: uint64(block.timestamp),
            expiresAt: expiresAt,
            revoked: false
        });
        factToAttestation[factHash] = id;
        emit AttestationIssued(subject, id, factHash, schema);
    }

    function revoke(uint256 id, string calldata reason) external onlyOracle {
        attestations[id].revoked = true;
        emit AttestationRevoked(tx.origin == oracle ? address(0) : address(0), id, reason);
    }

    /// @notice Валидна ли attestation (не отозвана и не истекла)
    function isValid(uint256 id) external view returns (bool) {
        Attestation memory a = attestations[id];
        if (a.factHash == bytes32(0) || a.revoked) return false;
        return a.expiresAt == 0 || a.expiresAt >= block.timestamp;
    }
}
