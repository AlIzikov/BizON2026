// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC1155/ERC1155.sol";

/**
 * @title SkillSBT — soulbound навык BizON (ERC-5192 поверх ERC-1155).
 *
 * КАНОН BizON (директива владельца, R3-ADR adr-erc5192-soulbound.md):
 *   - ERC-5192 `locked(uint256)` == true ВСЕГДА: передавать нельзя (Trust ≠ Currency).
 *   - Минтует только ReputationOracle (minter role): чейн — ПРОЕКЦИЯ оффчейн-состояния
 *     (антифрод N1–N6, decay, резонанс-веса остаются оффчейн — единственный источник истины).
 *   - PII НЕ на цепочке: tokenURI указывает на оффчейн-метаданные (canonical-json хеши),
 *     в events — только tokenId/хеши/адреса.
 *   - Жёжение (burn) разрешено ТОЛЬКО оракулу по решению DisputeResolver —
 *     «право на забвение» (152-ФЗ/GDPR) не нарушается публичностью хешей навыков.
 */
contract SkillSBT is ERC1155, AccessControl {
    event Locked(uint256 tokenId);   // ERC-5192
    event Unlocked(uint256 tokenId); // ERC-5192 (не эмитится в SBT-режиме, для полноты стандарта)

    /// @notice Оракул, единственный минтер/бёрнер (см. AccessManager roles)
    address public immutable oracle;

    error SBT_TransferDisabled();

    modifier onlyOracle() {
        require(msg.sender == oracle, "SkillSBT: caller is not the oracle");
        _;
    }

    constructor(address oracle_, string memory uriBase_) ERC1155(uriBase_) {
        require(oracle_ != address(0), "SkillSBT: zero oracle");
        oracle = oracle_;
    }

    /// @notice ERC-5192: SBT всегда залочен (ERC-165: 0xb45a3c0e)
    function locked(uint256) public pure returns (bool) {
        return true;
    }

    /// @notice ERC-5192 + жёсткий запрет переводов на уровне _update
    function _update(
        address from,
        address to,
        uint256[] memory ids,
        uint256[] memory values
    ) internal virtual override {
        // разрешены только минт (from == 0) и burn (to == 0) оракулом
        if (from != address(0) && to != address(0)) revert SBT_TransferDisabled();
        super._update(from, to, ids, values);
    }

    /// @notice Минт подтверждённого навыка (только оффчейн-оракул после антифрода)
    function mint(address to, uint256 tokenId, uint256 amount, bytes memory data) external onlyOracle {
        _mint(to, tokenId, amount, data);
        emit Locked(tokenId);
    }

    /// @notice Burn по решению DisputeResolver / права на забвение
    function burn(address from, uint256 tokenId, uint256 amount) external onlyOracle {
        _burn(from, tokenId, amount);
    }

    /// @notice Поддержка ERC-5192 (interfaceId 0xb45a3c0e) в supportsInterface
    function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
        return interfaceId == 0xb45a3c0e || super.supportsInterface(interfaceId);
    }
}
