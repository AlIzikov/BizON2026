// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/AccessControl.sol";

/**
 * @title AccessManager — роли платформы BizON on-chain (R3).
 *
 * РОЛИ (принцип наименьших привилегий):
 *   DEFAULT_ADMIN_ROLE — владелец (мультиподпись в R5+; сейчас Gnosis Safe-кандидат)
 *   ORACLE_ROLE        — ReputationOracle сервер BizON: минт SBT, issue/revoke attestations
 *   RESOLVER_ROLE      — DisputeResolver-джюри: влияет только на гашение по спору
 *   PAUSER_ROLE        — аварийная пауза минта (Kill-Switch канон docs/KILL-SWITCH.md)
 *
 * Приватность: роли адресные, без PII; админ-ключ ВСЕГДА в аппаратном хранилище
 * (см. ADR secrets-separation), в репо ключей нет.
 */
contract AccessManager is AccessControl {
    bytes32 public constant ORACLE_ROLE = keccak256("ORACLE_ROLE");
    bytes32 public constant RESOLVER_ROLE = keccak256("RESOLVER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    bool public mintingPaused;

    event MintingPaused(address indexed by);
    event MintingResumed(address indexed by);

    constructor() {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _grantRole(ORACLE_ROLE, msg.sender);
        _grantRole(RESOLVER_ROLE, msg.sender);
        _grantRole(PAUSER_ROLE, msg.sender);
    }

    function setMintingPaused(bool paused) external {
        require(hasRole(PAUSER_ROLE, msg.sender), "AccessManager: not pauser");
        mintingPaused = paused;
        if (paused) emit MintingPaused(msg.sender);
        else emit MintingResumed(msg.sender);
    }

    /// @notice Гейт для минт-путей других контрактов
    function requireMintingOpen() external view {
        require(!mintingPaused, "AccessManager: minting paused");
    }

    function grantOracle(address account) external {
        grantRole(ORACLE_ROLE, account);
    }

    function grantResolver(address account) external {
        grantRole(RESOLVER_ROLE, account);
    }
}
