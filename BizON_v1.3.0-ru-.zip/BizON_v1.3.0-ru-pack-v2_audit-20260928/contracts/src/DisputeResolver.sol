// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title DisputeResolver — споры о подтверждениях (R3).
 *
 * Оффчейн-канон BizON: жалобы 7 категорий (S-019) — основной контур модерации.
 * Контракт фиксирует РЕЗУЛЬТАТ спора (projectio решения DAO-джюри/модерации),
 * не сам спор: чейн не место для PII и переписки.
 */
contract DisputeResolver {
    enum Verdict {
        None,        // спор открыт
        Uphold,      // жалоба удовлетворена: attestation/SBT гасится
        Dismiss      // жалоба отклонена: данные остаются
    }

    struct Dispute {
        uint256 attestationId; // предмет спора в AttestationRegistry
        uint64 openedAt;
        uint64 resolvedAt;
        Verdict verdict;
        bytes32 decisionHash;  // keccak256 canonical-json решения (оффчейн-мотивация)
    }

    address public immutable oracle;
    mapping(uint256 => Dispute) public disputes;
    uint256 public nextDisputeId = 1;

    event DisputeOpened(uint256 indexed disputeId, uint256 indexed attestationId, bytes32 reasonHash);
    event DisputeResolved(uint256 indexed disputeId, Verdict verdict, bytes32 decisionHash);

    modifier onlyOracle() {
        require(msg.sender == oracle, "DisputeResolver: not oracle");
        _;
    }

    constructor(address oracle_) {
        oracle = oracle_;
    }

    function open(uint256 attestationId, bytes32 reasonHash) external onlyOracle returns (uint256 id) {
        id = nextDisputeId++;
        disputes[id] = Dispute({
            attestationId: attestationId,
            openedAt: uint64(block.timestamp),
            resolvedAt: 0,
            verdict: Verdict.None,
            decisionHash: bytes32(0)
        });
        emit DisputeOpened(id, attestationId, reasonHash);
    }

    function resolve(uint256 id, Verdict verdict, bytes32 decisionHash) external onlyOracle {
        require(disputes[id].verdict == Verdict.None, "DisputeResolver: already resolved");
        require(verdict != Verdict.None, "DisputeResolver: bad verdict");
        disputes[id].verdict = verdict;
        disputes[id].resolvedAt = uint64(block.timestamp);
        disputes[id].decisionHash = decisionHash;
        emit DisputeResolved(id, verdict, decisionHash);
    }
}
