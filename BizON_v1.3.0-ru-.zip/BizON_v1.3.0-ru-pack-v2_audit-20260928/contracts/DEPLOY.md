# R3 — план деплоя SkillSBT-стека (Amoy → мейннет)

## Статус R3 (Task 42)

| Артефакт | Статус |
|---|---|
| 5 контрактов (`contracts/src/`) | ✅ Написаны (Solidity 0.8.24, MIT) |
| Foundry-инварианты И1–И6 (`contracts/test/`) | ✅ Готовы к `forge test` |
| Оффчейн-якоря (`onchain-anchor-service.ts`) | ✅ В коде (canonical-json хеши, REUSE PII-движка) |
| Subgraph (`subgraph/`) | ✅ Источники готовы |
| Компиляция/тесты Foundry | ⛔ Блокер: forge/solc недоступны в песочнице |
| Деплой в Amoy | ⛔ Блокер: RPC недоступен из песочницы + нет ключа деплоя (ADR secrets-separation: ключи в репо запрещены) |
| 30-дневный тестнет с пользователями | ⛔ Требует живого деплоя + реальных пользователей (после деплоя) |
| Bug bounty (Immunefi) | ⛔ ОСТАНОВКА по директиве §1: бюджет >$5k — нужно решение владельца |
| Публикация в GitHub (MIT) | ⏳ Пуш контрактов возможен после компиляции (не публикуем непроверенный код) |

## Порядок запуска (когда появится окружение)

1. `curl -L https://foundry.paradigm.xyz | bash && foundryup`
2. `cd contracts && forge install OpenZeppelin/openzeppelin-contracts && forge test` (инварианты И1–И6 зелёные)
3. `forge build --sizes` (проверка лимитов)
4. Слепить ключ деплоя в аппаратном хранилище (ADR secrets-separation): НЕ в .env репозитория
5. `forge script script/Deploy.s.sol --rpc-url amoy --broadcast --verify`
6. Адреса → `subgraph/subgraph.yaml` ({{SkillSBTAddress}} и др.) → `graph deploy`
7. Подключить `OnchainAnchorService.prepareBatch` к keeper'у оракула (пакеты ≤ 200)
8. 30-дневный тестнет: счётчик дней с первого реального минта пользователя
9. Мейннет-гейт: аудит Trail of Bits + Immunefi (решение владельца, >$5k) + 30 дней тестнета + DAO-голосование

## Канон

- Чейн = проекция; оффчейн — единственный источник истины.
- PII не на чейне: только canonical-json хеши + адреса.
- Trust ≠ Currency: ERC-5192 locked, transfer revert.
- Пины канона: `tests/pins/contract-invariants.pin.test.ts` (7/7 зелёные).
