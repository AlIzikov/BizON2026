# W4-1+W4-3 — coder — Запись о работе

**Дата:** 2026-09-19 · **План:** OWNER-UX-PLAN-2026-09-19, шаги 15-16 из 24 · **Статус:** DONE (гейты зелёные, live-проверено)

## Что сделано

### W4-1 «Мои резюме» (шаг 15)
- **API `src/app/api/resumes/route.ts` (НОВЫЙ):** GET — мои резюме (createdAt desc) лёгкими карточками `{id, title, type, updatedAt(editedAt??createdAt), blocksCount, aiGenerated}` + `count/cap`; POST `{title?≤120, type?(default short), copyOf?}` — кап 10 → **422 «Максимум 10 резюме — удалите или объедините одно из существующих»** (важнее копирования); `copyOf` → content байт-в-байт + тип источника + title «Копия <title>» (пустой source-title → «Копия резюме») + aiGenerated источника; пустое создание → content `{"blocks":[],"blocksUpdatedAt":ISO}` (ФАКТИЧЕСКИЙ формат в БД — проверен db.resume.findFirst, блоковый, НЕ header/skills/секции) + `aiGenerated=false`. withRoute + inline-zod + rateLimit.
- **API `src/app/api/resumes/[id]/route.ts` (НОВЫЙ):** GET (полный распарсенный content) / PATCH `{title?,type?}` (+editedAt) / DELETE — владелец-only; чужое/несуществующее → **404** (паттерн ResumeBlocksService — не раскрываем существование; в гейте задачи допускался «403/404»); DELETE → JobApplication.resumeId SetNull схемой (отклики живы).
- **UI `src/components/resume/resumes-panel.tsx` (НОВЫЙ):** счётчик «N / 10»; создание 2 путями — «Создать» (диалог, инлайн-ввод названия → POST → сразу редактор) и «Сгенерировать из данных» (смонтирован осиротевший после W0-2 **ResumeGeneratorDialog** — живой /api/cv/generate, paywall люменов сохранён; аддитивный проп `onGenerated` → reload списка); карточки: title/«Без названия», бейдж типа (Краткое/Полное/Сопроводительное), AI-бейдж, «обновлено <дата>», блоков:N; действия Редактировать / Найти вакансии / Копировать / Удалить (AlertDialog-confirm); при капе создание disabled + Tooltip; пустое состояние — FileText + честный текст + обе кнопки создания.
- **Редактор `src/components/resume/resume-editor.tsx` (НОВЫЙ):** блоковый на СУЩЕСТВУЮЩЕМ API GET/PUT `/api/resumes/[id]/blocks` (первый клиентский вызов этого контракта); секции: О себе (≤5000, счётчик), Навыки (чипы ≤5, звёздочка = is_primary), Опыт и образование (title/organization/job|education/YYYY-MM type=month/end nullable/description), Квалификации (qualification+award); серверные ошибки валидации → тост с текстом сервера; для генераторных резюме (blocks=null) стартует пустым — blocks-service сохранит base-секции при первом PUT.
- **Монтирование (Q7):** `app-store.ts` — `ProfileSubTab = 'profile'|'resumes'` + `setProfileSubTab` (не персистится; NavSnapshot сознательно не расширял — отличие от feedSubSection задокументировано); `profile-view.tsx` — минимальная вставка: `ProfileSubTabs` (Tabs «Профиль | Резюме») только при `isOwn` (в шапке + ранний return «табы + ResumesPanel»); `app-shell.tsx` — RightRail пункт «Мои резюме» (FileText) → `setProfileSubTab('resumes') + setProfileUserId(user.id) + setView('profile')` (setProfileUserId обязателен: без него view='profile' при null открывает MeView).

### W4-3 «Подбор вакансий под резюме» (шаг 16)
- **API:** `src/app/api/jobs/match/route.ts` — существующий роут AI-подбора (top-3 по профилю + LLM) расширен **аддитивно** веткой `GET ?resumeId=`: навыки из content (blocks kind='skill' + генераторные topSkills/skills[].name) → скоринг активных вакансий. Формула (документирована в коде; skill-ядро computeJobMatch и /api/me/discover переиспользовано): `score = min(1, matched/required + 0.15·titleHit + 0.05·descHit)` — title/desc-hit = вхождение навыков резюме в title/description вакансии (case-insensitive); score=0 отфильтрованы; sort desc, кап 20; ответ `{matches:[{jobId,title,company,salaryMin,salaryMax,currency,location,score,matchedSkills[],missingSkills[]}]}`; 401/404/422 «В резюме не найдено навыков»; отдельный лимит 60/ч (ai:jobsMatch LLM-лимит не тронут); легаси-ветка без resumeId не изменена.
- **UI:** кнопка «Найти вакансии» → Dialog: score-полоса (Progress) + процент, matched-чипы зелёные, missing зачёркнутые; клик по вакансии → store-контракта selectedJobId нет (deep-link только через URL) → честно: закрыть диалог + фильтр + `setView('jobs')`; «Открыть в поиске вакансий» → `applyJobsFilter({mode:'quick', q:<навыки CSV>, resumeId}) + setJobsCurrentSearchParams(params) + setView('jobs')` (jobs-view применит jobsFilterApply-сигнал).

## SavedFilter-монитор — ЧЕСТНО НЕ ЗАВЕРШЁН (контракт готов)
- Готовый UI сохранения фильтров ЕСТЬ (saved-filters-panel + /api/saved-filters, target=jobs, params — JSON-строка). Монитор «под резюме» не собран: панель персистит `jobsCurrentSearchParams`, которые публикует jobs-view, а jobs-view (вне моей зоны) не знает про resumeId и перезапишет params без него. Выдумывать UI не стал.
- Сделано: `resumeId` передаётся в applyJobsFilter-params (незнакомые ключи jobs-view игнорирует — безвредно) + params-контракт задокументирован в коде матча и панели: `params = JSON.stringify({mode:'quick', q:'<навыки CSV>', resumeId})` — будущему монитору достаточно сохранить/восстановить ключ; миграции схемы не требуется.

## Файлы
- НОВЫЕ: `src/app/api/resumes/route.ts`, `src/app/api/resumes/[id]/route.ts`, `src/components/resume/resumes-panel.tsx`, `src/components/resume/resume-editor.tsx`, `tests/owner-w4.test.ts`
- АДДИТИВНАЯ ВЕТКА: `src/app/api/jobs/match/route.ts`
- ПРАВКИ: `src/components/cv/resume-generator-dialog.tsx` (только проп `onGenerated`), `src/components/profile/profile-view.tsx` (табы isOwn + ранний return), `src/components/shell/app-shell.tsx` (пункт RightRail), `src/stores/app-store.ts` (ProfileSubTab)

## Гейты (все зелёные)
- `bun test tests/owner-w4.test.ts` — **23 pass / 0 fail** (110 expect)
- Регресс: owner-w13-w33+owner-w3-conn+owner-w1+owner-w0-2+owner-w3-graph = **98/0**; owner-w2+wave1-trust = **34/0**
- tsc скоупами (конфиги удалены): серверная зона **0**, UI-зона **0**, тест-скоуп — 0 в моём файле (pre-existing `tests/helpers/setup.ts:36`, общий хелпер)
- `bun run lint` — exit 0
- Live (:3000, ivan@bizon.ru): без auth → 401; полный золотой путь: POST 201 → PUT blocks 200 → GET content → список blocksCount=3 → **match: «Senior Python Developer» score 0.7, matched [Python, Docker], missing [FastAPI, PostgreSQL]** → copy «Копия …» → PATCH (+editedAt) → DELETE ×2 → список пуст; dev.log — 0 ошибок/500 в моих роутах (только pre-existing [decrypt] legacy-warn при логине).

## Решения по умолчанию (задокументированы в коде)
1. Чужое резюме → **404** (не 403) — консистентно с ResumeBlocksService, существование чужого не раскрывается.
2. «Бухгалтерия»-вакансия при резюме React/Node честно отфильтровывается (score 0) — «подбор под резюме» = релевантное остаётся; «два разных резюме дают разные подборки».
3. Пустое создание — блоковый content (формат БД), `aiGenerated=false`; копия сохраняет aiGenerated источника (происхождение контента).
4. profileSubTab не пишется в историю навигации (NavSnapshot не расширял — минимальная вставка в store).
5. title/desc-hit — по навыкам РЕЗЮМЕ (а не required) в тексте вакансии: сигнал релевантности кандидату.

## Вне зоны (не тронуто)
- SavedFilter-монитор под резюме — params-контракт готов (выше); недостающее звено — проброс resumeId в jobsCurrentSearchParams внутри jobs-view (чужая зона).
- Выбор резюме при отклике — W4-2 (другой агент; JobApplication.resumeId уже в схеме, его заполняет W4-2).
- Браузерная проводка UI-путей — по плану W6-1 (приёмка); `tests/helpers/setup.ts:36` — pre-existing tsc (общий хелпер).
