# Task 2-b — docs (doc-mismatch-fix)

Проект: BizON, /home/z/my-project. Задача: верификация аудита GPT нашла DOC-MISMATCH — привести документацию в соответствие с ФАКТОМ. Писал только документацию: код, тесты, docs/audits/* не тронуты.

## Контекст
- Прочитан worklog.md (W1.5 / W6 audit-gap-closure / fix-login-email-lookup — там все факты о governance, кэше, email-ремонте).
- Все числа перепроверены независимо: `find src/app/api -name route.ts | wc -l` → 251; `rg -l "z-ai-web-dev-sdk" src` → 13; `grep -c "^model"` → 89; SQL (bun:sqlite, readonly): User total 35 / plaintext email 0 / enc+hash 21 / emailHash=null 14; схема — 2110 строк; сервисов — 58.

## Изменённые файлы (5)

### 1. docs/handover/04-api-catalog.md
- §6: 249 → **251** route.ts; сервисы 54 → **58** (+ai-governance в списке либ; research-tests → research-service).
- §1.10: `zai-client.ts` → **llm-client.ts** (прямая загрузка SDK ровно 2 точки: llm-client.ts:39, ai-core/index.ts:145).
- §1.11: research-tests.ts → research-service.ts.
- §2.11: добавлены **POST /api/projects/[id]/confirmation** (анти-коллюзия заказчик≠своя компания), **POST .../confirmation/decide** (approve|approve_with_changes|reject), **GET /api/projects/[id]/evidence** (публичная проекция approvedFields).
- §2.27: переписан — фактический роут ОДИН **/api/me/research** (GET/POST; consent, серверная формула, TTL 180д, rate 3/ч); пометка, что /api/research/tests* и /api/research/insights НЕ существуют.
- §2.30: добавлены **GET /api/ai/decisions** (Decision Inbox, не исполняет действия), **PATCH /api/ai/decisions/[id]** (approved|rejected, 409 повтор/истечение), **GET/PATCH /api/ai/governance/status** (admin; pause/resume/global_kill, персистентный kill через политику global_autonomy); запись **/api/ai-co-pilot заменена** честной пометкой «роут НЕ существует; компонент keyword-MVP без LLM, без API-вызовов» (89 строк).
- §2.31: добавлен **GET/PATCH /api/me/autonomy** (manual|collaborative; новая версия AiAuthority version+1); заголовок «35 маршрутов» → «39 каталогов, 53 route.ts».
- §3.4: «Research Tests (research-tests.ts)» → **«Research Service (research-service.ts)»** — prof_orientation v1, 5 вопросов (build/analyze/lead/communicate/deep), честность T8, submit/listActive/shouldOffer.
- §4 карта сигналов: «Прошёл опросник исследования» → POST /api/me/research (без LLM; ResearchResult create; сигнал в UnifiedIntentService).

### 2. docs/handover/03-data-model.md
- Шапка: схема 1910 → **2110 строк**; stale-абзац «ровно 80 деклараций» → **89** (v1.1.0: +ProjectConfirmation, +Recommendation, +ResearchResult, +9 Ai*).
- НОВЫЙ §2.7 «Governance (AI-управление)»: AiGoal, AiAgent, AiAuthority, AiPolicy, AiAction, AiApproval, AiAuditLog, AiBudget, AiIncident (schema.prisma:1939-2085; без relations к доменам; autopilot выключен) — краткие описания в стилистике файла (поля/статусы/индексы/кто пишет-читает).
- СВЕРХ перечня ТЗ (согласовано с миссией «факт, не выдумки»): модель **ResearchResult актуализирована** под фактическую схему — source/kind/version/answers/score/confidence/consent/capturedAt/expiresAt, userId без FK (§1.6); consumer — UnifiedIntentService. Старое описание (testKey profession|preferences|motivators, AIGateway-интерпретация, ai-co-pilot) ссылалось на несуществующие роуты.

### 3. docs/handover/06-ai-integration.md
- Принцип №2: zai-client.ts → **llm-client.ts**.
- Таблица §2: AI Co-Pilot — «роута НЕТ, keyword-MVP без LLM»; «Исследования» → api/me/research + research-service.ts (без LLM, AI-сигнал с consent/TTL).
- §2 под таблицей: «SDK упоминается в 15 файлах» → **13** (`rg -l "z-ai-web-dev-sdk" src`): 2 прямые загрузки (llm-client.ts:39, ai-core/index.ts:145 legacy getZai), остальные — llm-колбэки/комментарии/UI-текст; 2 клиентских компонента — текст/комментарий, вызовов нет. Убрано устаревшее «legacy-файлы инстанцируют SDK inline мимо шлюза» (после W1.6 ai.ts берёт getZaiClient из llm-client).
- §3 п.2 «Нет кэша AI-ответов» → актуализация: KV-кэш в gateway.ts (max 1000, TTL 1ч, SHA-256 {AI_CACHE_SCHEMA_VERSION+operation+payload+data}, кэшируется только provider='llm', hit — cached:true, аудит provider='cache'; флаги AI_CACHE_ENABLED=0/AI_CACHE_SCHEMA_VERSION; rate limit 30/ч на user+op). Redis — пост-пилот.
- §4 R6: база — ResearchResult (новые поля) + research-service.ts + UnifiedIntentService; research-view.tsx / research-tests.ts не существуют.

### 4. PRE-LAUNCH.md
- **C1 → [x]**: ЗАКРЫТО (W1.5, актуализировано 15.09): plaintext email 0/35 (SQL: 35/0/21/14), 21 encrypted+hash (ремонт 15.09, lookup 21/21), 14 legacy QA emailHash=null (потерян исторически); детерминированный DEV_FALLBACK_KEY.
- **C4 → [x]** с оговоркой: закрыто через альтернативный acceptance аудита — ssrf.ts validateUrlSafety, redirect:'manual' (:180), double-resolve (:16), BIZON_EXTERNAL_FETCH_ENABLED default OFF (:26-27, .env.example:79); полный DNS-pinning отложен (known-issue, 07 §2 п.8).
- **H6 → [x]**: whitelist существует (middleware.ts:23-50 PROD + preview *.space-z.ai/*.z.ai; localhost только вне prod :46-51); пометка «runtime-тест требуется».
- **H9 → [x]**: git ls-files не содержит .env/.pem/.key (только .env.example); оговорка: db/custom.db + db/custom-v6seed-backup.db (+backup-w2/w3/w15) с демо-токенами в git — осознанно, для воспроизводимости демо.
- **H10 → [x]**: BIZON_DEMO_AUTH default 0 (.env.example:20) + NODE_ENV!=='production' guard (middleware.ts:85-89, добавлен 15-09).
- **H11 → [ ]**: «частично → расширено 15-09: критичные mutation-роуты (auth, money: lumens/topup+subscriptions, PII: delete-account+hr-contacts, posts, jobs apply) под лимитами; остальные ~200 — при касании» (лимиты в файлах подтверждены grep).
- **H12 → [ ]**: note «Redis/кэш отложено» исправлена — in-memory AI-кэш реализован в AIGateway (KV max 1000, TTL 1ч, SHA-256, флаги), Redis — пост-пилот.
- **H13 → [ ]**: честная пометка «PII-чтения не логируются системно; инвентарь PII-роутов не составлен — см. 07-known-issues».
- **T10 → [x]**: scripts/restore-db.sh + режим --verify (15-09).
- Добавлено примечание о дефекте нумерации: H4/H5/H7/H8 отсутствуют (переход H3→H6→H9), исходник download/BizON-final-audit.md в репо отсутствует; пункты сознательно не выдумывались.

### 5. docs/handover/07-known-issues-and-roadmap.md
- НОВЫЙ §6 «Остатки аудита 14-09 и техдолг v1.1.0 (дополнено 15-09)»:
  - **DEF-23**: event bus in-process, события теряются при рестарте; outbox не реализован (ограничение пилота, single-worker) — план: при переходе на >1 воркера.
  - **H13**: PII-чтения не логируются системно (только мутации/security); инвентарь PII-роутов не составлен.
  - **Governance**: контур (registry/policy/decisions/inbox, 9 Ai*-моделей) готов и протестирован; proposeAction в бизнес-роуты не вшит (вызывающих вне контура — 0); kill-switch проверяется в **GovernanceService.proposeAction** (governance-service.ts:84: env BIZON_AI_AUTONOMY_KILLED + персистентная политика global_autonomy).
  - **Safe error map**: 124 e.message в 56 файлах src/components (81 — description: e.message в toast); план — клиентский аналог errors.ts.
  - **UnifiedIntentService**: реализован (unified-intent-service.ts, GET /api/me/intent-snapshot: intents+research+профиль+ActionEvent); интеграция в opportunity/feed/search — бэклог T6/T7.
- §3 (незакрытые пункты PRE-LAUNCH) актуализирован: убраны закрытые C1/C4/H6/H9/H10/T10, добавлен H3, T10 отмечен закрытым.
- §4 R6: база заменена на фактические файлы (research-view.tsx/research-tests.ts не существуют).

## Осознанные отклонения от ТЗ (по правилу «не выдумывать факты»)
1. ТЗ предлагало писать «kill-switch теперь проверяется в AIGateway.run() (15-09)» — проверка показала, что в ai-core/gateway.ts kill-switch ОТСУТСТВУЕТ (rg Governance|kill по ai-core — пусто); фактически проверка в GovernanceService.proposeAction (governance-service.ts:84, PolicyEngine env + БД-политика). В доках зафиксирован проверенный вариант с file:line.
2. Число 113 «raw e.message в toast» не воспроизвелось — фактические проверенные числа: 124 вхождения e.message в 56 файлах компонентов, из них 81 `description: e.message` (toast-паттерн). Использованы проверенные.
3. Дополнительно к перечню ТЗ: исправлены обнаруженные при сверке попутные DOC-MISMATCH того же класса — /api/ai-co-pilot в 04 (роут не существует), модель ResearchResult в 03, R6-база в 07/06, число сервисов 54→58 и строк схемы 1910→2110.

## Проверки
- Изменены только .md-файлы (worklog.md, 4 handover-дока, PRE-LAUNCH.md, agent-ctx). Код, schema, тесты, docs/audits/* — не тронуты.
- Финальный grep: в изменённых доках не осталось упоминаний research/tests*, research-tests.ts (кроме пометок «не существует»), zai-client.ts, api/ai-co-pilot (кроме пометки «НЕТ»), «249», «80 деклараций», «15 файлах».
