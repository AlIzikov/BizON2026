# W0-3+W2-1+W2-2+W2-3 — full-stack-developer — Work Record

**План:** OWNER-UX-PLAN-2026-09-19, шаги 2–4 из 24 (Зона «Сообщения»)
**Статус:** DONE (live-curl на :3000 — софт-скип: dev-сервер платформы лежал между вызовами; инпроцесс-проверка 401 детерминированно зелёная)
**Следующим агентам:** prisma/schema.prisma не трогать; chat-notify.ts НЕ передаёт type/metadata в сокет-броадкаст (см. «Хвосты» ниже).

## Что сделано

| Задача | Файлы: строки | Суть |
|---|---|---|
| W0-3 store | src/stores/app-store.ts:164-172, 285-291 | messagesComposeToUserId/messagesComposeDraft + setMessagesCompose/clearMessagesCompose; partialize не тронут (не персистится) |
| W0-3 ghost | src/components/projects/applications-panel.tsx:34-37, 80-86 | ghost setMessagesComposeToUserId → setMessagesCompose({toUserId, draft}) + setView('messages') — crash «Ответить» починен |
| W0-3 consumer | src/components/messages/messages-view.tsx:275-313, 361-366 | эффект prefill с анти-циклом (composeAppliedRef, ожидание loading); чип получателя с крестиком; карточка «Новое сообщение» при отсутствии беседы; имя из /api/users/[id] |
| W0-3 send | messages-view.tsx:368-429 | send() без activeConv (POST → 201 → перезагрузка списка → openConv созданного); ручной клик по диалогу гасит compose |
| W2-1 сервер | src/lib/validation.ts:107-119; src/app/api/messages/route.ts:76-99 | schema: content ≤21000 + type enum(message\|letter).default + metadata string ≤1000; роут: message >280 → 422 «Максимум 280 символов — напишите письмо», letter >20000 → 422 «Максимум 20 000 символов»; metadata не-JSON → 400 |
| W2-1 клиент | messages-view.tsx:585-672 (renderComposer) | Textarea autosize (кап 160px, maxLength=280), счётчик N/280: серый <240 / amber-500 240-279 / red 280; блок только при >280 (280 валидно — сервер 201) |
| W2-2 | messages-view.tsx:478-528, 833-901 | Dialog-композер «Написать письмо» (тема ≤200, текст ≤20000, счётчик), POST type:'letter' + metadata {subject}; свёрнутая карточка письма в ленте + полноэкранный ридер (text-base/leading-relaxed/whitespace-pre-wrap, одна метка времени); msgType() с эвристикой «>280 ⇒ letter» для живых сокет-пейлоадов |
| W2-3 бейдж | src/components/shell/app-shell.tsx:148-151, 816-853, 513-521, 663-671 | useMessagesUnreadBadge — polling 30с (totalUnread от сервера), бейдж на «Сообщения» в десктоп «Ещё» и моб. sheet; скрыт при 0 и view==='messages'; выбор polling-only задокументирован (сокет NotificationsDropdown не переиспользуем без рефактора вне зоны) |
| W2-3 сервер | route.ts:16-70 (offset/hasMore/totalUnread одним count); [conversationId]/route.ts:22-67 (?before=ISO\|id, take 50+1, hasMore+nextBefore) | валидация offset 0..100000 / курсора (мусор → 400) |
| W2-3 клиент | messages-view.tsx:431-476 | «Загрузить ещё» над лентой (prepend+дедуп, прокрутка на месте через scrollHeight-дельту в rAF); «Показать ещё диалоги» (offset+дедуп) |

## Тесты (tests/owner-w2.test.ts — НОВЫЙ, 18 pass / 0 fail, 54 expect)

- Инпроцесс-вызовы реальных хендлеров + real-сессия (Session.token=sha256(raw), Bearer) на изолированной копии БД (tests/helpers/setup).
- Анти-спам гейт обходится accepted-Connection через db.connection.create (тестовые юзеры ipScore=0).
- Кейсы: стор-контракт (set/clear/draft optional/partialize-guard по исходнику); 281→422 «Максимум 280»; 280→201; letter 5000→201 + БД type='letter' + metadata.subject; 20001→422; bizcard→400; metadata-мусор→400; пагинация треда (55 сообщений через createMany: 50/hasMore/nextBefore → остаток/hasMore=false; курсор по id; мусор→400; asc); список (31 диалог: 30/hasMore/totalUnread>0 → offset=30 остаток); unauth GET → 401 (список и тред).
- Регресс: owner-w0-1 15/0, kv2-outbox+kv2-session 9/0. tsc: 269 total (baseline ~270), в зоне 0. lint: exit 0.

## Решения/трактовки (честно)

1. **schema-max 21000, не 20000** — иначе 20001-й символ письма давал бы zod-400, а не требуемый 422 «Максимум 20 000 символов».
2. **«Блок отправки на 280»** = блок ПРЕВЫШЕНИЯ (>280; maxLength делает его недостижимым — защита от внешнего prefill). Ровно 280 — валидно и отправляется (сервер 201), блокировать нельзя.
3. **Бейдж polling-only** (допускался ТЗ): сокет NotificationsDropdown держит state локально — переиспользование = рефактор вне зоны; live-инкременты в открытом разделе уже делает messages-view по conversation:activity.
4. **Эвристика «>280 ⇒ letter»** в рендере: живой сокет-пейлоад (chat-notify) не несёт type/metadata; после переоткрытия треда REST отдаёт полную запись (тема появляется).

## Хвосты для следующих агентов

- **chat-notify.ts** (вне зоны W2): в ChatBroadcastMessage добавить `type`/`metadata` passthrough (2 строки + валидатор chat-service) — уберёт эвристику и даст live-тему письма.
- dev-сервер платформы :3000 периодически лежит между шелл-вызовами — live-smoke в тесте мягкий (по образцу owner-w0-1).
