# Task 2-c — full-stack-developer (Project Evidence UI + 2FA test + AIState)

## Task
Поднять UI-слой Project Evidence Engine (backend был готов, UI отсутствовал полностью): API списка подтверждений, кнопка запроса у владельца, бейджи clientStatus, диалог решения для компании-заказчика; тест полного 2FA login flow; контракт AIState + AiStateBadge с интеграцией в Decision Inbox.

## Work Log (выполнено)
1. Контекст: worklog.md (W1–W6), project-evidence-service.ts (requestConfirmation/decideConfirmation/getPublicEvidence), 3 существующих API-роута confirmation/decide/evidence, schema (ProjectConfirmation, Company.accountUsers ↔ User.companyId, Project.clientCompany), with-route/api-helpers, тест-паттерны w1 (setup.ts — изолированная копия БД; TOTP-тест 3: otplib v13 generateSync/verifyTokenPlain).
2. `src/app/api/projects/confirmations/route.ts` (NEW) — GET, auth 401: `incoming` = pending, где юзер в accountUsers компании-заказчика (фильтр `project.clientCompany.accountUsers.some(id)` — ТОЧНО как decideConfirmation: у ProjectConfirmation НЕТ своего relation на Company, только через project!); `outgoing` = подтверждения проектов владельца (+status). Формат: { id, projectId, project:{id,title,clientCompanyId,clientStatus,problem,context,solution,result}, requestedAt, createdAt }.
3. `src/lib/types.ts` — ProjectPublic +optional: clientCompanyId/clientStatus/problem/context/solution/result; `src/app/api/projects` GET — отдаёт эти поля (роут [id] уже отдавал через spread).
4. `src/components/projects/projects-view.tsx`:
   - ClientStatusBadge (pending/verified/verified_with_changes/rejected → русские бейджи с иконками Clock/BadgeCheck/FilePenLine/XCircle; emerald/amber/destructive, без синего);
   - бейдж на карточке И в детальном диалоге (блок со статусами справа от названия);
   - Evidence-блок «Проблема/Контекст/Решение/Результат» в детальном диалоге;
   - кнопка «Запросить подтверждение заказчика» (карточка + диалог): isOwner && status==='completed' && clientCompanyId && clientStatus∉{verified, verified_with_changes}; POST /api/projects/[id]/confirmation {} → toast «Запрос отправлен заказчику» (alreadyPending — серверный message); при pending кнопка disabled «Ожидает решения заказчика»; rejected → подсказка о повторном запросе (новая immutable-запись);
   - ClientConfirmationsSection: GET /api/projects/confirmations, секция «Подтверждения проектов» с count-badge, max-h-96 overflow-y-auto, рендер только при incoming>0;
   - ConfirmDecisionDialog: поля проекта с чекбоксами (title/problem/context/solution/result, все выбраны по умолчанию), textarea комментарий, «Подтвердить выбранные поля» (disabled при 0 выбранных — approve требует ≥1) → decision approve, approvedFields=выбранные, rejectedFields=остальные; «Отклонить» → decision reject; ошибки бэка показываются как есть (анти-коллюзия и т.п.).
5. `src/lib/ai-state.ts` (NEW) — AIState (CONFIDENT/UNCERTAIN/INSUFFICIENT_DATA/REQUIRES_HUMAN/POLICY_BLOCKED), AI_STATE_META (русские подписи+описания), toAiState(value, fallback=INSUFFICIENT_DATA) с нормализацией.
6. `src/components/ai/ai-state-badge.tsx` (NEW) — AiStateBadge: иконки CheckCircle2/HelpCircle/Database/UserCheck/ShieldAlert, палитра emerald/amber/muted/orange/destructive, title+aria-label с описанием.
7. `src/components/settings/decision-inbox.tsx` — AiStateBadge у каждого элемента: REQUIRES_HUMAN; если срок решения истёк (expiresAt ≤ now) → POLICY_BLOCKED + кнопки disabled (отклонённые исчезают из inbox — backend фильтрует pending&не-истёкшие). Риск-бейдж сохранён рядом.
8. `tests/w5-auth.test.ts` (NEW) — полный 2FA flow на изолированной копии БД: registerUser → generateSecretForUser+включение 2FA в БД → РЕАЛЬНЫЙ хендлер POST /api/auth/login → {twoFactorRequired:true, tempToken}, сессий не прибавилось → otplib generateSync → неверный код verifyToken=false → consume2FATempToken+verifyToken(по зашифрованному секрету из БД)+AuthService.createSession (последовательность 1:1 как в /api/auth/2fa/verify — сам роут не вызывается, т.к. setSessionCookie→cookies() недоступен вне Next-рантайма) → Session в БД + getUserFromRequest проходит → replay tempToken → null → неверный пароль → 401.

## Результаты проверок
- `bun test tests/w5-auth.test.ts` → 1 pass / 0 fail (20 expect).
- `bun run lint` → 0 ошибок 0 предупреждений; `tsc --noEmit` → 0.
- Runtime E2E живого сервера (временный скрипт, удалён после): request 200 → incoming клиента 200 (1 запись, title+requestedAt) → outgoing владельца 200 (status pending) → decide владельцем 403 «Подтверждать может только сотрудник компании-заказчика» → decide клиентом 200 (verified, immutable) → evidence отдаёт ТОЛЬКО approvedFields (title/problem/result; context/solution скрыты) → без сессии 401. Тестовые записи из БД удалены, артефактов нет.
- Готел найденный при E2E баг: первый вариант фильтра incoming через несуществующий relation `clientCompany` на ProjectConfirmation давал 500 — исправлен на путь через project.clientCompany (как в сервисе), подтверждено 200.

## Ключевые решения / контракты для координатора
- `/api/projects/confirmations` — единый read для UI: incoming (что решить) / outgoing (что запросил, со status). Решения по-прежнему только через существующий decide-роут.
- clientStatus-бейджи — отображение ортогонального статуса; наименования статусов берутся из schema ('verified_with_changes'), не из формулировки ТЗ ('client_changes' в схеме нет).
- AIState — презентационный контракт, не трогает ai-governance/ai-core (зоны параллельного агента не затронуты).
- Файлы в зоне Task 2-c не дублируют роуты Project Evidence (request/decide/evidence НЕ изменялись).

## Ограничения (честно)
- Диалог решения предлагает 5 полей (title/problem/context/solution/result); 'outcome' из PUBLIC_EVIDENCE_FIELDS в чекбоксах не представлен (в ТЗ 5 полей; бэкенд примет и его).
- Секция подтверждений скрыта при отсутствии incoming (минимальный шум); отдельной вкладки нет — пункт (в) ТЗ допускал выбор места.
- В decision-inbox «отклонён» не отображается постоянно — listPendingDecisions возвращает только pending&не-истёкшие; отклонённый элемент исчезает после перезагрузки списка.
