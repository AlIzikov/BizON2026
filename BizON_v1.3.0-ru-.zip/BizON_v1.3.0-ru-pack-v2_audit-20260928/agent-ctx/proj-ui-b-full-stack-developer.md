# Task proj-ui-b — full-stack-developer (UI, модуль «Проекты» ТЗ-ПР-4.9)

Дата: сессия proj-ui-b (продолжение после обрыва). Проект: /home/z/my-project.

## Контекст, с которого стартовал
- Прочитаны: worklog.md, docs/proposals/PROJECTS-MODULE-PROPOSAL-TZ-PR-4.9.md (§3.3 UI, §3.4 дизайн), docs/proposals/PROJECTS-API-CONTRACT.md (§0–§11), src/stores/app-store.ts (useAppStore: view/setView/selectedProjectId/setSelectedProjectId/setProfileUserId/api()), src/app/page.tsx (deep-link паттерн ?view=jobs&jobId=).
- Переиспользованы файлы предыдущего прогона (проверены на консистентность, НЕ переписывались): src/components/projects/types.ts (ProjectsTab, ProjectCardData, ProjectDetailResponse, LotCardData, LotResponsesResponse и др.), utils.ts (formatDate/DateTime/Relative, statusLabel, roleLabel, applicationStatus*, useDebouncedValue, fileToDataUrl 2Мб, videoEmbedUrl, scrollToFeedTop, plural), pagination.tsx (FeedPagination), forms/add-contributor-modal.tsx (AddContributorModal + ContributorDraft), modals/confirm-dialog.tsx, modals/report-modal.tsx, modals/share-modal.tsx. Расхождений имён/экспортов не найдено.
- Бэкенд-агенты работают параллельно: часть роутов (taxonomy, lots, saved, recently-viewed, recommendations) на момент работы ещё без route.ts — код писался строго по контракту.

## Что сделано (файлы + строки)
1. src/components/projects/projects-view.tsx — 198 (полная переписка, было 416): контейнер 7 разделов (подменю-чипы, role=tablist, overflow-x-auto, min-h-11), контент по табу (feed/lots/myLots), «Мои проекты» с «Добавить проект» + «Корзина» (trash=1, restore), страница проекта отдельным слоем, deep-link пропсы.
2. src/components/projects/feed/projects-feed.tsx — 805: тулбар (Sheet-фильтр тематик/регионов/дат, DropdownMenu-сортировка, поиск debounce 300мс), GET /api/projects с полным набором параметров + scope=recommended → /api/projects/recommendations; расширенная первая карточка + компактные; PremiumNewsRotator (10с, hover-пауза, точки); RecentlyViewed (только all, гость — скрыт); пустое состояние + «Сбросить фильтры»; FeedPagination; TrashCard с «Восстановить»; refreshKey-проп; звезда-избранное (POST save, гость — toast).
3. src/components/projects/detail/project-page.tsx — 819: крошки, бейджи (status/verified/isPremium/hasApplied), cover, description, evidence-Accordion, видео (iframe/<a>) + галерея-лайтбокс, таблица «Над проектом работали» (members+contributors), отзывы (форма+правила+ответы depth-1+удаление своего), «Об авторе», действия (избранное/поделиться/жалоба/заявка), владелец → ApplicationsPanel, POST view fire-and-forget, 404 → «Объект недоступен».
4. src/components/projects/applications-panel.tsx — 213: счётчики непрочитанные (клик=фильтр)/всего, «заинтересован в работе», разворот письма → PATCH view, Принять/Отклонить, «Заявок пока нет», max-h-96.
5. src/components/projects/forms/create-project-dialog.tsx — 515: поля с лимитами 100/150 + счётчики, чипы-тематики (≤5), Select-регион, участники через AddContributorModal, Switch видимости, cover/promo/галерея ≤20 через data-URL ≤2Мб (превью), videoUrl, предпросмотр «как в ленте», Разместить (publish:true, contributors) / черновик (publish:false).
6. src/components/projects/lots/lots-board.tsx — 613: поиск, рекламная заглушка, панель уточнения 4 вопроса → чипы 4 цветов (emerald/teal(lighthouse)/rose/amber, X-удаление), GET /api/lots с q/topic/employer/employment/region, карточка (звёзды рейтинга, звезда-save, меты ТЗ, разворот через GET /api/lots/[id]?track=1 → details, Откликнуться → Dialog → POST respond), счётчик «мы нашли N заданий».
7. src/components/projects/lots/my-lots.tsx — 397: свои лоты = GET /api/lots?limit=50 + клиентский фильтр employer.id (в контракте нет scope=mine), статистика, «Обновить» (POST boost, 422-текст сервера в тост), «Кандидаты» (responses, развернуть → PATCH view, accept/decline), меню Закрыть/Удалить (ConfirmDialog), «Лотов пока нет. Создайте первый».
8. src/components/projects/lots/create-lot-dialog.tsx — 328: название ≤150 счётчик, бюджет+«по договоренности», срок, datetime-local окончания, формат remote/onsite, роль, регион+datalist, 9 блоков-вопросов + Progress «Заполнено N/9 (обязательных M/3)», публикация с валидацией (тост с конкретикой), «Очистить» → ConfirmDialog.
9. src/app/page.tsx — 167 (145): deep-link ?view=projects&tab=…&projectId=… по паттерну jobs, пропсы projectsTab/deepLinkProjectId/onDeepLinkHandled.

## Проверки (гейты)
- npx tsc --noEmit → 0 ошибок по всему проекту (не только свои файлы).
- bun run lint → 0 ошибок, 0 предупреждений (10 неиспользуемых eslint-disable директив убраны).
- bun test tests/ → 47 pass / 0 fail.
- dev-сервер не запускался/не трогался; dev.log чист (компиляции без ошибок).
- Сторонние запреты соблюдены: не тронуты src/app/api/**, prisma/**, scripts/**, tests/**, AppShell.

## Ключевые решения / ограничения (для координатора)
- Страница проекта = замена таб-контента (Proposal §3.3 «отдельный view вместо Dialog»), не overlay.
- Мультивыбор тематики/региона в Sheet-фильтре отправляет join(',') в одиночные параметры topic/region (контракт их определяет скалярными; бэк contains точен для одного значения) — бэку рекомендуется разбивать по запятой в OR.
- «Мои лоты»: закрытые/удалённые/просроченные лоты недоступны через GET /api/lots (§8 жёстко фильтрует open+acceptUntil>now) — для полноценного кабинета бэку нужен scope=mine (или all=1 для владельца). Пилотно: только открытые свои.
- PremiumNewsRotator: latestComment не входит в ProjectCard (§0) — ротация по promoAnnotation/summary/description (честные данные).
- Медиа ≤2Мб/файл проверяется на клиенте (fileToDataUrl), серверная валидация — на бэке по контракту.
