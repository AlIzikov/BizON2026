# Task 9-e — full-stack-developer (p3-dataplane)

## Task
doc_scaling п.9 Shard-Ready + п.13 RU Data Plane (152-ФЗ): consistent-hash ring, региональный роутинг residency (классы A/B/C × RU/GDPR/none × storage/processing/batch), Repository-фасад с LocalSqliteBinding, GET /api/admin/data-plane, docs/data-plane.md. Зона: src/lib/data-plane/**, api/admin/data-plane/**, docs/data-plane.md — чужие файлы только read-only.

## Work Log (выполнено)
1. Контекст: worklog (8-audit/9-coord/9-a/9-d), /tmp/audit_scaling.md (пп.9/13 были ❌), /tmp/doc_scaling.txt (§2-4, §17, §27-28, ЭТАП 13), sovereignty/gateway.ts v6.1 (pseudonymizeUser уже есть от 9-d), schema.prisma (READ-ONLY), auth-паттерны admin-роутов.
2. `src/lib/data-plane/shard.ts` — SHA-256 consistent-hash ring, 160 vnodes на единицу веса, чистые функции buildRing/resolveShard/shardDistribution/redistributeStats, ключи userId/companyId/jobId.
3. `src/lib/data-plane/config.ts` — плоскости ru-primary/global-compute, 4 шарда (2+2, per-plane кольца, weight=1, sandbox target=local), 11 residency-правил, sandbox.localBinding=true.
4. `src/lib/data-plane/region-router.ts` — decidePlane (fail-closed, ruleId+причина+crossBorder+ownerPseudonym), журнал in-memory TTL 1ч/max 200, pseudonymizeForGlobalCompute через Sovereignty (READ-ONLY).
5. `src/lib/data-plane/repository.ts` — DataPlaneRepository (get/set/delete/route c entity/id/dataClass/owner) + LocalSqliteBinding (allow-list 6 моделей, типизированные unchecked inputs, честные ошибки prisma:P*/prisma-validation, delete идемпотентен).
6. `src/app/api/admin/data-plane/route.ts` — GET: топология, ringStats (600 ключей, probe 5×200), redistribution 2→3 (~1/(N+1)), политика, журнал (честный empty state), самотест 9 контекстов (чистый decidePlane), демо обезличивания; auth: Bearer DATA_PLANE_TOKEN / session+role admin / dev-релаксация (как /api/metrics), без сессии → 401.
7. `docs/data-plane.md` — архитектура, правила, ограничения песочницы, миграция на RU PG + внешние compute.
8. Ops-скрипты: scripts/dataplane-ring-check.ts, scripts/dataplane-repo-smoke.ts.

## Результаты проверок
- eslint (мои файлы) → 0; tsc --noEmit → 0 по всему проекту.
- Ring: детерминизм 1000× stable=true; равномерность макс. откл. 0.42 п.п.; 2→3 шарда: 32.19%/30.43% (теория 33.3%); веса 1:2 → 34.31/65.69%; псевдоним anonymous_user_XXXXX (doc-формат) детерминирован.
- Repo smoke: route→shard совпал с ring; create/update/get/validation-error/delete/идемпотентность — PASS, БД очищена (проверено sqlite).
- curl: bogus session → 401; demo-token → 200 с адекватным JSON (4 шарда×160 vnodes, rules=11, fail-closed семантика подтверждена, recentDecisions=0 + notice, wiredIntoBusinessFlows=false).

## Ключевые решения / контракты для координатора
- Fail-closed: класс A граждан РФ → ru-primary безусловно (ст.18 ч.5 152-ФЗ, согласие не отменяет первичное хранение); класс B на global-compute только при pseudonymized=true, иначе технический отказ маршрута на ru-primary.
- Псевдонимы — SovereigntyGateway.pseudonymizeUser (тот же, что видит LLM) — сквозная аналитика без PII.
- Binding меняется, контракты фасада нет: RuPrimaryPostgresBinding / GlobalComputeBinding по шагам из docs (9-d baseline migrations уже готов).
- Фасад НЕ вшит в чужие потоки (wiredIntoBusinessFlows=false) — обратная совместимость 100%, путь миграции задокументирован.

## Ограничения (честно)
Песочница: физические плоскости не подняты, обе плоскости и все шарды на одной SQLite через существующий db; маршрутизация — метаданные; журнал per-process; GDPR/SCC декларативны; 160 vnodes дают разброс долей в несколько п.п. (прод-ручка — увеличить virtualNodesPerShard).
