# Task ID: 2-f — Agent: full-stack-developer (A14 / A15 / A18 из STUBS-AUDIT-2026-09-10)

Дата: 2026-09-10 · Зона: career-compass, follows, trust-stream/feed-card, morning-brief, feed-подписки-источник

## Что сделано

### A14 — «+N вакансий от навыка» в компасе (реальный счёт)
- **Новый роут** `src/app/api/career-compass/vacancy-count/route.ts`: GET `?skill=...` (withRoute + auth, inline zod min2/max100, rate-limit 60/мин).
  Счёт детерминированный: термины = название области целиком + отдельные слова (≥3 символов) + синонимы из SkillSynonym через **переиспользованный** `buildSynonymIndex()` (тот же слой, что semantic-search и /api/jobs?prof=1; оба направления «синоним↔канон»). Матч по `Job.requiredSkills` (CSV «Навык:L» через `parseRequiredSkillsWithLevels`): точное равенство или substring в обе стороны (гвардия длины ≥4). Пул вакансий: `Job.active=true` — тот же фильтр, что в /api/jobs.
- **career-compass.tsx**: `DomainRow` фетчит счёт по своему домену; чип «+N вакансий» (иконка Briefcase, тач ≥44px) рисуется **только при N>0**; клик → `applyJobsFilter({ q: domain, mode: 'quick' })` + `setView('jobs')` — JobsView реально поддерживает `jobsFilterApply`→`executeSearch` (jobs-view.tsx:299-336), т.е. переход с фильтром честный. Текст «(функция в разработке)» и комментарий-«заглушка» удалены. При N=0/ошибке — чип скрыт, без фейков.

### A15 — подписки на авторов
- **Новый роут** `src/app/api/follows/route.ts` (withRoute + auth, inline zod):
  - POST `{ userId }` → 201 `{ok, following{id,name,title,avatarUrl}}`; гварды: self → **422** «Нельзя подписаться на себя», нет юзера → **404**, дубль → **409** «Вы уже подписаны» (пре-чек + P2002-страховка).
  - DELETE `?userId=` → 200/404 «Подписка не найдена»/400 без параметра. Нюанс: withRoute для DELETE валидирует body, поэтому query валидируется inline той же zod-схемой (задокументировано в коде).
  - GET → `{items:[{id(автора), followId, name, title, avatarUrl, ipScore, followedAt}], total}`.
- **Новый компонент** `src/components/common/follow-button.tsx`: toggle «Подписаться»/«Вы подписаны», оптимистичный UI с откатом+toast, тач ≥44px, на себя не рендерится. Состояние — module-level store (`useSyncExternalStore`): один GET /api/follows на страницу на все кнопки.
- **trust-stream.tsx** (FeedCard→PostCard): FollowButton в шапке карточки после бейджей (в mini-режиме — icon-only, 44px). OneThoughtMode в кодовой базе не найден (grep) — сломать нечего; FeedCard рендерится только из trust-stream. Empty state `favNews` заменён: «Вы ещё не подписаны на авторов. Нажмите «Подписаться» в карточке поста или в профиле автора — их посты появятся здесь.» (без «В Фазе 2»).
- **Источник «Подписок»**: `feed-service.ts` `sub==='favNews'` переключён с proxy «ipScore ≥ 30» на реальный Follow: `db.follow.findMany({followerId:userId})` → `authorId in followingIds` (выбран чистый Follow — название раздела «Подписки на авторов», union с Connection был бы нечестен).
- **ProfileView** (10-минутная правка — сделана): FollowButton в actions чужого профиля рядом с «Добавить в контакты».

### A18 — «ВОЗМОЖНОСТИ» в morning-brief
- Убран фейк `jobsMatched = name.length % 7` и слово «заглушка». В Promise.all добавлен `/api/me/signals` (тот же реальный источник, что у радара BIZON SIGNAL на дашборде — bizon-signal-card.tsx; примечание: /api/me/inbound в кодовой базе не существует, фактический роут возможностей — signals/whats-new).
- Блок показывает **топ-3 реальных сигнала** (иконка по типу skill_trend/new_company/skill_gap_opportunity/market_shift, title+description), клик → SPA-навигация action (externalUrl / company+entityId / setView) — зеркально BizonSignalCard. Empty state честный: «Новых возможностей за ночь нет.». Ссылка «Все возможности» → `setView('me')` (MeView default-таб = whats-new, где радар со всеми сигналами). Мини-статистика «Вакансий подобрано» (opportunitiesCount.jobs) остаётся на дашборде, в брифе не дублируется.

## Верификация
- `bunx tsc --noEmit` → **0 ошибок** (в середине сессии мелькали 2 ошибки в projects-view.tsx — параллельная правка другого агента, сами рассосались; мои файлы ни разу не светились).
- `bun run lint` → **0 errors** (1 pre-existing warning jobs-view.tsx:217 — не мой).
- curl-матрица /api/follows: POST self 422 · POST чужой 201 · дубль 409 · несуществующий 404 · GET 200 (items корректны) · DELETE 200 · повторный DELETE 404 · DELETE без param 400.
- Интеграция favNews: follow «QA3 User A» (4 поста) → `/api/feed?sub=favNews` вернул ровно его 4 поста и ничего больше; после отписки — пусто. **Тестовые Follow удалены: follow count = 0.**
- curl /api/career-compass/vacancy-count: `Data Engineering`→1, `React`→1, `реакт`→1 (SkillSynonym-расширение реально работает — матч в вакансию с requiredSkills «React»), `Frontend-разработка`→0 и `DevOps`→0 (честный ноль), без param→400, мусорная cookie→401.
- dev.log: мои роуты без ошибок (единственный 500 — pre-existing transaction-timeout в /api/jobs/[id]/apply от живого preview-трафика, не моя зона).

## Ограничения / заметки
- Схема не тронута, db:push не запускался, dev-сервер не перезапускался, app-shell/resume-dialog/projects/dao/referral/ai-co-pilot — не тронуты.
- Count-эндпоинт сознательно по requiredSkills (по ТЗ), не по title/description — для областей-«слов без навыков» честно отдаёт 0.
- app-store.ts не редактировался (в нём уже были applyJobsFilter/setJobsCurrentSearchParams) — новых полей не потребовалось.
