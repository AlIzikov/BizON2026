# Task C-e — WCAG 2.2 AA аудит + критические фиксы (Wave C, финал)

Agent: full-stack-developer (Z.ai Code)
Date: 2026-09-10
Полный worklog: `worklog.md` (запись Task ID: C-e). Отчёт: `docs/WCAG-2.2-AA-AUDIT-2026-09-10.md`.

## Что сделано

1. **Аудит** 12 критериев WCAG 2.2 статикой (grep + чтение ~11k строк) + программный расчёт контрастов (oklch→sRGB→WCAG-формула).
2. **7 критических фиксов Level A**:
   - `shell/unified-search-panel.tsx` — результаты поиска были недоступны с клавиатуры (только `onMouseDown`); добавлен `onClick` c `e.detail === 0` (клавиатура), id панели, role="status" на loading.
   - `profile/profile-view.tsx` BreakdownBar: 4 × `div onClick` → `<button>`.
   - `dashboard/dashboard-view.tsx`: 2 × `div onClick` → `<button>`; «aria-label на div без роли» → `role="status"` + sr-only.
   - `projects/project-results-chain.tsx`: «мёртвая» кнопка «Открыть профиль» (title без onClick) → реальная навигация setProfileUserId+setView.
   - `auth/auth-screen.tsx`: dropdown типа аккаунта → listbox/option/aria-selected/aria-expanded.
3. **20 DialogContent без описания** (Radix-ворнинг 4.1.2): 7 реальных `DialogDescription` + 13 файлов `aria-describedby={undefined}`; скрипт-проверка: все DialogContent/AlertDialogContent покрыты.
4. **Контраст 1.4.3** (только существующие токены): `text-success`→`success-text` (2.97→6.97), `emerald-600`→`emerald-700` (3.77→5.48), `amber-600`→`amber-700` (3.19→5.02), `teal-600`→`teal-700` (3.74→5.47), `muted-foreground/40–/80`→без opacity (1.92–4.46→7.40; 58 мест, 34 файла), `bg-emerald-600`+white→`bg-emerald-700` (3.77→5.48), trust-badge CSS-классы → токены warning/success пар.
5. **~40 атрибутов 4.1.2/3.3.2**: aria-label на икон-кнопках (тема, выход, уведомления, аватары, save/compare compact), aria-pressed/expanded (фильтры, лайки, save, выбор контакта, темы, RadioGroup name), aria-busy/role="status" на скелетах, aria-current="page" в навигации.

## Файлы (59 всего)
Целевые: app-shell, unified-search-panel, settings-view, two-factor-card, claim-card, trust-explain-card, evidence-modal, projects-view, project-results-chain, jobs-view, compare-vacancies, job-passport, profile-view, public-persona, dashboard-view, trust-stream, auth-screen, globals.css + 13 файлов aria-describedby + 34 файла контраст-свипа.

## Верификация
`bunx tsc --noEmit` = 0; `bun run lint` = 0 errors (1 пре-warning jobs-view.tsx:217); GET / = 200; dev.log чист. Поведение не изменено: только a11y-атрибуты, семантика, контраст-классы.

## Эталоны (проверены, не тронуты)
one-thought-mode.tsx и my-placements-card.tsx (звёзды radiogroup/aria-checked) — образцовые реализации.

## Честные ограничения
Статика без скринридера/AXE; бордеры контролов `--input` ≈1.19:1 (1.4.11) не чинил (глобальный редизайн — рекомендация в отчёте); кастомные оверлеи без focus-trap/Esc задокументированы; reflow/zoom, 2.5.7/3.3.8/2.4.11 (2.2-only) — не проверяемы статически; dark-контрасты считал по токенам.
