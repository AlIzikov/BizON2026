# W3-1+W3-2 — coder — Work Record

**План:** OWNER-UX-PLAN-2026-09-19, шаги 10-11 из 24 (Волна 3 «Граф доверия = рабочий инструмент»)
**Статус:** DONE (гейты: bun test 15/0 — 63 expect; tsc скоупами 0 ошибок; lint 0; live-smoke /api/trust-graph → 401 не 500; dev.log чист)
**Следующим агентам:** page.tsx/app-shell.tsx не тронуты (вне зоны); W3-3/W3-4 монтируют TrustChainBlock дальше — IntroRequestButton теперь ЭКСПОРТИРОВАН из trust-chain-block.tsx (не ломает существующих импортёров).

## Что сделано

| Задача | Файлы: строки | Суть |
|---|---|---|
| W3-1 API | src/app/api/trust-graph/route.ts (56→96) | АДДИТИВНО: 1-hop рёбра получили connectionId/kind/lastVerifiedAt(ISO)/discoverable + reasons[{type,label}] (computeContactReasons посчитан СЕРВЕРНО для пар «я↔узел» — выбран вариант «вложил в payload», меньше кода чем ?explain=); ПРИВАТНОСТЬ: ipScore чужих узлов не отдаётся (select level вместо ipScore), ipScore только у центрального узла; me.discoverable — состояние тумблера (connections.every, 0 рёбер → true) |
| W3-1 reasons | src/lib/trust/contact-reasons.ts (+32) | Ветка common_skills РЕАЛИЗОВАНА: UserSkill обоих по Skill.name case-insensitive (Set lowercase), explanation «Общие навыки: <до 3>», score 0.5 (между recommendation 0.7 и community 0.4); нумерация веток 3→4→5 сдвинута |
| W3-2 API | src/app/api/me/network-visibility/route.ts (НОВЫЙ, 33) | PATCH {discoverable:bool} (zod, withRoute auth) → db.connection.updateMany OR from/to (ВСЕ мои рёбра, любые статусы); ответ {updated: N, discoverable}; честное ограничение «per-edge модель, UX-переключатель глобальный; индивидуальные рёбра — позже» задокументировано в док-шапке |
| W3-2 экспорт | src/components/profile/trust-chain-block.tsx:197-199 | IntroRequestButton экспортирован (тело не менялось) — переиспользование из графа |
| W3-1 UI | src/components/trust-graph/trust-graph-view.tsx (74→795) | Кнопка «Что это значит» → Dialog: (1) «Ваш IP-score» — живой /api/me/trust-explain при открытии (число/уровень/8 factors label+value+description, честные «Нет данных» приходят с роута; кэш в стейте на жизнь компонента); (2) «Линии (рёбра)» — толстая=прямая (1-е рукопожатие), тонкая=через друга (0.5), зелёная=путь; затухание человеческим языком («вдвое за 14 месяцев», «подтвердите — окрепнет»); (3) «Узлы» — ipScore только в своём кружке, инициал в чужих, уровень в тултипе, клик = панель действий. Тултип узла (SVG <title>): имя·title·уровень·«Почему связаны: …» из edge.reasons, пусто → «Прямая связь (принятое знакомство)». ВНУТРИ чужого кружка ipScore заменён на инициал (приватность) |
| W3-2 UI поиск | trust-graph-view.tsx | Инпут «К кому выстроить путь?» — debounce 300мс → ГОТОВЫЙ /api/users/search?q=&limit=8 (себя исключаю), dropdown max-h-48 overflow-y-auto; выбор → POST /api/ai/matchmaker |
| W3-2 UI путь | trust-graph-view.tsx | found & path>2: подсветка пути на SVG (узлы/рёбра emerald oklch(0.62 0.16 160), цель amber oklch(0.75 0.14 75), остальные приглушены), чипы «Вы → Мария → Борис», IntroRequestButton (introducer=path[1]); found & path==2: «напрямую» + «Написать» (MessageComposeDialog {userId,userName,open,onOpenChange}); !found: цель в 1-hop → «Вы уже связаны», иначе «Цепочка длиннее 5 рукопожатий — путь не найден» |
| W3-2 UI verify | trust-graph-view.tsx | Клик узла → панель (не сразу профиль): 1-hop — «Почему связаны» + Select kind (5 вариантов, дефолт colleague, сброс при смене узла) + «Подтвердить связь» → POST /api/connections/[connectionId]/verify → тост «Связь подтверждена — она окрепла», edge.lastVerifiedAt обновляется локально; lastVerifiedAt <30 дней → «Подтверждено <дата>» вместо кнопки; 2-hop — «Связь через ваших знакомых»; везде «Открыть профиль»/«Написать» |
| W3-2 UI тумблер | trust-graph-view.tsx | Switch «Показывать меня в цепочках» над графом (состояние из me.discoverable): PATCH → тост «Вас видно в цепочках»/«Вы скрыты из цепочек», оптимистичный апдейт с откатом при ошибке; легенда дополняется «Путь до цели» при активном пути |
| Тесты | tests/owner-w3-graph.test.ts (НОВЫЙ, 15 кейсов) | Инпроцесс по образцу owner-w1: common_skills hit с 'React' + отсутствие на паре без навыков; trust-graph: чужие узлы без ipScore ('ipScore' in n === false), центр с ipScore, 1-hop ребро с connectionId/kind=colleague/discoverable/reasons (common_skills с 'React' end-to-end), 2-hop без connectionId, me.discoverable, 401; network-visibility: 401, false→БД false (updated=2, чужое B–C не тронуто), true→обратно, {}→400; статик: 4 обязательные фразы в view, переиспользование IntroRequestButton/MessageComposeDialog, в route.ts нет 'ipScore: other.ipScore'; export IntroRequestButton typeof==='function'; live-smoke 401 мягкий |

## Решения/трактовки (честно)

1. **reasons в payload, а не ?explain=** — сервер и так знает пары; меньше кода (0 клиентских запросов, тултип мгновенный). Нагрузка: computeContactReasons на 1-hop рёбра (кап 50) — приемлемо для SQLite in-process.
2. **Клик по узлу теперь выделяет и открывает панель действий** (раньше — сразу профиль): «Подтвердить связь»/«Написать» живут в панели; «Открыть профиль» — кнопкой. Задокументировано в док-шапке компонента.
3. **2-hop семантика роута сохранена как была** (рёбра МЕЖДУ прямыми связями: fromUserId in my AND toUserId in my) — фиксстеры теста построены под это (A–B, A–C, B–C). connectionId/kind на чужих 2-hop рёбрах не отдаю (не ваши связи).
4. **visibility PATCH идёт по рёбрам ЛЮБОГО статуса** (pending/accepted) — отложенные запросы при accept унаследуют выбор приватности; задокументировано.
5. **Инициал вместо уровня внутри чужого кружка** (задача допускала «уровень ИЛИ инициал») — уровень длинный для r=16, он виден в тултипе и панели.

## Хвосты для следующих агентов

- W3-3 (TrustChainBlock): путь на графе и в блоке профиля считают один и тот же матчмейкер — при добавлении выбора посредника (W3-3) достаточно менять trust-chain-block.tsx.
- W3-4: intro-accept создаёт Connection(provenance='intro') — новые рёбра автоматически попадут в граф с reasons.
- Тумблер глобальный; если владелец захочет per-edge скрытие — точечный PATCH /api/connections/[id] (поле уже в payload графа).

## Гейты (числа)

- bun test tests/owner-w3-graph.test.ts — 15 pass / 0 fail (63 expect).
- Регресс: owner-w0-2 21/0, owner-w1 21/0, owner-w2 18/0; owner-w0-1 13 pass / 2 fail — те же 2 известные средовые фейла live-smoke (логин test.private@bizon.demo → 401 backoff на живом сервере; сами роуты отвечают: unauth curl → 401, не 500), зафиксировано ещё в W1/W0-2.
- tsc: скоуп серверной зоны (route.ts ×3 + contact-reasons + matchmaker) → exit 0; скоуп UI (trust-graph-view + trust-chain-block + message-compose-dialog) → exit 0; конфиги удалены после прогона.
- bun run lint — exit 0.
- Live-smoke: GET /api/trust-graph → 401; PATCH /api/me/network-visibility → 401 (роут компилится на dev); GET / → 200; dev.log без 500/ошибок компиляции.
