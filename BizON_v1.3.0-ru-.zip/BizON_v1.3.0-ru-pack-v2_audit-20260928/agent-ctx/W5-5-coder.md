# W5-5 — coder — Запись о работе

**Дата:** 2026-09-19 · **План:** OWNER-UX-PLAN-2026-09-19, шаг 22 из 24, Волна 5 · **Статус:** DONE (гейты зелёные, live-проверено)

## Что сделано

### STORE (src/stores/app-store.ts)
- `NetworkSubTab = 'contacts' | 'birthdays'` (по паттерну ProfileSubTab W4-1) + state `networkSubTab: 'contacts'` + экшен `setNetworkSubTab`. **НЕ в partialize** (персистится только `view`) — guard-тест на исходник.

### СЕРВИС-ГЕНЕРАТОР (НОВЫЙ src/lib/services/birthday-notify-service.ts)
- `ensureBirthdayNotification(userId, {now?, names?})` — self-уведомление «сегодня ДР у X» через `NotificationService.notify` (type='birthday', fail-open внутри).
- **Дизайн ключа идемпотентности:** dayKey = `YYYY-MM-DD` (серверное локальное время); детерминированная пара «пользователь×день» разложена в СУЩЕСТВУЮЩИЕ поля Notification БЕЗ миграций: `link = /network?birthday=<dayKey>` (точное равенство по userId+type+link в query-before-create) + `metadata = {dayKey, names}` (наблюдаемость). Уникальность: findFirst → create; доп. страховка — кэш процесса `Map<userId, dayKey>` (SSE-поллинг не дёргает БД на каждый tick; негативный результат «празднующих нет» тоже кэшируется на день — задокументировано).
- `BIRTHDAY_NOTIFY_HONEST_NOTE` = «Уведомления о днях рождения приходят один раз в день и только вам — именинник не уведомляется, пока вы сами не поздравите» (конвенция HONEST_NOTE, как birthday-plans/route.ts).
- Экспорты добавлены в src/lib/services/index.ts (аддитивно).

### TRIGGERS (оба)
- **(а)** GET /api/network/birthdays — после сборки данных передаёт в генератор уже посчитанные имена `today` (ноль доп. запросов связей), FAIL-OPEN.
- **(б)** GET /api/notifications/stream (SSE, W2-3) — при коннекте И на каждом poll-тике (кэш делает тик дешёвым Map-lookup); `lastSentAt` инициализируется ДО триггера, чтобы созданное уведомление ушло клиенту первым же тиком.

### WHITELIST (src/lib/services/notification-service.ts)
- `NOTIFICATION_TYPES` + 'birthday' (8-й тип), `NotificationSettings.birthday` + дефолт `'instant'` + fallback в safeParseSettings — по паттерну bizcard_share (W5-1). Settings-роут итерирует whitelist — совместимо автоматически.

### API /api/network/birthdays (аддитивно)
- Ответ расширен: `tomorrow` (daysLeft === 1 — для виджета RightRail), `all` (все контакты с известной датой, сортировка по daysLeft asc — для таба «Все»), `honestNote`. Прежние `today/thisMonth/total/checkedAt` не тронуты — потребители не сломаны. Контакт без birthday по-прежнему не попадает ни в один массив (честность).

### API /api/birthday-plans (аддитивно)
- GET возвращает доп. поле `incoming`: чужие BirthdayPlan, где requester = personUserId (входящие «вас поздравят») — plannerUserId/plannerName/дата/канал/статус, **без comment** (заметка планировщика — приватная). `plans` (исходящие) не изменён. PATCH/DELETE не тронуты.

### UI
- **src/components/network/birthdays-panel.tsx — переписан в подстраницу `BirthdaysSubPage`** (панель ушла с боковой панели по решению владельца): shadcn Tabs «Все / Сегодня / В этом месяце / Мои планы» со счётчиками; «Все» — по ближайшести (дата + daysLeft + кнопки Поздравить/Запланировать); «Сегодня» — карточки с «Отправить поздравление» (POST /api/messages, переиспользован CongratulateDialog); «Мои планы» — исходящие (канал, comment, «Выполнен» PATCH done / удалить DELETE, «Запланировать» → переиспользованный BirthdayPlanDialog с пропсами open/onOpenChange/presetPerson/onCreated) + входящие read-only; честные пустые состояния («Нет данных о днях рождения — у контактов не заполнено поле birthday»); HONEST_NOTE из API выводится под контентом; списки в max-h + scroll-area-thin.
- **src/components/network/network-view.tsx:** ранний return при `networkSubTab === 'birthdays'` (паттерн profile-view W4-1) — шапка «Контакты» + табы + подстраница; табы `NetworkSubTabs` («Контакты | Дни рождения») в обеих ветках; правая панель упрощена: вместо BirthdaysPanel — `BirthdaysAsideTeaser` (счётчики сегодня/завтра + кнопка `setNetworkSubTab('birthdays')`), BizCardDialog W5-2 остался.
- **src/components/shell/app-shell.tsx:** `BirthdaysQuickWidget` в RightRail «Быстрых действий» после «Моя визитка» — Сегодня: имена (≤3 + «+N ещё») / нет; Завтра: имена / нет; клик → `setNetworkSubTab('birthdays') + setView('network')` (setProfileUserId НЕ нужен — network-view не читает его); данные GET /api/network/birthdays, лениво через 1.5с (паттерн ad-загрузки RightRail). + иконка Cake в импорты.

## Тесты (tests/owner-w55.test.ts — новый, 17 кейсов, 120 expect, инпроцесс)
- (а) идемпотентность: 3× GET → ровно 1 Notification type='birthday' (link=dayKey, metadata, title с именем); «следующий день» (подмена now в вызове генератора) → второй инстанс; повторы того же дня (кэш + skippedExisting) не размножают; пустой today → 0 уведомлений.
- (б) честность: today/tomorrow/thisMonth/all корректны (fixtures от реального «сегодня», день «в месяце» ≠ сегодня/≠ завтра, безопасно для февраля/конца месяца); контакт без birthday нигде не показан; honestNote в ответе.
- (г) планы: POST (200 — прежний контракт) → plans владельца + scheduled:false/note; получатель видит incoming БЕЗ comment; PATCH done; DELETE.
- (в) статики: табы подстраницы, ранний return, BirthdaysAsideTeaser, BirthdaysQuickWidget («Завтра:», setView('network')), NetworkSubTab не в partialize, 'birthday' в whitelist, ensureBirthdayNotification в обоих триггерах.
- (д) 401: birthdays GET, plans GET/POST, plan PATCH/DELETE. (е) live-smoke :3000 без auth → 401 (мягкий пропуск).

## Гейты (все зелёные)
- `bun test tests/owner-w55.test.ts` — **17 pass / 0 fail** (120 expect)
- Регресс: owner-w53 + owner-w5-bizcard + owner-w42 + owner-w4 = **86/0**; доп-регресс owner-w2 + kv2-outbox + wave1-trust + owner-w13-w33 = **63/0**
- tsc скоупом (временный tsconfig на 11 файлов, УДАЛЁН): в моих файлах **0**; pre-existing базлайн: company-passport-service.ts 181/187/194, tests/helpers/setup.ts:36
- `bun run lint` — **0 errors** / 5 pre-existing warnings (bizcard-* W5-1/2)
- Live (:3000): GET / → **200**; GET /api/network/birthdays без auth → **401**, с auth (ivan@bizon.ru) → 200 с tomorrow/all/honestNote; GET /api/birthday-plans без auth → 401, с auth → 200 {plans, incoming}; dev.log — без RangeError/500 в моих роутах (только pre-existing [decrypt] legacy-warn демо-логина)

## Файлы
- НОВЫЕ: `src/lib/services/birthday-notify-service.ts`, `tests/owner-w55.test.ts`, `agent-ctx/W5-5-coder.md`
- ПРАВКИ: `src/stores/app-store.ts`, `src/lib/services/notification-service.ts`, `src/lib/services/index.ts`, `src/app/api/network/birthdays/route.ts`, `src/app/api/notifications/stream/route.ts`, `src/app/api/birthday-plans/route.ts`, `src/components/network/birthdays-panel.tsx` (переписан в подстраницу), `src/components/network/network-view.tsx`, `src/components/shell/app-shell.tsx`
- НЕ ТРОНУТЫ: prisma/schema.prisma (нет миграций — BirthdayPlan переиспользован как есть), src/instrumentation.ts, src/middleware.ts, контракты W2/W5-3 (280/letters/bizcard), tests/owner-w53.test.ts и чужие тесты

## Отклонения от брифа (осознанные)
1. **BirthdayPlan не имеет поля receiver** (в схеме ownerId/personUserId) — «входящие» определены как планы, где requester указан personUserId у ДРУГОГО владельца; без миграций это единственная честная трактовка.
2. **Комментарий планировщика не показывается получателю во «входящих»** (бриф требует только «планы с каналами»): comment — личная заметка «что сделать» («купить подарок…»); раскрывать её человеку, о котором она, — дыра приватности.
3. **Негативный результат кэшируется на день** (по брифу «кэш Map<userId, dayKey>»): контакт с сегодняшним ДР, добавленный ПОСЛЕ первого обращения за день, не догоняется уведомлением сегодня — задокументировано в шапке сервиса; страховка — планы («Запланировать») и следующий год.
4. **Теоретическая параллельная гонка query-before-create**: без unique-индекса (миграции запрещены шагом) два ТОЧНО параллельных вызова из разных процессов могут создать второй инстанс; в одном процессе Next.js защищает кэш. Задокументировано, тест идемпотентности (последовательный) зелёный.
5. **«Мои планы» использует GET /api/birthday-plans 200-контракт как есть** (POST возвращает 200, не 201 — прежнее поведение не ломалось).
