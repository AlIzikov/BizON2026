# W1-3+W3-3 — coder — Запись о работе

**Дата:** 2026-09-19 · **План:** OWNER-UX-PLAN-2026-09-19, шаги 13-14 из 24 · **Статус:** DONE (гейты зелёные, live-проверено)

## Что сделано

### Волна 1 — W1-3 «Отзывы о человеке»
- **W1-3a** `src/app/api/users/[id]/review-eligibility/route.ts` (НОВЫЙ): GET → 401/404 → `{eligible, reasons, strongest, commonProjects}`. Движок — `checkPersonReviewEligibility` (W1-1); `commonProjects` добавлен в сервис **аддитивно** (плоская проекция project-evidence) + причина-отказ «Нет подтверждённых взаимодействий…» (принцип №3, симметрично company-варианту).
- **W1-3b** Блок «Отзывы» в `profile-view.tsx` (`ReviewsBlock`, монтируется только на чужом профиле под CommonContactsBlock): текст, бейдж wouldWorkAgain, проект-доказательство (клик → проект), автор (клик → профиль), дата; `scoreInternal` не рендерится (§3.3). Кнопка «Оставить отзыв»: eligibility на монтировании; `strongest='project'` → радио commonProjects + форма (text ≤2000, Switch) → **существующий** POST `/api/projects/<id>/reviews` (гейт «только участники» переиспользован); `!eligible` → диалог-объяснение + reasons; **contact-only → кнопка скрыта** (гейт = только общий проект, по ТЗ); сбой eligibility → fail-closed. Ошибки (409 дедуп и др.) — тост с текстом сервера.
- **Источник данных** (осознанное расширение зоны, задокументировано): `src/app/api/users/[id]/reviews/route.ts` (НОВЫЙ) — ProjectReview subjectId=профиль + author/project, auth-required (как GET /api/users/[id]), **scoreInternal не покидает сервер** (проверено тестом по сырому JSON).
- **W1-3c** Сегмент IP-score «Отзывы и рейтинги 30%»: фиктивная `(projectsCount ?? 0) * 5` удалена. **Формула: `value = min(30, received × 10)`**, где received = |ProjectReview subjectId=профиль|; 0 → «Нет данных», N → «N подтверждённых отзывов» (склонение). `BreakdownBar` +опциональный `caption`. Данные грузятся всегда (свой+чужой).

### Волна 3 — W3-3 «Выстроить цепочку контактов»
- **W3-3a** `src/lib/matchmaker.ts`: `findHandshakePaths(from, to, limit=4)` — BFS-перечисление путей (REUSE `getNeighbors`, depth ≤5, пути ≥2 рёбер, дедуп, приоритет РАЗНЫМ посредникам, кап 300 раскрытий). Роут `src/app/api/ai/matchmaker/paths/route.ts` (НОВЫЙ): GET ?targetId= → 401/400/404, свой лимит `checkUserRateLimit('ai:matchmaker-paths', 30/час)` (лимит основного POST не тронут, ReputationEvent не пишет) → `{paths: [{mediatorId, mediatorName, path:[{id,name}], hops}]}`.
- **W3-3b** `intro-service.create(..., mediatorId?)`: mediatorId передан → валидация ОБЕИХ accepted-связей (медиатор↔requester И медиатор↔target), иначе **422 «Выбранный посредник не связан с вами или с целью»**; findMatch пропускается; уведомление — выбранному. `intros/route.ts`: zod +`mediatorId` (после targetId). BizonError 422 маппится withRoute автоматически.
- **W3-3c** `trust-chain-block.tsx`: CTA **«Выстроить цепочку контактов»** (запускает матчмейкер, автозапуск сохранён); 1 хоп → **«Написать напрямую»** + «Вы уже знакомы — интро не нужно» (IntroRequestButton скрыт); ≥2 хопов → /paths → >1 пути: радио «через кого» (имя + hops), выбранный `mediatorId` → IntroRequestButton (новый опциональный проп) → POST /api/intros; **дефолт без явного выбора — серверный findMatch** (без регресса); «Попросить рекомендацию у посредника» (Sparkles) → MessageComposeDialog с initialDraft-черновиком; пусто → прежнее честное сообщение. `message-compose-dialog.tsx`: +опциональный `initialDraft` (аддитивно).

## Файлы
- НОВЫЕ: `src/app/api/users/[id]/review-eligibility/route.ts`, `src/app/api/users/[id]/reviews/route.ts`, `src/app/api/ai/matchmaker/paths/route.ts`, `tests/owner-w13-w33.test.ts`
- ПРАВКИ: `src/lib/services/review-eligibility-service.ts` (аддитивно), `src/lib/matchmaker.ts` (+findHandshakePaths, export generateIntroTemplate), `src/lib/services/intro-service.ts` (только create()), `src/app/api/intros/route.ts`, `src/components/profile/profile-view.tsx`, `src/components/profile/trust-chain-block.tsx`, `src/components/messages/message-compose-dialog.tsx`

## Гейты (все зелёные)
- `bun test tests/owner-w13-w33.test.ts` — **24 pass / 0 fail** (81 expect)
- Регресс: owner-w3-conn+owner-w1+owner-w0-2+owner-w3-graph = **74/0**; owner-w2+wave1-trust = **34/0**
- tsc скоупами (конфиги удалены): серверная зона **0**, UI-зона **0**, тест-скоуп — 0 в моём файле (pre-existing `tests/helpers/setup.ts:36`, общий хелпер)
- `bun run lint` — exit 0
- Live (:3000, ivan@bizon.ru): 3 новых роута без auth → 401; self-eligibility → «себе»; Мария → eligible/strongest=project/commonProjects=[«QA Limit Test 1»]; /paths → **4 пути с разными посредниками** (hops=2); dev.log — 0 ошибок/500 (только pre-existing [decrypt] legacy-warn)

## Решения по умолчанию (задокументированы в коде)
1. mediatorId валидируется строго по accepted-связям (по ТЗ) — медиатор «только соучастник проекта» получит честный 422-тост; UI передаёт mediatorId только при явном выборе в радио.
2. GET /api/users/[id]/reviews — auth-required (консистентно с FIX-02 профиля).
3. `<контекст>` в черновике рекомендации — обобщённый («общие проекты и связи в BizON»), пользователь правит.
4. Кнопка «Оставить отзыв» видна и при !eligible (диалог-объяснение — по образцу W1-2); при contact-only — скрыта (по ТЗ W1-3b).

## Вне зоны (не тронуто)
- `tests/helpers/setup.ts:36` — pre-existing tsc (bun-types, общий хелпер);
- Браузерная проводка золотого пути «через 2 рукопожатия» — по плану в W6-1 (приёмка).
