# BizON v6 — Prisma Migrations (PostgreSQL)

Task 9-d, doc_scaling §5 (SQLite → PostgreSQL), §26 (P0: «сделать нормальные
migrations», «убрать prisma db push --accept-data-loss»).

## Что здесь

| Файл | Назначение |
|---|---|
| `migration_lock.toml` | Провайдер миграций: **postgresql**. Prisma запрещает менять его после первой миграции — миграции пишутся только под PG. |
| `0001_baseline/migration.sql` | Baseline: полный PostgreSQL-DDL зеркал текущей `prisma/schema.prisma` (63 модели, индексы, unique, FK). Сгенерирован детерминированно `prisma migrate diff --from-empty --to-schema-datamodel` и hand-reviewed. |

## Почему `schema.prisma` остался на SQLite (осознанно)

Песочница проекта работает на локальном файле SQLite (`db/custom.db`), менять
`provider` в схеме сейчас нельзя: мгновенно сломаются dev-сервер, демо-данные и
параллельные агенты. Компромисс зафиксирован координатором (Task 9-coord):
**provider = "sqlite" в схеме, provider = "postgresql" в миграциях**. Baseline
гарантирует, что путь на PG подготовлен: схема БД воспроизводится одной командой,
когда будет доступен настоящий PG.

## Путь SQLite → PostgreSQL (как применять)

### Шаг 1. Поднять PostgreSQL

```bash
# deploy/docker-compose.yml уже содержит postgres:16-alpine
docker compose -f deploy/docker-compose.yml up -d postgres
```

### Шаг 2. Переключить провайдер в схеме (единственная правка)

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

`DATABASE_URL` пример: `postgresql://bizon:bizon@localhost:5432/bizon?schema=public`.

### Шаг 3. Применить baseline

```bash
# На ЧИСТОЙ базе (первый деплой):
bunx prisma migrate deploy          # применит 0001_baseline, отметит в _prisma_migrations

# Перенос данных с текущего SQLite (если нужны существующие записи):
bunx prisma db execute --file prisma/migrations/0001_baseline/migration.sql --schema prisma/schema.prisma
# затем перенести данные (pgloader / scripts/backup-db.sh + ETL-скрипт).
```

На действующей PG-базе дальше — только `prisma migrate dev` (генерирует
следующие миграции) и `prisma migrate deploy` (в CI/контейнере).

### Шаг 4. Точка старта контейнера

`deploy/Dockerfile` сейчас стартует `node server.js` без миграций. Для PG-деплоя
CMD должен стать (doc_scaling P0: migrate deploy при старте):

```dockerfile
CMD ["sh", "-c", "npx prisma migrate deploy && node server.js"]
```

## Что учесть при переносе (чек-лист)

- **Типы**: Prisma-маппинг SQLite→PG уже отражён в DDL — `String→TEXT`,
  `DateTime→TIMESTAMP(3)`, `Boolean→BOOLEAN`, `Int→INTEGER`, `Float→DOUBLE
  PRECISION`, `Json→JSONB`. Схема НЕ содержит `enum`-типов и
  `autoincrement()` — все «enum» это TEXT + app-валидация, ID — cuid
  (app-level), поэтому миграция механическая.
- **JSON-как-строки**: поля вроде `preferences`, `notificationSettings`,
  `backupCodes` хранят JSON в TEXT. На PG можно постепенно переезжать на
  `Json`/`JSONB` — только через новые миграции, не в baseline.
- **Регистронезависимый поиск**: SQLite `LIKE` нечувствителен к регистру, PG —
  чувствителен. Запросы `contains` в сервисах (поиск, лента) на PG требуют
  `mode: 'insensitive'` или pg_trgm/GIN-индекс. Это отдельная ревизия кода.
- **Даты**: SQLite хранит даты как строки — на PG сравнения `DateTime` станут
  строгими (без «string в DateTime-поле»). Код, пишущий сырые строки, надо
  проверять при переносе.
- **Булевы/целые**: SQLite допускал `0/1` из сырых SQL-запросов; через Prisma
  это прозрачно, но raw-запросы (`$queryRaw`) при переезде требуют PG-синтаксиса.
- **Конкурентность**: PG даст реальные транзакции и row-level блокировки —
  последовательные `findUnique`+`update` в сервисах можно (но не обязано)
  переводить на `updateMany`/транзакции.
- **`_prisma_migrations`**: таблица журнала миграций создаётся Prisma
  автоматически при `migrate deploy`; вручную её не создавать.
- **Бэкапы**: `scripts/backup-db.sh` (SQLite-файл) на PG заменяется
  `pg_dump`/WAL-архивом (doc_scaling §27 пп. 28-29 Backup/DR).

## Почему не `prisma db push`

`db push` не оставляет истории изменений и требует `--accept-data-loss` — это
прямой антипаттерн production (doc_scaling §26 п.4-5). Миграции дают:
воспроизводимую схему, диффы в code review, откат и журнал применений.
