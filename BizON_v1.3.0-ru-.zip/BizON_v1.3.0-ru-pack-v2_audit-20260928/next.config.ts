import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

// R5-P2 · next-intl groundwork (без i18n-роутинга — канон «без фанатизма»):
// next-intl v4 подключён конфигурацией «without i18n routing» — существующие
// пути НЕ меняются, locale по умолчанию ru, en доступен через cookie NEXT_LOCALE.
// Сообщения: messages/ru.json + messages/en.json (seed-набор).
// Потребители подключаются постепенно (NextIntlClientProvider / useTranslations).
const withNextIntl = createNextIntlPlugin("./src/i18n/request.ts");

// W1.11 (DEF-29): CSP frame-ancestors разделён по средам.
//  • production  — только 'self' (никаких localhost/preview wildcard)
//    + X-Frame-Options: SAMEORIGIN;
//  • development — 'self' + localhost + allowlist доменов песочницы Z.ai:
//    превью-панель песочницы ВСЕГДА встраивает приложение в iframe с origin
//    *.space-z.ai / *.z.ai, а .env пересоздаётся загрузчиком контейнера при
//    каждом старте, поэтому включать allowlist через переменную окружения
//    (BIZON_SANDBOX_PREVIEW) в dev нельзя — добавлен в код по умолчанию.
//    FIX-2026-09-15: до этого dev-политика содержала только localhost, из-за
//    чего превью падало с ERR_BLOCKED_BY_RESPONSE.
// Больше НЕ единая политика с localhost-wildcard на все среды (была дыра
// clickjacking/embedding в production). HSTS и полный CSP — на Caddy (Caddyfile).
const isProd = process.env.NODE_ENV === "production";

function frameAncestors(): string {
  if (isProd) {
    return "frame-ancestors 'self'";
  }
  return (
    "frame-ancestors 'self' http://localhost:* http://127.0.0.1:* " +
    "https://*.space-z.ai https://space-z.ai https://*.z.ai https://z.ai"
  );
}

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    // FIX-09 (аудит, код #10 / P2): сборка не должна проходить с type-ошибками.
    // tsc --noEmit чистый (strict, noImplicitAny: true) — держим gate включённым.
    ignoreBuildErrors: false,
  },
  reactStrictMode: false,

  // === Security headers (FIX-01, аудит P0-1/P1-6; W1.11: средо-зависимый CSP) ===
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          {
            key: "Content-Security-Policy",
            value: frameAncestors(),
          },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
          ...(isProd
            ? [{ key: "X-Frame-Options", value: "SAMEORIGIN" }]
            : []),
        ],
      },
    ];
  },
};

export default withNextIntl(nextConfig);
