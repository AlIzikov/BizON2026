# BIZON — KV2 · КОНТРОЛЬНЫЙ АДДЕНДУМ К ПЛАНУ-V2 («ДОДЕЛОК»)
Принят: 19.09.2026 (trace 1a0b87e426236205, приказ владельца)
Статус: ДОКУМЕНТ-ДОДЕЛОК — единственный источник порядка работ ПОВЕРХ закрытого Плана-v2 (155/155).
Основание: внешний аудит docs/audit/AUDIT-REPORT-2026-09-19.md (~70% READY / ~25% PARTIAL/DOC-MISMATCH).
Правила ведения: как PLAN-V2-STEPS (статусы PENDING/IN_PROGRESS/DONE/BLOCKED, каждая запись в worklog, приёмка §21 протокола).

---

## ДИАГНОЗ ОДНОЙ СТРОКОЙ
Бэкенд-ядро всех волн работает (225/225 тестов), но у ядра нет пользовательских «дверей»:
UI-проводка оборвана на 5 ключевых циклах + честность статусов/метрик завышена + демо-данные
загрязнили живую ленту. KV2 = открыть двери, выровнять честность, почистить данные.

## P0 — ОТКРЫТЬ ЗАКРЫТЫЕ ЦИКЛЫ (18 шагов)
| ID | Статус | Шаг | DoD |
|---|---|---|---|
| D-01 | PENDING | Карточка «Путь доверия» на профиле чужого + кнопка «Запросить знакомство» → POST /api/intros | Браузерный цикл: путь виден → запрос создан → получатель видит в инбоксе → accept → сообщение открыто; скриншоты в specs |
| D-02 | PENDING | Интро-инбокс в «Контактах» (входящие/исходящие, accept/decline) | UI вызывает существующий API; тесты UI→API |
| D-03 | PENDING | Честный UI жалоб: диалог 7 категорий → POST /api/complaints; убрать fake-тост three-dots-menu.tsx:35 | Fake-success исчез; adversarial на дедуп жалоб |
| D-04 | PARTIAL (скорректировано R2) | Дверь вакансий УЖЕ ЕСТЬ: company-dashboard.tsx:108→POST /api/jobs (смонтирован page.tsx:113). Остаток: мёртвый fab-create-dialogs.tsx + FAB-тупик «Фаза 2» (app-shell.tsx:838) — подключить или удалить; «Мои вакансии» | FAB ведёт к реальной форме; список своих вакансий |
| D-05 | PENDING | VC-экспорт W3C в Настройках → /api/me/credentials → скачивание JSON | Файл скачивается, JSON валиден, proof проверяем |

## P1 — ЧЕСТНОСТЬ И ЗАМЕТНЫЕ ДЫРЫ (10 шагов)
| ID | Статус | Шаг |
|---|---|---|
| D-06 | PENDING | Честные названия: «trend-v1 (эвристика)» вместо LSTM/Prophet; «graph-heuristics-v2» вместо GNN; «career-match-v0» вместо BERT. Интерфейсы не трогать |
| D-07 | PENDING | Внешний ground truth CareerMatcher (30–50 размеченных пар) → честный Precision@Top3 в tools/evals/RESULTS.md |
| D-08 | PENDING | Web-push: честный «нет подписки» вместо ok:true/sent:0 |
| D-09 | PENDING | detectTextSync встроить в пайплайн постов + замер FPR на 50 пробах |
| D-10 | PENDING | Режимы профиля contact/stranger по серверному /api/me/relationship |
| D-11 | PENDING | Блок «Похожие возможности» (/related) в UI проекта/вакансии |
| D-12 | PENDING | BIZCARD: серверный PDF A6 (сейчас печать) |
| D-13 | PENDING | Outbox: первые 2 продюсера (user.registered, job.posted) + воркер |

## P2 — ГИГИЕНА (7 шагов)
| ID | Статус | Шаг |
|---|---|---|
| D-14 | PENDING | scripts/cleanup-demo-data.ts: удалить QA/E2E-артефакты из живой БД (посты QA3/E2E, W4 E2E Project, QA Limit/Test) + проверка ленты |
| D-15 | PENDING | Убрать публичную демо-подсказку с экрана входа (за env-флагом) |
| D-16 | PENDING | Копирайт профиля по accountType (юрлицу не предлагать «день рождения») |
| D-17 | PENDING | Дедуп QA-двойников в ленте (входит в D-14) |
| D-18 | PENDING | a11y: description для DialogContent (2 варнинга) |

## ПРОЦЕССНЫЕ МЕРЫ (чтобы не повторялось) — ПРИНЯТЫ К ДЕЙСТВИЮ
1. **G-UI-PERFECT**: UI-шаг закрыт только браузерной проводкой (клик → сетевой запрос → скриншот в specs), grep-гейты для UI запрещены.
2. **4-слойный DoD**: схема/сервис + API + UI-проводка + доказательство поведения. Нет слоя → PARTIAL.
3. **Приёмка вторым взглядом**: §21-отчёты проверяет независимый агент + 4 автодетектора (fake-success, мёртвый экспорт, UI без fetch, API без UI).
4. **Запрет статусных слов без чисел**: «ML/GNN/BERT» только после benchmark с внешним ground truth (§12).
5. **Cleanup-гейт**: перед чек-пойнтом владельца — прогон D-14 и визуальная проверка ленты.
6. **Реестр «ядро/двери»**: два столбца статусов (ядро READY / дверь READY) — владелец видит оба.
7. **Eval-артефакты**: результаты бенчмарков сохраняются в tools/evals/RESULTS.md + JSON (перепроверяемы).

## R2-БЛОК — НАХОДКИ ФЛОТА ПОВТОРНОГО АУДИТА (19.09.2026, консенсус 7 аудиторов)
Реестр: docs/audit/r2/findings.json · Отчёт: docs/audit/r2/R2-CONSOLIDATED-REPORT.md
| ID | Статус | Шаг | Источник |
|---|---|---|---|
| D-19 | PENDING | **P0** LumenService.refundVar: привязать сумму возврата к original.amount + запрет refund после release (примитив печати денег) | R2-001 (A3+A5) |
| D-20 | PENDING | **P0** adminGuard на /api/admin/* (роль admin в withRoute/централизованный isAdmin); убрать хардкод админ-id | R2-002/005 (A4+A7) |
| D-21 | PENDING | **P0** Session.token → sha256-хэш в БД (rehash-on-verify, миграция живых сессий) | R2-003 (A7) |
| D-22 | PENDING | **P1** topup в $transaction; sweep с компенсацией покупателя; TTL/auto-resolution для fulfilled-эскроу | R2-011/012/013 (A2+A5) |
| D-23 | PENDING | **P1** Governance: передавать userId в PolicyEngine (prohibitions в боевом пути); полномочия на pause/resume агентов | R2-006/007 (A3) |
| D-24 | PENDING | **P1** AI Co-Pilot: подключить к боевому POST /api/ai-co-pilot ИЛИ честно маркировать «офлайн-режим» (§16 — запрещён фейк) | R2-008 (A6) |
| D-25 | PENDING | **P1** GDPR-кнопки в Настройках: export-data / delete-account / forget-me (UI к готовым API) | R2-009 (A6) |
| D-26 | PENDING | **P2** PATCH профиля: прекратить двойную запись plaintext+Encrypted (PII); roles/location в /api/users; валидация name/title/email | R2-004/023/025 |
| D-27 | PENDING | **P2** Согласие AI: fail-open → fail-closed для неизвестного юзера; полный блок анализа при consentAiAnalysis=false; verifyChain — проверка генезиса окна | R2-016/017 (A5) |
| D-28 | PENDING | **P2** Демо-гигиена: seed без deleteMany + демо-флаг; cleanup-скрипт (вместе с D-14); токен из middleware в env | R2-010/020 (A6+A1) |
| D-29 | PENDING | **P2** Тесты PaymentService (0 тестов на монетизационном ядре) + кап на /api/lumens/accrue | R2-018/019 (A2) |

## РАЗВИТИЕ АУДИТОРСКОГО КОНТУРА (этот же приказ, trace 1a0b87e426236205)
- **Флот до 7 аудиторов** с разными методиками (static-security, code-review, red-team, dataflow/authz, формальные инварианты, product-wiring, compliance-инструкция) — параллельно, прогрессно.
- **Консенсус**: находка входит в итоговый отчёт только после перекрёстного подтверждения (домен-аудитор + модератор/второй аудитор). Спорные помечаются DISPUTED, опровергнутые — REJECTED (остаются в отчёте для прозрачности).
- **Аудитор-редтимор** работает по фиксированному промпту владельца: «доказать, что BizON ломается; каждую атаку воспроизвести тестом; ничего не чинить; в конце — отчёт».
- База знаний: docs/knowledge/REPO-LEARNING (pr-agent, security-audit-skill, semgrep, codeql, rocq) + существующие щиты (unlazy-гейты, §21, adversarial-наборы, anti-fraud).
- Правила безопасности владельца (5 пунктов) — см. PROJECT-RULES §«Инструкция по безопасности» и DECISIONS.md Решение 6.
