# ADR-005: Разделение секретов по назначению + ротация ключей (поэтапно; немедленная ротация запрещена)

Принят: 22.09.2026 · Аудит 22-09-26 (CRYPTO-010, CRYPTO-011, CRYPTO-013) · Волна W2 (Task 29-f), авто-режим
Статус: ПЛАН + частично исполнено (BIZON1-версионирование шифротекста, security-env.ts, fail-closed).
Полное исполнение — после реализации key-provider и миграционного скрипта; немедленная ротация ключа ЗАПРЕЩЕНА (см. §Порядок).

## Контекст — текущее состояние по факту кода

Один ключ обслуживает все крипто-назначения:

1. **AES-256-GCM шифрование PII** — `BIZON_ENCRYPTION_KEY` (src/lib/security/crypto.ts:71, 108-145:
   emailEncrypted/bioEncrypted/locationEncrypted/phoneEncrypted, twoFactorSecret).
2. **HMAC-SHA256 emailHash** — ТА ЖЕ функция ключа: `hashEmail` = `HMAC-SHA256(getEncryptionKey(), email.toLowerCase())`
   (crypto.ts:173-176). Именно по emailHash идёт логин и поиск пользователя (User.emailHash @unique,
   prisma/schema.prisma:21). Следствие: смена ключа = все emailHash в БД невалидны = ни один аккаунт
   не может войти.
3. **HMAC-подписи governance/VC — фолбэк на ТОТ ЖЕ материал ключа**: policySignature()
   (src/lib/ai-governance/policy-engine.ts:16-31) предпочитает BIZON_POLICY_SIGNING_KEY, но при
   отсутствии читает .bizon-encryption-key; signingKey() VC JWS (src/lib/services/vc-export-service.ts:24-31,
   подпись :77-79) — та же схема с BIZON_VC_SIGNING_KEY. Имена переменных существуют, разделение
   наполовину фиктивно: общий фолбэк-файл = общий ключ.
4. **Dev-fallback keyfile** (FIX-2026-09-15): платформа песочницы пересоздаёт .env при старте
   контейнера → эфемерный ключ ломал emailHash/emailEncrypted ВСЕХ после каждого рестарта. Решение —
   стабильный keyfile `.bizon-encryption-key` (0o600, вне git), DEV-ONLY: в production ветка
   недостижима — instrumentation.ts бросает без env-ключа (src/instrumentation.ts:33-40) + дубль-throw
   в crypto.ts:88-93; формат 64-hex обязательный (CRYPTO-002/016: crypto.ts:77-81,
   src/lib/config/security-env.ts:33-35, 50-59). Этот же файл — фолбэк пункта 3.

Цена одного ключа уже выплачена дважды («эон-проблема»):
- 29-b: скан живой db/custom.db текущим ключом — 0 из 79 непустых *Encrypted/twoFactorSecret
  расшифровываются (все — legacy-эпохи эфемерных/пересозданных ключей).
- 29-W1-gate: keyfile пересоздан песочницей 22-09 20:22 → все emailHash невалидны → НИ ОДИН аккаунт
  не логинился (owner/qa → 401); ремонт — scripts/reset-demo-passwords.ts (10/10) +
  scripts/repair-canonical-accounts.ts (REPAIR-IDENTITY).

Валидация секретов сейчас: security-env.ts — requireEnv (пусто/нет → throw с именем переменной),
getSecurityConfig() (BIZON_ENCRYPTION_KEY обязателен + 64-hex). В шапке файла прямо зафиксировано
(CRYPTO-011): «encryption key и hashing secrets — РАЗНЫЕ сущности; смешивать назначения запрещено;
немедленная ротация BIZON_ENCRYPTION_KEY запрещена».

BIZON_SESSION_HASH_SECRET / BIZON_AUDIT_HASH_SECRET / BIZON_WEBHOOK_SECRET в коде НЕ упоминаются
(0 совпадений в src/scripts) — целевые переменные ещё не введены. Сессионный токен уже не зависит
от ключа шифрования: Session.token = sha256(сырой токен) (src/lib/security/session-token.ts:8, 21-23).

## Решение — целевая матрица секретов

| Переменная | Назначение | Алгоритм | Кто читает |
|---|---|---|---|
| BIZON_ENCRYPTION_KEY | PII-шифрование (AES-256-GCM) | AES-GCM, BIZON1/BIZON2-префикс | crypto.ts (encrypt/decrypt) |
| BIZON_SESSION_HASH_SECRET | HMAC для подписей сессионных/анти-replay артефактов, если появятся; сейчас сессионные токены — случайные + sha256 в БД (session-token.ts), 2FA temp-token — случайный в KV (totp-service.ts:205-211), HMAC не используется | HMAC-SHA256 | auth/auth-service (по потребности) |
| BIZON_AUDIT_HASH_SECRET | HMAC для audit-chain/секрет-сравнений аудита | HMAC-SHA256 | data-vault/audit-log.ts |
| BIZON_WEBHOOK_SECRET | HMAC исходящих/входящих webhook-подписей | HMAC + timestamp | появится вместе с внешними webhook'ами (API-024: сейчас внешних нет) |

Примечание к матрице: BIZON_POLICY_SIGNING_KEY (policy-engine.ts:17) и BIZON_VC_SIGNING_KEY
(vc-export-service.ts:25) уже введены точечно, но их фолбэк на общий keyfile должен быть устранён
в рамках этого ADR (явная ошибка без переменной в prod, явный dev-ключ в dev — по образцу crypto.ts).

Правила: переменные независимы и генерируются раздельно (аудит CRYPTO-011,
upload/аудит 22-09-26.txt:370-391); смена одной не влияет на другие (blast radius); все — 64-hex;
валидация через requireEnv/isValidEncryptionKeyFormat (security-env.ts) с расширением getSecurityConfig()
на новые имена. Существующий факт, который разделение сохраняет: hashEmail переезжает с ключа
шифрования на собственный секрет, но САМ алгоритм (HMAC-SHA256) не меняется — см. §Порядок, шаг 4.

## Почему немедленная ротация запрещена

`hashEmail` = HMAC(текущий ключ) → emailHash ВСЕЙ БД производен от BIZON_ENCRYPTION_KEY. Ротация
ключа (или «просто перегенерировать keyfile») мгновенно инвалидирует каждый emailHash: логин
(`findFirst({ emailHash })`) не находит пользователя → 401 у всех. Это не гипотеза, а воспроизведённый
инцидент 22-09 (29-W1-gate) и подтверждённая история legacy-данных (29-b). Поэтому:

1. Ротация допустима ТОЛЬКО как контролируемая процедура с версионированными ключами и периодом
   двойного ключа (ниже).
2. «Принудительная ротация ключей» из чек-листов — отклонена до завершения миграции emailHash
   (зафиксировано в матрице CRYPTO-010/011).

## Порядок внедрения (каждый шаг — отдельная волна с гейтом)

1. **key-provider.ts** (CRYPTO-010, интерфейс из аудита, upload/аудит 22-09-26.txt:337-369):
   `EncryptionKeyProvider { getCurrentKey(): string; getKey(version): string }` +
   `getEncryptionKeyByVersion(version)` с чтением `BIZON_ENCRYPTION_KEY_<VERSION>` и 64-hex-валидацией.
   Файла сейчас НЕТ (проверено) — реализация pending.
2. **Версионирование шифротекстов** — ИСПОЛНЕНО (CRYPTO-009, 29-b): новые записи =
   `BIZON1:<base64(iv|ct|tag)>` (crypto.ts:22-23, 116), decrypt принимает legacy base64 без префикса;
   tryDecrypt (crypto.ts:152-159) для legacy-вызовов. Будущие поколения — BIZON2:… (комментарий crypto.ts:19-21).
3. **Dual-ключ период**: держим старый и новый ключ одновременно; decrypt выбирает ключ по версии
   префикса (через key-provider), encrypt пишет только новой версией. Ни один чтатель не падает.
4. **Миграционный скрипт emailHash** (критический путь): перехэширование `emailHash = HMAC(email,
   НОВЫЙ_секрет)` для всех живых пользователей. Источник email для перехэша — decrypt(emailEncrypted):
   честно — в текущей БД emailEncrypted legacy-эпох не расшифровывается (29-b: 0/79), поэтому для
   демо-аккаунтов — восстановление через repair-скрипты (канон 29-W1-gate), для прод-данных —
   перехэш по мере успешного decrypt с отчётом по нечитаемым строкам (остаются NULL = legacy-семантика DB-007).
   Скрипт идемпотентен, батчевый, с бэкапом; гейт — контрольный логин владельца до и после.
4a. **Устранить фолбэк подписей governance/VC на общий keyfile** (policy-engine.ts:19-26,
   vc-export-service.ts:24-31): в prod отсутствие BIZON_POLICY_SIGNING_KEY / BIZON_VC_SIGNING_KEY →
   throw (requireEnv), в dev — явный dev-ключ. Безопасно делать независимо от шагов 1-5:
   подписи проверяются тем же алгоритмом и ключом, что и создавались, ротация этих секретов =
   инвалидация лишь соответствующих подписей/кэшей политик, а не логинов.
5. **Только после шага 4** — разделение: `hashEmail` переключается на BIZON_SESSION_HASH_SECRET-
   эквивалент (собственный секрет email-поиска), BIZON_ENCRYPTION_KEY остаётся только AES-ключом и
   впервые получает безопасную ротацию (BIZON2 через key-provider, dual-ключ, перекриптование батчами).
6. **DataClassification + assertAuditSafe** (CRYPTO-013, интерфейс из аудита
   upload/аудит 22-09-26.txt:452-492):
   `type DataClassification = 'PUBLIC' | 'PROFESSIONAL' | 'PRIVATE' | 'CONFIDENTIAL' | 'SECRET'`;
   `assertAuditSafe(classification)` — throw `SECRET_DATA_CANNOT_BE_WRITTEN_TO_AUDIT_LOG` на SECRET.
   Проводка: в data-vault/audit-log.ts перед записью AuditLog (metadata может нести email/phone/IP/
   AI prompt — аудит прямо перечисляет риски). Код мал; политика классификации — в этом ADR.
   Связка с уже исполненным CRYPTO-012: chainHash новых записей — канонический JSON 'v2:'
   (src/lib/security/canonical-json.ts, src/lib/data-vault/audit-log.ts:22-28), redact-sensitive.ts
   (CRYPTO-004) остаётся первым щитом на console-путях.

## Последствия

- (+) Компрометация одного назначения не раскрывает остальные (blast radius ограничен).
- (+) Ротация AES-ключа становится рутиной (версии + dual-ключ), а не катастрофой логинов.
- (+) Персональные данные перестают попадать в AuditLog без явной классификации.
- (−) Миграционный окно требует двойных секретов в env и аккуратного деплоя (порядок переменных).
- (−) До шага 4 остаётся фактическая связка «ключ шифрования = ключ логина» — компенсируется
  запретом ротации + fail-fast на формат (security-env.ts) + неизменяемым keyfile-контрактом.

## Отклонённые альтернативы

- **«Немедленно ротировать BIZON_ENCRYPTION_KEY (по чек-листу секретности)»** — убивает все emailHash
  (эон-проблема 22-09, дважды воспроизведённая). Отклонено до завершения шага 4.
- **«Сразу ввести 4 переменные и переключить код»** — без key-provider/dual-ключа новый HMAC-секрет
  для hashEmail = та же массовая инвалидация логинов. Отклонено как небезопасная последовательность.
- **KMS/cloud secret-store (Vault, AWS KMS)** — правильный терминальный пункт, но в песочнице
  недостижим и не устраняет проблему производных emailHash; отложено, интерфейс key-provider
  сохраняет путь к KMS-бэкенду.
- **Перехэшировать emailHash «на лету» при логине** — не работает: логин ищет пользователя ПО
  emailHash; после смены ключа найти строку нечем. Отклонено технически (причина — в §Почему запрещена).

## Честный статус

- ИСПОЛНЕНО: BIZON1-версионирование шифротекста + tryDecrypt (crypto.ts), security-env.ts
  (requireEnv/64-hex/fail-closed), dev-keyfile задокументирован DEV-ONLY, canonical audit-chain v2,
  redact-sensitive, session-token = sha256 (не зависит от ключа шифрования); отдельные имена
  BIZON_POLICY_SIGNING_KEY / BIZON_VC_SIGNING_KEY существуют (но с опасным фолбэком на keyfile).
- НЕ ИСПОЛНЕНО: key-provider.ts, BIZON_SESSION_HASH_SECRET / BIZON_AUDIT_HASH_SECRET /
  BIZON_WEBHOOK_SECRET (0 упоминаний), устранение фолбэка policy/VC-подписей, dual-ключ период,
  миграционный скрипт emailHash, DataClassification/assertAuditSafe. Порядок и запрет немедленной
  ротации — обязательны к исполнению будущими волнами; отступление от порядка = отказ логинов всей базы.
