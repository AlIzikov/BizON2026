# ADR-004: Миграция SQLite → PostgreSQL (план, поэтапно; cutover — решение владельца)

Принят: 22.09.2026 · Аудит 22-09-26 (DB-001, DB-009, DB-021, DB-029) · Волна W2 (Task 29-f), авто-режим
Статус: ПЛАН, НЕ ИСПОЛНЕН — переключение провайдера и cutover выполняются только по явному решению владельца.
Исполнение кодом в этом ADR НЕ производится: фиксируются подготовленность репозитория, порядок шагов и гейты приёмки.

## Контекст

Схема живёт на SQLite: `prisma/schema.prisma:10-13` (`provider = "sqlite"`, `url = env("DATABASE_URL")`), БД — файл `db/custom.db`.

Почему SQLite — архитектурное ограничение, а не «вкус»:

1. **Конкурентные записи.** Песочница = 2 vCPU → пул соединений Prisma к SQLite = 2. Замеры race-теста
   дебета (worklog 29-d, tests/money/lumen-race.test.ts): последовательный debit ≈ 3.4 мс; партия из 2
   конкурентных interactive-транзакций — 104 мс/20 шт.; конкурентность ≥3 — массовые «Socket timeout»
   даже БЕЗ записи. Тесты вынуждены идти партиями по 2 — реальную гонку N воркеров движок не воспроизводит.
   Критичные к конкурентной записи контуры (аудит DB-001, upload/аудит 22-09-26.txt:749-762): Lumen
   balance, CashierOperation, OutboxEvent, AiApproval, AiAuditLog, IntroductionRequest, JobApplication,
   ProjectApplication, Recommendation, AuditLog.
2. **Деградация под нагрузкой.** Один писатель на файл, блокировки уровня БД, отсутствие row-level
   блокировок — при росте инстансов Next (stateless-курс doc_scaling) SQLite не масштабируется.
3. **Почему pilot пока ок (временно).** Одиночный инстанс, демо-объёмы, guard-паттерны FIX-06 делают
   гонку двух транзакций корректной семантически (см. «Что уже PostgreSQL-ready»); миграция вслепую
   опаснее текущего ограничения. Аудит прямо запрещает «менять production database вслепую».

## Решение — план миграции (из аудита дословно, расширенный)

Последовательность этапов (аудит DB-001, upload/аудит 22-09-26.txt:777-796), каждый — с гейтом:

1. **SQLite** — текущее состояние; полная копия-бэкап обязательна до начала (`scripts/backup-db.sh`).
2. **schema validation** — инвентарь SQLite-специфики схемы и кода: отсутствие enum (см. ниже),
   JSON-как-TEXT (`preferences`, `notificationSettings`, `backupCodes`), raw-SQL ($queryRaw) с
   SQLite-синтаксисом (PRAGMA-тесты db-invariants), `contains`-поиск (SQLite LIKE нечувствителен к
   регистру, PG — чувствителен → `mode: 'insensitive'`/pg_trgm — отдельная ревизия кода). Базовый
   чек-лист уже составлен: prisma/migrations/README.md («Что учесть при переносе»).
3. **PostgreSQL empty database** — `docker compose -f deploy/docker-compose.yml up -d postgres`
   (postgres:16-alpine уже описан, deploy/docker-compose.yml:42-44).
4. **Prisma migrations** — единственная правка схемы: `provider = "postgresql"` в datasource
   (prisma/migrations/README.md, Шаг 2), затем `bunx prisma migrate deploy` на чистой базе.
   Гейт: миграции применяются без ошибок, `_prisma_migrations` заполнена, схема воспроизводится.
5. **data migration** — перенос строк из SQLite (pgloader/ETL-скрипт; id — app-level cuid, поэтому
   FK-ссылки переносятся как есть).
6. **row counts** — пофаковая сверка COUNT(src) == COUNT(dst) по всем таблицам; расхождение = стоп.
7. **foreign-key validation** — проверка отсутствия висячих ссылок (на PG FK-констрейнты baseline
   становятся реально enforcing; известные проблемные связи — Restrict-пункты docs/database/data-lifecycle.md §5.1).
8. **business invariant validation** — прогон инвариант-тестов против PG-БД: баланс = Σ(ledger)
   (tests/money/lumen-race.test.ts), outbox lease (tests/money/outbox-lease.test.ts), db-invariants
   (DB-007/DB-020), audit chain verifyChain. Гейт аудита: «Lumen race tests pass, Outbox race tests
   pass, concurrent transaction tests pass» — на PG race-тесты впервые запускаются с конкурентностью >2.
9. **read-only comparison** — период параллельной работы: PG обслуживает чтения-сверки (выборки
   критичных роутов сравниваются с SQLite-ответами), запись ещё на SQLite.
10. **cutover** — переключение записи на PG. Только после всех гейтов и явного решения владельца.

Acceptance-чек-лист аудита (upload/аудит 22-09-26.txt:797-806) принимается как гейт пунктов 4-9.

## Что уже PostgreSQL-ready (проверено по коду)

- **Prisma-миграции под PG созданы**: `prisma/migrations/migration_lock.toml` — `provider = "postgresql"`;
  `prisma/migrations/0001_baseline/migration.sql` — PostgreSQL-DDL зеркала схемы (72 таблицы на момент
  генерации, индексы, unique, FK), сгенерирован `prisma migrate diff --from-empty --to-schema-datamodel`
  и hand-reviewed (Task 9-d). ВНИМАНИЕ: текущая схема — 125 моделей, baseline отстаёт → обязательная
  регенерация `prisma migrate diff` до применения (см. «Последствия»). Компромисс
  «схема=sqlite, миграции=postgresql» зафиксирован в prisma/migrations/README.md.
- **KV-абстракция** (src/lib/runtime/kv.ts:30-58): интерфейс KVStore с Redis-совместимой семантикой
  (get/set/expire/ttl/scan/incr, incr = SET NX PX + INCR); фабрика `createMemoryKV({name})` — при
  переезде на Redis каждый инстанс мапится на свой key-prefix (kv.ts:205-212). Распределённый
  rate-limiter = замена бэкенда без изменения вызывающего кода (src/lib/security/rate-limiter.ts:16,32).
- **Деньги — guard-decrement транзакции (FIX-06)**: spend/debit/спенд-варианты атомарны —
  `updateMany` с условием «баланса хватает» + запись ledger в одной `$transaction`
  (src/lib/services/lumen-service.ts:374-386, 441-498); идемпотентность дебета по
  `LumenTransaction.idempotencyKey @unique` (prisma/schema.prisma:367) с P2002-путём
  DuplicateDebitKeyError (lumen-service.ts:43-49, 451-498). Эти паттерны на PG сохраняют семантику
  и перестают упираться в пул=2.
- **Outbox lease-claim (DB-014, 29-d)**: `OutboxEvent.lockedAt/lockedBy/nextAttemptAt`
  (prisma/schema.prisma:2754-2756, @@index([published, nextAttemptAt]):2759), атомарный claim через
  `updateMany` с перепроверкой lease-условий (src/lib/event-bus/outbox.ts:43, 112-156, OUTBOX_LEASE_MS=60s) —
  конкурентные воркеры корректны и на PG.
- **Cursor-пагинация лент** (news, notifications; worklog 29-d) с детерминированным
  `[publishedAt|createdAt desc, id desc]` — условие аудита DB-013, переносится без изменений.
- **Minor units в деньгах**: `lumenFractionMinor Int` (prisma/schema.prisma:225), Float из
  финансового состояния убран (29-d) — PG-тип INTEGER переносится без сюрпризов.

## Что требует замены/доработки на PG

1. **Prisma enum (DB-009)**: `enum` в схеме отсутствует (0 объявлений) — SQLite-коннектор их не
   поддерживает. Сейчас: `accountType String @default("individual")` (schema:37),
   `subscriptionTier String @default("free")` (schema:43) — свободные String; валидация живёт на
   уровне приложения: тип `AccountType` (src/lib/services/auth-service.ts:12, src/lib/types.ts:6),
   whitelist+фолбэк в onboarding-service.ts:54, whitelist в регистрации (src/app/api/auth/register/route.ts:62-63),
   whitelist тарифов через `PLANS.find` (src/lib/services/payment-service.ts:141,297,351), проверки
   `subscriptionTier === 'free'` в store-service.ts:150,257. После перехода на PG — `enum AccountType`
   / `enum SubscriptionTier` по аудиту (upload/аудит 22-09-26.txt:1126-1138) ОТДЕЛЬНОЙ миграцией
   (не в baseline: baseline сознательно держит TEXT + app-валидацию, prisma/migrations/0001_baseline/migration.sql, шапка).
2. **Partial unique index для активных emailHash (DB-007)**: сейчас `emailHash String? @unique`
   (schema:21) — уникальность по ВСЕМ строкам, включая soft-deleted: email soft-deleted-аккаунта
   занят до физического purge (30 дней), т.к. `delete-account` не чистит emailHash
   (src/app/api/me/delete-account/route.ts:46-49), в отличие от forget-me (route:77-79).
   Целевое состояние (аудит, upload/аудит 22-09-26.txt:1044-1052):
   `CREATE UNIQUE INDEX "User_emailHash_active_unique" ON "User" ("emailHash") WHERE "deletedAt" IS NULL;`
   — отдельной PG-миграцией (Prisma-DSL partial-индексы не выражает; контролируется raw-миграцией
   + тестом «повторная регистрация email soft-deleted → успешна»).
3. **Распределённый rate-limiter (API-026)**: KV-абстракция готова, но бэкенд — in-process MemoryKV.
   На PG-этапе (≥2 инстанса Next) лимиты перестают быть общими → Redis через KVStore
   (замена бэкенда, публичные сигнатуры сохранены — rate-limiter.ts:3-6). Модули, создающие свои
   KV-инстансы (rate-limiter, ai-cache, tempTokenStore, frozenAccounts…), мапятся по `name`.
4. **`contains`-поиск**: ревизия поисковых сервисов на `mode: 'insensitive'` / pg_trgm
   (prisma/migrations/README.md, «Регистронезависимый поиск»).
5. **Raw-SQL**: PRAGMA-запросы тестов db-invariants.test.ts:110-126 и прочие $queryRaw с
   SQLite-синтаксисом — заменить на PG-эквиваленты (information_schema/pg_indexes) до этапа 8.
6. **Бэкапы**: scripts/backup-db.sh (копия файла) → pg_dump/WAL-архив (prisma/migrations/README.md, «Бэкапы»).

## Бенчмарки перед cutover (DB-029)

Матрица верификации: DB-029 = C в песочнице — «1M Users / 100M Evidence невозможны: нет prod-масштаба»,
этап зафиксирован в ADR-004 как пред-переходный. Это НЕ отменяет бенчмарк, а переносит его туда, где
он имеет смысл:

- Этап 8.5 (между invariant validation и read-only comparison): на PG-контуре с данными, объём которых
  согласован с владельцем, замерить p50/p95/p99 критичных операций: поиск (unified-search),
  opportunity, профессиональный профиль, evidence, news, notifications, messages, AI actions
  (список аудита, upload/аудит 22-09-26.txt:1760-1769); фиксировать rows scanned / index used / duration
  (EXPLAIN ANALYZE).
- Почему не в песочнице: (1) объёмы данных песочницы (~десятки пользователей) не выявляют отсутствие
  индекса; (2) 2 vCPU искажают p99; (3) результаты на SQLite непереносимы на PG-планировщик.
- Каждый новый индекс — только по реальному запросу + замеру (аудит DB-012: «не добавлять индексы вслепую»).

## Запрет db:push в production + CI-gate (DB-021)

Факт: `"db:push": "prisma db push --accept-data-loss"` (package.json:11). Для production запрещён
(аудит, upload/аудит 22-09-26.txt:1503-1529): production = `prisma migrate deploy`, development =
`prisma migrate dev`, db push — только disposable dev-БД. Опыт 29-d показывает цену db push: правка
схемы одним заходом + db:push удалил Float-колонку вместе с данными (восстановлено из бэкапа) —
механика «add → push → backfill → drop → push» без миграций хрупка.

Развилки для владельца (скетч, подлежит исполнению отдельной задачей):
- `db:push` переименовать/обернуть: `if [ "$NODE_ENV" = "production" ]; then echo "Production must use Prisma migrations"; exit 1; fi` (дословно из аудита).
- CI-gate в .github/workflows/ci.yml (сейчас: lint→generate→tsc→build, БД-гейта нет): шаг
  «production-скрипты не содержат db push / --accept-data-loss» + (после PG) прогон
  `prisma migrate deploy` на disposable PG-контуре в CI.

## Последствия

- (+) Путь на PG подготовлен фактически (baseline-DDL, README-инструкция, docker-compose, KV/guard/lease).
- (+) Останется честный пилот на SQLite до решения владельца — без ложного «уже мигрировали».
- (−) До cutover сохраняется потолок конкурентности (пул=2): новые race-тесты — партиями по 2 (канон 29-d).
- (−) Baseline-DDL (72 таблицы) отстаёт от схемы (125 моделей на 22.09.2026) и будет отставать дальше —
  риск рассинхрона; регенерация `prisma migrate diff --from-empty` + diff-review обязательна перед
  каждым применением и как пред-гейт этапа 4.

## Отклонённые альтернативы

- **«Остаться на SQLite навсегда (с WAL и усиленным тюнингом)»** — WAL не добавляет параллельных
  писателей и не решает multi-instance; замеры 29-d (socket-timeout при ≥3 транзакциях) остаются.
  Отклонено: противоречит DB-030-gate «SQLite не используется как конечная масштабируемая DB».
- **Turso / либSQL (managed SQLite)** — даёт сетевой SQLite, но остаётся SQLite-совместимым движком
  с моделью одного писателя на shard: ограничения конкурентной записи сохраняются, добавляются
  внешняя зависимость и латентность в деньги-контур; выигрыш против локального файла в песочнице
  минимален. Отклонено как промежуточный шаг (можно пересмотреть владельцем, если PG-инфраструктура
  недоступна).
- **MongoDB / «переписать слой данных»** — аудит прямо требует «не переписывать весь Prisma layer»;
  смена парадигмы хранения ломает ledger/инварианты/все тесты. Отклонено.
- **«Переключить provider сейчас и починить по ходу»** — ломает dev-сервер, демо-данные и параллельных
  агентов (зафиксировано координатором Task 9-coord в prisma/migrations/README.md). Отклонено:
  только через полный план с гейтами.

## Честный статус

- ИСПОЛНЕНО (до этого ADR, другими задачами): baseline PG-DDL + migration_lock=postgresql
  (prisma/migrations/), KV-абстракция, guard-decrement, idempotency, outbox lease, cursor-пагинация,
  minor units.
- НЕ ИСПОЛНЕНО: смена provider в schema.prisma, enums, partial unique index, Redis-KV, CI-gate на
  db:push, benchmarks, сам перенос данных и cutover. Всё это — план; исполнение — отдельные волны
  после решения владельца (финансирование PG-инфраструктуры + окно остановки записи).

---

## ДОПОЛНЕНИЕ 25-09-26: решение владельца — PG ДО R2 (вопрос №2 из 5)

Статус изменён: «cutover — решение владельца» → **«срок привязан: R0/R1, до старта батч-джобов R2»**.

Решение владельца 25-09-26:
1. Миграция SQLite → PostgreSQL закрывается в R0 или в самом начале R1 — ДО батч-джобов R2
   (mass decay, recompute matches, IRT-калибровка), которые упрутся в пул = 2 на первой же неделе.
2. Держим SQLite для dev-режима (быстрее), Postgres — для staging/prod.
3. Предусловие старта R2: PG работает в staging ≥ 5 рабочих дней.
4. JSON-поля (preferences, notificationSettings, backupCodes, traits/answeredItemIds/offeringJson/
   teamJson — резонансные поля R1–R2) → JSONB для запросов; `contains`-поиск → pg_trgm ревизия (этап 2 плана).

Оценка владельца: стоимость миграции 3–5 дней против 3–4 недель переписывания 4+ сервисов
в R2–R3 при отсрочке.

Исполнение — по этапам 1–6 настоящего плана (выше), без изменений гейтов. Отметка о готовности
инфраструктуры staging — в worklog при исполнении (песочница сессии 25-09-26 не имеет PG-сервиса:
`psql`/`pg_ctl` отсутствуют — провайдер в schema.prisma НЕ переключался, dev не тронут).
