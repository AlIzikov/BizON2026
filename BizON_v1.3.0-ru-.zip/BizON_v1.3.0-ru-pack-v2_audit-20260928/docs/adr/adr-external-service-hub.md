# ADR-007: Hub внешних сервисов — ExternalServicePort (П4 Фаза 1) + судьба CashierPort

Дата: 28.09.2026 · Статус: ПРИНЯТО (Фаза 1 — параллельный реестр; МИГРАЦИЯ CashierPort — только по решению владельца, пункт «стоп и жди» директивы П4)
Связан: Решение 4/5 (виртуальная касса, порты-хаб), Решение 8 (SQLite→PG Вариант A, ПОДТВЕРЖДЕНО В1), ADR-004 (PG), директива владельца «П4 RU-PACK v2 + Hub-архитектура»

## Контекст

Директива П4: сначала hub-архитектура, потом всё остальное (YooKassa, Т-Банк, 54-ФЗ, Yandex Cloud) — как адаптеры. Проблема владельца: делать интеграции отдельными сервисами, а потом внедрять hub = переделка.

В системе уже существует ОДИН зрелый хаб: виртуальная касса (Решение 5) — модель `CashierPort` (реестр портов) + `CashierPortsService` (роутинг, идемпотентность, realMoneyGate) + `CashierOperation` (журнал). Это прецедент и канон: «подключение кассы существующего типа = запись реестра (данные, не код)».

Директива называет «12 категорий», но перечисляет 13 имён: email, storage, push, kyc, search, observability, payments, receipt, blockchain, sms, notifications, ai, analytics. Решение (автономное, в границах директивы): приняты ВСЕ 13 перечисленных категорий — супермножество; ни одно имя из директивы не выброшено, критерий «12 × stub + real» выполняется с запасом. Расхождение «12 против 13» зафиксировано честно.

## Решение

### 1. Parallel, не миграция (Фаза 1)

Новая модель `ExternalServicePort` — самостоятельный аддитивный реестр для 13 категорий. `CashierPort` остаётся единственным каноническим роутером кассы (прямые вызовы `CashierPortsService.pay` сохраняются — там идемпотентность, realMoneyGate, журнал операций; дублирование этого контура в Фазе 1 = риск платёжному ядру без заказа владельца).

Миграция `CashierPort → ExternalServicePort (category='payments')` — ПУНКТ «СТОП И ЖДИ МЕНЯ» директивы. Рекомендация CTO (к отчёту Фазы 1): мигрировать в Фазе 2.1, когда payments-hub получит реальные адаптеры — единый реестр вместо двух, `CashierPort` останется как журнал операций (`CashierOperation.portId` → код порта), `pay()` переедет в hub как адаптер `demo-virtual`. До явного «да» владельца — параллельное существование, никакой двойной записи.

### 2. Контракт хаба (правило директивы)

- Бизнес-код НИКОГДА не импортирует адаптер напрямую — только `getActivePort('<category>')` из `src/lib/hubs/<category>/`.
- Секреты — ТОЛЬКО env (по `required_env` из манифеста), в БД не хранятся и не возвращаются (прецедент CashierPort: `CASHIER_PORT_<КОД>_SECRET`).
- Каждая категория: `port.ts` (интерфейс) + `hub.ts` (`getActivePort` → адаптер из карты) + `adapters/` + `index.ts`.
- Честные состояния (канон платформы): `stub` (console-адаптер — пишет в журнал, success не имитирует там, где наружный эффект невозможен), `in-house` (работающая локальная реализация), `real` (внешний провайдер: `pending`, пока env/адаптер не готовы). Активация порта без адаптера или без env — отказ 422, никогда не «успех».

### 3. Seed-канон — 42 порта, 13 категорий

Активный порт = честное текущее состояние категории:

| Категория | Активный (kind) | Stub | Real (pending) |
|---|---|---|---|
| email | console-email (stub) | ✓ | smtp, yandex-360-smtp, mailru-email |
| storage | local-disk (in-house) | console-storage | s3-compatible, yandex-object-storage |
| push | console-push (stub) | ✓ | web-push-api |
| kyc | local-review (in-house) | console-kyc | sumsub |
| search | sqlite-fts5 (in-house) | console-search | pg-fulltext |
| observability | console-observability (stub) | ✓ | sentry, yandex-monitoring |
| payments | demo-virtual (in-house) | console-payments | yookassa-ru, tinkoff-ru |
| receipt | console-receipt (stub) | ✓ | yookassa-receipt, atol-online |
| blockchain | console-blockchain (stub) | ✓ | polygon-anchor, eth-anchor |
| sms | console-sms (stub) | ✓ | smsaero-ru, mts-exolve, smsru |
| notifications | in-app-db (in-house) | console-notifications | email-digest |
| ai | console-ai (stub) | ✓ | zai-glm, openai-compatible |
| analytics | in-house-actions (in-house) | console-analytics | yandex-metrica |

Итого 42 (INT-001…INT-042 в `config/integrations.manifest.yaml`). 6 категорий имеют работающий in-house активный порт (это фиксирует реальность: локальный диск, админ-ревью KYC, FTS5, демо-касса, in-app уведомления, ActionEvent-аналитика). 7 категорий — честный stub: их внешние провайдеры требуют ключей/договоров (Б1-ключи S3/R2 — у владельца, кассы — Фаза 2, и т.д.).

Приоритеты: in-house активный = 10, stub = 50, real pending = 100+ (порядок регистрации). `isActive` — единственный источник истины «кто активен» (переключается через /admin/integrations), `priority` — порядок отображения и будущей авто-маршрутизации.

### 4. Модель

Поля — ровно по директиве: `code` (unique), `category`, `provider`, `kind`, `mode`, `priority`, `isActive`, `configJson`, `description`, timestamps. Индексы: `@@index([category, isActive])`, `@@index([category, priority])`.

### 5. Аддитивность и границы Фазы 1

- Схема — только добавление модели; ни одна существующая не меняется.
- Ни один существующий вызов не переводится на хабы в Фазе 1 (кроме новых кодовых путей самих хабов). Хабы — инфраструктура и точка входа для Фазы 2 и будущих интеграций.
- Смена провайдера через UI без правок кода: активация разрешена только портам с реализованным адаптером и полным env; оба гейта проверяются автоматически (test-endpoint), отказ — честный 422 с причиной.
