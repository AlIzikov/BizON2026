# BizON — CI/CD (R5-P1 пункт B2)

Статус: **operational-ready**. Этот документ закрывает «битую ссылку» из
`scripts/rotate-secrets.ts` (находка аудита R5-P1: ссылка на docs/ci-cd.md
вела в никуда) и описывает фактические пайплайны репозитория.

## Пайплайны GitHub Actions

| Workflow | Файл | Триггер | Что делает |
|---|---|---|---|
| **CI** | `.github/workflows/ci.yml` | push/PR в main/master/develop, manual | Node 20: npm ci → `prisma generate` → `npm run lint` → `tsc --noEmit` → guard-тест DB-021 (`db:push` в production отклонён) → `npm run build` → upload артефакта |
| **Deploy** | `.github/workflows/deploy.yml` | push в main | сборка образа + публикация (см. comments в файле; в песочнице не исполняется — рабочая цель: сервер владельца) |
| **Clean Tree** (P1.3) | `.github/workflows/clean-tree.yml` | push/PR, manual | `git status --porcelain` → **fail, если дерево грязное** |

### Clean-tree gate — системное правило владельца

Урок потери R5-P1/R5-P2 при ролловере песочницы: **«Каждый PR — commit до
отчёта; git log = единственный источник истины»**. Автоматизация:

- CI: workflow `clean-tree.yml` (зеркало правила);
- локально: `bash scripts/clean-tree-gate.sh` — запускать **перед каждым
  отчётом владельцу**; exit 1 = закоммить. (db/custom.db[-shm|-wal] —
  средовой шум SQLite WAL, из гейта исключены.)

## Локальный гейт-стек (эквивалент CI перед коммитом)

```bash
bun run lint            # ESLint: 0 errors — блокер коммита
bunx tsc --noEmit       # типы: 0 ошибок
bun test                # полный прогон: pass/fail = baseline или лучше
bash scripts/clean-tree-gate.sh   # правило «commit до отчёта»
```

## Защиты, встроенные в CI

1. **DB-021**: `scripts/db-push-guarded.js` при `NODE_ENV=production` обязан
   отклонить `prisma db push --accept-data-loss` — CI проверяет гейт негативным
   тестом (exit 1 = guard жив).
2. **Pre-commit hook** (`scripts/pre-commit.sh`): сканер секретов в staged-файлах
   (API-ключи, приватные ключи, реальные значения BIZON_ENCRYPTION_KEY).
   Установка: `ln -sf ../../scripts/pre-commit.sh .git/hooks/pre-commit && chmod +x scripts/pre-commit.sh`.
3. **Pin-канон**: тесты/pины (`tests/pins/*.pin.test.ts`) гоняются в полном
   `bun test` — зелёные пины = канон-инварианты кода (см. docs/gates).

## Environment / Secrets (GitHub)

Ожидаемые секреты (Settings → Secrets and variables → Actions): см.
`docs/security/secrets-rotation.md` — там же порядок ротации и
`.secrets-rotation.json`-журнал (`scripts/rotate-secrets.ts`).

Песочница ≠ CI: в sandbox CI не исполняется; эквивалент проверок — локальный
гейт-стек выше. Push в GitHub (если настроен) — `scripts/github-sync.sh`.

## Известные ограничения (честно)

- Деплой-воркфлоу в песочнице не прогоняется (нет runner-цели) — приёмка
  деплоя возможна только на инфраструктуре владельца (Б2: GitHub Secrets
  выдаёт владелец).
- `bun test` в CI не запускается (runner-время/СУБД) — полный прогон остаётся
  локальной обязанностью CTO-агента перед отчётом (факт прогона фиксируется
  в worklog).
