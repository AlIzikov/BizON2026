# BizON — Ротация секретов (R5-P1 пункт B4)

Статус: **operational-ready**. Инструмент: `scripts/rotate-secrets.ts`
(закрывает «битую ссылку» в его комментариях — теперь она ведёт сюда).

## Инвентарь ротируемых секретов

Источник истины — массив `ROTATABLE` в `scripts/rotate-secrets.ts`
(добавляй новые секреты туда, не в этот документ):

| env-ключ | Провайдер | Горизонт |
|---|---|---|
| `STRIPE_SECRET_KEY` | Stripe | 90 дней |
| `RESEND_API_KEY` | Resend (email) | 90 дней |
| `UPSTASH_REDIS_URL/TOKEN` | Upstash | 90 дней |
| `BIZON_ENCRYPTION_KEY` | корневой ключ шифрования | ОСОБЫЙ порядок — см. ниже |
| `BIZON_KYC_WEBHOOK_SECRET` | KYC-webhook HMAC | 90 дней |
| `BIZON_STRIPE_WEBHOOK_SECRET` | Stripe webhook | 90 дней |
| `BIZON_CRON_SECRET`, `BIZON_ADMIN_TOKEN`, `DATA_PLANE_TOKEN`, `METRICS_TOKEN` | внутренние | 90 дней |
| `SUMSUB_*` | Sumsub (по триггеру Enterprise) | по договору |
| `BIZON_AUDIT_SESSION_TOKEN` | AUDIT-MODE | ротирован при каждом вкл/выкл (P0.1, 2026-09-28) |
| `OWNER_INITIAL_PASSWORD`, `BIZON_DEMO_PASSWORDS` | учётные данные | по процедуре P0.2/P0.3 |

## Ежеквартальная процедура (90 дней)

```bash
# 1. Проверка возраста секретов (что протухло)
bun scripts/rotate-secrets.ts
# → [rotate] N секрет(ов) требуют ротации

# 2. Смена на стороне провайдера (dashboard провайдера → новый ключ)

# 3. Обновление .env (+ GitHub Secrets: docs/ci-cd.md) — по шагам,
#    которые печатает скрипт для каждого ключа

# 4. Перезапуск приложения (секреты читаются при старте)

# 5. Отметка даты ротации
bun scripts/rotate-secrets.ts --mark STRIPE_SECRET_KEY
```

Журнал — `.secrets-rotation.json` (вне git): `{ envKey: lastRotatedAt }`.
Скрипт честно печатает «stale» по горизонту 90 дней; без журнала считает всё
устаревшим.

## Особый порядок: BIZON_ENCRYPTION_KEY (dual-key)

Корневой ключ шифрует PII (AES-256-GCM) и является ключом HMAC email-хэшей.
Наивная ротация = ВСЕ emailEncrypted становятся нечитаемыми (эон-проблема —
прецеденты в worklog: 2 случая). Порядок:

1. Добавить новый ключ рядом со старым (dual-key режим, `crypto.ts` — точка
   расширения: ключевой словарь старый→новый).
2. Фоновая перешифровка всех `emailEncrypted` новым ключом + перехэш
   `emailHash` (паттерн `scripts/migrate-email-encrypt.ts`).
3. Сверка: `login` по email для канонических аккаунтов (owner, qa-01..05,
   test.private) → 200; счётчики нечитаемых emailEncrypted = 0.
4. Удалить старый ключ из env/keyfile. Отметка: `--mark BIZON_ENCRYPTION_KEY`
   скрипт НЕ выполняет автоматически — только после шага 4 (см. printout).

## Учётные данные (P0.2/P0.3, 2026-09-28)

- Пароль владельца: `OWNER_INITIAL_PASSWORD` в .env; перезадание учётки —
  `bun scripts/reset-owner-identity.ts` (идемпотентно, AuditLog
  `owner_identity.reset`).
- Пароли демо-аккаунтов: `BIZON_DEMO_PASSWORDS` в .env (base64url JSON);
  ротация одной командой — `bun scripts/reset-demo-passwords.ts` (35 аккаунтов,
  revoke сессий, AuditLog `demo_passwords.rotate`). Регламент передачи HR —
  `docs/pilot/demo-access.md`.

## Чеклист после любой ротации

- [ ] `.env` обновлён (значения НЕ в git/worklog/отчётах)
- [ ] GitHub Secrets обновлены (Б2 — если настроен remote)
- [ ] приложение перезапущено, `/api/status` → components ok
- [ ] smoke: login владельца 200; демо-вход `bun scripts/ops-board.ts` → 10/10
- [ ] `bun scripts/rotate-secrets.ts --mark <KEY>` зафиксировал дату
- [ ] при webhooks: новый секрет внесён и на стороне провайдера (Stripe/Sumsub
  подписи timing-safe проверяются живым webhook'ом)
