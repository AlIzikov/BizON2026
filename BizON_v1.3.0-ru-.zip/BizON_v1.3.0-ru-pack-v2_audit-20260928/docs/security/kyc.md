# KYC — каркас верификации личности (R5-P1-REBUILD A1)

**Статус:** каркас готов, реальный провайдер НЕ подключён (честный stub-режим).
**Провайдер (план):** Sumsub. **Триггер подключения:** первый Enterprise-клиент
(`docs/legal/lawyer-brief.md`, `docs/KYC-REAL-GATEWAY-GATE.md` условие 2).

## Канон честности (не притворяемся успехом)

- Пока `SUMSUB_*` env не настроены → провайдер `stub`: заявка сохраняется в
  `KYCSubmission` со статусом `pending`, **`User.verificationTier` НЕ повышается**.
- Если `KYC_PROVIDER=sumsub`, а интеграция ещё не построена (до R6) →
  `POST /api/kyc` возвращает `501 SUMSUB_INTEGRATION_NOT_IMPLEMENTED`.
- Webhook без `BIZON_KYC_WEBHOOK_SECRET` → `501 KYC_PROVIDER_NOT_CONFIGURED`.
  Никогда не отвечаем «ok» на неподписанный/ненастроенный контур.

## Повышение `verificationTier` → `id_verified` (только 2 точки)

1. **Admin-review (ручное, доступно сейчас):** `POST /api/admin/kyc/submissions/[id]/review`
   `{ decision: 'approved'|'rejected', note? }` (роль admin). Решение пишется в AuditLog.
2. **Provider-webhook (после R6-интеграции):** `POST /api/kyc/webhook` с заголовком
   `x-kyc-signature: HMAC-SHA256(rawBody, BIZON_KYC_WEBHOOK_SECRET)` (timing-safe).

## Env (`.env.example`)

| Переменная | Назначение |
|---|---|
| `KYC_PROVIDER` | `stub` (по умолч.) \| `sumsub` |
| `SUMSUB_APP_TOKEN` / `SUMSUB_SECRET_KEY` / `SUMSUB_LEVEL_NAME` | обязательны при `sumsub`; до R6 наличие токенов даёт честный 501 |
| `BIZON_KYC_WEBHOOK_SECRET` | ключ HMAC webhook'а; без него webhook = 501 |

## Схема данных

`KYCSubmission`: `userId`, `provider` (stub|sumsub), `providerReference` (unique —
идемпотентность webhook), `level` (целевой tier), `status`
(`pending|approved|rejected|expired|canceled`), `decisionNote`, `decidedAt/decidedById`.

## Поверхности

- Пользователь: `GET/POST /api/kyc` + карточка «Верификация личности» в настройках.
- Админ: `GET /api/admin/kyc/submissions?status=…` + `POST …/[id]/review` + таб «KYC».
- Webhook: `POST /api/kyc/webhook` (auth:false — идентификация подписью).
- Маппинг payload Sumsub → нормализованный формат — задача R6 (этот док обновить).
