# BizON — Шифрование и работа с PII (R5-P1 пункт B3)

Статус: **соответствует коду** (проверено по `src/lib/security/crypto.ts`,
ADR `docs/adr/adr-zk-encryption.md`, схеме Prisma).

## Модель данных: hash + ciphertext (поиск ≠ хранение)

Каждое PII-поле хранится ПАРОЙ (двухколоночный канон):

| Поле | Колонка поиска (HMAC) | Колонка хранения (AES-256-GCM) |
|---|---|---|
| email | `User.emailHash` | `User.emailEncrypted` |
| bio | — | `User.bioEncrypted` |
| location | — | `User.locationEncrypted` |
| phone | — | `User.phoneEncrypted` |

- **Поиск**: `hashEmail(email) = HMAC-SHA256(key, email)` — точный lookup
  без дешифровки (login-lookup, анти-дубликаты). Частичный поиск по PII
  невозможен by design (это фича, не баг).
- **Хранение**: `encrypt(x) = AES-256-GCM(key, iv=random 12B)` → base64
  (`iv:tag:ciphertext` — смотри `crypto.ts` `ALGORITHM='aes-256-gcm'`).
  GCM даёт конфиденциальность + целостность (auth-tag).
- **Чтение**: `decrypt()` — только сервер; `tryDecrypt()` — null при чужом
  ключе (эон-проблема: ключ пересоздали → данные не расшифровываются честным
  null, не исключением). Прецеденты эон-ремонта: `scripts/repair-canonical-accounts.ts`,
  `scripts/reset-demo-passwords.ts`, `scripts/reset-owner-identity.ts`.

## Ключи

- `BIZON_ENCRYPTION_KEY` (64 hex = 32 байта) — единственный корневой ключ:
  AES-GCM шифрование И HMAC email-хэшей из одного источника.
- **В песочнице**: keyfile `.bizon-encryption-key` (вне git) — dev-режим,
  instrumentation печатает честное предупреждение при каждом запуске.
- **В production**: только env-ключ; instrumentation падает без него
  (fail-closed, dev-код недостижим).
- Экспорт/хранение: ключ НЕ в git, НЕ в worklog, НЕ в архивах аудита;
  передача владельцу — защищённым каналом. Ротация — по процедуре dual-key
  (`scripts/rotate-secrets.ts` печатает шаги; перешифровка всех
  emailEncrypted + перехэш emailHash обязательны, см. §Ротация).

## Что шифруется / что НЕ шифруется (сознательные решения)

| Данные | Обработка | Основание |
|---|---|---|
| email, bio, location, phone | AES-GCM + HMAC-поиск | прямая PII, 152-ФЗ/GDPR |
| password | НЕ шифруется — PBKDF2-SHA256, 600k итераций, случайная соль; формат `pbkdf2$600000$salt$hash` | пароль не нужно читать — только verify |
| session token | sha256-хэш в БД (`Session.token`), сырой токен только в HttpOnly cookie | угон БД ≠ угон сессий |
| AuditLog.metadata | JSON с PII-минимизацией + hash-chain (v2-канонический JSON) | tamper-evidence, не конфиденциальность |
| skill-факты на чейне | только keccak256(canonical-json) хэши, PII в событиях запрещена | Trust ≠ Currency, ADR-erc5192 |

## Zero-Knowledge курс (целевая архитектура, не текущее состояние)

Правило владельца №2 (PROJECT-RULES §6): E2E AES-256-GCM Zero-Knowledge —
ЦЕЛЬ для новых приватных данных. Сегодня сервер шифрует/дешифрует сам
(server-side E2E-подобная модель). Перевод PII класса A на клиентское E2E —
отдельный ADR (152-ФЗ + серверные функции восстановления) — см.
docs/adr/adr-zk-encryption.md.

## Проверки целостности

- Пин `tests/pins/` + `tests/security/crypto.test.ts`: round-trip encrypt/
  decrypt, hashEmail-детерминизм, tryDecrypt на чужом ключе → null.
- Restore-тест (`scripts/restore-db.sh --verify`) проверяет hash-chain
  AuditLog восстановленной копии (`scripts/verify-audit-chain.ts`).
- Журнал эонов/ремонтов — в worklog (искать «эон», «repair-email-hashes»).
