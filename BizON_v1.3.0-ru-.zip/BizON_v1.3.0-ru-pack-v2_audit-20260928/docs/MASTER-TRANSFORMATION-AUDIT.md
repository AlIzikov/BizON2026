# BizON — MASTER TRANSFORMATION AUDIT
## Сверка мастер-плана GPT (v5.0.1) с актуальным кодом · 2026-09-10

**Источник:** письмо «BIZON — MASTER TRANSFORMATION TASK» (57 блоков, аудит v5.0.1).
**Объект сверки:** текущий код (после 11 продуктовых волн + FIX-01..09 + независимая экспертиза 7,4/10).
**Метод:** 3 независимых статических аудита (Task 5-a схема данных, 5-b API/сервисы, 5-c фронтенд/UX), записи в `worklog.md`.
**Принцип GPT соблюдён:** REUSE → EXTEND → REFACTOR → REPLACE. Ничего с нуля, ничего не ломаем.

---

## 1. СВОДНАЯ МАТРИЦА «РЕКОМЕНДАЦИЯ → ФАКТ»

Легенда: ✅ ЕСТЬ · 🟡 ЧАСТИЧНО · ❌ НЕТ / противоречие

### Блок A. Ядро Professional Identity (GPT §4–7, 14–15)
| Требование GPT | Факт | Статус |
|---|---|---|
| ProfessionalIdentity (единое лицо) | Passport-модели нет, данные размазаны (User/CareerEntry/UserSkill/ProfessionalEvidence/ProfessionalIntent/ProfessionalCapital); паспорт-ссылки есть (passportToken) | 🟡 |
| Evidence Layer (type/source/project/role/responsibility/result/skill/verifier/status/confidence) | `ProfessionalEvidence` покрывает action/result/role/verificationLevel/confidence/status; **нет verifier и projectId-FK** | 🟡 |
| RESULT-цепочка PROJECT→ROLE→RESPONSIBILITY→ACTION→RESULT→VERIFICATION | PROJECT+ROLE в ProjectMember, результат — текстовые поля; узлов ACTION/RESULT/VERIFICATION нет | 🟡 |
| Самозаявление ≠ Evidence | подтверждено: SkillConfirmation требует общий проект; verificationLevel claimed→verified→project_verified→expert_verified | ✅ |
| Skill Graph (currentLevel/peak/confidence/lastUsedAt/decay/verification/evidenceCount) | `UserSkill` имеет всё, включая decayStatus; resurrection нет (мелочь) | ✅ |
| Professional Capital (8 составляющих, не публичная игра) | `ProfessionalCapital` 1:1 со спецификацией; виден только владельцу | ✅ |
| Trust = объяснимость, не балл | `TrustIndex.factors` JSON + 6-факторный `trust-explain` + `professional-trust-service` (объяснения по-русски) | ✅ |
| Профиль не CV: WHO I AM → … → WHY TRUST | Нарративный `public-persona.tsx` (ДЕЛАЕТ/ДЕЛАЛ/ПРОЕКТЫ/ЦЕПОЧКА ДОВЕРИЯ/TRANSFERABLE) **написан, но не подключён — мёртвый код** | 🟡 |

### Блок B. Intent, Learns You, граф (GPT §11–13)
| Требование | Факт | Статус |
|---|---|---|
| Intent центральный слой: explicit/behavioral/hypothesis/discovered | `ProfessionalIntent.source` только explicit/inferred; behavioral-сигналы есть (ActionEvent, dwell), coach-гипотезы есть, но **в intent не разделяются discovered/confirmed** | 🟡 |
| BIZON LEARNS YOU: observation→hypothesis→confirmation→intent→recommendation | coach-service: ≤3 гипотез/сутки, подтверждение Да/Нет/Пропустить → `intent.changed` → инвалидация рекомендаций. Цикл замкнут | ✅ |
| Behavioral signals | ActionEvent + dwell-пороги 3с/10с + просмотр вакансий/профилей | ✅ |
| OPPORTUNITY GRAPH (единый граф сущностей) | trust-graph, event-bus (31 событие), capital-пересчёты; граф отображается в truth/evidence-graph | 🟡 |

### Блок C. Возможности и поиск (GPT §10, 16–19, 25–26, 37)
| Требование | Факт | Статус |
|---|---|---|
| **INBOUND ENGINE «Вас нашли»** | **Отсутствует как сервис.** Есть outbound-радар (opportunity-service, 1328 стр., с explanation) и входящие HR-контакты. Reverse-match «требования → подходящий пользователь → уведомление» не существует | ❌ |
| Возможности = единый layer (8 типов) | `Opportunity` type: job/project/mentor/partnership/expert/education/event/business; **нет direction INBOUND/OUTBOUND, нет client/investment/team**; радар покрывает 8 типов | 🟡 |
| Возможности двух источников, различимы в UI | Радар = outbound; inbound не показывается вовсе | ❌ |
| Главная «Что вы хотите сделать?» + «Возможности для вас» | Главная = приветствие + 5 док-блоков; радар есть, но **интент-хаба и split INBOUND/OUTBOUND нет** | ❌ |
| Единый SEARCH ENGINE (query→understanding→…→explanation) | 4 поверхности (search, search/semantic с intent-парсером и 119 синонимов, users/search, jobs); semantic — словари, только вакансии; конвейера нет | 🟡 |
| Career Fit: почему/что получите/не хватает/через 12 мес | `match-explain`: 8 компонент + reasons + missing + why/whatYouGet; горизонт «12 месяцев» и «что потеряете» нет; `why-you-match.tsx` **мёртвый код** | 🟡 |
| Career Simulator | `career-scenario-service` (AI-сценарий, гапы, рост з/п, trade-off) + UI | ✅ |
| «Открыт для возможностей» (8 типов + видимость) | professionalStatus — 5 значений; 8 типов GPT нет, per-type видимости нет | 🟡 |

### Блок D. Компания и HR (GPT §20–23)
| Требование | Факт | Статус |
|---|---|---|
| Company = Business Face | company-view: hero/статы/About/Intelligence (таймлайн, потребности)/команда/отзывы; **нет нарратива-статьи и inbound-блока «что компания ищет»** | 🟡 |
| HR отдельная сущность: кого ищем (компетенции 8/10), кого вырастим | hr-view: BuildTalent (explainable), TeamBuilder, WorkforceGates, Placement-портфель; шкалы компетенций 8/10 нет | 🟡 |
| HR Trust (точность вакансий, скорость ответов, отзывы кандидатов) | Job.verificationStatus/vacancyTrust есть; **отзывы кандидатов — заглушка «Скоро»** | 🟡 |
| NEWS BRIDGE + TRAFFIC BACK | RSS→AI-резюме→NewsCard→feed→внешняя ссылка; **исходящие клики не считаются** | 🟡 |
| BUILD TALENT «кого вырастим» | build-talent-service + workforce chain demand→gap→training→pipeline + talent-forecast | ✅ |

### Блок E. AI и рекомендации (GPT §24, 27–28, 38–39, 50)
| Требование | Факт | Статус |
|---|---|---|
| BIZON AI CORE (единый, поверх профграфа) | ai-core: Intent Engine/Understanding/Prediction + 6 типов инсайтов, 13 событий в шину | ✅ |
| AI GATEWAY: model/cost/timeout/retry/fallback/caching/rate limit/logging/structured output | gateway.ts: rate-limit, кэш, Sovereignty, ComputeRouter, Circuit Breaker, fallback; **нет promptVersion, нет учёта cost/tokens, structured output — ручной JSON.parse**; `ai.ts` (1255 стр., 6 AI-функций) и 2 файла ходят мимо гейтвея | 🟡 |
| Ложный AI (детерминистику выдавать за AI запрещено) | `AiInsight.provider` честно различает llm/heuristic; fallback-ответы помечены; демо-шлюз люменов помечен | ✅ |
| Рекомендации: decay/negative feedback/exploration/diversity/feedback loop | feed-recommendations: decay, IgnoredTopic, Epsilon-Greedy ~15%, 70/20/10, interleaving, **source+reason на карточке** | ✅ |
| Лента ONE SCREEN — ONE MAIN THOUGHT, AI невидим | AI-зоопарка нет, спонсорские по AdPressure; но экран = микс ≥4 типов контента | 🟡 |

### Блок F. Монетизация и правила (GPT §41–43, 53)
| Требование | Факт | Статус |
|---|---|---|
| **Реклама: НЕ CPM-first** (relevance+intent+quality+trust+freshness+bid) | `sponsored/feed` сортирует **`cpm desc`** — **прямое противоречие**; все компоненты-кирпичики есть (targeting по intentTypes, adTrustIndex, AdPressure), комбинированный скор не считается | ❌ |
| Не продавать репутацию/доступ к людям | Люмены тратятся на AI-действия; перевод кошелька между юзерами есть (lumen transfer) — допустимо | ✅ |
| Люмены (1 AI-действие, дивиденды, kill-switch) | lumen-service: CAS-дивиденды, ledger, refund идемпотентный, LUMEN_ACTIONS, email-гейт | ✅ |
| KPI: Professional Outcome Rate | career-outcome API + causality-engine (view_to_action с decay); сквозного «рекомендация→результат» по всем доменам нет | 🟡 |
| Глобальный публичный рейтинг запрещён | IP-score виден владельцу, публично — уровень/бейдж; Trust с факторами | ✅ |
| Нельзя: дубли сервисов/моделей, mock=production | Проверено 2-b: дублей PLANS нет; заглушка `/api/subscription/upgrade` помечена «Production»; платежи честно stub | ✅ |

### Блок G. UX, приватность, качество (GPT §32–36, 45–49)
| Требование | Факт | Статус |
|---|---|---|
| Приватность 4 уровня (Public/Network/Verified/Private) | Разрозненные флаги (hrInvisible, showHobbiesToHr, visibility проектов); единой шкалы нет | ❌ |
| Паспорт отвечает «что хочет» | passport-service собирает кто/умеет/сделал/подтверждено/кто знает; **intents не включены** | 🟡 |
| 10 критических экранов | mobile-first готов: bottom-nav, FAB, skip-link, PWA | ✅ |
| Accessibility | skip-to-content, aria, semantic — базово есть; WCAG 2.2 AA полный аудит не проводился | 🟡 |
| Тесты (unit/E2E/API) | Автотестов нет; есть ручные curl-матрицы + браузерные E2E сессии (верификация в worklog) | 🟡 |
| `@ts-nocheck`, strict | strict=true, noImplicitAny, ignoreBuildErrors=false, tsc 0 ошибок | ✅ |

**Итог сверки: ✅ 22 · 🟡 24 · ❌ 5** — код v6 опережает v5.0.1, на котором делался анализ GPT, но 5 пунктов нарушают прямые требования.

---

## 2. ПЯТЬ КРИТИЧЕСКИХ РАЗРЫВОВ (волна A)

| # | Разрыв | GPT § | Решение (REUSE-first) |
|---|---|---|---|
| 1 | Inbound Engine «Вас нашли» отсутствует | §10, 37 | Новый сервис reverse-match на базе opportunity-service-кирпичиков + уведомления + блок на главной |
| 2 | Sponsored ranking CPM-first | §42 | Заменить сортировку на комбинированный скор: relevance+intentAlignment+quality(adTrustIndex)+freshness+normalized bid; CPM — только тай-брейк корзины |
| 3 | Главная не интент-хаб, inbound не виден | §25, 37 | Блок «Что вы хотите сделать?» (6 действий) + «Возможности для вас» с табами «Вас нашли»/«Мы нашли для вас» (radar переиспользуем как OUTBOUND) |
| 4 | Схема не поддерживает inbound/discovered/cost | §10, 12, 28 | `Opportunity.direction`, `User.openTo` (8 типов + видимость), `ProfessionalIntent.source` +discovered/confirmed, `AiUsageLog`, `ProfessionalCapitalSnapshot` |
| 5 | 3 готовых GPT-компонента мёртвым кодом | §34, 18, 26 | Подключить: public-persona → публичный профиль; why-you-match → job detail; opportunities-view → раздел «Возможности» |

## 3. ВОЛНА B (после A) — ВЫПОЛНЕНА 2026-09-10
1. ~~Паспорт + раздел «Что я хочу»~~ ✅ Готово: `PassportIntent` в getByToken (активные интенты, топ-5), секция «Что я хочу» во всех 7 шаблонах профессии, чипы с RU-метками и подсказками источника; в настройках добавлено управление паспортом (enable/disable/regenerate + копирование ссылки — раньше UI не было вовсе).
2. ~~AiUsageLog-запись в ai-core gateway~~ ✅ Сделано ещё в волне A (запись model/latency/токены).
3. ~~ProfessionalCapitalSnapshot (cron) → тренд капитала~~ ✅ Сделано в волне A (getTrend, порог ±2%).
4. ~~Privacy-матрица MVP~~ ✅ Готово: `User.privacyProfile` (public/network/private), `ProfessionalEvidence.visibility`; src/lib/privacy.ts (canViewProfile/isConnected/visibleEvidenceWhere); гейт на GET /api/users/[id] (restricted → минимальный конверт) + на не-владельческих evidence-поверхностях (404 без утечки существования); PATCH privacyProfile/hrInvisible с валидацией; в настройках — карточка «Приватность» (3 radio-карточки видимости + тумблеры hrInvisible/showHobbiesToHr — у hrInvisible UI не было) .
5. ~~Traffic-back метрика news~~ ✅ Готово: `NewsCard.clicks`, POST /api/news/[id]/click (rate-limit 30/мин), перехват обоих внешних линков в news-card (титул + relevance-панель), бейдж «N переходов» в ленте (только при clicks>0), в company intelligence — `trafficBack {totalClicks, newsCount}` по матчингу доменов website/newsSources + блок «Переходы из BizON» в панели.
6. ~~HR Trust MVP~~ ✅ Готово: модель `HrReview` (1:1 на Placement, unique), POST /api/placements/[id]/review (только реальный кандидат + подтверждение + 409/422 валидация + уведомление HR), GET /api/hr/[id]/reviews (aggregate avg/count + 20 последних), в hr-view вместо заглушки «Скоро» — реальный блок отзывов (средняя + список, honest empty state), кандидатская сторона — MyPlacementsCard в MeView (только individual, отзыв по подтверждённому placement), HrView подключён в MeView для hr_agency (был мёртвым кодом).

## 4. ВОЛНА C (стратегическая) — ВЫПОЛНЕНА 2026-09-10
- ~~Единый поисковый конвейер~~ ✅ Готово: unified-search-service (understanding→retrieval→ranking→explanation), GET /api/search/unified, UnifiedSearchPanel в app-shell с reason на русском; privacy-фильтр private/network.
- ~~Рефактор ai.ts (1255 стр., 3 байпаса)~~ ✅ Готово: SDK только в ai-core/zai-client.ts; 6 байпасов переведены на gateway; экспорты ai.ts сохранены; AiUsageLog.model = фактическая модель провайдера.
- ~~Result-цепочка как модели~~ ✅ Готово: модель ProjectResult (PROJECT→ROLE→ACTION→RESULT→VERIFICATION), сервис + API + UI «Цепочка результата» в диалоге проекта; подтверждение только другим участником проекта.
- ~~Feed «ONE SCREEN — ONE MAIN THOUGHT»~~ ✅ Готово: режим «Одна мысль» (GET /api/feed/thoughts с детерминированным объяснимым скором + why, одна карточка на экран, навигация 1/10, реклама исключена, persist).
- ~~WCAG 2.2 AA~~ ✅ Готово: аудит docs/WCAG-2.2-AA-AUDIT-2026-09-10.md; 7 критических A-фиксов, 4 контраст-группы, 20 диалогов aria-describedby, ~40 aria-атрибутов; остаток (скринридер, focus-trap кастомных оверлеев) задокументирован в отчёте.

Дополнительно в этой же сессии (см. docs/STUBS-AUDIT-2026-09-10.md): P0-честностные фиксы (NFT «не блокчейн», interested-companies без Math.random) и 5 быстрых побед A-I (2FA-карточка, AI Insight, Next Best Actions, Сравнение вакансий, Запросить подтверждение клейма).

Из исходного списка волны C отложено: Recommendation 2.0 (структурированная модель рекомендации «кто/контекст/роль/что/результат») — часть закрыта ProjectResult; live-проверка скринридером WCAG — на отдельную сессию.

## 5. Соответствие запретам GPT §53
Проверено: нулей с нуля нет; дублирующих сервисов нет; глобального публичного рейтинга нет; destructive migrations не применяются (db:push только добавляет поля); mock помечен mock'ом. Нарушений на момент аудита не выявлено, кроме CPM-first (исправляется в волне A).
