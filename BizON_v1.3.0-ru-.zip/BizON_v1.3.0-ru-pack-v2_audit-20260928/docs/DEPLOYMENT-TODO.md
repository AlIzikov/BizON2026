# BizON — ЧТО ДОДЕЛАТЬ ПРИ РАЗВЁРТЫВАНИИ НА РЕАЛЬНОМ СЕРВЕРЕ

> Создан аудитом 17-09-2026 (задача владельца: «что нельзя доделать сейчас — вывести отдельным файлом,
> чтобы при развёртывании понимали, что надо доделать»).
> **Как пользоваться:** идти по разделам сверху вниз; P0 — без этого система не запустится/вход будет невозможен;
> P1 — запустится, но часть функций сломана или деградирована; P2 — желательные улучшения.
> Источник фактов: код репозитория (файл:строка указаны); полная карта — worklog.md, секция audit-2-b.

---

## 1. P0 — СЛОМАЕТСЯ СРАЗУ, если не сделать

| # | Действие | Почему | Где в коде |
|---|----------|--------|------------|
| 1 | Задать **`BIZON_ENCRYPTION_KEY`** (сильный случайный ключ) и **сохранить его навсегда** (секрет-менеджер/офлайн) | Прод-сервер не стартует без него; смена ключа позже = все `emailHash/emailEncrypted` невалидны → не смогут войти ВСЕ пользователи | `src/instrumentation.ts` (fail-secure throw), `src/lib/security/crypto.ts` |
| 2 | Убедиться, что **`BIZON_DEMO_AUTH` НЕ задан** (=0) | Сейчас в `.env` песочницы стоит `=1` — каждый посетитель авто-входит под демо-юзером | `src/middleware.ts:86`; захардкоженный `DEMO_TOKEN` в `src/middleware.ts:20` |
| 3 | Настроить **HTTPS** (TLS-терминация на прокси) + `NODE_ENV=production` | Cookie `bizon_session` с `secure: true` отбрасывается браузером по HTTP → вход невозможен | `src/lib/services/auth-service.ts` (cookie), `src/middleware.ts:111` |
| 4 | Задать **`DATABASE_URL`** (относительный путь `file:../db/custom.db` или отдельный volume), прогнать `prisma generate` + `bun run db:push` | Без него Prisma падает; текущий `.env` содержит абсолютный путь песочницы `file:/home/z/my-project/db/custom.db` | `prisma/schema.prisma`, `.env` |
| 5 | Задать **`NEXT_PUBLIC_APP_URL=https://<ваш-домен>`** | Все ссылки в письмах (верификация email, re-engagement) ведут на дефолт `http://localhost:3000` | `src/lib/services/email-service.ts:149`, `src/lib/auth/verification-token.ts:26` |
| 6 | **`next build`** перед запуском (`npm run build` → standalone) | В песочнице build запрещён (OOM 4ГБ) — на сервере сборка нужна и возможна (CI прогоняет на Node 20) | `package.json` scripts build/start; `deploy/Dockerfile` |

## 2. P1 — СЛОМАЕТСЯ ЧАСТИЧНО / ДЕГРАДИРУЕТ

### 2.1 Почта (SMTP) — email-верификация неработоспособна без неё
- `SMTP_HOST/PORT/USER/PASSWORD/FROM` → `src/lib/services/email-service.ts:73-77`.
- Без SMTP письма пишутся в консоль сервера (`mode:'console'`) — токен верификации виден только в логах.
- Требование юридического решения 3 (`docs/DECISIONS.md`) — SMTP-контур обязателен.

### 2.2 Прокси и сеть
- **`TRUST_PROXY=1`** за реверс-прокси — иначе все клиенты в одном rate-limit бакете `'local'` (массовые 429 под нагрузкой) и IP в AuditLog неверные (`src/lib/security/rate-limiter.ts:99`).
- **CORS `PROD_ORIGINS` захардкожен** `https://bizon.app`/`www` (`src/middleware.ts:24-27`) — сменить на реальный домен. Preview-оригины `*.space-z.ai`/`*.z.ai` разрешены во всех средах — на проде сузить.
- **Правило gateway `?XTransformPort=` из Caddyfile НЕ переносить в прод** — это открытый доступ к любому локальному порту (песочница-специфика). Caddyfile целиком заменить нормальным реверс-прокси с TLS.

### 2.3 Кроны и фоновые задачи (11 скриптов)
- Планировщика в приложении нет; `drainOutbox` играет pending-события **только при старте сервера** (`src/instrumentation.ts:36`) — настроить периодический drainer или рестарты.
- Настроить crontab по шапкам скриптов `scripts/cron-*.js` (инсайты 05:10, coach 08:00, snapshots 03:00, weekly-digest пн 09:00, email-reengagement 10:00, memory/capital/trust/fraud/nft-decay/cleanup) + **`BIZON_CRON_SECRET`** в env сервера и крона (без него `POST /api/cron/insights` → 503 fail-closed).
- Все cron-скрипты, кроме insights, ходят в БД напрямую и требуют `BIZON_ENCRYPTION_KEY` в окружении крона.
- Комментарии в скриптах содержат абсолютный путь `/home/z/my-project` — поправить под реальный путь.

### 2.4 AI-интеграции
- SDK `z-ai-web-dev-sdk` читает конфиг **`.z-ai-config`** (JSON `{baseUrl (/v1), apiKey}`) в проекте / `$HOME` / `/etc`. Без него все LLM-фичи уходят в честный heuristic-fallback (работает, но без LLM-качества) — `src/lib/ai-core/zai-client.ts`.
- Остальные AI-переменные опциональны: `BIZON_AI_INSIGHTS` (фон; `=0` выключает), `BIZON_AI_DAILY_BUDGET` (200 ед/сут), `BIZON_AI_AUTONOMY_KILLED` (kill-switch), `AI_CACHE_ENABLED`.
- Тарифные квоты уже вшиты (free 5/ч, pro 50/ч, business 500/ч на matchmaker/career/projectMatch) — `src/lib/security/rate-limiter.ts`.

### 2.5 Данные и хранение
- **Медиа хранятся как data-URL прямо в SQLite** (лимит `BIZON_MEDIA_MAX_MB=2`, проверяется только в `POST /api/projects`, `src/app/api/projects/route.ts:24`) → БД раздувается (2МБ × N картинок), бэкапы тяжелеют. При росте: object storage (S3) + перенос + поднять лимит.
- Redis/общий KV не используется (rate-limit/кэш in-memory) → лимиты и кэш НЕ шарятся между репликами; горизонтальное масштабирование требует замены на Redis (`REDIS_URL` в compose уже есть, код его не читает).
- Переход на Postgres (deploy/docker-compose.yml с postgres:16 готов) требует смены `provider` в `schema.prisma` + миграции — сейчас код на SQLite.

### 2.6 Секреты и хвосты песочницы
- `bizon-config.env` содержит реальный ключ шифрования (gitignored) — перенести в секрет-менеджер, не копировать на сервер в репо.
- `DEMO_TOKEN` захардкожен в `src/middleware.ts:20` (в git) — вынести в env или удалить на проде.
- `.zscripts/mini-services-*.sh` — инфраструктура песочницы, в прод не переносить (каталог `mini-services/` пуст).
- Не запускать на проде `scripts/seed.ts` — **стирает БД** и наполняет демо-данными (10 юзеров с паролем `password`).

## 3. P2 — ЖЕЛАТЕЛЬНО ДОДЕЛАТЬ ПРИ ПОДГОТОВКЕ К ПУБЛИКУ

| # | Пункт | Где | Что нужно |
|---|-------|-----|-----------|
| 1 | Платёжный провайдер: `ExternalGatewayAdapter` — каркас без провайдера (`isConfigured=false`), буст вакансии пропускает платёжный шаг | `src/lib/services/payment-service.ts:213+`, `src/app/api/jobs/[id]/boost/route.ts:33` | Договор + ключи + реализация адаптера |
| 2 | Push-уведомления: заглушка «будет подключена позже»; sw.js есть, VAPID-контура нет | (use-pwa.ts удалён аудитом как мёртвый; остался `public/sw.js`) | VAPID-ключи + подписка/отправка |
| 3 | NFT-минт навыков: запись в БД + pseudo-token, блокчейна нет | `src/lib/services/nft-skills-service.ts:16,330`, `src/app/api/nft-skills/[id]/mint/route.ts` | Контракт/сеть ИЛИ осознанный отказ |
| 4 | Верификация компаний: валидация длины ИНН вместо API ЕГРЮЛ | `src/app/api/companies/[id]/verify/route.ts:3` | API ЕГРЮЛ (ключ) |
| 5 | OAuth-интеграции (LinkedIn/GitHub/Telegram): 501 + константный список `connected:false` | `src/app/api/integrations/*` | OAuth-приложения + ключи |
| 6 | Домен в коде: `https://bizon.app` захардкожен (sitemap, layout-метаданные, referral-ссылки, c/[token], p/[token] fallback) | `src/app/sitemap.ts`, `src/app/layout.tsx:16`, `src/app/api/referral/route.ts:41`, `src/middleware.ts:25-26` | Вынести в `NEXT_PUBLIC_APP_URL` |
| 7 | `DND`-окно тишины 22:00–08:00: тумблер есть, окно не реализовано | `prisma/schema.prisma:173`, `notification-service.ts:12` | Логика окна в notification-service |
| 8 | Планировщик напоминаний birthday-plans не реализован; «подарок — модуль позже» | `src/app/api/birthday-plans/route.ts:136` | Отдельная задача |
| 9 | CI deploy-воркфлоу — заглушка (нужны secrets DEPLOY_HOST/SSH_KEY) | `.github/workflows/deploy.yml` | Secrets + целевой хост |

## 4. ПРОЦЕДУРА РАЗВЁРТЫВАНИЯ (минимальная последовательность)

1. Сервер: Node 20+, 2+ ГБ RAM для сборки (build OOM-чувствителен), диск под SQLite с учётом роста от media data-URL.
2. `git clone` → `bun install` (или npm ci).
3. ENV (см. §1/§2): `DATABASE_URL`, `BIZON_ENCRYPTION_KEY`, `NEXT_PUBLIC_APP_URL`, `NODE_ENV=production`, `TRUST_PROXY=1`, SMTP-набор, `BIZON_CRON_SECRET`; УБЕДИТЬСЯ: `BIZON_DEMO_AUTH` отсутствует.
4. `bunx prisma generate` + `bun run db:push` (на существующей БД прод-данные не стирать; seed НЕ запускать).
5. `npm run build` → `npm start` (standalone; порт задаётся PORT; standalone НЕ читает `.env` — прокидывать env процессу, как делает `scripts/dev-prod.js`).
6. Реверс-прокси: TLS + прокидывание `X-Forwarded-Proto`; БЕЗ правила `XTransformPort`.
7. Проверка: `GET /api/health` (Dockerfile HEALTHCHECK уже на него), вход пользователя, письмо верификации со ссылкой на домен, rate-limit по IP.
8. Crontab по §2.3 + тот же env в cron.
9. Наблюдение: `LOG_LEVEL`, `/api/metrics` (или `METRICS_TOKEN`), AuditLog-записи с корректными IP.

## 5. ENV-ПЕРЕМЕННЫЕ — СВОДНАЯ ТАБЛИЦА

| Имя | Обязательна | Назначение |
|-----|-------------|------------|
| `DATABASE_URL` | ✅ P0 | SQLite-файл БД |
| `BIZON_ENCRYPTION_KEY` | ✅ P0 (prod) | Шифрование PII (emailHash/emailEncrypted); хранить вечно |
| `NODE_ENV` | ✅ P0 | `production` (влияет на secure-cookie и поведение middleware) |
| `NEXT_PUBLIC_APP_URL` | ✅ P0 | Базовый URL для писем/публичных ссылок |
| `BIZON_DEMO_AUTH` | ⛔ НЕ задавать | Авто-вход демо-юзера (только песочница) |
| `TRUST_PROXY` | ⚠️ P1 | `=1` за реверс-прокси (честные IP для rate-limit/AuditLog) |
| `SMTP_HOST/PORT/USER/PASSWORD/FROM` | ⚠️ P1 | Почтовый контур (верификация email) |
| `BIZON_CRON_SECRET` | ⚠️ P1 | Токен cron-эндпоинта insights (иначе 503) |
| `BIZON_MEDIA_MAX_MB` | нет | Лимит медиа в проектах (дефолт 2 МБ) |
| `BIZON_AI_INSIGHTS` | нет | `=0` — выключить фоновую AI-активность |
| `BIZON_AI_DAILY_BUDGET` | нет | Дневной AI-бюджет (дефолт 200) |
| `BIZON_AI_AUTONOMY_KILLED` | нет | Kill-switch автономных AI-действий |
| `AI_CACHE_ENABLED` / `AI_CACHE_SCHEMA_VERSION` | нет | Кэш AI-ответов |
| `LUMEN_DIVIDENDS_ENABLED` | нет | Kill-switch дивидендов люменов |
| `NEXT_PUBLIC_YM_ID` / `NEXT_PUBLIC_GA_ID` | нет | Аналитика (prod-gated) |
| `METRICS_TOKEN` / `CAUSALITY_ADMIN_TOKEN` / `DATA_PLANE_TOKEN` | нет | Токены сервисных эндпоинтов (fallback — admin-сессия) |
| `LOG_LEVEL` | нет | Логирование (дефолт info) |
| `BIZON_EXTERNAL_FETCH_ENABLED` | нет | SSRF-гейт внешних fetch (дефолт выкл) |
| `.z-ai-config` (файл) | ⚠️ P1 | Конфиг AI SDK `{baseUrl, apiKey}` — иначе heuristic-fallback |

## 6. SEED- И MAINTENANCE-СКРИПТЫ

| Скрипт | Что делает | На проде |
|--------|-----------|----------|
| `scripts/seed.ts` | Демо-данные, **СТИРАЕТ БД** | ❌ никогда |
| `scripts/seed-projects-tz.ts` | Идемпотентное обогащение «Проектов» | ⚪ опционально |
| `scripts/seed-ai-agents.ts` | AI-governance агенты (upsert) | ✅ желательно |
| `scripts/seed-skill-synonyms.ts` (+.js) | Синонимы поиска | ⚪ опционально |
| `scripts/seed-truth-engine.js` | Claims/career entries | ⚪ опционально |
| `scripts/migrate-email-encrypt.ts`, `migrate-pii-hashes.js`, `repair-email-hashes.ts`, `mark-existing-verified.ts` | Миграции PII существующей БД | ⚠️ только при переносе старой БД |

---
*Обновлять этот файл при каждом изменении конфигурации. Смежные документы: `docs/DECISIONS.md` (продуктово-юридические решения), `docs/solutions/README.md` (память реализации), `deploy/` (Docker/compose/helm).*
