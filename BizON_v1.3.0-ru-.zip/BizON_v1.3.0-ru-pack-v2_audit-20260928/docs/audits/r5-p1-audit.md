# Аудит R5-P1 — физическая верификация 16 пунктов по коду

**Дата:** 2026-09-28 · **Метод:** 3 параллельных read-only агента по коду (auth/security, platform, product) · **Контекст:** артефакты R5-P1 потеряны при ролловере сессии (worklog:4875); R5-P2 rebuild зафиксирован коммитом `cc0083d`. Вопрос владельца (Часть 3): что из R5-P1 физически есть сейчас.

## Сводная таблица

| # | Пункт | Статус | Где в коде (свидетельства) | Ключевой пробел |
|---|-------|--------|---------------------------|-----------------|
| A1 | KYC каркас | **MISSING** | Только платёжный «KYC-гейт»-док `docs/KYC-REAL-GATEWAY-GATE.md` + зарезервированный `User.verificationTier` (schema:278) + `virtual-cashier-service.ts` (kill-switch песочницы). Sumsub — 0 упоминаний в коде | Нет модели KYCSubmission, роутов, провайдер-стаба, `SUMSUB_*` env |
| A2 | 2FA компаний (обяз.) | **PARTIAL** | Механизм TOTP ПОЛНЫЙ: `twoFactorSecret/twoFactorEnabled/backupCodes` (schema:117-118,187), `otplib@13`, `src/lib/services/totp-service.ts` (AES-256-GCM, RFC 6238, backup-коды SHA-256), роуты `api/auth/2fa/{enable,confirm,verify,disable}`, login-челлендж `auth/login:77-91`, UI settings + auth-screen, тесты w5/w1/api-contract | **Обязательности для company/hr_agency нет нигде** (login не требует, write-гейта нет). Мёртвый дубль `two-factor-card.tsx` |
| A3 | Session management | **PARTIAL** | `Session` (schema:972-982, token sha256 D-21), TTL 7д + удаление просроченных (`auth.ts:180-194`), cookie httpOnly, logout-everywhere (`auth-service.ts:175-177`), инвалидация при бане/удалении, retention-чистка, пины kv2-session | Нет `/api/auth/sessions` (список устройств), нет revoke одной сессии, нет метаданных (userAgent/ip/lastUsedAt), нет sliding-ротации |
| B1 | Поиск (FTS5) | **PRESENT** | Semantic-search работает: `semantic-search-service.ts` (intent-парсинг, синонимы 119, XAI-формула 0.5/0.3/0.1/0.1), `unified-search-service.ts` (factors+reason), роуты `api/search{,/semantic,/unified}`, UI. FTS5 честно отложен: `docs/database/search-fts5.md` (триггер >10k / p95>500ms; фактических fts5-таблиц в коде 0 — соответствует доку) | Косметика: `formulaVersion` нет в поисковом XAI (есть в других доменах) |
| B2 | CI/CD | **PARTIAL** | `.github/workflows/ci.yml` (lint+tsc+db-push-guard+build, test non-blocking — честно закомментировано), `deploy.yml` (buildx→ghcr, deploy-заглушка с секретами), `deploy/Dockerfile+docker-compose+helm`, `docs/deploy/staging-runbook.md`, `crontab.bizon`, `scripts/github-sync.sh` | **`docs/ci-cd.md` отсутствует** (битая ссылка в rotate-secrets.ts:8); тест-job не блокирующая; деплой — заглушка |
| B3 | Encryption docs | **PRESENT** (код) | `src/lib/security/crypto.ts` (AES-256-GCM, `BIZON1:` версионирование, hashEmail HMAC-SHA256, fail-closed), `security-env.ts`, поля User emailEncrypted/bioEncrypted/locationEncrypted/phoneEncrypted, тесты crypto, ADR `adr-zk-encryption` + `adr-secrets-separation` | Директории `docs/security/` НЕТ (маркер потери); нет единого дока «какие поля чем шифруются» |
| B4 | Secrets rotation | **PARTIAL** | `scripts/rotate-secrets.ts` (аудит 90д × 6 секретов, `--mark`, журнал, инструкции, dual-key оговорка) + пин r5-p2-core — восстановлено R5-P2 | `docs/security/` нет; `.env.example` без rotation-комментариев |
| C1 | Interview scheduling | **MISSING** | Только: статус-лейбл `interview` в JobApplication (schema:907) + мёртвый тип уведомления `interview_scheduled` (notification-service:51, никогда не эмитится) + пассивный счётчик в дашборде | Нет модели Interview, API, UI назначения, эмиссии уведомления, тестов |
| C2 | Talent pools | **MISSING** | Смежное (НЕ то): Build Talent — эфемерный рейтинк (`build-talent-service.ts`, без сохранения), Talent Forecast — рыночная аналитика | Нет TalentPool/TalentPoolMember моделей, CRUD API, UI, тестов |
| C3 | Rejection с фидбеком | **PARTIAL** | Самоотказ кандидата РЕАЛЕН: `rejectReason` (schema:911), PATCH `applications/[id]/status` принимает `rejected` с обязательной причиной (400 если нет), уведомление с «Причина отказа», UI my-path (диалог + показ причины) | **HR-стороны нет нигде**: `/api/applications/[id]/status` owner-only (403 для компании); `hiringManagerResponse` — мёртвое поле (пишется только null); нет HR-диалога; нет тестов rejectReason |
| D1 | Data export | **PRESENT** | POST `api/me/export-data` (GDPR ст.20, 25+ коллекций, EXPORT_VERSION), GET `api/v1/user/data/export` (152-ФЗ контур, ConsentLog+DataRequestLog), 2 UI-кнопки в settings, исторический браузерный прогон 200 | — (нитт: два параллельных эндпоинта — оба осознаны по докам) |
| D2 | Cookie consent EU | **MISSING** | Ноль: нет компонента/категорий/хранения выбора/гейтинга скриптов/ключей i18n. Смежное НЕ то: ConsentLog = 152-ФЗ PII-согласия, TosBanner = версии оферты | Всё. NOTE: `/privacy` §7 честно заявляет «только необходимые cookies» — баннер консистентен текущей практике, но D2-деливерабл отсутствует |
| D3 | DPO designation | **MISSING** | Только плейсхолдеры «[email DPO/CSM]» в `dpa-template.md`; `/privacy` §8 — без DPO; `dpo@` в коде нет; lawyer-brief DPO не поднимает | dpo.md, контакт в /privacy, очередь юристу |
| E1 | Referral (UI+награды) | **PARTIAL** | API+Sхема+пины ПОЛНЫ (R5-P2): `Referral` (code non-unique+index — решение R5-P1 восстановлено), `ReferralMilestone`, GET `/api/referral` (+milestone.canClaim), claim (Pro через applyTier, 409 идемпотент), leaderboard (приватно) | **UI тонкий**: ReferralBlock в профиле (ссылка+копирование+статистика), НЕТ claim-кнопки (роут прямо ждёт «кнопку на фронте»), НЕТ leaderboard-UI, нет прогресса 5/5 |
| E2 | Support/FAQ | **PARTIAL** | FAQ-фрагмент 5 Q&A внутри subscription-view; Slack-слэш-команды (внутр. ops); Complaint ≠ тикеты; staff-роль `support` в админке | Нет `/faq`, `/support` страниц, SupportTicket модели/API, контакта поддержки, i18n-ключей |
| E3 | Product analytics | **PARTIAL** | Клиентский `src/lib/analytics.ts` (Metrica+GA4, enum 10 событий) — **dead code, 0 вызовов**; инъекция скриптов в layout гейтится env-ID (не настроены); РЕАЛЬНЫЙ сигнал: dwell-петля (feed_dwell → ActionEvent → буст рекомендаций); Experiment/ExperimentEvent (R4 A/B); ops-метрики `/api/metrics` (не продуктовые) | Нет серверного продуктового трекинга событий, модели, админ-дашборда, вызовов track() |

## Талли: PRESENT 3 · PARTIAL 8 · MISSING 5

- **PRESENT (не требуют rebuild):** B1 (поиск работает, FTS5 отложен по триггеру), B3 (реализация+ADR; док — в P3), D1 (полный GDPR-экспорт)
- **PARTIAL → достроить недостающее:** A2 (обязательность), A3 (device-list+revoke), B2 (док ci-cd), B4 (док security), C3 (HR-сторона), E1 (claim+leaderboard UI), E2 (/faq+/support), E3 (трекинг+дашборд)
- **MISSING → строить:** A1 (KYC каркас-стаб), C1 (Interview), C2 (Talent pools), D2 (cookie consent), D3 (DPO)

## Соответствие приоритетам владельца (Часть 4.2)

- **P0 (1 нед):** A2 2FA-обязательность, A3 Sessions device-list/revoke, C3 HR-rejection, E3 Analytics — все PARTIAL, достраиваются поверх существующего.
- **P1 (1 нед):** C1 Interview, C2 Talent pools, A1 KYC каркас — все MISSING, строятся с нуля.
- **P2 (1 нед):** B1 (только формула-версия косметика), B2 docs/ci-cd.md, E1 UI, E2 страницы.
- **P3 (3 дня):** B3/B4 docs/security/, D2 cookie consent, D3 DPO. D1 — закрыт.

## Дополнительно найдено аудитом (для бэклога)

1. Мёртвый дубликат `src/components/settings/two-factor-card.tsx` — нигде не импортируется (удалить/подключить).
2. `docs/ci-cd.md` — битая ссылка из rotate-secrets.ts:8.
3. Мёртвый блок кода в GET `/api/referral` (fetch referral, результат не используется).
4. Session без метаданных — device-list невозможен без миграции (входит в A3-P0).
5. 2FA tempToken — in-memory KV, single-instance (задел под горизонтальное масштабирование).
