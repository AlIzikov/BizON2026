# BizON — Staging Runbook (R5-B8)

Статус: **staging-window-pending** — код и compose-файлы готовы; внешнее окружение (VPS/окно развертывания) ожидает владельца (см. worklog R5-1: PG-staging окно ≥5 рабочих дней — предусловие волны).

## Что нужно для staging

| Компонент | Что уже есть | Что нужно |
|---|---|---|
| VPS / контейнеры | `deploy/docker-compose.yml` — app + PostgreSQL 16 + Redis 7 (одна команда `docker compose up -d --build`), `deploy/Dockerfile` | VPS (2 vCPU / 4GB минимум), открыты порты 80/443 |
| Reverse-proxy | TRUST_PROXY-канон (`src/lib/security/rate-limiter.ts`), CSRF allowlist env | Caddy/Nginx с X-Real-IP + TLS-сертификат |
| БД | Prisma-миграции (SQLite dev → PostgreSQL staging, ADR-004: Json-поля совместимы с JSONB) | выполнить `prisma db push`/migrate на staging-PG |
| Секреты | `.env.example` — полный список плейсхолдеров | заполнить на сервере (НЕ коммитить; ADR secrets-separation) |

## Env-переменные (полный шаблон — `.env.example`)

| Переменная | Назначение | Обязательна на staging |
|---|---|---|
| `DATABASE_URL` | PostgreSQL: `postgresql://user:pass@postgres:5432/bizon?schema=public` | да |
| `NEXT_PUBLIC_APP_URL` | публичный URL (ссылки в письмах) | да |
| `BIZON_ENCRYPTION_KEY` | шифрование PII — 64 hex | да (иначе ключ файловый) |
| `TRUST_PROXY` | `1` только за доверенным прокси | да (за Caddy/Nginx) |
| `BIZON_CRON_SECRET` | защита cron-эндпоинтов (alerts, insights) | да |
| `REDIS_URL` | `redis://redis:6379` (compose ставит сам) — rate-limit/алерты | рекомендуется |
| `RESEND_API_KEY` | email-транспорт (приоритет над SMTP) | для реальных писем |
| `SMTP_HOST/PORT/USER/PASSWORD/FROM` | email-транспорт №2 | альтернатива Resend |
| `BIZON_STRIPE_WEBHOOK_SECRET` + `STRIPE_SECRET_KEY` | платёжный контур Stripe | для webhook-теста |
| `SLACK_WEBHOOK_URL` | алерты errorRate/p95 | рекомендуется |
| `SENTRY_DSN` | Sentry SDK — P1 при сетевом доступе | нет (задел) |
| `BIZON_DEMO_AUTH` | **ОБЯЗАТЕЛЬНО 0/пусто** на staging | — |
| `BIZON_EXTERNAL_FETCH_ENABLED` | внешние fetch (cron-новости) | по необходимости |

## Шаги поднятия

1. `git clone` / `git pull` ветки `main` на VPS.
2. `cp .env.example .env` → заполнить значения (таблица выше).
3. `docker compose -f deploy/docker-compose.yml up -d --build` (поднимет postgres+redis+app).
4. `docker compose exec app bunx prisma db push` (или `prisma migrate deploy` — по ADR-004).
5. Проверить логи: `docker compose logs -f app` — загрузка без ошибок, instrumentation-хук установлен.

## Smoke-чеклист (5 пунктов)

1. [ ] `GET /api/health` → 200.
2. [ ] Регистрация нового пользователя (`POST /api/auth/register`) → 201/200, письмо (Resend/SMTP) реально ушло или честный console_stub.
3. [ ] Матч: резонанс-квиз завершён → матч вакансии возвращает score/XAI (INSUFFICIENT_DATA = честный 200).
4. [ ] Платёж-demo: `POST /api/subscriptions` (gateway=demo) → `succeeded`, Payment/Subscription-журнал в БД; Stripe-webhook без секрета отвечает 503 STRIPE_NOT_CONFIGURED (честность контура).
5. [ ] Алерты: `POST /api/cron/alerts` с `x-cron-secret` → `{ evaluated:true, ... }` (без SLACK_WEBHOOK_URL — `reason:'SLACK_NOT_CONFIGURED'`).
