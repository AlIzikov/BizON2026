# BizON ENGINEERING GAP MATRIX

**Дата:** 2026-09-17 · **Метод:** разведка 3 Explore-агентами (research-only, факты путь:строка) + изучение 12 open-source эталонов по первоисточникам + сверка с идеологией BizON (§5 мастер-директивы). Не копируем проекты — переносим принципы. BizON остаётся BizON.

**Эталоны изучены (первоисточники, README):** OpenHands (event-loop + runtime-изоляция), Cline (plan/act + approval на каждое действие + чекпоинты), Superpowers (UNDERSTAND→…→EVIDENCE→DONE — уже принят как CE-цикл), Aider (repo-map, вертикальная целостность правки), SWE-agent (audit finding→root cause→fix→test→evidence), LangGraph (durable execution + interrupts + state), Daytona (sandbox изоляция исполнения), browser-use (браузерные агенты для внешних источников), Promptfoo (eval + red team + регресс-матрицы), OWASP ASVS (V1-V14, L1-L3), OWASP AISVS (191 требование, C9 agentic security), OpenTelemetry GenAI (конвенции span/metric для LLM/тул-вызовов), GLM-4.5/Z.ai (собственная экосистема: agentic reasoning, tool use; используется через z-ai-web-dev-sdk — без предположений о несуществующих функциях).

**Ключевой факт разведки:** governance-контур BizON (AiAgent с autonomyLevel 0-5, Action Registry 12 действий, PolicyEngine, AiApproval TTL 15 мин, AiAuditLog, AiBudget, AiIncident, kill-switch env+персистентный, Decision Inbox UI) **уже существует и протестирован (w3), но мёртв: `proposeAction` имеет 0 вызывающих из бизнес-кода, approve не исполняет действие (§38 — executor отложен), уровни 2+ без поведения**. Поэтому P0 — не стройка, а оживление.

## Статусы: ✅ есть · 🟡 частично · ❌ нет · ⚠️ есть, но противоречит/не используется

## Домены A–I

| ID | DOMAIN | CURRENT BIZON | REFERENCE | REFERENCE PATTERN | STATUS | GAP | RISK | RECOMMENDATION | FILES | METHOD | TEST | VERIFICATION | PRIORITY | DEPS |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A | Agent Architecture | 4 агента сидом (co-pilot, matchmaker, news-scout, system), autonomyLevel 0-5 в схеме; уровни 2+ без поведения (`governance-service.ts:48` levelToMode) | OpenHands + LangGraph | агент = event-loop с состоянием и interrupt'ами; роли специализир. | 🟡 | уровни 2-5 не реализованы; AiGoal вне флоу | низкий | уровни 2-3 → реальная семантика в PolicyEngine; 4-5 — фича-флаг | policy-engine.ts, governance-service.ts, action-registry.ts | матрица риск×режим; тесты | w3+w7: кейсы 5 уровней × рисков | гейты + unit | **P0** | — |
| B | Human-Machine Management | Decision Inbox UI (settings) + approval TTL 15 мин + уведомления; всё живое, но inbox пуст — proposeAction не вызывается | Cline | каждое действие агента = diff на approval | ⚠️ | контур не подключён к бизнес-логике | высокий | P0: подключить запись AI-действий + executor (ниже, детально) | governance-service.ts, 3 AI-роута, decision-inbox.tsx | wiring | w7 | браузер: approve→execute | **P0** | G |
| C | Autonomy | kill-switch двухуровневый (env `policy-engine.ts:19` + персистентная политика `governance-service.ts:421`); setAutonomy только 0/1 | Cline (auto-approve toggle), LangGraph (durable) | градуированная автономия с лимитами | 🟡 | уровни 2-5 отсутствуют как поведение | средний | delegated/supervised в PolicyEngine (матрица риска); autonomous — за флагом | policy-engine.ts, /api/me/autonomy | матрица + валидация режимов | w7 матрица | unit + API-тест | **P0** | A |
| D | Action Registry | 12 действий с risk/reversible/externalSideEffect/defaultModes (`action-registry.ts:31`) — образцовый реестр | OpenHands (tool registry) | единый реестр + единая точка решения | ✅ | нет handler'ов исполнения | низкий | добавить EXECUTORS map к существующим ключам | executors.ts (нов) | handler-map | w7 | unit | **P0** | B |
| E | Approval | AiApproval TTL, decideAction честный (владелец, expiry, single-use) `governance-service.ts:229` | Cline | approve≠execute; re-check перед исполнением | ✅ | после approve ничего не происходит | высокий | executeApprovedAction с re-check политики+бюджета (по §38) | governance-service.ts, /api/ai/governance/execute | executor-wave | w7 | браузер e2e | **P0** | D |
| F | Decision Inbox | `/api/ai/decisions` + UI в settings; показывает риск/цену/обратимость/TTL | Cline (diff+approve) | inbox = единственная точка решений | ✅ | нет видимого результата после approve | средний | approve → execute (read-only) → показать summary результата | decision-inbox.tsx | wiring | w7 | браузер | **P0** | E |
| G | Kill Switch | env + персистентная политика + PATCH op global_kill (`status/route.ts:94`); PAUSE/RESUME агентов | Cline/LangGraph | аварийный тормоз вне AI-контура | ✅ | admin-кнопки в UI нет; ISOLATE/REVOKE без методов | низкий | UI-тумблер для admin (P1); ISOLATE/REVOKE методы (P2) | decision-inbox.tsx, status/route.ts | wiring | w3 | API-тест | P1 | — |
| H | Permissions | централизованный PolicyEngine (неизвестное действие→BLOCK; не выдано→BLOCK); authority через AiAuthority actionAccess | AISVS C9 (agent identity/permissions) | policy сильнее промпта | ✅ | только 5 read/low действий в DEFAULT_USER_ACTIONS | низкий | расширять осознанно при новых действиях | governance-service.ts:26 | декларативно | w3 | unit | P2 | — |
| I | Evidence Engine | AiAction inputHash/outputHash (SHA-256), AiAuditLog на каждый шаг, общий AuditLog; §8-цепочка Goal→…→Evidence частично в схеме | SWE-agent; OTel GenAI | каждая операция = трейс с evidence | 🟡 | user-initiated AI-вызовы НЕ попадают в AiAction; AiAuditLog не связан с OTel-конвенциями | средний | recordDirectAction для 3 AI-роутов; поля OTel-сопоставления в metadata (P1) | governance-service.ts, ai/matchmaker, ai/project-match, ai/career | wiring | w7 | dev.log + БД-проверка | **P0** | — |

## Домены J–R

| ID | DOMAIN | CURRENT BIZON | REFERENCE | REFERENCE PATTERN | STATUS | GAP | RISK | RECOMMENDATION | FILES | METHOD | TEST | VERIFICATION | PRIORITY | DEPS |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| J | Recommendation Engine | Recommendation: основание ≥10 симв + projectId обязателен + @@unique; сила скрыта, клиент-verified вес 1.0 vs 0.5 | — (идеология) | сарафанное радио | ✅🟡 | «работали вместе» не проверяется (рекомендация с улицы = 0.5) | средний | требовать Connection или projectId (решение владельца — идеологический вопрос) | api/recommendations/route.ts | guard | unit | API-тест | P1 | решение владельца |
| K | Projects | Project (Problem/Context/Solution/Result), clientStatus + анти-коллюзия, ProjectResult verify (только со-участник, 409 дубликат), клейм-verify (accepted-connection) — proof-ядро образцовое | SWE-agent (evidence) | claim → verification → evidence | ✅ | getUserChains не показан в профиле; experienceShare без структуры | низкий | подключить getUserChains в профиль (P1); структура experienceShare (P2) | project-result-service.ts:255 | wiring | существующие | браузер | P1 | — |
| L | Matchmaker | 5 рукопожатий BFS ≤5 хопов, confidence по пути, rate-limit по тарифу | — | детерминированный социальный граф | ✅ | — | — | — | lib/matchmaker.ts | — | w6 | — | — | — |
| M | Opportunity Engine | 8 типов, 4 скора, direction INBOUND/OUTBOUND, inbound reverse-match без AI, cooldown 1ч, дедуп | LangGraph (state) | explainable scoring | ✅ | sponsored-переменные вне матрицы рисков (реклама ≠ AI-действие — ок) | низкий | — | inbound-service.ts | — | — | — | — | — |
| N | News Bridge | url @unique дедуп, источники Company→User→fallback, 100/день, статус pending→модерация; verifiedVacancy-связи нет; 80/20-аналитики нет | browser-use (внешние источники — будущее) | external→metadata→summary→source | 🟡 | News Bridge = RSS-конвейер без анализа; нет связи с верифицированными вакансиями | средний | поле verifiedVacancyId + 20% аналитики (P2, по ТЗ) | schema, cron-fetch-news | additive | — | — | P2 | News Score |
| O | News Score | 6 факторов, «невычислимое=0»; НО newsScore+факторы уезжают клиенту (`api/news/route.ts:100`) вопреки собственному комментарию `news-score-service.ts:12` | — (идеология) | число не показываем | ⚠️ | утечка скоринга в публичный API | средний | **P0: strip newsScore из ответа**, сортировка на сервере (UI не использует — проверено grep) | api/news/route.ts | strip | unit | API-тест + браузер | **P0** | — |
| P | BIZON DISCOVER | 3-5 находок/день, match только по verified-навыкам, «нет данных → тип не возвращается» | OpenHands (automations) | честный ноль | ✅ | — | — | — | api/me/discover | — | — | — | — | — |
| Q | BIZON WORK | 4 таба (Jobs, FindForMe, FindSpecialist, Projects) на реальных данных | Aider (вертикальная целостность) | UI+API+DB согласованы | ✅ | — | — | — | opportunities-view.tsx | — | — | — | — | — |
| R | Security (web) | PBKDF2-600k, 2FA, login backoff, rate-limit, SSRF-гейты, PII hash+AES-GCM, admin-guard | OWASP ASVS L1-L2 | тестируемые контроли | 🟡 | A01: 193/290 роутов вне withRoute (IDOR-риск); A03: zod в 16/290; CSP только frame-ancestors; HSTS нет; DEMO_TOKEN в git; *.z.ai credentialed CORS в prod | высокий | P0: HSTS+базовый CSP; P1: миграция роутов на withRoute батчами, zod-схемы на мутациях, CORS-политика домена (деплой-зависимо) | next.config.ts, middleware.ts | headers | w6-security | curl -I + браузер | **P0** (headers) | — |

## Домены S–Z

| ID | DOMAIN | CURRENT BIZON | REFERENCE | REFERENCE PATTERN | STATUS | GAP | RISK | RECOMMENDATION | FILES | METHOD | TEST | VERIFICATION | PRIORITY | DEPS |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S | AI Security | PolicyEngine+registry+kill-switch+бюджет — ядро AISVS C9 (orchestration/agentic) уже есть | OWASP AISVS C9 | агент = субъект с полномочиями, не доверенный | 🟡 | prompt-injection защита не формализована; исключения (AiIncident) никто не создаёт | средний | P0: incident при failed-исполнении; P1: санитайзер внешнего контента (News) в промптах | governance-service.ts | executor-wave | w7 | unit | **P0** (incidents) | E |
| T | Observability | pino есть — импортирован в 3 файлах; 237 console.error; метрики p95/RPS `/api/metrics`; trace-id нет; AiAuditLog на LLM-вызовы (`ai-core/gateway.ts:164`) | OTel GenAI | span на каждый LLM/тул-вызов с cost | 🟡 | нет корреляции запрос→AI-вызов; cost не в метриках | средний | P1: trace-id middleware + gateway пишет actionId/cost в structured metadata (каркас OTel-маппинга) | logger.ts, gateway.ts | additive | unit | dev.log | P1 | — |
| U | Testing | 8 файлов/76 тестов (крипто, policy, outbox, auth, матрицы); **в CI тестов нет** (ci.yml:43-49); E2E нет | Promptfoo (матрицы), SWE-bench | регресс-сьют enforced в CI | ⚠️ | гейты существуют, но не enforced | высокий | **P0: подключить bun test + pii-inventory в CI** | .github/workflows/ci.yml | CI | сами тесты | зелёный CI | **P0** | — |
| V | E2E | нет системного E2E; браузерная верификация agent-browser в сессиях (зол. путь) | Playwright | e2e как часть DONE-критерия | ❌ | ручные проверки невоспроизводимы | средний | P1: Playwright smoke-сьют 10 сценариев (login→discover→inbox) | tests/e2e (нов) | Playwright | e2e | CI | P1 | U |
| W | Code Quality | tsc --incremental false гейт, lint, каталог моделей/роутов, реестр удалений, docs/solutions | Aider/SWE-agent (repo-map) | карта кодовой базы | ✅ | 193 ручных хендлера = дрейф конвенций | средний | P1: батчевая миграция на withRoute (по 20 роутов) | по зонам | рефактор | tsc | гейты | P1 | — |
| X | Secrets | ключ шифрования dev-фолбэк файл; bizon-config.env с реальным ключом в песочнице; DEMO_TOKEN в git; хэш email тем же ключом | ASVS V6 (secrets) | секреты вне кода + ротация | 🟡 | ротация ключа = потеря emailHash (задокументировано) | высокий | P0-в-деплой (уже в DEPLOYMENT-TODO §2.6); P1: DEMO_TOKEN из git | crypto.ts, middleware.ts | env | w1 | grep | P1 (код) | деплой |
| Y | Database | SQLite + Prisma, EventOutbox (2 события), AuditLog в памяти 5с flush | LangGraph (durable) | at-least-once + периодический drain | 🟡 | drain только при старте (limit 100); AI-событий в outbox нет; AuditLog буферный | средний | P1: cron drainOutbox; P2: Postgres-миграция (деплой) | outbox.ts, instrumentation.ts | cron | w-outbox | dev.log | P1 | деплой |
| Z | Scalability | in-memory rate-limit/KV (per-process), SQLite, data-URL медиа в БД | Daytona (изоляция), ASVS V1 | горизонт. масштабирование | ⚠️ | не масштабируется >1 инстанса | низкий (пилот 10-1000) | зафиксировано в DEPLOYMENT-TODO P1; не трогать до пилота | — | — | — | — | P2 | деплой |

## P0-детализация (Human-Machine Management + enforcement)

### P0-1 «Wiring»: запись пользовательских AI-действий в governance (Evidence, §8)
- **Проблема:** `proposeAction` имеет 0 вызывающих; 3 AI-роута не оставляют следов в AiAction/AiAuditLog → §8 (Goal/Agent/Action/Input/Result/Evidence) не выполняется для реальных вызовов.
- **Изменение:** новый `GovernanceService.recordDirectAction` (human-initiated: создаёт AiAction status=approved + audit `action.user_initiated`, fail-open) и вызовы в `ai/matchmaker` (→SEARCH_PEOPLE), `ai/project-match` (→SEARCH_JOBS), `ai/career` (→ANALYZE_PROFILE). Поведение ответов НЕ меняется.
- **Тест:** w7 (запись создана, hash, fail-open при мусорном agentKey). **Верификация:** БД-счётчик после живого вызова + dev.log.

### P0-2 «Executor wave»: approve → реальное исполнение с re-check (Cline/LangGraph-паттерн)
- **Проблема:** inbox одобряет в пустоту («Одобрение НЕ исполняет» — `governance-service.ts:229`); уровни 2+ не имеют семантики.
- **Изменение:** (1) матрица риск×режим в PolicyEngine (manual: всё через человека; collaborative: read/low auto; delegated: +medium в inbox; supervised/autonomous: medium auto — по AiAuthority-уровню); (2) `executors.ts` — read-only хендлеры SEARCH_JOBS/SEARCH_PEOPLE/ANALYZE_PROFILE; (3) `executeApprovedAction` с re-check статуса/политики/бюджета → executed + outputHash, failure → failed + **AiIncident**; (4) роут `/api/ai/governance/execute` (владелец действия, rate-limit); (5) UI: после «Разрешить» — исполнение read-only и показ результата.
- **Тест:** w7 (happy path, re-approval refuse, budget refuse, executor error → incident). **Верификация:** браузер — approve→«Выполнено: …».

### P0-3 «Идеология»: newsScore не показываем пользователю
- **Изменение:** strip newsScore/факторов из публичного `/api/news`; серверная сортировка сохраняется.
- **Тест:** unit. **Верификация:** API-ответ без поля + лента рендерится.

### P0-4 «Enforcement»: CI гоняет тесты и PII-гейт (ASVS V14)
- **Изменение:** ci.yml + `bun test tests/` + `node scripts/pii-inventory.mjs` после lint/tsc.
- **Верификация:** конфиг CI; локально обе команды зелёные.

### P0-5 «Headers»: HSTS + CSP base-uri/object-src (ASVS V14)
- **Изменение:** next.config.ts: HSTS (prod), CSP + base-uri 'self', object-src 'none'. Проверка: приложение не ломается (браузер, console errors 0).

### Сознательно НЕ в P0 (и почему)
- Удаление Project.rating/Mentorship.mentorRating (числовые рейтинги против идеологии) — **изменение схемы/продукта, решение владельца**; внесено в матрицу J/K как P1.
- UserPublic.ipScore публичное число vs паспорт-level — противоречие зафиксировано, решение владельца (продукт).
- Eval-suite 1000 сценариев (Promptfoo-подход), E2E Playwright, миграция 193 роутов, trace-id, Postgres — P1/P2, не влезают в итерацию без потери качества.
- browser-use/Daytona-паттерны — News Bridge-скрапинг и sandbox-исполнение кода: внешних зависимостей не добавляем до пилота (идеология: без нового софта без нужды).
