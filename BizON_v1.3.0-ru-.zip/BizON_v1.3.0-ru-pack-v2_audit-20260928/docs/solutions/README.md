# docs/solutions/ — память проекта (Compound Engineering)

> **Каждая единица инженерной работы должна делать следующую легче — не тяжелее.**
> Методология: [Compound Engineering (Every, MIT)](https://github.com/EveryInc/compound-engineering-plugin), адаптирована под BizON.

Эта папка — **институциональная память** для агентов и людей. Сюда попадают неочевидные из кода знания: первопричины, нерабочие подходы, инварианты, ограничения. Фаза планирования новой задачи и разбор багов **обязаны** начинаться с чтения этого индекса.

## Правило запуска (обязательно перед любой задачей)

1. **Перед планированием новой задачи** — прочитай этот README и релевантные записи ниже (заголовков обычно достаточно, файл целиком — только если тема совпадает).
2. **После верифицированно решённой проблемы** — прогони гейт захвата (три условия: *неочевидно из кода + долговременно + существенно*; контрфакт: «если эта запись исчезнет, будущий инженер повторит то же расследование?») → если да, добавь запись.
3. **Высокое пересечение с существующей записью** (4–5 совпадений: проблема/причина/решение/файлы/профилактика) — **обнови существующую**, не создавай дубликат. Поставь `last_updated`.

## Каталог

| Файл | Тип | Суть |
|------|-----|------|
| [tooling/sandbox-dev-server-lifecycle.md](tooling/sandbox-dev-server-lifecycle.md) | knowledge | Жизненный цикл dev-сервера и ограничения песочницы: сервер умирает между bash-вызовами, скрипты из /tmp не запускаются, `next build` запрещён, tsc требует 6GB |
| [tooling/gate-commands-pipe-masking.md](tooling/gate-commands-pipe-masking.md) | bug | Гейт-команды: `$?` после пайпа даёт код tail (ложный «0»); «[m» в выводе sed/rg — артефакт отображения, не битый файл |
| [architecture/api-route-conventions.md](architecture/api-route-conventions.md) | knowledge | Конвенции API-роутов: withRoute + rate-limit, EventOutbox, PII emailHash, guest-401 это норма, путь /api/taxonomy |
| [architecture/ui-state-vs-prisma-raw-returns.md](architecture/ui-state-vs-prisma-raw-returns.md) | knowledge | Почему raw-объекты Prisma из PATCH/POST нельзя мержить в UI-state и как обновлять состояние точечно |
| [database/sqlite-prisma-constraints.md](database/sqlite-prisma-constraints.md) | knowledge | Ограничения SQLite+Prisma: нет skipDuplicates в createMany, примитивные списки нельзя, рабочий процесс db:push |
| [testing/env-gated-side-effects-flaky-tests.md](testing/env-gated-side-effects-flaky-tests.md) | bug | Флаки тестов из-за env-гейта BIZON_AI_INSIGHTS: фоновые side effects должны быть детерминированы в тестах |
| [ui/seed-data-ui-prefix-duplication.md](ui/seed-data-ui-prefix-duplication.md) | bug | Дубли фразы в UI, когда seed-данные содержат UI-префиксы; префикс — зона ответственности только одного слоя |

## Формат записи

Два трека со своей структурой секций и frontmatter — см. шаблон: [`skills/compound-engineering/references/doc-template.md`](../../skills/compound-engineering/references/doc-template.md). Кратко:

- **bug-трек** (билд/тест/рантайм/интеграция): Симптомы → Что не сработало → Решение → Почему это работает → Профилактика.
- **knowledge-трек** (архитектура/конвенции/тулинг): Контекст → Руководство → Почему это важно → Когда применять → Примеры.

Каждый тезис должен быть подтверждаем: указывай файлы и строки, которые можно проверить (grounding).

## Связанные источники знания в проекте

- `worklog.md` — хронологический журнал работ агентов (обязателен к чтению перед работой; здесь — история, не правила).
- `docs/DECISIONS.md` — продуктово-юридические решения (контракт уровня продукта).
- `docs/proposals/PROJECTS-API-CONTRACT.md` — контракт API модуля «Проекты».

| bug | [dead-governance-contour-lesson](architecture/dead-governance-contour-lesson.md) | Мёртвый контур + рассинхрон approval/action ID | wiring мёртвых контуров, HITL |