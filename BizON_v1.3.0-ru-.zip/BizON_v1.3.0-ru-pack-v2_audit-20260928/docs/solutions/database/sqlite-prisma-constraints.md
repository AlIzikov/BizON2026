---
title: Ограничения SQLite + Prisma в BizON
date: 2026-09-17
last_updated: 2026-09-17
track: knowledge
problem_type: database_constraint
component: database
tags: [sqlite, prisma, schema, migration]
status: active
---

# Ограничения SQLite + Prisma в BizON

## Контекст

BizON работает на Prisma + SQLite (файл БД в `db/`). При внедрении «Рекомендовать проект» понадобилось идемпотентно создать записи рекомендаций; привычный `createMany({ skipDuplicates: true })` недоступен.

## Руководство

1. **`createMany` в SQLite-коннекторе не поддерживает `skipDuplicates`** — вместо этого find-then-create:
   ```ts
   const existing = await db.projectRecommendation.findFirst({ where: { projectId, fromUserId, toUserId } });
   if (!existing) await db.projectRecommendation.create({ data: {...} });
   ```
   Пример: `src/app/api/projects/[id]/recommend/route.ts:48` (комментарий прямо в коде).
2. **Примитивные списки в схеме запрещены** (`prisma/schema.prisma`: примитивный тип не может быть `[]`). Массивы строк моделируются CSV-строкой (например `topicsCsv`) или отдельной таблицей связей. Выбирай CSV для «тегов без запросов», таблицу — для связей с индексами/уникальностью.
3. **Схема меняется так**: правка `prisma/schema.prisma` → `bun run db:push` (= `prisma db push --accept-data-loss`, `package.json:11`) → при правках сидов — идемпотентный прогон сида (вставки с проверкой существования).
4. **Уникальные составные constraint'ы** (`@@unique([a, b])`) — основной инструмент идемпотентности связей; при find-then-create без него возможна гонка, но для текущих объёмов она принимаема (осознанный трейд-офф).

## Почему это важно

Каждый из пунктов — реальный потолок, о котором не предупреждают сообщения об ошибках до момента выполнения. `skipDuplicates` не падает на этапе типов: падение происходит в рантайме роута уже под нагрузкой проверки.

## Когда применять

- Проектирование новых моделей/полей в схеме.
- Мутации, которые должны быть идемпотентными (повторные клики, ретраи).

## Примеры

- Модель `ProjectRecommendation` (`prisma/schema.prisma`): `@@unique([projectId, fromUserId, toUserId])` + find-then-create в роуте рекомендаций.
- `Project.experienceShare` — добавлен аддитивно через db:push без потери данных.
