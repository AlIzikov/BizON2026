# unlazy gate-check: уроки внедрения (17-09)

Контекст: эталон №15 Leonxlnx/unlazy вендорен в tools/unlazy/, dogfood-ledger specs/adopt-unlazy/GATES.md.

## Урок 1: CWD-якорение явных ledger-ов
При явном указании файла ledger-а чекер якорит CHECK-команды в ДИРЕКТОРИИ LEDGER-А
(`explicit: file dir`), а не в корне репо. Репозиторий-относительные пути (tools/..., docs/...)
ломаются с "Cannot find module" / "No such file or directory".
**Решение**: всегда передавать `--cwd /home/z/my-project` для ledger-ов в specs/<slug>/.
(Первый прогон: 5 из 8 гейтов упали именно на этом — ledger сделал своё дело, поймал дефект до отчёта.)

## Урок 2: approval-привязка включает resolved CWD
Approval хранится с сигнатурой oracle (check+expect+resolved cwd+shell+timeout+limits+platform+PATH).
Смена --cwd между запусками инвалидирует approvals ВСЕХ гейтов.
Ловушка: `--approve` обрабатывает только гейты в состоянии unmet; гейт, оставшийся file-met
со старой approval-привязкой, образует тупик (approve его пропускает, reverify блокируется).
**Решение**: совмещать флаги — `--approve --reverify --cwd <repo-root>`; тогда pending = все гейты,
недостающие approvals создаются, все гейты перезапускаются.

## Урок 3: evidence-дайджест ≠ approval-привязка
Definition SHA-256 (в evidence) средо-независим (не включает resolved paths/shell/PATH) — evidence
не протухает от смены cwd. Протухает только approval. Поэтому "ALL MET" при старой привязке был
честным по evidence, но unverified по исполнению — различать эти два состояния при отчёте.

## Статус dogfood
ALL MET (8 met, reran: 8, previously met reverified: 8), exit 0.
Гейты: линт ledger, bun test, eslint, tsc, eval FAIL=0, worklog, AGENT-WORKFLOW §6.1, чекер v2.1.0.
