---
title: Конвенции API-роутов BizON
date: 2026-09-17
last_updated: 2026-09-17
track: knowledge
problem_type: architecture_convention
component: api
tags: [api, with-route, rate-limit, event-outbox, pii, auth]
status: active
---

# Конвенции API-роутов BizON

## Контекст

В платформе 290+ роутов, и поведенческие инварианты (rate-limit, аутентификация, события, PII) распределены по общим хелперам. Новый агент, пишущий роут «с нуля» по обычным практикам Next.js, почти всегда нарушает хотя бы одну конвенцию: забывает rate-limit, шлёт сырой email в лог, возвращает 500 там, где ожидается 401/422.

## Руководство

1. **Оборачивай хендлеры в `withRoute`** (`src/lib/with-route.ts:98`). Он даёт: единый контекст запроса, опциональный rate-limit (`opts.rateLimit: { key, limit, windowMs }`, строка 41, проверка до тяжёлой работы — строки 126–127), стандартизированные ошибки (`errorJson`), логирование.
   - Типичные лимиты: 30/мин для обычных мутаций, 10/мин для «тяжёлых» семантик (apply/share/recommend).
2. **Коды ошибок честные**: 401 — гость на персональном эндпоинте (это норма, не баг: например `GET /api/projects/recommendations` без сессии отвечает 401), 404 — объект не найден/не опубликован, 422 — ошибка валидации ввода с человеческим текстом, 429 — превышен лимит (текст лимита показываем пользователю).
3. **PII**: email никогда не пишется в открытом виде — только HMAC `emailHash` (`src/lib/security/crypto.ts`). Не логируй сырые персональные данные.
4. **Исходящие события — через EventOutbox** (`prisma/schema.prisma:2419`): `emitDurable` при мутации, `drainOutbox` доставляет подписчикам (`src/lib/event-bus/subscribers.ts`). Не шлём события напрямую «в сторону» подписчиков.
5. **Знай фактические пути**: таксономия живёт на `/api/taxonomy`, а не `/api/projects/taxonomy` (запрос по второму пути даёт 404). При добавлении роутов сверяйся с деревом `src/app/api/` — вложенность отражает модуль, но не всегда интуитивна.
6. Мутация, затрагивающая счётчики/ленты, должна возвращать консистентную форму: `{project: ...}` / `{recommended, skipped, message}` — и эта форма документируется в `docs/proposals/PROJECTS-API-CONTRACT.md`.

## Почему это важно

Кросс-модульные гарантии (анти-абьюз, PII/152-ФЗ, аудит через события) держатся на том, что каждый роут идёт через один и тот же конвейер. Один «самодельный» роут ломает гарантию целиком — аудит платформы это фиксирует как дефект уровня волны.

## Когда применять

- Любое создание/изменение API-роута.
- Диагностика «почему 401/429/422» — сначала проверить, что это ожидаемое поведение конвейера, а не баг.

## Примеры

- `POST /api/projects/[id]/recommend` (`src/app/api/projects/[id]/recommend/route.ts`): withRoute 10/мин, 404 на неопубликованный проект, 422 «сам-себе», уведомление через событие `project_recommended`.

## Миграция 17-09 (fix-campaign-p1-residue): 100% покрытие withRoute

Вся поверхность `src/app/api/**/route.ts` переведена на `withRoute` (291 роут-файл,
~292 handler-а): сырые `export async function GET/POST/PUT/PATCH/DELETE` больше не существуют
в кодовой базе. Это закрывает GAP-MATRIX R/W (IDOR-дрейф конвенций: до кампании 152 GET-роута
шли мимо конвейера auth/trace/ошибок).

Семантика типов (перегрузки в `src/lib/with-route.ts`):
- `withRoute(handler)` / `withRoute(handler, { schema, rateLimit })` → auth: true;
  `ctx.user` на уровне типов НЕ null (композер вернул бы 401 раньше);
- `withRoute(handler, { auth: false })` → публичный эндпоинт; `ctx.user: User | null`,
  проверка на null внутри handler-а обязательна.

Единственное осознанное исключение (whitelist):

- `src/app/api/notifications/stream/route.ts` — SSE-стрим (`text/event-stream`).
  НЕ оборачивается в withRoute: жизненный цикл стрима (открытое соединение, heartbeat,
  отмена клиента) несовместим с композером запрос-ответ. Auth для SSE проверяется
  внутри самого роута.

Публичные роуты (auth:false), выявленные при миграции: `/api/health`, `/api/metrics`
(Bearer METRICS_TOKEN ИЛИ admin-сессия), `/api/taxonomy`, `/api/subscriptions` (GET),
`/api/c/[token]`, `/api/p/[token]`, `/api/email/status`, `/api/lots` (гостевая лента),
`/api/projects` (гостевая лента), `/api/projects/[id]`, `/api/projects/[id]/comments`,
`/api/companies/[id]/claims|cultural-signals` (public + owner/admin-расширение),
`/api/users/[id]/persona`, `/api/wallet/transfer` (410-стаб), `/api` (корневая заглушка),
`/api/admin/*` (Bearer-токены ops, проверка внутри).

Правило для новых роутов: любой новый handler оборачивается в withRoute немедленно;
`req.nextUrl` в handler-е запрещён (Request + `new URL(req.url)` или `ctx.data`);
body — через `ctx.data` (zod-схема в opts.schema).
