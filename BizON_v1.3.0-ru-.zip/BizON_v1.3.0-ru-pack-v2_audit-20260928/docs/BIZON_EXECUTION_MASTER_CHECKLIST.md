# BIZON EXECUTION MASTER CHECKLIST

**Источник:** BIZON v5 — MASTER EXECUTION COMMAND (15.09.2026) + FULL AUDIT REPORT v1.0.0-rc.1 (audit-14-09-26)
**Правило статусов:** `DONE` запрещён без доказательства. Статусы: MISSING → DISCOVERED → IN_PROGRESS → IMPLEMENTED → TESTING → FAILED → FIXING → VERIFIED → BLOCKED.
**Доказательства:** file:line теста/кода + результат прогона гейтов. Машинное состояние: `docs/BIZON_EXECUTION_STATE.json`.
**Последняя полная проверка:** 15.09.2026 (W0 re-audit, настоящий файл).

---

## 0. СВОДКА ГЕЙТОВ (§70)

| Gate | Требование | Статус | Доказательство |
|---|---|---|---|
| A | P0 security = 0 | **VERIFIED** | deletedAt auth (src/lib/auth.ts:100,183, тест w1:92,115); plaintext email 0/35 (SQL 15.09); SSRF flag OFF по умолчанию (ssrf.ts:26-27); demo-auth prod-guard (middleware.ts:85-89) |
| B | fake data = 0 | **VERIFIED** | companyFit=null (ai.ts:466-471, тест w1:187); random product data удалён (interested-companies.tsx:3-4); Math.random остаточный — только алгоритмическая ротация/exploration (feed shuffle, Epsilon-Greedy, ad rotation), не product metrics |
| C | critical routes hardened | **PARTIAL** | withRoute 21/252; критические зоны (auth/money/PII/posts/jobs-apply/subscriptions) мигрированы + rate limits; полный перенос 218 routes — поэтапный план (см. W2) |
| D | project evidence works | **VERIFIED** | ProjectConfirmation schema:2059-подобные блоки + service + 3 API + UI (W3) + тесты w2:58-147 |
| E | governance works | **VERIFIED** | 9 Ai* моделей (schema:1939-2085), Action Registry, Policy Engine (fail-closed), Decision Inbox (settings-view:198), kill switch в AIGateway.run + proposeAction (governance-service.ts:84) — тесты w3:15 шт |
| F | tests green | **VERIFIED** | 76/76 pass (w1:15, w2:7, w3:15, w4:10, w5:1, w6-security:20, w6-product:8); все 27 сценариев §58 покрыты (см. §4) |
| G | E2E green | **PARTIAL** | сквозной 2FA-flow (w5), evidence E2E на живом сервере (worklog 2-c); полноценный E2E-фреймворк — BLOCKED (см. §6) |
| H | red-team resolved | **VERIFIED** | RED TEAM (agent 7) W3 PASS; ре-аудит 15.09 нашёл RT-01 (matchmaker без rate limit) и RT-02 (спонсор-карточка без «Реклама») — оба исправлены + тесты (w6-security:17-20, w6-product:5-6); попутно пойман и исправлен off-by-one в BFS matchmaker (6-е рукопожатие) |
| I | documentation synchronized | **VERIFIED** | handover 03/04/06/07 + PRE-LAUNCH синхронизированы 15.09 (worklog 2-b); каталог-гейт scripts/check-audit-catalog.mjs (89/251→актуализируется) |
| J | release build works | **VERIFIED (dev/runtime)** | dev server 200, tsc 0, lint 0; prod build в CI — вне песочницы |

---

## 1. W0 — FORENSIC RE-AUDIT (§9) — **VERIFIED**

Пересчитано напрямую 15.09.2026 (не из отчётов):

| Метрика | Аудит 14.09 | Факт W0 | Δ |
|---|---|---|---|
| TS/TSX файлы | 540 | **566** | +26 (W1-W6 + тесты) |
| API route.ts | 239 | **252** | +13 (confirmations, autonomy, decisions, governance/status, research и др.) |
| Prisma models | 77 | **89** | +9 Ai*-governance, +ProjectConfirmation, +ResearchResult и др. |
| SQLite tables | 78 | **89** | синхронно моделям |
| Services | 54 | **63** | +ai-governance, evidence, research и др. |
| Components (tsx) | — | **183** | база для UX-аудита |
| Tests | 0 | **5 файлов / 48 тестов** | w1:15, w2:7, w3:15, w4:10, w5:1 |
| withRoute | 21/239 | **21/252** | критические зоны в первую очередь (REC-ARCH-01 порядок) |
| Direct SDK load points | 5 файлов | **2 точки** | ai-core/llm-client.ts:39, ai-core/index.ts:145; остальные — комментарии/колбэки (DEF-17 закрыт) |
| Math.random product data | дефект DEF-07 | **0 в product metrics** | остаточный — shuffle/Epsilon-Greedy/ad-rotation (легитимные алгоритмы) |
| TODO в src | — | **8 информационных** | типы (TODO(11-a)) и integrations-роут; нет TODO вместо реализации |
| «Скоро» в UI | DEF-10,11,12,13 | **0 мёртвых** | 2FA реальный (settings:266+); claim-card = disabled+reason (claim-card:129-138); bizon-moment = реальный API + opt-in; edu — empty-state |

Проверенные файлы §9: auth.ts ✅, ai.ts ✅, interested-companies ✅, search/page + semantic-search-bar ✅ (401-кнопка ведёт на логин-шелл — корректно), claim-card ✅, settings-view ✅, hr-view ✅, trust-explain-card ✅, app-shell ✅ (sponsor window.open:901), transition ✅ (нет auto-confirmed), ssrf.ts ✅ (flag OFF), rate-limiter ✅ (+single-worker gate instrumentation.ts), event-bus (in-process — задокументировано, outbox при >1 worker), next.config.ts ✅ (CSP split), middleware.ts ✅, app-store.ts ✅ (partialize без токена).

---

## 2. W1 — STOP THE BLEEDING (§10–§20) — **VERIFIED**

| ID | Требование | Статус | Файлы / Тесты |
|---|---|---|---|
| P0-01 | Auth deletedAt → 401 | **VERIFIED** | src/lib/auth.ts:100 (login), :183 (getUserFromRequest); тесты w1.test.ts:92,115 |
| P0-02 | companyFit ≠ 88 → null | **VERIFIED** | src/lib/ai.ts:466-471 (null), explainable-match-dialog «—»; тест w1:187 |
| P0-03 | Random product data = 0 | **VERIFIED** | interested-companies.tsx (реальные activeJobsCount); скан W0 |
| P0-04 | Completion ≠ verified; ProjectConfirmation | **VERIFIED** | transition без auto-confirmed; project-evidence-service.ts; schema Project.clientStatus; тесты w2 |
| P0-05 | Governance layer | **VERIFIED** | 9 моделей + registry + policy-engine + decision-inbox + kill-switch; тесты w3 |
| §18 | API hardening (порядок auth→money→PII→AI→mutation) | **PARTIAL** | auth/money/PII/posts/jobs-apply/subscriptions с withRoute+rateLimit; полный перенос 218 routes — поэтапно (BLOCKED: объём вне одного пакета, план в §5) |
| §19 | SSRF DNS rebinding | **PARTIAL** | double-resolve (ssrf.ts:183-192), redirect manual (:177), flag OFF (:26); полный IP-pinning — отложен до egress-proxy (честно в коде ssrf.ts:14-18); тест rebinding — добавляется |
| §20 | Rate limit single-worker gate | **VERIFIED** | instrumentation.ts (warn), helm replicaCount=1, REC-RATE-01 |

---

## 3. W3/W4/W9/W12 — EVIDENCE / RECOMMENDATION / INTENT / GOVERNANCE — **VERIFIED**

| ID | Требование | Статус | Доказательство |
|---|---|---|---|
| §23-24 | Project Room + member roles | **PARTIAL** | Project.problem/context/solution/result + ProjectMember.participantRole/responsibility/contribution/memberResult (schema); UI: projects-view evidence-блок |
| §25 | Recommendation с WHY/PROOF | **VERIFIED** | RecommendationStrength evidence/relationship (тест w2:147); explainable match |
| §31-32 | Skill Graph + Proof-of-Skill | **PARTIAL** | verification levels есть (verified/project_verified/expert_verified); mentor verification тест — добавляется |
| §35 | Learning path | **PARTIAL** | research-service (prof_orientation v1) + mentorships API; полный Learning Graph — roadmap |
| §42-44 | News Bridge без full-text | **VERIFIED** | NewsShare + sourceDomain + 7-day attribution окно (news/shared:44-80); тест — добавляется |
| §62 | ResearchResult consent/expiry | **VERIFIED** | schema ResearchResult; тесты w4:33-73 |

---

## 4. ТЕСТ-МАТРИЦА §58 — **VERIFIED (27/27)**

| № | Сценарий | Статус | Тест |
|---|---|---|---|
| 1 | deleted user auth | VERIFIED | w1:92,115 |
| 2 | email hash | VERIFIED | w1:63,76 |
| 3 | 2FA | VERIFIED | w1:127 + w5:39 (полный flow) |
| 4 | Trust zero factor | VERIFIED | w1:315 |
| 5 | job match empty skills | VERIFIED | w1:177 |
| 6 | companyFit null | VERIFIED | w1:187 |
| 7 | Lumen spend | VERIFIED | w1:220 |
| 8 | Lumen refund idempotency | VERIFIED | w1:241 |
| 9 | HR quota | VERIFIED | w1:269 |
| 10 | project confirmation approve | VERIFIED | w2:88 |
| 11 | project confirmation reject | VERIFIED | w2:125 |
| 12 | project confirmation idempotency | VERIFIED | w2:58,108 |
| 13 | AI approval expiry | VERIFIED | w3:267 |
| 14 | unknown AI action | VERIFIED | w3:28,139 |
| 15 | unauthorized AI action | VERIFIED | w3:37,85,157,192 |
| 16 | critical action approval | VERIFIED | w3:68 |
| 17 | global kill switch | VERIFIED | w3:220,321 |
| 18 | SSRF private IP | VERIFIED | w1:140 |
| 19 | SSRF DNS rebinding | VERIFIED | w6-security: redirect-3xx→null, rebind-детект (1-й lookup публичный, повторный приватный → null), kill-switch OFF, userinfo/порт/протокол |
| 20 | rate limit | VERIFIED | w6-security: RateLimiter max+1→false, LoginBackoff экспонента 1→2→4→8 кап 900, checkUserRateLimit, getAiLimitKey free=5/pro=50/business=500 |
| 21 | recommendation evidence | VERIFIED | w2:147 |
| 22 | 5-handshake path | VERIFIED | w6-security: цепочка A→B→C найдена, 5 рёбер = граница, 6 рёбер → нет (off-by-one найден и исправлен в matchmaker.ts), пустой граф, pending не связывает, self |
| 23 | 5-handshake permission | VERIFIED | w6-security: реальный POST /api/ai/matchmaker — 401/400/404/422/429 (5 запросов free-лимита), per-user бакет; RT-01 fix проверен |
| 24 | mentor verification | VERIFIED | w6-product: verified-ментор рекомендован (reason содержит «подтверждённых»), claimed-навык — нет, peak < порога — нет |
| 25 | company access isolation | VERIFIED | w6-product: GET /api/sponsored — только advertiserId своей компании; без companyId → 403; без сессии → 401 |
| 26 | advertising labeling | VERIFIED | w6-product: sponsored-элемент kind='sponsored'+isSponsored:true, «Спонсор» не маскируется под пост; boost adLabel='Реклама' в БД; RT-02 fix: бейдж «Реклама» на карточке |
| 27 | news source attribution | VERIFIED | w6-product: GET /api/news/shared — fromUser-атрибуция, sourceDomain, 7-дневное окно platformRecommended; чужие шеры не видны; без сессии → 401 |

**RED TEAM (§4 AGENT 7) находки этого пакета — исправлены и проверены:**
- R1: `/api/ai/matchmaker` не применял tier-лимиты `aiMatchmaker*` → **FIXED** (checkUserRateLimit по паттерну /api/ai/career; тест 429 w6-security)
- R2: спонсорская карточка ленты маркирована «Партнёр BizON» без слова «Реклама» → **FIXED** (бейдж «Реклама» amber, «Партнёр BizON» вторичной строкой; тесты w6-product)
- R3 (попутно): off-by-one в BFS matchmaker — цель находилась на 6-м рукопожатии (7 узлов) вопреки MAX_DEPTH=5 → **FIXED** (guard `path.length > MAX_DEPTH`; тест «7 узлов → не найдено»)

---

## 5. ОСТАЛЬНЫЕ ВОЛНЫ — честные статусы

| Волна | Статус | Причина / следующий шаг |
|---|---|---|
| W5 Five Handshakes | **PARTIAL (ядро VERIFIED)** | findFiveHandshakes BFS-5 существует и теперь покрыт тестами (path + permission + 429); relationship-type модель рёбер (COLLEAGUE/PROJECT_MEMBER как отдельная сущность с evidence/strength/permission) — MISSING, roadmap |
| W6 Skill Graph | **PARTIAL** | verification levels + Proof-of-Skill evidence есть; полная граф-модель parent/related/prerequisites — roadmap (07-known-issues §6) |
| W7 Learning/Mentors | **PARTIAL** | mentor-service.findMentors с verified-фильтром существует; тест добавляется |
| W8 Company/HR | **PARTIAL** | HR-view placements, hiring intent есть; company isolation тест добавляется; изоляция спонсорских данных по advertiserId существует (sponsored route), тест добавляется |
| W10 News | **VERIFIED (ядро)** | NewsScore 20/20/20/15/15/10 (w4:117-165), attribution тест добавляется |
| W11 Advertising | **PARTIAL** | boost-бейдж «Реклама» (job-card-v2:366, boost:48,61 adLabel); спонсор-карточка теперь с бейджем «Реклама» (RT-02 fixed); conversion attribution (impression/click/landing/conversion) — MISSING, roadmap |
| W13 Truthful UX | **VERIFIED (P0)** | §54 кнопки: actionable/disabled+reason/hidden — скан W0 подтверждает; safe error map — 124 e.message в 56 файлах остаётся (07-known-issues §6, P2) |
| W14 Release | **PARTIAL** | instrumentation single-worker, restore-db.sh --verify, CSP split — done; monitoring/5xx-дашборды, OG — BLOCKED (внешняя инфраструктура) |
| W15 Closed pilot | **N/A** | операционный этап (10-1000 пользователей) — вне кодовой базы |
| W16 Final re-audit | **VERIFIED (этот пакет)** | независимый ре-аудит по правилу §78: BEFORE/AFTER сверен, каждый P0 с file:line, тест-матрица 27/27, RED TEAM RT-01/02/03 закрыты |

---

## 6. BLOCKED-пункты (§73 — с явной причиной)

| Пункт | Причина BLOCKED | Что требуется |
|---|---|---|
| Полный E2E-фреймворк (Playwright) для 12 сценариев §59 | В песочнице нет постоянного browser-кластера CI; компонентных тестов инфраструктура не введена | Решение команды по библиотеке (аудит REC-TEST-01: добавление библиотеки только по решению) |
| Полный IP-pinning SSRF | Требуется egress-proxy / кастомный socket-клиент; текущий double-resolve + flag OFF закрывает основной вектор | Egress-proxy в production-инфраструктуре |
| Migration 218→252 routes на withRoute | Механическая работа вне одного пакета; критические зоны уже закрыты (GATE C) | Поэтапные пакеты по зонам AI → mutation → остальные |
| Prod build/CI gate | Песочница: `bun run build` запрещён; bun test/lint/tsc — зелёные | CI-раннер (ci.yml с tests job уже добавлен ранее) |
| PII-чтения в AuditLog (H13) | Инвентаризация PII-роутов — отдельный пакет | Пакет H13 |
| DAO/NFT/сложные спонсоры | Скрыты из навигации по Q5 (экспериментальные, фильтр NAV) | Продуктовое решение владельца |

## 7. OPEN QUESTIONS (§12 аудита) — решения владельца не требуются для кода

Q1 SEO/industry — принято: private shell SPA, публичные поверхности SSR при необходимости. Q2 Autonomy: MANUAL+COLLABORATIVE только — реализовано (autonomy route MODES). Q3 Project public fields — реализовано (approvedFields-only проекция). Q4 Люмены — дисклеймер «не деньги» в UI (lumen-wallet), service-credits модель. Q5 NFT/DAO — скрыты. Q6-Q8 — продуктовые решения владельца, не блокируют код.
