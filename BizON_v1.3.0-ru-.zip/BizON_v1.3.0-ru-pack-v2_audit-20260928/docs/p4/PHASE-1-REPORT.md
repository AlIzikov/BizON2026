# П4 · ОТЧЁТ ПО ФАЗЕ 1 — Hub-архитектура

**Дата:** 2026-09-29 · **Статус:** ЗАВЕРШЕНА (код) · **Дедлайн 7 дней — уложился**
**Коммиты:** `2775402` (В5+инцидент) → `b47f81a` PR-2 → `43b64b9` PR-3 → `27cc310` PR-4a → `5870cef` PR-4b → `77d95ef` PR-5 → `8602fa7` PR-6/7 → `3d36b84` PR-8

---

## 1. Что построено (факты, не обещания)

### 1.1 Ядро хабов
| Артефакт | Где | Факт |
|---|---|---|
| Модель `ExternalServicePort` | prisma/schema.prisma (аддитивно) | code unique, категория+isActive/priority индексы, **42 порта в БД** |
| Ядро | `src/lib/hubs/core.ts` | HUB_CATEGORIES=13, getActivePortRecord, requiredEnvStatus (факты env **без значений**), requireReadyPort |
| Манифест | `config/integrations.manifest.yaml` | **42 пункта INT-001…042**, zod-схема fail-closed, биндинг port_code |
| Загрузчик | `src/lib/hubs/manifest.ts` | канон id/codes, нарушения манифеста = ошибка старта |
| Интеграционный хаб | `src/lib/hubs/integration-hub.ts` | getActivePort / requireIntegration / resolveAdapter; честные отказы HUB_NO_ACTIVE_PORT / ADAPTER_NOT_IMPLEMENTED / ENV_MISSING |

### 1.2 Категории: 13 (не 12) — расхождение зафиксировано
Директива называет «12 категорий», но перечисляет 13 пунктов. Принято **супермножество 13** (все перечисленные + никакие не выброшены): `email, storage, push, kyc, search, observability, payments, receipt, blockchain, sms, notifications, ai, analytics`. Решение задокументировано в ADR-007. Если владелец настаивает на 12 — конкретную категорию можно исключить одним удалением порта+манифест-строки, архитектура не меняется.

### 1.3 Хабы и адаптеры (17 файлов адаптеров)
13 хабов × {port.ts, hub.ts, index.ts, adapters/} по единому эталону (email). Адаптеры:
- **console-стабы** — во всех 13 (честная семантика: наружный эффект → `ok:false 'STUB: …'`; раковины observability/analytics → `ok:true`; console.log **только внутри adapters/**; PII маскируется);
- **in-house** — payments/demo-virtual (делегирование CashierPortsService: идемпотентность и realMoneyGate сохранены), notifications/in-app-db, analytics/in-house-actions, storage/local-disk (path-traversal sanitize, probe round-trip);
- **real-провайдеры — 0 адаптеров реализовано** (по плану Фазы 2.1–2.2: yookassa, tinkoff, yookassa-receipt, atol-online).

### 1.4 Admin UI + API + CLI
- **UI:** вкладка «Интеграции» в /admin — 13 аккордеон-групп, строки портов (provider/code/kind/mode/priority/активен/факт адаптера/env-точки с именами отсутствующих, **без значений**), кнопки «Тест» и «Активировать» с честными гейт-тостами;
- **API:** GET /api/admin/integrations; POST activate (гейты 404/422/501 ADAPTER_NOT_IMPLEMENTED/ENV_MISSING, атомарный «ровно 1 активный на категорию», AuditLog INTEGRATION_ACTIVATED); POST test (честный 501, когда адаптера нет);
- **CLI:** `bun scripts/integrations:status|verify|activate` — те же гейты, что API; verify принимает code|INT-id; exit-коды как гейт.

### 1.5 Пин
`tests/pins/p4-hub.pin.test.ts` — **15/15, 246 expect()** (схема/13 хабов/ядро/нет console вне adapters/манифест zod+канон/seed↔манифест/admin-гейты/CLI/REQUIRED_ENV↔манифест 42/42).

---

## 2. Критерий владельца «смена provider без изменений кода» — как доказано
Канонический сценарий: `activate-integration <code>` или кнопка «Активировать» в админке → переключение isActive ровно одной записи ExternalServicePort → следующий вызов `getActivePort('payments')` отдаёт другой адаптер. **Ни одна строка бизнес-кода не меняется** — код никогда не импортирует адаптер напрямую, только хаб. Сегодня реально переключаются: payments→demo-virtual, storage→local-disk, notifications→in-app-db, analytics→in-house-actions, плюс консольные стабы прочих категорий.

## 3. Решения в границах автономии
1. **ADR-007** (`docs/adr/adr-external-service-hub.md`): CashierPort **не мигрирует**, работает параллельно с payments-хабом (demo-virtual делегирует в него); миграция = **стоп-граница владельца**, рекомендация — Фаза 2.1 после e2e адаптеров.
2. 13 категорий = супермножество списка директивы (см. §1.2).
3. «42 пункта манифеста» — 42 порта/13 категорий с полным биндингом (INT-001…042), каждый с required_env, activation и verification.
4. Инцидент ролловера (эон №3) до Фазы 1: .env/keyfile вне снапшотов → реставрация по эон-устойчивым протоколам ротации; рекомендация владельцу — offsite-копия .env при получении Б1-ключей.

## 4. Верификация
| Проверка | Результат |
|---|---|
| Полный прогон | **1215 pass / 0 fail** (baseline 1200 улучшен) |
| Пин p4-hub | 15/15, 246 expect |
| lint | 0 errors (6 предсуществующих warnings) |
| clean-tree-gate | чистое дерево, все PR закоммичены до отчёта |
| REQUIRED_ENV ↔ манифест | 42/42 |
| Браузерная E2E вкладки | рендер 13 категорий, Тест → честный 501, Активировать → 200 + смена бейджа + возврат канона, mobile 390 без overflow, консоль чистая |
| В5 (вне Фазы 1, выполнено) | qa-01..05@bizon.test ротированы (криптослучайные, .env BIZON_QA_PASSWORDS, сессии отозваны, AuditLog) |

## 5. Границы и что НЕ сделано (честно)
- **Real-адаптеров нет** — так задумано: Фаза 1 = каркас, Фаза 2 = содержимое. Каждый real-порт в БД `pending`, факт адаптера в UI честно читает «подключение в Фазе 2».
- Смена провайдера для категорий с единственным real-провайдером **не проверяется e2e до Фазы 2.1** (нечем переключаться) — после yookassa/tinkoff добавлю пин «смена активного порта payments меняет адаптер без правки кода».
- PG-cutover (Вариант A, Решение 8 подтверждён) — Фаза 2.4, groundwork ADR-004 готов.

## 6. Старт Фазы 2 (порядок)
2.1 payments yookassa+tinkoff+webhooks → 2.2 receipt 54-ФЗ (модель+retry+2 адаптера) → 2.3 мультивалютность (ExchangeRate+ЦБ РФ cron+/api/pricing?currency=) → 2.4 Yandex Cloud порты pending + соучер-адаптеры при Б1 → 2.5 РКН-уведомление → 2.6 ToS/Privacy РФ → 2.7 ИТ-доходы (Revenue+дашборд). Стоп-границы: договор YooKassa/бюджет >$5k — владелец.
