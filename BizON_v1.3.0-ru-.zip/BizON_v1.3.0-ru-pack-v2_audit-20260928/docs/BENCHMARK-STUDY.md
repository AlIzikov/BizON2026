# BENCHMARK STUDY — 13 эталонных проектов (цикл изучения закрыт)

Дата изучения: 17-09. Метод: первоисточники загружены с raw.githubusercontent.com (README + ключевые
спеки, корпус в /tmp/bench: 12 README + ASVS README + OTel GenAI spans/metrics/events ~264KB).
Для каждого проекта: принципы ИЗ ПЕРВОИСТОЧНИКА → статус интеграции в BizON с evidence → правило применения.

Легенда статуса: ✅ РЕАЛИЗОВАНО (код+тесты) · 📋 КОДИФИЦИРОВАНО (процесс-документ) · 🟡 P1/P2 (расписано в GAP-MATRIX)

---

## №01 — OpenHands / Agent Canvas (All-Hands-AI/OpenHands)

**Источник**: README.md, branch main. Проект эволюционировал в «Agent Canvas» — self-hosted control center
для coding-агентов и автоматизаций (OpenHands, Claude Code, Codex, любой ACP-совместимый агент).

**Ключевые принципы (из первоисточника):**
1. Control Center поверх нескольких agent-бэкендов (local / Docker / VM / cloud) — переключение без потери фокуса.
2. Automation Server: агенты запускаются по расписанию ИЛИ по webhook-событиям (Slack, GitHub, Linear).
3. Изоляция исполнения: Docker-песочница с монтированием только PROJECTS_PATH; запуск без песочницы помечен WARNING («full access to your filesystem!»).
4. Явные repository boundaries (таблица): frontend / SDK+Agent Server / TS-client / automation — каждый репозиторий владеет своим поведением; AGENTS.md фиксирует границы для контрибьюторов.
5. Agent Server = REST API для многих агентов на одной машине; ACP (Agent-Client Protocol) как plugs для любых агентов.
6. Работа агента = conversation + events (каждый шаг событие, наблюдаемо).

**Интеграция в BizON**: ✅ + 🟡
- Control Center ≈ Decision Inbox + /api/ai/governance/{status,traces,execute} (живой контур, w3/w7/w9).
- Conversation+events ≈ AiAction + AiAuditLog + AiTrace на каждый шаг агента.
- Бэкенд-агностичность ≈ AIGateway с modelRoute (z-ai / heuristic / cache).
- 🟡 P2: automation по расписанию/webhook (News Bridge) — ждёт решения владельца о внешних источниках.

**Правило применения**: агентный шаг = событие с evidence (кто/что/когда/результат); новые агенты
подключаются через единый реестр действий и gateway, никогда — прямым вызовом модели из роута.

---

## №02 — Cline (cline/cline)

**Источник**: README.md, branch main. Кодинг-агент: CLI, VS Code, JetBrains, Desktop, SDK.

**Ключевые принципы (из первоисточника):**
1. Plan/Act: сначала исследование кодовой базы + стратегия, потом исполнение; переключение режимов явное.
2. Human-in-the-loop: каждое редактирование файла и каждая команда требуют одобрения; авто-approve — отдельный переключатель (градуированная автономия).
3. Каждое изменение = diff на ревью; checkpoints позволяют откатить работу агента целиком.
4. Агент мониторит linter/compiler ошибки ПО ХОДУ работы и чинит их до того, как увидит человек.
5. `.clinerules` — правила проекта подхватываются автоматически; skills загружают правила по необходимости.
6. Plugin SDK: lifecycle hooks именно для logging, auditing, policy enforcement.
7. Multi-agent teams: координатор декомпозирует и делегирует специалистам; state команды персистентен между сессиями.
8. Scheduled agents: cron-расписания переживают рестарты, независимы от терминала.
9. Модель-агностичность: любой провайдер.

**Интеграция в BizON**: ✅ (P0, закрыто — worklog gap-matrix-p0-17-09)
- propose→approve→execute = Plan/Act c явным одобрением: src/lib/ai-governance/governance-service.ts.
- AiApproval TTL 15 мин, single-use, expiry-check — approve ≠ execute; re-check политики+бюджета перед исполнением.
- Автономия: 5 режимов × матрица риска (policy-engine.ts), kill-switch env+персистентный.
- Checkpoint ≈ outputHash (SHA-256) + AiAuditLog на каждый шаг; UI: src/components/settings/decision-inbox.tsx.
- Модель-агностичность = AIGateway (src/lib/ai-core/gateway.ts).

**Правило применения**: любое действие агента — propose (или recordDirect для user-initiated) с риском из
реестра; исполнение ТОЛЬКО после re-check; diff-подобный артефакт (вход/выход/hash) обязателен для ревью.

---

## №03 — Superpowers (obra/superpowers)

**Источник**: README.md, branch main. «Полная методология разработки для кодинг-агентов» на композируемых скиллах.

**Ключевые принципы (из первоисточника):**
1. Workflow = обязательные скиллы («Mandatory workflows, not suggestions»), триггерятся автоматически перед каждой задачей.
2. Brainstorming: спека вытягивается вопросами, показывается порциями для чтения, сохраняется документ дизайна.
3. Изоляция: git worktree на новую ветку + чистая тестовая база до начала.
4. writing-plans: задачи по 2–5 минут, КАЖДАЯ с точными путями файлов, полным кодом и шагами верификации.
5. Двухступенчатое ревью: сначала соответствие спеке, ПОТОМ качество кода.
6. TDD RED-GREEN-REFACTOR enforced; код, написанный до теста, УДАЛЯЕТСЯ.
7. verification-before-completion — отдельный скилл «Ensure it's actually fixed».
8. systematic-debugging: 4-фазный root-cause процесс.
9. Философия: TDD всегда; систематичность поверх ad-hoc; снижение сложности; **evidence over claims — verify before declaring success**.

**Интеграция в BizON**: 📋 → docs/AGENT-WORKFLOW.md (этот цикл)
- Наша дисциплина UNDERSTAND→PLAN→IMPLEMENT→TEST→REVIEW→VERIFY→EVIDENCE→DONE — прямое воплощение.
- Усилено по итогам повторного изучения: (a) двухступенчатое ревью (спека→качество) — в workflow §5;
  (b) verification-before-completion как отдельный обязательный гейт — §6; (c) 4-фазный дебаг — §7.
- TDD-требование адаптировано: бизнес-логика — тест сначала; UI-обвязка — тест сразу после (правило §4).

**Правило применения**: DONE запрещён без VERIFY+EVIDENCE; «сделал частично» никогда не репортится как DONE;
ревью всегда в два прохода; баг чинится root-cause, не симптомом.

---

## №04 — Aider (Aider-AI/aider)

**Источник**: README.md, branch main. AI pair programming в терминале.

**Ключевые принципы (из первоисточника):**
1. Repo map: карта всей кодовой базы (в т.ч. больших) — контекст отношений между файлами.
2. Git-интеграция: авто-коммиты с осмысленными сообщениями; diff/undo AI-изменений привычными инструментами.
3. Lint+test после КАЖДОГО изменения; авто-фикс обнаруженных проблем.
4. Coordinated multi-file edits: понимает связи файлов, меняет согласованно.
5. Мульти-модальный контекст: изображения и URL прямо в чат.

**Интеграция в BizON**: 📋 + ✅ рутина
- Repo map ≈ docs/BIZON-GAP-MATRIX.md (26 доменов) + docs/solutions/ (durable знания) + worklog.
- Lint+test после каждого изменения = наши гейты TSC/LINT/TEST после каждой задачи (уже рутина).
- Git-дисциплина: осмысленные коммиты + worklog-записи с Task ID.
- Full-vertical правило (функция не реализована, пока не пройдена вся вертикаль) → docs/AGENT-WORKFLOW.md §4.

**Правило применения**: изменение функции = вся вертикаль UI→API→service→DB→Prisma→validation→
permissions→tests→docs; «поменял только UI» ≠ «функция реализована»; гейты после каждой задачи, не в конце.

---

## №05 — SWE-agent / mini-SWE-agent (SWE-agent/SWE-agent)

**Источник**: README.md, branch main. Princeton/Stanford; SWE-bench SOTA среди open-source.
ВАЖНО: разработка сместилась на mini-SWE-agent («matches the performance while being much simpler»).

**Ключевые принципы (из первоисточника):**
1. **mini-SWE-agent: 65% SWE-bench verified в 100 строках Python** — простота бьёт сложность.
2. Agent-Computer Interfaces (ACI): заголовок статьи — «ACI Enable Automated Software Engineering». Дизайн интерфейсов инструментов решает больше, чем промпт.
3. Конфигурация одним YAML-файлом — вся управляемость в одном месте.
4. SWE-bench methodology: оценка на РЕАЛЬНЫХ issues, а не синтетике.
5. Free-flowing: максимальная свобода модели внутри жёсткого контура инструментов.

**Интеграция в BizON**: ✅ методология
- Аудит-конвейер AUDIT FINDING→CODE LOCATION→ROOT CAUSE→FIX→TEST→VERIFICATION→EVIDENCE — применён в GAP-MATRIX и fix-работах (пример: живой e2e нашёл 2 бага контура — worklog gap-matrix-p0).
- Action Registry (12 действий с риском/обратимостью/внешними эффектами) — наш ACI: дизайн интерфейса действия первичен.
- Eval-suite = наш SWE-bench: 1259 сценариев, exit 1 при FAIL.

**Правило применения**: новые инструменты агента проектировать как ACI (узкие, безопасные, описываемые);
каждая находка — по полному формату с root cause; не усложнять без бенчмарка (урок mini-swe-agent).

---

## №06 — LangGraph (langchain-ai/langgraph)

**Источник**: README.md, branch main. «Low-level orchestration framework for stateful agents».

**Ключевые принципы (из первоисточника):**
1. Durable execution: воркфлоу переживает падения, возобновляется ТОЧНО с места остановки.
2. Human-in-the-loop interrupts: инспекция и модификация состояния агента в ЛЮБОЙ точке исполнения.
3. Память двух уровней: short-term working memory + long-term persistent memory между сессиями.
4. Глубокая наблюдаемость: трассировка путей исполнения, state transitions, runtime-метрики.
5. Низкоуровневая оркестрация графом (вдохновлено Pregel/Apache Beam) для long-running stateful workflows.

**Интеграция в BizON**: ✅ (P0, закрыто совместно с №02)
- Durable state machine: AiAction pending→approved→executed/failed в Prisma — не в памяти процесса.
- Interrupt = approval gate (AiApproval TTL) — исполнение останавливается до решения человека.
- Long-term память = AiGoal/AiAuditLog/docs/solutions; short-term = контекст запроса.
- State transitions = AiTrace спаны + AiAuditLog шаги (w9).

**Правило применения**: любой multi-step агентский процесс пишется как персистентная state machine с
точками interrupt, НЕ как один длинный вызов; после падения — продолжение с сохранённого шага.

---

## №07 — Daytona (daytonaio/daytona)

**Источник**: README.md, branch main. ВАЖНО: репозиторий более не поддерживается (June 2026 — core
ушёл в приватный кодбейс); паттерны остаются публичными и применимыми.

**Ключевые принципы (из первоисточника):**
1. Sandbox = «full composable computer»: полная изоляция, собственные kernel/filesystem/network stack, выделенные vCPU/RAM/disk.
2. Spin-up <90ms; snapshots — персистентное состояние среды между сессиями.
3. Platform governance из коробки: organizations, API keys, limits, billing, **audit logs**, **OpenTelemetry**, network limits, webhooks.
4. Архитектура плоскостей: interface / control / compute — чёткое разделение ответственности.
5. Agent tools vs Human tools vs System tools — отдельные поверхности для разных типов доступа.

**Интеграция в BizON**: ✅ адаптация под среду
- Изоляция: проект исполняется в собственной песочнице (ограниченный порт-экспозит, gateway-проксирование,
  curl --noproxy) — паттерн «compute plane отделена от интернета» соблюдён средой.
- Governance control plane = ai-governance (лимиты, аудит, kill-switch); network limits = rateLimit 30/10min
  в with-route.ts; OTel = w9.
- 🟡 P2: полный sandbox-per-action для автономных уровней 4–5 (за фича-флагом, по GAP-MATRIX).

**Правило применения**: любой внешний эффект агента (сеть/файлы/почта) — только через контролируемую
плоскость с лимитом и аудитом; прежде чем дать агенту способность, спросить «где её песочница?».

---

## №08 — browser-use (browser-use/browser-use)

**Источник**: README.md, branch main. Открытый браузерный агент (Python/TS) + облако ($0.02/browser-hour).

**Ключевые принципы (из первоисточника):**
1. Навигация «как человек»: найти слот, выбрать дату, решить CAPTCHA, забронировать — end-to-end сценарии.
2. Три пути внедрения: hosted cloud / CLI / локальная библиотека — один агент, разные плоскости доверия.
3. **llms.txt** — машиночитаемая карта продукта для AI-агентов (и llms.txt для доков) — новый стандарт публикации.
4. Разделение Agent и Browser: модель и браузерная среда выбираются независимо.
5. Stealth + CAPTCHA + residential proxies — реальность работы с внешним вебом (этические границы явно не оговорены в README — применять осторожно).

**Интеграция в BizON**: 🟡 P2 + ✅ защита
- News Bridge (внешние источники вакансий/новостей браузерным агентом) — P2 в GAP-MATRIX: требует решения
  владельца по источникам и правовому периметру.
- Внешний контент УЖЕ считается недоверенным: prompt-sanitizer wrapUntrusted + EXTERNAL_DATA_RULES
  (src/lib/security/prompt-sanitizer.ts) — внешний текст никогда не инструкции.
- Паттерн llms.txt: добавить машиночитаемую карту BizON API — P1-кандидат, безвреден.

**Правило применения**: всё, что пришло из веба — <untrusted_external_data> обёртка до модели; браузерные
действия = externalSideEffect=true в реестре →最高 approval level; ни одного браузерного шага вне контура аудита.

---

## №09 — Promptfoo (promptfoo/promptfoo)

**Источник**: README.md, branch main. LLM evals + red teaming. ВАЖНО: Promptfoo теперь часть OpenAI
(остаётся open source, MIT).

**Ключевые принципы (из первоисточника):**
1. Evals и red teaming в одном CLI: «Stop the trial-and-error approach».
2. Автоматизация проверок в CI/CD; ревью PR на LLM-безопасность (code scanning).
3. Приватность: evals исполняются 100% локально, промпты не покидают машину.
4. Side-by-side сравнение моделей/промптов/провайдеров.
5. Battle-tested: LLM-приложения на 10M+ пользователей.

**Интеграция в BizON**: ✅ (закрыто — worklog ai-eval-suite-17-09)
- BIZON AI EVALUATION SUITE: **1259 сценариев, 10 категорий** (permissions 189, tool_safety 94,
  prompt_injection 619, data_leakage 41, privacy 44, correctness 102, hallucination 46,
  recommendation_quality 47, security 51, regression 26) — src/lib/ai-eval/.
- Судьи ТОЛЬКО rule-based (спек-таблицы и white-list независимы от тестируемого кода); LLM — испытуемый,
  не судья (BIZON_AI_EVAL_LLM=1, env-гейт).
- CI-гейт: run-eval exit 1 при FAIL; отчёт docs/ai-eval/REPORT-latest.{json,md}; тесты w8.

**Правило применения**: любое изменение AI-поведения = новый eval-сценарий + полный прогон сьюта;
найденный на eval FAIL не «подгоняется» под тест — чинится причина; self-оценка AI запрещена.

---

## №10 — OWASP ASVS 5.0 (OWASP/ASVS)

**Источник**: README.md, branch master. Актуальная стабильная версия — **5.0.0 (May 2025)**; есть
официальная русская версия PDF.

**Ключевые принципы (из первоисточника):**
1. Стандарт = каталог тестопригодных требований; ID формата `chapter.section.requirement` (напр. 1.11.3).
2. v5.0 переработал структуру (глава 1 — Encoding and Sanitization; наш V14-v4-нумерация устарела — при ссылках сверяться с 5.0).
3. Уровни верификации по риск-профилю системы.
4. Требование-ориентированность: каждое требование можно превратить в CHECK или AUTOMATED TEST.

**Интеграция в BizON**: ✅ частично (закрыто — worklog gap-matrix-p0-17-09)
- Security headers: CSP + base-uri 'self' + object-src 'none' (next.config), HSTS в prod — курл-проверка.
- Security-матрица: tests/w6-security-matrix.test.ts; auth/password-policy (w5).
- 🟡 P1: разметка остальных применимых требований v5.0 (auth/session/access-control) в GAP-MATRIX с ID-ссылками.

**Правило применения**: каждое применимое требование ASVS превращается в CHECK или автоматический тест;
в отчётах ссылаться ID-форматом; при апгрейде стандарта — пересверка нумерации.

---

## №11 — OWASP AISVS 1.0 (OWASP/AISVS)

**Источник**: README.md + список глав (1.0/en). AI-версия ASVS: «verifiable, testable, implementable».

**Ключевые принципы (из первоисточника):**
1. НЕ governance-фреймворк (это NIST AI RMF / ISO 42001 / EU AI Act) — именно ТЕХНИЧЕСКИЕ контроли.
2. Уровни 1/2/3; production-системы с персональными данными — минимум **Level 2**.
3. 12 глав: C01 Training Data, C02 Input Validation, C03 Model Lifecycle, C04 Infrastructure,
   C05 Access Control, C06 Supply Chain, C07 Model Behavior, C08 Memory/Embeddings,
   **C09 Orchestration & Agentic Action**, **C10 MCP Security**, C11 Adversarial Robustness, C12 Monitoring & Logging.
4. Применение: дизайн-чеклист → CI/CD → аудит → procurement.

**Интеграция в BizON**: ✅ частично (закрыто — worklog ai-eval-suite-17-09)
- C02 Input Validation = prompt-sanitizer: 11 правил инъекций (override en/ru, extraction, role-hijack,
  tool-coercion, exfiltration, credential-hunt…), PII-редакция, zero-width/control-символы, лимиты —
  src/lib/security/prompt-sanitizer.ts.
- C09 Agentic Action = governance-контур: реестр действий, матрица риск×режим, re-check, инциденты.
- C12 Monitoring = AiTrace + AiAuditLog + eval-отчёт.
- 🟡 P1: формальный чек-лист C02/C05/C09/C12 по уровням для всех AI-роутов (аддитивно в GAP-MATRIX).

**Правило применения**: target уровень = 2; каждая новая AI-фича проверяется по чек-листу
C02 (вход) / C05 (доступ) / C09 (агентное действие) / C12 (наблюдаемость) до DONE.

---

## №12 — OpenTelemetry GenAI Semantic Conventions (open-telemetry/semantic-conventions-genai)

**Источник**: README + полные спеки gen-ai-spans.md (122KB), gen-ai-metrics.md (98KB),
gen-ai-events.md (43KB), gen-ai-agent-spans.md — branch main.

**Ключевые принципы (из первоисточника):**
1. Конвенции gen_ai.* на трёх поверхностях: spans (Inference / Execute tool / Retrieval / Memory / Embeddings), events, metrics.
2. Канонические атрибуты (инвентаризация из спеков): `gen_ai.operation.name`, `gen_ai.request.model`,
   `gen_ai.response.model`, `gen_ai.response.finish_reasons`, `gen_ai.usage.*_tokens`, `gen_ai.provider.name`,
   `gen_ai.agent.{id,name,version}`, `gen_ai.conversation.id`, `gen_ai.tool.definitions`,
   `gen_ai.system_instructions`, `gen_ai.output.type`.
3. Агентские спаны ОТДЕЛЕНЫ от inference-спанов (агент-воркфлоу ≠ вызов модели).
4. Корреляция через W3C trace/span id; события несут контент отдельно от метаданных спана.

**Интеграция в BizON**: ✅ (закрыто — worklog otel-trace-17-09)
- Модель AiTrace: traceId (W3C 32hex) / spanId / parentSpanId / operation / agentId / userId / actionId /
  genAiSystem / modelRoute / provider / autonomyMode / status / errorCode / latencyMs / tokens / costUnits /
  attributesJson + 4 индекса.
- middleware.ts: traceId на КАЖДЫЙ запрос (входящий валидный переиспользуется); with-route.ts: ALS-биндинг,
  спаны наследуют контекст; gateway.ts: спан на каждый вызов модели (ok/fallback/rate_limited/blocked/error).
- Живая верификация: POST /api/ai/project-match → 5 спанов ОДНОГО traceId (4× project.match.why + 1×
  governance.user_direct); GET /api/ai/governance/traces отдаёт только свои.
- 🟡 P2: заполнение finish_reasons / conversation.id / tool.definitions (нет данных из ZaiCompletion usage).

**Правило применения**: каждый новый AI-роут обязан оставлять спаны по этим полям (WHO/WHAT/WHEN/WHY/
AGENT/MODEL/DECISION/RESULT/ERROR/COST); экспорт в настоящий OTel-коллектор возможен позже поверх тех же
полей без миграции.

---

## №13 — GLM-4.5 / 4.6 / 4.7 (zai-org/GLM-4.5)

**Источник**: README.md, branch main. Собственная модельная экосистема BizON (Z.ai SDK).

**Ключевые принципы (из первоисточника):**
1. Hybrid reasoning: режим thinking для сложных задач и tool-use, non-thinking для быстрых ответов.
2. GLM-4.7: **Interleaved Thinking** (думать перед каждым ответом/вызовом инструмента), **Preserved Thinking**
   (сохранение блоков рассуждения между турами — меньше потери и несогласованности на длинных задачах),
   **Turn-level Thinking** (per-turn контроль reasoning: отключать для лёгких запросов = экономия
   latency/cost, включать для сложных = точность).
3. SWE-bench 73.8% (4.7), Terminal Bench 2.0 41%; интеграция в agent-фреймворки (Claude Code, Cline, Roo, Kilo).
4. GLM-4.7-Flash (30B-A3B) — лёгкий вариант для быстрого исполнения.
5. MIT-лицензия, открытие MTP/speculative-конфигураций.

**Интеграция в BizON**: ✅ использование + соответствие
- AIGateway (src/lib/ai-core/gateway.ts): роуты llm-fast / llm + heuristic fallback + cache — фактически
  реализует Turn-level принцип: лёгкие операции (рейтинг новости) на fast-роуте, сложные (match-объяснения)
  на полноценной модели; простой код — heuristic без LLM.
- latency/кост уже замеряются в AiTrace → данные для будущей маршрутизации по цене/качеству.
- 🟡 P2: Preserved Thinking для длинных агентских сессий (зависит от SDK-поддержки проброса thinking-блоков).

**Правило применения**: выбор роута по сложности задачи (не всё на тяжёлую модель); замерять до и после
оптимизации; thinking-режим включать только там, где задача действительно сложная.

---

## Сводная таблица

| № | Проект | Статус | Главное внедрение | Evidence |
|---|--------|--------|-------------------|----------|
| 01 | OpenHands | ✅+🟡 | Control Center-паттерн, events-модель | ai-governance/, AiTrace; P2: automation |
| 02 | Cline | ✅ | Approval-контур, автономия 0–5, kill-switch | governance-service.ts, w3/w7, decision-inbox.tsx |
| 03 | Superpowers | 📋 | Workflow-дисциплина | docs/AGENT-WORKFLOW.md |
| 04 | Aider | 📋+✅ | Full-vertical, repo map, гейты после каждой задачи | GAP-MATRIX, docs/solutions/ |
| 05 | SWE-agent | ✅ | ACI-дизайн, аудит-формат, минимализм | action-registry.ts, eval-suite |
| 06 | LangGraph | ✅ | Durable state machine, interrupts | AiAction lifecycle, w7 |
| 07 | Daytona | ✅адапт. | Контролируемая плоскость, лимиты, аудит | with-route rateLimit, w9 |
| 08 | browser-use | 🟡+✅ | Untrusted-обёртка внешнего контента | prompt-sanitizer.ts; P2: News Bridge |
| 09 | Promptfoo | ✅ | Eval-suite 1259/10 категорий | src/lib/ai-eval/, w8, REPORT-latest |
| 10 | ASVS 5.0 | ✅част. | CSP/headers, security-матрица | next.config, w6-security |
| 11 | AISVS 1.0 | ✅част. | Санитайзер (C02), агентные контроли (C09) | prompt-sanitizer.ts, w7 |
| 12 | OTel GenAI | ✅ | Трейсинг gen_ai-конвенций | AiTrace, middleware, w9 |
| 13 | GLM-4.5/4.6/4.7 | ✅ | Маршрутизация по сложности, замер cost | AIGateway, AiTrace |

## Что осознанно НЕ внедрено (с причинами)

1. **News Bridge / browser-автоматизация (№01 automation, №08)** — P2: продуктовое решение владельца о
   внешних источниках (правовой перимет, источники, частота).
2. **Sandbox-per-action для autonomy 4–5 (№07)** — P2 за фича-флагом: уровни 4–5 сейчас флаг-gated.
3. **finish_reasons/conversation.id/tool.definitions в трейсах (№12)** — P2: нет данных из SDK usage.
4. **Preserved Thinking (№13)** — P2: зависит от SDK.
5. **Полный перебор требований ASVS 5.0 / AISVS C01–C12 (№10/11)** — P1: аддитивная разметка в GAP-MATRIX.

---

## Дополнение 17-09 (вечер): №15 — unlazy (Leonxlnx/unlazy)

**Источник**: https://github.com/Leonxlnx/unlazy.git (v2.1.0, MIT, ~3.2k★). Найден по запросу владельца
(«unlyzy» — точного имени нет, это unlazy). **Внедрён как эталон №15** — впервые с вендорингом кода.

**Ключевые принципы (из первоисточника):**
1. Acceptance ledger ДО работы: `GATES.md` — машинно-проверяемый контракт завершения; гейт = наблюдаемый исход + `CHECK:` (shell) + `EXPECT:` (success-only маркер).
2. Гейт met = exit 0 И совпадение EXPECT; evidence привязан versioned SHA-256-дайджестом определения гейта (структурный дрейф детектится; raw output не персистится).
3. `--reverify` перезапускает ВСЕ runnable-гейты, включая закрытые (`--status` не есть повторное исполнение) — лекарство от протухших доказательств.
4. Depth Tree: для больших задач — дерево листьев с собственными ledger, PLAN-таблица Owns/Needs/waves, роллинг-диспетч, 4 слоя верификации (self → parent --reverify → branch integration → Stop hook).
5. Abandonment ≠ успех: `ABANDON: <id> <причина>` → exit 1 HANDOFF REQUIRED — честный терминальный хэндофф.
6. Research-база: SlopCodeBench (лучший агент прошёл 14.8% чекпойнтов — чекпойнт ≠ завершение), arXiv о model laziness/underthinking/premature completion.
7. Approval boundary: CHECK исполняется только после явного ревью команд (`--approve`); `--status` и линт не исполняют.

**Интеграция в BizON**: ✅ (worklog benchmark-15-unlazy)
- Вендорено: `tools/unlazy/` (scripts/gate-check.mjs 960 строк + gate-lint.mjs + lib, templates, references, LICENSE, SECURITY.md); проходит eslint проекта без правок.
- Кодифицировано: docs/AGENT-WORKFLOW.md §6.1 (7 правил + команды; ledgers в specs/<slug>/GATES.md).
- Dogfood: specs/adopt-unlazy/GATES.md — ledger самой задачи внедрения, исполнен чекером с evidence.

**Правило применения**: существенная задача = ledger приёмки написан ДО работы; финальный отчёт =
мет/unmet/abandoned счётчики; вернувшаяся работа = --reverify; бросание = только ABANDON-handoff.

---

## Дополнение 17-09 (поздний вечер): №16 — emilkowalski/skills

**Источник**: https://github.com/emilkowalski/skills.git — Эмиль Ковальски (ex-Vercel, ex-Linear;
автор Sonner и Vaul). 13 скиллов design-engineering: «агенты не обладают вкусом; скиллы перечисляют
мелкие ошибки агентов и объясняют, как их исправить. Мелочи складываются».

**Ключевые принципы (из первоисточника):**
1. Десять неоспоримых стандартов ревью: оправданность движения, соответствие частоте (клавиатурные
   действия — НИКОГДА), ease-out для входов (ease-in = блок), UI < 300ms, origin от триггера и
   запрет scale(0), прерываемость (transitions/спринги, не keyframes), только transform/opacity,
   reduced-motion «мягче, не ноль» + hover-гейтинг, асимметрия вход/выход, cohesion.
2. Ворота анимации по порядку: частота → цель → самый дешёвый инструмент → свойства → кривая/длительность;
   zero-lines-of-code — валидный исход ворот.
3. Сильные кастомные кривые: cubic-bezier(0.23,1,0.32,1) / (0.77,0,0.175,1) / iOS-шторка (0.32,0.72,0,1);
   встроенные CSS easing «слишком слабы».
4. Производительность: FM-шорткаты x/y/scale не аппаратно ускорены (полный transform-строка); CSS-анимации
   вне главного потока бьют rAF под нагрузкой; WAAPI = JS-контроль с CSS-производительностью; blur < 20px.
5. Мобильный натив-baseline: tap-highlight, touch-action: manipulation, 16px инпуты на coarse (вместо
   запрета зума), viewport-fit=cover + env(safe-area-inset-*), themeColor по схемам, user-select только
   на контролах, тест ощущений только на железе.
6. Библиотечная карта с правилом «installed first»: sonner/framer-motion/zustand/clsx/cva/next-themes/
   recharts/dnd-kit — уже в стеке BizON (совпадение 8/8).

**Интеграция в BizON**: ✅ (worklog benchmark-16-emil-skills)
- Кодифицировано: docs/UI-CRAFT.md (12 разделов; планка ревью UI-диффов, привязана к AGENT-WORKFLOW §5).
- Применено к коду: globals.css (мобильный baseline + 3 easing-токена), layout.tsx (viewportFit=cover,
  interactiveWidget, themeColor light/dark), button.tsx (press-фидбек scale(0.97) 150ms + точные свойства
  перехода вместо transition-all), футер лендинга (safe-area-inset-bottom).
- Dogfood: specs/adopt-emil-skills/GATES.md — 10 runnable-гейтов, исполнение вендоренным чекером №15.

**Правило применения**: любая UI-задача проходит ворота §11 UI-CRAFT (частота → цель → инструмент →
свойства → кривая); ревью UI-диффа — по десяти стандартам §1; агрессивные триггеры (transition: all,
scale(0), ease-in, >300ms без причины, transform-origin: center на поповере) — флаг сразу.
