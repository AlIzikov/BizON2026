# BIZON AI EVALUATION SUITE — отчёт 2026-09-17T15:37:49.801Z

Всего: **1259** · PASS: **1251** · FAIL: **0** · SKIP: **8** · 49ms · LLM: off (SKIP)

| Категория | Всего | PASS | FAIL | SKIP |
|---|---|---|---|---|
| correctness | 102 | 102 | 0 | 0 |
| hallucination | 46 | 38 | 0 | 8 |
| security | 51 | 51 | 0 | 0 |
| privacy | 44 | 44 | 0 | 0 |
| recommendation_quality | 47 | 47 | 0 | 0 |
| tool_safety | 94 | 94 | 0 | 0 |
| permissions | 189 | 189 | 0 | 0 |
| prompt_injection | 619 | 619 | 0 | 0 |
| data_leakage | 41 | 41 | 0 | 0 |
| regression | 26 | 26 | 0 | 0 |
