# Остаточная матрица аудита 22-09-26 (после Команды 29 v3)

Дата реверификации: 25-09 (задача 29-a-1/2/3, read-only, три верификатора)
Источник: `upload/аудит 22-09-26.txt` (84 ID: CRYPTO-001..019, DB-001..030, API-001..035)
База сверок: коммит `7da39e3` (после hygiene: work/ снят с трекинга).
Предыстория: Команда 29 v3 закрыла A×52 (код+тесты), B×15 (ADR-004/005, domain-ownership, data-lifecycle), C×2, STALE×6 — см. `docs/OTCHET-AUDIT-FIX-22-09-26.md`. Эта матрица — **остаток после той сдачи**, верифицирован заново по коду.

## Сводка остатка

**СТАТУС (29-A-redux исполнение, та же сессия): все 20 A-пунктов закрыты кодом+тестами** —
коммиты `c249df9` (29-C), `2f22711` (29-M-1), `32cc896` (29-M-2), `5319c1d` (29-M-3),
`e5dda6d` (29-M-4), `2695380` (29-A). Гейты: tsc=0, bun test 620/620 (базлайн 595 + 25 новых),
lint=0 errors, живой смоук + agent-browser (лендинг/логин/лента/сообщения/уведомления,
Mobile 390 без h-скролла, консоль чиста). B/C ниже — как было задокументировано.

| Глава | A (исполнено в этой сессии) | B (ADR/бэклог) | C (отклонено) | УСТАРЕЛ (закрыто ранее) |
|---|---|---|---|---|
| №2 Crypto (17) | 3 (003, 008, 011) ✅ | 2 (010, 013) | 0 | 12 |
| №3 DB (29) | 9 (012, 013, 015, 018, 019, 021, 023, 027, 028) ✅ | 10 | 1 (029) | 9 |
| №4 API (35) | 8 (001, 005, 006, 007, 012, 014, 015, 034) ✅ | 5 (017, 018, 026, 032, 035) | 4 (023, 024, 029, 030) | 18 |
| **Итого** | **20** | **17** | **5** | **39** |

## Глава №2 Crypto&Secrets

| ID | Приоритет | Вердикт | Доказательство file:line | Действие |
|---|---|---|---|---|
| CRYPTO-001 | Критично | УСТАРЕЛ | crypto.ts:108-117 encrypt throw; :127-145 decrypt throw; :152-159 tryDecrypt→null (закрыто 29-b) | — |
| CRYPTO-002 | Критично | УСТАРЕЛ | security-env.ts:33-59; crypto.ts:71-84,88-93; instrumentation.ts:33-40; тест crypto.test.ts:119-161 | — |
| CRYPTO-003 | Критично | **A** | vc-export-service.ts:25-35 fallback `'dev-vc-key'`; policy-engine.ts:24-34 fallback `'dev-policy-key'` (без NODE_ENV guard) — знание исходников позволяет подделать VC/подписи политики | Убрать строковые fallback → env → dev-keyfile (DEV-ONLY) → prod throw |
| CRYPTO-004 | Важно | УСТАРЕЛ | redact-sensitive.ts:12-64; logger.ts:26-36 pino redact; with-route.ts:180 | — |
| CRYPTO-005 | Важно | УСТАРЕЛ | session-token.ts:24-26 sha256; auth.ts:123-124 | — |
| CRYPTO-006 | Важно | УСТАРЕЛ | единственный `?token=` — одноразовый email-verify (register/route.ts:139); сессия только HttpOnly cookie | — |
| CRYPTO-007 | Важно | УСТАРЕЛ | VerificationToken schema.prisma:344-354; verification-token.ts:33-76 | — |
| CRYPTO-008 | Важно | **A** | timing-safe.ts:15-33 готов; применён в admin-guard.ts:67, totp-service.ts:146, vc-export-service.ts:121, auth.ts:50-58; НО 7 роутов сравнивают `===`: admin/metrics:37, metrics:67, admin/causality:26, admin/data-plane:64, admin/cashier/ports:17 и [id]:15, kill-switch:22 | Заменить на timingSafeEqualString в 7 роутах |
| CRYPTO-009 | Важно | УСТАРЕЛ | crypto.ts:22-23,116,129-131 BIZON1 | — |
| CRYPTO-010 | Важно | B | key-provider отсутствует; BIZON1-префикс — предпосылка готова; blocker: hashEmail=HMAC(ключ) | ADR-005 (существует) |
| CRYPTO-011 | Важно | **A** | crypto.ts:173-176 hashEmail=HMAC(encryption-key); vc/policy — тот же keyfile (разделение фиктивно, шаг 4a ADR-005) | Отдельные BIZON_VC_SIGNING_KEY/BIZON_POLICY_SIGNING_KEY; emailHash-сплит — ADR-005 |
| CRYPTO-012 | Важно | УСТАРЕЛ | canonical-json.ts:9-55; audit-log.ts:40-79,148-163 chain `v2:`; verifyChain :205-218 | — |
| CRYPTO-013 | Важно | B | DataClassification отсутствует; app-логи чисты (audit-log.ts:164-166); AiAuditLog — только хэши | ADR-005; быстрый win: redactSensitiveObject в AuditLogService.log |
| CRYPTO-014 | Критично | УСТАРЕЛ | grep провайдерских ключей в src = 0; SDK только server-side (zai-client.ts:30-48) | — |
| CRYPTO-015 | Критично | УСТАРЕЛ | NEXT_PUBLIC_*: YM_ID/GA_ID/APP_URL/DEMO_HINT — публичные по назначению | — |
| CRYPTO-016 | Важно | УСТАРЕЛ | security-env.ts:19-27 requireEnv; instrumentation.ts:31-40 | — |
| CRYPTO-017 | Важно | УСТАРЕЛ | tests/security/crypto.test.ts:1-224 | — |

## Глава №3 Database

| ID | Приоритет | Вердикт | Доказательство file:line | Действие |
|---|---|---|---|---|
| DB-001 | Критично | B | schema.prisma:11 sqlite; docs/adr/adr-postgresql-migration.md (ADR-004) | ADR существует; cutover — решение владельца |
| DB-002 | Критично | B | User = 112 relation-полей; docs/database/domain-ownership.md §2 | Только ADR |
| DB-003 | Критично | УСТАРЕЛ | schema.prisma:226 lumenFractionMinor Int; lumen-service.ts:126,155-166 | — |
| DB-004 | Критично | УСТАРЕЛ | ledger в одной $transaction: topup :307-327, spend :382-401, debit :468-506, refund :555-606 | — |
| DB-005 | Критично | УСТАРЕЛ | guard-декремент updateMany; tests/money/lumen-race.test.ts | — |
| DB-006 | Критично | УСТАРЕЛ | schema:371 idempotencyKey @unique, :367 refundOf, tests/money/lumen-idempotency.test.ts | — |
| DB-007 | Критично | УСТАРЕЛ | schema:21 emailHash HMAC; tests/db-invariants.test.ts:1-14 | — |
| DB-008 | Важно | B | schema:35 roles CSV | ADR (role-модель) |
| DB-009 | Важно | B | schema:37,43 String; enum невозможен на SQLite | ADR-004 этап |
| DB-010 | Критично | B | deletedAt на 4 моделях; docs/database/data-lifecycle.md §1-2 | Эволюционно |
| DB-011 | Критично | B | delete-account/forget-me живы; lifecycle §4-5 фиксирует дыры | Отдельная миграция |
| DB-012 | Важно | **A** | составные индексы есть; принцип «индекс по замеру» ADR-004:125 | Инвентарь запросов → 2-3 индекса лент; тест PRAGMA index_list |
| DB-013 | Критично | **A (остаток)** | cursor id+skip:1+lookahead готов на news:132, notifications:34, users:66 | Дотянуть на feed-service.ts:116, posts/route.ts:56, messages/route.ts:33 |
| DB-014 | Критично | УСТАРЕЛ | schema:2820-2822 lease; outbox.ts:45,52-53,127-193; tests/money/outbox-lease.test.ts | — |
| DB-015 | Критично | **A** | emitDurable (outbox.ts:67-107) — 0 вызовов; project.completed/confirmed публикуются in-memory void EventBus.publish (transition/route.ts:193, project-evidence-service.ts:210) → crash = потеря события | tx?-параметр в emitDurable; бизнес-апдейт+emitDurable в одной $transaction; тест |
| DB-016 | Критично | УСТАРЕЛ | 0 update/delete по audit-моделям; chainHash schema:1370 | — |
| DB-017 | Важно | B | typed-связи есть; Evidence Graph — вне таймбокса | ADR |
| DB-018 | Важно | **A** | schema:1333-1358 evidence есть; НЕТ projectId/verifiedAt/verifierId/visibility | Additive-миграция 4 nullable-полей + заполнение в verify-потоке |
| DB-019 | Критично | **A** | api/projects/[id]/route.ts:157-175 findUnique→ownerId-чек→update (TOCTOU); guard-паттерн уже в store/lot/intro/milestone-сервисах | updateMany({where:{id, ownerId, completedAt:null}}) + count!==1→409/403; adversarial-тест |
| DB-020 | Важно | УСТАРЕЛ | 39 @@unique; db-invariants.test.ts:1-50 | — |
| DB-021 | Критично | **A** | package.json:11 db:push --accept-data-loss без гейта; ci.yml без БД-гейта | Guard NODE_ENV=production→exit 1 + CI job |
| DB-022 | Важно | B | инварианты закодированы констрейнтами+тестами | Практика продолжается |
| DB-023 | Важно | **A** | schema:179 notificationSettings String?; потребители изолированы (notification-service.ts:179-225) | Json? + бэкфилл; тест typed-чтения |
| DB-024 | Важно | B | CSV живы: hobbies:173, newsSources:170, preferences:211 | Вне таймбокса |
| DB-025 | Важно | УСТАРЕЛ | domain-ownership.md §1; UserRecommendation отсутствует | — |
| DB-026 | Критично | B | TrustIndex formulaVersion='v1' (professional-trust-service.ts:407-425) | ADR reconciliation |
| DB-027 | Важно | **A (мал.)** | AiInsight версионирован (29-d); НЕТ версий: CoachInsight (schema:1462-1484), Opportunity (schema:2070-2100) | algorithmVersion/generatedAt nullable + заполнение в writer'ах |
| DB-028 | Важно | **A** | executeApprovedAction — 3 независимых write без $transaction (governance-service.ts:854,858-873); бюджет чек :819-835 и инкремент :444-456 разнесены | $transaction + атомарный guard updateMany; race-тест 2 execute при остатке 1 |
| DB-029 | Важно | C | 1M/100M бенчмарки невозможны в песочнице (2 vCPU, пул 2) | Зафиксировано этапом 8.5 ADR-004 |

## Глава №4 API&Protocol

| ID | Приоритет | Вердикт | Доказательство file:line | Действие |
|---|---|---|---|---|
| API-001 | Критично | **A** | 212/359 с withRoute (59%); 147 raw: companies/[id]/route.ts, notifications, ai/matchmaker, ai/decisions/[id]… | Миграция money/PII первыми (ai/matchmaker, ai/career, cashier/status, notifications, claims/**) |
| API-002 | Критично | УСТАРЕЛ | auth/me/route.ts:13-16 на withRoute (закрыто 29-c) | — |
| API-003 | Критично | УСТАРЕЛ | login/route.ts:56-128 on withRoute | — |
| API-004 | Критично | УСТАРЕЛ | loginSchema strict :49-54 | — |
| API-005 | Критично | **A** | withRoute:145-175 контракт полный; legacy api-helpers.ts:19-21 только {error}; утечки catch-all e.message: companies/[id]/follow:19, events/[id]/rsvp:47 | code-параметр в errorJson (аддитивно); убрать e.message→400 |
| API-006 | Важно | **A** | коды только в withRoute:36-39 | Совместно с API-005 |
| API-007 | Критично | **A (низк.)** | «200+error» = 0 нарушений; расхождение 400/422 в legacy | Зафиксировать политику 400(schema)/422(semantic) в шапке with-route.ts |
| API-008 | Критично | УСТАРЕЛ | with-route.ts:359-372 CSRF-гейт (закрыто 29-c) | — |
| API-009 | Важно | УСТАРЕЛ | with-route.ts:452-459 | — |
| API-010 | Критично | УСТАРЕЛ | with-route.ts:85,385-397,441-449 (256KB) | — |
| API-011 | Важно | УСТАРЕЛ | with-route.ts:87,343-355 | — |
| API-012 | Критично | **A (низк.)** | paramsSchema на 1 роуте (jobs boost) | Добавлять на денежные [id]-роуты при миграции |
| API-013 | Критично | УСТАРЕЛ | 8/8 сэмплированных [id]-роутов имеют authz | — |
| API-014 | Критично | **A** | red-team жив (adv-auth, a3-authz 7 pass); полного инвентаря 153 [id]-роутов нет | Скрипт-инвентарь ROUTE×AUTH×OWNER + red-team на money/PII |
| API-015 | Критично | **A** | 9/9 admin-роутов гейтованы; НО kill-switch:22 и cashier/ports:17 — `===` | timing-safe (совместно с CRYPTO-008) |
| API-016 | Критично | УСТАРЕЛ | governance-service.ts:756-830 re-check policy | — |
| API-017 | Критично | B | idempotencyKey только на cashier/pay | ADR платежей |
| API-018 | Важно | B | 3 несовместимых пагинационных контракта | Стандарт pageInfo — вне таймбокса |
| API-019 | Важно | УСТАРЕЛ | динамический orderBy = 0 | — |
| API-020 | Важно | УСТАРЕЛ | проекции toUserPublic/Lite; passwordHash в ответах = 0 | — |
| API-021 | Критично | УСТАРЕЛ | серверные policy-проекции evidence | — |
| API-022 | Важно | УСТАРЕЛ | сырых entity в ответах = 0 | — |
| API-023 | Важно | C | монолит, единственный клиент — свой фронт | Переоткрыть при внешнем клиенте |
| API-024 | Критично | C | webhook-поверхности нет (шлюз — заглушка) | В ADR платежей |
| API-025 | Важно | УСТАРЕЛ | x-request-id на все ответы (29-c) | — |
| API-026 | Важно | B | in-memory KV; Redis-бэкенд за KV-абстракцией | ADR-текст |
| API-027 | Критично | УСТАРЕЛ | RATE_CLASSES:99-110; AUTH_STRICT login | — |
| API-028 | Критично | УСТАРЕЛ | entitlement+quota на AI-роутах; AiBudget execute | — |
| API-029 | Критично | C | долгих HTTP-операций нет | При появлении bulk |
| API-030 | Важно | C | async-операций API нет | При первом async-флоу |
| API-031 | Критично | УСТАРЕЛ | создания возвращают сущности; «200+error» = 0 | — |
| API-032 | Важно | B | оптимистика с откатом соблюдена (29-e проверил; 1 нарушение исправлено) | Гигиена фронта |
| API-033 | Важно | УСТАРЕЛ | cache.ts:61 invalidatePrefix; конвенция | — |
| API-034 | Важно | **A** | zod в 62/359 (17%) | CI-счётчик + порог-рампа (+5%/волна) |
| API-035 | Gate | B | чеклист покрывается матрицей | Трекер CI |

## Порядок исполнения A-остатка (деньги и PII первыми)

1. **Cluster C (crypto)**: CRYPTO-003+011 (fallback-секреты → env/dev-keyfile/prod-throw; отдельные ключи VC/policy), CRYPTO-008+API-015 (timing-safe в 7 роутах).
2. **Cluster M (деньги/БД)**: DB-019 (TOCTOU projects complete), DB-028 (AI-транзакция+бюджет), DB-015 (durable outbox producer), DB-013 (cursor-пагинация posts/messages/feed), DB-021 (db:push guard), DB-023 (Json?), DB-027 (algorithmVersion), DB-018 (evidence-поля), DB-012 (индексы по замеру).
3. **Cluster A (API)**: API-005/006 (errorJson code + 2 catch-all), API-007 (политика в шапке), API-001 (миграция money/PII legacy-роутов), API-014 (IDOR-инвентарь скриптом), API-034 (coverage-гейт).

## B-остаток (задокументировано)

ADR-004 (PostgreSQL: DB-001/009/021-этап/029-этап), ADR-005 (секреты: CRYPTO-010/013), domain-ownership (DB-002/017/024/026), data-lifecycle (DB-010/011), ADR-тексты API-017/018/026 (платежи/pagination-стандарт/Redis), API-032 (фронт-гигиена), API-035 (CI-трекер).

## C-остаток (отклонено письменно)

DB-029 (бенчмарки вне песочницы — этап 8.5 ADR-004), API-023 (версионирование без потребителей), API-024/029/030 (webhook/async-поверхности не существуют).
