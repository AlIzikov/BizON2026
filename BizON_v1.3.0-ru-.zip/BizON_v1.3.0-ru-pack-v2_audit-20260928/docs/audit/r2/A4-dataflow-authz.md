# A4 — Dataflow/Authz аудит (повторный аудит BizON, Task R2-A4)

Методика: codeql-стиль source→sink. Source = пользовательский ввод (`req.json()`, `searchParams`, `req.headers`, route-params). Sink = `db.*`, файловые/сетевые операции, авторизационные решения. Формат находки = ПУТЬ атаки: source → … → sink → нарушенная граница → принципал/ресурс → результат. Self-impact того же принципала не учитывается (антипаттерн №5). Ни один файл кода не изменён.

Инфраструктура authz (проверено чтением, не по отчётам):
- `src/lib/auth.ts:131` `getUserFromRequest` — opaque-токен в cookie `bizon_session`/Bearer → `db.session` → user; soft-deleted и просроченные сессии отбрасываются (auth.ts:180-189).
- `src/lib/with-route.ts:104` `withRoute` — композер: **auth:true по умолчанию (401)**, zod-strip, rate-limit опция, маппинг ошибок. Используется в 202/348 роутов. **ВАЖНО: withRoute НЕ проверяет роль admin** — только факт сессии (with-route.ts:135-137).
- `src/lib/admin-guard.ts:35` `requireAdmin` — централизованная проверка роли `admin` в CSV `user.roles`.

Калибровка severity — cloudflare/security-audit-skill: критичность = нарушенная граница доверия × конкретный результат; «нет границы/результата — не находка».

---

## 1. Находки

### A4-F1 — HIGH · `/api/admin/outbox` доступен любому аутентифицированному (нет роли admin)
- **Путь:** source: cookie `bizon_session` любого зарегистрированного пользователя → `withRoute` (auth:true, роль НЕ проверяется) `src/app/api/admin/outbox/route.ts:9` (GET) и `:13` (POST) → sink: `OutboxService.stats()` / `OutboxService.drain()` → `db.outboxEvent.findMany/updateMany(attempts+1)` `src/lib/services/outbox-service.ts:26,35` и `:65`.
- **Граница:** всё пространство `/api/admin/*` требует роль admin (соседние роуты: kill-switch — x-admin-token `admin/kill-switch/route.ts:22`; cashier/ports — `admin/cashier/ports/route.ts:17`; data-plane/metrics/causality — `requireAdmin`/`isAdminRole`). Здесь граница отсутствует.
- **Принципал/ресурс:** платформа (EventBus-очередь, внутренняя телеметрия).
- **Результат:** (а) любой юзер читает внутреннюю статистику очереди (pending/published/dead); (б) любой юзер дёргает ops-операцию drain без лимита частоты: каждый вызов инкрементирует `attempts` до 50 event'ам → нагрузочная амплификация и вмешательство в конвейер событий (после 5 неудачных публикаций события уходят в dead — `OUTBOX_MAX_ATTEMPTS=5`, outbox-service.ts:10,27).
- **Перепроверка:** `curl -s -X POST http://localhost:3000/api/admin/outbox -b "bizon_session=$(токен обычного юзера)"` → 200 `{"published":..}` вместо 403.

### A4-F2 — LOW · `/api/admin/audit-verify` доступен любому аутентифицированному
- **Путь:** source: cookie/Bearer любого юзера → `withRoute` без роли `src/app/api/admin/audit-verify/route.ts:9` → `?limit=` (searchParams, clamp 2..1000 на `:12`) → sink: `AuditLog.verifyChain(limit)` (чтение AuditLog + CPU-проверка хэш-цепочки).
- **Граница:** та же, что A4-F1 (путь `/api/admin/*`, соседние роуты защищены ролью/токеном).
- **Результат:** раскрытие обычным пользователям состояния tamper-evidence журнала (валидна ли цепочка, размер выборки) + повторяемая нагрузка (без rate-limit, limit до 1000 записей за вызов). Read-only, поэтому LOW.
- **Перепроверка:** `curl -s "http://localhost:3000/api/admin/audit-verify?limit=1000" -b "bizon_session=$(токен обычного юзера)"` → 200 с вердиктом цепочки.

### A4-F3 — LOW · Каталог `/api/users` раскрывает роли (включая `admin`) и позволяет их искать
- **Путь:** source: query `q` → `where.roles = { contains: q }` `src/app/api/users/route.ts:37`, select `roles: true` `:75` → sink: авторизационно-значимое поле в ответе `roles: [...]` `:95`.
- **Граница:** собственная гарантия проекта — «НЕТ roles — привилегии (в т.ч. 'admin') не раскрываются публично» (`src/lib/api-helpers.ts:192`, UserPublicLite). Каталог её нарушает для всех аутентифицированных.
- **Результат:** перечисление админов/модераторов платформы одним запросом (`/api/users?q=admin`) — мишени для социальной инженерии/фишинга; разведка привилегий.
- **Перепроверка:** `curl -s "http://localhost:3000/api/users?q=admin" -b "bizon_session=..."` → в выдаче есть пользователи с `roles:["admin",...]`.

### A4-F4 — LOW · Каталог `/api/users` отдаёт plaintext `location` (PII) из legacy-колонки
- **Путь:** source: GET /api/users → select `location: true` `src/app/api/users/route.ts:74` → sink: ответ `location` `:93` любому аутентифицированному.
- **Граница:** location классифицирован как PII (расшифровывается в toUserPublic из `locationEncrypted`, api-helpers.ts:73); в каталоге утекает старый plaintext для пользователей, у которых он не обнулён (сам код это признаёт комментарием `:48-50`).
- **Результат:** массовая выгрузка местоположения пользователей постранично (20/запрос, cursor-пагинация) без relationship-гейтов, которые применяются в `/api/users/[id]`.
- **Перепроверка:** `curl -s "http://localhost:3000/api/users?limit=50" -b ...` → непустые `location` в выдаче.

### A4-F5 — INFORMATIONAL · Мутирующие роуты без rate-limit (write-амплификация/спам)
- **Путь:** source: authed POST-тело/params → `withRoute` (auth есть, rateLimit-опции нет) → sink: `db.postLike.create + db.post.update` и аналоги.
- Файлы: `posts/[id]/like/route.ts:11` (2 записи за вызов), `posts/[id]/comment`, `posts/[id]/save`, `jobs/[id]/apply`, `events/[id]/rsvp`, `communities/[slug]/join/route.ts:8,18`, `companies/[id]/follow`, `feed/recommendations/ignore`.
- **Результат:** спам-комментарии/накрутка действий в пределах уникальных констрейнтов (like — 1/юзер/пост, `posts/[id]/like:21`), нагрузка на БД. Явной границы с крупным результатом нет → informational; рекомендуется дешёвый `rateLimit` в withRoute-опциях.
- **Перепроверка:** `for i in $(seq 1 200); do curl -s -o /dev/null -X POST http://localhost:3000/api/posts/<id>/comment -b ... -d '{"text":"spam"}'; done` → все 200 (без 429).

### A4-F6 — INFORMATIONAL · `/api/auth/verify-email` — токен в query, без rate-limit
- **Путь:** source: `?token=` `auth/verify-email/route.ts:21` → sink: `db.verificationToken` lookup → `db.user.update(emailVerified=true)` `:38-44`.
- **Смягчения:** токен 32 случайных байта (verification-token.ts:4,13), в БД только sha256, одноразовость, TTL 24ч — перебор нереален.
- **Результат:** остаточные риски — попадание токена в access-логи/Referer (GET-ссылка); отсутствие лимита на невалидные попытки. Перебор невозможен, поэтому informational.
- **Перепроверка:** `curl -s "http://localhost:3000/api/auth/verify-email?token=<невалид>" -i` → 400; повторно → снова 400 (без 429).

Отдельно проверено и НЕ является находкой: сравнение env-токенов через `===` (kill-switch/metrics/data-plane/causality) — non-timing-safe, но токены 32+ байт из env, перебор через timing нереалистичен (informational-уровень, вне реестра).

---

## 2. Отсеянные кандидаты (проверено — НЕ находки)

| # | Кандидат | Причина отсеивания |
|---|----------|--------------------|
| 1 | `/api/wallet/transfer` — все методы без auth | Deprecated-заглушка: все 5 методов возвращают 410 без обращения к БД (wallet/transfer/route.ts:30-50) — sink отсутствует |
| 2 | 139 роутов без строки `getUserFromRequest` | Подавляющее большинство используют `withRoute` (auth default true, with-route.ts:135-137) — auth присутствует, маркер другой |
| 3 | `spread req.json()` в db (mass assignment) | rg `data: {...body}` / `data: body` / `...body` по всем 348 роутам — 0 совпадений; identity-поля (`authorId/ownerId/userId/companyId`) нигде не берутся из тела (rg по body→identity: 0); в withRoute-роутах zod-strip вырезает неизвестное |
| 4 | `posts/[id]/unlock`, `votePoll`, `unlockSubscription` | Услуги принимают `userId` из сессии; доступ к платному контенту гейтится `accessGrants` (`posts/route.ts:82-100` — locked-контент урезается) |
| 5 | `/api/store/bookings/[id]/{fulfil,release,decline,cancel}` | Service-слой проверяет владельца: `booking.sellerId !== sellerId` / `buyerId !== buyerId` → 404 (store-service.ts:397-399,438-441,501-504,541-546) |
| 6 | `/api/connections/[id]/verify` | Явная owner-проверка обеих сторон ребра перед update (connections/[id]/verify/route.ts:20-24) |
| 7 | `/api/ai/governance/execute` | actionId из тела, но исполнитель подтверждается в GovernanceService (`executeApprovedAction({actionId, userId: user.id})`, FORBIDDEN→403); rate-limit 10/мин (execute/route.ts:15-18,32) |
| 8 | `/api/lots/[id]/{respond,accept,complete,cancel}` | Все решения уходят в `LotService.*(ctx.params.id, ctx.user.id)` — владелец/участник проверяется в сервисе; velocity-лимиты по тирам (lots/[id]/respond:21-25) |
| 9 | `/api/users/[id]` (GET профиля) | FIX-02 работает: полная проекция с PII — только owner или accepted-connection, остальным `toUserPublicLite` без email/phone/bio (users/[id]/route.ts:24-46) |
| 10 | `/api/p/[token]`, `/api/c/[token]` (публичные passport) | token 64 hex (32 байта), `passportEnabled=false` → 404 без раскрытия существования, в ответе нет userId/контактов (p/[token]/route.ts:36-50) |
| 11 | `/api/jobs/analyze-url` | Пользовательский URL только парсится (extractDomain) и ищется по БД; `fetch()` по URL отсутствует — SSRF нет (analyze-url/route.ts:23-75) |
| 12 | `/api/edu/complete/[userCourseId]` | `enrollment.userId !== user.id → 403` до записи (edu/complete/[userCourseId]/route.ts:28-30), rate-limit есть |

---

## 3. Coverage-таблица

Всего роутов: **348** (rg `src/app/api/**/route.ts`).

| Слой проверки | Роутов | Чем покрыто |
|---|---|---|
| Полное чтение файла (source→sink вручную) | 21 | Read: admin/{data-plane,metrics,audit-verify,outbox}, wallet/transfer, lumens/{topup,accrue}, store/bookings/[id]/fulfil, intros, cashier/pay, edu/complete/[userCourseId], auth/{register,verify-email}, reports/[reportId], messages/[conversationId], users/[id]/transferable, + lib: auth.ts, with-route.ts, admin-guard.ts, api-helpers.ts |
| Частичное чтение (первые ~60-100 строк + ключевые ветки) | 34 | lots/[id]/*(5), events/[id]/{publish,cancel}, connections/[id]/verify, intros/[id]/accept, me/relationship/[userId], search-prefs/[id], posts/[id]/{unlock,vote,like,comment-like ветки}, jobs/[id]/{view-log,match-explain,analyze-url}, companies/[id]/memory, resumes/[id]/blocks, projects/[id]/{confirm,milestones,applications,reviews,premium}, hr-organizations/[id], career-entries/[id], me/intent/[id], applications/[id]/status, colleague-inquiries/[id]/respond, claims/[id]/verify, users/{route.ts,[id],[id]/view}, p/[token], c/[token], integrations/github, communities/[slug]/join |
| Точечные rg-проверки (auth-маркер, rate-limit, owner-фильтры, identity-from-body, spread) | 143 | батчи: admin/*, cron, governance, moderation, subscriptions, me/*, notifications, sponsored, dao, cashier, feed, insights, hr-contacts, research и др. |
| Класс-вывод (withRoute-аудит: auth/zod/error-маппинг гарантированы композером, без индивидуального чтения) | 150 | транзитивно: any withRoute-роут не может быть «без auth»/«сырой 500»; IDOR-специфика не подтверждалась индивидуально |
| Итого просмотрено (все слои) | 348 | 100% поверхности; «класс-вывод» — честная оговорка: 150 роутов не открыты индивидуально, находки в них маловероятны, но не исключены |

Приоритеты скоупа выполнены: (1) все 148 `[id]`-роутов прошли хотя бы rg-слой owner-маркеров; (2) мутирующие POST/PATCH/DELETE — rg-слой rate-limit (находка A4-F5); (3) admin/governance/lumens/store/jobs/intros/cashier — полное/частичное чтение.

## 4. Топ-рекомендации (для модератора флота, БЕЗ правок кода здесь)
1. A4-F1/F2: в `withRoute` добавить опцию `requireRole: 'admin'` либо обернуть admin/outbox и admin/audit-verify в `requireAdmin` (как data-plane).
2. A4-F3/F4: из select `/api/users` убрать `roles` и `location` (или отдавать `hasAdminRole: boolean` только себе); фильтр `q` по roles тоже убрать.
3. A4-F5: проставить `rateLimit` в 8 перечисленных мутирующих роутах (шаблон уже есть в 102 других).
4. Процесс: добавить в гейты правило «путь /api/admin/* ⇒ requireAdmin|x-admin-token» — grep-гейт «есть auth» пропускает «auth есть, роли нет».
