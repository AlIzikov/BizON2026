# A7 — Security-Compliance аудит (повторный аудит BizON, R2-A7)

Дата: 19.09.2026 · Аудитор: A7 (Explore, не писал код, файлы не менял — единственный артефакт этот отчёт)
Методика: проверка ИСПОЛНЕНИЯ правил владельца по КОДУ (не по документации и не по отчётам исполнителей).
Норматив: `docs/PROJECT-RULES.md` §6 (правила 1–5, trace 1a0b87e426236205, ПРИНЯТЫ).
Инструменты: Read, Grep/rg по `src/**` и `mini-services/**`, Prisma-запросы к живой БД `db/custom.db`.

---

## 1. SCORECARD (5 правил §6)

| # | Правило | Вердикт | % / метрика по коду | Ключевое |
|---|---|---|---|---|
| R1 | НЕ доверять пользователю (owner-check + валидация + rate-limit на каждом мут. роуте) | **ЧАСТИЧНО** | Выборка 20 мутирующих роутов: **12/19 полностью (63%)**, 6/19 частично (всё есть, кроме rate-limit), 1/19 нарушение, 1 N/A. По всем 212 мут. файлам rate-limit есть в 145 (68%) | 1 high-находка (admin/outbox) |
| R2 | E2E-шифрование / ZK (направление, поэтапно) + «нет plaintext без необходимости» | **ЧАСТИЧНО** | Серверное AES-256-GCM класса A есть и fail-secure; client-side шифрования нет (честный план, не нарушение). **Но 4 plaintext-находки без необходимости**, из них 2 high | Session.token plaintext в БД; дублирование PII в легаси-колонки |
| R3 | Zero Trust: сессия на каждом запросе + RBAC/ABAC на каждом ресурсе | **ЧАСТИЧНО** | 10/12 админ-поверхностей защищены корректно (роль admin / x-admin-token, fail-closed); **2 high + 1 medium** находки: мутация без роли, захардкоженный ID-админ, read-only без роли | `/api/admin/outbox`, `/api/ai/governance/status` |
| R4 | Запрет eval/exec/child_process/innerHTML без санитизации | **ИСПОЛНЕН** | src/** + mini-services/**: `eval(`=0, `new Function(`=0, `child_process`=0, `exec/spawn`=0; `dangerouslySetInnerHTML`=3 — все статический конфиг/зависимость, без пользовательского ввода | Нет нарушений |
| R5 | Строго параметризованный SQL | **ИСПОЛНЕН** | `$queryRaw`/`$executeRaw`/`*Unsafe` в src/** = **0 матчей** — весь доступ к БД через Prisma-запросы | Нет нарушений |

---

## 2. ТАБЛИЦА НАРУШЕНИЙ / НАХОДОК

Severity по калибровке: нарушение R4/R5 в нашем коде = high · отсутствие owner-check = high · admin без роли = high · PII в логах = medium. Токены plaintext в БД и plaintext-копии PII — high (прямо названы в правиле 2 как класс находки).

| ID | Sev | file:line | Принципал → ресурс | Последствие | Правило |
|----|-----|-----------|--------------------|-------------|---------|
| A7-01 | **HIGH** | `src/app/api/admin/outbox/route.ts:9-16` | Любой аутентифицированный пользователь → очередь Outbox/EventBus платформы | POST /api/admin/outbox (drain очереди — мутация) и GET (статистика) защищены только сессией; роль admin НЕ проверяется. Любой зарегистрированный может управлять шиной событий платформы | R1+R3 |
| A7-02 | **HIGH** | `src/app/api/ai/governance/status/route.ts:12-23` (ID в строке 20) | Демо-аккаунт «Иван Петров» (`cmtlwo7cr000ome6uscm1ipkt`) → управление AI-governance | Локальный `requireAdmin` даёт админа по захардкоженному user.id (в БД у пользователя roles=`Data Engineer,Mentor`, НЕ admin) + роли `administrator`/`owner` вне центрального `isAdminRole`. Worklog CRED-1: пароль демо-аккаунта `password`. Итог: известный аккаунт может pause/kill агентов (PATCH), PATCH без zod (`body as any`) | R3 |
| A7-03 | **HIGH** | `src/lib/auth.ts:124-128` (аналог `src/lib/data-vault/auth-vault.ts:12-26`) | Атакующий с дампом БД → все 57 живых сессий | Session.token хранится в БД открытым текстом (`token String @unique`, без хэша). Контраст: VerificationToken — sha256-хэш («сырой токен НЕ храним», schema.prisma:322). Утечка БД = мгновенный захват аккаунтов, обесценивает AES-шифрование PII (PII не расшифровать, а войти можно) | R2 |
| A7-04 | **HIGH** | `src/app/api/users/[id]/route.ts:219-220, 227-228, 235-236` | Владелец профиля → собственные bio/location/phone | PATCH пишет PII одновременно в plaintext-колонку и в Encrypted-твин. Schema (строки 26-32) помечает легаси-колонки «nullable — plaintext очищен», но живой код перезаписывает plaintext обратно → колонки `bio/location/phone` в БД снова содержат PII открытым текстом; шифрование в этой ветке декоративно | R2 |
| A7-05 | **MEDIUM** | `src/app/api/admin/audit-verify/route.ts:9-14` | Любой аутентифицированный → тампер-статусы журнала AuditLog | /api/admin/* с сессией БЕЗ проверки роли admin (read-only: verifyChain). Непривилегированный пользователь видит служебную информацию цепочки аудита | R3 |
| A7-06 | **MEDIUM** | `prisma/schema.prisma:45` + `src/app/api/users/[id]/route.ts:239-255` | Владелец → дата рождения | User.birthday — plaintext DateTime без Encrypted-твина (email/phone/bio/location имеют твины). Класс PII, хранится без необходимости открытым текстом | R2 |
| A7-07 | **MEDIUM** | `src/app/api/messages/route.ts:90-92` | Отправитель сообщения → Notification получателя | Приватный текст сообщения дублируется plaintext'ом в `Notification.content` (`content.slice(0,100)`) — копия приватного диалога живёт вне диалога; станет блокером при переходе на E2E (сервер не должен видеть текст) | R2 |
| A7-08 | **MEDIUM** | `src/middleware.ts:20, 86-115` | Неавторизованный запрос → сессия демо-пользователя | `DEMO_TOKEN` захардкожен в исходнике; при `BIZON_DEMO_AUTH=1` middleware подставляет сессию Иван Петрова на ВСЕ пути (в т.ч. `/api/admin/*`, где она проходит session-only роуты — A7-01/A7-05) и НЕ проверяет NODE_ENV. Смягчение: у Ивана нет роли admin, токен-роуты закрыты; документировано «never in production» | R3 |
| A7-09 | **LOW** | `src/lib/data-vault/user-vault.ts:50-53, 103-114` | (потенциальный) будущий调用 → User.email/bio/phone | Facade data-vault экспортируется, но живыми роутами не используется (grep: импортов нет). `UserVault.create` пишет plaintext email — латентная мина при переиспользовании фасада; схема заявляет «plaintext очищен» | R2 |
| A7-10 | **LOW** | `src/app/api/admin/kill-switch/route.ts:33-43` | Аутентифицированный/анонимный → статус kill-switch | GET с `auth:false` без токена раскрывает флаги состояния автономии и факт наличия BIZON_ADMIN_TOKEN (`adminConfigured`). POST корректно закрыт токеном (fail-closed) | R3 |
| A7-11 | **INFO** | `src/app/layout.tsx:62, 84`; `src/components/ui/chart.tsx:83` | — | `dangerouslySetInnerHTML` ×3: статические скрипты Яндекс.Метрика/GA4 (интерполяция только env NEXT_PUBLIC_*_ID, production-only) и vendored shadcn/ui (CSS из статического ChartConfig). Пользовательский ввод не попадает — **не нарушение** по калибровке задания | R4 |
| A7-12 | **INFO** | `scripts/fix09-db.ts:30,47,50` | — | `$queryRawUnsafe` с константными строками (PRAGMA/sqlite_master) в CLI-скрипте вне src/** — не нарушение, вне скоупа правила | R5 |

Статусы по протоколу флота: находки A7-01…A7-04 — кандидаты в confirmed (выводы по прямому чтению кода, воспроизводимые rg-командами); A7-05…A7-10 — confirmed по коду, влияние нуждается в оценке владельца; A7-11…A7-12 — rejected-как-нарушения (информационные).

---

## 3. ЧТО УЖЕ СООТВЕТСТВУЕТ (проверено по коду, выборка)

**R3/R1 инфраструктура:**
- `src/middleware.ts` честно НЕ выдаёт себя за auth: только CORS-whitelist (prod/preview/dev origins) + demo-режим; реальная проверка сессии — в каждом роуте через `getUserFromRequest` (Session по таблице, TTL, soft-delete блок). Серверная сессионная модель — по правилу 3, JWT-самодеятельности нет.
- `src/lib/with-route.ts`: auth:true по умолчанию (401 без сессии, гарантия на уровне типов), zod-strip неизвестных полей, rate-limit-хук, канонический маппинг ошибок без сырых e.message для 5xx.
- `src/lib/admin-guard.ts`: централизованная точная проверка CSV-роли `admin` (trim/exact), используется в admin-роутах, /api/metrics, news/moderation, companies/verify, edu/courses, nft-skills/stale-check и др. (10+ поверхностей — корректно).
- Админ-роуты с корректной защитой: `/api/admin/data-plane` (requireAdmin | Bearer DATA_PLANE_TOKEN), `/api/admin/metrics` (requireAdmin | METRICS_TOKEN), `/api/admin/causality` (роль | ops-токен), `/api/admin/kill-switch` POST и `/api/admin/cashier/ports` GET/POST/[id] PATCH (x-admin-token == BIZON_ADMIN_TOKEN, при неустановленном токене — честный 403, fail-closed).

**R1 owner-check/ABAC подтверждён в сервисах (не в отчётах):**
- store-service: `booking.buyerId !== buyerId → 404` (release:438-441), `sellerId` (fulfil/decline), `item.ownerId === buyerId → 400 нельзя купить своё` (287), эскроу-статусы одноразовы (optimistic update count===0 → 409).
- lot-service: `lot.ownerId !== userId → FORBIDDEN` (accept/decline/responses/cancel: 161, 225, 239, 291).
- intro-service: `intro.introducerId !== introducerId → 404` (accept/decline: 154, 219).
- event-service: `event.organizerId !== organizerId → 404` (publishEvent: 123).
- messages POST: ABAC-гейт «connection accepted ИЛИ ipScore ≥ 30» (anti-спам); messages GET/[conversationId]: участник диалога (`fromUserId/toUserId`), чужие диалоги → 404.
- hr-contacts POST: ABAC `accountType='hr_agency'`, Privacy Shield (hrInvisible → 403), блок-окно 7 дней, лимит 1/неделю через unique constraint.
- Профиль: GET /api/users/[id] — полная проекция только владельцу или accepted-connection, остальным Lite-слайс без PII; PATCH — owner-only 403 + whitelist полей (roles/twoFactor/subscription в whitelist НЕ входят — mass-assignment закрыт, FIX-02).

**R1 валидация/анти-абуз:**
- zod-схемы + strip по умолчанию в withRoute; white-list-санитайзеры (me/preferences: ALLOWED_* + MAX_ITEMS, мусор выбрасывается); `sanitizeUserText` против stored-XSS (posts/comment — ADV-B109); velocity-лимиты по тиру верификации (intro 20/ч, complaint 10/ч, store_book 10/ч, basic ×4 ниже); идемпотентность кассы по idempotencyKey; дедуп жалоб; rate-limit на денежных роутах (topup 20/мин, accrue 10/мин, cashier/pay 20/мин, 2fa/enable 5/мин + re-auth текущим паролем).
- 2FA enable требует текущий пароль (украденная сессия не включит 2FA); delete-account инвалидирует все сессии и идемпотентен.

**R2 серверное шифрование:**
- `src/lib/security/crypto.ts`: AES-256-GCM (IV 12B, auth-tag), ключ только env `BIZON_ENCRYPTION_KEY`; production без ключа НЕ стартует (fail-secure, `instrumentation.ts:33-40` + дубль в crypto.ts:70-75); dev-fallback — стабильный keyfile 0600 (не тихая эфемерная подмена).
- Email: регистрация НЕ пишет plaintext (`auth.ts:79-91` — только emailHash=HMAC-SHA256 + emailEncrypted); поиск по emailHash (`getByEmail`, loginUser); читатели — decrypt-first (`api-helpers.ts:71-74`).
- VerificationToken — sha256-хэш в БД, сырой токен не хранится (schema:322).

**R4/R5:** сканы чистые (см. scorecard); raw SQL в src/** отсутствует вообще, включая тесты adversarial-инъекций (adversarial/adv-injection.test.ts подтверждает поведенчески).

---

## 4. РЕКОМЕНДАЦИИ (smallest-effective-fix, без изменения кода в рамках аудита)

1. **A7-01 (admin/outbox):** добавить в оба хендлера одну строку проверки `await adminGuard(req)` из `src/lib/admin-guard.ts` (паттерн уже есть в admin/metrics). Альтернатива — перейти на x-admin-token, как соседние cashier/ports. ~5 строк.
2. **A7-02 (governance/status):** удалить захардкоженный `user.id === 'cmtlwo7cr...'` и роли `administrator`/`owner`; заменить локальный requireAdmin на централизованный `isAdminRole`; PATCH обернуть в zod-схему (`op: z.enum([...]), agentKey: z.string()`). Выдать реальному оператору роль admin через серверный путь.
3. **A7-03 (Session.token):** хранить `tokenHash = sha256(token)` (уникальный индекс), сырой токен — только в cookie; при проверке хэшировать входящий. Миграция additive: `tokenHash String? @unique` → бэкфилл при следующем логине (rehash-on-verify, паттерн H2 уже есть в loginUser). Заодно закрыть AuthVault на тот же паттерн или удалить фасад (A7-09).
4. **A7-04 (plaintext PII дубли):** в PATCH /api/users/[id] и UserVault.update перестать писать `bio/location/phone` plaintext-колонки (писать только `*Encrypted`, plaintext = null); одноразовая миграция-очистка легаси-колонок (схема уже обещает «plaintext очищен»).
5. **A7-05:** `/api/admin/audit-verify` — добавить `isAdminRole(ctx.user.roles)` (или переименовать в /api/audit-verify, если это пользовательская функция). 1 строка.
6. **A7-06 (birthday):** добавить `birthdayEncrypted` (additive), писать твин, читать через decrypt — как уже сделано для phone.
7. **A7-07 (notification preview):** заменить текст-превью на нейтральный шаблон «Новое сообщение» (текст и так виден в диалоге) — снимет будущий конфликт с E2E-переходом.
8. **A7-08 (demo-mode):** в middleware добавить `process.env.NODE_ENV !== 'production'` к условию demo-режима (fail-closed в проде), DEMO_TOKEN вынести в env.
9. **R1-хвост (6 роутов без rate-limit):** добавить `rateLimit:` в opts withRoute по готовым ключам (jobs/apply ~30/ч, messages ~60/мин, users PATCH ~20/мин, posts/comment ~30/мин; preferences/delete-account — низкий приоритет, owner-only).
10. **План (ADR, не тихая замена — по правилу 2):** E2E для приватных диалогов — client-side AES-GCM-256, ключ у пользователя, сервер хранит шифротекст Message.content и НЕ строит текстовые превью; переход класса A в ZK — отдельный ADR (логин по emailHash уже готов к этому).

---

## 5. ПОКРЫТИЕ И ОГРАНИЧЕНИЯ

- Покрыто по коду: 100% §6-правил; выборочно 20 мутирующих роутов (+4 сервиса-каскада), все 12 admin-поверхностей, middleware/with-route/admin-guard, crypto+data-vault, rg-сканы опасных функций и raw-SQL по src/** и mini-services/**.
- Не покрыто (честно): полный обход всех 212 мут. роутов (выборка 9%); behavioral red-team (скоуп A3); dataflow-пути req→db целиком (скоуп A4); UI-санитизация на рендере (XSS на выходе — скоуп A1/A2); логи операционной системы/инфраструктуры вне src.
- БД-факты (живая db/custom.db): пользователей с ролью admin = 0 (все requireAdmin fail-closed → 403; управление платформой сейчас реально доступно только по BIZON_ADMIN_TOKEN и через находку A7-02); живых сессий = 57 (plaintext-токены, находка A7-03).
