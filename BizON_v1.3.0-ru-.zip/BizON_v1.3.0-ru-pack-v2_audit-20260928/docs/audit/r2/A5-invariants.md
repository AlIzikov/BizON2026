# R2-A5 — Formal-Invariants: формальные инварианты денежного ядра BizON

- Аудитор: A5 (Task ID: R2-A5), методика: rocq-мышление — инварианты сформулированы как теоремы с кванторами, затем проверены машинно property-тестами bun на конечных данных.
- Полный Rocq-тулчейн в песочнице недоступен (сборка OCaml; зафиксировано в docs/knowledge/REPO-LEARNING-2026-09-19.md §5) — статус PROVEN означает «свойство выдержало все построенные проверки на данных», а не proof-certificate.
- Границы вмешательства соблюдены: src/** и prisma/** только читались; созданы исключительно тест-файлы adversarial2/a5-*.test.ts и этот отчёт.
- Команда прогона: `cd /home/z/my-project && bun test adversarial2/a5-*.test.ts` → **32 pass / 0 fail, 6595 expect()** (bun 2.7.x, изолированная копия db/custom.db через tests/helpers/setup.ts).

## Сводка вердиктов

| # | Инвариант | Статус | Контрпример |
|---|---|---|---|
| I1 | SPLIT (computeSplit) | **PROVEN** (1122 пары amount×p + границы + мусор) | — (remark: у чистой функции нет собственного капа p) |
| I2 | ESCROW-IDEMPOTENT (release², refund-после-release) | **PROVEN** (вкл. параллельные гонки) | — |
| I2' | нет печати денег: refund ≤ исходный spend | **VIOLATED** | refundVar принимает cost=250 при spend=100 (+150 напечатаны) |
| I3 | NON-NEG (баланс ≥ 0, мусор не меняет баланс) | **PROVEN** (300 случайных операций, модель==БД на каждом шаге) | — |
| I4 | LEDGER-CONSERVATION (spend/refund/credit) | **PROVEN** (вкл. краш внутри $transaction → полный откат) | — |
| I4t | LEDGER-CONSERVATION (topup) | **VIOLATED** | increment и ledger НЕ в одной транзакции → «+300 баланса без ledger» |
| I4c | crash-window эскроу (requestBooking→sweep) | **VIOLATED** (низкая) | краш между spendVar и записью spendTxId → sweepStale отменяет бронь без возврата |
| I5 | HASH-CHAIN (AuditLog) | **PROVEN** (tamper/insert/delete/порядок) — **частично VIOLATED** | tamper самой старой записи окна verifyChain не детектируется |
| I6 | CONSENT (AI-анализ без согласия) | **частично VIOLATED** | consentAiAnalysis=false не запрещает AI-анализ (allowed=true); fail-open для несуществующего userId/сбоя БД |

---

## I1 (SPLIT)

**Теорема.** ∀ amount ∈ ℤ, amount ≥ 1; ∀ p ∈ ℤ ∩ [0, CAP], CAP = 50 (COMMISSION_PERCENT_CAP, virtual-cashier-service.ts:42):

> computeSplit(amount, p) = { commission, sellerGets }, где
> commission = ⌊amount·p / 100⌋ ∧ sellerGets = amount − commission
> ∧ commission + sellerGets = amount (сохранение суммы)
> ∧ commission ≥ 0 ∧ sellerGets ≥ 0 (неотрицательность долей)

**Где гарантия:** `src/lib/services/virtual-cashier-service.ts:126-138` (чистая функция, Math.floor); кап p enforced конфиг-слоем `parseCommissionPercent` (:94-104, бросок при p<0 или p>50). Settle-путь использует тот же сплит внутри $transaction (:250-257) с fail-secure при комиссии > 0 без счёта платформы (:226-233).

**Результат: PROVEN.** Полный перебор 22 сумм (1…1 999 999 999) × p∈[0..50] = 1122 пары: conservation, floor и неотрицательность выполняются; границы amount=1 (floor(50/100)=0), amount=999/p=5 (49+950=999), 10⁹/p=50, невалидные входы (0, дробные, отрицательные, NaN) → BizonError.

**Замечание (не нарушение квантора):** computeSplit не самопроверяет верхнюю границу p — прямой вызов `computeSplit(100, 200)` даёт sellerGets = −100. Защита живёт только в конфиг-слое; если функция когда-нибудь вызовется в обход getCashierConfig, неотрицательность доли продавца исчезнет. Рекомендация: продублировать guard `p ≤ 100` в самой функции.

**Тест:** `adversarial2/a5-money-invariants.test.ts` → describe «A5-I1 SPLIT».

## I2 (ESCROW-IDEMPOTENT)

**Теорема.** ∀ booking b: release(b)² = release(b) — повторный release не меняет балансы/ledger; все refund-пути после release(b) отклонены — эскроу расходуется ровно один раз (spend(b) + ровно один исход из {release, refund}).

**Теорема I2′ (нет печати денег).** ∀ spend-транзакции t: сумма возвратов по t ≤ −t.lumens.

**Где гарантия:** release — guard `updateMany(status='fulfilled')` + credit в одной $transaction, гонка → откат (`store-service.ts:452-470`, ранний guard :441-443); decline/cancel — guard status='held' (:504-510, :547-555); refundVar — идемпотентность через `LumenTransaction.refundOf @unique` (prisma/schema.prisma:342) + P2002-ловушка (`lumen-service.ts:557-591`); sweepStale дозакрывает возвраты идемпотентно (`store-service.ts:645-669`).

**Результат: PROVEN** для системного уровня: release² → 409, баланс продавца и ledger неизменны, ровно один escrow_release; refund после release (decline/cancel) → 409, деньги не удваиваются; параллельные гонки (2×release, 2×refundVar) → ровно один зачёт/возврат; повторный refund — no-op (ужеRefunded).

**Результат: VIOLATED для I2′.** `LumenService.refundVar` (lumen-service.ts:545-593) проверяет существование/владельца/тип исходной транзакции (:554-555), но **не сравнивает cost с original.lumens**: контрпример — spendVar 100 → refundVar(buyer, **250**, …, spendTxId) → баланс +250. Печать денег ограничена «один refund на spend» (@unique), но сумма возврата произвольна. Эксплуатабельность сейчас низкая: refundVar — внутренний примитив, все 4 вызова в store-service передают booking.priceLumens; формально инвариант на уровне примитива нарушен. Фикс — одна строка: `cost = -original.lumens` (игнорировать переданный cost либо валидировать его равенством).

**Замечание (примитив):** refundVar не знает о состоянии booking — прямой вызов refundVar по уже release-нутой сделке вернул бы деньги покупателю ПОВЕРХ зачёта продавцу (удвоение эскроу). Системно закрыто гвардами вызывающих (:504, :547, :563, :663), т.е. безопасность делегирована контрактам, а не деньгам.

**Тест:** describe «A5-I2 ESCROW» в a5-money-invariants.test.ts.

## I3 (NON-NEG)

**Теорема.** ∀ последовательности операций из {spendVar, debit, spend, refund, refundVar, credit, topup} с ЛЮБЫМИ значениями аргументов (NaN, undefined, строки, 0, отрицательные, дробные, оверспенд): либо операция отклонена, либо после неё balance ≥ 0; мусорные аргументы не меняют баланс; итоговый баланс == сумме ledger-строк.

**Где гарантия:** guard-декремент `lumenBalance: { gte: cost }` — spendVar (lumen-service.ts:517-522), spend (:330-334), debit (:386-391); валидация `Number.isInteger ∧ ≥ 1` — :514, :382-384, :607-609 (credit бросает → откат tx); каталог сумм topup (:253-258); guard для NaN/undefined/строк отсекается `Number.isInteger` (все три возвращают `false` для не-чисел).

**Результат: PROVEN.** (1) Все мусорные входы отклонены, баланс бит-в-бит неизменен. (2) Property-прогон: 300 случайных операций (mulberry32, seed 20260919) поверх модели — после КАЖДОЙ операции баланс в БД == модели и ≥ 0; оверспенды отклонены как `insufficient`; двойные refund'ы — no-op; финальная конserвация balance == Σ ledger. Дивиденды на время прогона выключены kill-switch'ом LUMEN_DIVIDENDS_ENABLED=0 (FIX-08).

**Тест:** describe «A5-I3 NON-NEG» в a5-money-invariants.test.ts.

## I4 (LEDGER-CONSERVATION)

**Теорема.** ∀ money-операции o: изменение баланса == сумме созданных o записей LumenTransaction; сбой в любой точке o откатывает всё (не существует «баланса без ledger» и «ledger без баланса»).

**Где гарантия:** одна $transaction на операцию — spend (lumen-service.ts:328-347), spendVar (:517-532), refund (:447-463, :476-491), refundVar (:566-582), credit выполняется в $transaction вызывающего (:601-624). Продемонстрировано: краш между credit/debit и следующей операцией оркестрированной транзакции → полный откат (баланс и ledger без изменений).

**Результат: PROVEN** для всех перечисленных операций; **VIOLATED для topup** и для crash-window эскроу:

1. **VIOLATED (I4t): topup не атомарен** — `lumen-service.ts:252-289`: `db.user.update` (increment lumenBalance+lumenRubles, :268-276) и `db.lumenTransaction.create` (:278-286) — два независимых top-level await БЕЗ $transaction. Контрпример (падение записи ledger simulated): баланс +300, lumenRubles +300, ledger-строки нет → balance − Σledger = 300. Последствия: расхождение «маяка правды» (кошелёк vs история), раздувание базы дивидендов без следа. Это единственная money-операция ядра без транзакционной пары — фикс: обернуть оба вызова в db.$transaction.
2. **VIOLATED (I4c, crash-window, низкая):** requestBooking (`store-service.ts:297-346`): spendVar списывает деньги (:311-315), spendTxId записывается ПОСЛЕ (:331-338). Краш процесса в зазоре оставляет held-бронь с потраченными деньгами и без spendTxId; sweepStale (:648-651) считает такие брони «мусором ДО списания» (комментарий :297-298 неверен для этого зазора), отменяет их и не возвращает деньги — покупатель теряет сумму (воспроизведено: −100 люменов при отменённой брони и пустом refundOf).

**Тест:** describe «A5-I4 LEDGER-CONSERVATION» в a5-money-invariants.test.ts.

## I5 (HASH-CHAIN)

**Теорема.** ∀ изменение текста (actorId/action/resource/resourceId/metadata) любой записи AuditLog, ∀ вставка/удаление записи → verifyChain() = { ok: false }; порядок выборки записей и окна верификации не влияют на результат.

**Где гарантия:** построение цепочки chainHash = SHA256(prevHash|actorId|action|resource|resourceId|metadata|createdAt) (`src/lib/data-vault/audit-log.ts:92-118`), строго монотонные createdAt внутри flush (S-134, :92-95), сериализация flush'ей (:70-73); verifyChain (:129-156).

**Результат: PROVEN** для: tamper metadata/actorId/action средней записи → ok:false + brokenAtId указывает на запись (восстановление текста → снова ok:true); инъекция записи с чужим chainHash → разрыв; удаление средней записи → разрыв; порядок выборки/окно (limit=3 и вся таблица) — на результат не влияют; метки строго монотонны.

**Результат: частично VIOLATED.** verifyChain проверяет пары, начиная с i=1 (:138) — хэш самой старой записи окна (ordered[0], включая генезис всей таблицы) **никогда не пересчитывается по содержимому**: подделка её metadata/actorId → verifyChain = { ok: true }. Контрпример воспроизведён: первая запись таблицы изменена, верификатор зелёный. Теоретическое дополнение: дописывание записи в «голову» с пересчитанным хэшем тоже недетектируемо — у цепочки нет внешнего якоря ( published head-hash). Фикс: пересчитывать ordered[0] с anchor='GENESIS' (и/или публиковать head-hash наружу).

**Тест:** describe «A5-I5 HASH-CHAIN» в a5-audit-consent.test.ts.

## I6 (CONSENT)

**Теорема.** ∀ userId: (¬consentAiAnalysis(userId)) → AI-анализ невозможен; cross-border без consentCrossBorder → внешний compute (LLM) запрещён.

**Где гарантия:** `src/lib/sovereignty/gateway.ts:117-229` — check() читает согласия (:118-136), класс A без consentAiAnalysis → blockedFields (:151-157), cross-border без согласия → allowed=false + externalComputeBlocked (:173-191); AIGateway вызывает LLM только при allowed=true (`src/lib/ai-core/gateway.ts:267-302`); minimizeForAI обезличивает класс A безусловно (:239-257); BizonMoment — fail-closed гейт S-139 (`bizon-moment-service.ts:160-162, 182-183`).

**Результат — MIXED:**

- **PROVEN:** поля класса A без согласия попадают в blockedFields и минимизируются (email/phone/birthday/ip/passwordHash удалются, name→псевдоним, location→регион, bio≤300); cross-border RU→DE без согласия → allowed=false (LLM не вызывается, эвристика); согласие → разрешает; псевдоним детерминированный; BizonMoment без consentAiAnalysis не отдаёт и не генерирует инсайты даже при наличии данных (дифференциальный тест).
- **VIOLATED (строгая формулировка):** (а) `consentAiAnalysis=false` **не запрещает сам AI-анализ** — check() возвращает allowed=true (заблокированные поля лишь перечислены в blockedFields, :211-228), AIGateway видит blocked=false и вызывает LLM на минимизированных данных: согласие фактически управляет только набором полей, которое и так минимизируется безусловно; операционного отказа нет. (б) **fail-open**: user не найден / сбой БД → согласия считаются выданными (`gateway.ts:133-136`, дефолт true) — контрпример: check('несуществующий-id', …, ['email','phone']) → allowed=true без блокировок; тот же fail-open срабатывает при недоступности БД. (в) код-наблюдение без отдельного теста: в AIGateway падение check() глотается (`.catch → null`, gateway.ts:272) и трактуются как blocked=false (:273) — второй fail-open слой.
- Рекомендации: для операций над классом A без consentAiAnalysis возвращать allowed=false (или явный флаг `operationRefused`), дефолт для отсутствующего пользователя сделать fail-closed, результат check()==null в AIGateway трактовать как blocked.

**Тест:** describe «A5-I6 CONSENT» в a5-audit-consent.test.ts.

---

## Приоритизация находок (для модератора)

| ID | Находка | Серьёзность | file:line |
|---|---|---|---|
| A5-1 | topup: increment баланса/рублей и ledger не в одной $transaction → «баланс без ledger» при сбое | **medium** | lumen-service.ts:268-286 |
| A5-2 | refundVar не сверяет сумму возврата с исходным spend (печать денег на уровне примитива) | **medium** (латентная: прямого API-пути нет) | lumen-service.ts:554-582 |
| A5-3 | verifyChain не проверяет контент самой старой записи окна (генезис) — tamper незамечен | **medium** | audit-log.ts:138 |
| A5-4 | consentAiAnalysis не запрещает AI-анализ; fail-open при отсутствии пользователя/сбое БД (152-ФЗ/GDPR-постулат) | **medium** | sovereignty/gateway.ts:133-136, 211-228; ai-core/gateway.ts:272-273 |
| A5-5 | crash-window: краш между spendVar и записью spendTxId → sweepStale отменяет бронь без возврата | **low** (требует краша в зазоре) | store-service.ts:297-346, 648-651 |
| A5-6 | computeSplit без собственного верхнего капа p (защита только в конфиг-слое) | **low** (remark) | virtual-cashier-service.ts:126-138 |
| A5-7 | refundVar не знает о статусе booking — удвоение эскроу закрыто только гвардами вызывающих | **low** (remark) | lumen-service.ts:545-593; store-service.ts:504,547,563 |

Воспроизведение каждой находки — зелёные COUNTEREXAMPLE-тесты в `adversarial2/a5-*.test.ts` (запуск: `bun test adversarial2/a5-*.test.ts`). Ничего в src/** и prisma/** не изменялось.
