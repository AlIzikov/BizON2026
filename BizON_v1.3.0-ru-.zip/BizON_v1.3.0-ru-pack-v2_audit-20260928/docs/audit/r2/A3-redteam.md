# R2-A3 «Red-Team» — адверсариальное ревью BizON (повторный аудит)

Дата: 2026-09-19 · Аудитор: A3 (red-team, R2-A3) · Приказ владельца: «доказать, что BizON ломается, каждую атаку воспроизвести тестом, ничего не чинить»

**Метод.** Каждая атака — воспроизводящий тест в BLOCKED-семантике: тест **красный** = атака удалась (BizON сломан, доказано); тест **зелёный** = система отбила. Уровень атаки — сервисный контракт (`src/lib/services/**`, `src/lib/ai-governance/**`) плюс один API-слой (`/api/messages`) через прямой вызов route-handler. Фикстуры — изолированная копия БД (`tests/helpers/setup.ts`), живые данные не затронуты. `src/**`, `prisma/**` не менялись.

**Файлы атак:** `adversarial2/a3-economics.test.ts`, `a3-authz.test.ts`, `a3-intro.test.ts`, `a3-validation.test.ts`.

**Запуск:** `bun test --timeout 60000 adversarial2/a3-*.test.ts`
*(без `--timeout` два зелёных теста ложнопадают по дефолтному лимиту bun 5с — инфраструктурный шум, не атаки)*

**Хвост вывода:**
```
 10 pass
 12 fail
 11 expect() calls
Ran 22 tests across 4 files. [3.38s]
```
**Итог: 22 атаки → 12 BROKEN / 10 BLOCKED.** BizON сломан в 12 местах; каждый BROKEN ниже подтверждён падающим тестом с сообщением «АТАКА УДАЛАСЬ: …».

---

## 1. Таблица атак (по убыванию силы)

| ID | Атака | Цель | Вердикт | Уязвимое место (file:line) |
|---|---|---|---|---|
| A3-ATK-002 | **Печать люменов: refundVar с завышенной суммой** — spend 10 Л, refund по той же транзакции на 5000 Л | LumenService.refundVar | **BROKEN** | `src/lib/services/lumen-service.ts:552-582` — параметр `cost` не сверяется с `original.lumens`; зачисляется ровно то, что попросили |
| A3-ATK-001 | **Двойной расход: refund ПОСЛЕ release** — сделка released (продавцу зачислено), затем refund покупателю по тому же spendTxId | эскроу StoreService + LumenService | **BROKEN** | `src/lib/services/lumen-service.ts:554-556` — refundVar проверяет только `type==='spend'` и владельца, не знает о состоянии StoreBooking; `store-service.ts:452-470` release не «гасит» spendTxId для refund'ов |
| A3-ATK-010 | **User-prohibition «\*» обходится в основном пути** — пользователь с запретом всех AI-действий получает `approved` | GovernanceService.proposeAction | **BROKEN** | `src/lib/ai-governance/governance-service.ts:119-123` — в `PolicyEngine.evaluateAction` НЕ передаётся `userId`; prohibit-ветка (`policy-engine.ts:72-85`, Wave 6 S-135) недостижима из боевого пути |
| A3-ATK-009 | **Пауза чужого агента без прав** — посторонний userId выполняет pauseAgent/resumeAgent | GovernanceService.pauseAgent/resumeAgent | **BROKEN** | `src/lib/ai-governance/governance-service.ts:442-471` — сервис не проверяет ни роль, ни владение агентом (API-гейт requireAdmin есть только в route) |
| A3-ATK-014 | **Consent-обход интро: диалог до accept посредника** — сообщение незнакомцу через /api/messages при ipScore≥30 | интро-цикл §7.6 / messages route | **BROKEN** | `src/app/api/messages/route.ts:61,79-81` — гейт репутационный (ipScore≥30, достижимо легитимно), а не consent-ный; инвариант `intro-service.ts:8` «сообщение цели уходит ТОЛЬКО после accept» обходится параллельным путём. Контроль: ipScore=0 честно 403 |
| A3-ATK-002→004 | **Сплит без верхнего капа** — computeSplit(100,150) → sellerGets = −50 | VirtualCashierService.computeSplit | **BROKEN** (контракт) | `src/lib/services/virtual-cashier-service.ts:126-138` — нет верхней границы: комиссия 100% забирает всё продавцу, >100% даёт отрицательную выплату. Кап живёт только в env-парсере (`:94-104`; env=150 → BLOCKED, проверено) |
| A3-ATK-015 | **Velocity-спам интро не блокируется** — 8 интро/час (riskScore=50<70 → observe/allow); взаимное кольцо на verified-аккаунте (40<70 → allow) | sarafanGuard.evaluateIntroRequest | **BROKEN** | `src/lib/services/sarafan-guard.ts:62-66` — порог блока 70 недостижим без созвездия «кольцо+новый аккаунт»; чистый спам и обмен «ты-за-меня» проходят всегда |
| A3-ATK-017 | **Инъекция в name при регистрации** — `<script>` и имя в 5000 символов сохраняются дословно | AuthService.register | **BROKEN** | `src/lib/services/auth-service.ts:50` — `name: input.name` без sanitizeUserText и без лимита (контракт аудита: ≤300). `auth.ts:88` (bidi-strip) тоже не режет теги |
| A3-ATK-020 | **Email без формата и длины** — `not-an-email-at-all` и email в 500+ символов принимаются сервисом | AuthService.register | **BROKEN** | `src/lib/services/auth-service.ts:27-32` — проверок нет; route (`register/route.ts:57`) проверяет только `includes('@')` |
| A3-ATK-018 | **Инъекция в title товара** — `<script>` сохраняется в StoreItem дословно | StoreService.createItem | **BROKEN** | `src/lib/services/store-service.ts:160` — только `trim()`; sanitizeUserText не применён |
| A3-ATK-019 | **XSS-носитель через интро-сообщение** — `<img onerror>` из текста запроса дословно уходит в Message цели после accept | introService.create→accept | **BROKEN** | `src/lib/services/intro-service.ts:107` (slice 2000, без санитизации) → `:174-176` message.create |
| A3-ATK-016 | **updateItem принимает slotsTotal=−1** — квота сессий тихо снимается (createItem требует 0..1000) | StoreService.updateItem | **BROKEN** | `src/lib/services/store-service.ts:255` — patch.slotsTotal пишется без валидации; slot-guard `requestBooking` трактует ≤0 как «безлимит» |
| A3-ATK-003 | Двойной release одного booking (последовательный) | StoreService.release | BLOCKED | `store-service.ts:452-470` — updateMany-guard + releaseTxId @unique → повтор 409, второго зачисления нет; release до fulfil → 409 |
| A3-ATK-005 | Нулевые/отрицательные/дробные/NaN цены и суммы | spendVar / topup / debit / createItem / slotAt | BLOCKED | `lumen-service.ts:514,253,382`, `store-service.ts:121,292` — bad_cost / whitelist / fail-fast / 400 |
| A3-ATK-020c | NaN/строка/∞ не меняют баланс ни в одной люмен-операции | LumenService | BLOCKED | `lumen-service.ts:514,382` |
| A3-ATK-006 | Сбой в середине транзакции → частичное списание? | sweepStale | BLOCKED | `store-service.ts:645-668` — held-без-spendTxId закрывается, «declined без refund» досылается идемпотентно; потери средств нет |
| A3-ATK-007 | IDOR: release/fulfil/decline/cancel чужого booking, accept чужого интро | StoreService, introService | BLOCKED | `store-service.ts:399,440,503,546`, `intro-service.ts:154` — 404, статусы не изменены |
| A3-ATK-008 | Утечка scoreInternal через публичные отзывы; self-review | ProjectRoomService.listPublic/review | BLOCKED | `project-room-service.ts:218` — поле не сериализуется; self-review 422 |
| A3-ATK-011 | Риск-действие без записи в action-registry; SPEND_MONEY без полномочия | proposeAction | BLOCKED | `policy-engine.ts:66-69,86-89` — неизвестное действие и невыданный critical → POLICY_BLOCKED (secure-by-default) |
| A3-ATK-012 | Порядок проверок права vs состояние; повторное решение; 2-of-N одним юзером; expired | decideAction | BLOCKED | `governance-service.ts:252-258` (FORBIDDEN раньше ALREADY_DECIDED — посторонний не узнаёт состояние), `:293-296` (дубль одобрения), `:261-267` (TTL) |
| A3-ATK-013 | Self-intro, мусорный purpose, дубликат pending, accept по истечении | introService | BLOCKED | `intro-service.ts:46-47,65-69,154-159` — 400/400/409/410 |
| A3-ATK-007x | Сессии по чужому userId | AuthService.createSession | BLOCKED | токен привязан к создателю; чужой идентификатор сессию не выдаёт |

## 2. BROKEN: принципал → ресурс → последствие

1. **A3-ATK-002 (критично, деньги).** Любой вызывающий refundVar → `LumenTransaction` чужого spend → печатает произвольную сумму люменов (в тесте: 10 → 5000). Ресурс: `User.lumenBalance`. Последствие: инфляция валюты платформы, «напечатанные» дивиденды/балансы.
2. **A3-ATK-001 (критично, деньги).** Покупатель после release возвращает себе цену, продавец уже получил оплату → двойное зачисление из эскроу (в тесте продавец +50 и покупателю вернули 50). Ресурс: эскроу-бухгалтерия Store. Последствие: систематический двойной расход при любом будущем вызывающем refund (порт кассы, новая механика возвратов).
3. **A3-ATK-010 (высокий, governance).** Пользователь с `UserProhibition('*')` (kill его AI-прав полностью) получает `approved` действия в основном пути proposeAction. Ресурс: AI-контур (S-135). Последствие: заявленный щит Wave 6 «prohibition сильнее полномочий» не работает там, где он нужен, — в боевом пути (тест Wave 6 проверял PolicyEngine напрямую, минуя GovernanceService).
4. **A3-ATK-009 (высокий, доступность AI).** Любой, кто доходит до сервиса, ставит на паузу/возобновляет чужой агент. Ресурс: `AiAgent.status`. Последствие: саботаж чужой автоматизации; защита держится только на одном слое (route), defense-in-depth отсутствует.
5. **A3-ATK-014 (высокий, приватность/consent).** Диалог и текст запросера доставляются цели ДО согласия посредника — гейт ipScore≥30 заменяет согласие человека. Ресурс: интро-инвариант §7.6, приватность цели. Последствие: легитимно набравший ipScore пользователь пишет любому незнакомцу, минуя весь consent-контур Sarafan Radio (конфликт с задокументированной M4-политикой route).
6. **A3-ATK-004 (высокий при переходе на реальные кассы).** Контракт сплита допускает sellerGets<0 и комиссию 100%+. Ресурс: будущие CashierPort-адаптеры. Последствие: опечатка будущего конфига/адаптера уводит выплату продавца в минус молча.
7. **A3-ATK-015 (средний, антифрауд).** Спам 8+/час и взаимные кольца на verified-аккаунтах не блокируются. Ресурс: Sarafan Radio. Последствие: фермы знакомств/спам не встречают сопротивления гварда.
8. **A3-ATK-017 / 020 (средний, целостность данных).** Имя с HTML и неограниченной длиной, email произвольного формата/длины попадают в БД. Ресурс: User.name/email. Последствие: XSS-носители для не-React потребителей (письма email-service.html, тексты уведомлений), переполнения, грязные email-хэши поиска.
9. **A3-ATK-018 / 019 (средний).** Store title и текст интро хранят `<script>`/`<img onerror>` дословно (в Message попадают после легитимного accept). Ресурс: StoreItem.title, Message.content. Последствие: носители stored-XSS (React экранирует рендер — риск вне React-рендера), нарушение собственной политики `src/lib/sanitize.ts` («пользовательский текст — не HTML»).
10. **A3-ATK-016 (низкий).** updateItem обходит валидацию slotsTotal. Ресурс: StoreItem.slotsTotal. Последствие: тихое снятие квоты сессий (≤0 = безлимит в slot-guard).

## 3. Coverage

**Атакованные зоны:** эскроу Store (release/fulfil/decline/cancel/double-release/refund-after-release), примитивы LumenService (spendVar/refundVar/debit/topup/credit-суммы), касса (computeSplit/env-кап), governance (proposeAction, decideAction: права/состояние/2-of-N/TTL, pauseAgent, user-prohibitions, action-registry), интро-цикл (self/дубликаты/TTL/чужой accept/velocity/consent через messages route), IDOR (booking/intro/review), утечки (scoreInternal), Store-валидация (цены/slots/title), регистрация (name/email), сессии.

**Не атаковано (вне охвата R2-A3, кандидаты на следующий раунд):** LOT-эскроу (`lot-service`), `cashier-ports-service` (роутинг портов VC-2, идемпотентность pay), hash-chain аудит (tamper-evidence — покрыт wave6-adversarial), web-push, KYC-гейт (недостижим by design), rate-limit остальных API, параллельные гонки (проверена последовательная семантика), UI-слой и E2E-браузер, complaint-дедуп, jobs/claims.

**Процесс-заметка:** 2 из 12 BROKEN (010, 009) — зоны, где Wave 6 заявляла щиты и имела зелёные тесты; тесты проверяли слой ниже боевого пути (PolicyEngine напрямую, а не proposeAction). Рекомендация (без исполнения): гейты governance — только через GovernanceService.

## 4. Изменения в репозитории

- Создано: `adversarial2/a3-economics.test.ts`, `adversarial2/a3-authz.test.ts`, `adversarial2/a3-intro.test.ts`, `adversarial2/a3-validation.test.ts` (22 атаки), этот отчёт.
- Не тронуто: `src/**`, `prisma/**`, `src/lib/**` — ничего не чинилось и не менялось.
