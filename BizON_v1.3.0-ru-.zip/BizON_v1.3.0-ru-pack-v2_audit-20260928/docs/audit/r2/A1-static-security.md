# A1 — STATIC-SECURITY (повторный аудит R2)

Task ID: R2-A1 · Дата: 2026-09-19 · Аудитор: A1 (код не писал, прошлым отчётам не доверяет)
Методика: semgrep-правила «паттерн → сообщение → severity», перенесённые в rg/regex-сканы
(карточка semgrep — docs/knowledge/REPO-LEARNING-2026-09-19.md §3). Скоуп: только src/**
(/home/z/my-project). Все находки открыты вручную, false positives отсекались по правилу
«предназначенное поведение того же принципала / тестовый файл / зависимость-внутри».

---

## 1. ТАБЛИЦА НАХОДОК

| ID | Категория (semgrep-правило) | Severity | File:line | Доказательство (сниппет) | Как перепроверить (1 команда) |
|----|---------------------------|----------|-----------|--------------------------|-------------------------------|
| A1-F1 | Hardcoded secret: сессионный токен в исходнике | **medium** | src/middleware.ts:20 | `const DEMO_TOKEN = '8a4be271d397c02c84b17fe8d4edaa5a1d3fe9c60b9ad232c34459ad2900e758';` — комментарий: «реальная строка Session в db/custom.db, пользователь "Иван Петров"» | `rg -n "const DEMO_TOKEN" /home/z/my-project/src/middleware.ts` |
| A1-F2 | Logging PII/секрета: сырой verify-токен + email в лог | **low** | src/lib/services/email-service.ts:120–127 | `console.log(\`\n📧 [DEV EMAIL STUB] … To: ${input.to} … ${input.text \|\| input.html.replace(/<[^>]+>/g, '').slice(0, 200)}…\`)` — срабатывает при НЕнастроенном SMTP и в проде | `rg -n -A8 "DEV EMAIL STUB" /home/z/my-project/src/lib/services/email-service.ts` |
| A1-F3 | Weak randomness (Math.random) для идентификатора «NFT» | **informational** | src/lib/services/nft-skills-service.ts:381 (дубль: src/app/api/nft-skills/[id]/mint/route.ts:18) | `// Заглушка blockchain-минта` + `const tokenId = \`0x${Math.random().toString(16).slice(2).padStart(64,'0')…}\`` | `rg -n "Math.random" /home/z/my-project/src/lib/services/nft-skills-service.ts` |
| A1-F4 | dangerouslySetInnerHTML с интерполяцией env | **informational** | src/app/layout.tsx:84–90 | `__html: \`… gtag('config', '${process.env.NEXT_PUBLIC_GA_ID}');\`` — env-переменная инлайнится в скрипт без экранирования | `rg -n -A6 "NEXT_PUBLIC_GA_ID" /home/z/my-project/src/app/layout.tsx` |

### Детали и границы находок

**A1-F1 (medium).** Токен захардкожен, но инъекция cookie в middleware гейтируется env
(`BIZON_DEMO_AUTH === '1'`, middleware.ts:86–99). Ключевой нюанс: сам API это env НЕ
проверяет — `getUserFromRequest` (src/lib/auth.ts:175–183) валидирует ЛЮБОЙ токен из
Session-таблицы, а seed-скрипт `scripts/bizon/seed-demo-profile.js:33–41` (вне скоупа,
приведён как доказательство) создаёт эту строку в БД с TTL 7 дней. Независимая проверка
живой БД (sqlite read-only): `SELECT … WHERE token='8a4be…'` → **0 строк** — сейчас токен
мёртв. Риск материализуется, когда: (а) seed перезапущен (это документированный путь
доступа в docs/CHECKPOINT.md:18 — кука прописана прямо в доке), или (б) код+доку унесут
в прод. Тогда знание исходника = вход без пароля за пользователя «Иван Петров».
Severity medium, а не high: радиус ограничен одним демо-принципалом в песочнице; но это
подлинный креденшел в коде — фикс (генерить токен при seed, не хранить в git) обязателен.

**A1-F2 (low).** Регистр строит сырой verify-токен (src/app/api/auth/register/route.ts:138:
`${appUrl()}/api/auth/verify-email?token=${verifyToken}`) и передаёт в шаблон письма.
При `isSmtpConfigured() === false` (email-service.ts:119–128) письмо целиком — включая
ссылку с сырым 24-часовым токеном и email получателя — уходит в console.log сервера.
Сам сервис токенов честный (в БД только sha256-хэш, verification-token.ts:1–8). Условие
эксплуатации — misconfig SMTP в проде, поэтому low. Лечится: не логировать html/text,
даже в dev-заглушке.

**A1-F3 (informational).** Предсказуемый tokenId для мока-«минта». Секретов не создаёт,
границу не пересекает (там же контракт — заглушка). При реальном блокчейне → минимум low.

**A1-F4 (informational).** NEXT_PUBLIC_GA_ID / NEXT_PUBLIC_YM_ID интерполируются в
inline-скрипт без экранирования. Значения задаёт оператор на билде, не пользователь;
инъекция возможна только при компрометации конфига. Отмечено как подтверждённая мелочь
(обычная практика GA-сниппетов), не уязвимость user-input.

---

## 2. FALSE POSITIVES ОТСЕЧЕНЫ (примеры)

| Где сработал скан | File:line | Почему НЕ находка |
|---|---|---|
| `\bexec\s*\(` (категория 1 — exec) | src/lib/services/notification-service.ts:120 | `const m = /^(\d{1,2}):(\d{2})$/.exec(t);` — это RegExp.exec, а не child_process/os.exec. По всему src/**: 0 вызовов eval/new Function/child_process/exec/spawn (остальные хиты — комментарии «цель eval (protocol §12)»). |
| `secret\s*[:=]\s*['"]…` (категория 4) | src/lib/ai-eval/generators.ts:567, 1295–1326 | `{ embedSecret: 'SECRET_EMBED_2' }` и `http://10.1.2.3/x`, `http://169.254.169.254/…` — фикстуры eval-набора (SSRF-тесты на собственный validateUrlSafety), значения-маркеры, не креденшелы и не реальные вызовы наружу. |
| `sha1` (категория 5 — weak crypto) | src/lib/services/totp-service.ts:19 | `algorithm='sha1' — соответствует RFC` — TOTP по RFC 4226/6238 обязан использовать HMAC-SHA1. Backup-коды: CSPRNG (`randomInt`, FIX-03) + SHA-256 с солью. Пароли: PBKDF2 (auth.ts:30, auth-service.ts:150) — слабой крипты нет. |
| Un-awaited `AuditLog.log(...)` / `void NotificationService.notify(...)` (категория 8 — floating promise) | src/app/api/auth/login/route.ts:65,80; src/lib/services/intro-service.ts:120,182,189,228 | `AuditLog.log` — синхронный push в буфер (audit-log.ts:37–41), flush — цепочка с мьютексом и внутренним catch. `NotificationService.notify` целиком обёрнут в try/catch, возвращает null, не reject'ит (notification-service.ts:147–187) — fire-and-forget безопасен by design («fail-open», задокументирован). Денежные пути проверены отдельно: lumen-service (spendVar/refundVar/credit), cashier-ports-service.pay, store-service release, lot-service acceptResponse — все через `await`. |
| `dangerouslySetInnerHTML` (категория 2) | src/app/layout.tsx:62,84; src/components/ui/chart.tsx:83 | layout: статичные аналитические сниппеты Yandex.Metrica/GA4, прод-only, данные — build-time env. chart.tsx: канонический shadcn/ui, сериализация статического THEMES/colorConfig-конфига разработчика. User input в `__html` не попадает нигде (`.innerHTML =` в src/** — 0). |

Дополнительно отсечено: CORS (категория 10) — единственные установки Access-Control-*
в src/middleware.ts:74–123, origin-whitelist с отражением конкретного origin, `*` нет;
http:// (категория 6) — только localhost/127.0.0.1 дефолты и dev-CORS-origins, внешних
незашифрованных вызовов 0; redirect (категория 7) — единственный NextResponse.redirect
(verify-email/route.ts:58) ведёт на константный `/`, searchParams-редиректов нет;
`$queryRaw`/`$executeRaw`/`$queryRawUnsafe` в src/** — **0 матчей** (SQL только через
параметризованный Prisma, сырого SQL-склейки `SELECT ${…}` — 0); localStorage-хранения
токенов в клиентских сторах — 0.

---

## 3. COVERAGE-ЗАМЕТКА

**Сканировано: весь src/** = 746 файлов** (tree-wide rg-сканы по каждой категории):
- src/app — 359 файлов (все ~200 API-роутов: auth, lumens, cashier, wallet, admin, me, jobs, projects, store, news…);
- src/components — 217 файлов;
- src/lib — 164 файла (security/, services/, ai-core/, data-vault/, event-bus/, governance…);
- src/stores — 1 файл; src/hooks; src/middleware.ts; src/instrumentation.ts.

Прогнано ~15 правил-сканов (по одному на класс опасности + 4 косвенных: raw-SQL-склейка,
прямые sqlite-клиенты, document.write, localStorage-токены, NEXT_PUBLIC-секреты, private
key/AKIA/sk-/ghp_-префиксы, hex-литералы ≥32).

**Вне скоупа по заданию** (не сканировались, кроме следов F1 как доказательства):
tests/**, tools/** (adversarial, evals), scripts/**, mini-services/, examples/,
bizon-recovery/, docs/, specs/.

**Непосещённое / deferred (честный остаток):**
1. Межфайловый taint-трекинг (source→sink через хелперы) не делался вручную для всех 746
   файлов — это зона A4 (dataflow/authz: IDOR, mass assignment, per-route auth). Здесь
   проверены только локальные паттерны redirect/HTML-инъекций.
2. next.config.ts (корень, не src) — peeked для проверки CSP/заголовков: frame-ancestors
   средо-зависимый, прод без wildcard — нарушений не зафиксировано; полный аудит
   Caddyfile/HSTS — вне скоупа A1.
3. Регулярка секретов не ловит секреты в нестандартных именах переменных (напр.
   `const K = '…64hex…'`) — компенсировано отдельным hex-сканом (единственный хит = F1
   + golden-hash тестфикстура).
4. Динамически собираемые ключи process.env[...] (src/lib/security/crypto.ts:62) —
   намеренный анти-инлайн паттерн, ключ не хардкожен; ок.

**Калибровка severity применена по cloudflare-правилу:** критических (RCE без аутентификации)
и high (полный bypass auth/cross-tenant) не найдено: 0 critical / 0 high / 1 medium / 1 low /
2 informational.
