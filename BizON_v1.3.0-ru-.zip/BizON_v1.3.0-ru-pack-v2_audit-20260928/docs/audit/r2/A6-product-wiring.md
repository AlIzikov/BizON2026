# R2 · A6 «Product-Wiring» — аудит взаимных связей UI ↔ API ↔ данных

**Task ID:** R2-A6 · **Дата:** 19.09.2026 · **Аудитор:** независимый (A6, код не писал, файлы не менял)
**Метод:** собственная AUD-методика, 5 детекторов:
(1) fake-success — toast/alert «успех» без сетевого вызова; (2) мёртвый экспорт — экспорт без единого импорта;
(3) API без UI — роут без потребителя в компонентах/stores; (4) UI без API — кнопка/форма без fetch;
(5) тест-данные в проде — QA/E2E-артефакты в живом UI.
**Инструменты:** статический разбор (rg по src/components, src/stores, src/hooks, src/app/api) + read-only запросы к живой БД (db/custom.db, Prisma, только count/find).
**Ограничение:** живой браузерный прогон не выполнялся (статика + БД); вердикты «wired in code» требуют браузерного подтверждения по гейту G-UI-PERFECT.

---

## 1. ПОВТОРНАЯ ПРОВЕРКА НАХОДОК AUDIT-REPORT-2026-09-19 (раздел 3A)

| # | Находка аудита | Вердикт R2 | Доказательство (file:line) |
|---|---|---|---|
| A-1 | Жалоба — fake success, three-dots-menu.tsx:35 | **CONFIRMED** | three-dots-menu.tsx:35 — `toast({ title: 'Жалоба отправлена'…})`, ни одного fetch в файле; компонент даже не получает id объекта. /api/complaints существует (route.ts, 7 категорий), но **ни один компонент его не вызывает** (rg: только route.ts:1). Бонус-находка: там же :29 «Сохранено в закладки» — второй fake-success без /api/posts/[id]/save. |
| A-2 | POST /api/intros не вызывается ни одним UI («интро-цикл недостижим») | **CONFIRMED (уточнено)** | Потребители /api/intros — только intro-inbox.tsx:39 (GET ?box=incoming) и :53 (POST accept/decline). **POST-создание запроса не зовёт никто.** Карточки «Путь: Вы → N → M» и кнопки «Запросить знакомство» на чужом профиле нет (public-persona.tsx: rg introPath/«Запросить знакомство» — 0 в UI; строка есть лишь в ai-governance/action-registry.ts:64). Инбокс при 0 записей рендерит null (intro-inbox.tsx:63) → цикл обрывается на шаге 1 навсегда. sendIntro в matchmaker-view.tsx:82 шлёт /api/messages, не /api/intros. |
| A-3 | Юрлицо не может разместить вакансию из UI | **REFUTED (исправлено после аудита)** | company-dashboard.tsx:108–109 кнопка «Создать вакансию» → CreateJobDialog → :210 `api('/api/jobs', { method: 'POST' …})`; дашборд смонтирован для company/hr_agency: app/page.tsx:113. Вторая форма — fab-create-dialogs.tsx:350 (но сам FabCreateDialogs мёртв, см. A6-F07). Остаточное: кнопки нет в jobs-view (путь FAB ведёт в тупик, см. A6-F08). |
| A-4 | VC-экспорт W3C без UI (/api/me/credentials жив, пункта в Настройках нет) | **CONFIRMED** | settings-view.tsx — полный обход секций (IP-score, тариф, кошелёк, тема, 2FA, Decision Inbox, суверенитет, выход): пункта экспорта credentials нет. rg `me/credentials` в src/components + src/stores — 0. Цепочка VCExportService → /api/me/credentials → ∅. |
| A-5 | /api/me/relationship/[userId] никто не потребляет (двухрежимный профиль contact/stranger) | **CONFIRMED** | rg `me/relationship` — только route.ts:1. Ни компонент, ни store. Профиль не скрывает контакты stranger'у (D-10 не сделан). |
| A-6 | Opportunity Graph /related без UI; Reputation Estimator и ролевая матрица сообществ без API/UI; detectTextSync мёртв; outbox без продюсеров | **CONFIRMED (4/4)** | /api/opportunities/related — 0 потребителей. src/lib/trust/reputation-estimator.ts:42 estimateReputation — импортируют только tests/wave3-*. Оба факта — в §3. fraud-text-sync.ts:44 detectTextSync — импортируют только tests/wave3-*. outbox-service.ts импортирует только /api/admin/outbox (продюсеров нет). |
| A-7 (3B) | Web-push fake success при настроенных ключах | **CONFIRMED** | web-push-service.ts:56 — при настроенном VAPID `return { ok: true, sent: 0 }` без отправки (сам комментарий :42–44 признаёт: RFC 8291 «подключается библиотекой… в рамках ADR»). Плюс: у /api/push нет UI-подписки вообще (A6-F10). |
| A-8 (3C) | Лента загрязнена тест-артефактами; демо-подсказка на входе; «день рождения» у юрлица; дубли QA3 | **CONFIRMED (живая БД)** | См. §4: в db/custom.db — 52 юзера, «QA3 User A» ×2 (дубли!), QA3 User B–H, QA Test XFF, Alice/Bob/Carol E2E, 8 QA/E2E-проектов, 4 SSRF-тест-поста. auth-screen.tsx:318 «Демо: ivan@bizon.ru · пароль: password» публично. profile-view.tsx:191 «День рождения (необязательно)» без accountType-гейта (rg accountType в файле — 0). |

**Итог перепроверки: 7 CONFIRMED / 1 REFUTED (A-3 — «вакансия юрлица» уже проводена в UI).**

---

## 2. НОВЫЙ ОБХОД ПО ДЕТЕКТОРАМ (участки, где AUD-1/2 не смотрели)

| ID | Детектор | Находка | file:line | Severity |
|---|---|---|---|---|
| A6-F01 | 4+3 | **AI Co-Pilot — двойной обрыв.** UI отвечает клиентскими keyword-заготовками с фейковой задержкой 500мс и **не вызывает** существующий боевой POST /api/ai-co-pilot (LLM, AIGateway, rate-limit, честный бейдж provider='heuristic'). Роут мёртв, UI имитирует AI — вопреки конвенции самого роута («детерминистику нельзя выдавать за AI») | ai-co-pilot.tsx:19–43 (0 сетевых вызовов); /api/ai-co-pilot/route.ts:1–232 (потребителей 0) | **HIGH** (продукт: витринная AI-функция — фикция) |
| A6-F02 | 3 | **GDPR/152-ФЗ двери отсутствуют в UI:** /api/me/export-data, /api/me/delete-account, /api/me/forget-me — 0 потребителей. Пользователь не может ни экспортировать, ни удалить данные, хотя бэкенд готов (суверенитет-секция при этом заявляет 152-ФЗ/GDPR-режимы) | rg по src/components+stores — 0; route-файлы: me/export-data:1, me/delete-account:1, me/forget-me:4 | **HIGH** (регуляторный продукт-обещание без двери) |
| A6-F03 | 3 | /api/notifications/settings (GET/PATCH) — 0 потребителей: тонкая настройка уведомлений недоступна из UI (dropdown умеет только «прочитать всё») | app-shell.tsx:867–915 (только GET /api/notifications, POST read); settings route:4–5 — 0 вызовов | MEDIUM |
| A6-F04 | 3 | Lifecycle мероприятий без UI: /api/events/[id]/publish, /cancel, /attendees — 0 потребителей. Организатор может создать событие и RSVP, но не может опубликовать/отменить/увидеть список участников | events-view.tsx:79,92 (только GET+RSVP), :418 (POST create); rg publish/cancel/attendees — 0 | MEDIUM |
| A6-F05 | 3 | Сервис интентов без UI: /api/me/intent (+[id]), /api/me/intent-snapshot — 0 потребителей (job-intent-bar — управляемый инпут, API зовёт родитель на /api/jobs/match) | job-intent-bar.tsx (0 api); rg `me/intent` — 0 | MEDIUM (Wave-ядро «intention-first» без двери) |
| A6-F06 | 3 | Мёртвые me-API: /api/me/career-outcome, /api/me/history-people, /api/me/interested-companies, /api/users/recommendations (+[id]), /api/cultural-signals (верхнеуровневый), /api/me/sovereignty/check, /api/hypotheses (+/run) — по 0 потребителей | rg-серия §2, пакетная проверка (11 роутов с нулём) | LOW–MEDIUM |
| A6-F07 | 2 | **fab-create-dialogs.tsx (673 строки) — мёртвый компонент:** ни одного импорта. Внутри рабочие формы поста/события/вакансии (POST /api/jobs:350 и др.). FAB при этом открывает заглушку CreateActionModal «🚧 Полноценная форма будет в Фазе 2» | rg `from '@/components/shell/fab-create-dialogs'` — 0; app-shell.tsx:677,803,810,838 | MEDIUM (дед-код + обманчивая заглушка) |
| A6-F08 | 4 | FAB «Опубликовать вакансию» ведёт в jobs-view, где **кнопки создания нет** → тупик; рабочая дверь существует только в другом разделе («Дашборд» юрлица) | app-shell.tsx:818 (view:'jobs'); jobs-view.tsx — rg «Создать вакансию|api/jobs» — 0; рабочая форма: company-dashboard.tsx:210 | MEDIUM |
| A6-F09 | 1 | data-sovereignty-section читает состояние через **GET на /api/me/sovereignty/update** (эндпоинт-мутант), тогда как /api/me/sovereignty/check остался мёртвым — контракт API расходится с семантикой | data-sovereignty-section.tsx:62 (GET …/update), :86 (PATCH) | LOW |
| A6-F10 | 3+1 | Web-push: подписка недоступна из UI (0 потребителей /api/push) + fake-success при настроенных ключах (см. A-7). Push недостижим с обеих сторон | rg `api/push` — 0; web-push-service.ts:56 | MEDIUM |
| A6-F11 | 3 | /api/admin/{outbox,metrics,causality,data-plane} — 0 потребителей (нет админ-UI вообще; kill-switch/audit-verify — token-API, допустимо для ops, но outbox-админка без воркера и без UI — мёртвый контур) | rg admin/* в components/stores — 0 | LOW |

**Что подтвердилось РАБОТАЮЩИМ (позитивный контроль, чтобы не очернять зря):**
- Настройки: recalc → /api/reputation/recalculate (settings-view.tsx:34); 2FA enable/confirm/disable (:287,307,326); люмены GET/topup/accrue (lumen-wallet.tsx:63,80,96); Decision Inbox → /api/me/autonomy + /api/ai/autonomy (decision-inbox.tsx:108,122); суверенитет PATCH (:86).
- Уведомления: GET + POST read + live-socket + 30с-фолбэк (app-shell.tsx:867–915) — wired.
- Лента: like/save/comment/respond/vote/unlock/composer — все вызывают API (trust-stream.tsx:454,467,479,784,990,1045; post-composer.tsx:84).
- Сообщества: join/leave DELETE+POST, пост в сообщество (community-view.tsx:47,50,63; communities-view аналогично).
- События: фильтры + RSVP + Pro-гейт честным тостом без API (events-view.tsx:79,92,118–129,418).
- Компании: follow POST, отзывы POST (company-view.tsx:80,448; companies-view.tsx:86); «Компании с открытыми вакансиями» на реальных счётчиках (interested-companies.tsx:33–46).
- AI-контуры: coach (5 эндпоинтов, bizon-coach-card.tsx:185–258), matchmaker (matchmaker-view.tsx:51; public-persona.tsx:951), career (career-agent-view.tsx:28), project-match (projects-feed.tsx:210).

---

## 3. ДЕТЕКТОР МЁРТВОГО КОДА: 12 проверенных экспортов src/lib/services (и смежных)

| Экспорт | Где | Импортёры вне себя | Вердикт |
|---|---|---|---|
| OutboxService (index.ts:109) | services/outbox-service.ts | только /api/admin/outbox | Мёртв E2E: нет продюсеров, нет воркера, нет UI |
| VCExportService (index.ts:110) | services/vc-export-service.ts | только /api/me/credentials → у которого 0 потребителей | **Мёртв E2E (сервис→API→∅)** |
| WebPushService (index.ts:111) | services/web-push-service.ts | только /api/push → 0 потребителей + sent:0 при ключах | **Мёртв E2E + fake-success** |
| estimateReputation :42 | trust/reputation-estimator.ts | только tests/wave3-* | Мёртв в проде (ядро считает по-старому) |
| HeuristicCareerMatcher :51, CareerMatcher :100 | ml/career-matcher.ts | только tests/wave5-* | Мёртв в проде (матчинг живёт в jobs-сервисах) |
| detectTextSync :44 | services/fraud-text-sync.ts | только tests/wave3-* | Мёртв: в пайплайн постов не встроен (D-09) |
| SemanticSearchService (index.ts:22) | services/semantic-search-service.ts | /api/search/semantic жив (semantic-search-bar) | жив |
| OpportunityRadar (index.ts:106) | services/opportunity-radar.ts | /api/opportunities/radar | жив |
| diversity-service | services/diversity-service.ts | feed-service, news-opportunity-bridge, skill-graph | жив (внутренний) |
| governance-service | ai-governance/ | /api/ai/autonomy + governance/index | жив |
| virtual-cashier + cashier-ports | services/ | store-service + 5 cashier-роутов + бейджи Store | жив |
| FabCreateDialogs (компонент) | shell/fab-create-dialogs.tsx | **0 импортов** | Мёртв (A6-F07) |

Итого из 12 выборочных: **5 мёртвых (из них 3 — целые волны W6-периферии «сервис→API→∅»), 6 живых, 1 dead-компонент.** Проверка «import хотя бы в одном компоненте/роуте» выполнена rg по всему src + tests (тестовый импорт в проде не считается).

---

## 4. SEED-ГИГИЕНА И ЖИВАЯ БД (детектор 5)

**scripts/seed.ts (267 строк):**
- Создаёт: **10 фейковых юзеров** (иван/мария/…, пароль `password` у всех, :85–105), 12 навыков, **5 проектов**, 6 вакансий, 3 рекламы, случайные связи (40% пар, :163–175), **30 случайных reputation-событий** (:191). **Постов seed не создаёт.**
- **Флага чистого демо НЕТ**: ни --clean, ни env-гейта. Наоборот — seed **разрушителен**: каскад `deleteMany()` по User/Job/Project/… (:64–76) снесёт живые данные при случайном запуске в проде.
- Заявленные «10 пользователей… для живой ленты» — де-факто витрина для демо, отдельного «чистого демо-режима» (пустой прод vs наполненное демо) в коде нет.

**Происхождение мусора «QA3 User A»:** не seed. Это QA/E2E-прогоны по живой БД: пользователи `wave1-alice@bizon.test` (tests/wave1-trust.test.ts:104), `Seller W2/Buyer W2/Escrow W2` (tests/wave2-store.test.ts:90–102) — имена в точности совпадают с «E2E Seller W2» из ленты. Тесты пишут в тот же db/custom.db без изоляции и без cleanup.

**Снимок живой БД (read-only, 19.09):** User=52 (в т.ч. «QA3 User A» ×2 — дубли из двух прогонов, QA3 User B–H, QA Test XFF, Alice/Bob/Carol E2E, «W2 Клиент Сотрудник»); Post=21, из них **4 SSRF-тест-поста** («Test post with link http://169.254.169.254/…», localhost, 10.0.0.5 — security-QA мусор с внутренними IP, виден в ленте); Project=16, из них 8 QA/E2E («QA Test Project», «QA Limit Test 1/2», «QA3 Spam Project 1–3», «W2 E2E Проект», «Agent7 E2E»).

**Вывод:** владелец, открывший ленту, увидит «QA3 User A · Test post with valid link http://example.com» и соседство с internal-IP-ссылками — **да, увидит**. `scripts/cleanup-demo-data.ts` (D-14) не существует (в scripts/ только cleanup-ssrf-posts.js, и тот не дочистил: SSRF-посты в БД). Тестовый гигиенический гейт отсутствует.

---

## 5. СВЕРКА KV2-ADDENDUM (D-01…D-18) С КОДОМ

| D | Статус в аддендуме | Факт R2 по коду |
|---|---|---|
| D-01 интро-кнопка на профиле | PENDING | **Подтверждён дефект** (A-2): POST /api/intros никто не зовёт, карточки пути нет |
| D-02 интро-инбокс | PENDING | **В коде УЖЕ ЕСТЬ** (intro-inbox.tsx, смонтирован network-view.tsx:90) — статус аддендума устарел; но без D-01 инбокс всегда пуст |
| D-03 UI жалоб | PENDING | **Подтверждён дефект** (A-1): fake-тост на месте, /api/complaints не потребляется |
| D-04 вакансия юрлица | PENDING | **В коде УЖЕ ЕСТЬ** (company-dashboard.tsx:108/210, page.tsx:113) — REFUTED как дефект; остаток A6-F08 (тупик из FAB/jobs-view) |
| D-05 VC-экспорт | PENDING | **Подтверждён дефект** (A-4): пункта в Настройках нет |
| D-06 честные ML-названия | PENDING | Подтверждён частично: «Career BERT v1» (ml/career-matcher.ts:3,44), «GNN-анти-фрауд v2» (fraud-text-sync.ts:1); trend-модель честно подписана «Prophet-lite/Holt» (trust/model-interfaces.ts:214–217) |
| D-07 внешний ground truth | PENDING | Дефект подтверждён (продолжает быть актуальным; tools/evals/ — только matchmaker-eval.ts, SARAFAN_RECOMMENDATION_EVAL отсутствует) |
| D-08 web-push честность | PENDING | **Подтверждён** (web-push-service.ts:56) |
| D-09 detectTextSync в пайплайн | PENDING | **Подтверждён** (0 импортёров в проде) |
| D-10 режимы contact/stranger | PENDING | **Подтверждён** (A-5) |
| D-11 /related в UI | PENDING | **Подтверждён** (0 потребителей /api/opportunities/related) |
| D-12 BIZCARD PDF | PENDING | **Подтверждён** (bizcard-dialog.tsx:3 — «через системную печать») |
| D-13 outbox продюсеры | PENDING | **Подтверждён** (0 продюсеров) |
| D-14 cleanup-demo-data | PENDING | **Подтверждён**: скрипта нет, мусор в БД растёт (§4) |
| D-15 демо-подсказка на входе | PENDING | **Подтверждён** (auth-screen.tsx:318) |
| D-16 копирайт по accountType | PENDING | **Подтверждён** (profile-view.tsx:191, гейта нет) |
| D-17 дедуп QA-двойников | PENDING | **Подтверждён** (QA3 User A ×2 в БД) |
| D-18 a11y DialogContent | PENDING | Подтверждён частично (выборочно: DialogContent без DialogDescription в dao-view, daily-brief и др.; полный подсчёт не делался) |

**Важно для процесса:** аддендум помечает ВСЕ пункты PENDING, но D-02 и D-04 в коде уже сделаны — статусы ведутся неаккуратно в обе стороны (часть DONE-претензий Плана-v2 была PARTIAL, часть PENDING уже DONE).

---

## 6. ТОП-НАХОДКИ ПО SEVERITY (калибровка cloudflare с продуктовой поправкой)

| ID | Что | Детектор | Severity | Почему |
|---|---|---|---|---|
| A6-F01 | AI Co-Pilot: UI-фикция вместо живого LLM-API | 4+3 | **HIGH** | Витринная AI-функция выдаёт эвристику за AI; готовый роут мёртв |
| A6-F02 | Нет дверей GDPR/удаления/экспорта аккаунта | 3 | **HIGH** | Регуляторное обещание (152-ФЗ/GDPR) без кнопок; бэкенд готов |
| A6-F12 | Жалоба — fake success (+fake «Сохранить» рядом) | 1 | **HIGH** | Модерационный цикл абуз-безопасности не работает для пользователя |
| A6-F13 | Интро-цикл: создание запроса недостижимо из UI → ядро W1 мёртво для пользователя | 3 | **HIGH** | Ключевой продукт-цикл «5 рукопожатий» обрывается на шаге 1 |
| A6-F14 | Тест-мусор в живой ленте + разрушительный seed без флага + отсутствие cleanup-скрипта | 5 | **HIGH** (продуктово) | Первое впечатление владельца/демо; SSRF-посты с internal-IP в ленте |
| A6-F15 | VC-экспорт «унести репутацию» без двери (цепочка мертва E2E) | 3 | MEDIUM-HIGH | W3C-обещание портируемости без UI |
| A6-F16 | Web-push: подписи нет в UI + sent:0 при ключах | 3+1 | MEDIUM | Пуш-канал недостижим с обеих сторон |
| A6-F17 | FAB-заглушка «Фаза 2» + мёртвый fab-create-dialogs (673 стр.) + тупик вакансий в jobs-view | 2+4 | MEDIUM | Двойные двери-призраки в главном потоке создания |
| A6-F18 | Lifecycle событий (publish/cancel/attendees) без UI | 3 | MEDIUM | Организатор не управляет событием |
| A6-F19 | Интент-сервис W5 (intent/intent-snapshot) без UI | 3 | MEDIUM | Ядро «intention-first» без двери |
| A6-F20 | Мелочь: GET на /update, /sovereignty/check мёртв, /api/hypotheses без UI, admin-контур без UI | 3 | LOW | Гигиена контрактов |

*(A6-F12…F14 = переименованные A-1/A-2/§4 в единую нумерацию; полная нумерация находок A6-F01…A6-F20 использована в §2/§4/§5.)*

---

## 7. COVERAGE-ЗАМЕТКА

- **Покрыто статически:** все 5 целей перепроверки аудита; выборочный новый обход — settings (все секции), notifications (dropdown+socket), companies (view/dashboard/stream-обёртки), communities (view+detail), events, feed (like/comment/save/respond/vote/unlock/composer), AI Co-Pilot, ai/coach/matchmaker/career; 12 экспортов сервисов; 15+ API-роутов на «нулевого потребителя»; seed.ts; живая БД (read-only).
- **Покрыто частично:** a11y-варнинги (выборочно); таблицы «ядро/двери» по всем ~300 роутам — полный перебор не делался (методика: пакетная rg-проверка префиксов + ручная верификация динамических шаблонов; найдено 11 роутов с нулём, ложно-положительные отсеяны встречными grep'ами).
- **Не покрыто (честно):** живой браузерный прогон (клик → сетевой запрос → скриншот) — поэтому «REFUTED» для D-04/A-3 означает «wired in code», а не «доказано поведение»; серверные side-эффекты роутов; сравнение контрактов query/RESPONSE-полей (риск расхождений типа /radar, найденного W5, вне скоупа A6).
- **Рекомендация следующему аудитору:** прогнать G-UI-PERFECT-обход по 5 подтверждённым циклам (жалоба, интро, вакансия, VC-экспорт, Co-Pilot) — это закроет разрыв «статика vs поведение» за одну сессию.

## 8. NEXT ACTIONS (для флота/исполнителя, вне мандата A6)

1. A6-F01: подключить ai-co-pilot.tsx к POST /api/ai-co-pilot с бейджем provider (час работы, максимальный продуктовый эффект).
2. A6-F02: секция «Мои данные» в Настройках: export-data / delete-account / forget-me (бэкенд готов).
3. A6-F13: карточка пути + «Запросить знакомство» на чужом профиле → POST /api/intros (D-01; инбокс уже жив).
4. A6-F14: scripts/cleanup-demo-data.ts (D-14/D-17) + env-гейт для seed (запрет deleteMany вне DEMO_MODE).
5. A6-F12: D-03 — диалог жалоб из COMPLAINT_CATEGORIES; убрать оба fake-тоста three-dots-menu.tsx:29,35.
