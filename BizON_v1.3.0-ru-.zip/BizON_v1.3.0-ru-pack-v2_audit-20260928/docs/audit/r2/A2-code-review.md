# R2-A2 — Code-Review аудит (методика pr-agent / Qodo)

- **Task ID:** R2-A2 · Аудитор: A2 (Explore, код не писал, прошлые отчёты не использовались — всё проверено по исходникам)
- **Дата:** 2026-09-19 · **Скоуп:** 8 критичных модулей, прочитаны целиком
- **Категории находок:** 1=«Может сломаться?» · 2=«Тесты?» · 3=«Security?» · 4=«Качество кода?» · 5=«Ошибка→что с пользователем?»
- **Severity-калибровка:** critical=RCE/полный доступ · high=полное поражение явного контроля · medium=ограниченное реальное нарушение · low=мелочь · informational=наблюдение

---

## 1. src/lib/services/auth-service.ts (180 строк)

**Вердикт: ЗДОРОВ** — ядро аутентификации надёжное (PBKDF2 600k, timingSafeEqual, soft-delete-гейты, PII не пишется plaintext); находки только low/informational.

**Ответы pr-agent:**
1. *Может сломаться:* повреждённый hash в БД роняет verifyPassword (F02); logout при сбое БД «тихо успешен» (F01).
2. *Тесты:* w1.test (register без plaintext email, soft-deleted логин 401/отказ), w5-auth (2FA/TOTP, replay tempToken). НЕ покрыто: параллельная регистрация одного email (P2002-путь), ветка rehash 100k→600k, неуспешный deleteMany в logout.
3. *Security:* права до операции — не требуется (owner-scope сервисов нет); email-поиск только по HMAC-hash; сообщение регистрации раскрывает существование email (F03).
4. *Качество:* парсинг формата hash без валидации (F04); `.catch(() => {})` на session-удалениях.
5. *Ошибка→пользователь:* login даёт честный generic «Неверный email или пароль»; исключение — F01/F02.

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|-----|-----|---------|--------------------------|
| A2-F01 | 5/4 | low | auth-service.ts:133 | `await db.session.deleteMany({ where: { userId } }).catch(() => {});` | Ошибка логаута глотается → роут вернёт успех, сессии останутся живыми (fake success). Перепроверка: уронить БД перед logout → HTTP 200, сессия в таблице Session жива. |
| A2-F02 | 1 | low | auth-service.ts:157 | `const salt = Uint8Array.from(parts[2].match(/.{2}/g)!.map(...))` | Non-null assertion: повреждённый `passwordHash` (`pbkdf2$600000$$xx`) → TypeError → 500 вместо «неверный пароль». Перепроверка: записать такой hash тест-юзеру, вызвать login. |
| A2-F03 | 3 | informational | auth-service.ts:32 | `throw new Error('Пользователь с таким email уже существует');` | Email enumeration через register, при том что login — generic. Перепроверка: два POST /api/auth/register с одним email → второй подтверждает существование. |
| A2-F04 | 4 | informational | auth-service.ts:85–86 | `const storedIterations = Number(user.passwordHash.split('$')[1]);` | `Number(undefined)=NaN` → `NaN < 600000` false → rehash тихо пропущен для чужого формата hash; парсинг без валидации. Перепроверка: hash без поля итераций → rehash не срабатывает, ошибок нет. |

---

## 2. src/lib/services/lumen-service.ts (625 строк)

**Вердикт: ЗДОРОВ С ОГОВОРКАМИ** — FIX-06 (guard-декремент + ledger в одной $transaction, CAS-дивиденды, идемпотентный refund по `refundOf @unique`) реализован образцово в spend/spendVar/debit/refund(с txId)/refundVar; 2 medium-дыры вне этого контура.

**Ответы pr-agent:**
1. *Может сломаться:* topup не атомарен — «баланс без ledger» при краше (F05, нарушает собственный инвариант из шапки файла); demo-дивиденды фармятся повторными вызовами (F06); легаси-refund неидемпотентен (F07).
2. *Тесты:* w1.test (spend уменьшает баланс, insufficient, refund идемпотентен), wave2-store (spendVar/refundVar, чужая транзакция, нецелая цена). НЕ покрыто: CAS-гонка дивидендов под параллельностью, повторный accrueDemoMonth, краш-окно topup, отрицательные/нулевые суммы в topup (валидация whitelist'ом — покрыто косвенно схемой zod).
3. *Security:* refundVar/refund проверяют `original.userId !== userId` — чужой refund невозможен; spend/refundVar валидируют `Number.isInteger(cost) && cost >= 1` — отрицательные суммы исключены; debit/credit бросают на невалидной сумме.
4. *Качество:* catch-all в accrueInternal (F08) — fail-closed, задокументирован; магических чисел почти нет (DAY_MS, ACCRUE_MAX_ATTEMPTS именованы).
5. *Ошибка→пользователь:* структурированный `SpendResult` с need/have; 402 на недостаток средств в роуте — честно.

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|-----|-----|---------|--------------------------|
| A2-F05 | 1 | **medium** | lumen-service.ts:268–286 | `const user = await db.user.update({...increment: amount...}); ... await db.lumenTransaction.create({ data: { type: 'topup', ...` | topup: increment баланса и запись ledger — два независимых вызова БД без $transaction. Краш между → люмены начислены, ledger-записи нет (нарушение I4; в шапке файла: «баланс без ledger невозможен»). Перепроверка: kill процесса между update и create; сверить `sum(LumenTransaction.lumens)` с `User.lumenBalance`. |
| A2-F06 | 1 | **medium** | lumen-service.ts:295–313 + src/app/api/lumens/accrue/route.ts:19 | `const result = await accrueInternal(userId, 30);` / `checkUserRateLimit(user.id, 'lumens:accrue', 10, 60_000)` | Демо-ускорение «+30 дней дивидендов» не ограничено суммарно: каждый вызов ≈ +1.23% базы (15%·30/365), rate-limit 10/мин лишь замедляет → до ~12% базы в минуту, бесконечно (люмены — валюта эскроу Store). Перепроверка: 11 POST /api/lumens/accrue подряд с базой 1000 ₽ → суммарный credited >> ожидаемых 12 люменов за 30 дней. |
| A2-F07 | 1/4 | low | lumen-service.ts:475–492 | `// Легаси-путь (вызовы без transactionId): increment + ledger одной транзакцией` | Легаси-refund без spendTransactionId — слепой increment без связи `refundOf`: повторный вызов (retry/двойной catch) возвращает люмены повторно. Перепроверка: два вызова `LumenService.refund(uid, action, reason)` → баланс вырос дважды; `rg "LumenService.refund\("` — найти живых вызывателей без 4-го аргумента. |
| A2-F08 | 4/5 | informational | lumen-service.ts:177–184 | `catch (e) { console.error('[lumen-service] accrueInternal transaction failed:', e); return { credited: 0, ... }` | Ошибка начисления полностью прозрачна для пользователя (кошелёк просто не показывает accrual) — направление безопасное (без двойного кредита), но нет метрики/алерта. Перепроверка: код-ревью ветки catch; убедиться, что ответ кошелька не ломается. |

---

## 3. src/lib/services/store-service.ts (670 строк)

**Вердикт: ЗДОРОВ С ОГОВОРКАМИ** — лучший модуль скоупа: двойной release исключён (status-guard + `releaseTxId @unique` + rollback credit в одной $transaction, покрыт тестом), слоты не перепродаются (guard-инкремент + возврат проигравшему), refund идемпотентен. Две medium-дыры — краш-окно и отсутствие таймаутов эскроу.

**Ответы pr-agent:**
1. *Может сломаться:* краш после spendVar до записи spendTxId → sweep гасит букинг БЕЗ возврата (F09); fulfilled без таймаута — люмены заморожены бессрочно (F10); backlog >100 возвратов голодает (F11).
2. *Тесты:* wave2-store (полный цикл held→fulfilled→released, идемпотентность release 409+без второго зачисления, гонка слотов 409+полный возврат, decline-возврат, цена при открытых сделках, sweep), wave2-adversarial (эскроу не отдаёт деньги без подтверждения покупателя, trust-изоляция). НЕ покрыто: краш-окно «списано, spendTxId не записан», stale-fulfilled, параллельный (а не последовательный) двойной release.
3. *Security:* owner-гейты на каждой мутации (`booking.sellerId !== sellerId` / `booking.buyerId !== buyerId` → 404), self-purchase заблокирован (400), premium-гейт по тарифу (403), governance SPEND_MONEY manual-only, цена — серверный snapshot в booking.
4. *Качество:* updateItem молча режет title/description вместо 400 (F12, в противоречии с createItem); комментарий «Слот expert-access освобождается» при декременте для всех типов (F13); снапшот цены читается вне транзакции (гонка с updateItem benign — покупатель платит увиденную цену).
5. *Ошибка→пользователь:* честные 402/409/404 с конкретикой («нужно N, доступно M»); уведомления обеим сторонам; AuditLog на каждый шаг.

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|-----|-----|---------|--------------------------|
| A2-F09 | 1 | **medium** | store-service.ts:299–330 + 645–652 | booking.create(held) → `spendVar` (деньги списаны) → … → `updateMany({ data: { spendTxId } })`; sweep: `where: { status: 'held', spendTxId: null, createdAt: { lt: ttlAgo } }, data: { status: 'cancelled' }` | Краш между spendVar и записью spendTxId: деньги списаны (ledger `escrow:true` с meta.bookingId), букинг held без spendTxId → через 15 мин sweepStale(a) ставит cancelled БЕЗ возврата (refundVar требует spendTxId; по bookingId ledger никто не ищет) → люмены покупателя застревают навсегда. Перепроверка: создать booking, исполнить spendVar, не писать spendTxId, вызвать sweepStale после TTL → status=cancelled, баланс покупателя не восстановлен. |
| A2-F10 | 1 | **medium** | store-service.ts:345–390 (fulfil) + 645+ (sweepStale — нет ветки) | `if (booking.status !== 'held') throw ...` (fulfil), после fulfilled — только ручной release покупателя | Эскроу без таймаутов: продавец отметил исполнение, покупатель молчит → люмены заморожены бессрочно; нет auto-release/auto-refund/dispute/арбитража; sweepStale обрабатывает только held-без-оплаты и closed-без-refund. Перепроверка: fulfilled-букинг недельной давности → sweepStale/myBookings ничего не меняют; средства недоступны обеим сторонам. |
| A2-F11 | 1 | low | store-service.ts:655–662 | `findMany({ where: {...}, take: 100, orderBy: { updatedAt: 'desc' } })` | Sweep возвратов берёт 100 свежих по updatedAt: при backlog >100 старейшие недозакрытые refund'ы не обрабатываются, пока очередь не разгребена. Перепроверка: 150 closed-букингов без refund → после sweep 50 остаются без возврата. |
| A2-F12 | 4 | low | store-service.ts:247–249 | `title: patch.title.trim().slice(0, TITLE_MAX)` | updateItem молча обрезает title/description, createItem на то же — 400. Неконсистентный контракт ввода. Перепроверка: PATCH с title 150 симв. → 200 с обрезанным title, POST с тем же → 400. |
| A2-F13 | 4 | informational | store-service.ts:516–521, 561–566 | `// Слот expert-access освобождается … slotsBooked: { decrement: 1 }` | Декремент слотов выполняется для ЛЮБОГО типа товара (не только expert-access); для services/digital с квотой поведение совпадает — комментарий вводит в заблуждение. Перепроверка: код-ревью decline/cancel; негативных эффектов нет. |

---

## 4. src/lib/services/payment-service.ts (405 строк)

**Вердикт: ЗДОРОВ С ОГОВОРКАМИ** — архитектурно честный модуль (ExternalGatewayAdapter возвращает структурный `unavailable`, никогда не имитирует успех; цена только из серверного PLANS), **но это единственный модуль скоупа с нулевым тест-щитом**.

**Ответы pr-agent:**
1. *Может сломаться:* createPayment и applyTier не в одной транзакции (F15) — краш между → «оплаченная» Subscription без применения тарифа.
2. *Тесты:* **НЕ покрыто ничего** (F14) — ни DemoGateway, ни verify, ни unsubscribe, ни applyTier; `rg "PaymentService" tests/` — пусто.
3. *Security:* сумма берётся из PLANS на сервере (клиентский amount не trusted); verify не проверяет владельца paymentId (F17, потенциальная утечка tier/activeUntil, если роут отдаст наружу без owner-гейта).
4. *Качество:* unsubscribe глотает ошибку журнала (F16); TODO-каркас вынесен в явный класс-адаптер (это плюс, не минус).
5. *Ошибка→пользователь:* честные explanation-строки во всех intent/verification; unknown webhook provider → `ok:false`; NOT_CONFIGURED без fake success.

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|-----|-----|---------|--------------------------|
| A2-F14 | 2 | **medium** | tests/ (отсутствие) | `rg -n "PaymentService\|DemoGateway\|ExternalGateway" tests/` → 0 совпадений | Монетизационное ядро (подписки 25% дохода по ТЗ) не имеет ни одного теста: subscribe/unsubscribe/verify/applyTier/DemoGateway — вне тест-щита. Перепроверка: `rg "PaymentService" tests/` — пусто; в wave-тестах подписки не фигурируют. |
| A2-F15 | 1 | low | payment-service.ts:156–167 + 311–314 | `db.subscription.create(...)` затем `if (intent.status === 'succeeded') user = await applyTier(userId, tier, period);` | Demo-платёж: запись Subscription и применение тарифа к User — два независимых вызова без $transaction; краш между → платёж «успешен», тариф не применён (demo-деньги, но журнал перестаёт быть истиной). Перепроверка: throw в applyTier → Subscription status=active при subscriptionTier=free. |
| A2-F16 | 4/5 | low | payment-service.ts:383–388 | `.catch(() => undefined); // журнал не блокирует отмену тарифа` | Ошибка гашения manual-подписок глотается: Subscription останется active при отменённом тарифе — рассинхрон журнала молча. Перепроверка: сломать updateMany → DELETE /api/subscriptions → 200, запись всё ещё active. |
| A2-F17 | 3 | informational | payment-service.ts:321–326 | `async verifyPayment(paymentId, gatewayName) { return resolveGateway(gatewayName).verify(paymentId); }` | verify не проверяет ownership paymentId; на текущих роутах наружу не выставлен (IDOR-риск только при будущей проводке без owner-гейта). Перепроверка: grep роутов на verifyPayment; при появлении роута — требовать `sub.userId === ctx.user.id`. |

---

## 5. src/lib/services/intro-service.ts (260 строк)

**Вердикт: ЗДОРОВ** — главный инвариант «сообщение цели уходит ТОЛЬКО после accept посредника» соблюдён; guard до дорогого findMatch; TTL + expireSweep; честные 400/404/409/410/429. Минусы — check-then-act гонки без unique-констрейнтов.

**Ответы pr-agent:**
1. *Может сломаться:* два параллельных accept → дважды сообщение цели + два reputationEvent (F18); гонка duplicate-pending → два активных запроса (F19).
2. *Тесты:* wave1-trust (self-intro 400), wave1-adversarial (guard-скоринг, кольца). НЕ покрыто: expireSweep, decline, параллельный accept, 410 на просрочке.
3. *Security:* ownership `intro.introducerId !== introducerId → 404` (IDOR закрыт); сообщение режется до 2000 симв; цель не узнаёт запросчика до accept.
4. *Качество:* expireSweep пишет AuditLog с resourceId 'sweep' (условная конвенция); дублируется `userName()`-хелпер с store-service (мелочь).
5. *Ошибка→пользователь:* каждый отказ — конкретный код и текст; decline объясняет что текст не ушёл.

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|-----|-----|---------|--------------------------|
| A2-F18 | 1 | low | intro-service.ts:153–176, 198–206 | `if (intro.status !== 'pending') throw ...; await db.introductionRequest.update({ where: { id: introId }, ...})` | Статус-чек и update не атомарны (в where нет `status: 'pending'`): параллельные accept → message.create дважды + два `reputationEvent intro_accepted` (+2 веса репутации). Перепроверка: `Promise.all([accept(id,u), accept(id,u)])` → в Conversation два одинаковых сообщения, ReputationEvent ×2. |
| A2-F19 | 1 | low | intro-service.ts:65–69 | `const duplicate = await db.introductionRequest.findFirst({ where: { requesterId, targetId, status: 'pending', ...` | Duplicate-чек и create не атомарны, в схеме нет unique-констрейнта на активный pending пары → два pending при гонке (обход «один активный pending» из шапки). Перепроверка: два параллельных create → 2 записи pending. |
| A2-F20 | 1 | informational | intro-service.ts:217–226 | decline: `if (intro.status !== 'pending') throw` — проверка expiresAt отсутствует | Просроченный pending закрывается как `declined` (accept в этой же ситуации даёт `expired` + 410) — статусная асимметрия, искажает фичевый лог INTRO_ACCEPT_PREDICTION. Перепроверка: создать intro, вручную проставить expiresAt в прошлом, decline → status=declined. |

---

## 6. src/lib/services/sarafan-guard.ts (137 строк)

**Вердикт: ЗДОРОВ** — простой скоринговый гвард, порог синхронизирован с SEC-1 (AUTO_FREEZE_THRESHOLD=70), fail-open задокументирован как принцип; для анти-абьюз-фильтра уровня «наблюдение→решение» — корректно.

**Ответы pr-agent:**
1. *Может сломаться:* только деградация БД → guard молча превращается в allow (F21) — направление осознанное (не блокировать легитимных).
2. *Тесты:* wave1-adversarial (кольца рекомендаций found/not-found, скоринг block/observe), wave1-trust. НЕ покрыто: граница порога ровно на 70, reciprocal-детектор (пары A↔B).
3. *Security:* гвард не авторизует, а скорит; решение block → AuditLog; авто-заморозка вынесена в anti-fraud.applyAutoTakedown (не дублируется).
4. *Качество:* DFS с лимитом циклов (≥5 — стоп) и глубины; магические веса (+40/+25) соответствуют SEC-1 — согласованность документирована в шапке.
5. *Ошибка→пользователь:* block даёт 429 «Запросы временно ограничены» без раскрытия скоринга — корректно (не палит детекторы).

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|----|-----|---------|--------------------------|
| A2-F21 | 3 | informational | sarafan-guard.ts:87–91 | `catch (e) { ... return { allowed: true, riskScore: 0, ... }` | FAIL-OPEN: любая ошибка БД отключает анти-абьюз (задокументировано «SEC-1»); злоумышленник, способный вызвать деградацию БД, снимает гвард. Перепроверка: уронить db перед evaluateIntroRequest → allowed:true. |
| A2-F22 | 4 | informational | sarafan-guard.ts:105–108 | `const edges = await db.recommendation.findMany({ where: { status: 'active' } })` | Полная загрузка всех активных рекомендаций в память на каждый вызов — O(N) без лимита; при росте графа — деградация (и при ошибке — fail-open). Перепроверка: замер времени/памяти на 100k рекомендаций. |

---

## 7. src/lib/ai-governance/governance-service.ts (641 строка)

**Вердикт: ЗДОРОВ С ОГОВОРКАМИ** — контроль сильный: secure-by-default полномочия, 2-of-N с разными подтверждающими (покрыт adversarial-тестами 9/9), права проверяются РАНЬШЕ состояния (VC-1 фикс), anti-creeping, kill-switch вне AI-контура, Decision Inbox не executor (§38 соблюдён). Оговорка — audit-запись fail-open (F23) и мелкие гонки.

**Ответы pr-agent:**
1. *Может сломаться:* lost-update на approvalsJson при параллельных вторых голосах (F24, безопасность не обходится — теряется голос/статус pending); P2002 на идемпотентном propose под гонкой → 500 (F25); бюджет превышается под параллельностью (F26).
2. *Тесты:* wave6-governance (2-of-N, подписи политик, user-prohibitions, hash-chain, HOP+тиры), wave6-adversarial (A1–A9: secure-by-default, двойное одобрение одним, idempotent guard, tamper-evidence, anti-creeping, prohibition>authority, kill-switch, подмена подписи, TTL). НЕ покрыто: параллельные голоса, canSpend/recordSpend (бюджет), P2002-гонка propose.
3. *Security:* критический апрув требует 2 разных пользователей (проверка `prior.some(a.by === userId)`); rejection любым участником = сторонний DoS апрувов — документированный MVP-компромисс (F27); setAutonomyLevel затирает выданный actionAccess дефолтным списком (F27).
4. *Качество:* в audit передаётся `agentKey: agent.id` (имя поля ложно, пишется id) — мелкая несогласованность; `void updated;` (мёртвая переменная, L334); catch-all в audit() — F23.
5. *Ошибка→пользователь:* честные коды NOT_FOUND/FORBIDDEN/ALREADY_DECIDED/EXPIRED/POLICY_BLOCKED с маппингом в 404/403/409/500; PATCH-роут отдаёт честное «действие не исполнено — executor отдельный контур».

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|-----|-----|---------|--------------------------|
| A2-F23 | 4/5 | **medium** | governance-service.ts:490–508 | `await db.aiAuditLog.create({...}).catch((e) => console.error('[AiAuditLog] write failed:', e));` | Запись audit-следа fail-open: при сбое БД решение по critical-действию фиксируется (approval+action обновлены), а audit-событие молча теряется — для governance-контура с требованием tamper-evidence это реальный зазор (контроль без следа). Перепроверка: временно сломать aiAuditLog (например, переименовать таблицу в тесте) → decideAction вернёт ok:true, записей в журнале нет. |
| A2-F24 | 1 | low | governance-service.ts:293–309 | `const prior = JSON.parse(approval.approvalsJson \|\| '[]'); const approvals = [...prior, { by: input.userId, ...}]; await db.aiApproval.update({ ... approvalsJson: JSON.stringify(approvals) ...` | Read-append-write без транзакции/версии: два параллельных вторых голоса → lost update (один голос пропадает, статус остаётся pending). Обхода 2-of-N нет (запись `[A,B]` или `[A,C]` в любом случае даёт length≥2 → approved), риск — недосчитанные голоса/аудит. Перепроверка: prior=1 голос, два параллельных approve разными юзерами → approvalsJson length 1. |
| A2-F25 | 1 | low | governance-service.ts:69–82, 159–169 | `db.aiAction.create({ data: { idempotencyKey: input.idempotencyKey, ...` | Два параллельных propose с одним idempotencyKey: оба проходят findUnique → второй ловит необработанный P2002 → 500 (вместо идемпотентного повторного ответа). Перепроверка: Promise.all два propose с одним ключом → один 500 (withRoute замапит P2002→409, если путь через него — прямой вызов сервиса даёт исключение). |
| A2-F26 | 1 | low | governance-service.ts:411–435 | `return { allowed: spent + input.units <= limit, ... }` … `update: { spentUnits: { increment: input.units } }` | canSpend/recordSpend — классический TOCTOU: между проверкой и инкрементом параллельные траты проходят ту же проверку → дневной бюджет превышается (второй предохранитель перед платным AI ослаблен). Перепроверка: 2 параллельных canSpend+recordSpend при остатке 1 юнит → spent=limit+1. |
| A2-F27 | 3 | informational | governance-service.ts:593–596, 625–628; 268–291 | `permissions: JSON.stringify(['SEARCH_JOBS', ...])` (жёсткий список) / rejection любым участником | (а) setAutonomyLevel/setAutonomy молча сбрасывают actionAccess к дефолтным 5 действиям, затирая ранее выданные полномочия (направление least-privilege, но неожиданное затирание); (б) любой аутентифицированный юзер может rejected-ить чужие pending critical-действия (документированный MVP) → сторонний DoS апрувов. Перепроверка: выдать кастомный actionAccess → сдвинуть IL-слайдер → actionAccess = дефолт. |

---

## 8. src/lib/services/jobs-*.ts → job-filters-service.ts (170) + job-growth-service.ts (150)

**Вердикт: ЗДОРОВ** — read-only сервисы без денежного контура; facet-агрегации честные (groupBy по БД, не захардкожены), ответ всегда валиден (200 с непустым контрактом). Мелочи: fake-success в logView, кламп уровней.

**Ответы pr-agent:**
1. *Может сломаться:* logView возвращает counted:true даже при провале записи (F28); уровень «Навык:99» делает требование вечным гэпом (F29); `filters.salaryMin` через falsy-чек (0 = «не задано» — семантически ок).
2. *Тесты:* wave5-opportunities/adversarial (skill-gaps, facets — файлы ссылаются на сервисы). НЕ покрыто: viewCalendar (расхождение count/jobIds), logView идемпотентность под гонкой.
3. *Security:* сервисы принимают userId от роута (owner-scope); JSON-флаги строятся только из whitelist FLAG_KEYS (нет инъекции в contains); q-фильтр — `contains` без экранирования LIKE-символов (SQLite, только качество выдачи).
4. *Качество:* магических чисел нет (лимиты именованы/константы), any-кастов нет (кроме осознанных `as unknown as` для groupBy-типизации Prisma).
5. *Ошибка→пользователь:* JobGrowth всегда 200 с валидным контрактом — задокументировано в шапке (безопасный рендер фронтенда); logView — единственный fake-success (F28).

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|-----|-----|---------|--------------------------|
| A2-F28 | 5 | low | job-filters-service.ts:160–169 | `await db.jobViewLog.create({...}).catch(() => ({ id: '' })); return { counted: true };` | Ошибка записи просмотра глотается → API отвечает `counted:true` при несохранённой записи (fake success). Перепроверка: вызвать logView при сломанной таблице → counted:true, записи нет. |
| A2-F29 | 4 | informational | job-growth-service.ts:50–53 | `const m = s.match(/^(.+?):\s*(\d{1,2})$/u); if (m) return { name: m[1].trim(), level: Number(m[2]) };` | Уровень не клампится к шкале 1..10 (допустимо 0/11..99): «Навык:99» → вечный недостижимый гэп в readiness/gives. Перепроверка: requiredSkills «Go:99» → ok:false при любом уровне. |
| A2-F30 | 4 | informational | job-filters-service.ts:136–157 | `count: r._count._all` (полный) против `take: 500` для jobIds | viewCalendar: count за день — полный, а список jobIds обрезан 500 → число и состав списка расходятся на активных аккаунтах; LIKE-паттерны `contains` без экранирования `%`/`_` в q/location/industry. Перепроверка: 600 просмотров в день → count=600, jobIds.length=500. |

---

## 9. Кросс-модульная находка

| ID | Кат. | Sev | Где | Сниппет | Суть / как перепроверить |
|----|------|-----|-----|---------|--------------------------|
| A2-F31 | 1/2 | **medium** | src/lib/data-vault/audit-log.ts:18–42 (потребители: store/lumen/auth/intro/governance) | `private buffer: AuditEntry[] = []; ... setInterval(() => this.flush(), 5000); log(entry) { this.buffer.push(entry); if (this.buffer.length >= 100) this.flush(); }` | Все финансовые/security-события (STORE_BOOKING_RELEASED, STORE_BOOKING_DECLINED, INTRO_GUARD_BLOCKED…) идут в **волатильный буфер в памяти** с flush каждые 5с: краш/рестарт процесса теряет до ~5с (≤99 записей) audit-следа денег — при этом hash-chain (S-134) доказуем только для долетевших записей. Перепроверка: вызвать logSecurity N<100 раз, kill -9 процесса, перезапустить → в таблице AuditLog записей нет. |

---

## Что сделано хорошо (5 пунктов)

1. **Паттерн FIX-06 последователен и протестирован:** guard-декремент (`lumenBalance >= cost` в where) + ledger-запись в одной `$transaction` — в spend/spendVar/debit; идемпотентный refund через `LumenTransaction.refundOf @unique` с обработкой P2002-гонки; баланс < 0 недостижим by design (где-где, а это — образцово).
2. **Двойной release эскроу закрыт тройным барьером** (status-guard `updateMany` + `releaseTxId @unique` + rollback зачисления в той же транзакции) **и подтверждён тестом**: повтор → 409, баланс продавца без второго зачисления (wave2-store.test:198–205).
3. **Честные ошибки вместо fake-success:** структурированные коды (insufficient с need/have, ALREADY_DECIDED, EXPIRED, NOT_CONFIGURED_IN_SANDBOX, CASHIER_REAL_NOT_ENABLED с перечнем условий); ExternalGatewayAdapter и realMoneyGate никогда не имитируют успех; комиссия >0 без счёта платформы → fail-secure откат всей транзакции release.
4. **Права проверяются ДО операции и до раскрытия состояния:** owner-гейты на всех мутациях букинга (fulfil=seller, release/cancel=buyer, decline=seller), `refundVar` отвергает чужую транзакцию, self-purchase заблокирован, governance `decideAction` проверяет полномочия раньше ALREADY_DECIDED (посторонний не узнаёт состояние действия).
5. **Governance-контур зрел:** 2-of-N с разными подтверждающими покрыт adversarial-набором (9/9), secure-by-default (без authority — только read/low), anti-creeping (агент не повышает уровень), kill-switch env+policy вне AI-контура, Decision Inbox не исполняет действия (§38), KYC-гейт реальных денег требует решения владельца, а не env-переменных.

## Coverage-заметка (что покрыто / что нет)

- **Покрыто:** 8/8 модулей скоупа прочитаны целиком (2918 строк ядра + 320 строк jobs + зависимые virtual-cashier-service.ts 297, with-route.ts, api-helpers, data-vault/audit-log.ts); выборочно проверены потребляющие API-роуты (store, lumens×2, intros/accept, ai/decisions/[id], subscriptions) — auth/401/rate-limit/zod на месте.
- **Тест-щит:** сверен через rg-реестр (14 тест-файлов, имена кейсов); подтверждено покрытие store-эскроу (13 кейсов), governance (18 кейсов W6), lumen spend/refund (W1+W2), auth (W1+W5), guard (W1).
- **НЕ покрыто этим аудитом (честные deferred):** конкурентные сценарии проверены статическим чтением кода, гонки не воспроизводились в рантайме (F18/F19/F24/F25/F26 — выводы о lost-update нужно подтвердить верификатору исполнением); полный обход всех API-роутов — скоуп A4 (dataflow/IDOR); prisma/schema.prisma (констрейнты unique на IntroductionRequest/StoreBooking) не сверялся построчно; UI-проводка — скоуп A6.

---

## Сводка по severity

| Severity | Кол-во | ID |
|----------|--------|----|
| critical | 0 | — |
| high | 0 | — |
| **medium** | **7** | A2-F05, A2-F06, A2-F09, A2-F10, A2-F14, A2-F23, A2-F31 |
| low | 13 | A2-F01, A2-F02, A2-F07, A2-F11, A2-F12, A2-F15, A2-F16, A2-F18, A2-F19, A2-F24, A2-F25, A2-F26, A2-F28 |
| informational | 11 | A2-F03, A2-F04, A2-F08, A2-F13, A2-F17, A2-F20, A2-F21, A2-F22, A2-F27, A2-F29, A2-F30 |

**Топ-5 (одной строкой):**
1. **A2-F09** — краш-окно в requestBooking: люмены списаны, spendTxId не записан → sweep гасит букинг БЕЗ возврата (застрявшие деньги, нет пути восстановления по bookingId).
2. **A2-F10** — эскроу без таймаутов: fulfilled-сделка навсегда замораживает люмены (нет auto-release/auto-refund/dispute).
3. **A2-F05** — topup не в $transaction: краш между increment баланса и ledger даёт «баланс без ledger» (нарушение собственного инварианта FIX-06/I4).
4. **A2-F06** — /api/lumens/accrue: ферма дивидендов (каждый вызов +1.23% базы, rate-limit 10/мин не ограничивает суммарно) при том, что люмены — валюта эскроу Store.
5. **A2-F14 + A2-F31** — PaymentService (монетизационное ядро) без единого теста; audit-след финансовых операций — волатильный буфер памяти (потеря до ~5с при краше, governance-audit к тому же fail-open — A2-F23).
