# SPECKIT PROTOCOL — как я исполняю команды GitHub Spec Kit в BizON

Источник: github/spec-kit README (branch main, загружен 17-09). Spec Kit = spec-driven development:
«Define what and why before deciding how» + техплан + задачи + исполнение до конвергенции.

Статус: команды НЕ установлены как файлы (.claude/commands, .specify отсутствуют) — принимаю их как
СЛОВЕСНЫЙ ПРОТОКОЛ владельца. Нотация `speckit.x` и `speckit-x` — синонимы. Каждая команда = директива
исполнить соответствующую фазу по семантике Spec Kit, совмещённой с docs/AGENT-WORKFLOW.md.

## Пайплайн SDD: specify → clarify → plan → tasks → implement (→ converge)

| Команда | Семантика Spec Kit | Что делаю я в BizON | Артефакт |
|---|---|---|---|
| `/speckit.specify` | Спецификация ЧТО и ЗАЧЕМ: user stories, требования, критерии приёмки | Фаза UNDERSTAND+PLAN: пишу spec (US-1..N, acceptance criteria, out-of-scope). Проверяю по идеологии BizON (real data, без публичных рейтингов/XP, Evidence Graph, Professional Passport) и по домену GAP-MATRIX | spec |
| `/speckit.clarify` | Снять двусмысленности ДО планирования | Один пакет точечных вопросов владельцу; ответы фиксирую в docs/DECISIONS.md. Блокирующие вопросы — стоп, не выдумываю ответы сам | вопросы + DECISIONS.md |
| `/speckit.plan` | Технический план КАК: стек, архитектура, границы | План с точными файлами по полной вертикали UI→API→service→DB→Prisma→validation→permissions; учитываю ограничения среды: Next.js 16 App Router, Prisma+SQLite, shadcn/ui, withRoute, AiTrace-спаны, без next build | plan |
| `/speckit.tasks` | Декомпозиция плана на исполнимые задачи | Задачи 2–5 минут каждая (Superpowers writing-plans): точные пути файлов, полный критерий проверки, Task ID, зависимости и параллельность | tasks |
| `/speckit.implement` | Исполнить задачи | Для КАЖДОЙ задачи: IMPLEMENT→TEST→REVIEW (2 прохода: спека, потом качество)→VERIFY (живая проверка браузер/curl/БД)→EVIDENCE. Гейты после каждой задачи (tsc/lint/tests; для AI-фич — eval-suite). Worklog. DONE только после живой верификации | worklog + evidence |

## Сопутствующие команды (тоже принимаю)

- `/speckit.constitution` — принципы проекта. Аналог УЖЕ существует: идеология BizON + docs/AGENT-WORKFLOW.md. Новую конституцию не пишу; добавки — только через согласование с владельцем.
- `/speckit.converge` — проверка конвергенции spec↔реализация; цикл implement→converge до «Converged». У нас = VERIFY→EVIDENCE + сверка acceptance criteria из spec со сделанным; отчёт «Converged / Diverged: список».
- `/speckit.checklist`, `/speckit.analyze` — дополнительные quality gates: чек-листы и анализ согласованности spec↔plan↔tasks; запускаю по запросу.
- Bug-тройка `/speckit.bug-assess → bug-fix → bug-test` — наш формат SWE-agent (AGENT-WORKFLOW §7): ROOT CAUSE до фикса + regression-тест + живая верификация.

## Инварианты при исполнении speckit-команд

1. Артефакты (spec/plan/tasks) кладу в `specs/<feature-slug>/` в репозитории — переживают сессии.
2. Никогда не пропускаю clarify при блокирующих двусмысленностях — вопросы владельцу, не догадки.
3. tasks = 2–5 минут каждая с путями и проверкой (без «сделать фронт», «сделать бэк»).
4. implement идёт по полной вертикали на каждую задачу; только UI ≠ реализовано.
5. Все инварианты AGENT-WORKFLOW.md действуют в полном объёме (гейты, evidence, запрет частичного DONE).
