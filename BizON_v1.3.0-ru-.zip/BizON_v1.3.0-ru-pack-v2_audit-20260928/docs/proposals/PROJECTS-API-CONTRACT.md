# API-контракт ТЗ-ПР-4.9 «Модуль Проекты» — источник истины для имплементации

**Статус:** ядро уже внедрено (см. §0). Этот документ — обязательный контракт для всех новых роутов.
**Правила инфраструктуры (не нарушать):**
- Каждый mutation-роут: паттерн `async function __bizon_impl_X(req: Request, ctx: { params: { id: string } })` + `export const X = withRoute<{id:string}>(__bizon_impl_X, { rateLimit: { key: 'api:...:METHOD', limit: 60, windowMs: 60_000 } })`.
- GET-роуты могут быть руками (`export async function GET(req: NextRequest)`), как в `src/app/api/projects/route.ts`.
- Импорты: `import { db } from '@/lib/db'; import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';` (+ `withRoute` для mutations). `export const runtime = 'nodejs';`
- Поля Date в ответах — `.toISOString()`.
- SQLite: `mode: 'insensitive'` НЕ поддерживается — использовать `contains` без mode.
- Уведомления: `NotificationService.notify(userId, { type: 'application'|'confirmation'|'message', title, body?, link?, metadata? })` из `@/lib/services`. Не ломать.
- PII (телефон/email участников): выдавать только авторизованным (`getUserFromRequest` → null = скрывать поля `phone`/`email`).
- Тексты ответов/ошибок — на русском.
- НЕ трогать существующие файлы: `src/app/api/projects/route.ts`, `src/app/api/projects/[id]/route.ts`, `[id]/transition`, `[id]/leave`, `[id]/view`, `[id]/evidence`, `[id]/confirmation*`, `[id]/related-jobs`.

## §0 Уже внедрено (НЕ трогать, использовать)

- `GET /api/projects?page&limit&q&topic&region&dateFrom&dateTo&sort(new|updated|popular)&scope(all|mine|saved|contacts)&trash=1&status=` → `{ projects: ProjectCard[], total, page, limit, pages }`. Гостю — публичные. ProjectCard: `{ id,title,description,summary,promoAnnotation,topics[],region,coverImage,promoImage,status,visibility,clientStatus,rating,viewsCount,commentsCount,applicationsCount,isPremium,publishedAt,createdAt,updatedAt,tags[],progress,fundingType,budget,requiredSkills[],lookingFor,saved,owner{id,name,title,avatarUrl,ipScore},members[{userId,role,user,exitState}],allMembersCount }`
- `POST /api/projects` — создание: `{ title*, description*, summary≤100, promoAnnotation≤150, topics[](≤5), region, coverImage, promoImage, gallery[](≤20), videoUrl(URL), visibility(public|private), publish(bool, default true), tags[], problem/context/solution/result, clientCompanyId, contributors[{name*, role*, phone?, email?, website?, externalId?}] }` → 201 `{ project }`.
- `GET /api/projects/[id]` → `{ project: {...ProjectCard, description full, gallery[], evidence-поля problem/context/solution/result, contributors[], comments[{id,text,createdAt,author, replies[{id,parentId,text,createdAt,author}]}], membersCount...}, me: {isOwner,isMember,saved,hasApplied,applicationStatus}, applications (только владельцу, с user), unreadApplications, author {id,name,title,avatarUrl,ipScore,projectsCount,postsCount} }`. Удалённый/частный без доступа → 404 «Объект недоступен».
- `PATCH /api/projects/[id]` actions: `join` (существующее), `complete`, `update` (владелец, частичное: title/description/summary/promoAnnotation/topics/region/coverImage/promoImage/gallery/videoUrl/visibility/tags), `publish`/`unpublish`, `delete` (soft, 30 дней), `restore`.
- `POST /api/projects/[id]/view` → `{ ok, counted, viewsCount }` (дедуп 24ч).
- Модели Prisma уже в схеме: `ProjectApplication, ProjectContributor, ProjectComment, SavedProject, ProjectView, ProjectShare, Report, Lot, LotResponse, SavedLot, TaxonomyItem` (+ поля Project: `summary, promoAnnotation, topicsCsv, region, coverImage, promoImage, galleryJson, videoUrl, isPremium, premiumUntil, publishedAt, deletedAt, viewsCount`).

## §1 Комментарии проекта (ТЗ §5.3)

**`GET /api/projects/[id]/comments`** → `{ comments: [как в GET [id]], total }`. Публично.
**`POST /api/projects/[id]/comments`** (withRoute, 30/мин) body `{ text* (1..2000), parentId? }`:
- только авторизованный (401); parentId → комментарий существует, принадлежит проекту и сам является корневым (глубина 1, иначе 422 «Ответы на ответы не поддерживаются»);
- уведомление: автору проекта (если не сам) и автору родительского комментария (если есть и не сам).
→ 201 `{ comment: { id, parentId, text, createdAt, author } }`.
**`DELETE /api/projects/[id]/comments/[commentId]`** (withRoute) — только автор комментария → soft `deletedAt`. → `{ ok: true }`.

## §2 Заявки на участие (ТЗ §7.1, UC-03)

**`POST /api/projects/[id]/apply`** (withRoute, 10/мин) body `{ coverLetter? (≤4000), city?, specialization? }`:
- авторизация 401; проект опубликован и не удалён (404); не владелец (403 «Владелец не подаёт заявку на свой проект»); unique → если заявка уже есть и status=declined и прошло <30 дней → 409 «Повторная заявка возможна через N дней»; если new/viewed/accepted → 409 «Заявка уже отправлена»;
- уведомление владельцу: type 'application', title «Новая заявка на участие в проекте «{title}»», link → view projects.
→ 201 `{ application }`.
**`GET /api/projects/[id]/applications`** — только владелец (403): `{ applications: [{id, coverLetter, city, specialization, status, isRead, createdAt, user{id,name,title,avatarUrl,ipScore}}], unreadCount, totalCount }`.
**`PATCH /api/projects/[id]/applications/[applicationId]`** (withRoute) — только владелец. Actions:
- `{ action: 'view' }` → isRead=true, status: new→viewed;
- `{ action: 'accept' }` → status=accepted, decidedAt, создаёт ProjectMember (role 'member', если ещё нет), уведомление кандидату type 'application' «Вас приняли в проект...»;
- `{ action: 'decline' }` → status=declined, decidedAt.
→ `{ application }`.

## §3 Внешние участники (ТЗ §7.2 «Над проектом работали»)

**`POST /api/projects/[id]/contributors`** (withRoute) — только владелец. Body `{ name* (2..150), role* (≤100), phone? (маска +7 или междунар., ≤30), email? (формат), website? (URL http/https), externalId? (≤100) }` → 201 `{ contributor }` (displayOrder = max+1).
**`DELETE /api/projects/[id]/contributors/[contributorId]`** (withRoute) — только владелец → `{ ok: true }`.
PII: GET-выдача contributors в `GET /api/projects/[id]` уже включает phone/email — для гостя должны быть скрыты. Изменение внести в `[id]/route.ts` GET: если `!user` — маппить contributors, заменяя `phone: undefined, email: undefined`. (Единственное разрешённое изменение существующего файла.)

## §4 Избранное (ТЗ «Избранные»)

**`POST /api/projects/[id]/save`** (withRoute, 60/мин) — toggle как `posts/[id]/save`: → `{ saved: boolean }`.
**`GET /api/projects/saved`** → `{ projects: ProjectCard[], total }` (карточки через ту же сериализацию; допускается упрощённая: include project + owner; saved=true).

## §5 Шеринг (ТЗ §10.4)

**`POST /api/projects/[id]/share`** (withRoute, 20/мин) body `{ toUserIds* (1..20, валидные юзеры), message? (≤500) }`:
- каждому: upsert ProjectShare (unique [projectId,fromUserId,toUserId] — при повторе update message), создать/переиспользовать Conversation (пара from/to, как в POST /api/messages), Message с текстом «Поделился проектом «{title}»: {message}» + уведомление.
→ 201 `{ shared: n }`.

## §6 Жалобы (ТЗ §10.5)

**`POST /api/reports`** (withRoute, 10/мин) body `{ targetType*: 'project'|'comment'|'lot'|'user', targetId*, reason*: 'abuse'|'forbidden'|'spam'|'other', details? (≤1000) }`:
- проверка существования цели (404); unique [reporterId,targetType,targetId] → 409 «Жалоба уже отправлена»;
→ 201 `{ report }`.
**`GET /api/reports`** — админ-очередь (проверка ролей: `user.roles.split(',')` содержит `'admin'`; у User НЕТ поля isAdmin): `{ reports: [{...report, reporter:{id,name}}], openCount }` + фильтр `?status=open|reviewed|dismissed`.
**`PATCH /api/reports/[reportId]`** — админ: `{ status: 'reviewed'|'dismissed' }` → `{ report }`.

## §7 Таксономия и подборки (ТЗ §8.2, §4.2)

**`GET /api/taxonomy?type=topic|region|role`** (публично) → `{ items: [{id,type,name}] }`. Seed см. §10.
**`GET /api/projects/recently-viewed`** (авторизован; 401 если нет) → последние 10 уникальных проектов из ProjectView (по viewerId=user.id, viewedAt desc) → `{ projects: ProjectCard[] }` (даже если <10 — честная пустота `[]`).
**`GET /api/projects/recommendations`** (авторизован) → топ-8 опубликованных публичных проектов с пересечением topicsCsv с темами недавно просмотренных/сохранённых проектов пользователя (не свои, не удалённые; если данных мало — заполнить популярными по viewsCount; полная пустота — вернуть `[]` честно) → `{ projects: ProjectCard[] }`.

## §8 Биржа проектов — ЛОТЫ (ТЗ §8, §9, UC-04, UC-05)

**`GET /api/lots`** (публично; гость — open-лоты) параметры `page&limit(≤50)&q&topic&employer&employment(remote|onsite)&region&sort(new|boosted|budget)`:
- где status='open', deletedAt=null, acceptUntil > now() (просроченные не показывать; параметр `?all=1` для владельца не нужен);
- сортировка: new → publishedAt desc; boosted → (boostedAt ?? publishedAt) desc; budget → budget desc nulls last (SQLite: orderBy два поля не поможет — сортировать в JS после выборки страницы допустимо только в пределах страницы; лучше orderBy publishedAt и пометить) — выбери простое корректное: new/boosted через orderBy [{boostedAt:'desc'},{publishedAt:'desc'}], budget черезorderBy [{budget:'desc'}].
→ `{ lots: LotCard[], total, page, pages }`.
LotCard: `{ id,title,budget,budgetNegotiable,duration,acceptUntil,workFormat,requiredRole,region, topics (из detailsJson.topic? — нет, topics у лота нет: пропускаем), status, responsesCount, viewsCount, favoritesCount, publishedAt, boostedAt, employer{id,name,title,avatarUrl,ipScore,subscriptionTier}, rating (→ employer.ipScore → нормировка 1..5: Math.max(1, Math.min(5, ipScore/20)) — честная нормировка; если ipScore=0 → 0), saved (для текущего юзера), responsesCount }`. Полный detailsJson — только в GET [id] (развёрнутая карточка).
**`POST /api/lots`** (withRoute, 10/мин) body `{ title* (≤150), budget? (число>0), budgetNegotiable*, duration* (≤100), acceptUntil* (ISO, будущее), workFormat*: 'remote'|'onsite', requiredRole?, region?, details*: { what_to_do*, essence*, background?, result?, criteria?, workload?, interaction_format?, requirements*, tips? } (строки ≤5000; обязательны блоки 1,2,8: what_to_do, essence, requirements) }` → 201 `{ lot }`.
**`GET /api/lots/[id]`** (публично для open) → `{ lot: {...LotCard, details, employer{...}}, me: {isOwner, saved, hasResponded} }`; регистрирует просмотр аналогично project/view (дедуп 24ч на юзера, increment viewsCount) — только если запрошен `?track=1`.
**`PATCH /api/lots/[id]`** (withRoute) — только владелец: actions `update` (те же поля), `close` (status='closed'), `open` (если acceptUntil в будущем), `delete` (deletedAt, soft 30 дней), `restore`.
**`POST /api/lots/[id]/respond`** (withRoute, 10/мин) body `{ coverLetter* (10..4000), roleApplied? (≤100) }`:
- авторизован; лот open, не просрочен, не свой (403); unique [lotId,userId] → 409 «Отклик уже отправлен»;
- increment responsesCount; уведомление владельцу type 'application' «Новый отклик на лот «{title}»».
→ 201 `{ response }`.
**`GET /api/lots/[id]/responses`** — только владелец → `{ responses: [{id,coverLetter,roleApplied,status,isRead,createdAt,user{id,name,title,avatarUrl,ipScore}}], unreadCount }`; PATCH-обработка в этом же файле не нужна — см. ниже.
**`PATCH /api/lots/[id]/responses/[responseId]`** (withRoute) — владелец лота: `{ action: 'view'|'accept'|'decline' }` (view → isRead=true/status viewed; accept/decline → status, уведомление кандидату).
**`POST /api/lots/[id]/boost`** (withRoute) — владелец; cooldown 24ч по boostedAt → 429-подобный ответ 422 «Обновить можно через {часы} ч.» если недавно; иначе boostedAt=now → `{ lot }`.
**`GET /api/lots/saved`** → избранные лоты юзера.
**`POST /api/lots/[id]/save`** — toggle избранного (инкремент/декремент favoritesCount) → `{ saved }`.

## §9 Премиум (ТЗ §4.4)

Отдельный роут не требуется: isPremium вычисляется при выдаче. В `GET /api/projects` ProjectCard отдаёт `isPremium` как есть в БД. Реализация флага: **`POST /api/projects/[id]/premium`** (withRoute) — владелец; проверяет активную подписку владельца (`db.subscription.findFirst({ where: { userId: user.id, status: 'active', tier: { in: ['pro','business','enterprise'] } } })`); нет подписки → 403 «Требуется подписка PREMIUM»; есть → isPremium=true, premiumUntil=+30 дней (или из expiresAt подписки) → `{ project }`.

## §10 Seed-обогащение (`scripts/seed-projects-tz.ts`, idempotent upsert, НЕ трогая пользователей)

- TaxonomyItem: topics [Здравоохранение, Промышленность, Спорт, Дизайн, Разработка ПО, Строительство, Образование, Культура, Маркетинг, Логистика]; regions [Москва, Санкт-Петербург, Самара, Петропавловск-Камчатский, Чувашская республика, Российская Федерация, Республика Беларусь, Online]; roles [Автор, Заказчик, Дизайнер, Разработка, Верстка и печать, Информационная и рекламная поддержка, Ментор].
- Первым 5 существующим проектам (созданы scripts/seed.ts): upsert summary/promoAnnotation/topics/region (по смыслу), publishedAt (если null), viewsCount (детерминированные значения 40-500), 2-3 ProjectContributor с displayOrder (роли из справочника), по 1-2 ProjectComment + 1 reply от пользователей `*@bizon.ru` (authorId по emailHash НЕ нужен: возьми любых users из db.user.findMany take 5), 1-2 ProjectApplication от разных юзеров к recruiting-проектам (coverLetter, city, specialization).
- 3 лота от разных юзеров: реальные по ТЗ детали (detailsJson — все 9 блоков, обязательные заполнены), budget/budgetNegotiable, duration «7 месяцев», acceptUntil +30 дней, workFormat remote/onsite, region; к одному лоту — 2 LotResponse от других юзеров (responsesCount синхронно).
- Idempotent: `upsert`/`findFirst-else-create` по естественным ключам; повторный запуск не дублирует.

## §11 Готовность

Гейт: `npx tsc --noEmit` = 0 ошибок; `bun run lint` без новых ошибок; `bun test tests/` — все зелёные (тесты НЕ писать, но не сломать: тесты используют db-копию и сервисы напрямую).

---

# §11. Аддендум «Проекты как инструмент» (17-09-2026, владелец: 8 доработок)

## §11.1 POST /api/projects/[id]/recommend — «Рекомендовать проект»
- Auth 401; проект опубликован/не удалён → 404; toUserIds 1..20 (422 пусто), получатели существуют (404), самому себе 422; message ≤500.
- Модель `ProjectRecommendation` (unique [projectId, fromUserId, toUserId]); повторы тихо исключаются (find-then-create, SQLite без skipDuplicates).
- Ответ 201 `{recommended, skipped, message}` / 200 если все повторы.
- Уведомление получателю: type `project_recommended` (строковый, по паттерну `news_recommended` — вне канонической пятёрки NOTIFICATION_TYPES, осознанное решение), link `/?view=projects&projectId=…`.
- Лимит withRoute 10/мин. UI: кнопка «Рекомендовать» на странице проекта (рядом с «Поделиться») и в развороте карточки ленты; диалог — принятые контакты `GET /api/connections?status=accepted`.

## §11.2 GET /api/projects/recommendations — + rule-based причины
- Аддитивно к §0/§7: каждый элемент теперь `{...ProjectCardData, saved, reasons: string[]}`.
- Причины строит `src/lib/projects/recommendation-picker.ts` → `buildReasons()` (темы интересов → навыки → регион → квалификация → популярность). Пикер общий с §11.4.

## §11.3 Project.experienceShare — «Мы готовы поделиться опытом и знаниями по …»
- Поле `String?` ≤500; принимается POST /api/projects (create) и PATCH [id] action=update (422 при >500); отдаётся в GET [id] (spread).
- UI: блок на странице проекта (после описания), редактирование владельцем; поле в форме создания; seed заполняет 5 проектов.

## §11.4 POST /api/ai/project-match — AI-объяснения «почему интересно»
- Auth 401; AI-лимит по тарифу `getAiLimitKey('projectMatch', tier)` (free 5/ч, pro 50/ч, business 500/ч) → 429 честным текстом; H11 60/мин остаётся в withRoute.
- Тело `{limit?: 1..4 (дефолт 4)}`; ответ `{matches: [{projectId, why}], provider: 'llm-with-fallback'}`.
- LLM: `generateProjectMatchWhy()` в src/lib/ai.ts → AIGateway.run(operation 'project.match.why') → z-ai-web-dev-sdk только в llm-колбэке; fallback — rule-based текст. Кнопка «Подобрать с AI» во вкладке «Рекомендации».

## §11.5 UI-изменения (не ломают контракт §0)
- Карточки ленты: кнопка «Развернуть» (inline-превью: резюме без обрезки, автор, просмотры, «Читать полностью», «Рекомендовать»).
- Страница проекта: журнальная вёрстка описания (лид-абзац, абзацы, галерея между абзацами).
- Меню 7 разделов «Проектов» перенесено в правый сайдбар (RightRail, под «Быстрыми действиями»); на мобиле остаётся пилюля-строка. Активный таб теперь в app-store (`projectsTab`, входит в NavSnapshot — «Назад» работает).
- Левая кнопка «Создать проект» удалена; зелёный FAB «+» (SmartButton) открывает реальные формы: пост/новость, проект (CreateProjectDialog), лот (CreateLotDialog), событие, вакансия (company/hr), рекомендация человека (POST /api/recommendations).
