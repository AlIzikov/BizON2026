# WCAG 2.2 AA Аудит BizON — 10.09.2026 (Task C-e)

**Метод**: статический анализ (grep/чтение кода, ~11 000 строк в зоне аудита) + расчёт контрастов по oklch/hex-палитре проекта (WCAG-формула). Живой скринридер/аудит AXE не запускался — см. «Честные ограничения».

**Зона**: shell/app-shell, unified-search-panel, лента (trust-stream, one-thought-mode, news-card), поиск, настройки, профиль (profile-view, public-persona), вакансии (jobs-view, compare-vacancies, job-passport), проекты (projects-view, project-results-chain), правда (truth-dashboard-tab, trust-explain-card, claim-card), новые диалоги (2FA, request-verify, my-placements, interested-companies), auth-screen, dashboard-view, globals.css, layout.tsx.

---

## 1. Сводка

| Категория | Найдено | Исправлено | Осталось |
|---|---|---|---|
| **Критические (Level A: keyboard/semantic)** | 7 | 7 | 0 |
| **Средние (AA: контраст текста)** | 4 группы | 4 группы | (1 наблюдение) |
| **Средние (AA: name/role/value, labels)** | 5 групп | 5 групп | 0 |
| **DialogContent без описания (Radix warning 4.1.2)** | 20 диалогов | 20 | 0 |
| **Низкие / наблюдения (не фиксил по ТЗ)** | 6 | 0 | задокументировано |

**Итог по критериям WCAG 2.2 (проверено 12 пунктов из практического чек-листа):**

| № | Критерий | Статус до аудита | После фиксов |
|---|---|---|---|
| 1.1.1 | Non-text Content | ✅ почти ок (все `img` имеют alt: контентные — описательный, декоративные — `alt=""` + часто `aria-hidden`) | ✅ без изменений |
| 1.3.1 | Info & Relationships | ❌ 3 кликабельных `div onClick` без роли | ✅ → `<button>` |
| 1.4.3 | Contrast (min) | ❌ 4 системные группы текста < 4.5:1 | ✅ исправлены (см. таблицу контрастов) |
| 1.4.11 | Non-text Contrast | ⚠️ бордеры контролов `--input`/`--border` ≈1.2–1.3:1 | ⚠️ осталось (см. «Осталось») |
| 2.1.1 | Keyboard | ❌ unified-search: активация только `onMouseDown`; 3 `div onClick` | ✅ исправлено |
| 2.4.1 | Bypass Blocks | ✅ skip-link есть (`SkipToContent` → `#main-content` в app-shell, `<main id="main-content">`) | ✅ |
| 2.4.7 | Focus Visible | ✅ глобальный `*:focus-visible` в globals.css НЕ удалён; `outline-none` встречается только в паре с `focus-visible:ring-*` (видимый фокус сохранён) | ✅ |
| 2.5.3 | Label in Name | ✅ проверено: все добавленные `aria-label` содержат видимый текст («Спросить…», «Нравится, N», «Сравнить…») | ✅ |
| 2.5.8 | Target Size (min) | ✅ глобально `min-height: 44px` для button/a/input/select/textarea; исключения `h-8` (32px) и sidebar-collapse `w-6 h-6` (24px) — проходят AA-минимум 24×24 | ✅ |
| 3.3.2 | Labels or Instructions | ❌ поиск без aria-label; referral-input без подписи; сообщение в диалоге без aria-label | ✅ исправлено |
| 4.1.2 | Name, Role, Value | ❌ икон-кнопки без accessible name (тема, выход, уведомления, аватары, save/compare в compact); выбор контакта/фильтры/темы без state-атрибуов; «мёртвая» кнопка-профиль | ✅ исправлено |
| 4.1.3 | Status Messages | ⚠️ toast есть; loading-скелеты без анонса; aria-label на div без роли (игнорируется) | ✅ role="status"/aria-busy добавлены |

---

## 2. Критические исправления (Level A)

### C1. Единый поиск — результаты недоступны с клавиатуры (2.1.1) — `shell/unified-search-panel.tsx`
Кнопки результатов и «Показать все» обрабатывали **только** `onMouseDown` (защита от onBlur-гонки). Enter/Space на сфокусированной кнопке эмулирует `click`, но не `mousedown` → клавиатурный пользователь не мог открыть ни один результат поиска.
**Фикс**: добавлен `onClick={(e) => { if (e.detail === 0) onItem(...) }}` — `detail === 0` только у клавиатурного click; мышиный путь (mousedown) не тронут. Плюс `id="unified-search-results"` для `aria-controls`.

### C2. Кликабельные `div onClick` без роли/клавиатуры (1.3.1/2.1.1)
- `profile/profile-view.tsx` BreakdownBar (4 строки «Из чего состоит IP-score») — кликабельные при `isOwn`, но `<div onClick>`: фокус не получить, скринридер не знает про интерактивность → `<button type="button">` (для некликабельных — остался div).
- `dashboard/dashboard-view.tsx:516–533` (превью ленты) и `:550–568` (ближайшие события) — то же → `<button>`.

### C3. «Мёртвая» кнопка-профиль в цепочке результата (4.1.2) — `projects/project-results-chain.tsx:215`
`<button title="Открыть профиль">` **без onClick** — роль обещает действие, действия нет (клавиатурный пользователь активирует и ничего не происходит). Подключён реальный переход: `setProfileUserId(m.userId); setView('profile')` (тот же паттерн, что во всём проекте).

### C4. Auth: кастомный dropdown типа аккаунта — `auth-screen.tsx:336–390`
Триггер без `aria-expanded/aria-haspopup`, опции без состояния выбора, `<Label>` не связан.
**Фикс**: `aria-expanded`, `aria-haspopup="listbox"`, `aria-labelledby="account-type-label"`, контейнер `role="listbox"`, опции `role="option"` + `aria-selected`, иконки `aria-hidden`.

### C5. Radix-ворнинг «Missing Description or aria-describedby for DialogContent» — 20 диалогов
Составлено программно (каждый `<DialogContent>` проверен):
- **Реальные `DialogDescription` добавлены** (7): `jobs/compare-vacancies`, `projects/projects-view` (детальный проект + создание), `profile/profile-view` (QR-код, добавить навык, подтвердить навык), `profile/public-persona` (персонализированное приглашение, написать сообщение), `truth/evidence-modal` (`<p>` → `DialogDescription`).
- **`aria-describedby={undefined}`** (13 файлов, без визуальных изменений): companies/company-view, companies/company-dashboard, truth/prove-it-button, truth/truth-profile, truth/truth-gap-display, truth/career-timeline, dashboard/daily-brief, hr/hr-contact-button, hr/hr-view, dao/dao-view, cultural-signals (×2), jobs/job-card-v2 (×3), cv/resume-generator-dialog.
Все `AlertDialogContent` уже имели `AlertDialogDescription` ✅.

---

## 3. Контраст текста (1.4.3) — точные пары

Расчёт по WCAG-формуле (oklch → sRGB → luminance; hex — Tailwind v4). Light theme, фон белый, если не указано.

| Пара (до) | Ratio | Вердикт | Заменено на | Ratio | Где |
|---|---|---|---|---|---|
| `text-success` oklch(.65 .13 195) ≈ #00A7A8 на white | **2.97:1** | FAIL | `text-success-text` ≈ #006465 | **6.97:1** | projects-view statusColor('completed') |
| `text-emerald-600` #059669 на white | **3.77:1** | FAIL | `text-emerald-700 dark:text-emerald-400` | **5.48:1** / **9.42:1** (dark) | compare-vacancies (★, growthLabel), trust-explain-card (delta, NBA), profile-view (referral) |
| `text-amber-600` #D97706 на white | **3.19:1** | FAIL | `text-amber-700 dark:text-amber-400` | **5.02:1** / **10.85:1** | trust-explain-card (LEVEL_COLOR.basic), my-placements-card (бейдж «Частично», счётчик) |
| `text-teal-600` #0D9488 на white (лайк активен) | **3.74:1** | FAIL | `text-teal-700 dark:text-teal-400` | **5.47:1** / **9.73:1** | trust-stream PostCard |
| `text-red-600 dark:text-red-500` (delta<0) | **4.83:1** | pass (погранично) | → `text-red-700 dark:text-red-400` (запас) | **6.47:1** | trust-explain-card |
| `text-muted-foreground/40` на white | **1.92:1** | FAIL | → `text-muted-foreground` | **7.40:1** | app-shell (заблокированные разделы, 🔒-пункты) |
| `text-muted-foreground/50` | **2.32:1** | FAIL | → `text-muted-foreground` | **7.40:1** | 14 мест |
| `text-muted-foreground/60` | **2.84:1** | FAIL | → `text-muted-foreground` | **7.40:1** | 11 мест |
| `text-muted-foreground/70` | **3.54:1** | FAIL | → `text-muted-foreground` | **7.40:1** | 18 мест (в т.ч. FAB-подсказка) |
| `text-muted-foreground/80` | **4.46:1** | FAIL (маргинально) | → `text-muted-foreground` | **7.40:1** | 7 мест |
| `bg-emerald-600` + white (буквы A/B/C, бейдж навыков, кнопка «Сравнить») | **3.77:1** | FAIL для мелкого текста | → `bg-emerald-700 hover:bg-emerald-800` | **5.48:1** | compare-vacancies |
| `.trust-badge-basic` (oklch .65 .12 65) + white | **≈2.3:1** | FAIL | → `var(--warning)` + `var(--warning-foreground)` | **7.66:1** | globals.css (в коде используется как индикатор-точка; цвет зафиксирован токенами на всякий случай) |
| `.trust-badge-expert` (oklch .55 .13 195) + white | **≈3.5:1** | FAIL | → `var(--success)` + `var(--success-foreground)` | **6.54:1** | globals.css |

**Проверены и PASSED без изменений** (типовые пары проекта):

| Пара | Ratio |
|---|---|
| `text-foreground` oklch(.20 .04 255) ≈ #0B2545 на white | **18.11:1** |
| `text-muted-foreground` oklch(.45 .025 240) на white | **7.40:1** |
| `text-primary` navy на white | **16.92:1** |
| `text-lighthouse` oklch(.55 .10 200) ≈ #008388 на white | **4.59:1** (pass; полоса заголовков/бейджи) |
| `text-destructive` oklch(.58 .22 25) ≈ #DF202E на white | **4.79:1** |
| `#1e3a8a` (blue-900) на `blue-50` (#EFF6FF) — IP-hero в настройках | **9.52:1** |
| `text-blue-400` на `blue-950` — dark-вариант того же hero | **5.78:1** |
| `text-slate-500` #64748B на white (праймериз сравнения) | **4.76:1** |
| dark: `muted-foreground` oklch(.70) на navy | **6.82:1** |
| dark: `primary-foreground` на `primary` oklch(.40 .08 200) | **8.00:1** |
| white на `lighthouse` (FAB, кнопка «Назад») | **4.59:1** |
| `matchBadgeClass` (jobs-types): emerald-700/amber-700 + dark -400 | **5.48:1 / 5.02:1** |
| `bg-warning`+`warning-foreground`, `bg-success`+`success-foreground` (типы аккаунтов в auth) | **7.66:1 / 6.54:1** |
| `.trust-badge-extended` (lighthouse) + white | **4.59:1** |
| `impact-medium` oklch(.55 .08 240) | **4.79:1** |

Наблюдения по 1.4.11/1.4.1 (зафиксированы, не фиксил): звезда рейтинга `fill-yellow-400` (1.53:1) — но рядом всегда текст значения; цветовое кодирование scoreClass в compare-таблице дублируется весом шрифта и легендой ★.

---

## 4. Name / Role / Value и Labels (4.1.2, 3.3.2) — исправления

**app-shell.tsx**: поиск — `aria-label` + `aria-expanded` + `aria-controls` (3.3.2 + 4.1.2); кнопки «тема»/«выход»/«уведомления» — `aria-label` (у уведомлений — с количеством; счётчик-бейдж `aria-hidden`); сайдбар-навигация — `aria-label` + `aria-current="page"` (десктоп и мобильный таб-бар); «Ещё» — `aria-expanded`; mobile «Ещё»-sheet — `role="dialog" aria-modal aria-label` + закрытие с `aria-label`; иконки — `aria-hidden`.

**settings-view.tsx**: RadioGroup приватности — `aria-label="Видимость профиля"` (Radix даёт `role="radiogroup"`, но имя группы отсутствовало); все 4 Switch — `aria-label` (HR-невидимость, хобби, паспорт, FlagRow); ThemeButton — `aria-pressed`.

**trust-stream.tsx**: сохранить — `aria-label` + `aria-pressed`; лайк — `aria-label="Нравится, N"` + `aria-pressed`; комментарии — `aria-label="Комментарии, N"` + `aria-expanded`; аватар-кнопки (пост/событие) — `aria-label="{Имя} — открыть профиль"`; фильтры Все/Посты/Достижения — `aria-pressed`.

**compare-vacancies.tsx**: загрузка — `aria-busy` + sr-only; таблица — `scope="col"/"scope="row"` (1.3.1); выбор контакта в `claim-card` — `aria-pressed` (выбор вакансий для сравнения уже имеет `aria-pressed` в GroupChip/`job-explore-panel`/`saved-filters-panel` — проверено ✅).

**my-placements-card.tsx (звёзды рейтинга)** — проверено, БЕЗ ИЗМЕНЕНИЙ: уже `role="radiogroup"` + `role="radio"` + `aria-checked` + `aria-label` на каждую звезду + `aria-live` на «Оценка: N/5» + каскадные touch-цели 44px. Эталон.

**one-thought-mode.tsx** — проверено, без изменений: `aria-busy` на loading, `aria-live` на счётчике «N/10», `aria-label` на секции и кнопках навигации. Эталон.

**two-factor-card.tsx**: QR-обёртка — `role="img"` + `aria-label` (aria-label на div без роли игнорируется бы). Все 4 шага 2FA уже имели Labels/DialogDescription ✅.

**jobs**: job-passport — save/compare в compact-режиме получили `aria-label` + `aria-pressed`; jobs-view — `aria-busy` + sr-only на скелетах (оба экрана обновлены в аудит-зоне; у «Обновить» aria-label уже были ✅).

**dashboard-view.tsx**: скелет «Вас нашли» — `aria-label` на div без роли заменён на `role="status"` + sr-only (4.1.3).

**public-persona.tsx**: «Спросить» — `aria-label` (содержит видимый «Спросить» → 2.5.3 ok); Textarea сообщения — `aria-label`.

**Loading-состояния (4.1.3, сводное)**: `aria-busy`/`role="status"` добавлены в compare-vacancies, projects-view, jobs-view (JobListArea), project-results-chain (`aria-busy` на секции). Один троттлинг-паттерн — `UnifiedSearchPanel` loading → `role="status"` + `aria-live="polite"`.

---

## 5. Что осталось (честно, с file:line и рекомендацией)

1. **1.4.11 — бордеры контролов** (`globals.css`: `--border: oklch(0.91 …)`, `--input: oklch(0.94 …)` → **1.30:1 / 1.19:1** на белом; dark: white/10% ≈ 1.31:1). Формально визуальная идентификация input/select опирается на бордер. Менять глобально = редизайн всех полей. **Рекомендация**: следующая волна — `--input: oklch(0.70 0.01 240)` (≈3:1) + рассмотреть фон `bg-muted/50` у полей.
2. **Цвет как единственный носитель в compare-таблице** (`jobs/compare-vacancies.tsx`, scoreClass/daysClass): цвет + жирность, но не текстовый маркер (1.4.1). Легенда ★ объясняет «лучшее значение», но цветовые ранги значений читает только зрячий. Рекомендация: текстовые суффиксы («хорошо»/«средне») или иконки.
3. **Кастомные оверлеи без focus-trap и без Esc**: CreateActionModal (`app-shell.tsx:805`), mobile «Ещё»-sheet (`:598`), NotificationsDropdown (`:889`), dropdown типа аккаунта (`auth-screen.tsx:360`), `three-dots-menu`, `ai-co-pilot`. Клавиатурный пользователь может «пройти» под оверлей на фон. Radix-диалоги (основная масса) — ок. Рекомендация: перевести на Dialog/Popover в следующей волне.
4. **Click-outside слои** `<div className="fixed inset-0" onClick>` (app-shell:889, auth-screen:360, three-dots-menu:20) — не фокусируемы, но это невидимые закрыторы поверх явной кнопки закрытия — допустимый паттерн, зафиксировано.
5. **`text-muted-foreground/30`** (6 мест: not-found «404», разделители «·»/«|», avatar-placeholder в `/c/[token]`) — декоративные, оставлены намеренно.
6. **Звезда рейтинга `fill-yellow-400`** (`profile-view.tsx:487`, rating проектов) — 1.53:1 как графика; значение рядом текстом → 1.4.11-исключение «не требуется для понимания». Рекомендация: `fill-amber-500` (2.15:1) + или добавить контур `stroke-amber-700`.
7. **UserAvatar online-точка** (`user-avatar.tsx:64`): `aria-label` на `<span>` без роли; статус «онлайн» дублируется не везде. Рекомендация: `role="img"` или sr-only текст «Сейчас онлайн».
8. **1.3.1 — заголовки**: h1 во всех view есть; CardTitle (h3) используется в карточках — иерархия h1→h3 без h2 в ряде view (пропуск уровня — best practice violation, не строго AA). Рекомендация не приоритетна.

---

## 6. Честные ограничения — что статикой не проверяемо

Нужен живой скринридер (NVDA/JAWS/VoiceOver) и браузерный AXE-прогон:

1. **Реальные анонсы 4.1.3**: правильно ли NVDA озвучит `role="status"`-скелеты, `aria-live` счётчик «N / 10», `role="alert"` ошибок поиска; отсутствие двойного чтения (aria-label + контент).
2. **Практическая навигация**: порядок фокуса в модалках Radix (focus-trap работает из коробки, но проверяется руками), возврат фокуса после закрытия диалогов, поведение `aria-modal` в самодельных оверлеях (п.5 «Осталось»).
3. **Скринридер-формы**: Stripe-подобные ошибки валидации (toast не фокусируется — слышит ли SR пользователь ошибку, если фокус остался в поле).
4. **Dark mode в динамике**: расчёты dark-контрастов сделаны по токенам; фактические комбинации (например, бейджи на градиентах) нужно проверить пиксельным пипером на живой странице.
5. **Zoom/Reflow (1.4.10, AA)**: не проверялся — нужен браузер (400% зум, 320px). Mobile-first сетки (`grid-cols-1 sm:…`) — хороший знак, но это прогон, не статика.
6. **2.5.7 Dragging / 3.3.8 Redundant Entry / 2.4.11 Focus Not Obscured** — критерии 2.2, требующие интерактивной проверки; статически в коде drag-взаимодействий не найдено (карусель embla — кнопки-стрелки есть ✅).
7. **Yandex Metrica webvisor** в production не рассматривался (внешний скрипт).

---

## 7. Верификация фиксов

- `bunx tsc --noEmit` → **0 ошибок**.
- `bun run lint` → **0 errors** (1 пре-существующий warning: `jobs-view.tsx:217` unused eslint-disable, не мой).
- `GET /` → **200**, dev.log без ⨯.
- Автопроверка: каждый `<DialogContent>`/`<AlertDialogContent>` в `src/**` имеет `DialogDescription`/`AlertDialogDescription` либо `aria-describedby={undefined}` — **скрипт: OK**.
- Поведение не менялось: только атрибуты, семантика (`div→button` с теми же классами), цветовые классы (`-600→-700`, удаление opacity-модификаторов), `aria-*`.

**Затронуто файлов: 59** (31 целевых + 34 в механическом контраст-свипе `text-muted-foreground/NN`, пересечение частичное).
