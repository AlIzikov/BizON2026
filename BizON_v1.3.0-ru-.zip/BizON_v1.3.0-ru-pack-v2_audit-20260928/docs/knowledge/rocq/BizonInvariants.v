(* ===================================================================== *)
(* BIZON — ФОРМАЛЬНЫЕ ИНВАРИАНТЫ ДЕНЕЖНОГО ЯДРА (R2-A5 / D-19 / D-27)    *)
(* Модель соответствует:                                                  *)
(*   computeSplit  → src/lib/services/virtual-cashier-service.ts           *)
(*   guardedDebit  → guard-декремент src/lib/services/lumen-service.ts     *)
(*   refundVar (текущий/фикс) → D-19 / A5-2 (примитив печати денег)        *)
(*   verifyChain   → src/lib/data-vault/audit-log.ts (окно, генезис)       *)
(* ===================================================================== *)

Require Import ZArith Bool Lia.
Open Scope Z_scope.

(* ===================== I1: SPLIT (комиссия кассы) ==================== *)
(* TS: commission = Math.floor(amount * p / 100); sellerGets = amount - commission *)
(* Для неотрицательных целых Z.div == floor: модель точна (граница 2^53 — в отчёте) *)

Definition commission (amount p : Z) : Z := amount * p / 100.
Definition sellerGets (amount p : Z) : Z := amount - commission amount p.

(* I1-a: СОХРАНЕНИЕ СУММЫ — для ЛЮБЫХ amount и p (без ограничений!) *)
Theorem T1a_conservation : forall amount p,
  commission amount p + sellerGets amount p = amount.
Proof.
  intros amount p. unfold commission, sellerGets.
  assert (Hlin : forall c : Z, c + (amount - c) = amount) by lia.
  apply Hlin.
Qed.

(* вспомогательная: комиссия не превышает amount при p <= 100 *)
Lemma commission_le_amount : forall amount p,
  0 <= amount -> p <= 100 -> commission amount p <= amount.
Proof.
  intros amount p Hamount Hp. unfold commission.
  assert (H1 : amount * p <= amount * 100) by (apply Z.mul_le_mono_nonneg_l; lia).
  apply Z.le_trans with (m := amount * 100 / 100).
  - apply Z.div_le_mono; lia.
  - rewrite Z.div_mul by lia. lia.
Qed.

(* I1-b: НЕОТРИЦАТЕЛЬНОСТЬ ДОЛЕЙ — для ВСЕХ amount >= 1, 0 <= p <= 50 *)
(* (тест A5 проверил 1122 пары; здесь доказано для бесконечного множества) *)
Theorem T1b_nonneg : forall amount p, 1 <= amount -> 0 <= p -> p <= 50 ->
  0 <= commission amount p /\ 0 <= sellerGets amount p.
Proof.
  intros amount p H1 H2 H3.
  assert (Hpos : 0 <= commission amount p).
  { unfold commission. apply Z.div_pos;
      [lia | nia]. }
  assert (Hup : commission amount p <= amount)
    by (apply commission_le_amount; lia).
  split; [exact Hpos |].
  unfold sellerGets. lia.
Qed.

(* I1-c: КОМИССИЯ НИКОГДА НЕ СЪЕДАЕТ БОЛЬШЕ ВЗНОСА *)
Theorem T1c_fee_capped : forall amount p,
  0 <= amount -> p <= 100 -> 0 <= sellerGets amount p.
Proof.
  intros amount p H1 H2. unfold sellerGets.
  pose proof (commission_le_amount amount p H1 H2). lia.
Qed.

(* ============ I3: GUARDED DEBIT — баланс не уходит в минус ============ *)
(* TS: db.user.updateMany({ where: { lumenBalance: { gte: cost } }, ...}) *)

Definition guardedDebit (balance cost : Z) : option Z :=
  if ((0 <=? cost) && (cost <=? balance)) then Some (balance - cost) else None.

Theorem T3_nonneg_after_debit : forall b c r,
  guardedDebit b c = Some r -> 0 <= r /\ r <= b.
Proof.
  intros b c r H. unfold guardedDebit in H.
  destruct ((0 <=? c) && (c <=? b)) eqn:E.
  - apply andb_true_iff in E. destruct E as [E1 E2].
    apply Z.leb_le in E1. apply Z.leb_le in E2.
    injection H as H. subst. lia.
  - discriminate.
Qed.

(* ============ D-19 / A5-2: примитив refundVar и печать денег ========== *)

(* Текущий примитив: guard'ы проверяют существование/владельца/тип,      *)
(* но сумму возврата ничем не сверяют (эквивалентно: вернёт requested)   *)
Definition refundVar_current (spend requested : Z) : Z := requested.

(* МАШИННО ПОДТВЕРЖДЁННАЯ НАХОДКА: инвариант "возврат <= spend" ЛОМАЕТСЯ *)
Theorem T_D19_violation : exists spend requested,
  0 < spend /\ spend < refundVar_current spend requested.
Proof. exists 100, 250. unfold refundVar_current. lia. Qed.

(* Фикс D-19 (одна строка: cost := original.lumens): инвариант ДОКАЗАН   *)
Definition refundVar_fixed (spend requested : Z) : Z := spend.

Theorem T_D19_fixed : forall spend requested,
  refundVar_fixed spend requested <= spend.
Proof. intros spend requested. unfold refundVar_fixed. lia. Qed.

(* ============ I5: HASH-CHAIN — окно верификации и генезис ============ *)
(* Hh — стенд-ин для SHA-256 (детерминированная функция):                *)
(* сменить payload, сохранив поле h, невозможно «бесплатно» — это и есть  *)
(* тампер-модель A5.                                                      *)

Definition Hh (prev payload : Z) : Z := 3 * prev + 7 * payload + 11.

Record entry := mkE { pay : Z; h : Z }.

(* генезис: prevHash = 0, payload = 42 → h = 3*0+7*42+11 = 305 *)
Definition e1_genesis : entry := mkE 42 305.
(* ТАМПЕР генезиса: payload подменён на 999, поле h оставлено прежним (305) *)
Definition e1_tampered : entry := mkE 999 305.
(* хвост цепочки согласован с оригинальным генезисом *)
Definition e2 : entry := mkE 5 (3 * 305 + 7 * 5 + 11).
Definition e3 : entry := mkE 7 (3 * (3 * 305 + 7 * 5 + 11) + 7 * 7 + 11).

(* текущий verifyChain: пары с i=1 — генезис НЕ пересчитывается *)
Definition verifyChain_current (a b c : entry) : bool :=
  (h b =? Hh (h a) (pay b)) && (h c =? Hh (h b) (pay c)).

(* фиксированный verifyChain (D-27): первая запись сверяется с якорем *)
Definition verifyChain_fixed (a b c : entry) (prevHash : Z) : bool :=
  (h a =? Hh prevHash (pay a)) &&
  (h b =? Hh (h a) (pay b)) &&
  (h c =? Hh (h b) (pay c)).

(* НАХОДКА A5-3 МАШИННО ПОДТВЕРЖДЕНА: тампер генезиса ПРОХОДИТ текущую верификацию *)
Theorem T_I5_current_blind_to_genesis :
  verifyChain_current e1_tampered e2 e3 = true.
Proof.
  unfold verifyChain_current, e1_tampered, e2, e3, Hh, h, pay.
  vm_compute. reflexivity.
Qed.

(* Фикс D-27: тот же тампер ЛОВИТСЯ (сверка первой записи с якорем 0) *)
Theorem T_I5_fixed_detects_genesis_tamper :
  verifyChain_fixed e1_tampered e2 e3 0 = false.
Proof.
  unfold verifyChain_fixed, e1_tampered, e2, e3, Hh, h, pay.
  vm_compute. reflexivity.
Qed.

(* Фикс не даёт ложных срабатываний: оригинальная цепочка проходит *)
Theorem T_I5_fixed_accepts_intact :
  verifyChain_fixed e1_genesis e2 e3 0 = true.
Proof.
  unfold verifyChain_fixed, e1_genesis, e2, e3, Hh, h, pay.
  vm_compute. reflexivity.
Qed.

(* ======================= ИТОГ ДЛЯ ОТЧЁТА ============================= *)
(* T1a/T1b/T1c, T3, T_D19_fixed, T_I5_fixed_* — УНИВЕРСАЛЬНЫЕ гарантии:    *)
(*   верны для всех значений, а не для выборки (de Bruijn criterion).      *)
(* T_D19_violation, T_I5_current_blind_to_genesis — машинные репродукции   *)
(* находок R2-A5: нарушение воспроизводится конструктивно, без тестов.     *)
(* Проверено ядром Coq/Rocq 8.20.1; независимая перепроверка — coqchk.     *)
