# BIZON — ОБУЧЕНИЕ ПО РЕПОЗИТОРИЯМ ВЛАДЕЛЬЦА (REPO-LEARNING)
Дата: 19.09.2026 (trace 1a0b87e426236205) · Формат: карточки §2 GITHUB-ENGINEERING-PROTOCOL-v2
Изучено: README/схемы/методики 5 репозиториев. Вердикт по каждому: СИЛЬНЕЕ/ДОПОЛНЯЕТ/НЕ ПРИМЕНЯЕМ + куда встраиваем.

---

## ГЛАВНЫЙ ВЫВОД ДЛЯ ВЛАДЕЛЬЦА
Наша текущая аудиторская система (grep-гейты unlazy + §21-отчёты + adversarial-наборы) —
хорошая, но **уязвима к self-confirmation** (исполнитель сам ставит DONE) и не доказывает
ПОКРЫТИЕ (что проверили всё). Методика **cloudflare/security-audit-skill объективно сильнее**
в трёх местах: (1) hunter ≠ verifier ≠ final-verification (три независимых взгляда),
(2) coverage-ledger (каждая единица поверхности либо покрыта, либо честно deferred),
(3) статус-модель confirmed/needs_validation/rejected с привязкой к trust boundary —
«нет границы и конкретного результата — это НЕ находка». Принимаю её КАРКАСОМ повторного
аудита. Остальные четыре — усилители отдельных фаз. Rocq — не ежедневный инструмент,
а способ формализовать инварианты денежного ядра.

---

## 1. cloudflare/security-audit-skill — ВЕРДИКТ: СИЛЬНЕЕ, ПРИНИМАЕМ КАРКАСОМ
- REFERENCE_PATTERN: 6-фазный аудит: Reconnaissance (карта границ доверия + coverage-ledger) →
  Coverage-led hunting waves (изолированные hunter-агенты по единицам покрытия) →
  Candidate validation (свежий verifier на каждого кандидата) → Structured output (findings.json
  по схеме, валидатор) → Independent record verification (ещё раз свежими агентами) →
  Target-neutral report. Профили quick/standard/deep, бюджет в агент-вызовах.
- WHY_IT_EXISTS: self-review и «чек-листные сканы» дают шум и ложные READY; схема устраняет
  обе беды: разделение ролей и счётное покрытие.
- WHEN_IT_WORKS: аудит кодовой базы целиком/по волнам; спорные находки; бюджетирование.
- WHEN_IT_FAILS: слишком дорог для каждого коммита; требует песочницы для исполнения таргета.
- BIZON_APPLICATION (ПРИНЯТО): (а) флот повторного аудита = hunting waves с 7 методиками;
  (б) находка получает статус confirmed только после перекрёстной проверки верификатором;
  (в) findings.json + coverage-ledger как артефакты; (г) антипаттерны №1/№5/№8 включены в
  промпты аудиторов (чек-лист ≠ уязвимость; self-impact ≠ нарушение границы; повторное
  подтверждение не анкерить).
- BIZON_REJECTION_REASON: полный sandbox-контур (write-isolation по дескрипторам) — избыточен
  в текущей песочнице; берём методику и артефакты, без 10-шаговой процедуры promotion.

## 2. The-PR-Agent/pr-agent — ВЕРДИКТ: ДОПОЛНЯЕТ (фаза code-review)
- REFERENCE_PATTERN: структурированное ревью по категориям (/review: can be broken? tests?
  security? code quality?; /improve: конкретные патчи), PR-compression (сжатие контекста
  без потери важных частей), JSON-промпты, ответы машиночитаемы.
- WHY: ловит «review-слепоту» — изменение выглядит рабочим, но ломает контракт/тесты.
- BIZON_APPLICATION: промпт аудитора A2 (code-review) — фиксированные категории вопросов
  к каждому модулю + машиночитаемые находки (таблица file:line/severity/category).
  Compression = скоуп-листы модулей на аудитора, вместо «проверь всё».
- REJECTION_REASON: сам демон не нужен — у нас нет PR-потока (trunk-based).

## 3. semgrep/semgrep — ВЕРДИКТ: ДОПОЛНЯЕТ (методика правил; бинарник — needs_validation)
- REFERENCE_PATTERN: правила «паттерн → сообщение → severity», taint-mode (source→sink),
  CI-интеграция, тысячи готовых правил (OWASP, secrets, dangerous APIs).
- WHY: дёшево находит известные классы ошибок без понимания логики.
- BIZON_APPLICATION: переносим МЕТОДИКУ в rg-правила для аудитора A1 (static-security):
  eval/exec/child_process, dangerouslySetInnerHTML/innerHTML, $queryRaw с интерполяцией,
  hardcoded secrets, weak crypto, `http://`-вызовы, missing await (floating promises).
- REJECTION_REASON: полный semgrep в песочнице — питон-тулчейн + сотни мегабайт; попытка
  запуска помечена needs_validation, не блокирует аудит.

## 4. github/codeql — ВЕРДИКТ: ДОПОЛНЯЕТ (dataflow-методика; CLI лицензионно ограничен)
- REFERENCE_PATTERN: база кода как запросимая БД; dataflow-запросы source→sink с sanitizer;
  «путь атаки» как первоклассный результат (path queries).
- WHY: ловит сквозные уязвимости, невидимые grep'ом (user input → SQL/eval/redirect).
- BIZON_APPLICATION: методика для аудитора A4 (dataflow/authz): вручную прослеживаем пути
  req→getUserFromRequest→db по API-роутам: IDOR (чужой id без owner-проверки), mass
  assignment (spread req.json() в db), missing auth, missing rate-limit. Формат находки =
  путь: source → … → sink → граница → результат.
- REJECTION_REASON: CodeQL CLI нельзя легально применить к закрытому коду без лицензии
  GitHub Advanced Security; в песочнице недоступен.

## 5. rocq-prover/rocq (ex-Coq) — ВЕРДИКТ: СПЕЦИАЛИЗИРОВАННОЕ ПРИМЕНЕНИЕ (инварианты денег)
- REFERENCE_PATTERN: интерактивный доказатель теорем: формальная модель (inductive types,
  функции) + теоремы инвариантов + машинно-проверяемое доказательство. Rocq — актуальное
  имя (Coq → Rocq, currentness §18 соблюдён).
- WHY_IT_EXISTS: математическая гарантия свойств (сохранение суммы, отсутствие double-spend).
- WHEN_IT_WORKS: ядро с деньгами/протоколами, где цена ошибки = деньги.
- WHEN_IT_FAILS: CRUD-платформы; оверхед доказательств >> пользы.
- BIZON_APPLICATION: формальная СПЕЦИФИКАЦИЯ инвариантов в виде теорем-комментариев +
  property-тесты bun (машинная проверка того же инварианта на конечных данных):
  (I1) computeSplit: commission+sellerGets == amount, оба ≥0, floor;
  (I2) эскроу: hold+release+refund == 0 нетто-утечек, release одноразов (idempotent);
  (I3) баланс никогда < 0; (I4) ledger: сумма кредитов = сумма дебетов по транзакции;
  (I5) hash-chain: verifyChain(tamper)=false. Auditor A5 это проверяет.
- REJECTION_REASON: полный Rocq-тулчейн в песочнице не разворачиваем (сборка OCaml, часы);
  окупится только при создании реального платёжного ядра — зафиксировано на будущее.
- **КОРРЕКТИРОВКА 19.09.2026 (ROCQ-DEEP-STUDY, trace 1a0b8be5d560e4e9): REJECTION ОТМЕНЁН.**
  Тулчейн поднят за ~5 мин без root (apt-get download coq + dpkg -x + локальный findlib-conf);
  инварианты I1/I3 доказаны машинно, находки A5-2/A5-3 воспроизведены машинно, фиксы
  D-19/D-27 доказаны как теоремы (docs/knowledge/ROCQ-DEEP-STUDY-2026-09-19.md,
  модель docs/knowledge/rocq/BizonInvariants.v, coqchk-перепроверка зелёная).

## КАК ЭТО СОБИРАЕТСЯ ВО ФЛОТ ПОВТОРНОГО АУДИТА (7 аудиторов)
| # | Роль | Источник методики | Скоуп |
|---|---|---|---|
| A1 | Static-security | semgrep-методика (rg-правила) | src/**: dangerous APIs, secrets, crypto, SQL |
| A2 | Code-review | pr-agent-категории | ядро: auth, lumen, store, governance, intro, jobs |
| A3 | Red-team (промпт владельца) | adversarial-традиция BizON | «доказать что ломается», тесты-репродукции, ничего не чинить |
| A4 | Dataflow/Authz | codeql-методика (source→sink) | API-роуты: IDOR, mass assignment, auth, rate-limit |
| A5 | Formal-invariants | rocq-методика + property-тесты | денежное ядро: split/escrow/ledger/hash-chain |
| A6 | Product-wiring | AUD-1/AUD-2 (наша, подтверждена) | UI→API проводка, fake success, мёртвый код, demo-данные |
| A7 | Security-compliance | Инструкция владельца (5 правил) | нулевое доверие, шифрование PII, eval/innerHTML, SQL |
Модератор (я): сливаю находки в findings-реестр, каждая проходит верификацию (fresh
verifier-логика cloudflare-скилла): confirmed — только перепроверенные; needs_validation —
с конкретным блокером; rejected — с причиной. Итог = консолидированный отчёт повторного аудита.
