# МЁРТВЫЙ КОД — реестр удалений (обновляется постоянно)

> **Назначение.** Единый журнал всего кода, который мы удаляем из платформы, с резервной копией
> каждого файла. Цель: ничего не потерять. Если удаление оказалось лишним — код восстанавливается
> отсюда одной командой, без археологии по git-истории.

## Правила ведения (обязательны для агента)

1. **Каждое удаление кода → запись в этом файле в тот же сеанс.** Не «потом», не «в worklog» — worklog хронология, здесь резервные копии.
2. Запись обновляется **до или сразу после** удаления; файл без записи здесь считается потерянным.
3. Обязательные поля записи: **дата-время, git-коммит, релиз системы** (брать из `VERSION` на момент удаления), **задача** (Task ID из worklog), **причина удаления** с доказательством (не «кажется лишним»), **полный код файла** в свернутом блоке.
4. Удаление считается законным только при доказательстве мёртвости: 0 живых импортов по всему дереву (проверено grep до удаления), либо маршруты/модели, которых нет в сборке/схеме, либо разовые tmp-скрипты с 0 ссылок.
5. Пустые директории записываются списком (копировать нечего).
6. **Восстановление:** скопировать код из блока резервной копии, либо `git show <КОММИТ>^:<путь> > <путь>`. После восстановления — прогнать гейты (tsc/lint/test) и сделать запись «восстановлено» в этой строке таблицы.
7. Реестр живёт в `docs/DELETED-CODE.md`, в git; при релизе (обновлении `VERSION`) в свод включается число записей/строк за период.

## Индекс удалённого

| Запись | Дата | Коммит | Релиз | Файл | Строк | Причина (кратко) |
|---|---|---|---|---|---|---|
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/follows/route.ts` | 114 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/components/common/follow-button.tsx` | 169 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/research/insights/route.ts` | 59 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/research/tests/route.ts` | 49 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/research/tests/[key]/route.ts` | 164 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/components/research/research-view.tsx` | 608 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/search/unified/route.ts` | 74 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/lib/services/unified-search-service.ts` | 1223 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/components/shell/unified-search-panel.tsx` | 286 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/hr/[id]/reviews/route.ts` | 85 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/placements/[id]/review/route.ts` | 113 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/components/hr/my-placements-card.tsx` | 300 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/components/feed/one-thought-mode.tsx` | 245 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/feed/thoughts/route.ts` | 37 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `src/app/api/projects/[id]/confirm/route.ts` | 281 | мёртвая параллельная линия (модели не существовали в схеме) |
| №001 | 2026-09-17 | c51a00d | 1.2.0-honest-pilot | `scripts/a9-confirm-test.ts` | 262 | мёртвая параллельная линия (модели не существовали в схеме) |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `src/components/profile/public-persona.tsx` | 1210 | 0 импортов PublicPersona во всём дереве |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `src/components/colleague-inquiries/colleague-inquiry-dialog.tsx` | 213 | цепочка: импортировался только из public-persona |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `src/components/jobs/compare-vacancies.tsx` | 526 | 0 импортов, кнопка не рендерится нигде |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `src/components/jobs/search-job-card-v2.tsx` | 277 | «v2 для /search» никогда не подключена |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `src/hooks/use-pwa.ts` | 164 | 0 вызовов usePWA и экспортов |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `scripts/tmp-10b-service-verify.ts` | 135 | разовый tmp-скрипт прогона 10-b |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `scripts/tmp-10b-verify.py` | 107 | разовый tmp-скрипт прогона 10-b |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `scripts/tmp-9b-dbcount.ts` | 17 | разовый tmp-скрипт прогона 9-b |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `scripts/tmp-9g-inspect.cjs` | 22 | разовый tmp-скрипт прогона 9-g |
| №002 | 2026-09-17 | 83d43d5 | 1.2.0-honest-pilot | `scripts/tmp-9g-inspect2.cjs` | 10 | разовый tmp-скрипт прогона 9-g |
| №003 | 2026-09-19 | d8a0057 | 1.1.1-pilot-ready | `src/app/api/hr/[id]/reviews/route.ts` | 85 | повторное удаление после отката песочницы: модели HrReview нет в схеме → роут 500 |
| №003 | 2026-09-19 | d8a0057 | 1.1.1-pilot-ready | `src/app/api/placements/[id]/review/route.ts` | 113 | повторное удаление после отката песочницы: модели HrReview нет в схеме → роут 500 |
| №004 | 2026-09-19 | d8a0057 | 1.1.1-pilot-ready | `src/components/profile/public-persona.tsx` | 1358 | повторное удаление (№002): мёртвый контейнер, 0 живых импортов; живые части перенесены в trust-chain-block.tsx / message-compose-dialog.tsx / common-contacts-block.tsx |
| №005 | 2026-09-19 | d8a0057 | 1.1.1-pilot-ready | `src/components/trust/bizcard-dialog.tsx` | 129 | замена на персистную визитку (W5-2, OWNER-UX-PLAN): единственный потребитель старого stateless POST /api/me/bizcard был сам диалог — оба переписаны (новый: `src/components/bizcard/bizcard-dialog.tsx`) |

---

## Запись №001 — карантин «мёртвой параллельной линии» (16 файлов)

- **Дата:** 2026-09-17 08:08 UTC
- **Коммит:** `c51a00d` (удаление из рабочего дерева)
- **Релиз системы:** 1.2.0-honest-pilot
- **Задача:** projects-finish-17-09 (worklog)
- **Причина:** обнаружен пласт ~16 файлов мёртвой параллельной линии (домены «подписки», «research», «единый поиск», «отзывы на HR/платформу», «режим одной мысли», «подтверждение проекта»), ссылающихся на модели Prisma, которых **никогда не существовало в схеме** (подтверждено `git log -S`). Честный `tsc --incremental false` давал 94 ошибки, из них этот пласт — основная часть. Живого UI-входа к этим файлам не было.
- **Доказательство:** `git log -S` по именам моделей; гейты после удаления tsc=0/lint=0/76-76; каталог роутов 297→288.
- **Доп. копия:** папка `bizon-recovery/legacy-quarantine-2026-09-17/` (те же файлы в исходном виде).

### src/app/api/follows/route.ts (114 строк)

<details><summary>Резервная копия кода (114 строк)</summary>

```ts
// BizON API — /api/follows (A15, STUBS-AUDIT-2026-09-10)
//
// Односторонние подписки на авторов ленты (модель Follow: followerId/followingId,
// @@unique — подписка не требует взаимности и не создаёт контакт, в отличие от Connection).
//
//   POST   { userId }     → подписаться   (422 — на себя, 409 — дубль, 404 — нет юзера)
//   DELETE ?userId=       → отписаться    (404 — подписки нет)
//   GET                   → список моих подписок (id/name/title/avatarUrl/ipScore/followedAt)
//
// Auth: обязательна (withRoute). Валидация — inline zod (общий validation.ts не расширяется).
import { z } from 'zod';
import { db } from '@/lib/db';
import { json, withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const followSchema = z.object({
  userId: z.string().trim().min(1).max(64),
});

// === POST — подписаться на автора ===
export const POST = withRoute(
  async (_req, ctx) => {
    const me = ctx.user!;
    const { userId } = ctx.data as { userId: string };

    // Guard: подписка на себя запрещена
    if (userId === me.id) {
      return json({ error: 'Нельзя подписаться на себя' }, 422);
    }

    const target = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, title: true, avatarUrl: true },
    });
    if (!target) return json({ error: 'Пользователь не найден' }, 404);

    // Guard: дубль (явный 409 с понятным текстом; P2002 страхует гонку)
    const existing = await db.follow.findUnique({
      where: { followerId_followingId: { followerId: me.id, followingId: userId } },
    });
    if (existing) {
      return json({ error: 'Вы уже подписаны на этого автора' }, 409);
    }

    await db.follow.create({
      data: { followerId: me.id, followingId: userId },
    });

    return json({ ok: true, following: target }, 201);
  },
  {
    schema: followSchema,
    rateLimit: { key: 'follows-create', limit: 30, windowMs: 60_000 },
  },
);

// === DELETE — отписаться от автора (?userId=) ===
// userId приходит в QUERY (DELETE ?userId=); withRoute валидирует схемой body
// для DELETE, поэтому query валидируем inline той же zod-схемой.
export const DELETE = withRoute(
  async (req, ctx) => {
    const me = ctx.user!;
    const url = new URL(req.url);
    const parsed = followSchema.safeParse({ userId: url.searchParams.get('userId') ?? '' });
    if (!parsed.success) {
      return json({ error: 'Укажите userId в query-параметре (?userId=...)' }, 400);
    }
    const { userId } = parsed.data;

    const existing = await db.follow.findUnique({
      where: { followerId_followingId: { followerId: me.id, followingId: userId } },
    });
    if (!existing) {
      return json({ error: 'Подписка не найдена' }, 404);
    }

    await db.follow.delete({ where: { id: existing.id } });
    return json({ ok: true });
  },
  {
    rateLimit: { key: 'follows-delete', limit: 30, windowMs: 60_000 },
  },
);

// === GET — список моих подписок (для кнопок и раздела «Подписки на авторов») ===
export const GET = withRoute(async (_req, ctx) => {
  const me = ctx.user!;

  const follows = await db.follow.findMany({
    where: { followerId: me.id },
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      createdAt: true,
      following: {
        select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true },
      },
    },
  });

  return json({
    items: follows.map((f) => ({
      id: f.following.id, // id автора — для навигации в профиль
      followId: f.id, // id записи Follow — для отладки/отписки напрямую
      name: f.following.name,
      title: f.following.title,
      avatarUrl: f.following.avatarUrl,
      ipScore: f.following.ipScore,
      followedAt: f.createdAt.toISOString(),
    })),
    total: follows.length,
  });
});
```

</details>

### src/components/common/follow-button.tsx (169 строк)

<details><summary>Резервная копия кода (169 строк)</summary>

```tsx
// BizON — FollowButton (A15, STUBS-AUDIT-2026-09-10)
//
// Кнопка «Подписаться» / «Вы подписаны» на автора поста или профиля.
//   • Источник состояния — GET /api/follows (одна загрузка на страницу,
//     разделяется всеми инстансами кнопки через module-level store).
//   • Переключение — POST /api/follows { userId } / DELETE /api/follows?userId=.
//   • Оптимистичный UI: состояние меняется сразу, при ошибке — откат + toast.
//   • На себя кнопка не рендерится. Тач-цель ≥ 44px.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { UserPlus, Check } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

// ============================================================================
// === Module-level store подписок (разделяется всеми кнопками на странице) ===
// ============================================================================

const EMPTY_SET: ReadonlySet<string> = new Set<string>();
const listeners = new Set<() => void>();
let followingIds: ReadonlySet<string> = EMPTY_SET;
let loadPromise: Promise<void> | null = null;
let loaded = false;

function emit() {
  for (const l of listeners) l();
}

function ensureLoaded() {
  if (loaded || loadPromise) return;
  loadPromise = api<{ items: Array<{ id: string }> }>('/api/follows')
    .then((res) => {
      followingIds = new Set(res.items.map((i) => i.id));
      loaded = true;
      emit();
    })
    .catch(() => {
      // Тихо: считаем, что подписок нет — кнопки работают через POST/DELETE
      loaded = true;
    })
    .finally(() => {
      loadPromise = null;
    });
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  ensureLoaded();
  return () => {
    listeners.delete(listener);
  };
}

function getSnapshot(): ReadonlySet<string> {
  return followingIds;
}

function getServerSnapshot(): ReadonlySet<string> {
  return EMPTY_SET;
}

async function followUser(userId: string): Promise<void> {
  await api('/api/follows', { method: 'POST', body: JSON.stringify({ userId }) });
  followingIds = new Set(followingIds);
  (followingIds as Set<string>).add(userId);
  emit();
}

async function unfollowUser(userId: string): Promise<void> {
  await api(`/api/follows?userId=${encodeURIComponent(userId)}`, { method: 'DELETE' });
  followingIds = new Set(followingIds);
  (followingIds as Set<string>).delete(userId);
  emit();
}

// ============================================================================
// === Кнопка ===
// ============================================================================

interface FollowButtonProps {
  /** ID автора, на которого подписываемся */
  authorId: string;
  /** Имя автора — для тостов и aria-label */
  authorName?: string;
  /** icon-only (для компактного режима ленты) */
  iconOnly?: boolean;
  /** Дополнительные классы */
  className?: string;
}

export function FollowButton({ authorId, authorName, iconOnly = false, className }: FollowButtonProps) {
  const user = useAppStore((s) => s.user);
  const ids = React.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const [optimistic, setOptimistic] = React.useState<boolean | null>(null);
  const [pending, setPending] = React.useState(false);

  // Все хуки — до раннего выхода (правила хуков)
  if (!user || user.id === authorId) return null;

  const following = optimistic ?? ids.has(authorId);
  const name = authorName || 'автором';

  async function handleToggle() {
    if (pending) return;
    const next = !following;
    setOptimistic(next); // оптимистичный UI
    setPending(true);
    try {
      if (next) {
        await followUser(authorId);
        toast({ title: `Вы подписались на ${name}`, description: 'Его посты появятся в «Избранных новостях»' });
      } else {
        await unfollowUser(authorId);
        toast({ title: `Вы отписались от ${name}` });
      }
      setOptimistic(null); // синхронно со снапшотом
    } catch (e: any) {
      setOptimistic(null); // откат
      toast({ title: 'Ошибка', description: e?.message ?? 'Не удалось изменить подписку', variant: 'destructive' });
    } finally {
      setPending(false);
    }
  }

  if (iconOnly) {
    return (
      <button
        type="button"
        onClick={handleToggle}
        disabled={pending}
        aria-pressed={following}
        aria-label={following ? `Вы подписаны на ${name}` : `Подписаться на ${name}`}
        title={following ? 'Вы подписаны' : 'Подписаться'}
        className={cn(
          'inline-flex items-center justify-center min-h-[44px] min-w-[44px] rounded-md transition',
          following
            ? 'text-primary hover:bg-accent'
            : 'text-muted-foreground hover:text-foreground hover:bg-accent',
          pending && 'opacity-60',
          className,
        )}
      >
        {following ? <Check className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
      </button>
    );
  }

  return (
    <Button
      type="button"
      size="sm"
      variant={following ? 'secondary' : 'outline'}
      onClick={handleToggle}
      disabled={pending}
      aria-pressed={following}
      className={cn(
        'min-h-[44px] gap-1.5 rounded-full px-3 font-medium',
        following && 'border-transparent',
        className,
      )}
    >
      {following ? <Check className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
      {following ? 'Вы подписаны' : 'Подписаться'}
    </Button>
  );
}
```

</details>

### src/app/api/research/insights/route.ts (59 строк)

<details><summary>Резервная копия кода (59 строк)</summary>

```ts
// BizON API — GET /api/research/insights
// ИИ-профиль пользователя: агрегат всех пройденных тестов «Исследования».
// Потребители (контрольные данные для других систем):
//   - AI Co-Pilot: подмешивает contextText в системный промпт;
//   - Профиль: карточка «ИИ-профиль» (своё — видно, объяснимо);
//   - «Работа» → «Исследовать»: приглашение пройти опросник, пока данных мало.
// Честность: provider каждой интерпретации сохранён ('llm' | 'heuristic') и
// отдаётся как есть — UI не выдаёт эвристику за AI.
import { db } from '@/lib/db';
import { withRoute, json } from '@/lib/api-helpers';
import { RESEARCH_TESTS, getResearchTest, topScales, type ResearchScores } from '@/lib/research-tests';

export const runtime = 'nodejs';

export const GET = withRoute(async (_req, ctx) => {
  const user = ctx.user!;

  const results = await db.researchResult.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: 'desc' },
  });

  const items = results.map((r) => {
    const test = getResearchTest(r.testKey);
    let scores: ResearchScores = {};
    try {
      scores = JSON.parse(r.scores) as ResearchScores;
    } catch {
      scores = {};
    }
    const scaleById = new Map(test?.scales.map((s) => [s.id, s]));
    return {
      testKey: r.testKey,
      testTitle: test?.title ?? r.testKey,
      summary: r.summary,
      provider: r.provider,
      scores,
      top: topScales(scores, 3).map((t) => ({
        id: t.id,
        value: t.value,
        label: scaleById.get(t.id)?.label ?? t.id,
        meaning: scaleById.get(t.id)?.meaning ?? '',
      })),
      updatedAt: r.updatedAt.toISOString(),
    };
  });

  const contextText = items.length > 0
    ? items.map((i) => `${i.testTitle}: ${i.summary}`).join('\n')
    : '';

  return json({
    completedCount: items.length,
    totalTests: RESEARCH_TESTS.length,
    ready: items.length === RESEARCH_TESTS.length,
    items,
    contextText,
  });
});
```

</details>

### src/app/api/research/tests/route.ts (49 строк)

<details><summary>Резервная копия кода (49 строк)</summary>

```ts
// BizON API — GET /api/research/tests
// «Исследование» (Волна D, запрос владельца 2026-09-11): список тестов-опросников
// и статус прохождения для текущего пользователя. Сами вопросы лежат в статическом
// банке src/lib/research-tests.ts (общий для клиента и сервера) — сюда ответы не ходят.
import { db } from '@/lib/db';
import { withRoute, json } from '@/lib/api-helpers';
import { RESEARCH_TESTS, type ResearchScores } from '@/lib/research-tests';

export const runtime = 'nodejs';

export const GET = withRoute(async (_req, ctx) => {
  const user = ctx.user!;

  const results = await db.researchResult.findMany({ where: { userId: user.id } });
  const byKey = new Map(results.map((r) => [r.testKey, r]));

  return json({
    tests: RESEARCH_TESTS.map((t) => {
      const r = byKey.get(t.key);
      let top: Array<{ id: string; label: string; value: number }> = [];
      if (r) {
        try {
          const scores = JSON.parse(r.scores) as ResearchScores;
          top = Object.entries(scores)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 3)
            .map(([id, value]) => ({
              id,
              value,
              label: t.scales.find((s) => s.id === id)?.label ?? id,
            }));
        } catch {
          // повреждённый JSON — трактуем как «результатов нет»
        }
      }
      return {
        key: t.key,
        title: t.title,
        description: t.description,
        timeHint: t.timeHint,
        questionsCount: t.questions.length,
        completed: !!r,
        completedAt: r ? r.updatedAt.toISOString() : null,
        provider: r ? r.provider : null,
        top,
      };
    }),
  });
});
```

</details>

### src/app/api/research/tests/[key]/route.ts (164 строк)

<details><summary>Резервная копия кода (164 строк)</summary>

```ts
// BizON API — POST /api/research/tests/[key]
// Сохранение ответов теста «Исследования» (Волна D, запрос владельца 2026-09-11).
//
// Конвейер честности:
//   1) ответы валидируются на сервере (каждый вопрос отвечен, каждый optionId
//      существует в банке вопросов) — клиенту не доверяем;
//   2) очки считаются детерминированной локальной логикой (computeResearchScores);
//   3) интерпретация — LLM через ЕДИНЫЙ шлюз AIGateway (rate limit, кэш,
//      Sovereignty-минимизация; PII не отправляем — только ответы и шкалы);
//      если LLM недоступен — локальная эвристика, provider='heuristic';
//   4) результат upsert-ится (пересдача заменяет прежний результат).
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute, json, errorJson } from '@/lib/api-helpers';
import {
  getResearchTest,
  computeResearchScores,
  heuristicSummary,
  type ResearchScores,
} from '@/lib/research-tests';
import { AIGateway } from '@/lib/ai-core';
import { getZaiClient } from '@/lib/ai-core/zai-client';

export const runtime = 'nodejs';

const bodySchema = z
  .object({
    answers: z
      .array(z.object({ qId: z.string().min(1), optionId: z.string().min(1) }))
      .min(1)
      .max(20),
  })
  .strip();

type Interpretation = { summary: string; provider: 'llm' | 'heuristic' };

/** LLM-интерпретация: возвращает строку-резюме или null (→ fallback эвристики). */
async function callInterpretationLlm(testTitle: string, answerLines: string, scoreLines: string): Promise<string | null> {
  const zai = await getZaiClient();
  if (!zai) return null;
  const system =
    'Ты — исследовательский модуль профессиональной платформы BizON. ' +
    'По ответам человека на тест и нормированным шкалам напиши краткую интерпретацию (3-5 предложений, по-русски, «вы»-обращение): ' +
    'что для человека важно, чем он живёт, что ищет, и 1-2 практических следствия для подбора работы. ' +
    'Без оценочных суждений, без выдуманных фактов, опирайся только на ответы и шкалы. ' +
    'Ответь ТОЛЬКО валидным JSON вида {"summary": "..."} без markdown.';
  const user = `Тест: «${testTitle}»\n\nОтветы:\n${answerLines}\n\nШкалы (0-100%):\n${scoreLines}`;
  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
      thinking: { type: 'disabled' },
      temperature: 0.5,
      max_tokens: 400,
    });
    const text = String(completion?.choices?.[0]?.message?.content ?? '').trim();
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) return null;
    const parsed = JSON.parse(m[0]) as { summary?: unknown };
    if (typeof parsed.summary !== 'string' || parsed.summary.trim().length < 30) return null;
    return parsed.summary.trim().slice(0, 1200);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error(`[research/interpret] LLM error: ${msg.slice(0, 200)}`);
    return null;
  }
}

export const POST = withRoute<{ key: string }>(
  async (_req, ctx) => {
    const user = ctx.user!;
    const { key } = ctx.params;

    const test = getResearchTest(key);
    if (!test) return errorJson('Тест не найден', 404);

    const { answers } = ctx.data as { answers: Array<{ qId: string; optionId: string }> };

    // 1. Валидация ответов: каждый вопрос ровно один раз, каждый вариант существует
    const questionIds = new Set(test.questions.map((q) => q.id));
    const validOptionIds = new Set(test.questions.flatMap((q) => q.options.map((o) => o.id)));
    const seenQ = new Set<string>();
    for (const a of answers) {
      if (!questionIds.has(a.qId) || !validOptionIds.has(a.optionId)) {
        return errorJson('Ответ не соответствует вопросам этого теста', 422);
      }
      if (seenQ.has(a.qId)) return errorJson('На один вопрос дано несколько ответов', 422);
      seenQ.add(a.qId);
    }
    if (seenQ.size !== test.questions.length) {
      return errorJson(`Отвечены не все вопросы: ${seenQ.size} из ${test.questions.length}`, 422);
    }

    // 2. Детерминированные очки (0..100 по каждой шкале)
    const { scores } = computeResearchScores(test, answers);

    // 3. Интерпретация через единый AI-шлюз (fallback — честная эвристика)
    const answerLines = test.questions
      .map((q) => {
        const chosen = answers.find((a) => a.qId === q.id)?.optionId;
        const opt = q.options.find((o) => o.id === chosen);
        return `Q: ${q.text}\nA: ${opt?.text ?? ''}`;
      })
      .join('\n');
    const scoreLines = test.scales
      .map((s) => `- ${s.label}: ${scores[s.id]}% (${s.meaning})`)
      .join('\n');

    const gw = await AIGateway.run<Interpretation>({
      userId: user.id,
      operation: 'research.interpret',
      fields: [], // PII не отправляем: только ответы теста и нормированные шкалы
      priority: 'normal',
      cacheTtlMs: 60 * 60 * 1000,
      data: { test: test.title, scores },
      payload: { key, choices: answers.map((a) => a.optionId).join(',') },
      llm: async () => {
        const summary = await callInterpretationLlm(test.title, answerLines, scoreLines);
        return summary ? { summary, provider: 'llm' as const } : null;
      },
      fallback: () => ({ summary: heuristicSummary(test, scores), provider: 'heuristic' as const }),
    });
    const interpretation: Interpretation =
      gw?.value ?? { summary: heuristicSummary(test, scores), provider: 'heuristic' };

    // 4. Upsert: пересдача заменяет прежний результат
    const saved = await db.researchResult.upsert({
      where: { userId_testKey: { userId: user.id, testKey: key } },
      create: {
        userId: user.id,
        testKey: key,
        answers: JSON.stringify(answers),
        scores: JSON.stringify(scores),
        summary: interpretation.summary,
        provider: interpretation.provider,
      },
      update: {
        answers: JSON.stringify(answers),
        scores: JSON.stringify(scores),
        summary: interpretation.summary,
        provider: interpretation.provider,
      },
    });

    return json({
      result: {
        testKey: saved.testKey,
        scores,
        summary: saved.summary,
        provider: saved.provider,
        completedAt: saved.updatedAt.toISOString(),
      },
    });
  },
  {
    schema: bodySchema,
    rateLimit: { key: 'research-submit', limit: 20, windowMs: 60 * 60 * 1000 },
  },
);

// Тип экспортируется только для документации контракта (не для runtime)
export type ResearchScoresContract = ResearchScores;
```

</details>

### src/components/research/research-view.tsx (608 строк)

<details><summary>Резервная копия кода (608 строк)</summary>

```tsx
// BizON — «Исследование» (Волна D, запрос владельца 2026-09-11)
//
// Зачем модуль пользователю: это место, где ИИ BizON изучает человека.
// Три коротких теста-опросника:
//   1) «Профессиональный ориентир» — подбор профессии;
//   2) «Предпочтения в работе» — условия, формат, среда;
//   3) «Внутренние мотиваторы» — нематериальные критерии («души желания»),
//      которые нельзя вытащить из резюме: смысл, свобода, признание,
//      мастерство, близость, уверенность.
// Результаты — контрольные данные для других систем платформы: подбор работы,
// AI Co-Pilot, карьерный агент. Если пользователь сам не рассказывает о себе —
// система предлагает опросник (приглашение в режиме «Исследовать» и в профиле).
//
// Честность: интерпретация помечается «ИИ» или «Локальная» (provider llm/heuristic).
// Все данные реальные: ответы, очки, даты. Пересдача заменяет прежний результат.
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';
import {
  FlaskConical, ClipboardList, Heart, Compass as CompassIcon, CheckCircle2,
  Loader2, ChevronLeft, ChevronRight, Sparkles, RotateCcw, Eye, BrainCircuit,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { RESEARCH_TESTS, getResearchTest, type ResearchTest, type ResearchTestKey, type ResearchScores } from '@/lib/research-tests';

// ============================================================================
// Типы ответов API
// ============================================================================

interface TestStatus {
  key: ResearchTestKey;
  title: string;
  description: string;
  timeHint: string;
  questionsCount: number;
  completed: boolean;
  completedAt: string | null;
  provider: string | null;
  top: Array<{ id: string; label: string; value: number }>;
}

interface InsightItem {
  testKey: string;
  testTitle: string;
  summary: string;
  provider: string;
  scores: ResearchScores;
  top: Array<{ id: string; value: number; label: string; meaning: string }>;
  updatedAt: string;
}

interface Insights {
  completedCount: number;
  totalTests: number;
  ready: boolean;
  items: InsightItem[];
  contextText: string;
}

const TEST_ICONS: Record<ResearchTestKey, React.ReactNode> = {
  profession: <CompassIcon className="w-5 h-5 text-primary" />,
  preferences: <ClipboardList className="w-5 h-5 text-primary" />,
  motivators: <Heart className="w-5 h-5 text-primary" />,
};

// ============================================================================
// Главный экран «Исследование»
// ============================================================================

export function ResearchView() {
  const [tests, setTests] = React.useState<TestStatus[] | null>(null);
  const [insights, setInsights] = React.useState<Insights | null>(null);
  const [activeTest, setActiveTest] = React.useState<ResearchTest | null>(null);
  const [resultFor, setResultFor] = React.useState<TestStatus | null>(null);

  const load = React.useCallback(async () => {
    try {
      const [t, i] = await Promise.all([
        api<{ tests: TestStatus[] }>('/api/research/tests'),
        api<Insights>('/api/research/insights'),
      ]);
      setTests(t.tests);
      setInsights(i);
    } catch {
      setTests([]);
      setInsights({ completedCount: 0, totalTests: RESEARCH_TESTS.length, ready: false, items: [], contextText: '' });
    }
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const completedCount = tests?.filter((t) => t.completed).length ?? 0;

  return (
    <div className="space-y-4 w-full min-w-0">
      {/* Заголовок */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <FlaskConical className="w-6 h-6 text-primary" /> Исследование
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Короткие тесты, через которые ИИ BizON понимает вас: что вы ищете, какие у вас предпочтения
          и что для вас важно кроме профессии. Результаты делают подбор работы и советы ассистента точнее.
        </p>
      </div>

      {/* Прогресс */}
      {tests && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Пройдено {completedCount} из {tests.length}</span>
              {insights?.ready && (
                <Badge className="bg-success/15 text-success-text border-transparent">
                  <CheckCircle2 className="w-3 h-3 mr-1" /> ИИ-профиль заполнен
                </Badge>
              )}
            </div>
            <Progress value={tests.length > 0 ? (completedCount / tests.length) * 100 : 0} className="h-2" />
          </CardContent>
        </Card>
      )}

      {/* «Что BizON понял о вас» — агрегат по пройденным тестам */}
      {insights && insights.items.length > 0 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <BrainCircuit className="w-4 h-4 text-primary" /> Что BizON понял о вас
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {insights.items.map((item) => (
              <div key={item.testKey}>
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="text-sm font-semibold">{item.testTitle}</span>
                  <ProviderBadge provider={item.provider} />
                </div>
                <p className="text-sm text-foreground/85">{item.summary}</p>
                <Separator className="my-3" />
              </div>
            ))}
            <p className="text-xs text-muted-foreground">
              Эти данные BizON использует при подборе вакансий и в AI-ассистенте. Пересдать тест можно в любой момент —
              прежний результат заменится.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Карточки тестов */}
      {!tests ? (
        <div className="space-y-3">
          <Skeleton className="h-28 w-full rounded-xl" />
          <Skeleton className="h-28 w-full rounded-xl" />
          <Skeleton className="h-28 w-full rounded-xl" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {tests.map((t) => (
            <Card key={t.key} className={cn('flex flex-col', t.completed && 'border-success/40')}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  {TEST_ICONS[t.key] ?? <ClipboardList className="w-5 h-5 text-primary" />}
                  {t.completed ? (
                    <Badge variant="outline" className="text-xs border-success/40 text-success-text">
                      <CheckCircle2 className="w-3 h-3 mr-1" /> Пройден
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="text-xs">Не пройден</Badge>
                  )}
                </div>
                <CardTitle className="text-base leading-snug">{t.title}</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col gap-3">
                <p className="text-sm text-muted-foreground flex-1">{t.description}</p>
                <p className="text-xs text-muted-foreground">{t.timeHint}</p>

                {t.completed && t.top.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {t.top.map((s) => (
                      <Badge key={s.id} variant="secondary" className="text-[11px]">
                        {s.label} {s.value}%
                      </Badge>
                    ))}
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant={t.completed ? 'outline' : 'default'}
                    className="flex-1"
                    onClick={() => setActiveTest(getResearchTest(t.key) ?? null)}
                  >
                    {t.completed ? <><RotateCcw className="w-3.5 h-3.5 mr-1" /> Пересдать</> : 'Пройти тест'}
                  </Button>
                  {t.completed && (
                    <Button size="sm" variant="ghost" onClick={() => setResultFor(t)} aria-label="Посмотреть результат">
                      <Eye className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Диалог прохождения теста */}
      {activeTest && (
        <TestFlowDialog
          test={activeTest}
          onClose={() => setActiveTest(null)}
          onSaved={() => { load(); }}
        />
      )}

      {/* Диалог результата (просмотр сохранённого) */}
      <ResultDialog result={resultFor} onClose={() => setResultFor(null)} />
    </div>
  );
}

// ============================================================================
// Проходка теста: один вопрос на экран, прогресс, сохранение
// ============================================================================

function TestFlowDialog({ test, onClose, onSaved }: {
  test: ResearchTest;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [index, setIndex] = React.useState(0);
  const [answers, setAnswers] = React.useState<Record<string, string>>({});
  const [submitting, setSubmitting] = React.useState(false);
  const [savedResult, setSavedResult] = React.useState<{ summary: string; provider: string; scores: ResearchScores } | null>(null);

  const q = test.questions[index];
  const total = test.questions.length;
  const chosen = answers[q?.id ?? ''];
  const answeredAll = test.questions.every((qq) => answers[qq.id]);
  const isLast = index === total - 1;

  function reset() {
    setIndex(0);
    setAnswers({});
    setSubmitting(false);
    setSavedResult(null);
  }

  async function submit() {
    setSubmitting(true);
    try {
      const payload = {
        answers: test.questions.map((qq) => ({ qId: qq.id, optionId: answers[qq.id] })),
      };
      const res = await api<{ result: { summary: string; provider: string; scores: ResearchScores } }>(
        `/api/research/tests/${test.key}`,
        { method: 'POST', body: JSON.stringify(payload) },
      );
      setSavedResult(res.result);
      toast({ title: 'Результат сохранён', description: 'ИИ BizON обновил понимание того, что вам нужно' });
      onSaved();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Не удалось сохранить результат';
      toast({ title: 'Ошибка', description: msg, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  }

  function handleClose() {
    onClose();
    // сброс после закрытия — диалог размонтируется родителем
    reset();
  }

  return (
    <Dialog open onOpenChange={(o) => { if (!o) handleClose(); }}>
      <DialogContent className="max-w-lg">
        {savedResult ? (
          // --- Экран результата ---
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-success-text" /> Готово: {test.title}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <ProviderBadge provider={savedResult.provider} />
                <span className="text-xs text-muted-foreground">Сохранено в ИИ-профиль</span>
              </div>
              <p className="text-sm leading-relaxed">{savedResult.summary}</p>
              <ScoreBars scores={savedResult.scores} test={test} limit={4} />
              <Button className="w-full" onClick={handleClose}>Хорошо</Button>
            </div>
          </>
        ) : (
          // --- Прохождение ---
          <>
            <DialogHeader>
              <DialogTitle className="text-base">{test.title}</DialogTitle>
            </DialogHeader>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Вопрос {index + 1} из {total}</span>
                <span>{test.timeHint}</span>
              </div>
              <Progress value={((index + 1) / total) * 100} className="h-1.5" />
            </div>

            <p className="text-sm font-medium leading-snug">{q.text}</p>

            <div className="space-y-2" role="radiogroup" aria-label={q.text}>
              {q.options.map((opt) => {
                const selected = chosen === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    role="radio"
                    aria-checked={selected}
                    onClick={() => setAnswers((prev) => ({ ...prev, [q.id]: opt.id }))}
                    className={cn(
                      'w-full text-left px-3.5 py-3 min-h-[48px] rounded-lg border transition text-sm',
                      selected
                        ? 'border-primary bg-primary/10 font-medium'
                        : 'border-border bg-card hover:border-primary/50 hover:bg-accent/40',
                    )}
                  >
                    {opt.text}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center justify-between gap-2 pt-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIndex((i) => Math.max(0, i - 1))}
                disabled={index === 0 || submitting}
              >
                <ChevronLeft className="w-4 h-4 mr-0.5" /> Назад
              </Button>
              {isLast ? (
                <Button size="sm" onClick={submit} disabled={!answeredAll || submitting}>
                  {submitting
                    ? <><Loader2 className="w-4 h-4 mr-1 animate-spin" /> Сохраняем…</>
                    : <><Sparkles className="w-4 h-4 mr-1" /> Завершить</>}
                </Button>
              ) : (
                <Button
                  size="sm"
                  onClick={() => setIndex((i) => Math.min(total - 1, i + 1))}
                  disabled={!chosen || submitting}
                >
                  Далее <ChevronRight className="w-4 h-4 ml-0.5" />
                </Button>
              )}
            </div>
            {!answeredAll && isLast && (
              <p className="text-xs text-muted-foreground -mt-1">
                {total - Object.keys(answers).length > 0
                  ? `Осталось ответить: ${total - Object.keys(answers).length}.`
                  : ''}
              </p>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// Просмотр сохранённого результата (кнопка «глаз»)
// ============================================================================

function ResultDialog({ result, onClose }: { result: TestStatus | null; onClose: () => void }) {
  const [insights, setInsights] = React.useState<Insights | null>(null);

  React.useEffect(() => {
    if (!result) { setInsights(null); return; }
    api<Insights>('/api/research/insights')
      .then(setInsights)
      .catch(() => setInsights(null));
  }, [result]);

  const item = insights?.items.find((i) => i.testKey === result?.key);
  const test = result ? getResearchTest(result.key) : null;

  return (
    <Dialog open={!!result} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-base">Результат: {result?.title}</DialogTitle>
        </DialogHeader>
        {!insights ? (
          <Skeleton className="h-32 w-full" />
        ) : item ? (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <ProviderBadge provider={item.provider} />
              <span className="text-xs text-muted-foreground">
                Пройден {new Date(item.updatedAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}
              </span>
            </div>
            <p className="text-sm leading-relaxed">{item.summary}</p>
            {test && <ScoreBars scores={item.scores} test={test} limit={4} />}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Результат не найден. Пересдайте тест.</p>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// Мелкие общие блоки
// ============================================================================

function ProviderBadge({ provider }: { provider: string }) {
  return provider === 'llm' ? (
    <Badge variant="secondary" className="text-xs gap-1">
      <Sparkles className="w-3 h-3 text-primary" /> ИИ-интерпретация
    </Badge>
  ) : (
    <Badge variant="outline" className="text-xs text-muted-foreground">
      Локальная интерпретация
    </Badge>
  );
}

function ScoreBars({ scores, test, limit }: { scores: ResearchScores; test: ResearchTest; limit?: number }) {
  const scaleById = new Map(test.scales.map((s) => [s.id, s]));
  const rows = Object.entries(scores)
    .map(([id, value]) => ({ id, value, scale: scaleById.get(id) }))
    .filter((r) => !!r.scale)
    .sort((a, b) => b.value - a.value)
    .slice(0, limit ?? 4);
  return (
    <div className="space-y-2">
      {rows.map((r) => (
        <div key={r.id}>
          <div className="flex items-center justify-between text-xs mb-0.5">
            <span className="font-medium">{r.scale!.label}</span>
            <span className="text-muted-foreground tabular-nums">{r.value}%</span>
          </div>
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: `${r.value}%` }} />
          </div>
          <p className="text-[11px] text-muted-foreground mt-0.5">{r.scale!.meaning}</p>
        </div>
      ))}
    </div>
  );
}

// ============================================================================
// Приглашение к исследованию (режим «Исследовать» в «Работе»)
// Показываем, пока ИИ-профиль не заполнен: «если человек сам о себе не
// рассказывает — система предлагает опросник». Когда ready → компактная строка.
// ============================================================================

let _insightsCache: { data: Insights | null; ts: number } | null = null;

export function ResearchInviteCard() {
  const setView = useAppStore((s) => s.setView);
  const [insights, setInsights] = React.useState<Insights | null>(_insightsCache?.data ?? null);
  const [loading, setLoading] = React.useState(!_insightsCache);

  React.useEffect(() => {
    if (_insightsCache && Date.now() - _insightsCache.ts < 60_000) {
      setInsights(_insightsCache.data);
      setLoading(false);
      return;
    }
    api<Insights>('/api/research/insights')
      .then((data) => {
        _insightsCache = { data, ts: Date.now() };
        setInsights(data);
      })
      .catch(() => setInsights(null))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !insights) return null;

  if (insights.ready) {
    return (
      <div className="rounded-lg border border-success/30 bg-success/5 px-3 py-2.5 flex items-center gap-2 flex-wrap">
        <CheckCircle2 className="w-4 h-4 text-success-text shrink-0" />
        <span className="text-xs text-foreground/85 flex-1 min-w-0">
          Поиск учитывает результаты вашего исследования — подбираем по вашим акцентам.
        </span>
        <Button size="sm" variant="ghost" className="h-8 text-xs" onClick={() => setView('research')}>
          Открыть исследование
        </Button>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
      <div className="flex items-start gap-3">
        <FlaskConical className="w-5 h-5 text-primary mt-0.5 shrink-0" />
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium">
            Исследование: пройдено {insights.completedCount} из {insights.totalTests}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5 mb-2">
            Три коротких теста — и BizON поймёт, какую работу вам искать и что для вас важно кроме профессии.
            Это делает «Исследовать» полезным: подбор строится по вам, а не по словам.
          </p>
          <Button size="sm" onClick={() => setView('research')}>
            Пройти исследование · ~10 минут
          </Button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// Карточка «ИИ-профиль» в профиле (только свой)
// ============================================================================

export function ResearchProfileCard() {
  const setView = useAppStore((s) => s.setView);
  const [insights, setInsights] = React.useState<Insights | null>(null);
  const [expanded, setExpanded] = React.useState(false);

  React.useEffect(() => {
    api<Insights>('/api/research/insights')
      .then(setInsights)
      .catch(() => setInsights(null));
  }, []);

  if (!insights || insights.items.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <BrainCircuit className="w-4 h-4 text-primary" /> ИИ-профиль
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            ИИ BizON ещё мало знает о вас. Три коротких теста расскажут, что вы ищете, чем живёте
            и что для вас важно — подбор станет заметно точнее.
          </p>
          <Button size="sm" onClick={() => setView('research')}>
            <FlaskConical className="w-4 h-4 mr-1" /> Пройти исследование
          </Button>
        </CardContent>
      </Card>
    );
  }

  const shown = expanded ? insights.items : insights.items.slice(0, 2);

  return (
    <Card className="border-primary/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <BrainCircuit className="w-4 h-4 text-primary" /> ИИ-профиль
          <Badge variant="secondary" className="ml-1">
            {insights.completedCount}/{insights.totalTests}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {shown.map((item) => (
          <div key={item.testKey}>
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="text-sm font-semibold">{item.testTitle}</span>
              <ProviderBadge provider={item.provider} />
            </div>
            <p className="text-sm text-foreground/85 line-clamp-3">{item.summary}</p>
          </div>
        ))}
        {insights.items.length > 2 && (
          <Button variant="ghost" size="sm" onClick={() => setExpanded((e) => !e)}>
            {expanded ? 'Свернуть' : `Показать все (${insights.items.length})`}
          </Button>
        )}
        <Button size="sm" variant="outline" onClick={() => setView('research')}>
          <FlaskConical className="w-4 h-4 mr-1" />
          {insights.ready ? 'Открыть исследование' : 'Продолжить исследование'}
        </Button>
      </CardContent>
    </Card>
  );
}
```

</details>

### src/app/api/search/unified/route.ts (74 строк)

<details><summary>Резервная копия кода (74 строк)</summary>

```ts
// BizON API — GET /api/search/unified (Wave C, GPT master-plan §17)
// Единый поисковый конвейер: understanding → retrieval → ranking → explanation.
//
// Auth — как у остальных поисковых роутов. Rate limit: 60 запросов/час на
// пользователя (панель быстрых результатов с debounce 350ms на клиенте).
//
// Параметры:
//   q     — поисковый запрос (минимум 2 символа, иначе 400)
//   types — опционально: CSV доменов (job,person,company,project,event,community,post).
//           Если не задан — домены определяет understanding (по ключевым словам запроса).
//
// Ответ: { query, understanding: { entities, slots, detectedTypes },
//          results: { jobs, people, companies, projects, events, communities, posts },
//          total, tookMs }
// Пустые домены возвращаются честными пустыми массивами.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';
import {
  UnifiedSearchService,
  UNIFIED_ENTITY_TYPES,
  type UnifiedEntityType,
} from '@/lib/services/unified-search-service';

export const runtime = 'nodejs';

const RATE_LIMIT_MAX = 60;
const RATE_LIMIT_WINDOW_MS = 60 * 60 * 1000; // 1 час
const MIN_QUERY_LENGTH = 2;

export async function GET(req: NextRequest) {
  // 1. Auth — как в /api/search и /api/users/search
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // 2. Rate limit per-user
  const rl = checkUserRateLimit(user.id, 'search:unified', RATE_LIMIT_MAX, RATE_LIMIT_WINDOW_MS);
  if (!rl.allowed) {
    return json(
      { error: `Слишком много поисковых запросов. Повторите через ${rl.retryAfter} секунд.`, retryAfter: rl.retryAfter },
      429,
    );
  }

  // 3. Параметры
  const q = req.nextUrl.searchParams.get('q')?.trim() ?? '';
  if (q.length < MIN_QUERY_LENGTH) {
    return errorJson(`Минимум ${MIN_QUERY_LENGTH} символа для поиска`, 400);
  }

  // types — опциональный фильтр доменов; неизвестное значение → 422 (строгая валидация)
  let types: UnifiedEntityType[] | undefined;
  const typesRaw = req.nextUrl.searchParams.get('types')?.trim();
  if (typesRaw) {
    const parts = typesRaw.split(',').map((t) => t.trim()).filter(Boolean);
    const invalid = parts.filter((p) => !(UNIFIED_ENTITY_TYPES as readonly string[]).includes(p));
    if (invalid.length > 0) {
      return errorJson(
        `Неизвестный тип поиска: ${invalid.join(', ')}. Допустимо: ${UNIFIED_ENTITY_TYPES.join(', ')}`,
        422,
      );
    }
    types = parts as UnifiedEntityType[];
  }

  // 4. Конвейер
  try {
    const response = await UnifiedSearchService.search({ query: q, viewerId: user.id, types });
    return json(response);
  } catch (e) {
    console.error('[/api/search/unified] error:', e);
    return errorJson('Поисковый конвейер не смог обработать запрос. Попробуйте ещё раз.', 500);
  }
}
```

</details>

### src/lib/services/unified-search-service.ts (1223 строк)

<details><summary>Резервная копия кода (1223 строк)</summary>

```ts
// BizON v6 — Unified Search Service (Wave C, GPT master-plan §17)
// ============================================================
// Единый поисковый конвейер: понимание → извлечение → ранжирование → объяснение.
//
// Принципы BizON:
//  - «только реальные данные»: всё строится из живых таблиц БД, без заглушек.
//  - Детерминизм честно помечен: понимание запроса — это словари и regex
//    (не LLM, никакого «магического AI»); каждая причина — воспроизводимый факт.
//  - REUSE-first: парсер интента и синонимы навыков переиспользованы из
//    semantic-search-service (SkillSynonym + фолбэк-словарь), приватность —
//    из lib/privacy (canViewProfileSync). Словари НЕ дублируются.
//
// Конвейер:
//  1. Understanding: parseIntent (роль/навыки/город/зарплата/грейд/индустрия)
//     + детерминированное определение типов сущностей по ключевым словам
//     («вакансия» → jobs, «компания» → companies, «найти разработчика» → люди+вакансии).
//  2. Retrieval: параллельные Promise.all-запросы по доменам, топ-8 на домен
//     до ранжирования; навыки расширяются синонимами (SkillSynonym + фолбэк).
//  3. Ranking: объяснимая формула на домен. Для вакансий — те же факторы, что
//     в semantic-search-service (0.5 навыки + 0.3 роль + 0.1 локация + 0.1
//     зарплата + бонус доверия); для остальных доменов — свои веса с причинами.
//  4. Explanation: у КАЖДОГО результата — причина на русском (совпавший навык
//     с уровнем доказательности, город, название и т.п.).

import { db } from '@/lib/db';
import { Prisma } from '@prisma/client';
import {
  SemanticSearchService,
  expandSynonyms,
  getAdjacentRoles,
  type SearchIntent,
} from '@/lib/services/semantic-search-service';
import { canViewProfileSync } from '@/lib/privacy';

// ---------- Публичные типы (используются и роутом, и UI через import type) ----------

export const UNIFIED_ENTITY_TYPES = [
  'person',
  'job',
  'company',
  'project',
  'event',
  'community',
  'post',
] as const;

export type UnifiedEntityType = (typeof UNIFIED_ENTITY_TYPES)[number];

export type UnifiedUnderstanding = {
  // Найденные в запросе сущности: слоты парсера + ключевые слова типов.
  entities: Array<{ type: string; value: string; source: 'parser' | 'keyword' }>;
  // Извлечённые слоты (детерминированный парсер semantic-search-service).
  slots: {
    role: string | null;
    skills: string[];
    location: string | null;
    remote: boolean | null;
    salaryMin: number | null;
    seniority: string | null;
    industry: string | null;
    workFormat: string | null;
  };
  // Какие домены будут искаться (по ключевым словам; без сигналов — все).
  detectedTypes: UnifiedEntityType[];
};

export type UnifiedPersonItem = {
  id: string;
  name: string;
  title: string | null;
  location: string | null;
  avatarUrl: string | null;
  ipScore: number;
  level: string;
  accountType: string;
  matchedSkills: Array<{ name: string; verificationLevel: string }>;
  score: number;
  reason: string;
};

export type UnifiedJobItem = {
  id: string;
  title: string;
  company: string;
  location: string | null;
  salaryFrom: number | null;
  salaryTo: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string | null;
  verificationStatus: string;
  matchedSkills: string[];
  score: number;
  reason: string;
};

export type UnifiedCompanyItem = {
  id: string;
  name: string;
  industry: string | null;
  location: string | null;
  size: string | null;
  logoUrl: string | null;
  adTrustIndex: number;
  score: number;
  reason: string;
};

export type UnifiedProjectItem = {
  id: string;
  title: string;
  status: string;
  tags: string[];
  ownerName: string | null;
  score: number;
  reason: string;
};

export type UnifiedEventItem = {
  id: string;
  title: string;
  category: string;
  format: string;
  startDate: string;
  location: string | null;
  score: number;
  reason: string;
};

export type UnifiedCommunityItem = {
  id: string;
  name: string;
  slug: string;
  category: string;
  membersCount: number;
  score: number;
  reason: string;
};

export type UnifiedPostItem = {
  id: string;
  contentPreview: string;
  authorName: string | null;
  authorAvatarUrl: string | null;
  tags: string[];
  createdAt: string;
  score: number;
  reason: string;
};

export type UnifiedSearchResults = {
  jobs: UnifiedJobItem[];
  people: UnifiedPersonItem[];
  companies: UnifiedCompanyItem[];
  projects: UnifiedProjectItem[];
  events: UnifiedEventItem[];
  communities: UnifiedCommunityItem[];
  posts: UnifiedPostItem[];
};

export type UnifiedSearchResponse = {
  query: string;
  understanding: UnifiedUnderstanding;
  results: UnifiedSearchResults;
  total: number;
  tookMs: number;
};

// ---------- Детерминированные словари понимания запроса ----------

// Ключевые слова типов сущностей. Тестируются по сырому lowercase-запросу.
// Кириллические «\b» не работают в JS — везде lookbehind/lookahead (см. v6.1).
const TYPE_KEYWORDS: Array<[UnifiedEntityType, RegExp]> = [
  ['person', /(?<![a-zа-яё])(человек[а-яё]*|люд[а-яё]*|специалист[а-яё]*|эксперт[а-яё]*|коллег[а-яё]*|кандидат[а-яё]*|ментор[а-яё]*|наставник[а-яё]*|фрилансер[а-яё]*|подрядчик[а-яё]*|профессионал[а-яё]*)/i],
  ['job', /(?<![a-zа-яё])(ваканси[а-яё]*|работ[а-яё]*|трудоустройств[а-яё]*|нанять|найм[а-яё]*|подработк[а-яё]*)/i],
  ['company', /(?<![a-zа-яё])(компани[а-яё]*|фирм[а-яё]*|организац[а-яё]*|работодател[а-яё]*|агентств[а-яё]*)/i],
  ['project', /(?<![a-zа-яё])(проект[а-яё]*|стартап[а-яё]*|команд[а-яё]*)/i],
  ['event', /(?<![a-zа-яё])(событи[а-яё]*|мероприят[а-яё]*|конференц[а-яё]*|митап[а-яё]*|meetup|вебинар[а-яё]*|хакатон[а-яё]*|воркшоп[а-яё]*|workshop|встреч[а-яё]*)/i],
  ['community', /(?<![a-zа-яё])(сообществ[а-яё]*|групп[а-яё]*|клуб[а-яё]*|чат[а-яё]*|community)/i],
  ['post', /(?<![a-zа-яё])(пост[а-яё]*|стат[а-яё]*|публикаци[а-яё]*|обсуждени[а-яё]*|новост[а-яё]*)/i],
];

// Слова-профессии: запрос вида «найти разработчика» → ищем и людей, и вакансии.
const ROLE_NOUNS = /(?<![a-zа-яё])(разработчик|программист|инженер|дизайнер|аналитик|менеджер|маркетолог|тестировщик|devops|qa|директор|руководител|архитектор|специалист|юрист|бухгалтер|экономист|повар|преподавател|строител|verificat|developer|engineer|designer|analyst|manager|architect)(?![a-zа-яё])/i;

// Русско-латинские профессиональные соответствия. В БД встречаются тайтлы
// на двух языках («Frontend Developer» и «Шеф-повар»), поэтому роль из
// запроса на русском должна находить и латинские тайтлы. Детерминированный
// словарь — часть объяснимого пайплайна, НЕ «AI».
const ROLE_TRANSLATIONS: Record<string, string[]> = {
  'разработчик': ['developer', 'engineer', 'программист'],
  'программист': ['developer', 'engineer', 'разработчик'],
  'инженер': ['engineer', 'разработчик'],
  'дизайнер': ['designer', 'ui/ux'],
  'аналитик': ['analyst', 'analytics'],
  'менеджер': ['manager'],
  'маркетолог': ['marketing', 'growth'],
  'архитектор': ['architect'],
  'тестировщик': ['qa', 'tester', 'quality'],
};

// Служебные слова, которые не должны участвовать в матчинге имён/названий.
const STOP_TOKENS = new Set([
  'найти', 'искать', 'ищу', 'ищем', 'нужен', 'нужна', 'нужно', 'хочу', 'мне',
  'все', 'всё', 'для', 'как', 'что', 'или', 'и', 'в', 'на', 'с', 'по', 'от', 'до', 'за',
]);

const SENIORITY_RU: Record<string, string> = {
  junior: 'джуниор',
  middle: 'мидл',
  senior: 'сеньор',
  lead: 'лид',
};

const WORK_FORMAT_RU: Record<string, string> = {
  remote: 'удалённо',
  hybrid: 'гибрид',
  onsite: 'офис',
};

const VERIFICATION_LEVEL_RU: Record<string, string> = {
  claimed: 'заявлен',
  verified: 'подтверждён',
  project_verified: 'подтверждён проектом',
  expert_verified: 'подтверждён экспертом',
};

// ---------- Детерминированные хелперы ----------

/**
 * Мини-стеммер для русских словоформ (детерминированный, без библиотек).
 * «разработчика» → «разработчик», «Москве» → «москв», «аналитика» → «аналитик».
 * Отрезаем распространённые окончания, но не короче 5 символов.
 */
function ruStem(word: string): string {
  const w = word.toLowerCase();
  const suffixes = [
    'иями', 'ами', 'ями', 'ого', 'его', 'ому', 'ему', 'ых', 'их', 'ым', 'им',
    'ов', 'ев', 'ей', 'ой', 'ый', 'ий', 'ая', 'яя', 'ые', 'ие', 'ом', 'ем',
    'ах', 'ях', 'ам', 'ям', 'а', 'я', 'ы', 'и', 'е', 'у', 'ю', 'ь',
  ];
  for (const s of suffixes) {
    if (w.length - s.length >= 5 && w.endsWith(s)) return w.slice(0, w.length - s.length);
  }
  return w;
}

/** Токены запроса: слова ≥2 символов без служебных. */
function tokenize(query: string): string[] {
  return query
    .toLowerCase()
    .split(/[^a-zа-яё0-9]+/i)
    .map((t) => t.trim())
    .filter((t) => t.length >= 2 && !STOP_TOKENS.has(t));
}

/** Варианты токена для LIKE-поиска: SQLite `contains` регистрочувствителен к кириллице. */
function caseVariants(token: string): string[] {
  const lower = token.toLowerCase();
  const capped = lower.charAt(0).toUpperCase() + lower.slice(1);
  return lower === capped ? [lower] : [lower, capped];
}

/** Форматирование денег честным Intl (детерминированно). */
function formatMoney(n: number, currency: string | null): string {
  const symbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : '₽';
  return `${new Intl.NumberFormat('ru-RU').format(Math.round(n))} ${symbol}`;
}

function pluralRu(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

/**
 * Термины роли для матчинга тайтлов: стемы слов роли + смежные роли
 * (переиспользован граф ADJACENT_ROLE_GRAPH из semantic-search-service)
 * + русско-латинские соответствия (ROLE_TRANSLATIONS).
 */
function buildRoleTerms(intent: SearchIntent): string[] {
  const out = new Set<string>();
  if (intent.role) {
    for (const word of intent.role.toLowerCase().split(/\s+/)) {
      if (word.length < 3 || STOP_TOKENS.has(word)) continue;
      const stem = ruStem(word);
      out.add(stem);
      // Переводы ищем и по словоформе, и по стему («разработчика» → «разработчик»)
      for (const t of ROLE_TRANSLATIONS[word] ?? ROLE_TRANSLATIONS[stem] ?? []) out.add(t.toLowerCase());
    }
    // Смежные роли из готового графа (REUSE): «разработчик» → «software engineer»…
    for (const adjacent of getAdjacentRoles(intent.role)) {
      out.add(adjacent.toLowerCase());
      for (const w of adjacent.toLowerCase().split(/[\s-]+/)) {
        if (w.length >= 4) out.add(w);
      }
    }
  }
  return [...out].filter((t) => t.length >= 3);
}

/** Совпадает ли локация (стем-подход: «Москве» → «москв» ⊂ «москва»). */
function locationMatches(haystack: string | null | undefined, location: string | null): boolean {
  if (!haystack || !location) return false;
  return haystack.toLowerCase().includes(ruStem(location));
}

// ---------- Понимание запроса (Stage 1) ----------

async function buildUnderstanding(
  raw: string,
  intent: SearchIntent,
): Promise<UnifiedUnderstanding> {
  const lower = raw.toLowerCase();

  // Ключевые слова типов сущностей
  const keywordHits: Array<{ type: UnifiedEntityType; value: string }> = [];
  for (const [type, re] of TYPE_KEYWORDS) {
    const m = lower.match(re);
    if (m) keywordHits.push({ type, value: m[0].toLowerCase() });
  }

  // Слово-профессия → люди + вакансии («найти разработчика в Москве»).
  // Проверяем и словоформу, и стем: «разработчика» = «разработчик» + падежное
  // окончание, поэтому ROLE_NOUNS по сырому слову не ловит (lookahead после стема).
  const queryWords = lower.split(/[^a-zа-яё0-9]+/).filter((w) => w.length >= 3);
  const roleNounHit = queryWords.some((w) => ROLE_NOUNS.test(w) || ROLE_NOUNS.test(ruStem(w)));

  let detectedTypes: UnifiedEntityType[];
  if (keywordHits.length > 0 || roleNounHit) {
    const set = new Set<UnifiedEntityType>(keywordHits.map((k) => k.type));
    if (roleNounHit) {
      set.add('person');
      set.add('job');
    }
    detectedTypes = UNIFIED_ENTITY_TYPES.filter((t) => set.has(t));
  } else {
    // Нет явных сигналов типа («GreenAI», «React», «Москва») → ищем во всех доменах.
    detectedTypes = [...UNIFIED_ENTITY_TYPES];
  }

  // Навыки: слоты парсера (KNOWN-словарь) + точная сверка токенов с каталогом
  // навыков BizON через переиспользованный expandSynonyms (SkillSynonym + фолбэк).
  // Так «PyTorch» находится, даже если его нет в KNOWN-словаре парсера.
  const allSkills = await db.skill.findMany({ select: { id: true, name: true } });
  const catalog = allSkills.map((s) => ({ id: s.id, nameLower: s.name.toLowerCase(), name: s.name }));

  const expandedForms = new Set<string>(intent.skills);
  for (const token of tokenize(raw)) {
    const syns = await expandSynonyms(token);
    syns.forEach((s) => expandedForms.add(s));
  }
  const matchedSkillNames = catalog
    .filter((c) => expandedForms.has(c.nameLower))
    .map((c) => c.name);

  // Сущности для объяснения понимания
  const entities: UnifiedUnderstanding['entities'] = [];
  if (intent.role) entities.push({ type: 'role', value: intent.role, source: 'parser' });
  for (const name of matchedSkillNames.slice(0, 3)) {
    entities.push({ type: 'skill', value: name, source: 'parser' });
  }
  if (intent.location) entities.push({ type: 'city', value: intent.location, source: 'parser' });
  if (intent.salaryMin) {
    entities.push({ type: 'salary', value: formatMoney(intent.salaryMin, 'RUB'), source: 'parser' });
  }
  if (intent.seniority) {
    entities.push({ type: 'grade', value: SENIORITY_RU[intent.seniority] ?? intent.seniority, source: 'parser' });
  }
  if (intent.industry) entities.push({ type: 'industry', value: intent.industry, source: 'parser' });
  if (intent.workFormat) {
    entities.push({ type: 'work_format', value: WORK_FORMAT_RU[intent.workFormat] ?? intent.workFormat, source: 'parser' });
  }
  for (const k of keywordHits) {
    entities.push({ type: k.type, value: k.value, source: 'keyword' });
  }

  return {
    entities,
    slots: {
      role: intent.role,
      skills: matchedSkillNames.length > 0 ? matchedSkillNames : intent.skills.slice(0, 5),
      location: intent.location,
      remote: intent.remote,
      salaryMin: intent.salaryMin,
      seniority: intent.seniority,
      industry: intent.industry,
      workFormat: intent.workFormat,
    },
    detectedTypes,
  };
}

// ---------- Ранжирование по доменам (Stage 3) — объяснимые формулы ----------

type Scored<T> = { item: T; score: number; factors: string[] };

/** Причина = топ-факторы, соединённые в одну честную строку на русском. */
function explain(factors: string[]): string {
  return factors.slice(0, 2).join(', ');
}

// ===== Вакансии: факторы semantic-search-service (0.5+0.3+0.1+0.1+доверие) =====
type JobRow = Prisma.JobGetPayload<{ select: {
  id: true; title: true; company: true; description: true;
  requiredSkills: true; salaryFrom: true; salaryTo: true;
  salaryMin: true; salaryMax: true; currency: true;
  location: true; verificationStatus: true; vacancyTrust: true; createdAt: true;
} }>;

function scoreJob(
  job: JobRow,
  opts: {
    skillSet: Set<string>;
    expectedSkills: number;
    skillNameLowerToOriginal: Map<string, string>;
    roleTerms: string[];
    tokens: string[];
    intent: SearchIntent;
  },
): Scored<UnifiedJobItem> | null {
  const factors: string[] = [];
  const jobSkills = job.requiredSkills
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  const titleLower = job.title.toLowerCase();
  const companyLower = job.company.toLowerCase();

  let score = 0;

  // 0.5 — совпадение навыков (те же веса, что в semantic-search-service)
  const matchedRaw = jobSkills.filter((s) => opts.skillSet.has(s));
  if (matchedRaw.length > 0) {
    score += 0.5 * Math.min(1, matchedRaw.length / Math.max(1, opts.expectedSkills));
    for (const m of matchedRaw.slice(0, 3)) {
      const original = opts.skillNameLowerToOriginal.get(m) ?? m;
      factors.push(`Навык: ${original}`);
    }
  }

  // 0.3 — роль в заголовке / компания по названию / слова запроса в названии
  const roleHit = opts.roleTerms.find((t) => titleLower.includes(t));
  const tokenInCompany = opts.tokens.filter((t) => companyLower.includes(t));
  const tokenInTitle = opts.tokens.filter((t) => titleLower.includes(t));
  if (roleHit) {
    score += 0.3;
    factors.push('Роль в названии вакансии');
  } else if (tokenInCompany.length > 0) {
    score += 0.3;
    factors.push(`Компания: ${job.company}`);
  } else if (tokenInTitle.length > 0 && opts.tokens.length > 0) {
    score += 0.3 * (tokenInTitle.length / opts.tokens.length);
    factors.push('Слова запроса в названии вакансии');
  }

  // 0.1 — локация / удалёнка (как в semantic-search-service)
  if (opts.intent.remote !== null) {
    const jobRemote = job.location ? /удал[её]н|remote/i.test(job.location) : false;
    if (jobRemote === opts.intent.remote) {
      score += 0.1;
      if (jobRemote) factors.push('Удалённая работа');
    }
  } else if (job.location && locationMatches(job.location, opts.intent.location)) {
    score += 0.1;
    factors.push(`Город: ${job.location}`);
  }

  // 0.1 — зарплата (тот же порядок полей, что в semantic-search-service)
  if (opts.intent.salaryMin) {
    const jobSalary = job.salaryMax ?? job.salaryTo ?? job.salaryFrom ?? job.salaryMin ?? 0;
    if (jobSalary >= opts.intent.salaryMin) {
      score += 0.1;
      factors.push(`Зарплата от ${formatMoney(jobSalary, job.currency)}`);
    }
  }

  // бонус доверия — как в semantic-search-service (vacancyTrust × 0.05)
  if ((job.vacancyTrust ?? 0) > 0) {
    score += (job.vacancyTrust ?? 0) * 0.05;
    factors.push(`Доверие вакансии: ${Math.round((job.vacancyTrust ?? 0) * 100)}%`);
  }

  if (score < 0.1 || factors.length === 0) return null;

  return {
    item: {
      id: job.id,
      title: job.title,
      company: job.company,
      location: job.location,
      salaryFrom: job.salaryFrom,
      salaryTo: job.salaryTo,
      salaryMin: job.salaryMin,
      salaryMax: job.salaryMax,
      currency: job.currency,
      verificationStatus: job.verificationStatus,
      matchedSkills: matchedRaw.map((m) => opts.skillNameLowerToOriginal.get(m) ?? m),
      score: Math.round(Math.min(1, score) * 100) / 100,
      reason: explain(factors),
    },
    score,
    factors,
  };
}

// ===== Люди: навыки с уровнем доказательности, должность, имя, город, верификация =====
type UserRow = Prisma.UserGetPayload<{ select: {
  id: true; name: true; title: true; location: true; avatarUrl: true;
  ipScore: true; level: true; accountType: true; isVerified: true; privacyProfile: true;
  skills: { select: { verificationLevel: true; skill: { select: { name: true } } } };
} }>;

function scorePerson(
  user: UserRow,
  opts: {
    viewerId: string;
    skillCatalogIds: Map<string, string>; // nameLower → skillId
    querySkillIds: Set<string>;           // id навыков, подразумеваемых запросом
    roleTerms: string[];
    tokens: string[];
    intent: SearchIntent;
    connectedIds: Set<string>;
  },
): Scored<UnifiedPersonItem> | null {
  // --- Приватность (Wave B): private → не включать; network → только соединения.
  const access = canViewProfileSync({
    isSelf: user.id === opts.viewerId,
    privacyProfile: user.privacyProfile,
    connected: opts.connectedIds.has(user.id),
  });
  if (access !== 'full') return null;

  const factors: string[] = [];
  let score = 0;
  const titleLower = (user.title ?? '').toLowerCase();
  const nameLower = user.name.toLowerCase();

  // 0.4 — навыки (точная сверка с каталогом; уровень доказательности — из UserSkill)
  const userSkills = user.skills ?? [];
  const matchedSkills = userSkills.filter((us) => {
    const nameLowerSkill = us.skill.name.toLowerCase();
    const id = opts.skillCatalogIds.get(nameLowerSkill);
    return id ? opts.querySkillIds.has(id) : false;
  });
  if (matchedSkills.length > 0 && opts.querySkillIds.size > 0) {
    score += 0.4 * Math.min(1, matchedSkills.length / opts.querySkillIds.size);
    for (const m of matchedSkills.slice(0, 3)) {
      const levelRu = VERIFICATION_LEVEL_RU[m.verificationLevel] ?? m.verificationLevel;
      factors.push(`Найдено по навыку ${m.skill.name} (уровень: ${levelRu})`);
    }
  }

  // 0.3 — должность (роль/переводы/смежные роли из готового графа)
  const roleHit = opts.roleTerms.find((t) => titleLower.includes(t));
  if (roleHit && user.title) {
    score += 0.3;
    factors.push(`Должность: ${user.title}`);
  }

  // 0.2 — имя (токены запроса)
  const nameHits = opts.tokens.filter((t) => nameLower.includes(t));
  if (nameHits.length > 0) {
    score += 0.2;
    factors.push(`Имя: ${user.name}`);
  }

  // 0.05 — город (у части профилей локация скрыта/не указана — фактор честно 0)
  if (locationMatches(user.location, opts.intent.location)) {
    score += 0.05;
    factors.push(`Город: ${user.location}`);
  }

  // +0.05 — верификация / экспертный уровень доверия
  if (user.isVerified || user.level === 'expert') {
    score += 0.05;
    factors.push(`Верифицированный аккаунт (IP-score: ${user.ipScore})`);
  }

  if (score < 0.1 || factors.length === 0) return null;

  return {
    item: {
      id: user.id,
      name: user.name,
      title: user.title,
      location: user.location,
      avatarUrl: user.avatarUrl,
      ipScore: user.ipScore,
      level: user.level,
      accountType: user.accountType,
      matchedSkills: matchedSkills.map((m) => ({
        name: m.skill.name,
        verificationLevel: m.verificationLevel,
      })),
      score: Math.round(Math.min(1, score) * 100) / 100,
      reason: explain(factors),
    },
    score,
    factors,
  };
}

// ===== Компании: название, отрасль, описание, Ad Trust Index =====
type CompanyRow = Prisma.CompanyGetPayload<{ select: {
  id: true; name: true; description: true; logoUrl: true; industry: true;
  size: true; location: true; adTrustIndex: true; isVerified: true;
} }>;

function scoreCompany(
  company: CompanyRow,
  opts: { tokens: string[]; intent: SearchIntent },
): Scored<UnifiedCompanyItem> | null {
  const factors: string[] = [];
  let score = 0;
  const nameLower = company.name.toLowerCase();
  const descLower = company.description.toLowerCase();
  const industryLower = (company.industry ?? '').toLowerCase();

  // 0.5 — название
  const nameHits = opts.tokens.filter((t) => nameLower.includes(t));
  if (nameHits.length > 0) {
    score += 0.5;
    factors.push(`Название компании: ${company.name}`);
  }

  // 0.2 — отрасль (слот индустрии из парсера или прямое совпадение)
  const industryFromIntent = opts.intent.industry && industryLower.includes(opts.intent.industry.toLowerCase());
  const industryFromTokens = opts.tokens.some((t) => industryLower.includes(ruStem(t)) || industryLower.includes(t));
  if (industryFromIntent || industryFromTokens) {
    score += 0.2;
    if (company.industry) factors.push(`Отрасль: ${company.industry}`);
  }

  // 0.2 — описание
  const descHits = opts.tokens.filter((t) => descLower.includes(t));
  if (descHits.length > 0) {
    score += 0.2;
    factors.push('Совпадение в описании');
  }

  // 0.1 — Ad Trust Index (ТЗ 7.1): бонус пропорционален индексу
  score += Math.min(1, Math.max(0, company.adTrustIndex)) * 0.1;
  if (company.adTrustIndex > 0.5) {
    factors.push(`Ad Trust Index: ${Math.round(company.adTrustIndex * 100)}%`);
  }

  // +0.05 — верифицированная компания
  if (company.isVerified) {
    score += 0.05;
    factors.push('Верифицированная компания');
  }

  if (score < 0.1 || factors.length === 0) return null;

  return {
    item: {
      id: company.id,
      name: company.name,
      industry: company.industry,
      location: company.location,
      size: company.size,
      logoUrl: company.logoUrl,
      adTrustIndex: company.adTrustIndex,
      score: Math.round(Math.min(1, score) * 100) / 100,
      reason: explain(factors),
    },
    score,
    factors,
  };
}

// ===== Проекты: название, теги/навыки, описание, рейтинг =====
type ProjectRow = Prisma.ProjectGetPayload<{ select: {
  id: true; title: true; description: true; status: true; rating: true;
  tags: true; requiredSkills: true; visibility: true;
  owner: { select: { name: true } };
} }>;

function scoreProject(
  project: ProjectRow,
  opts: { tokens: string[]; skillSet: Set<string> },
): Scored<UnifiedProjectItem> | null {
  // Приватные проекты не ищем (visibility в БД бывает в разном регистре —
  // сверяемся без учёта регистра).
  if ((project.visibility ?? 'public').toLowerCase() === 'private') return null;

  const factors: string[] = [];
  let score = 0;
  const titleLower = project.title.toLowerCase();
  const descLower = project.description.toLowerCase();
  const tagsLower = project.tags.toLowerCase();
  const skillsLower = project.requiredSkills.toLowerCase();

  // 0.45 — название
  const titleHits = opts.tokens.filter((t) => titleLower.includes(t));
  if (titleHits.length > 0) {
    score += 0.45;
    factors.push(`Название проекта: ${project.title}`);
  }

  // 0.25 — теги / требуемые навыки
  const tagHits = opts.tokens.filter((t) => tagsLower.includes(t));
  const skillHits = [...opts.skillSet].filter((s) => skillsLower.includes(s));
  if (tagHits.length > 0 || skillHits.length > 0) {
    score += 0.25;
    factors.push(skillHits.length > 0 ? `Навык проекта: ${skillHits[0]}` : 'Совпадение в тегах');
  }

  // 0.2 — описание
  const descHits = opts.tokens.filter((t) => descLower.includes(t));
  if (descHits.length > 0) {
    score += 0.2;
    factors.push('Совпадение в описании');
  }

  // 0.1 — рейтинг проекта (только если реально выставлен)
  if (project.rating > 0) {
    score += 0.1 * Math.min(1, project.rating / 5);
    factors.push(`Рейтинг проекта: ${project.rating.toFixed(1)}`);
  }

  if (score < 0.1 || factors.length === 0) return null;

  return {
    item: {
      id: project.id,
      title: project.title,
      status: project.status,
      tags: project.tags ? project.tags.split(',').map((t) => t.trim()).filter(Boolean) : [],
      ownerName: project.owner?.name ?? null,
      score: Math.round(Math.min(1, score) * 100) / 100,
      reason: explain(factors),
    },
    score,
    factors,
  };
}

// ===== События: название, описание, категория, локация =====
type EventRow = Prisma.EventGetPayload<{ select: {
  id: true; title: true; description: true; category: true; format: true;
  startDate: true; location: true;
} }>;

const EVENT_CATEGORY_RU: Record<string, string> = {
  conference: 'конференция',
  meetup: 'митап',
  workshop: 'воркшоп',
  webinar: 'вебинар',
  hackathon: 'хакатон',
};

const EVENT_CATEGORY_KEYWORDS: Record<string, RegExp> = {
  conference: /конференц/i,
  meetup: /митап|meetup|встреч/i,
  workshop: /воркшоп|workshop|мастер-класс/i,
  webinar: /вебинар|webinar/i,
  hackathon: /хакатон|hackathon/i,
};

function scoreEvent(
  event: EventRow,
  opts: { tokens: string[]; intent: SearchIntent },
): Scored<UnifiedEventItem> | null {
  const factors: string[] = [];
  let score = 0;
  const titleLower = event.title.toLowerCase();
  const descLower = event.description.toLowerCase();

  // 0.5 — название
  const titleHits = opts.tokens.filter((t) => titleLower.includes(t));
  if (titleHits.length > 0) {
    score += 0.5;
    factors.push(`Название события: ${event.title}`);
  }

  // 0.2 — описание
  const descHits = opts.tokens.filter((t) => descLower.includes(t));
  if (descHits.length > 0) {
    score += 0.2;
    factors.push('Совпадение в описании');
  }

  // 0.15 — категория («конференция» → category: conference)
  const categoryMatched = Object.entries(EVENT_CATEGORY_KEYWORDS).find(([cat, re]) => {
    const tokenHit = opts.tokens.some((t) => re.test(t) || t === cat);
    return tokenHit;
  });
  if (categoryMatched) {
    score += 0.15;
    factors.push(`Категория: ${EVENT_CATEGORY_RU[event.category] ?? event.category}`);
  }

  // 0.15 — локация
  if (locationMatches(event.location, opts.intent.location)) {
    score += 0.15;
    factors.push(`Локация: ${event.location}`);
  }

  if (score < 0.1 || factors.length === 0) return null;

  return {
    item: {
      id: event.id,
      title: event.title,
      category: event.category,
      format: event.format,
      startDate: event.startDate.toISOString(),
      location: event.location,
      score: Math.round(Math.min(1, score) * 100) / 100,
      reason: explain(factors),
    },
    score,
    factors,
  };
}

// ===== Сообщества: название, описание, категория, размер =====
type CommunityRow = Prisma.CommunityGetPayload<{ select: {
  id: true; name: true; slug: true; description: true; category: true; membersCount: true;
} }>;

function scoreCommunity(
  community: CommunityRow,
  opts: { tokens: string[] },
): Scored<UnifiedCommunityItem> | null {
  const factors: string[] = [];
  let score = 0;
  const nameLower = community.name.toLowerCase();
  const descLower = community.description.toLowerCase();

  // 0.5 — название
  const nameHits = opts.tokens.filter((t) => nameLower.includes(t));
  if (nameHits.length > 0) {
    score += 0.5;
    factors.push(`Название сообщества: ${community.name}`);
  }

  // 0.2 — описание
  const descHits = opts.tokens.filter((t) => descLower.includes(t));
  if (descHits.length > 0) {
    score += 0.2;
    factors.push('Совпадение в описании');
  }

  // 0.15 — категория (ml / frontend / backend / devops / product / design / career)
  if (opts.tokens.some((t) => community.category === t)) {
    score += 0.15;
    factors.push(`Категория: ${community.category}`);
  }

  // 0.15 — размер сообщества (реальный счётчик участников)
  if (community.membersCount > 0) {
    score += Math.min(0.15, community.membersCount / 200);
    factors.push(
      `${community.membersCount} ${pluralRu(community.membersCount, 'участник', 'участника', 'участников')}`,
    );
  }

  if (score < 0.1 || factors.length === 0) return null;

  return {
    item: {
      id: community.id,
      name: community.name,
      slug: community.slug,
      category: community.category,
      membersCount: community.membersCount,
      score: Math.round(Math.min(1, score) * 100) / 100,
      reason: explain(factors),
    },
    score,
    factors,
  };
}

// ===== Посты: текст, теги, автор =====
type PostRow = Prisma.PostGetPayload<{ select: {
  id: true; content: true; tags: true; createdAt: true;
  author: { select: { name: true; avatarUrl: true } };
} }>;

function scorePost(
  post: PostRow,
  opts: { tokens: string[] },
): Scored<UnifiedPostItem> | null {
  const factors: string[] = [];
  let score = 0;
  const contentLower = post.content.toLowerCase();
  const tagsLower = post.tags.toLowerCase();
  const authorLower = (post.author?.name ?? '').toLowerCase();

  // 0.6 — текст поста (пропорционально доле совпавших токенов)
  const contentHits = opts.tokens.filter((t) => contentLower.includes(t));
  if (contentHits.length > 0 && opts.tokens.length > 0) {
    score += 0.6 * (contentHits.length / opts.tokens.length);
    factors.push('Совпадение в тексте поста');
  }

  // 0.25 — теги
  const tagHits = opts.tokens.filter((t) => tagsLower.includes(t));
  if (tagHits.length > 0) {
    score += 0.25;
    factors.push(`Тег: ${post.tags.split(',').map((t) => t.trim()).find((t) => tagHits.some((h) => t.toLowerCase().includes(h))) ?? tagHits[0]}`);
  }

  // 0.15 — автор
  if (post.author?.name && opts.tokens.some((t) => authorLower.includes(t))) {
    score += 0.15;
    factors.push(`Автор: ${post.author.name}`);
  }

  if (score < 0.1 || factors.length === 0) return null;

  const flat = post.content.replace(/[#*`>\[\]]/g, '').replace(/\s+/g, ' ').trim();
  const preview = flat.length > 160 ? `${flat.slice(0, 160)}…` : flat;

  return {
    item: {
      id: post.id,
      contentPreview: preview,
      authorName: post.author?.name ?? null,
      authorAvatarUrl: post.author?.avatarUrl ?? null,
      tags: post.tags ? post.tags.split(',').map((t) => t.trim()).filter(Boolean) : [],
      createdAt: post.createdAt.toISOString(),
      score: Math.round(Math.min(1, score) * 100) / 100,
      reason: explain(factors),
    },
    score,
    factors,
  };
}

// ---------- Извлечение (Stage 2) + сборка конвейера ----------

export const UnifiedSearchService = {
  /**
   * Полный конвейер: query → understanding → retrieval → ranking → explanation.
   * @param types — опциональное ограничение доменов (иначе detectedTypes из понимания).
   */
  async search(options: {
    query: string;
    viewerId: string;
    types?: UnifiedEntityType[];
  }): Promise<UnifiedSearchResponse> {
    const startedAt = Date.now();
    const raw = options.query.trim();
    const tokens = tokenize(raw);

    // ===== Stage 1: Understanding (детерминированный парсер — REUSE) =====
    const intent = await SemanticSearchService.parseIntent(raw, options.viewerId);
    const understanding = await buildUnderstanding(raw, intent);

    const wanted: UnifiedEntityType[] = options.types && options.types.length > 0
      ? options.types
      : understanding.detectedTypes;
    const want = (t: UnifiedEntityType) => wanted.includes(t);

    // Каталог навыков: точная сверка (lowercase) вместо неточного LIKE.
    const allSkills = await db.skill.findMany({ select: { id: true, name: true } });
    const skillCatalogIds = new Map(allSkills.map((s) => [s.name.toLowerCase(), s.id]));

    const expandedForms = new Set<string>(intent.skills);
    for (const token of tokens) {
      (await expandSynonyms(token)).forEach((s) => expandedForms.add(s));
    }
    const querySkillIds = new Set(
      [...expandedForms]
        .map((f) => skillCatalogIds.get(f))
        .filter((id): id is string => !!id),
    );
    const skillSet = new Set(expandedForms); // расширенные формы навыков (lowercase)
    const skillNameLowerToOriginal = new Map(
      allSkills.filter((s) => expandedForms.has(s.name.toLowerCase())).map((s) => [s.name.toLowerCase(), s.name]),
    );
    const expectedSkills = Math.max(1, querySkillIds.size);
    const roleTerms = buildRoleTerms(intent);

    // Соединения зрителя — один батч-запрос (приватность «network», Wave B).
    const connections = await db.connection.findMany({
      where: {
        OR: [{ fromUserId: options.viewerId }, { toUserId: options.viewerId }],
        status: 'accepted',
      },
      select: { fromUserId: true, toUserId: true },
    });
    const connectedIds = new Set(
      connections.flatMap((c) => [c.fromUserId, c.toUserId]).filter((id) => id !== options.viewerId),
    );

    // ===== Stage 2: Retrieval — параллельно, топ-8 на домен до ранжирования =====
    const perDomain = 8;

    // Варианты токенов для LIKE-поиска (SQLite `contains` регистрочувствителен к кириллице)
    const likeVariants = tokens.flatMap(caseVariants);

    /** OR-фрагменты по текстовым полям; W — Prisma where-тип домена. */
    function textOr<W>(fields: string[]): W[] {
      const out: unknown[] = [];
      for (const v of likeVariants) {
        for (const f of fields) out.push({ [f]: { contains: v } });
      }
      return out as W[];
    }

    const [
      jobRows,
      userRows,
      companyRows,
      projectRows,
      eventRows,
      communityRows,
      postRows,
    ] = await Promise.all([
      want('job')
        ? db.job.findMany({
            where: {
              active: true,
              // Пул как в главном разделе «Работа» (/api/jobs): active: true.
              OR: [
                ...textOr<Prisma.JobWhereInput>(['title', 'company', 'description', 'location', 'requiredSkills']),
                ...roleTerms.map((t) => ({ title: { contains: t } })),
                ...[...skillSet].map((s) => ({ requiredSkills: { contains: s } })),
              ],
            },
            orderBy: { createdAt: 'desc' },
            take: perDomain,
            select: {
              id: true, title: true, company: true, description: true,
              requiredSkills: true, salaryFrom: true, salaryTo: true,
              salaryMin: true, salaryMax: true, currency: true,
              location: true, verificationStatus: true, vacancyTrust: true, createdAt: true,
            },
          })
        : Promise.resolve([] as JobRow[]),

      want('person')
        ? db.user.findMany({
            where: {
              OR: [
                ...textOr<Prisma.UserWhereInput>(['name', 'title', 'location']),
                ...roleTerms.map((t) => ({ title: { contains: t } })),
                // Пользователи с навыками, подразумеваемыми запросом (точная сверка)
                ...(querySkillIds.size > 0
                  ? [
                      {
                        skills: {
                          some: { skillId: { in: [...querySkillIds] } },
                        },
                      },
                    ]
                  : []),
              ],
            },
            orderBy: { ipScore: 'desc' },
            take: perDomain,
            select: {
              id: true, name: true, title: true, location: true, avatarUrl: true,
              ipScore: true, level: true, accountType: true, isVerified: true, privacyProfile: true,
              skills: { select: { verificationLevel: true, skill: { select: { name: true } } } },
            },
          })
        : Promise.resolve([] as UserRow[]),

      want('company')
        ? db.company.findMany({
            where: {
              OR: textOr<Prisma.CompanyWhereInput>(['name', 'description', 'industry']),
            },
            orderBy: [{ adTrustIndex: 'desc' }, { name: 'asc' }],
            take: perDomain,
            select: {
              id: true, name: true, description: true, logoUrl: true, industry: true,
              size: true, location: true, adTrustIndex: true, isVerified: true,
            },
          })
        : Promise.resolve([] as CompanyRow[]),

      want('project')
        ? db.project.findMany({
            where: {
              OR: textOr<Prisma.ProjectWhereInput>(['title', 'description', 'tags', 'requiredSkills']),
            },
            orderBy: [{ rating: 'desc' }, { createdAt: 'desc' }],
            take: perDomain,
            select: {
              id: true, title: true, description: true, status: true, rating: true,
              tags: true, requiredSkills: true, visibility: true,
              owner: { select: { name: true } },
            },
          })
        : Promise.resolve([] as ProjectRow[]),

      want('event')
        ? db.event.findMany({
            where: {
              OR: textOr<Prisma.EventWhereInput>(['title', 'description', 'location']),
            },
            orderBy: { startDate: 'desc' },
            take: perDomain,
            select: {
              id: true, title: true, description: true, category: true, format: true,
              startDate: true, location: true,
            },
          })
        : Promise.resolve([] as EventRow[]),

      want('community')
        ? db.community.findMany({
            where: {
              visibility: 'public',
              OR: textOr<Prisma.CommunityWhereInput>(['name', 'description', 'slug']),
            },
            orderBy: { membersCount: 'desc' },
            take: perDomain,
            select: {
              id: true, name: true, slug: true, description: true, category: true, membersCount: true,
            },
          })
        : Promise.resolve([] as CommunityRow[]),

      want('post')
        ? db.post.findMany({
            where: {
              isHidden: false,
              OR: textOr<Prisma.PostWhereInput>(['content', 'tags']),
            },
            orderBy: { createdAt: 'desc' },
            take: perDomain,
            select: {
              id: true, content: true, tags: true, createdAt: true,
              author: { select: { name: true, avatarUrl: true } },
            },
          })
        : Promise.resolve([] as PostRow[]),
    ]);

    // ===== Stage 3+4: Ranking + Explanation (детерминированно, с причинами) =====
    const jobResults = jobRows
      .map((j) =>
        scoreJob(j, {
          skillSet,
          expectedSkills,
          skillNameLowerToOriginal,
          roleTerms,
          tokens,
          intent,
        }),
      )
      .filter((r): r is Scored<UnifiedJobItem> => r !== null)
      .sort((a, b) => b.score - a.score)
      .map((r) => r.item);

    const peopleResults = userRows
      .map((u) =>
        scorePerson(u, {
          viewerId: options.viewerId,
          skillCatalogIds,
          querySkillIds,
          roleTerms,
          tokens,
          intent,
          connectedIds,
        }),
      )
      .filter((r): r is Scored<UnifiedPersonItem> => r !== null)
      .sort((a, b) => b.score - a.score || b.item.ipScore - a.item.ipScore)
      .map((r) => r.item);

    const companyResults = companyRows
      .map((c) => scoreCompany(c, { tokens, intent }))
      .filter((r): r is Scored<UnifiedCompanyItem> => r !== null)
      .sort((a, b) => b.score - a.score || b.item.adTrustIndex - a.item.adTrustIndex)
      .map((r) => r.item);

    const projectResults = projectRows
      .map((p) => scoreProject(p, { tokens, skillSet }))
      .filter((r): r is Scored<UnifiedProjectItem> => r !== null)
      .sort((a, b) => b.score - a.score)
      .map((r) => r.item);

    const eventResults = eventRows
      .map((e) => scoreEvent(e, { tokens, intent }))
      .filter((r): r is Scored<UnifiedEventItem> => r !== null)
      .sort((a, b) => b.score - a.score)
      .map((r) => r.item);

    const communityResults = communityRows
      .map((c) => scoreCommunity(c, { tokens }))
      .filter((r): r is Scored<UnifiedCommunityItem> => r !== null)
      .sort((a, b) => b.score - a.score || b.item.membersCount - a.item.membersCount)
      .map((r) => r.item);

    const postResults = postRows
      .map((p) => scorePost(p, { tokens }))
      .filter((r): r is Scored<UnifiedPostItem> => r !== null)
      .sort((a, b) => b.score - a.score)
      .map((r) => r.item);

    const results: UnifiedSearchResults = {
      jobs: jobResults,
      people: peopleResults,
      companies: companyResults,
      projects: projectResults,
      events: eventResults,
      communities: communityResults,
      posts: postResults,
    };

    const total = Object.values(results).reduce((acc, arr) => acc + arr.length, 0);

    return {
      query: raw,
      understanding,
      results,
      total,
      tookMs: Date.now() - startedAt,
    };
  },
};
```

</details>

### src/components/shell/unified-search-panel.tsx (286 строк)

<details><summary>Резервная копия кода (286 строк)</summary>

```tsx
// BizON — Панель быстрых результатов единого поиска (Wave C, GPT §17)
// ============================================================
// Выпадающая панель под главным поисковым боксом app-shell:
//  - группы по типам сущностей (люди / вакансии / компании / проекты / события /
//    сообщества / посты), максимум 3 результата на группу в компактном виде;
//  - у каждого результата — «почему найдено» (честная причина из конвейера);
//  - «Показать все результаты» раскрывает до 8 на группу (лимит retrieval);
//  - understanding-чипы: как запрос был понят (детерминированно, без «AI-магии»).
//
// Mobile-first: панель на всю ширину, тач-таргеты ≥44px (min-h-11),
// max-h с overflow-y-auto. Loading — спиннер, ошибки — честный текст.
'use client';

import * as React from 'react';
import {
  Users, Briefcase, Building2, FolderKanban, Calendar, MessagesSquare,
  Newspaper, Loader2, SearchX, Eye, EyeOff,
} from 'lucide-react';
import type { UnifiedSearchResponse, UnifiedSearchResults } from '@/lib/services/unified-search-service';
import { UserAvatar } from '@/components/common/user-avatar';

const PREVIEW_COUNT = 3;
const MAX_COUNT = 8; // = лимит retrieval на домен в unified-search-service

const TYPE_LABELS: Record<string, string> = {
  person: 'Люди',
  job: 'Вакансии',
  company: 'Компании',
  project: 'Проекты',
  event: 'События',
  community: 'Сообщества',
  post: 'Посты',
};

const ENTITY_LABELS: Record<string, string> = {
  role: 'роль',
  skill: 'навык',
  city: 'город',
  salary: 'от',
  grade: 'грейд',
  industry: 'отрасль',
  work_format: 'формат',
  person: 'люди',
  job: 'вакансии',
  company: 'компании',
  project: 'проекты',
  event: 'события',
  community: 'сообщества',
  post: 'посты',
};

const STATUS_RU: Record<string, string> = {
  recruiting: 'набирает команду',
  active: 'в работе',
  completed: 'завершён',
  cancelled: 'отменён',
  PROPOSAL: 'предложение',
  ACTIVE: 'в работе',
  COMPLETED: 'завершён',
};

const FORMAT_RU: Record<string, string> = {
  online: 'онлайн',
  offline: 'офлайн',
  hybrid: 'гибрид',
};

const GROUP_META: Array<{ key: keyof UnifiedSearchResults; icon: React.ReactNode }> = [
  { key: 'people', icon: <Users className="w-4 h-4 text-muted-foreground" aria-hidden="true" /> },
  { key: 'jobs', icon: <Briefcase className="w-4 h-4 text-muted-foreground" aria-hidden="true" /> },
  { key: 'companies', icon: <Building2 className="w-4 h-4 text-muted-foreground" aria-hidden="true" /> },
  { key: 'projects', icon: <FolderKanban className="w-4 h-4 text-muted-foreground" aria-hidden="true" /> },
  { key: 'events', icon: <Calendar className="w-4 h-4 text-muted-foreground" aria-hidden="true" /> },
  { key: 'communities', icon: <MessagesSquare className="w-4 h-4 text-muted-foreground" aria-hidden="true" /> },
  { key: 'posts', icon: <Newspaper className="w-4 h-4 text-muted-foreground" aria-hidden="true" /> },
];

type AnyItem = { id: string; reason: string } & Record<string, unknown>;

function SecondaryLine({ item, group }: { item: AnyItem; group: string }) {
  const parts: string[] = [];
  switch (group) {
    case 'people': {
      if (item.title) parts.push(String(item.title));
      if (item.location) parts.push(String(item.location));
      break;
    }
    case 'jobs': {
      parts.push(String(item.company));
      if (item.location) parts.push(String(item.location));
      const from = (item.salaryMax ?? item.salaryTo ?? item.salaryFrom ?? item.salaryMin) as number | null;
      if (from) {
        parts.push(`от ${new Intl.NumberFormat('ru-RU').format(Math.round(from))} ${item.currency === 'USD' ? '$' : '₽'}`);
      }
      break;
    }
    case 'companies': {
      if (item.industry) parts.push(String(item.industry));
      if (item.location) parts.push(String(item.location));
      break;
    }
    case 'projects': {
      const st = STATUS_RU[String(item.status)] ?? String(item.status);
      parts.push(st);
      if (item.ownerName) parts.push(`владелец: ${String(item.ownerName)}`);
      break;
    }
    case 'events': {
      const d = new Date(String(item.startDate));
      if (!Number.isNaN(d.getTime())) parts.push(d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }));
      parts.push(FORMAT_RU[String(item.format)] ?? String(item.format));
      if (item.location) parts.push(String(item.location));
      break;
    }
    case 'communities': {
      const n = Number(item.membersCount ?? 0);
      parts.push(`${n} ${n % 10 === 1 && n % 100 !== 11 ? 'участник' : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 'участника' : 'участников'}`);
      break;
    }
    case 'posts': {
      if (item.authorName) parts.push(`автор: ${String(item.authorName)}`);
      break;
    }
  }
  const text = parts.filter(Boolean).join(' · ');
  return text ? <div className="text-xs text-muted-foreground truncate">{text}</div> : null;
}

export function UnifiedSearchPanel({
  query,
  data,
  loading,
  error,
  expanded,
  onToggleExpanded,
  onItem,
}: {
  query: string;
  data: UnifiedSearchResponse | null;
  loading: boolean;
  error: string | null;
  expanded: boolean;
  onToggleExpanded: () => void;
  onItem: (group: string, item: AnyItem) => void;
}) {
  const groups = React.useMemo(() => {
    if (!data) return [];
    return GROUP_META.map((meta) => ({
      ...meta,
      items: (data.results[meta.key] as AnyItem[]) ?? [],
    })).filter((g) => g.items.length > 0);
  }, [data]);

  const understanding = data?.understanding;
  const chips: string[] = [];
  if (understanding) {
    for (const t of understanding.detectedTypes.slice(0, 4)) chips.push(TYPE_LABELS[t] ?? t);
    for (const e of understanding.entities.slice(0, 3)) {
      chips.push(`${ENTITY_LABELS[e.type] ?? e.type}: ${e.value}`);
    }
  }

  return (
    <div
      id="unified-search-results"
      role="region"
      aria-label="Результаты поиска"
      className="absolute top-full left-0 right-0 mt-1 bg-popover border rounded-lg shadow-lg max-h-96 overflow-y-auto scroll-area-thin z-50"
    >
      {/* Loading — спиннер (role=status: скринридер объявит начало/конец поиска) */}
      {loading && (
        <div role="status" aria-live="polite" className="flex items-center gap-2 px-3 py-3 text-sm text-muted-foreground">
          <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
          Ищем по всем разделам…
        </div>
      )}

      {/* Ошибка — честный текст от сервера */}
      {!loading && error && (
        <div className="px-3 py-3 text-sm text-destructive" role="alert">{error}</div>
      )}

      {/* Пустой результат — честно, без фикстур */}
      {!loading && !error && data && groups.length === 0 && (
        <div className="px-3 py-4">
          <div className="flex items-center gap-2 text-sm font-medium">
            <SearchX className="w-4 h-4 text-muted-foreground" aria-hidden="true" />
            По запросу «{query}» ничего не найдено
          </div>
          <div className="mt-1 text-xs text-muted-foreground">
            Попробуйте навык (React, Docker), название компании, должность или город.
          </div>
        </div>
      )}

      {/* Понимание запроса — детерминированное, показываем честно */}
      {!loading && !error && groups.length > 0 && chips.length > 0 && (
        <div className="px-3 pt-2 pb-1 flex flex-wrap gap-1 border-b">
          <span className="text-[11px] text-muted-foreground self-center mr-1">Поняли запрос как:</span>
          {chips.map((c, i) => (
            <span key={`${c}-${i}`} className="text-[11px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
              {c}
            </span>
          ))}
        </div>
      )}

      {/* Группы результатов */}
      {groups.map((g) => {
        const shown = expanded ? MAX_COUNT : PREVIEW_COUNT;
        return (
          <div key={g.key} className="py-1 border-b last:border-b-0">
            <div className="flex items-center gap-2 px-3 pt-1.5 pb-1">
              {g.icon}
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                {TYPE_LABELS[g.key] ?? g.key}
              </span>
              <span className="text-[11px] text-muted-foreground">{g.items.length}</span>
            </div>
            {g.items.slice(0, shown).map((item) => (
              // WCAG 2.1.1: onMouseDown обрабатывает мышь (раньше blur успевал закрыть
              // панель), а click c event.detail === 0 — активацию Enter/Space с клавиатуры
              // (клавиатурный click НЕ эмулирует mousedown).
              <button
                key={item.id}
                type="button"
                aria-label={`${TYPE_LABELS[g.key] ?? g.key}: ${String(item.name ?? item.title ?? '')}`}
                onMouseDown={() => onItem(g.key, item)}
                onClick={(e) => { if (e.detail === 0) onItem(g.key, item); }}
                className="w-full min-h-11 flex items-start gap-3 px-3 py-2.5 hover:bg-accent text-left transition"
              >
                {g.key === 'people' ? (
                  <UserAvatar
                    name={String(item.name ?? '')}
                    avatarUrl={(item.avatarUrl as string | null) ?? null}
                    size="sm"
                  />
                ) : (
                  <span className="mt-0.5">{g.icon}</span>
                )}
                <span className="flex-1 min-w-0">
                  <span className="block text-sm font-medium truncate">
                    {String(item.name ?? item.title ?? item.contentPreview ?? '')}
                  </span>
                  <SecondaryLine item={item} group={g.key} />
                  {item.reason && (
                    <span
                      className="block mt-0.5 text-[11px] text-emerald-700 dark:text-emerald-400 truncate"
                      title={item.reason}
                    >
                      <Eye className="inline w-3 h-3 mr-1 -mt-0.5" aria-hidden="true" />
                      {item.reason}
                    </span>
                  )}
                </span>
              </button>
            ))}
          </div>
        );
      })}

      {/* «Все результаты» — раскрыть до 8 на группу / свернуть */}
      {!loading && !error && data && data.total > 0 && (
        // WCAG 2.1.1: дублируем активацию клавиатурой (см. комментарий к результатам)
        <button
          type="button"
          onMouseDown={(e) => { e.preventDefault(); onToggleExpanded(); }}
          onClick={(e) => { if (e.detail === 0) onToggleExpanded(); }}
          className="w-full min-h-11 flex items-center justify-center gap-1.5 px-3 py-2.5 text-sm text-muted-foreground hover:bg-accent hover:text-foreground transition"
        >
          {expanded ? (
            <>
              <EyeOff className="w-4 h-4" aria-hidden="true" />
              Свернуть
            </>
          ) : (
            <>
              <Eye className="w-4 h-4" aria-hidden="true" />
              Показать все результаты ({data.total})
            </>
          )}
        </button>
      )}
    </div>
  );
}
```

</details>

### src/app/api/hr/[id]/reviews/route.ts (85 строк)

<details><summary>Резервная копия кода (85 строк)</summary>

```ts
// BizON API — /api/hr/[id]/reviews (Wave B, GPT §22: HR Trust MVP)
// GET — публичный список отзывов кандидатов о HR-агентстве + агрегат.
// Отзывы привязаны к подтверждённым трудоустройствам (Placement) — объяснимый
// HR Trust: у каждого отзыва видны позиция и компания трудоустройства.
//
// Ответ: { reviews: [{ id, rating, text, createdAt, author{name,avatarUrl},
//          placement{jobTitle, company{name}} }], aggregate: { avg, count } }
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const MAX_REVIEWS = 20;

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await getUserFromRequest(req);
    if (!user) return errorJson('Не авторизован', 401);

    const { id } = await ctx.params;
    if (!id) return errorJson('id обязателен', 422);

    // Rate limit: 60 запросов/час на пользователя
    const rl = checkUserRateLimit(user.id, 'hr:reviews', 60, 60 * 60 * 1000);
    if (!rl.allowed) {
      return errorJson('Слишком много запросов. Попробуйте позже.', 429);
    }

    const hrAgency = await db.user.findUnique({
      where: { id },
      select: { id: true, accountType: true },
    });
    if (!hrAgency || hrAgency.accountType !== 'hr_agency') {
      return errorJson('HR-агентство не найдено', 404);
    }

    const [reviews, agg] = await Promise.all([
      db.hrReview.findMany({
        where: { hrAgencyId: id, status: 'published' },
        orderBy: { createdAt: 'desc' },
        take: MAX_REVIEWS,
        include: {
          author: { select: { id: true, name: true, avatarUrl: true } },
          placement: {
            select: {
              id: true,
              jobTitle: true,
              company: { select: { id: true, name: true } },
            },
          },
        },
      }),
      db.hrReview.aggregate({
        where: { hrAgencyId: id, status: 'published' },
        _avg: { rating: true },
        _count: { rating: true },
      }),
    ]);

    const count = agg._count.rating;
    // Средняя с 1 знаком после запятой; нет отзывов → честный 0 (UI показывает empty state)
    const avg = agg._avg.rating !== null ? Math.round(agg._avg.rating * 10) / 10 : 0;

    return json({
      reviews: reviews.map((r) => ({
        id: r.id,
        rating: r.rating,
        text: r.text,
        createdAt: r.createdAt.toISOString(),
        author: { id: r.author.id, name: r.author.name, avatarUrl: r.author.avatarUrl },
        placement: {
          id: r.placement.id,
          jobTitle: r.placement.jobTitle,
          company: { id: r.placement.company.id, name: r.placement.company.name },
        },
      })),
      aggregate: { avg, count },
    });
  } catch (e) {
    console.error('[hr/reviews] error:', e);
    return errorJson('Ошибка загрузки отзывов', 500);
  }
}
```

</details>

### src/app/api/placements/[id]/review/route.ts (113 строк)

<details><summary>Резервная копия кода (113 строк)</summary>

```ts
// BizON API — /api/placements/[id]/review (Wave B, GPT §22: HR Trust MVP)
// POST — кандидат оставляет отзыв о работе HR-агентства по конкретному
// трудоустройству (Placement). 1 отзыв на placement (placementId unique).
// Правила:
//   • отзыв может оставить ТОЛЬКО кандидат этого placement (candidateId = session user);
//   • требуется подтверждение трудоустройства (кандидатом или компанией);
//   • rating 1..5 (integer), text 10..500 символов;
//   • повторный отзыв → 409;
//   • HR-агентство получает Notification (type='hr_review').
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const MIN_TEXT_LENGTH = 10;
const MAX_TEXT_LENGTH = 500;

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await getUserFromRequest(req);
    if (!user) return errorJson('Не авторизован', 401);

    const { id } = await ctx.params;
    if (!id) return errorJson('id обязателен', 422);

    // Rate limit: как у создания отзывов — 5 в час
    const rl = checkUserRateLimit(user.id, 'placements:review', ...MUTATION_LIMITS.reviewsCreate);
    if (!rl.allowed) {
      return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
    }

    const placement = await db.placement.findUnique({
      where: { id },
      select: {
        id: true,
        hrAgencyId: true,
        candidateId: true,
        confirmedByCandidate: true,
        confirmedByCompany: true,
      },
    });
    if (!placement) return errorJson('Трудоустройство не найдено', 404);

    if (placement.candidateId !== user.id) {
      return errorJson('Отзыв может оставить только кандидат этого трудоустройства', 403);
    }

    if (!placement.confirmedByCandidate && !placement.confirmedByCompany) {
      return errorJson('Сначала подтвердите трудоустройство', 422);
    }

    const existing = await db.hrReview.findUnique({ where: { placementId: placement.id } });
    if (existing) return errorJson('Отзыв уже оставлен', 409);

    const body = await req.json().catch(() => null);
    const { rating, text } = body ?? {};

    if (!Number.isInteger(rating) || (rating as number) < 1 || (rating as number) > 5) {
      return errorJson('Оценка должна быть целым числом от 1 до 5', 422);
    }
    if (typeof text !== 'string' || text.trim().length < MIN_TEXT_LENGTH || text.trim().length > MAX_TEXT_LENGTH) {
      return errorJson(`Текст отзыва обязателен: от ${MIN_TEXT_LENGTH} до ${MAX_TEXT_LENGTH} символов`, 422);
    }

    const review = await db.hrReview.create({
      data: {
        hrAgencyId: placement.hrAgencyId,
        authorId: user.id,
        placementId: placement.id,
        rating,
        text: text.trim(),
      },
      include: {
        author: { select: { id: true, name: true, avatarUrl: true } },
        placement: { select: { id: true, jobTitle: true } },
      },
    });

    // Уведомляем HR-агентство (тот же паттерн, что в POST /api/placements)
    await db.notification
      .create({
        data: {
          userId: placement.hrAgencyId,
          type: 'hr_review',
          title: 'Новый отзыв о вашей работе',
          content: `Кандидат ${user.name} оценил(а) трудоустройство: ${rating}/5`,
          link: '/me',
        },
      })
      .catch((e) => console.error('[placements/review] notification error:', e));

    return json(
      {
        review: {
          id: review.id,
          rating: review.rating,
          text: review.text,
          createdAt: review.createdAt.toISOString(),
          hrAgencyId: review.hrAgencyId,
          placementId: review.placementId,
          author: review.author,
          placement: review.placement,
        },
      },
      201,
    );
  } catch (e) {
    console.error('[placements/review] error:', e);
    return errorJson('Ошибка создания отзыва', 500);
  }
}
```

</details>

### src/components/hr/my-placements-card.tsx (300 строк)

<details><summary>Резервная копия кода (300 строк)</summary>

```tsx
// BizON — My Placements Card (Wave B, GPT §22: HR Trust MVP — сторона кандидата)
// ============================================================================
// Блок «Мои трудоустройства» в разделе «Я» (для accountType='individual'):
//   • список placements текущего пользователя (GET /api/placements?candidateId=me):
//     позиция, компания, дата, бейджи статуса подтверждения;
//   • подтверждённое трудоустройство без отзыва → кнопка «Оставить отзыв» →
//     диалог: выбор звёзд 1–5 (touch-цели ≥44px) + текст 10–500 символов →
//     POST /api/placements/[id]/review (HrReview) → toast → обновление списка;
//   • отзыв уже оставлен → показан инлайн «Ваш отзыв» (звёзды + текст);
//   • нет placements вообще → компонент рендерит null (не захламляем профиль).
// Отзыв может оставить только кандидат этого трудоустройства — API это
// энфорсит (403), здесь кнопка показывается только на своих placements.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { StarsRow } from './intel-shared';
import {
  Briefcase, Building2, CheckCircle2, Loader2, MessageSquarePlus, Star,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const MIN_TEXT_LENGTH = 10;
const MAX_TEXT_LENGTH = 500;

/** Элемент GET /api/placements?candidateId=me */
interface MyPlacement {
  id: string;
  jobTitle: string;
  placedAt: string;
  confirmedByCandidate: boolean;
  confirmedByCompany: boolean;
  isPublic: boolean;
  company: { id: string; name: string; logoUrl: string | null; industry: string | null };
  hrAgency: { id: string; name: string; avatarUrl: string | null; title: string | null };
  hrReview: { id: string; rating: number; text: string; createdAt: string } | null;
}

export function MyPlacementsCard() {
  const [placements, setPlacements] = React.useState<MyPlacement[] | null>(null);

  const load = React.useCallback(async () => {
    try {
      const res = await api<{ placements: MyPlacement[] }>('/api/placements?candidateId=me');
      setPlacements(res.placements ?? []);
    } catch (e) {
      // Ошибка загрузки — блок просто не показываем (не критично для профиля)
      console.error('[MyPlacementsCard] load error:', e);
      setPlacements([]);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  // Ещё грузится или placements нет — ничего не рендерим (честно и без шума)
  if (placements === null || placements.length === 0) return null;

  return (
    <Card>
      <CardHeader className="px-4">
        <CardTitle className="flex items-center gap-2 text-base">
          <Briefcase className="w-4 h-4 text-primary" />
          Мои трудоустройства
          <Badge variant="secondary" className="ml-1">{placements.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-4">
          {placements.map((p) => (
            <PlacementCard key={p.id} placement={p} onReviewed={load} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// === Одна позиция: статус подтверждения + отзыв (или кнопка «Оставить отзыв») ===
// ============================================================================

function PlacementCard({ placement, onReviewed }: { placement: MyPlacement; onReviewed: () => void }) {
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const fullyConfirmed = placement.confirmedByCandidate && placement.confirmedByCompany;
  const partialConfirmed = placement.confirmedByCandidate || placement.confirmedByCompany;

  return (
    <div className="p-3 rounded-lg border bg-card space-y-2">
      <div className="flex items-start justify-between gap-2 flex-wrap">
        <div className="min-w-0">
          <div className="text-sm font-medium truncate">{placement.jobTitle}</div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5 flex-wrap">
            <Building2 className="w-3 h-3 flex-shrink-0" aria-hidden="true" />
            <span className="truncate">{placement.company.name}</span>
            <span aria-hidden="true">·</span>
            <span>
              {new Date(placement.placedAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' })}
            </span>
          </div>
        </div>
        {/* Статус подтверждения */}
        <div className="flex-shrink-0">
          {fullyConfirmed ? (
            <Badge className="bg-emerald-600 text-white gap-1 text-xs">
              <CheckCircle2 className="w-3 h-3" aria-hidden="true" />
              Подтверждено
            </Badge>
          ) : partialConfirmed ? (
            <Badge variant="outline" className="text-amber-600 border-amber-600/40 gap-1 text-xs">
              <Loader2 className="w-3 h-3" aria-hidden="true" />
              Частично подтверждено
            </Badge>
          ) : (
            <Badge variant="outline" className="text-muted-foreground text-xs">
              Ожидает подтверждения
            </Badge>
          )}
        </div>
      </div>

      {/* HR-агентство, которое закрыло позицию */}
      <div className="text-xs text-muted-foreground">
        HR-агентство: <span className="font-medium text-foreground/80">{placement.hrAgency.name}</span>
      </div>

      {/* Отзыв: уже оставлен — инлайн; иначе кнопка (только для подтверждённых) */}
      {placement.hrReview ? (
        <div className="p-2.5 rounded-lg bg-muted/40 border border-lighthouse/20">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <span className="text-xs font-semibold text-lighthouse flex items-center gap-1">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" aria-hidden="true" />
              Ваш отзыв
            </span>
            <StarsRow rating={placement.hrReview.rating} />
          </div>
          <p className="text-xs mt-1.5 leading-relaxed">{placement.hrReview.text}</p>
        </div>
      ) : (placement.confirmedByCandidate || placement.confirmedByCompany) ? (
        <>
          <Button size="sm" variant="outline" className="min-h-11 gap-1.5" onClick={() => setDialogOpen(true)}>
            <MessageSquarePlus className="w-4 h-4" aria-hidden="true" />
            Оставить отзыв
          </Button>
          <ReviewDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            placement={placement}
            onCreated={() => {
              setDialogOpen(false);
              onReviewed();
            }}
          />
        </>
      ) : null}
    </div>
  );
}

// ============================================================================
// === Диалог «Оставить отзыв»: звёзды 1–5 + текст 10–500 ===
// ============================================================================

function ReviewDialog({
  open,
  onOpenChange,
  placement,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  placement: MyPlacement;
  onCreated: () => void;
}) {
  const [rating, setRating] = React.useState(0);
  const [hovered, setHovered] = React.useState(0);
  const [text, setText] = React.useState('');
  const [submitting, setSubmitting] = React.useState(false);

  const trimmed = text.trim();
  const canSubmit = rating >= 1 && rating <= 5 && trimmed.length >= MIN_TEXT_LENGTH && trimmed.length <= MAX_TEXT_LENGTH;

  // Переоткрытие диалога — сброс формы
  React.useEffect(() => {
    if (open) {
      setRating(0);
      setHovered(0);
      setText('');
      setSubmitting(false);
    }
  }, [open]);

  async function handleSubmit() {
    if (!canSubmit || submitting) return;
    setSubmitting(true);
    try {
      await api(`/api/placements/${placement.id}/review`, {
        method: 'POST',
        body: JSON.stringify({ rating, text: trimmed }),
      });
      toast({ title: 'Отзыв отправлен', description: `Оценка ${rating}/5 — спасибо, это помогает HR Trust.` });
      onCreated();
    } catch (e: unknown) {
      toast({
        title: 'Не удалось отправить отзыв',
        description: e instanceof Error ? e.message : 'Попробуйте позже',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  }

  const shown = hovered || rating;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Оцените работу HR-агентства</DialogTitle>
          <DialogDescription>
            {placement.hrAgency.name} · «{placement.jobTitle}» @ {placement.company.name}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-1">
          {/* Выбор оценки: 5 звёзд, touch-цель каждой ≥44px */}
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center gap-1" role="radiogroup" aria-label="Оценка от 1 до 5 звёзд">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={rating === value}
                  aria-label={`${value} ${value === 1 ? 'звезда' : value < 5 ? 'звезды' : 'звёзд'}`}
                  onClick={() => setRating(value)}
                  onMouseEnter={() => setHovered(value)}
                  onMouseLeave={() => setHovered(0)}
                  className={cn(
                    'w-11 h-11 rounded-full flex items-center justify-center transition',
                    'hover:bg-muted focus-visible:outline-2 focus-visible:outline-lighthouse',
                  )}
                >
                  <Star
                    className={cn(
                      'w-7 h-7 transition',
                      value <= shown ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground',
                    )}
                    aria-hidden="true"
                  />
                </button>
              ))}
            </div>
            <span className="text-xs text-muted-foreground tabular-nums" aria-live="polite">
              {shown > 0 ? `Оценка: ${shown}/5` : 'Выберите оценку'}
            </span>
          </div>

          {/* Текст отзыва */}
          <div className="space-y-1.5">
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value.slice(0, MAX_TEXT_LENGTH))}
              placeholder="Что было хорошо? Скорость подбора, коммуникация, качество предложений…"
              rows={4}
              aria-label="Текст отзыва"
            />
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>От 10 до 500 символов — конкретика помогает агентству расти</span>
              <span className={cn('tabular-nums flex-shrink-0 ml-2', trimmed.length > 0 && trimmed.length < MIN_TEXT_LENGTH && 'text-amber-600')}>
                {trimmed.length}/{MAX_TEXT_LENGTH}
              </span>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
            Отмена
          </Button>
          <Button onClick={handleSubmit} disabled={!canSubmit || submitting}>
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" /> : null}
            Отправить отзыв
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
```

</details>

### src/components/feed/one-thought-mode.tsx (245 строк)

<details><summary>Резервная копия кода (245 строк)</summary>

```tsx
// BizON — One Thought Mode (Wave C, GPT §30 «ONE SCREEN — ONE MAIN THOUGHT»)
//
// Режим ленты «Одна мысль»: экран показывает РОВНО ОДНУ главную карточку —
// топ по объяснимому скору релевантности, посчитанному НА СЕРВЕРЕ
// (GET /api/feed/thoughts → ThoughtScoring в feed-service: доверие автора
// × отклик читателей × свежесть × совпадение с навыками; детерминированно,
// без «AI решил»). Под карточкой — объяснение почему она главная сегодня.
// Навигация «← Назад / Следующая мысль →» листает топ-N по одной, позиция «3 / 10».
//
// ЧЕСТНОСТЬ (§30):
//   - почему-блок строится из ТЕХ ЖЕ факторов, что и скор (приходит с сервера);
//   - остальной контент ленты (зоопарк) в этом режиме скрыт самим trust-stream;
//   - спонсорские карточки исключены ещё на сервере + страховочный фильтр здесь;
//   - пустая лента — честный empty state без выдуманного контента;
//   - каждая показанная мысль-пост отправляет dwell-сигнал через СУЩЕСТВУЮЩИЙ
//     механизм (useDwellTracker → POST /api/feed/dwell, itemType 'post').
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Lightbulb, ChevronLeft, ChevronRight } from 'lucide-react';
import type { FeedItem } from '@/lib/types';
import { useDwellTracker } from './dwell-tracking';

/** Сколько «мыслях» листаем: топ-N сегодняшней ленты. */
const THOUGHTS_LIMIT = 10;

/** Фактор объяснимого скора (контракт GET /api/feed/thoughts). */
interface ThoughtFactor {
  key: string;
  label: string;
  value: number;
}

/** Мысль = обычный FeedItem + серверные score/why/factors (аддитивно). */
type ThoughtCard = FeedItem & {
  score: number;
  why: string;
  factors: ThoughtFactor[];
};

export function OneThoughtMode({
  renderCard,
}: {
  /**
   * Рендер карточки передаёт родитель (trust-stream) — так режим переиспользует
   * РОВНО те же карточки ленты (PostCard/ReputationEventCard c кликами по автору,
   * лайками и комментариями) без дублирования и без циклических импортов.
   */
  renderCard: (item: FeedItem) => React.ReactNode;
}) {
  const [items, setItems] = React.useState<ThoughtCard[]>([]);
  const [index, setIndex] = React.useState(0);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  // Task 10-c/A7: dwell-сигнал показанной мысли (один трекер на режим; flush на
  // pagehide/visibilitychange/unmount — механика существующая, не новая).
  const dwell = useDwellTracker();

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    setIndex(0);
    try {
      const res = await api<{ items: ThoughtCard[]; total: number }>(`/api/feed/thoughts?limit=${THOUGHTS_LIMIT}`);
      // Честность: спонсорское не должно приходить в принципе (исключено на
      // сервере) — страховочный фильтр; мысли без конечного скора отбрасываем.
      const safe = (res.items ?? []).filter(
        (i) => i.kind !== 'sponsored' && Number.isFinite(i.score),
      );
      setItems(safe);
    } catch (e: any) {
      setError(e?.message || 'Не удалось загрузить главную мысль');
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    void load();
  }, [load]);

  // Листание с закольцовкой: «Следующая мысль →» на последней возвращает к первой.
  const go = React.useCallback(
    (dir: 1 | -1) => {
      setIndex((i) => {
        if (items.length === 0) return 0;
        return (i + dir + items.length) % items.length;
      });
    },
    [items.length],
  );

  // Клавиатурная навигация ←/→ (тач-кнопки дублируют её для всех остальных).
  // Не перехватываем стрелки из полей ввода (комментарии внутри карточки).
  React.useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        go(1);
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(-1);
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [go]);

  const current = items[index] ?? null;

  // Dwell: регистрируем карточку текущей мысли. Только для постов — для
  // reputation-событий в контракте dwell нет честного типа (job|person|event|
  // company|post), выдумывать не стали (см. worklog).
  const trackCardRef = React.useCallback(
    (el: HTMLElement | null) => {
      if (!el || !current) return;
      if (current.kind === 'post' && current.post) {
        const topic =
          current.post.tags && current.post.tags.length > 0
            ? current.post.tags.join(', ')
            : current.post.author?.name || null;
        dwell.track({ itemType: 'post', itemId: current.post.id, topic }, el);
      }
    },
    [current, dwell],
  );

  if (loading) {
    return (
      <section aria-label="Одна мысль" aria-busy="true" className="space-y-4">
        <Card className="p-4">
          <div className="flex gap-3">
            <Skeleton className="w-10 h-10 rounded-full" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-1/3" />
              <Skeleton className="h-3 w-2/3" />
              <Skeleton className="h-3 w-1/2" />
              <Skeleton className="h-24 w-full mt-2" />
            </div>
          </div>
        </Card>
        <p className="text-center text-xs text-muted-foreground">Собираем главную мысль дня…</p>
      </section>
    );
  }

  if (error) {
    return (
      <section aria-label="Одна мысль" className="space-y-4">
        <Card className="p-6 text-center space-y-3">
          <p className="text-sm text-muted-foreground">{error}</p>
          <Button variant="outline" onClick={() => void load()}>
            Повторить
          </Button>
        </Card>
      </section>
    );
  }

  if (!current) {
    // Честный empty state (GPT §30): без выдуманного контента и виджетов.
    return (
      <section aria-label="Одна мысль" className="space-y-4">
        <Card className="p-8 text-center space-y-3">
          <Lightbulb className="w-6 h-6 text-muted-foreground mx-auto" aria-hidden="true" />
          <p className="text-muted-foreground">
            Лента пока пуста — добавьте навыки и подключения, чтобы появились рекомендации
          </p>
        </Card>
      </section>
    );
  }

  const why = current.why && current.why.length > 0 ? current.why.charAt(0).toUpperCase() + current.why.slice(1) : '';

  return (
    <section aria-label="Одна мысль" className="space-y-4">
      {/* ЕДИНСТВЕННАЯ карточка мысли (key — ремоunt состояния лайков/комментариев между мыслями) */}
      <div key={current.id} ref={trackCardRef} className="soft-fade-in">
        {renderCard(current)}
      </div>

      {/* Объяснение «почему главная» — из тех же факторов, что и скор (честность §30) */}
      <Card className="p-4 border-lighthouse/20 bg-lighthouse-gradient-soft">
        <div className="flex items-center gap-2 text-sm font-semibold mb-1.5">
          <Lightbulb className="w-4 h-4 text-lighthouse" aria-hidden="true" />
          Почему это главная мысль
        </div>
        {why && <p className="text-sm leading-relaxed">{why}</p>}
        {current.factors.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2.5">
            {current.factors.map((f) => (
              <Badge
                key={f.key}
                variant="outline"
                className="text-xs font-normal gap-1.5 bg-background/60"
                title={`Фактор скора: ${f.value.toFixed(2)}`}
              >
                {f.label}
                <span className="tabular-nums text-muted-foreground">{Number.isFinite(f.value) ? f.value.toFixed(2) : '—'}</span>
              </Badge>
            ))}
          </div>
        )}
        <p className="text-xs text-muted-foreground mt-2.5">
          Скор {Number.isFinite(current.score) ? current.score.toFixed(2) : '—'} — детерминированный
          расчёт по факторам вашей ленты: доверие автора, отклик читателей, свежесть, совпадение
          с навыками. Топ-{items.length} сегодняшней ленты, без «магии»: та же формула — тот же порядок.
        </p>
      </Card>

      {/* Навигация по мыслям — единственные элементы управления режима */}
      <nav aria-label="Навигация по мыслям" className="flex items-center justify-between gap-2">
        <Button
          variant="outline"
          onClick={() => go(-1)}
          className="min-h-11 gap-1.5 flex-1 sm:flex-none"
          aria-label="Предыдущая мысль"
        >
          <ChevronLeft className="w-4 h-4" aria-hidden="true" />
          Назад
        </Button>
        <span className="text-sm font-medium tabular-nums text-muted-foreground whitespace-nowrap" aria-live="polite">
          {index + 1} / {items.length}
        </span>
        <Button
          onClick={() => go(1)}
          className="min-h-11 gap-1.5 flex-1 sm:flex-none"
          aria-label="Следующая мысль"
        >
          Следующая мысль
          <ChevronRight className="w-4 h-4" aria-hidden="true" />
        </Button>
      </nav>
    </section>
  );
}
```

</details>

### src/app/api/feed/thoughts/route.ts (37 строк)

<details><summary>Резервная копия кода (37 строк)</summary>

```ts
// BizON API — GET /api/feed/thoughts (Wave C, GPT §30 «ONE SCREEN — ONE MAIN THOUGHT»)
//
// Топ-N карточек ленты по ОБЪЯСНИМОМУ детерминированному скору для режима
// «Одна мысль» (one-thought-mode.tsx). Скор считается на сервере (ThoughtScoring
// в feed-service) из уже существующих факторов платформы:
//   доверие автора (ipScore) × отклик читателей (лайки/комментарии) ×
//   свежесть (A2 decay 1/(1+days×0.1)) × совпадение тегов с навыками юзера.
// Никакой рандомизации и LLM — одинаковый вход даёт одинаковый порядок.
//
// ЧЕСТНОСТЬ:
//   - каждый элемент несёт score + why (рус., из тех же факторов) + factors[];
//   - спонсорские карточки и commercial-посты исключены (main thought ≠ ad);
//   - ответ аддитивный: форма FeedItem сохранена, поля score/why/factors
//     добавлены сверху (не ломает существующие потребители FeedItem).
//
// Контракт: GET ?limit=10 (1..20) → { items: ThoughtItem[], total }
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { ThoughtScoring } from '@/lib/services/feed-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rawLimit = Number(req.nextUrl.searchParams.get('limit') ?? 10);
  const limit = Number.isFinite(rawLimit) ? Math.floor(rawLimit) : 10;

  try {
    const result = await ThoughtScoring.getTopThoughts(user.id, { limit });
    return json(result);
  } catch (e) {
    console.error('[api/feed/thoughts] failed:', e);
    return errorJson('Не удалось собрать «Одну мысль» — попробуйте ещё раз', 500);
  }
}
```

</details>

### src/app/api/projects/[id]/confirm/route.ts (281 строк)

<details><summary>Резервная копия кода (281 строк)</summary>

```ts
// BizON API — /api/projects/[id]/confirm
// A9 (STUBS-AUDIT 10.09.2026): подтверждение участником завершения проекта.
//
// Поток: владелец вызывает POST /api/projects/[id]/transition { status: 'completed' }
// для ACTIVE-проекта с 2+ активными участниками → открывается «волна
// подтверждений» (ProjectConfirmation на каждого активного участника), статус
// проекта НЕ меняется (202). Каждый активный участник подтверждает здесь.
// Когда подтвердят все (кворум 100%), проект завершается АТОМАРНО — в одной
// $transaction: статус 'completed' + ReputationEvent всем участникам (тот же
// паттерн, что в ReputationService.awardBulk волн C-c: createMany событий с
// impactScore + массовый пересчёт IP-score) + Notification «Проект X завершён».
//
// GET  — состояние волны для UI (только участники/владелец): waveOpen,
//        confirmed/total, myPending/myConfirmed.
// POST — подтверждение текущим пользователем:
//   403 — пользователь не активный участник проекта;
//   404 — проект не найден;
//   409 — пользователь уже подтверждал (или параллельный запрос успел раньше);
//   422 — нет открытой волны подтверждения (завершение не запрашивалось).
import { z } from 'zod';
import { db } from '@/lib/db';
import { json } from '@/lib/api-helpers';
import { withRoute, jsonError } from '@/lib/with-route';
import { computeImpactScore, recomputeIpScoresBulk } from '@/lib/reputation';
import { normalizeStatus } from '@/lib/projects/constants';
import { ActionEventService } from '@/lib/services';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

// Тело не требуется; inline-схема оставляет место будущим полям (например,
// комментарий к подтверждению) и вырезает неизвестное.
const confirmSchema = z.object({}).passthrough();

// Активный участник: exitState='active' (пустое значение — совместимость со
// старыми записями до введения Three States of Exit).
const isActiveExit = (m: { exitState: string | null }) => !m.exitState || m.exitState === 'active';

// === GET: состояние волны подтверждения (для баннеров/индикаторов UI) ===
export const GET = withRoute<{ id: string }>(async (_req, ctx) => {
  const user = ctx.user;
  if (!user) return jsonError(401, 'Не авторизован');

  const project = await db.project.findUnique({
    where: { id: ctx.params.id },
    include: { members: true },
  });
  if (!project) return jsonError(404, 'Проект не найден');

  const isOwner = project.ownerId === user.id;
  const isMember = project.members.some((m) => m.userId === user.id);
  if (!isOwner && !isMember) {
    return jsonError(403, 'Состояние подтверждения доступно только участникам проекта');
  }

  const activeMembers = project.members.filter(isActiveExit);
  const rows = await db.projectConfirmation.findMany({ where: { projectId: project.id } });
  const confirmedIds = new Set(rows.filter((r) => r.confirmedAt).map((r) => r.userId));
  const confirmed = activeMembers.filter((m) => confirmedIds.has(m.userId)).length;
  const total = activeMembers.length;

  return json({
    projectId: project.id,
    status: project.status,
    total,
    confirmed,
    pending: Math.max(0, total - confirmed),
    // Волна открыта: проект активен, записи волны существуют и кворум ещё не собран
    waveOpen:
      normalizeStatus(project.status) === 'ACTIVE' && rows.length > 0 && confirmed < total,
    myConfirmed: confirmedIds.has(user.id),
    myPending: activeMembers.some((m) => m.userId === user.id) && !confirmedIds.has(user.id),
  });
});

// === POST: подтвердить завершение текущим пользователем ===
export const POST = withRoute<{ id: string }>(
  async (_req, ctx) => {
    const user = ctx.user;
    if (!user) return jsonError(401, 'Не авторизован');
    const id = ctx.params.id;

    const project = await db.project.findUnique({
      where: { id },
      include: { members: true },
    });
    if (!project) return jsonError(404, 'Проект не найден');

    if (normalizeStatus(project.status) !== 'ACTIVE') {
      return jsonError(422, 'Волна подтверждения не открыта: проект не в статусе «Активный»');
    }

    const activeMembers = project.members.filter(isActiveExit);
    if (!activeMembers.some((m) => m.userId === user.id)) {
      return jsonError(403, 'Подтвердить завершение может только активный участник проекта');
    }

    const rows = await db.projectConfirmation.findMany({ where: { projectId: id } });
    if (rows.length === 0) {
      return jsonError(422, 'Нет открытой волны подтверждения: завершение проекта ещё не запрошено');
    }
    const myRow = rows.find((r) => r.userId === user.id);
    if (myRow?.confirmedAt) {
      return jsonError(409, 'Вы уже подтвердили завершение проекта');
    }

    const now = new Date();

    const result = await db.$transaction(async (tx) => {
      // 1) Подтверждение текущего пользователя (guard от гонки: null → now)
      if (myRow) {
        const updated = await tx.projectConfirmation.updateMany({
          where: { id: myRow.id, confirmedAt: null },
          data: { confirmedAt: now },
        });
        if (updated.count === 0) return null; // параллельный запрос уже подтвердил
      } else {
        // Участник вступил после открытия волны: запись создаётся уже подтверждённой
        await tx.projectConfirmation.create({
          data: { projectId: id, userId: user.id, confirmedAt: now },
        });
      }

      // 2) Пересчёт кворума по актуальным активным участникам
      const [members, confirms] = await Promise.all([
        tx.projectMember.findMany({ where: { projectId: id } }),
        tx.projectConfirmation.findMany({ where: { projectId: id } }),
      ]);
      const actives = members.filter(isActiveExit);
      const confirmedIds = new Set(confirms.filter((c) => c.confirmedAt).map((c) => c.userId));
      const confirmedCount = actives.filter((m) => confirmedIds.has(m.userId)).length;
      const total = actives.length;

      if (confirmedCount < total) {
        return { completed: false as const, confirmed: confirmedCount, total, actives };
      }

      // 3) Кворум собран — завершаем проект (guard: только из ACTIVE, чтобы
      //    гонка с transition 'cancelled'/'on_hold' не перезаписала статус)
      const flipped = await tx.project.updateMany({
        where: { id, status: 'ACTIVE' },
        data: { status: 'completed', completedAt: now },
      });
      if (flipped.count === 0) {
        return { completed: false as const, confirmed: confirmedCount, total, actives };
      }

      // 4) Репутация всем участникам — паттерн ReputationService.awardBulk
      //    (волны C-c): createMany ReputationEvent с impactScore + массовый
      //    пересчёт IP-score. Здесь — внутри ЭТОЙ транзакции, атомарно со
      //    сменой статуса (awardBulk открыл бы вложенную транзакцию — риск
      //    SQLITE_BUSY, поэтому переиспользуем его внутренности напрямую).
      const userIds = [...new Set(actives.map((m) => m.userId))];
      const users = await tx.user.findMany({
        where: { id: { in: userIds } },
        select: { id: true, ipScore: true },
      });
      const ipById = new Map(users.map((u) => [u.id, u.ipScore]));
      const impactPayload = { rating: project.rating, participantsCount: total };
      await tx.reputationEvent.createMany({
        data: userIds.map((uid) => ({
          userId: uid,
          eventType: 'project_completed',
          payload: JSON.stringify({
            projectId: project.id,
            projectTitle: project.title,
            rating: project.rating,
            participantsCount: total,
            role: actives.find((m) => m.userId === uid)?.role,
            viaQuorum: true,
          }),
          weight: 5,
          impactScore: computeImpactScore(
            'project_completed',
            ipById.get(uid) ?? 0,
            impactPayload
          ),
        })),
      });
      const recomputed = await recomputeIpScoresBulk(userIds, tx);
      for (const uid of userIds) {
        const r = recomputed.get(uid);
        if (r) {
          await tx.user.update({
            where: { id: uid },
            data: { ipScore: r.ipScore, level: r.level },
          });
        }
      }

      // 5) Notification каждому участнику: «Проект X завершён»
      await tx.notification.createMany({
        data: userIds.map((uid) => ({
          userId: uid,
          type: 'project_completed',
          title: `Проект «${project.title}» завершён`,
          content: `Все участники подтвердили завершение (${confirmedCount} из ${total}). Репутация обновлена.`,
          link: '/projects',
        })),
      });

      // 6) AuditLog
      await tx.auditLog.create({
        data: {
          actorId: user.id,
          action: 'project_completed_confirmed',
          resource: 'project',
          resourceId: project.id,
          metadata: JSON.stringify({
            title: project.title,
            confirmed: confirmedCount,
            total,
            lastConfirmedBy: user.name,
          }),
        },
      });

      return { completed: true as const, confirmed: confirmedCount, total, actives };
    });

    if (result === null) {
      return jsonError(409, 'Вы уже подтвердили завершение проекта');
    }

    const { confirmed, total, actives } = result;

    // 7) Side-эффекты вне транзакции (fail-open, как в transition-роуте)
    if (result.completed) {
      // R10: Actions Timeline — «Завершён проект …» каждому активному участнику
      for (const m of actives) {
        ActionEventService.logAction({
          userId: m.userId,
          type: 'project_completed',
          title: `Завершён проект «${project.title}»`,
          description: project.outcome?.slice(0, 200) ?? undefined,
          metadata: {
            projectId: project.id,
            projectTitle: project.title,
            role: m.role,
            rating: project.rating,
            participantsCount: total,
            viaQuorum: true,
          },
        }).catch((e) => console.error('[projects/confirm] actionEvent error:', e));
      }

      // Event Bus: проект завершён (fail-open)
      try {
        void EventBus.publish('project.completed', {
          userId: user.id,
          projectId: project.id,
          outcome: project.outcome,
        }).catch(() => undefined);
      } catch {
        // fail-open: ошибки шины игнорируем
      }

      return json({
        ok: true,
        completed: true,
        confirmed,
        pending: 0,
        total,
        message: `Проект «${project.title}» завершён: все участники подтвердили`,
      });
    }

    return json({
      ok: true,
      completed: false,
      confirmed,
      pending: total - confirmed,
      total,
      message: `Подтверждение принято: подтверждено ${confirmed} из ${total}`,
    });
  },
  {
    schema: confirmSchema,
    rateLimit: { key: 'project-confirm', limit: 30, windowMs: 60_000 },
  }
);
```

</details>

### scripts/a9-confirm-test.ts (262 строк)

<details><summary>Резервная копия кода (262 строк)</summary>

```ts
// A9 (Task 2-e) — ONE-OFF: curl-матрица кворум-завершения проекта + cleanup.
// Создаёт 3 тестовых пользователя (founder A, member B, outsider C) с сессиями,
// прогоняет матрицу переходов/подтверждений через живой dev-сервер (:3000),
// проверяет DB-эффекты и УДАЛЯЕТ все тестовые записи (каскад).
//
// Запуск: bun scripts/a9-confirm-test.ts
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();
const BASE = 'http://localhost:3000';
const HASH_PREFIX = 'a9test-';

let failures = 0;
function check(name: string, cond: boolean, detail?: unknown) {
  const mark = cond ? 'PASS' : 'FAIL';
  console.log(`[${mark}] ${name}${cond ? '' : ` :: ${JSON.stringify(detail)?.slice(0, 400)}`}`);
  if (!cond) failures++;
}

type Ctx = { cookie: string };
async function call(
  ctx: Ctx,
  method: string,
  path: string,
  body?: unknown
): Promise<{ status: number; json: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      'content-type': 'application/json',
      cookie: ctx.cookie,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json: any = null;
  try {
    json = await res.json();
  } catch {
    json = null;
  }
  return { status: res.status, json };
}

async function main() {
  // ---------- 0. Setup: тестовые пользователи + сессии ----------
  const runId = Date.now().toString(36);
  const mk = (tag: string) => ({
    emailHash: `${HASH_PREFIX}${runId}-${tag}`,
    name: `A9 Test ${tag.toUpperCase()}`,
    passwordHash: 'a9-test-not-used-for-login',
  });
  const [userA, userB, userC] = await Promise.all([
    db.user.create({ data: mk('founder') }),
    db.user.create({ data: mk('member') }),
    db.user.create({ data: mk('outsider') }),
  ]);
  const mkSession = (userId: string, tag: string) =>
    db.session.create({
      data: { userId, token: `${HASH_PREFIX}${runId}-${tag}-session`, expiresAt: new Date(Date.now() + 86400_000) },
    });
  await Promise.all([mkSession(userA.id, 'a'), mkSession(userB.id, 'b'), mkSession(userC.id, 'c')]);
  const A: Ctx = { cookie: `bizon_session=${HASH_PREFIX}${runId}-a-session` };
  const B: Ctx = { cookie: `bizon_session=${HASH_PREFIX}${runId}-b-session` };
  const C: Ctx = { cookie: `bizon_session=${HASH_PREFIX}${runId}-c-session` };
  console.log(`[setup] users A/B/C created (${runId})`);

  const testProjectIds: string[] = [];

  try {
    // ---------- 1. Проект с 2 участниками ----------
    const created = await call(A, 'POST', '/api/projects', {
      title: `A9 Кворум-тест ${runId}`,
      description: 'Тестовый проект для проверки кворум-завершения (A9).',
      tags: ['a9test'],
    });
    check('POST /api/projects (A) → 201', created.status === 201, created);
    const projectId = created.json?.project?.id as string;
    testProjectIds.push(projectId);
    check('project id получен', !!projectId, created.json);

    const join = await call(B, 'PATCH', `/api/projects/${projectId}`, { action: 'join' });
    check('PATCH join (B) → 200', join.status === 200, join);

    // ---------- 2. Активация: PROPOSAL(recruiting) → ACTIVE ----------
    const forbidden = await call(B, 'POST', `/api/projects/${projectId}/transition`, { status: 'ACTIVE' });
    check('transition (B, не founder) → 403', forbidden.status === 403, forbidden);

    const activate = await call(A, 'POST', `/api/projects/${projectId}/transition`, { status: 'ACTIVE' });
    check('transition active (A) → 200', activate.status === 200, activate);

    // Толерантность к нижнему регистру ('active' → ACTIVE)
    const activateLower = await call(A, 'POST', `/api/projects/${projectId}/transition`, { status: 'on_hold' });
    check('transition принимает нижний регистр (on_hold → ON_HOLD)', activateLower.status === 200, activateLower);
    await call(A, 'POST', `/api/projects/${projectId}/transition`, { status: 'ACTIVE' }); // вернём в ACTIVE

    // ---------- 3. Confirm до волны → 422 ----------
    const earlyConfirm = await call(A, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('confirm до волны (A) → 422', earlyConfirm.status === 422, earlyConfirm);
    check('текст «нет открытой волны»', /волны подтверждения не открыта|не запрошено/.test(earlyConfirm.json?.error ?? ''), earlyConfirm.json);

    // GET /confirm до волны: member видит состояние, волна не открыта
    const earlyGet = await call(B, 'GET', `/api/projects/${projectId}/confirm`);
    check('GET confirm (B) до волны → 200', earlyGet.status === 200, earlyGet);
    check('GET confirm: waveOpen=false, total=2', earlyGet.json?.waveOpen === false && earlyGet.json?.total === 2, earlyGet.json);

    // ---------- 4. Волна: transition completed → 202 ----------
    const wave = await call(A, 'POST', `/api/projects/${projectId}/transition`, {
      status: 'COMPLETED',
      rating: 5,
      outcome: 'Доставили MVP в срок',
    });
    check('transition completed (A) → 202', wave.status === 202, wave);
    check('202: pendingConfirmation=true', wave.json?.pendingConfirmation === true, wave.json);
    check('202: confirmed=0, pending=2, total=2', wave.json?.confirmed === 0 && wave.json?.pending === 2 && wave.json?.total === 2, wave.json);
    check('202: сообщение «подтверждено 0 из 2»', wave.json?.message === 'Завершение требует подтверждения всех участников: подтверждено 0 из 2', wave.json);
    check('202: статус проекта НЕ изменился', wave.json?.projectStatus === 'ACTIVE', wave.json);

    const waveCount = await db.projectConfirmation.count({ where: { projectId } });
    check('ProjectConfirmation создано 2 записи', waveCount === 2, { waveCount });

    // ---------- 5. Повторный transition completed → 409 со счётчиками ----------
    const repeat = await call(A, 'POST', `/api/projects/${projectId}/transition`, { status: 'COMPLETED' });
    check('повторный transition completed → 409', repeat.status === 409, repeat);
    check('409: confirmed=0/pending=2/total=2', repeat.json?.confirmed === 0 && repeat.json?.pending === 2 && repeat.json?.total === 2, repeat.json);
    check('409: сообщение с счётчиками', typeof repeat.json?.message === 'string' && repeat.json.message.includes('0 из 2'), repeat.json);

    const waveCountAfterRepeat = await db.projectConfirmation.count({ where: { projectId } });
    check('повтор не дублирует записи', waveCountAfterRepeat === 2, { waveCountAfterRepeat });

    // ---------- 6. GET /confirm ----------
    const getA = await call(A, 'GET', `/api/projects/${projectId}/confirm`);
    check('GET confirm (A) → 200 waveOpen=true myPending=true', getA.status === 200 && getA.json?.waveOpen === true && getA.json?.myPending === true, getA.json);

    const getC = await call(C, 'GET', `/api/projects/${projectId}/confirm`);
    check('GET confirm (C, чужой) → 403', getC.status === 403, getC);

    // ---------- 7. Confirm чужим → 403 ----------
    const confirmC = await call(C, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('confirm (C, не участник) → 403', confirmC.status === 403, confirmC);

    // ---------- 8. Первый confirm (B) → 200, не завершён ----------
    const confirmB = await call(B, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('confirm (B) → 200', confirmB.status === 200, confirmB);
    check('confirm (B): completed=false, confirmed=1/total=2', confirmB.json?.completed === false && confirmB.json?.confirmed === 1 && confirmB.json?.total === 2, confirmB.json);

    const stillActive = await db.project.findUnique({ where: { id: projectId }, select: { status: true } });
    check('после 1-го confirm проект ещё ACTIVE', stillActive?.status === 'ACTIVE', stillActive);

    // ---------- 9. Повторный confirm (B) → 409 ----------
    const confirmB2 = await call(B, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('повторный confirm (B) → 409', confirmB2.status === 409, confirmB2);
    check('текст «уже подтвердили»', /уже подтвердили/.test(confirmB2.json?.error ?? ''), confirmB2.json);

    // ---------- 10. Финальный confirm (A) → кворум, completed ----------
    const confirmA = await call(A, 'POST', `/api/projects/${projectId}/confirm`, {});
    check('confirm (A) → 200 completed=true', confirmA.status === 200 && confirmA.json?.completed === true, confirmA);
    check('confirm (A): confirmed=2/2, pending=0', confirmA.json?.confirmed === 2 && confirmA.json?.pending === 0, confirmA.json);

    const finished = await db.project.findUnique({ where: { id: projectId } });
    check('проект status=completed', finished?.status === 'completed', finished?.status);
    check('completedAt проставлен', !!finished?.completedAt, finished?.completedAt);
    check('рейтинг основателя сохранён (5)', finished?.rating === 5, finished?.rating);
    check('outcome сохранён', finished?.outcome === 'Доставили MVP в срок', finished?.outcome);

    // ---------- 11. DB-эффекты: репутация/уведомления/аудит ----------
    const repEvents = await db.reputationEvent.findMany({
      where: { eventType: 'project_completed', payload: { contains: projectId } },
    });
    check('ReputationEvent ×2 (project_completed, viaQuorum)', repEvents.length === 2 && repEvents.every((e) => e.weight === 5 && e.payload.includes('viaQuorum')), repEvents.length);

    const [aAfter, bAfter] = await Promise.all([
      db.user.findUnique({ where: { id: userA.id }, select: { ipScore: true, level: true } }),
      db.user.findUnique({ where: { id: userB.id }, select: { ipScore: true, level: true } }),
    ]);
    check('IP-score участников пересчитан (>0)', (aAfter?.ipScore ?? 0) > 0 && (bAfter?.ipScore ?? 0) > 0, { a: aAfter, b: bAfter });

    const notifs = await db.notification.findMany({ where: { userId: { in: [userA.id, userB.id] }, type: 'project_completed' } });
    check('Notification ×2 «Проект … завершён»', notifs.length === 2 && notifs.every((n) => n.title.includes('завершён')), notifs.map((n) => n.title));

    const audits = await db.auditLog.findMany({ where: { resourceId: projectId }, select: { action: true } });
    const actions = audits.map((a) => a.action).sort();
    check('AuditLog: requested/transition/confirmed', JSON.stringify(actions) === JSON.stringify(['project_completion_requested', 'project_completed_confirmed', 'project_transition']), actions);

    const confirms = await db.projectConfirmation.findMany({ where: { projectId } });
    check('ProjectConfirmation: обе с confirmedAt', confirms.length === 2 && confirms.every((c) => !!c.confirmedAt), confirms.length);

    const getAfter = await call(A, 'GET', `/api/projects/${projectId}/confirm`);
    check('GET confirm после завершения: waveOpen=false', getAfter.json?.waveOpen === false && getAfter.json?.confirmed === 2, getAfter.json);

    // ---------- 12. Соло-кворум: ACTIVE-проект с 1 активным → мгновенное завершение ----------
    const solo = await call(A, 'POST', '/api/projects', {
      title: `A9 Соло-кворум ${runId}`,
      description: 'Соло-проект: кворум 1 — завершается сразу.',
    });
    const soloId = solo.json?.project?.id as string;
    testProjectIds.push(soloId);
    await call(B, 'PATCH', `/api/projects/${soloId}`, { action: 'join' });
    await call(A, 'POST', `/api/projects/${soloId}/transition`, { status: 'ACTIVE' });
    // B выходит (graceful) → остаётся 1 активный участник.
    // NB: POST /api/projects/[id]/leave у таких участников падает 400
    // «уже покинули с состоянием active» (pre-existing баг: exitState по умолчанию
    // 'active' трактуется как «уже вышел») — поэтому эмулируем выход напрямую в БД.
    const soloMemberB = await db.projectMember.findFirst({ where: { projectId: soloId, userId: userB.id } });
    await db.projectMember.update({ where: { id: soloMemberB!.id }, data: { exitState: 'graceful', exitedAt: new Date() } });
    const soloComplete = await call(A, 'POST', `/api/projects/${soloId}/transition`, { status: 'COMPLETED', rating: 4 });
    check('соло ACTIVE → completed сразу (200, без волны)', soloComplete.status === 200 && !soloComplete.json?.pendingConfirmation, soloComplete);
    const soloRow = await db.project.findUnique({ where: { id: soloId }, select: { status: true } });
    check('соло-проект завершён', soloRow?.status === 'completed', soloRow);
    const soloConfirms = await db.projectConfirmation.count({ where: { projectId: soloId } });
    check('соло-кворум не создаёт записей волны', soloConfirms === 0, { soloConfirms });

    // ---------- 13. Совместимость: recruiting-проект → transition 422, PATCH complete работает ----------
    const fresh = await call(A, 'POST', '/api/projects', {
      title: `A9 Совместимость ${runId}`,
      description: 'Рекрутинг-проект: прежний прямой путь завершения.',
    });
    const freshId = fresh.json?.project?.id as string;
    testProjectIds.push(freshId);
    const freshTransition = await call(A, 'POST', `/api/projects/${freshId}/transition`, { status: 'COMPLETED' });
    check('recruiting → transition completed → 422 (state machine)', freshTransition.status === 422, freshTransition);
    const freshPatch = await call(A, 'PATCH', `/api/projects/${freshId}`, { action: 'complete', rating: 5 });
    check('PATCH complete (прежний путь) → 200', freshPatch.status === 200, freshPatch.status);
    const freshRow = await db.project.findUnique({ where: { id: freshId }, select: { status: true } });
    check('recruiting-проект завершён прежним путём', freshRow?.status === 'completed', freshRow);
  } finally {
    // ---------- 14. Cleanup: тестовые записи проекта/уведомлений/reputation ----------
    const pre = {
      projects: await db.project.count({ where: { id: { in: testProjectIds } } }),
      confirms: await db.projectConfirmation.count({ where: { projectId: { in: testProjectIds } } }),
      notifs: await db.notification.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
      rep: await db.reputationEvent.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
      actions: await db.actionEvent.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
    };
    const auditDel = await db.auditLog.deleteMany({ where: { resourceId: { in: testProjectIds } } });
    await db.user.deleteMany({ where: { emailHash: { startsWith: HASH_PREFIX } } }); // каскад: sessions/projects/members/confirmations/notifications/reputation/actionEvents
    const post = {
      projects: await db.project.count({ where: { id: { in: testProjectIds } } }),
      confirms: await db.projectConfirmation.count({ where: { projectId: { in: testProjectIds } } }),
      notifs: await db.notification.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
      rep: await db.reputationEvent.count({ where: { userId: { in: [userA.id, userB.id, userC.id] } } }),
      users: await db.user.count({ where: { emailHash: { startsWith: HASH_PREFIX } } }),
      sessions: await db.session.count({ where: { token: { startsWith: HASH_PREFIX } } }),
    };
    console.log(`[cleanup] pre: ${JSON.stringify(pre)}; auditLogs removed: ${auditDel.count}`);
    console.log(`[cleanup] post: ${JSON.stringify(post)}`);
    check('cleanup: проекты удалены', post.projects === 0, post);
    check('cleanup: волны подтверждений удалены', post.confirms === 0, post);
    check('cleanup: уведомления удалены', post.notifs === 0, post);
    check('cleanup: reputation-события удалены', post.rep === 0, post);
    check('cleanup: пользователи/сессии удалены', post.users === 0 && post.sessions === 0, post);
  }

  console.log(failures === 0 ? '\n=== ALL CHECKS PASSED ===' : `\n=== ${failures} CHECK(S) FAILED ===`);
  if (failures > 0) process.exit(1);
}

main()
  .catch((e) => {
    console.error('[a9-confirm-test] failed:', e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
```

</details>

---

## Запись №002 — аудит платформы: мёртвые компоненты + tmp-скрипты (10 файлов, 4 пустые директории)

- **Дата:** 2026-09-17 12:42 UTC
- **Коммит:** `83d43d5`
- **Релиз системы:** 1.2.0-honest-pilot
- **Задача:** platform-audit-17-09 (worklog; первый CE-цикл)
- **Общая причина:** полный аудит на недоделанные куски и забытые вставки. Каждое имя проверено `git grep` по всему дереву **до удаления** (коммит `83d43d5^`): единственные упоминания — внутри самих файлов либо цепочка из одного импорта. После удаления гейты tsc=0/lint=0/тесты 76-76 — живых ссылок не осталось.
- **Пустые карантинные директории (копировать нечего):** `src/app/api/projects/[id]/confirm/`, `src/app/api/placements/[id]/review/`, `src/app/api/feed/thoughts/`, `src/components/research/` — остались после записи №001, физически пустые, вне git.

### src/components/profile/public-persona.tsx (1210 строк)

**Причина:** 0 импортов PublicPersona во всём дереве src (проверено git grep по дереву 83d43d5^ — упоминания только внутри самого файла: определения и экспорт)

<details><summary>Резервная копия кода (1210 строк)</summary>

```tsx
// BizON — Public Persona (Этап 3.2 — Блок R)
// Нарративный формат публичного профиля:
//   «Делает X / Делал вместе с N,M,K / Проекты / NFT-навыки / [Спроси у коллег]»
// БЕЗ чисел (IP-score, confirmationsCount, level) — только факты и имена.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Sparkles, Users, FolderKanban, Award, MessageCircleHeart,
  ArrowRight, Calendar, MessageSquareMore, Compass, Send,
  Handshake, Link2, ChevronRight, Mail, Loader2,
} from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { ColleagueInquiryDialog } from '@/components/colleague-inquiries/colleague-inquiry-dialog';
// Этап 4.2 — HR Persona: кнопка «Связаться» для HR-агентств
import { HrContactButton } from '@/components/hr/hr-contact-button';
// Этап 5.3 — CV блок: AI-резюме (для HR view) + Transferable skills блок
import { ResumeGeneratorDialog } from '@/components/cv/resume-generator-dialog';
// P0-3 — Evidence Graph: компактная версия для публичного профиля
import { EvidenceGraph } from '@/components/truth/evidence-graph';

interface PersonaCollaborator {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  projects: Array<{ title: string; yearRange: string }>;
  projectsCount: number;
}

interface PersonaProject {
  id: string;
  title: string;
  teamSize: number;
  yearRange: string;
  status: string;
  role: string;
}

interface PersonaNftSkill {
  skillName: string;
  level: number;
  confirmedBy: string[];
}

interface PersonaData {
  user: {
    id: string;
    name: string;
    title: string | null;
    bio: string | null;
    avatarUrl: string | null;
    roles: string[];
    accountType?: string;
    hrInvisible?: boolean;
    createdAt: string;
    professionalStatus?: string | null;
  };
  professionalSince: number;
  does: string[];
  collaborators: PersonaCollaborator[];
  collaboratorsTotal: number;
  projects: PersonaProject[];
  nftSkills: PersonaNftSkill[];
}

interface PublicPersonaProps {
  userId: string;
  /**
   * Если true — владелец смотрит «Как видят меня».
   * Скрывает кнопку «Добавить в контакты» / «Спроси у коллег» (последняя всё равно доступна как заглушка,
   * но кнопка «Добавить в контакты» скрывается).
   */
  previewMode?: boolean;
  /** Колбэк для добавления в контакты (внешняя логика). */
  onAddConnection?: () => void;
}

export function PublicPersona({ userId, previewMode = false, onAddConnection }: PublicPersonaProps) {
  const { setProfileUserId, user: currentUser } = useAppStore();
  const [data, setData] = React.useState<PersonaData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [collabLimit, setCollabLimit] = React.useState(5);
  // R9: выбранный коллега для диалога «Спроси у коллег»
  const [inquiryColleague, setInquiryColleague] = React.useState<PersonaCollaborator | null>(null);
  // Правка 3: диалог «Написать сообщение» (через /api/messages)
  const [messageOpen, setMessageOpen] = React.useState(false);

  // Этап 5.3 — HR view transferable skills
  const isHrViewer =
    !previewMode &&
    !!currentUser &&
    currentUser.id !== userId &&
    currentUser.accountType === 'hr_agency';

  const load = React.useCallback(async (limit: number) => {
    setLoading(true);
    try {
      const res = await api<PersonaData>(`/api/users/${userId}/persona?limit=${limit}`);
      setData(res);
    } catch (e: any) {
      toast({ title: 'Не удалось загрузить профиль', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load(collabLimit);
  }, [load, collabLimit]);

  // R9: можно спросить у коллег ТОЛЬКО если:
  //   • не preview mode
  //   • пользователь авторизован
  //   • это не свой собственный профиль
  //   • мы спрашиваем про aboutUser (владельца страницы)
  const canAskColleagues =
    !previewMode && !!currentUser && currentUser.id !== userId;

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
      </div>
    );
  }

  const u = data.user;
  const hasMoreCollaborators = data.collaboratorsTotal > data.collaborators.length;

  return (
    <div className="space-y-4">
      {/* Header card — Имя + специальность + «с YYYY в профессии» */}
      <Card className="overflow-hidden">
        <div className="h-20 bg-gradient-to-r from-primary/15 via-accent/40 to-primary/10" />
        <CardContent className="pt-0">
          <div className="flex items-start gap-4 -mt-10">
            <div className="rounded-full ring-4 ring-card bg-card">
              <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="xl" />
            </div>
            <div className="flex-1 pt-10 min-w-0">
              <h1 className="text-2xl font-bold truncate">{u.name}</h1>
              <div className="text-sm text-muted-foreground mt-1 flex items-center gap-2 flex-wrap">
                {u.title && <span className="font-medium text-foreground/80">{u.title}</span>}
                <span className="text-muted-foreground/70">·</span>
                <span>с {data.professionalSince} в профессии</span>
              </div>
              {u.roles && u.roles.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {u.roles.map((r) => (
                    <Badge key={r} variant="secondary" className="text-xs">{r}</Badge>
                  ))}
                </div>
              )}
              {/* Phase 3: Professional Status — бейдж (если установлен) */}
              {u.professionalStatus && (
                <div className="mt-2">
                  <ProfessionalStatusBadge status={u.professionalStatus} />
                </div>
              )}
            </div>
            {!previewMode && onAddConnection && (
              <div className="pt-10 flex gap-2 flex-wrap justify-end">
                <Button size="sm" variant="outline" onClick={onAddConnection}>
                  <Users className="w-4 h-4 mr-1" /> В контакты
                </Button>
                {/* Правка 3 — Кнопка «Написать сообщение» через /api/messages */}
                {canAskColleagues && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setMessageOpen(true)}
                  >
                    <Mail className="w-4 h-4 mr-1" /> Написать
                  </Button>
                )}
                {/* Этап 4.2 — HR Persona: кнопка «Связаться» для HR-агентств */}
                {currentUser?.accountType === 'hr_agency' &&
                  u.accountType === 'individual' && (
                    <HrContactButton
                      candidateId={u.id}
                      candidateName={u.name}
                      candidateHrInvisible={u.hrInvisible}
                    />
                  )}
              </div>
            )}
          </div>
          {u.bio && <p className="mt-4 text-sm text-foreground/80 leading-relaxed">{u.bio}</p>}

          {/* Этап 5.3 — CV блок: кнопка «Сформировать резюме» для HR viewing individual */}
          {isHrViewer && u.accountType === 'individual' && !u.hrInvisible && (
            <div className="mt-4 pt-4 border-t flex items-center justify-between gap-2 flex-wrap">
              <div className="text-xs text-muted-foreground">
                Сформируйте персонализированное резюме кандидата на основе подтверждённых навыков и проектов.
              </div>
              <ResumeGeneratorDialog
                targetUserId={u.id}
                triggerLabel="Сформировать резюме"
                triggerVariant="outline"
                triggerSize="sm"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Правка 3 — Общие контакты + Цепочка доверия (только для зарегистрированных, не preview) */}
      {canAskColleagues && (
        <>
          <CommonContactsBlock userId={u.id} userName={u.name} />
          <TrustChainBlock userId={u.id} userName={u.name} />
        </>
      )}

      {/* ДЕЛАЕТ */}
      {data.does.length > 0 && (
        <Card>
          <CardContent className="p-4 sm:p-6">
            <SectionTitle icon={<Sparkles className="w-4 h-4" />} label="ДЕЛАЕТ" />
            <div className="flex flex-wrap gap-2 mt-3">
              {data.does.map((s) => (
                <Badge key={s} variant="outline" className="px-3 py-1 text-sm font-medium">
                  {s}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ДЕЛАЛ ВМЕСТЕ С */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <SectionTitle
            icon={<Users className="w-4 h-4" />}
            label="ДЕЛАЛ ВМЕСТЕ С"
            right={
              data.collaboratorsTotal > 0 && (
                <span className="text-xs text-muted-foreground">
                  {data.collaboratorsTotal} {pluralColl(data.collaboratorsTotal)}
                </span>
              )
            }
          />
          {data.collaborators.length === 0 ? (
            <p className="text-sm text-muted-foreground mt-3">
              Публичных совместных проектов пока нет.
            </p>
          ) : (
            <ul className="mt-3 space-y-3">
              {data.collaborators.map((c) => (
                <li key={c.id} className="flex items-start gap-2">
                  <button
                    type="button"
                    onClick={() => !previewMode && setProfileUserId(c.id)}
                    className={cn(
                      'flex-1 text-left flex items-start gap-3 p-2 rounded-lg transition',
                      !previewMode && 'hover:bg-accent/40'
                    )}
                    disabled={previewMode}
                  >
                    <UserAvatar name={c.name} avatarUrl={c.avatarUrl} size="sm" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{c.name}</div>
                      {c.title && (
                        <div className="text-xs text-muted-foreground truncate">{c.title}</div>
                      )}
                      <div className="mt-1 space-y-0.5">
                        {c.projects.map((p, i) => (
                          <div key={i} className="text-xs text-foreground/70 flex items-start gap-1.5">
                            <span className="text-muted-foreground/60 mt-0.5">—</span>
                            <span>
                              <span className="font-medium">{p.title}</span>
                              <span className="text-muted-foreground"> · {p.yearRange}</span>
                            </span>
                          </div>
                        ))}
                        {c.projectsCount > c.projects.length && (
                          <div className="text-xs text-muted-foreground/70 pl-3">
                            ещё {c.projectsCount - c.projects.length} проектов вместе
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                  {/* R9: кнопка «Спросить» рядом с коллаборатором */}
                  {canAskColleagues && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setInquiryColleague(c);
                      }}
                      title={`Спросить у ${c.name.split(' ')[0]} про ${u.name.split(' ')[0]}`}
                      className="shrink-0 mt-1 inline-flex items-center gap-1 text-xs px-2 py-1 rounded-md border border-lighthouse/30 text-lighthouse hover:bg-lighthouse/10 transition"
                    >
                      <MessageSquareMore className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Спросить</span>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
          {hasMoreCollaborators && (
            <button
              type="button"
              onClick={() => setCollabLimit((l) => l + 10)}
              className="mt-3 inline-flex items-center gap-1 text-sm text-primary hover:underline"
            >
              Показать ещё <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </CardContent>
      </Card>

      {/* ПРОЕКТЫ */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <SectionTitle
            icon={<FolderKanban className="w-4 h-4" />}
            label="ПРОЕКТЫ"
            right={
              data.projects.length > 0 && (
                <span className="text-xs text-muted-foreground">
                  {data.projects.length} {pluralProj(data.projects.length)}
                </span>
              )
            }
          />
          {data.projects.length === 0 ? (
            <p className="text-sm text-muted-foreground mt-3">Проектов пока нет.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {data.projects.map((p) => (
                <li
                  key={p.id}
                  className="flex items-start gap-2 p-2 rounded-lg bg-muted/30"
                >
                  <span className="text-muted-foreground/60 mt-0.5">—</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">
                      {p.title}
                      <span className="text-muted-foreground font-normal">
                        {'  '}· команда {p.teamSize}, {p.yearRange}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1.5">
                      <Badge variant="outline" className="text-xs px-1.5 py-0">
                        {statusLabel(p.status)}
                      </Badge>
                      <span>· роль: {roleLabel(p.role)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* NFT-НАВЫКИ (факты) */}
      {data.nftSkills.length > 0 && (
        <Card>
          <CardContent className="p-4 sm:p-6">
            <SectionTitle icon={<Award className="w-4 h-4" />} label="NFT-НАВЫКИ" />
            <p className="text-xs text-muted-foreground mt-1 mb-3">
              Факты, подтверждённые коллегами через совместные проекты.
            </p>
            <ul className="space-y-2">
              {data.nftSkills.map((nft, i) => (
                <li key={`${nft.skillName}-${i}`} className="flex items-start gap-2">
                  <span className="text-muted-foreground/60 mt-0.5">—</span>
                  <div className="text-sm">
                    <span className="font-medium">{nft.skillName}</span>
                    {nft.confirmedBy.length > 0 ? (
                      <span className="text-muted-foreground">
                        {' '}— подтверждён {formatConfirmers(nft.confirmedBy)}
                      </span>
                    ) : (
                      <span className="text-muted-foreground"> — NFT выпущен</span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* P0-3 — Evidence Graph (компактная версия для публичного профиля) */}
      <EvidenceGraph userId={u.id} compact />

      {/* Этап 5.3 — HR view Transferable skills (только для HR-агентств) */}
      {isHrViewer && u.accountType === 'individual' && !u.hrInvisible && (
        <HrTransferableBlock userId={u.id} userName={u.name} />
      )}

      {/* Спроси у коллег — информационная плашка (само действие — через кнопки у каждого коллаборатора) */}
      <Card className="bg-lighthouse-gradient-soft border-lighthouse/30">
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-start gap-3">
            <div className="rounded-full bg-background/60 p-2 shrink-0">
              <MessageCircleHeart className="w-5 h-5 text-lighthouse" />
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold">
                Хотите узнать, как с {u.name.split(' ')[0]} работается?
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {canAskColleagues ? (
                  data.collaborators.length > 0
                    ? `Нажмите «Спросить» рядом с любым коллегой выше — отправим личный запрос. Никаких оценок и звёзд, только живые истории.`
                    : `У этого пользователя пока нет публичных совместных проектов. Как только они появятся — вы сможете спросить у коллег.`
                ) : (
                  `Попросите коллег поделиться опытом — без оценок и звёзд, только живые истории.`
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Footer-метка для preview-режима */}
      {previewMode && (
        <div className="text-center text-xs text-muted-foreground">
          <Calendar className="w-3 h-3 inline mr-1" />
          Это публичный вид вашего профиля — так его видят другие.
        </div>
      )}

      {/* R9: Диалог «Спроси у коллег» */}
      {inquiryColleague && (
        <ColleagueInquiryDialog
          open={!!inquiryColleague}
          onOpenChange={(o) => !o && setInquiryColleague(null)}
          colleague={inquiryColleague}
          aboutUser={{
            id: u.id,
            name: u.name,
            avatarUrl: u.avatarUrl,
          }}
        />
      )}

      {/* Правка 3 — Диалог «Написать сообщение» (POST /api/messages) */}
      {messageOpen && (
        <MessageComposeDialog
          open={messageOpen}
          onOpenChange={setMessageOpen}
          toUserId={u.id}
          toUserName={u.name}
        />
      )}
    </div>
  );
}

// ============================================================================
// Phase 3: ProfessionalStatusBadge — бейдж профессионального статуса.
// Используется в публичном профиле рядом с именем/ролью.
// Цветовая схема совпадает с настройками (settings-view.tsx).
// ============================================================================
const PROFESSIONAL_STATUS_META: Record<string, {
  label: string;
  dotClass: string;
  badgeClass: string;
}> = {
  active_searching: {
    label: 'Активно ищу работу',
    dotClass: 'bg-emerald-500',
    badgeClass: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30',
  },
  open_to_offers: {
    label: 'Открыт предложениям',
    dotClass: 'bg-blue-500',
    badgeClass: 'bg-blue-500/10 text-blue-700 dark:text-blue-300 border-blue-500/30',
  },
  open_to_projects: {
    label: 'Ищу проект',
    dotClass: 'bg-amber-500',
    badgeClass: 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30',
  },
  open_to_consulting: {
    label: 'Готов к консультациям',
    dotClass: 'bg-purple-500',
    badgeClass: 'bg-purple-500/10 text-purple-700 dark:text-purple-300 border-purple-500/30',
  },
  not_searching: {
    label: 'Не ищу',
    dotClass: 'bg-muted-foreground',
    badgeClass: 'bg-muted/40 text-muted-foreground border-border',
  },
};

export function ProfessionalStatusBadge({ status }: { status: string | null }) {
  if (!status) return null;
  const meta = PROFESSIONAL_STATUS_META[status];
  if (!meta) return null;
  return (
    <Badge
      variant="outline"
      className={`text-xs gap-1.5 ${meta.badgeClass}`}
      title={meta.label}
    >
      <span
        className={`w-2 h-2 rounded-full inline-block ${meta.dotClass}`}
        aria-hidden
      />
      {meta.label}
    </Badge>
  );
}

function SectionTitle({
  icon,
  label,
  right,
}: {
  icon: React.ReactNode;
  label: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <span className="text-muted-foreground">{icon}</span>
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
      </div>
      {right}
    </div>
  );
}

function statusLabel(s: string) {
  return (
    { recruiting: 'Набор', active: 'Активен', completed: 'Завершён', cancelled: 'Отменён' } as Record<string, string>
  )[s] ?? s;
}

function roleLabel(r: string) {
  return ({ owner: 'владелец', lead: 'лид', member: 'участник' } as Record<string, string>)[r] ?? r;
}

function pluralColl(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'коллега';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'коллеги';
  return 'коллег';
}

function pluralProj(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'проект';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'проекта';
  return 'проектов';
}

function formatConfirmers(names: string[]): string {
  if (names.length === 0) return '';
  if (names.length === 1) return `${shortName(names[0])}`;
  if (names.length === 2) return `${shortName(names[0])} и ${shortName(names[1])}`;
  return `${shortName(names[0])}, ${shortName(names[1])} и другими`;
}

function shortName(fullName: string): string {
  // «Мария Иванова» → «М. Ивановой» (для нарратива)
  const parts = fullName.trim().split(/\s+/);
  if (parts.length < 2) return fullName;
  const first = parts[0];
  const last = parts[parts.length - 1];
  const initial = first[0]?.toUpperCase() ?? '';
  // Склонение фамилии в творительный падеж — упрощённо: «Иванова» → «Ивановой»
  const lastNameTvr = declineLastNameTvr(last);
  return `${initial}. ${lastNameTvr}`;
}

// Очень упрощённое склонение русских фамилий в творительный падеж для нарратива
function declineLastNameTvr(last: string): string {
  if (!last) return last;
  // Женские на -ова/-ева/-ёва/-на
  if (/ова$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/ева$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/ёва$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/на$/i.test(last)) return last.slice(0, -1) + 'ой';
  if (/ская$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/цкая$/i.test(last)) return last.slice(0, -2) + 'ой';
  // Мужские на -ов/-ев/-ёв/-ин/-ын/-ский/-цкий
  if (/ов$/i.test(last)) return last + 'ым';
  if (/ев$/i.test(last)) return last + 'ым';
  if (/ёв$/i.test(last)) return last + 'ым';
  if (/ин$/i.test(last)) return last + 'ым';
  if (/ын$/i.test(last)) return last + 'ым';
  if (/ский$/i.test(last)) return last.slice(0, -2) + 'им';
  if (/цкий$/i.test(last)) return last.slice(0, -2) + 'им';
  // fallback
  return last;
}

// ============================================================================
// Этап 5.3 — HR Transferable skills блок
// Показывается только HR-агентствам (currentUser.accountType='hr_agency') при просмотре
// профиля кандидата (individual). Загружает /api/users/[id]/transferable.
// Хобби показываются только если кандидат дал opt-in (showHobbiesToHr=true).
// ============================================================================
interface TransferableResponse {
  user: {
    id: string;
    name: string;
    title: string | null;
    bio: string | null;
    ipScore: number;
    level: string;
    avatarUrl: string | null;
  };
  confirmedSkills: Array<{
    id: string;
    name: string;
    level: number;
    verificationLevel: string;
    confirmationsCount: number;
  }>;
  hobbies: string[]; // полный список — только если showHobbiesToHr=true
  hobbiesCount: number; // счётчик всегда показывается
  hobbiesVisible: boolean;
  annotation: string;
  engine: 'llm' | 'fallback';
}

function HrTransferableBlock({ userId, userName }: { userId: string; userName: string }) {
  const [data, setData] = React.useState<TransferableResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [invitationOpen, setInvitationOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<TransferableResponse>(`/api/users/${userId}/transferable`);
      setData(res);
    } catch (e: any) {
      // 403 = Privacy Shield / не HR
      setError(e?.message ?? 'Не удалось загрузить transferable skills');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <Card className="border-lighthouse/30">
        <CardContent className="p-4 sm:p-6 space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (error || !data) {
    // Тихая ошибка — не показываем HR'у детали, просто не рендерим блок
    // (Privacy Shield — кандидат сам решил не быть видимым)
    return null;
  }

  return (
    <Card className="border-lighthouse/30 bg-lighthouse-gradient-soft">
      <CardContent className="p-4 sm:p-6 space-y-3">
        <SectionTitle
          icon={<Compass className="w-4 h-4 text-lighthouse" />}
          label="TRANSFERABLE SKILLS"
          right={
            <Badge variant="outline" className="text-xs gap-1">
              {data.engine === 'llm' ? 'AI-аннотация' : 'Из фактов'}
            </Badge>
          }
        />

        {/* AI-аннотация: «Сильные стороны: X, Y. Transferable для: A, B, C.» */}
        <p className="text-sm leading-relaxed pt-1">{data.annotation}</p>

        {/* Подтверждённые навыки */}
        {data.confirmedSkills.length > 0 && (
          <div className="pt-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Подтверждённые навыки ({data.confirmedSkills.length})
            </div>
            <div className="flex flex-wrap gap-1.5">
              {data.confirmedSkills.slice(0, 12).map((s) => (
                <Badge key={s.id} variant="secondary" className="text-xs gap-1">
                  {s.name}
                  <span className="text-xs text-muted-foreground">·{s.level}/5</span>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Хобби — только если showHobbiesToHr=true */}
        {data.hobbiesVisible && data.hobbies.length > 0 ? (
          <div className="pt-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Хобби (видны по opt-in кандидата)
            </div>
            <div className="flex flex-wrap gap-1.5">
              {data.hobbies.map((h, i) => (
                <Badge key={`${h}-${i}`} variant="outline" className="text-xs">
                  {h}
                </Badge>
              ))}
            </div>
          </div>
        ) : data.hobbiesCount > 0 ? (
          <div className="pt-2 text-xs text-muted-foreground italic">
            У кандидата {data.hobbiesCount}{' '}
            {data.hobbiesCount === 1 ? 'хобби' : data.hobbiesCount < 5 ? 'хобби' : 'хобби'}, но он не дал согласия
            на показ HR. Список анонимизирован.
          </div>
        ) : null}

        {/* Кнопка «Отправить персонализированное приглашение» */}
        <div className="pt-3 border-t flex justify-end">
          <Button size="sm" variant="outline" onClick={() => setInvitationOpen(true)} className="gap-1.5">
            <Send className="w-3.5 h-3.5" />
            Отправить персонализированное приглашение
          </Button>
        </div>
      </CardContent>

      {/* Диалог «Персонализированное приглашение» — пока заглушка */}
      {invitationOpen && (
        <InvitationDialog
          open={invitationOpen}
          onOpenChange={setInvitationOpen}
          candidateId={userId}
          candidateName={userName}
          annotation={data.annotation}
        />
      )}
    </Card>
  );
}

// ============================================================================
// Заглушка: диалог персонализированного приглашения
// В продакшене — должно открывать HrContactButton с предзаполненным сообщением
// из AI-аннотации transferable skills. Пока — простая обёртка.
// ============================================================================
function InvitationDialog({
  open,
  onOpenChange,
  candidateId,
  candidateName,
  annotation,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  candidateId: string;
  candidateName: string;
  annotation: string;
}) {
  // Используем существующий HrContactButton внутри диалога — он уже умеет отправлять
  // контакт с сообщением. Предзаполним сообщение аннотацией transferable skills.
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-4 h-4 text-lighthouse" />
            Персонализированное приглашение для {candidateName}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="rounded-lg bg-muted/40 border border-muted p-3 text-xs text-muted-foreground">
            <div className="font-medium text-foreground mb-1">AI-контекст кандидата:</div>
            {annotation}
          </div>
          <p className="text-sm text-muted-foreground">
            Нажмите кнопку ниже, чтобы инициировать контакт. Лимит — 1 контакт в неделю на кандидата.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
              Отмена
            </Button>
            <HrContactButton
              candidateId={candidateId}
              candidateName={candidateName}
              // Сообщение предзаполнить аннотацией — пользователь увидит поле и сможет отредактировать
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// Правка 3 — Блок «Общие контакты» (как Vings/XING)
// Загружает /api/users/[id]/common-contacts, показывает до 3 аватаров + «+N»
// ============================================================================
interface CommonContact {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
}
interface CommonContactsResponse {
  contacts: CommonContact[];
  total: number;
}

function CommonContactsBlock({ userId, userName }: { userId: string; userName: string }) {
  const { setProfileUserId } = useAppStore();
  const [data, setData] = React.useState<CommonContactsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<CommonContactsResponse>(`/api/users/${userId}/common-contacts`);
      setData(res);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить общих контактов');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  return (
    <Card>
      <CardContent className="p-4 sm:p-6">
        <SectionTitle
          icon={<Handshake className="w-4 h-4" />}
          label="ОБЩИЕ КОНТАКТЫ"
          right={
            !loading && data ? (
              <span className="text-xs text-muted-foreground">
                {data.total} {pluralCommon(data.total)}
              </span>
            ) : null
          }
        />

        {loading ? (
          <div className="flex items-center gap-2 mt-3">
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-9 h-9 rounded-full" />
          </div>
        ) : error ? (
          <p className="text-xs text-muted-foreground mt-3">
            Не удалось загрузить общих контактов.
          </p>
        ) : !data || data.total === 0 ? (
          <p className="text-sm text-muted-foreground mt-3">
            Нет общих контактов с {userName.split(' ')[0]}.
          </p>
        ) : (
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            {/* До 3 аватаров */}
            {data.contacts.slice(0, 3).map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setProfileUserId(c.id)}
                title={c.title ? `${c.name} · ${c.title}` : c.name}
                className="group flex flex-col items-center gap-1 transition hover:opacity-80"
              >
                <div className="rounded-full ring-2 ring-background">
                  <UserAvatar name={c.name} avatarUrl={c.avatarUrl} size="sm" />
                </div>
                <span className="text-xs text-muted-foreground max-w-[60px] truncate">
                  {c.name.split(' ')[0]}
                </span>
              </button>
            ))}
            {/* «+N» если больше */}
            {data.total > 3 && (
              <div
                className="flex items-center justify-center w-8 h-8 rounded-full bg-muted text-xs font-semibold text-muted-foreground ring-2 ring-background"
                title={`Ещё ${data.total - 3} общих контактов`}
              >
                +{data.total - 3}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Правка 3 — Блок «Цепочка доверия» (killer feature)
// POST /api/ai/matchmaker { toUserId } → визуализация пути
// ============================================================================
interface MatchmakerPathUser {
  userId: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  ipScore: number;
}
interface MatchmakerPathResponse {
  found: boolean;
  path: MatchmakerPathUser[];
  confidence: number;
  introducerId: string | null;
  introTemplate: string;
}

function TrustChainBlock({ userId, userName }: { userId: string; userName: string }) {
  const { setProfileUserId, user: currentUser } = useAppStore();
  const [data, setData] = React.useState<MatchmakerPathResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Существующий /api/ai/matchmaker POST принимает { toUserId }.
      // Находит кратчайший путь в графе доверия (5 рукопожатий).
      const res = await api<MatchmakerPathResponse>(`/api/ai/matchmaker`, {
        method: 'POST',
        body: JSON.stringify({ toUserId: userId }),
      });
      setData(res);
    } catch (e: any) {
      // 429 — rate limit по тарифу; не показываем как ошибку, просто «Нет цепочки»
      setError(e?.message ?? 'Не удалось построить цепочку доверия');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  // Число «рукопожатий» = число рёбер = path.length - 1
  // path[0] = я, path[last] = целевой пользователь.
  // Прямая связь (path.length === 2) — «Вы связаны напрямую»
  const handshakes = data?.path?.length ? data.path.length - 1 : 0;
  const isDirect = handshakes === 1;

  return (
    <Card className="bg-lighthouse-gradient-soft border-lighthouse/30">
      <CardContent className="p-4 sm:p-6">
        <SectionTitle
          icon={<Link2 className="w-4 h-4 text-lighthouse" />}
          label="ЦЕПОЧКА ДОВЕРИЯ"
          right={
            !loading && data?.found ? (
              <span className="text-xs text-muted-foreground">
                {isDirect ? 'напрямую' : `${handshakes} рукопожатия`}
              </span>
            ) : null
          }
        />

        {loading ? (
          <div className="flex items-center gap-2 mt-3">
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-8 h-1.5" />
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-8 h-1.5" />
            <Skeleton className="w-9 h-9 rounded-full" />
          </div>
        ) : !data || !data.found ? (
          <p className="text-sm text-muted-foreground mt-3">
            Нет цепочки доверия до {userName.split(' ')[0]}.
            {error && error.includes('лимит') && (
              <span className="block mt-1 text-xs text-amber-600 dark:text-amber-400">
                {error}
              </span>
            )}
          </p>
        ) : isDirect ? (
          <div className="mt-3 flex items-center gap-2 text-sm">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-lighthouse/15 text-lighthouse font-medium">
              <Handshake className="w-3.5 h-3.5" />
              Вы связаны напрямую
            </span>
          </div>
        ) : (
          <div className="mt-3 flex items-center gap-1.5 flex-wrap">
            {/* «Ты» — первый узел пути */}
            <PathNode
              name={currentUser?.name ?? 'Вы'}
              avatarUrl={currentUser?.avatarUrl ?? null}
              isMe
            />
            {/* Промежуточные узлы + целевой */}
            {data.path.slice(1).map((node, idx) => (
              <React.Fragment key={node.userId}>
                <Arrow />
                <PathNode
                  name={node.name}
                  avatarUrl={node.avatarUrl}
                  isLast={idx === data.path.length - 2}
                  onClick={() =>
                    idx !== data.path.length - 2 && setProfileUserId(node.userId)
                  }
                />
              </React.Fragment>
            ))}
          </div>
        )}

        {!loading && data?.found && !isDirect && data.path.length > 2 && (
          <p className="text-xs text-muted-foreground mt-2">
            Через {shortFirstName(data.path[1].name)} можно попросить интро.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function PathNode({
  name,
  avatarUrl,
  isMe = false,
  isLast = false,
  onClick,
}: {
  name: string;
  avatarUrl: string | null;
  isMe?: boolean;
  isLast?: boolean;
  onClick?: () => void;
}) {
  const inner = (
    <>
      <div
        className={cn(
          'rounded-full ring-2 ring-background',
          isMe && 'ring-lighthouse/30'
        )}
      >
        <UserAvatar name={name} avatarUrl={avatarUrl} size="sm" />
      </div>
      <span
        className={cn(
          'text-xs mt-1 max-w-[64px] truncate',
          isLast ? 'font-medium text-foreground' : 'text-muted-foreground'
        )}
      >
        {isMe ? 'Вы' : name.split(' ')[0]}
      </span>
    </>
  );

  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        title={name}
        className="group flex flex-col items-center gap-0.5 transition hover:opacity-80"
      >
        {inner}
      </button>
    );
  }
  return (
    <div className="flex flex-col items-center gap-0.5" title={name}>
      {inner}
    </div>
  );
}

function Arrow() {
  return (
    <ChevronRight className="w-4 h-4 text-muted-foreground/60 self-center mt-[-12px]" />
  );
}

// ============================================================================
// Правка 3 — Диалог «Написать сообщение» (POST /api/messages)
// ============================================================================
function MessageComposeDialog({
  open,
  onOpenChange,
  toUserId,
  toUserName,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  toUserId: string;
  toUserName: string;
}) {
  const [content, setContent] = React.useState('');
  const [sending, setSending] = React.useState(false);

  const handleSend = async () => {
    const trimmed = content.trim();
    if (!trimmed) {
      toast({ title: 'Введите текст сообщения', variant: 'destructive' });
      return;
    }
    setSending(true);
    try {
      await api('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ toUserId, content: trimmed }),
      });
      toast({ title: `Сообщение отправлено для ${toUserName.split(' ')[0]}` });
      setContent('');
      onOpenChange(false);
    } catch (e: any) {
      toast({
        title: 'Не удалось отправить',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-lighthouse" />
            Написать {toUserName.split(' ')[0]}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`Здравствуйте, ${toUserName.split(' ')[0]}! ...`}
            rows={5}
            maxLength={2000}
            disabled={sending}
          />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Максимум 2000 символов</span>
            <span>{content.length}/2000</span>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onOpenChange(false)}
              disabled={sending}
            >
              Отмена
            </Button>
            <Button size="sm" onClick={handleSend} disabled={sending || !content.trim()}>
              {sending ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> Отправка...
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5 mr-1" /> Отправить
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Вспомогательные plural/имя для блоков Правки 3
function pluralCommon(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'общий контакт';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'общих контакта';
  return 'общих контактов';
}

function shortFirstName(fullName: string): string {
  return fullName.trim().split(/\s+/)[0] ?? fullName;
}
```

</details>

### src/components/colleague-inquiries/colleague-inquiry-dialog.tsx (213 строк)

**Причина:** единственный импорт во всём коде — public-persona.tsx:23; цепочка: умирает вместе с public-persona (сам по себе не монтируется)

<details><summary>Резервная копия кода (213 строк)</summary>

```tsx
// BizON — ColleagueInquiryDialog (R9 «Спроси у коллег»)
// Модалка для отправки личного запроса коллеге с просьбой поделиться
// опытом работы с третьим человеком.
//
// Используется в PublicPersona: рядом с каждым коллаборатором в списке
// «ДЕЛАЛ ВМЕСТЕ С» появляется кнопка «Спросить». При клике открывается эта модалка.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import { Loader2, MessageCircleHeart, Send } from 'lucide-react';

interface ColleagueInquiryDialogProps {
  /** Коллега, у которого спрашивают. */
  colleague: {
    id: string;
    name: string;
    title?: string | null;
    avatarUrl?: string | null;
  };
  /** Человек, про которого спрашивают. */
  aboutUser: {
    id: string;
    name: string;
    avatarUrl?: string | null;
  };
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Колбэк после успешной отправки (например, чтобы закрыть модалку). */
  onSent?: () => void;
}

const DEFAULT_MESSAGE =
  'Привет! Видел, что вы работали вместе с {about}. Поделись, пожалуйста, как тебе с ним работалось?';

const MAX_LENGTH = 2000;

export function ColleagueInquiryDialog({
  colleague,
  aboutUser,
  open,
  onOpenChange,
  onSent,
}: ColleagueInquiryDialogProps) {
  const [message, setMessage] = React.useState('');
  const [isAnonymous, setIsAnonymous] = React.useState(false);
  const [sending, setSending] = React.useState(false);

  // Pre-fill message when dialog opens
  React.useEffect(() => {
    if (open) {
      setMessage(DEFAULT_MESSAGE.replace('{about}', aboutUser.name));
      setIsAnonymous(false);
    }
  }, [open, aboutUser.name]);

  const handleSend = async () => {
    if (!message.trim()) {
      toast({ title: 'Введите текст запроса', variant: 'destructive' });
      return;
    }
    if (message.length > MAX_LENGTH) {
      toast({
        title: `Сообщение слишком длинное (макс. ${MAX_LENGTH} символов)`,
        variant: 'destructive',
      });
      return;
    }
    setSending(true);
    try {
      await api('/api/colleague-inquiries', {
        method: 'POST',
        body: JSON.stringify({
          toUserId: colleague.id,
          aboutUserId: aboutUser.id,
          message: message.trim(),
          isAnonymous,
        }),
      });
      toast({
        title: 'Запрос отправлен',
        description: `${colleague.name} получит уведомление и сможет ответить в разделе «Что нового».`,
      });
      onOpenChange(false);
      onSent?.();
    } catch (e: any) {
      toast({
        title: 'Не удалось отправить запрос',
        description: e?.message ?? 'Попробуйте ещё раз.',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageCircleHeart className="w-5 h-5 text-lighthouse" />
            Спросить у коллеги
          </DialogTitle>
          <DialogDescription>
            Личный запрос — никто, кроме коллеги, его не увидит.
          </DialogDescription>
        </DialogHeader>

        {/* Коллега → про кого */}
        <div className="flex items-center gap-3 py-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <UserAvatar
              name={colleague.name}
              avatarUrl={colleague.avatarUrl ?? null}
              size="sm"
            />
            <div className="min-w-0">
              <div className="text-sm font-medium truncate">{colleague.name}</div>
              {colleague.title && (
                <div className="text-xs text-muted-foreground truncate">{colleague.title}</div>
              )}
            </div>
          </div>
          <div className="text-muted-foreground text-xs px-1">про</div>
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <UserAvatar
              name={aboutUser.name}
              avatarUrl={aboutUser.avatarUrl ?? null}
              size="sm"
            />
            <div className="min-w-0">
              <div className="text-sm font-medium truncate">{aboutUser.name}</div>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="inquiry-message">Сообщение</Label>
          <Textarea
            id="inquiry-message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={5}
            maxLength={MAX_LENGTH}
            placeholder="Напишите, что именно хотите узнать…"
            disabled={sending}
          />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{message.length} / {MAX_LENGTH}</span>
            <span>Коллега увидит запрос в разделе «Что нового»</span>
          </div>
        </div>

        {/* Анонимно */}
        <label
          htmlFor="inquiry-anonymous"
          className="flex items-center justify-between gap-3 rounded-lg border bg-muted/30 p-3 cursor-pointer"
        >
          <div className="space-y-0.5">
            <div className="text-sm font-medium">Анонимно</div>
            <div className="text-xs text-muted-foreground">
              Коллега не увидит ваше имя — только сообщение.
            </div>
          </div>
          <Switch
            id="inquiry-anonymous"
            checked={isAnonymous}
            onCheckedChange={setIsAnonymous}
            disabled={sending}
          />
        </label>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={sending}
          >
            Отмена
          </Button>
          <Button onClick={handleSend} disabled={sending || !message.trim()}>
            {sending ? (
              <>
                <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                Отправка…
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-1.5" />
                Отправить
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
```

</details>

### src/components/jobs/compare-vacancies.tsx (526 строк)

**Причина:** упоминания CompareVacanciesDialog/CompareVacanciesButton только внутри самого файла (экспорты и док-комментарий); кнопка «Сравнить вакансии» не рендерится ни на одной странице

<details><summary>Резервная копия кода (526 строк)</summary>

```tsx
// BizON — Compare Vacancies (P1: Side-by-side сравнение вакансий)
// Модалка с таблицей сравнения по метрикам: Match / Hiring Reality / Employer Trust /
// Время ответа / Зарплата / Время закрытия / Проекты / Рост.
// Источник: POST /api/jobs/compare { jobIds: string[] }
//
// Вызов:
//   <CompareVacanciesDialog jobIds={[...]} open={...} onOpenChange={...} />
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import {
  Sparkles,
  Loader2,
  ShieldCheck,
  TrendingUp,
  Clock,
  Wallet,
  CheckCircle2,
  Minus,
  GitBranch,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ---------- типы ответа API ----------

interface CompareRow {
  jobId: string;
  title: string;
  company: string;
  companyId: string | null;
  match: number;
  hiringReality: number;
  employerTrust: number | null;
  responseDays: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  closureDays: number | null;
  hasTrustChain: boolean;
  growthScore: number;
  growthLabel: 'низкий' | 'средний' | 'высокий' | 'оч. высокий';
  requiredSkills: string[];
  matchedSkills: string[];
  missingSkills: string[];
}

interface CompareResponse {
  rows: CompareRow[];
  recommendation: string;
  meta: {
    userId: string;
    userSkillsCount: number;
    generatedAt: string;
  };
}

// ---------- helpers ----------

const LETTERS = ['A', 'B', 'C', 'D'];

function currencySymbol(c: string): string {
  return c === 'RUB' ? '₽' : c === 'USD' ? '$' : c === 'EUR' ? '€' : c;
}

function formatSalary(min: number | null, max: number | null, cur: string): string {
  if (min == null || max == null || min <= 0 || max <= 0) return '—';
  const sym = currencySymbol(cur);
  // Если диапазон узкий — показываем одно число, иначе «350k–400k»
  const fmtK = (n: number) => (n >= 1000 ? `${Math.round(n / 1000)}k` : `${n}`);
  if (min === max) return `${fmtK(min)}${sym}`;
  return `${fmtK(min)}–${fmtK(max)}${sym}`;
}

function formatDays(d: number | null): string {
  if (d == null) return '—';
  if (d < 1) return 'менее дня';
  if (d === 1) return '1 день';
  if (d < 5) return `${d} дня`;
  return `${d} дн`;
}

// Цветовой ранг для метрик «чем больше — тем лучше» (0..100)
function scoreClass(score: number): string {
  if (score >= 70) return 'text-emerald-700 dark:text-emerald-400 font-bold';
  if (score >= 40) return 'text-amber-700 dark:text-amber-400 font-medium';
  return 'text-muted-foreground';
}

// Цветовой ранг для дней «чем меньше — тем лучше»
function daysClass(d: number | null, good: number, mid: number): string {
  if (d == null) return 'text-muted-foreground';
  if (d <= good) return 'text-emerald-700 dark:text-emerald-400 font-medium';
  if (d <= mid) return 'text-amber-700 dark:text-amber-400';
  return 'text-red-700 dark:text-red-400 font-medium';
}

// ---------- компонент ----------

interface Props {
  jobIds: string[];
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function CompareVacanciesDialog({ jobIds, open, onOpenChange }: Props) {
  const [data, setData] = React.useState<CompareResponse | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    if (!open || jobIds.length < 2) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api<CompareResponse>('/api/jobs/compare', {
        method: 'POST',
        body: JSON.stringify({ jobIds }),
      });
      setData(res);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить сравнение');
      toast({
        title: 'Не удалось сравнить вакансии',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [open, jobIds]);

  React.useEffect(() => {
    if (open) {
      load();
    } else {
      // Сброс при закрытии — чтобы при следующем открытии не мелькали старые данные
      setData(null);
      setError(null);
    }
  }, [open, load]);

  const rows = data?.rows ?? [];

  // Определим «лучшее» значение по каждой метрике — для подсветки.
  // Лучшее = max для score-метрик, min для days-метрик.
  const best = React.useMemo(() => {
    if (rows.length === 0) return null;
    const max = (sel: (r: CompareRow) => number) => Math.max(...rows.map(sel));
    const min = (sel: (r: CompareRow) => number | null) => {
      const vals = rows.map(sel).filter((v): v is number => v != null);
      return vals.length === 0 ? null : Math.min(...vals);
    };
    return {
      match: max((r) => r.match),
      hiringReality: max((r) => r.hiringReality),
      employerTrust: rows.every((r) => r.employerTrust == null)
        ? null
        : max((r) => r.employerTrust ?? -1),
      responseDays: min((r) => r.responseDays),
      closureDays: min((r) => r.closureDays),
      growth: max((r) => r.growthScore),
      // Salary: best = max верхняя граница
      salaryMax: max((r) => r.salaryMax ?? 0),
    };
  }, [rows]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl w-[95vw] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Сравнение вакансий
          </DialogTitle>
          <p className="text-xs text-muted-foreground mt-1">
            Side-by-side по 8 метрикам · {rows.length} вакансии
          </p>
        </DialogHeader>

        {loading ? (
          <div className="space-y-3 py-4">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ) : error ? (
          <div className="py-8 text-center text-sm text-muted-foreground">
            {error}
            <div className="mt-3">
              <Button variant="outline" size="sm" onClick={load}>
                Повторить
              </Button>
            </div>
          </div>
        ) : rows.length === 0 ? (
          <div className="py-8 text-center text-sm text-muted-foreground">
            Недостаточно данных для сравнения
          </div>
        ) : (
          <div className="space-y-4">
            {/* === Таблица сравнения === */}
            <div className="overflow-x-auto -mx-2 px-2">
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left text-xs text-muted-foreground font-medium uppercase tracking-wider py-2 pr-3 align-bottom">
                      Метрика
                    </th>
                    {rows.map((r, i) => (
                      <th
                        key={r.jobId}
                        className="text-left py-2 px-3 align-bottom min-w-[140px]"
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-600 text-white text-xs font-bold flex-shrink-0">
                            {LETTERS[i] ?? '?'}
                          </span>
                          <div className="min-w-0">
                            <div className="text-xs font-semibold truncate" title={r.title}>
                              {r.title}
                            </div>
                            <div className="text-xs text-muted-foreground truncate">
                              {r.company}
                            </div>
                          </div>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {/* Match */}
                  <CompareRowCells
                    label="Match"
                    icon={<TrendingUp className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className={cn('tabular-nums', scoreClass(r.match))}>
                        {r.match}%
                        {best && r.match === best.match && (
                          <span className="ml-1 text-xs text-emerald-600">★</span>
                        )}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Hiring Reality */}
                  <CompareRowCells
                    label="Hiring Reality"
                    icon={<ShieldCheck className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className={cn('tabular-nums', scoreClass(r.hiringReality))}>
                        {r.hiringReality}
                        {best && r.hiringReality === best.hiringReality && (
                          <span className="ml-1 text-xs text-emerald-600">★</span>
                        )}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Employer Trust */}
                  <CompareRowCells
                    label="Employer Trust"
                    icon={<ShieldCheck className="w-3.5 h-3.5" />}
                    render={(r) =>
                      r.employerTrust == null ? (
                        <span className="text-muted-foreground">—</span>
                      ) : (
                        <span className={cn('tabular-nums', scoreClass(r.employerTrust))}>
                          {r.employerTrust}
                          {best && r.employerTrust === best.employerTrust && (
                            <span className="ml-1 text-xs text-emerald-600">★</span>
                          )}
                        </span>
                      )
                    }
                    rows={rows}
                  />
                  {/* Ответ (дни) */}
                  <CompareRowCells
                    label="Ответ"
                    icon={<Clock className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className={cn('tabular-nums', daysClass(r.responseDays, 1, 5))}>
                        {formatDays(r.responseDays)}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Зарплата */}
                  <CompareRowCells
                    label="Зарплата"
                    icon={<Wallet className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className="tabular-nums font-medium">
                        {formatSalary(r.salaryMin, r.salaryMax, r.currency)}
                        {best && r.salaryMax === best.salaryMax && r.salaryMax != null && (
                          <span className="ml-1 text-xs text-emerald-600">★</span>
                        )}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Закрытие (дни) */}
                  <CompareRowCells
                    label="Закрытие"
                    icon={<Clock className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className={cn('tabular-nums', daysClass(r.closureDays, 30, 60))}>
                        {formatDays(r.closureDays)}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Проекты (trustChain) */}
                  <CompareRowCells
                    label="Проекты"
                    icon={<GitBranch className="w-3.5 h-3.5" />}
                    render={(r) =>
                      r.hasTrustChain ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" /> есть
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-muted-foreground">
                          <Minus className="w-3.5 h-3.5" /> —
                        </span>
                      )
                    }
                    rows={rows}
                  />
                  {/* Рост */}
                  <CompareRowCells
                    label="Рост"
                    icon={<TrendingUp className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span
                        className={cn(
                          'tabular-nums',
                          r.growthLabel === 'оч. высокий'
                            ? 'text-emerald-700 dark:text-emerald-400 font-bold'
                            : r.growthLabel === 'высокий'
                              ? 'text-emerald-600 dark:text-emerald-500 font-medium'
                              : r.growthLabel === 'средний'
                                ? 'text-amber-700 dark:text-amber-400'
                                : 'text-muted-foreground',
                        )}
                      >
                        {r.growthLabel}
                        {best && r.growthScore === best.growth && (
                          <span className="ml-1 text-xs text-emerald-600">★</span>
                        )}
                      </span>
                    )}
                    rows={rows}
                  />
                </tbody>
              </table>
            </div>

            {/* === Легенда === */}
            <p className="text-xs text-muted-foreground">
              ★ — лучшее значение по метрике. Hiring Reality: ≥70 — высокая реальность
              найма, 40–69 — средняя, &lt;40 — низкая.
            </p>

            {/* === Совпадение навыков (развернуто) === */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {rows.map((r, i) => (
                <div key={r.jobId} className="rounded-lg border p-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-600 text-white text-xs font-bold">
                      {LETTERS[i] ?? '?'}
                    </span>
                    <div className="text-xs font-semibold truncate">{r.title}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Совпало {r.matchedSkills.length} из {r.requiredSkills.length} навыков
                  </div>
                  {r.matchedSkills.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {r.matchedSkills.map((s) => (
                        <Badge
                          key={`m-${s}`}
                          variant="default"
                          className="text-xs bg-emerald-600 hover:bg-emerald-700 text-white"
                        >
                          {s}
                        </Badge>
                      ))}
                    </div>
                  )}
                  {r.missingSkills.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {r.missingSkills.map((s) => (
                        <Badge key={`x-${s}`} variant="secondary" className="text-xs">
                          {s}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* === AI рекомендация === */}
            <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3">
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 mb-1">
                    AI рекомендация
                  </div>
                  <p className="text-sm text-foreground/90 leading-relaxed">
                    {data?.recommendation ?? '—'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Закрыть
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------- подкомпонент: строка таблицы ----------

function CompareRowCells({
  label,
  icon,
  render,
  rows,
}: {
  label: string;
  icon: React.ReactNode;
  render: (r: CompareRow) => React.ReactNode;
  rows: CompareRow[];
}) {
  return (
    <tr>
      <td className="py-2 pr-3 text-xs text-muted-foreground align-middle">
        <div className="flex items-center gap-1.5">
          <span className="text-muted-foreground/70">{icon}</span>
          <span className="font-medium">{label}</span>
        </div>
      </td>
      {rows.map((r) => (
        <td key={r.jobId} className="py-2 px-3 align-middle">
          {render(r)}
        </td>
      ))}
    </tr>
  );
}

// ---------- маленький trigger-компонент для родителя ----------

export function CompareVacanciesButton({
  selectedIds,
  onClear,
  maxJobs = 4,
}: {
  selectedIds: string[];
  onClear?: () => void;
  maxJobs?: number;
}) {
  const [open, setOpen] = React.useState(false);
  const count = selectedIds.length;
  const canCompare = count >= 2 && count <= maxJobs;

  return (
    <>
      <div className="inline-flex items-center gap-2">
        <Button
          size="sm"
          onClick={() => setOpen(true)}
          disabled={!canCompare}
          className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5"
          title={
            count < 2
              ? `Выберите ещё ${2 - count} вакансию(и)`
              : count > maxJobs
                ? `Максимум ${maxJobs} вакансии для сравнения`
                : `Сравнить ${count} вакансии`
          }
        >
          <Sparkles className="w-3.5 h-3.5" />
          Сравнить ({count})
        </Button>
        {count > 0 && onClear && (
          <button
            onClick={onClear}
            className="text-xs text-muted-foreground hover:text-foreground"
            title="Очистить выбор"
          >
            сбросить
          </button>
        )}
      </div>

      <CompareVacanciesDialog
        jobIds={selectedIds}
        open={open}
        onOpenChange={setOpen}
      />
    </>
  );
}
```

</details>

### src/components/jobs/search-job-card-v2.tsx (277 строк)

**Причина:** «v2-карточка для страницы /search» никогда не подключена; реальная страница /search импортирует только ui/card и рендерит карточки сама

<details><summary>Резервная копия кода (277 строк)</summary>

```tsx
// BizON — SearchJobCardV2 (v5.1)
// Компактная v2-карточка вакансии для страницы глобального поиска /search.
// Переиспользует v2-функционал:
//   • match % (персональный, рассчитан в /api/search)
//   • VerifiedVacancyBadge (8 критериев, по клику — модалка)
//   • Hiring Manager preview (ipScore, avatar, online badge)
//   • Boosted mark (ФЗ-38 — бейдж «Реклама»)
//   • 3 пути отклика — кнопка "Откликнуться" ведёт в раздел jobs с фильтром
//   • Hot badge (если matchConfidence >= 0.5)
//   • Personal state — saved / applied индикаторы
'use client';

import * as React from 'react';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { VerifiedVacancyBadge } from '@/components/jobs/verified-vacancy-badge';
import {
  MapPin, Flame, Bookmark, CheckCircle2, Zap, Clock,
  ArrowRight, Sparkles, MessageSquare,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export interface SearchJobV2 {
  id: string;
  title: string;
  company: string;
  description: string;
  requiredSkills: string[];
  salaryFrom: number | null;
  salaryTo: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  location: string | null;
  growthScore: number;
  matchConfidence: number;
  isHot: boolean;
  hiringManager: {
    id: string;
    name: string;
    title: string | null;
    avatarUrl: string | null;
    ipScore: number;
    level: string;
  } | null;
  responseTimeHours: number | null;
  boosted: boolean;
  boostedUntil: string | null;
  verificationStatus: 'draft' | 'posted' | 'verified';
  verifiedAt: string | null;
  vacancyTrust: number;
  companyId: string | null;
  hasApplied: boolean;
  isSaved: boolean;
  createdAt: string;
}

interface SearchJobCardV2Props {
  job: SearchJobV2;
  query: string;
  onHighlight: (text: string, q: string) => React.ReactNode;
}

function formatSalary(job: SearchJobV2): string | null {
  // Приоритет — salaryMin/Max (новые v2-поля), fallback на salaryFrom/To
  const from = job.salaryMin ?? job.salaryFrom;
  const to = job.salaryMax ?? job.salaryTo;
  if (!from && !to) return null;
  const fmt = (n: number) => {
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
    if (n >= 1000) return `${(n / 1000).toFixed(0)}k`;
    return `${n}`;
  };
  const cur = job.currency === 'RUB' ? '₽' : job.currency === 'USD' ? '$' : job.currency === 'EUR' ? '€' : ` ${job.currency}`;
  if (from && to) return `${fmt(from)}–${fmt(to)}${cur}`;
  if (from) return `от ${fmt(from)}${cur}`;
  if (to) return `до ${fmt(to)}${cur}`;
  return null;
}

function matchColor(match: number): string {
  if (match >= 0.7) return 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30';
  if (match >= 0.4) return 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30';
  return 'bg-muted text-muted-foreground border-border';
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  if (days < 1) return 'сегодня';
  if (days < 7) return `${days} дн. назад`;
  if (days < 30) return `${Math.floor(days / 7)} нед. назад`;
  return `${Math.floor(days / 30)} мес. назад`;
}

export function SearchJobCardV2({ job, query, onHighlight }: SearchJobCardV2Props) {
  const salary = formatSalary(job);
  const matchPercent = Math.round(job.matchConfidence * 100);
  const isVerified = job.verificationStatus === 'verified';

  // Кликабельная ссылка в раздел /jobs с фильтром по ID вакансии
  // (на странице поиска мы НЕ открываем модалку — пользователь должен перейти в раздел,
  // где есть полный v2-функционал: 3 пути отклика, сравнение, Time Value, etc.)
  const jobsDeepLink = `/?view=jobs&jobId=${job.id}`;

  return (
    <Link href={jobsDeepLink} className="block group">
      <Card
        className={cn(
          'hover:border-primary/50 hover:shadow-md transition-all overflow-hidden',
          job.boosted && 'ring-1 ring-amber-500/30',
          isVerified && 'border-emerald-500/30',
        )}
      >
        {/* Boosted stripe (ФЗ-38 маркировка рекламы) */}
        {job.boosted && (
          <div className="h-1 bg-gradient-to-r from-amber-400 to-amber-500" />
        )}

        <CardContent className="p-4 space-y-2.5">
          {/* Row 1: Title + Match + Boosted mark */}
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-[15px] leading-snug group-hover:text-primary transition">
                {onHighlight(job.title, query)}
                {job.boosted && (
                  <Badge
                    variant="outline"
                    className="ml-2 text-xs px-1.5 py-0 h-4 bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30 align-middle"
                    title="Реклама (ФЗ-38)"
                  >
                    <Zap className="w-2.5 h-2.5 mr-0.5" />
                    Реклама
                  </Badge>
                )}
              </div>
              <div className="text-sm text-muted-foreground truncate">
                {onHighlight(job.company, query)}
                {job.location && (
                  <>
                    {' · '}
                    <MapPin className="w-3 h-3 inline-block -mt-0.5" />
                    {onHighlight(job.location, query)}
                  </>
                )}
              </div>
            </div>

            {/* Personal match score */}
            <div
              className={cn(
                'flex-shrink-0 flex flex-col items-center justify-center px-2 py-1 rounded-md border min-w-[52px]',
                matchColor(job.matchConfidence),
              )}
              title="Ваше персональное совпадение по навыкам"
            >
              <div className="text-base font-bold tabular-nums leading-none">
                {matchPercent}%
              </div>
              <div className="text-xs uppercase tracking-wide opacity-80 mt-0.5">match</div>
            </div>
          </div>

          {/* Row 2: Salary + Verified + Hot + Posted time */}
          <div className="flex items-center gap-2 flex-wrap text-xs">
            {salary && (
              <span className="font-semibold text-foreground">
                {salary}
              </span>
            )}
            <VerifiedVacancyBadge
              jobId={job.id}
              initialStatus={job.verificationStatus}
              initialScore={job.vacancyTrust}
              compact={false}
            />
            {job.isHot && (
              <Badge className="bg-rose-500/10 text-rose-700 dark:text-rose-300 border-rose-500/30 text-xs px-1.5 py-0 h-4">
                <Flame className="w-2.5 h-2.5 mr-0.5" />
                Горячая
              </Badge>
            )}
            <span className="text-muted-foreground ml-auto">
              {timeAgo(job.createdAt)}
            </span>
          </div>

          {/* Row 3: Skills (top 5) */}
          {job.requiredSkills.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {job.requiredSkills.slice(0, 5).map((s) => (
                <Badge
                  key={s}
                  variant="secondary"
                  className="text-xs px-1.5 py-0 h-4"
                >
                  {s}
                </Badge>
              ))}
              {job.requiredSkills.length > 5 && (
                <span className="text-xs text-muted-foreground self-center">
                  +{job.requiredSkills.length - 5}
                </span>
              )}
            </div>
          )}

          {/* Row 4: Hiring Manager preview (если есть) */}
          {job.hiringManager && (
            <div className="flex items-center gap-2 pt-1.5 border-t">
              <Avatar className="w-6 h-6">
                <AvatarImage src={job.hiringManager.avatarUrl ?? undefined} alt={job.hiringManager.name} />
                <AvatarFallback className="text-xs">
                  {job.hiringManager.name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0 text-xs">
                <div className="font-medium truncate flex items-center gap-1">
                  {job.hiringManager.name}
                  {isVerified && (
                    <CheckCircle2 className="w-3 h-3 text-emerald-500 flex-shrink-0" />
                  )}
                </div>
                <div className="text-muted-foreground truncate">
                  {job.hiringManager.title ?? 'Hiring Manager'}
                </div>
              </div>
              {job.responseTimeHours != null && (
                <Badge variant="outline" className="text-xs px-1.5 py-0 h-4 gap-0.5">
                  <Clock className="w-2.5 h-2.5" />
                  ~{job.responseTimeHours}ч
                </Badge>
              )}
            </div>
          )}

          {/* Row 5: Personal state CTA */}
          <div className="flex items-center gap-2 pt-1">
            {job.hasApplied ? (
              <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 text-xs">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Отклик отправлен
              </Badge>
            ) : (
              <Button
                size="sm"
                variant="default"
                className="h-7 text-xs gap-1"
                // Кнопка ведёт в раздел jobs — там доступны все 3 пути отклика
                onClick={(e) => {
                  // Link уже отработает, ничего не делаем
                }}
              >
                <MessageSquare className="w-3 h-3" />
                Открыть вакансию
                <ArrowRight className="w-3 h-3" />
              </Button>
            )}
            {job.isSaved && (
              <Badge variant="outline" className="text-xs px-1.5 py-0 h-4 gap-0.5">
                <Bookmark className="w-2.5 h-2.5 fill-current" />
                Сохранена
              </Badge>
            )}
            <div className="ml-auto text-xs text-muted-foreground flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" />
              AI-подбор
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
```

</details>

### src/hooks/use-pwa.ts (164 строк)

**Причина:** ни одного вызова usePWA / useInstallPrompt / requestPushPermission / triggerInstall во всём дереве; PWA-домен в платформе не активирован

<details><summary>Резервная копия кода (164 строк)</summary>

```ts
// BizON — PWA hook (MOB-1: PWA v1)
// Инкапсулирует:
//   • регистрацию Service Worker (production-only)
//   • запрос Notification permission при первом логине
//   • ловлю beforeinstallprompt для показа «Установить приложение»
//
// usePWA() — вызывается ОДИН раз в AppShell (регистрирует SW, спрашивает push).
// useInstallPrompt() — вызывается в любом компоненте (например, в Settings),
//   чтобы узнать доступна ли установка и вызвать triggerInstall().

'use client';

import * as React from 'react';
import { toast } from '@/hooks/use-toast';

// Module-level store для beforeinstallprompt event.
// Event можно использовать только один раз (после prompt() он становится invalid),
// поэтому храним в module scope — кнопка в Settings может его прочитать.
type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
};

let deferredPromptEvent: BeforeInstallPromptEvent | null = null;
const installListeners = new Set<(e: BeforeInstallPromptEvent | null) => void>();

function setDeferredPrompt(e: BeforeInstallPromptEvent | null) {
  deferredPromptEvent = e;
  installListeners.forEach((fn) => fn(e));
}

// Регистрация SW — только в production, один раз за сессию страницы.
function registerServiceWorker() {
  if (typeof window === 'undefined') return;
  if (!('serviceWorker' in navigator)) return;
  if (process.env.NODE_ENV !== 'production') return;
  // После onload — чтобы не блокировать first paint
  window.addEventListener(
    'load',
    () => {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        // SW не зарегистрировался — fail-open: PWA не работает, но приложение работает
        console.warn('[PWA] SW registration failed:', err);
      });
    },
    { once: true }
  );
}

// Ловим beforeinstallprompt на window — это нужно делать как можно раньше.
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    // Предотвращаем стандартный мини-инфо-бар (Chrome 67+)
    e.preventDefault();
    setDeferredPrompt(e as BeforeInstallPromptEvent);
  });
  window.addEventListener('appinstalled', () => {
    setDeferredPrompt(null);
  });
}

/**
 * Запросить Notification permission.
 * Возвращает true если granted, false иначе.
 * Показывает toast о результате.
 */
export async function requestPushPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) return false;
  try {
    const perm = await Notification.requestPermission();
    if (perm === 'granted') {
      toast({ title: 'Разрешение на уведомления получено', description: 'Push-доставка событий будет подключена позже.' });
      return true;
    } else if (perm === 'denied') {
      toast({ title: 'Push-уведомления заблокированы', description: 'Можно включить в настройках браузера', variant: 'destructive' });
    }
    return false;
  } catch (e) {
    console.warn('[PWA] Notification.requestPermission failed:', e);
    return false;
  }
}

/**
 * Trigger install prompt (если раньше был пойман beforeinstallprompt).
 * Возвращает true если пользователь согласился установить.
 */
export async function triggerInstall(): Promise<boolean> {
  if (!deferredPromptEvent) return false;
  try {
    await deferredPromptEvent.prompt();
    const choice = await deferredPromptEvent.userChoice;
    setDeferredPrompt(null);
    return choice.outcome === 'accepted';
  } catch (e) {
    console.warn('[PWA] install prompt failed:', e);
    return false;
  }
}

/**
 * usePWA — вызывается ОДИН раз (в AppShell).
 * Регистрирует SW при монтировании, запрашивает push permission
 * при появлении пользователя (первый логин).
 */
export function usePWA(userId: string | undefined | null) {
  const [pushAsked, setPushAsked] = React.useState(false);

  // Регистрация SW — один раз за сессию
  React.useEffect(() => {
    registerServiceWorker();
  }, []);

  // Запрос push-permission при первом логине.
  // Условие: пользователь залогинен, мы ещё не спрашивали,
  // браузер поддерживает Notifications, permission в состоянии 'default'.
  React.useEffect(() => {
    if (!userId) return;
    if (pushAsked) return;
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (Notification.permission !== 'default') {
      setPushAsked(true);
      return;
    }
    // Не блокируем первый рендер — спрашиваем через 2 сек после логина
    const t = setTimeout(() => {
      setPushAsked(true);
      requestPushPermission().catch(() => {});
    }, 2000);
    return () => clearTimeout(t);
  }, [userId, pushAsked]);
}

/**
 * useInstallPrompt — отслеживает состояние install prompt.
 * Можно вызывать в любом компоненте (например, в Settings)
 * — не дублирует SW/push логику.
 */
export function useInstallPrompt() {
  // Начальное состояние всегда false — чтобы SSR и первый клиентский рендер совпадали.
  // Реальное состояние обновляется в useEffect после монтирования.
  const [installAvailable, setInstallAvailable] = React.useState<boolean>(false);
  const [isStandalone, setIsStandalone] = React.useState<boolean>(false);

  React.useEffect(() => {
    // standalone = уже установлено как PWA (display-mode: standalone или iOS navigator.standalone)
    const mq = window.matchMedia('(display-mode: standalone)');
    const iosStandalone = (window.navigator as any).standalone === true;
    setIsStandalone(mq.matches || iosStandalone);
    // Если уже поймали event ранее (модуль loaded до монтирования компонента) — подхватим.
    setInstallAvailable(deferredPromptEvent !== null);

    const fn = () => setInstallAvailable(deferredPromptEvent !== null);
    installListeners.add(fn);
    const onChange = () => setIsStandalone(mq.matches || (window.navigator as any).standalone === true);
    mq.addEventListener('change', onChange);
    return () => {
      installListeners.delete(fn);
      mq.removeEventListener('change', onChange);
    };
  }, []);

  return { installAvailable, isStandalone };
}
```

</details>

### scripts/tmp-10b-service-verify.ts (135 строк)

**Причина:** разовый проверочный скрипт прерванного прогона 10-b; 0 ссылок в package.json/CI/обёртках; упоминается только в worklog как история

<details><summary>Резервная копия кода (135 строк)</summary>

```ts
// Временный сервисный скрипт верификации Task 10-b (удалить после прогона).
// Контекст: shell-песочница изолирована от :3000 (worklog 9-b/9-c) — HTTP-ветки
// build-talent/team-builder/workforce уже live-верифицированы 9-g, company/intelligence — 9-b.
// Здесь доверифицируются ДАННЫЕ-контракты, которые читают UI-панели 10-b.
import { BuildTalentService } from '../src/lib/services/build-talent-service';
import { TeamBuilderService } from '../src/lib/services/team-builder-service';
import { WorkforceService } from '../src/lib/services/workforce-service';
import { CompanyIntelligenceService } from '../src/lib/services/company-intelligence-service';
import { db } from '../src/lib/db';

const QA3_COMPANY = 'cmtoxx1yp0021l5cgviknpipu';
const BIZON = 'cmtlwo7hw00amme6uxof0jjii';

let failures = 0;
function check(label: string, ok: boolean, detail = '') {
  if (!ok) failures += 1;
  console.log(`${ok ? 'OK ' : 'FAIL'} ${label}${detail ? ' — ' + detail : ''}`);
}

async function main() {
  console.log('=== 1. BuildTalentService.buildTalentPool (UI: build-talent-panel) ===');
  const pool = await BuildTalentService.buildTalentPool({
    requiredSkills: [
      { name: 'Python', level: 6 },
      { name: 'Docker', level: null },
    ],
    companyId: QA3_COMPANY,
    limit: 10,
  });
  check('totalCandidates:number', typeof pool.totalCandidates === 'number', String(pool.totalCandidates));
  check('formulaVersion:v1', pool.formulaVersion === 'v1');
  check('privacy.note:string', typeof pool.privacy?.note === 'string', pool.privacy?.note.slice(0, 60));
  const c = pool.candidates[0];
  if (c) {
    check('candidate поля панели', (
      typeof c.score === 'number' && Array.isArray(c.matchedSkills) && Array.isArray(c.missingSkills)
      && Array.isArray(c.why) && typeof c.ipScore === 'number' && typeof c.level === 'string'
      && (c.trust === null || typeof c.trust.score === 'number')
      && (c.activity === null || typeof c.activity.status === 'string')
    ), `${c.name} score=${c.score} matched=${c.matchedSkills.length} missing=${c.missingSkills.length} why=${c.why.length}`);
    const m = c.matchedSkills[0];
    if (m) check('matchedSkill поля', ['name', 'requiredLevel', 'candidateLevel', 'ok', 'verificationLevel'].every((k) => k in m), JSON.stringify(m));
  } else {
    check('empty-pool честный note', typeof pool.note === 'string' && pool.note.length > 0, pool.note ?? 'нет note');
  }

  console.log('=== 2. TeamBuilderService.compose ×2 (UI: team-builder-panel, детерминизм) ===');
  const roles = [
    { title: 'Backend Engineer', skills: ['TypeScript:8', 'Node.js:7'] },
    { title: 'DevOps Engineer', skills: ['Docker:7', 'Kubernetes:6'] },
  ];
  const r1 = await TeamBuilderService.compose({ companyId: QA3_COMPANY, roles, maxSize: null });
  const r2 = await TeamBuilderService.compose({ companyId: QA3_COMPANY, roles, maxSize: null });
  check('детерминизм: байт-идентичный результат', JSON.stringify(r1) === JSON.stringify(r2));
  check('поля панели: team/coverage/gaps/overlaps/successProbability/rolesReport', (
    Array.isArray(r1.team) && typeof r1.coverage.percent === 'number'
    && Array.isArray(r1.gaps) && Array.isArray(r1.overlaps)
    && typeof r1.successProbability.value === 'number' && typeof r1.successProbability.explanation === 'string'
    && Array.isArray(r1.rolesReport)
  ), `team=${r1.team.length} coverage=${r1.coverage.percent}%`);
  check('persisted:false + persistNote', r1.persisted === false && typeof r1.persistNote === 'string', r1.persistNote.slice(0, 70));
  const mem = r1.team[0];
  if (mem) check('member поля панели', (
    ['userId', 'name', 'avatarUrl', 'ipScore', 'level', 'roleTitle', 'roleFit', 'coveredSkills', 'why'].every((k) => k in mem)
  ), `${mem.name} roleFit=${mem.roleFit}`);

  console.log('=== 3. WorkforceService.getOverview (UI: workforce-gates-panel) ===');
  const ov = await WorkforceService.getOverview(QA3_COMPANY);
  check('chain 5 звеньев', JSON.stringify(ov.chain) === JSON.stringify(['demand', 'gap', 'training', 'mentoring', 'pipeline']));
  check('demand {activeJobs,gapSkills,criticalGaps}', (
    typeof ov.demand.activeJobs === 'number' && typeof ov.demand.gapSkills === 'number' && typeof ov.demand.criticalGaps === 'number'
  ), JSON.stringify(ov.demand));
  check('gap severity-enum панели', ov.gap.every((g) => ['low', 'medium', 'high', 'critical'].includes(g.severity)), `${ov.gap.length} гэпов`);
  check('training-поля панели', Array.isArray(ov.training.recommendations) && Array.isArray(ov.training.employeeEnrollments) && typeof ov.training.catalogSize === 'number', `recs=${ov.training.recommendations.length} catalog=${ov.training.catalogSize}`);
  check('mentoring-поля панели', Array.isArray(ov.mentoring.activeMentorships) && Array.isArray(ov.mentoring.recommendations) && typeof ov.mentoring.note === 'string', `active=${ov.mentoring.activeMentorships.length} recs=${ov.mentoring.recommendations.length}`);
  check('pipeline-поля панели (не null при companyId; конверсии number|null)', ov.pipeline !== null && typeof ov.pipeline.stages.source === 'number' && (ov.pipeline.conversions.screenRate === null || typeof ov.pipeline.conversions.screenRate === 'number') && typeof ov.pipeline.placements.total === 'number', `source=${ov.pipeline?.stages.source} screenRate=${ov.pipeline?.conversions.screenRate} (0 откликов → конверсии null, UI показывает % только для not-null)`);
  // Содержательные данные по BizON (у QA3 пусто — честные empty states)
  const ovBizon = await WorkforceService.getOverview(BIZON);
  check('BizON: demand.gapSkills>0', ovBizon.demand.gapSkills > 0, JSON.stringify(ovBizon.demand));
  check('BizON: гэп-ноты explainable', ovBizon.gap.every((g) => g.note.length > 0), ovBizon.gap.slice(0, 2).map((g) => `${g.skill}(${g.severity})`).join(', '));
  const rec = ovBizon.mentoring.recommendations[0];
  if (rec) {
    check('mentoring-rec поля панели', (
      ['menteeId', 'menteeName', 'skillName', 'currentLevel', 'targetLevel', 'mentors'].every((k) => k in rec)
    ), `${rec.menteeName}: ${rec.skillName} ${rec.currentLevel}→${rec.targetLevel}, наставников ${rec.mentors.length}`);
  }

  console.log('=== 4. CompanyIntelligenceService.getIntelligence (UI: company-intelligence-panel) ===');
  const ci = await CompanyIntelligenceService.getIntelligence(BIZON);
  check('company не null + поля', ci !== null && ['id', 'name', 'isVerified', 'industry'].every((k) => k in (ci as { company: Record<string, unknown> }).company), ci?.company.name);
  check('dataFootprint 8 счётчиков', ci !== null && ['employeesCurrent', 'employeesFormer', 'reviews', 'culturalSignals', 'claims', 'openJobs', 'news', 'placements'].every((k) => typeof (ci as { dataFootprint: Record<string, unknown> }).dataFootprint[k] === 'number'), JSON.stringify(ci?.dataFootprint));
  const ts = ci?.trustSignals;
  check('trustSignals 4 индекса + reviews/claims/culture', ts !== undefined && (
    typeof ts.employerTrust === 'number' && typeof ts.businessTrust === 'number'
    && typeof ts.deliveryTrust === 'number' && typeof ts.transparency === 'number'
    && Array.isArray(ts.claims.items) && typeof ts.reviews.count === 'number'
    && (ts.reviews.avgRating === null || typeof ts.reviews.avgRating === 'number')
    && typeof ts.dataNote === 'string'
  ), `employer=${ts?.employerTrust} reviews=${ts?.reviews.count} dataNote="${ts?.dataNote.slice(0, 50)}"`);
  const cn = ci?.currentNeeds;
  check('currentNeeds: openJobs/topSkills/hiredRoles/dataNote', cn !== undefined && (
    Array.isArray(cn.openJobs) && Array.isArray(cn.topSkills) && Array.isArray(cn.hiredRoles) && typeof cn.dataNote === 'string'
  ), `jobs=${cn?.openJobs.length} topSkills=${JSON.stringify(cn?.topSkills.slice(0, 3))}`);
  const cm = ci?.competencyMemory;
  check('competencyMemory: now/appearing/disappearing/positions/dataNote', cm !== undefined && (
    Array.isArray(cm.skillsNow) && Array.isArray(cm.skillsAppearing) && Array.isArray(cm.skillsDisappearing) && Array.isArray(cm.employeePositions) && typeof cm.dataNote === 'string'
  ), `appearing=${JSON.stringify(cm?.skillsAppearing.slice(0, 4))}`);
  const tl = ci?.timeline;
  check('timeline: items[{kind,at,title,detail,meta}] + total + dataNote', tl !== undefined && (
    Array.isArray(tl.items) && tl.items.every((i) => typeof i.kind === 'string' && typeof i.at === 'string' && typeof i.title === 'string' && ('detail' in i) && typeof i.meta === 'object')
  ), `total=${tl?.total} kinds=${[...new Set(tl?.items.map((i) => i.kind) ?? [])].join(',')}`);
  // UI-таймлайн ключи: `${item.kind}-${item.at}-${i}` — уникальность
  const keys = new Set(tl?.items.map((i, idx) => `${i.kind}-${i.at}-${idx}`));
  check('timeline React-keys уникальны', keys.size === tl?.items.length);
  // Сортировка таймлайна по дате (свежие сверху — UI не сортирует, доверяет API)
  const dates = tl?.items.map((i) => new Date(i.at).getTime()) ?? [];
  check('timeline отсортирован по дате desc', dates.every((d, i) => i === 0 || dates[i - 1] >= d));

  console.log('=== 5. Ветки пустых состояний ===');
  const emptyPool = await BuildTalentService.buildTalentPool({
    requiredSkills: [{ name: 'КвантоваяХиромантия', level: 9 }],
    companyId: QA3_COMPANY,
    limit: 10,
  });
  check('несуществующий навык → 0 кандидатов + note', emptyPool.totalCandidates === 0 && typeof emptyPool.note === 'string' && emptyPool.note.length > 0, emptyPool.note?.slice(0, 80));

  console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECKS FAILED`);
  await db.$disconnect();
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error('SCRIPT ERROR:', e);
  process.exit(1);
});
```

</details>

### scripts/tmp-10b-verify.py (107 строк)

**Причина:** то же: разовый tmp-скрипт прогона 10-b, 0 ссылок

<details><summary>Резервная копия кода (107 строк)</summary>

```py
#!/usr/bin/env python3
# Временный скрипт верификации Task 10-b (удалить после прогона).
import json
import urllib.request

BASE = 'http://21.0.3.2:81'
DEMO = '8a4be271d397c02c84b17fe8d4edaa5a1d3fe9c60b9ad232c34459ad2900e758'  # individual (ivan)
COMPANY = 'cd85af379580f950610fcf07997c96ad63347bfeaa6d9f29'  # QA3 Company C (company)
HR = '2c2d204cc8dba8cc84676a35b3d32c78e734863b4384c369'  # IT Recruiting Pro (hr_agency)
BIZON = 'cmtlwo7hw00amme6uxof0jjii'
QA3 = 'cmtoxx1yp0021l5cgviknpipu'


def req(method, path, token=None, body=None):
    headers = {'Content-Type': 'application/json'}
    if token:
        headers['Cookie'] = f'bizon_session={token}'
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            raw = resp.read().decode()
            try:
                payload = json.loads(raw) if raw else None
            except Exception:
                payload = raw[:120]
            return resp.status, payload
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try:
            payload = json.loads(raw) if raw else None
        except Exception:
            payload = raw[:120]
        return e.code, payload


def show(label, status, payload, keys=None):
    extra = ''
    if keys and isinstance(payload, dict):
        extra = ' | ' + ', '.join(f'{k}={json.dumps(payload.get(k), ensure_ascii=False)[:110]}' for k in keys)
    print(f'{label}: {status}{extra}')


print('=== 1. GET / (страница жива) ===')
r = urllib.request.Request(BASE + '/')
with urllib.request.urlopen(r, timeout=30) as resp:
    print('GET /:', resp.status)

print('=== 2. demo-token (individual) на company-API → 403/401 ===')
s, p = req('GET', '/api/build-talent/candidates?skills=Python', DEMO)
show('build-talent individual', s, p, ['error'])
s, p = req('POST', '/api/team-builder/compose', DEMO, {'roles': [{'title': 'X', 'skills': ['Python']}]})
show('team-builder individual', s, p, ['error'])
s, p = req('GET', '/api/workforce/overview', DEMO)
show('workforce individual', s, p, ['error'])

print('=== 3. bogus token → 401 ===')
s, p = req('GET', '/api/build-talent/candidates?skills=Python', 'bogus-token-000')
show('build-talent bogus', s, p, ['error'])

print('=== 4. company-сессия QA3 Company C ===')
s, p = req('GET', '/api/build-talent/candidates?skills=Python:6,Docker&limit=10', COMPANY)
show('build-talent company GET', s, p, ['totalCandidates', 'formulaVersion', 'privacy'])
if isinstance(p, dict) and p.get('candidates'):
    top = p['candidates'][0]
    print('  top:', top['name'], 'score', top['score'], '| why[0]:', (top['why'] or ['-'])[0][:90])

roles = [
    {'title': 'Backend Engineer', 'skills': ['TypeScript:8', 'Node.js:7']},
    {'title': 'DevOps Engineer', 'skills': ['Docker:7', 'Kubernetes:6']},
]
s1, p1 = req('POST', '/api/team-builder/compose', COMPANY, {'roles': roles})
s2, p2 = req('POST', '/api/team-builder/compose', COMPANY, {'roles': roles})
show('team-builder compose #1', s1, p1, ['coverage', 'deterministic', 'persisted'])
show('team-builder compose #2', s2, p2, ['coverage', 'deterministic', 'persisted'])
t1 = json.dumps(p1.get('team') if isinstance(p1, dict) else None, sort_keys=True, ensure_ascii=False)
t2 = json.dumps(p2.get('team') if isinstance(p2, dict) else None, sort_keys=True, ensure_ascii=False)
print('  DETERMINISM team identical:', t1 == t2, '| team size:', len(p1.get('team', [])) if isinstance(p1, dict) else 'n/a')

s, p = req('GET', f'/api/workforce/overview?companyId={QA3}', COMPANY)
show('workforce company QA3', s, p, ['demand', 'companyName', 'chain'])

s, p = req('GET', f'/api/company/intelligence?companyId={BIZON}', COMPANY)
show('company-intelligence BizON', s, p, ['generatedAt'])
if isinstance(p, dict):
    print('  footprint:', p.get('dataFootprint'))
    print('  timeline items:', len(p.get('timeline', {}).get('items', [])), '| topSkills:', p.get('currentNeeds', {}).get('topSkills'))

print('=== 5. hr_agency-сессия IT Recruiting Pro ===')
s, p = req('GET', '/api/build-talent/candidates?skills=Docker,Python', HR)
show('build-talent hr GET', s, p, ['totalCandidates', 'note'])
s, p = req('GET', f'/api/workforce/overview?companyId={BIZON}', HR)
show('workforce hr BizON', s, p, ['demand', 'companyName', 'hrAgencyOutreach'])
s, p = req('POST', '/api/team-builder/compose', HR, {'roles': [{'title': 'Data Engineer', 'skills': ['Python:8', 'PostgreSQL:6']}]})
show('team-builder hr POST', s, p, ['coverage', 'successProbability'])

print('=== 6. company-intelligence доступен individual-сессии (публичная аналитика) ===')
s, p = req('GET', f'/api/company/intelligence?companyId={BIZON}', DEMO)
show('company-intelligence demo(individual)', s, p, ['generatedAt'])

print('=== 7. Ошибочные ветки ===')
s, p = req('GET', '/api/company/intelligence', COMPANY)
show('company-intelligence без companyId', s, p, ['error'])
s, p = req('GET', '/api/company/intelligence?companyId=nonexistent-id-xyz', COMPANY)
show('company-intelligence 404', s, p, ['error'])
s, p = req('GET', '/api/build-talent/candidates', COMPANY)
show('build-talent без skills', s, p, ['error'])
```

</details>

### scripts/tmp-9b-dbcount.ts (17 строк)

**Причина:** разовый tmp-скрипт прогона 9-b (подсчёт записей БД), 0 ссылок; соседние tmp-9b-* уже удалены ранее

<details><summary>Резервная копия кода (17 строк)</summary>

```ts
import { db } from '../src/lib/db';
async function main() {
  const [companies, users, jobs, newsCards, culturalSignals, companyClaims, companyReviews, employees, placements, careerEntries, projects, skillConfirmations, reputationSnapshots, actionEvents, evidence, applications, userSkills, skills] = await Promise.all([
    db.company.count(), db.user.count(), db.job.count(), db.newsCard.count(),
    db.culturalSignal.count(), db.companyClaim.count(), db.companyReview.count(), db.employee.count(),
    db.placement.count(), db.careerEntry.count(), db.project.count(), db.skillConfirmation.count(),
    db.reputationSnapshot.count(), db.actionEvent.count(), db.professionalEvidence.count(),
    db.jobApplication.count(), db.userSkill.count(), db.skill.count(),
  ]);
  console.log(JSON.stringify({ companies, users, jobs, newsCards, culturalSignals, companyClaims, companyReviews, employees, placements, careerEntries, projects, skillConfirmations, reputationSnapshots, actionEvents, evidence, applications, userSkills, skills }, null, 1));
  const comp = await db.company.findMany({ select: { id: true, name: true, industry: true, isVerified: true }, take: 5 });
  const us = await db.user.findMany({ select: { id: true, name: true, accountType: true, companyId: true }, take: 8 });
  console.log('companies:', JSON.stringify(comp));
  console.log('users:', JSON.stringify(us));
  await db.$disconnect();
}
main().catch(e => { console.error(e); process.exit(1); });
```

</details>

### scripts/tmp-9g-inspect.cjs (22 строк)

**Причина:** разовый tmp-скрипт прерванного прогона 9-g, 0 ссылок в коде/CI

<details><summary>Резервная копия кода (22 строк)</summary>

```js
const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();
(async () => {
  const users = await db.user.findMany({ select: { id: true, name: true, accountType: true, companyId: true, ipScore: true, subscriptionTier: true }, take: 30 });
  console.log('USERS:', JSON.stringify(users, null, 1));
  const companies = await db.company.findMany({ select: { id: true, name: true, industry: true }, take: 10 });
  console.log('COMPANIES:', JSON.stringify(companies));
  const jobs = await db.job.findMany({ select: { id: true, title: true, companyId: true, requiredSkills: true, active: true }, take: 15 });
  console.log('JOBS:', JSON.stringify(jobs, null, 1));
  const skills = await db.skill.count();
  const userSkills = await db.userSkill.count();
  console.log('SKILLS count:', skills, 'USERSKILLS:', userSkills);
  const courses = await db.course.findMany({ take: 10 });
  console.log('COURSES:', JSON.stringify(courses.map(c => ({id: c.id, title: c.title, category: c.category}))));
  const userCourses = await db.userCourse.count();
  const mentorships = await db.mentorship.count();
  const placements = await db.placement.count();
  const subs = await db.subscription.count();
  const jobApps = await db.jobApplication.count();
  console.log('USERCOURSES:', userCourses, 'MENTORSHIPS:', mentorships, 'PLACEMENTS:', placements, 'SUBSCRIPTIONS:', subs, 'JOBAPPS:', jobApps);
  await db.$disconnect();
})().catch(e => { console.error(e); process.exit(1); });
```

</details>

### scripts/tmp-9g-inspect2.cjs (10 строк)

**Причина:** то же: разовый tmp-скрипт прогона 9-g

<details><summary>Резервная копия кода (10 строк)</summary>

```js
const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();
(async () => {
  const s = await db.session.findMany({ where: { token: { in: ['demo-token', '8a4be271d397c02c84b17fe8d4edaa5a1d3fe9c60b9ad232c34459ad2900e758'] } }, include: { user: { select: { id: true, name: true, accountType: true, companyId: true } } } });
  console.log('SESSIONS:', JSON.stringify(s, null, 1));
  // userSkills for candidate pool
  const us = await db.userSkill.findMany({ select: { userId: true, skill: { select: { name: true } }, level: true, currentLevel: true, peakLevel: true, verificationLevel: true, confidence: true }, take: 100 });
  console.log('USERSKILLS:', JSON.stringify(us, null, 0));
  await db.$disconnect();
})().catch(e => { console.error(e); process.exit(1); });
```

</details>

---

## Журнал восстановлений

| Дата | Файл | Кто/зачем | Гейты после восстановления |
|---|---|---|---|
| — | — | — | — |

## Запись №003 — повторное удаление HR-review-роутов (откат песочницы вернул мёртвые файлы)

- **Дата:** 2026-09-19 13:53 UTC
- **Коммит:** `d8a0057` (удаление из рабочего дерева)
- **Релиз системы:** 1.1.1-pilot-ready (VERSION на момент удаления)
- **Задача:** OWNER-UX-PLAN W0-1 (worklog; план docs/plans/OWNER-UX-PLAN-2026-09-19.md, Волна 0)
- **Что:** удалены 2 роута HR-review-контура, которые откат песочницы 18.09 вернул в дерево (они уже удалялись в Записи №001):
  - `src/app/api/hr/[id]/reviews/route.ts` (85 строк) — читал `db.hrReview.findMany/aggregate`;
  - `src/app/api/placements/[id]/review/route.ts` (113 строк) — читал/писал `db.hrReview`.
- **Причина (с доказательством):** модели `HrReview` НЕТ в `prisma/schema.prisma` (проверено grep по схеме: 0 вхождений) → оба роута гарантированно падали 500 на любом запросе. HR-review-контур («HR Trust MVP», Wave B) был вырезан осознанно вместе с модулем трудоустройства (см. Запись №001).
- **Доказательство мёртвости:** живых импортов роутов нет (роуты Next.js вызываются только по URL); во фронтенде URL `POST /api/placements/[id]/review` упоминает только некий смонтированный нигде компонент `src/components/hr/my-placements-card.tsx:207` (0 импортов MyPlacementsCard по всему дереву — проверено rg), т.е. живого вызова нет.
- **Резервные копии:** ПОЛНОСТЬЮ присутствуют в Записи №001 этого же файла (те же два пути). Перед повторным удалением текущие файлы сверены с копиями №001 утилитой diff — **байт-в-байт идентичны** (проверено 2026-09-19, задача W0-1), повторная копия кода не дублируется во избежание расхождения двух версий.
- **План возврата:** вернуть оба роута (из копии №001 + Prisma-модель `HrReview` в схему) ТОЛЬКО при возрождении модуля трудоустройства/HR-агентств (Placement-контур жив: `src/app/api/placements/route.ts`, `placements/[id]/confirm`); вместе с ними вернуть и смонтировать `my-placements-card.tsx`.
- **Гейты после удаления:** tsc — в файлах зоны W0-1 ошибок 0; bun test tests/owner-w0-1.test.ts — зелёный; lint — 0 новых ошибок.

## Запись №004 — повторное удаление мёртвого контейнера PublicPersona (откат песочницы вернул файл, доросший до 1358 строк)

- **Дата:** 2026-09-19 15:12 UTC
- **Коммит:** `d8a0057` (удаление из рабочего дерева)
- **Релиз системы:** 1.1.1-pilot-ready (VERSION на момент удаления)
- **Задача:** OWNER-UX-PLAN W0-2 «Ревизия мёртвого PublicPersona: оживить нужное, удалить остальное» (worklog; план docs/plans/OWNER-UX-PLAN-2026-09-19.md, Волна 0, шаг 9 из 24)
- **Что:** удалён `src/components/profile/public-persona.tsx` (1358 строк) — контейнер «публичной персоны» (Этап 3.2 Блок R + наросшие KV2-блоки). Повторное удаление: файл уже удалялся в Записи №002 (тогда 1210 строк, 0 импортов), откат песочницы вернул его в дерево, после чего KV2 D-01 (TrustChainBlock/IntroRequestButton) и «Правки 3» (CommonContactsBlock/MessageComposeDialog) доросли его до 1358 строк.
- **Причина (с доказательством):** мёртвый контейнер — 0 живых импортов `PublicPersona` во всём дереве src (проверено rg перед удалением, задача W0-2; совпадения по дереву — только комментарии в новых файлах переноса). Единственный живой импорт из файла (`TrustChainBlock` в `profile-view.tsx:20`) в рамках той же задачи обновлён на новый путь `@/components/profile/trust-chain-block`.
- **Живые части перенесены (задача W0-2, логика сохранена):**
  - `TrustChainBlock` + `IntroRequestButton` + `PathNode` + `Arrow` (+ типы Matchmaker*, `INTRO_PURPOSES`, `shortFirstName`, локальный `SectionTitle`) → `src/components/profile/trust-chain-block.tsx`;
  - `MessageComposeDialog` → `src/components/messages/message-compose-dialog.tsx` (адаптирован под универсальный контракт: props `{userId, userName, open, onOpenChange, onSent?}`, POST `/api/messages {toUserId, content}`, текст ошибки сервера — в тосте);
  - `CommonContactsBlock` (+ `pluralCommon`, локальный `SectionTitle`) → `src/components/profile/common-contacts-block.tsx` (при загрузке скрыт, при 0 — тихая строка; данные GET `/api/users/[id]/common-contacts`).
- **Удалено без переноса (мёртвое):** сам `PublicPersona` (0 импортов), `HrTransferableBlock` + `InvitationDialog` + `TransferableResponse` (использовались только внутри контейнера; HR-view нигде не смонтирован), хелперы нарратива `statusLabel`/`roleLabel`/`pluralColl`/`pluralProj`/`formatConfirmers`/`shortName`/`declineLastNameTvr`/локальный `SectionTitle` (живые копии хелперов — в файлах переноса).
- **`ProfessionalStatusBadge` (экспорт :534):** живых потребителей нет (использовался только внутри `PublicPersona` :195; проверено rg по дереву) → перенесён НЕ был. При появлении потребителя восстановить из копии ниже (функция + `PROFESSIONAL_STATUS_META`, ~50 строк).
- **Сопутствующие осиротевшие импорты (не удалялись, вне зоны W0-2, задокументировано):** `HrContactButton` (`src/components/hr/hr-contact-button.tsx`) и `ResumeGeneratorDialog` (`src/components/cv/resume-generator-dialog.tsx`) импортировались только отсюда; оба файла остались в дереве. `ResumeGeneratorDialog` — зона W4 «Резюме» (смонтирует его в новом UI); `HrContactButton` — кандидат на чистку/монтаж вместе с HR-модулем. `EvidenceGraph` жив (используется `me-view.tsx`).
- **API `/api/users/[id]/persona`:** остаётся живым (реальные модели: UserSkill/ProjectMember/NFTSkill/SkillConfirmation/CareerEntry) и получил нового потребителя — выбор коллеги «Спроси у коллег» в `profile-view.tsx`.
- **План возврата:** сам файл возвращать НЕ нужно (живые части уже в файлах переноса). Полный контейнер при необходимости — из копии ниже. HR-блоки (`HrTransferableBlock`/`InvitationDialog`) возвращать только вместе с монтированием HR-view; нарративный контейнер целиком — только отдельным решением владельца (кейс перекрывается планом W5 «Визитка»).
- **Гейты после удаления:** bun test tests/owner-w0-2.test.ts — зелёный; tsc по скоупу зоны W0-2 — 0 ошибок; bun run lint — 0 новых ошибок; dev.log без новых 500.

<details><summary>Резервная копия кода (1358 строк)</summary>

```tsx
// BizON — Public Persona (Этап 3.2 — Блок R)
// Нарративный формат публичного профиля:
//   «Делает X / Делал вместе с N,M,K / Проекты / NFT-навыки / [Спроси у коллег]»
// БЕЗ чисел (IP-score, confirmationsCount, level) — только факты и имена.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Sparkles, Users, FolderKanban, Award, MessageCircleHeart,
  ArrowRight, Calendar, MessageSquareMore, Compass, Send,
  Handshake, Link2, ChevronRight, Mail, Loader2, Check,
} from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { ColleagueInquiryDialog } from '@/components/colleague-inquiries/colleague-inquiry-dialog';
// Этап 4.2 — HR Persona: кнопка «Связаться» для HR-агентств
import { HrContactButton } from '@/components/hr/hr-contact-button';
// Этап 5.3 — CV блок: AI-резюме (для HR view) + Transferable skills блок
import { ResumeGeneratorDialog } from '@/components/cv/resume-generator-dialog';
// P0-3 — Evidence Graph: компактная версия для публичного профиля
import { EvidenceGraph } from '@/components/truth/evidence-graph';

interface PersonaCollaborator {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  projects: Array<{ title: string; yearRange: string }>;
  projectsCount: number;
}

interface PersonaProject {
  id: string;
  title: string;
  teamSize: number;
  yearRange: string;
  status: string;
  role: string;
}

interface PersonaNftSkill {
  skillName: string;
  level: number;
  confirmedBy: string[];
}

interface PersonaData {
  user: {
    id: string;
    name: string;
    title: string | null;
    bio: string | null;
    avatarUrl: string | null;
    roles: string[];
    accountType?: string;
    hrInvisible?: boolean;
    createdAt: string;
    professionalStatus?: string | null;
  };
  professionalSince: number;
  does: string[];
  collaborators: PersonaCollaborator[];
  collaboratorsTotal: number;
  projects: PersonaProject[];
  nftSkills: PersonaNftSkill[];
}

interface PublicPersonaProps {
  userId: string;
  /**
   * Если true — владелец смотрит «Как видят меня».
   * Скрывает кнопку «Добавить в контакты» / «Спроси у коллег» (последняя всё равно доступна как заглушка,
   * но кнопка «Добавить в контакты» скрывается).
   */
  previewMode?: boolean;
  /** Колбэк для добавления в контакты (внешняя логика). */
  onAddConnection?: () => void;
}

export function PublicPersona({ userId, previewMode = false, onAddConnection }: PublicPersonaProps) {
  const { setProfileUserId, user: currentUser } = useAppStore();
  const [data, setData] = React.useState<PersonaData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [collabLimit, setCollabLimit] = React.useState(5);
  // R9: выбранный коллега для диалога «Спроси у коллег»
  const [inquiryColleague, setInquiryColleague] = React.useState<PersonaCollaborator | null>(null);
  // Правка 3: диалог «Написать сообщение» (через /api/messages)
  const [messageOpen, setMessageOpen] = React.useState(false);

  // Этап 5.3 — HR view transferable skills
  const isHrViewer =
    !previewMode &&
    !!currentUser &&
    currentUser.id !== userId &&
    currentUser.accountType === 'hr_agency';

  const load = React.useCallback(async (limit: number) => {
    setLoading(true);
    try {
      const res = await api<PersonaData>(`/api/users/${userId}/persona?limit=${limit}`);
      setData(res);
    } catch (e: any) {
      toast({ title: 'Не удалось загрузить профиль', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load(collabLimit);
  }, [load, collabLimit]);

  // R9: можно спросить у коллег ТОЛЬКО если:
  //   • не preview mode
  //   • пользователь авторизован
  //   • это не свой собственный профиль
  //   • мы спрашиваем про aboutUser (владельца страницы)
  //   • D-10 (KV2): relationship подтверждён СЕРВЕРОМ (/api/me/relationship) —
  //     спрашивать коллег может только contact (серверная правда, не клиентская)
  const [relationship, setRelationship] = React.useState<{ mode: string; kind: string | null } | null>(null);
  React.useEffect(() => {
    if (previewMode || !currentUser || currentUser.id === userId) {
      setRelationship(null);
      return;
    }
    let cancelled = false;
    api<{ mode: string; kind: string | null }>(`/api/me/relationship/${userId}`)
      .then((r) => { if (!cancelled) setRelationship(r); })
      .catch(() => { if (!cancelled) setRelationship(null); });
    return () => { cancelled = true; };
  }, [previewMode, currentUser, userId]);
  const isContact = relationship?.mode === 'contact';

  const canAskColleagues =
    !previewMode && !!currentUser && currentUser.id !== userId && isContact;

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
      </div>
    );
  }

  const u = data.user;
  const hasMoreCollaborators = data.collaboratorsTotal > data.collaborators.length;

  return (
    <div className="space-y-4">
      {/* Header card — Имя + специальность + «с YYYY в профессии» */}
      <Card className="overflow-hidden">
        <div className="h-20 bg-gradient-to-r from-primary/15 via-accent/40 to-primary/10" />
        <CardContent className="pt-0">
          <div className="flex items-start gap-4 -mt-10">
            <div className="rounded-full ring-4 ring-card bg-card">
              <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="xl" />
            </div>
            <div className="flex-1 pt-10 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl font-bold truncate">{u.name}</h1>
                {/* D-10 (KV2): режим профиля по серверной /api/me/relationship */}
                {isContact && (
                  <Badge variant="secondary" className="text-xs gap-1">
                    <Handshake className="w-3 h-3" /> В ваших контактах{relationship?.kind ? ` · ${relationship.kind}` : ''}
                  </Badge>
                )}
              </div>
              <div className="text-sm text-muted-foreground mt-1 flex items-center gap-2 flex-wrap">
                {u.title && <span className="font-medium text-foreground/80">{u.title}</span>}
                <span className="text-muted-foreground/70">·</span>
                <span>с {data.professionalSince} в профессии</span>
              </div>
              {u.roles && u.roles.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {u.roles.map((r) => (
                    <Badge key={r} variant="secondary" className="text-xs">{r}</Badge>
                  ))}
                </div>
              )}
              {/* Phase 3: Professional Status — бейдж (если установлен) */}
              {u.professionalStatus && (
                <div className="mt-2">
                  <ProfessionalStatusBadge status={u.professionalStatus} />
                </div>
              )}
            </div>
            {!previewMode && onAddConnection && (
              <div className="pt-10 flex gap-2 flex-wrap justify-end">
                <Button size="sm" variant="outline" onClick={onAddConnection}>
                  <Users className="w-4 h-4 mr-1" /> В контакты
                </Button>
                {/* Правка 3 — Кнопка «Написать сообщение» через /api/messages */}
                {canAskColleagues && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setMessageOpen(true)}
                  >
                    <Mail className="w-4 h-4 mr-1" /> Написать
                  </Button>
                )}
                {/* Этап 4.2 — HR Persona: кнопка «Связаться» для HR-агентств */}
                {currentUser?.accountType === 'hr_agency' &&
                  u.accountType === 'individual' && (
                    <HrContactButton
                      candidateId={u.id}
                      candidateName={u.name}
                      candidateHrInvisible={u.hrInvisible}
                    />
                  )}
              </div>
            )}
          </div>
          {u.bio && <p className="mt-4 text-sm text-foreground/80 leading-relaxed">{u.bio}</p>}

          {/* Этап 5.3 — CV блок: кнопка «Сформировать резюме» для HR viewing individual */}
          {isHrViewer && u.accountType === 'individual' && !u.hrInvisible && (
            <div className="mt-4 pt-4 border-t flex items-center justify-between gap-2 flex-wrap">
              <div className="text-xs text-muted-foreground">
                Сформируйте персонализированное резюме кандидата на основе подтверждённых навыков и проектов.
              </div>
              <ResumeGeneratorDialog
                targetUserId={u.id}
                triggerLabel="Сформировать резюме"
                triggerVariant="outline"
                triggerSize="sm"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Правка 3 — Общие контакты + Цепочка доверия (только для зарегистрированных, не preview) */}
      {canAskColleagues && (
        <>
          <CommonContactsBlock userId={u.id} userName={u.name} />
          <TrustChainBlock userId={u.id} userName={u.name} />
        </>
      )}

      {/* ДЕЛАЕТ */}
      {data.does.length > 0 && (
        <Card>
          <CardContent className="p-4 sm:p-6">
            <SectionTitle icon={<Sparkles className="w-4 h-4" />} label="ДЕЛАЕТ" />
            <div className="flex flex-wrap gap-2 mt-3">
              {data.does.map((s) => (
                <Badge key={s} variant="outline" className="px-3 py-1 text-sm font-medium">
                  {s}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ДЕЛАЛ ВМЕСТЕ С */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <SectionTitle
            icon={<Users className="w-4 h-4" />}
            label="ДЕЛАЛ ВМЕСТЕ С"
            right={
              data.collaboratorsTotal > 0 && (
                <span className="text-xs text-muted-foreground">
                  {data.collaboratorsTotal} {pluralColl(data.collaboratorsTotal)}
                </span>
              )
            }
          />
          {data.collaborators.length === 0 ? (
            <p className="text-sm text-muted-foreground mt-3">
              Публичных совместных проектов пока нет.
            </p>
          ) : (
            <ul className="mt-3 space-y-3">
              {data.collaborators.map((c) => (
                <li key={c.id} className="flex items-start gap-2">
                  <button
                    type="button"
                    onClick={() => !previewMode && setProfileUserId(c.id)}
                    className={cn(
                      'flex-1 text-left flex items-start gap-3 p-2 rounded-lg transition',
                      !previewMode && 'hover:bg-accent/40'
                    )}
                    disabled={previewMode}
                  >
                    <UserAvatar name={c.name} avatarUrl={c.avatarUrl} size="sm" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{c.name}</div>
                      {c.title && (
                        <div className="text-xs text-muted-foreground truncate">{c.title}</div>
                      )}
                      <div className="mt-1 space-y-0.5">
                        {c.projects.map((p, i) => (
                          <div key={i} className="text-xs text-foreground/70 flex items-start gap-1.5">
                            <span className="text-muted-foreground/60 mt-0.5">—</span>
                            <span>
                              <span className="font-medium">{p.title}</span>
                              <span className="text-muted-foreground"> · {p.yearRange}</span>
                            </span>
                          </div>
                        ))}
                        {c.projectsCount > c.projects.length && (
                          <div className="text-xs text-muted-foreground/70 pl-3">
                            ещё {c.projectsCount - c.projects.length} проектов вместе
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                  {/* R9: кнопка «Спросить» рядом с коллаборатором */}
                  {canAskColleagues && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setInquiryColleague(c);
                      }}
                      title={`Спросить у ${c.name.split(' ')[0]} про ${u.name.split(' ')[0]}`}
                      className="shrink-0 mt-1 inline-flex items-center gap-1 text-xs px-2 py-1 rounded-md border border-lighthouse/30 text-lighthouse hover:bg-lighthouse/10 transition"
                    >
                      <MessageSquareMore className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Спросить</span>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
          {hasMoreCollaborators && (
            <button
              type="button"
              onClick={() => setCollabLimit((l) => l + 10)}
              className="mt-3 inline-flex items-center gap-1 text-sm text-primary hover:underline"
            >
              Показать ещё <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </CardContent>
      </Card>

      {/* ПРОЕКТЫ */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <SectionTitle
            icon={<FolderKanban className="w-4 h-4" />}
            label="ПРОЕКТЫ"
            right={
              data.projects.length > 0 && (
                <span className="text-xs text-muted-foreground">
                  {data.projects.length} {pluralProj(data.projects.length)}
                </span>
              )
            }
          />
          {data.projects.length === 0 ? (
            <p className="text-sm text-muted-foreground mt-3">Проектов пока нет.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {data.projects.map((p) => (
                <li
                  key={p.id}
                  className="flex items-start gap-2 p-2 rounded-lg bg-muted/30"
                >
                  <span className="text-muted-foreground/60 mt-0.5">—</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">
                      {p.title}
                      <span className="text-muted-foreground font-normal">
                        {'  '}· команда {p.teamSize}, {p.yearRange}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1.5">
                      <Badge variant="outline" className="text-xs px-1.5 py-0">
                        {statusLabel(p.status)}
                      </Badge>
                      <span>· роль: {roleLabel(p.role)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* NFT-НАВЫКИ (факты) */}
      {data.nftSkills.length > 0 && (
        <Card>
          <CardContent className="p-4 sm:p-6">
            <SectionTitle icon={<Award className="w-4 h-4" />} label="NFT-НАВЫКИ" />
            <p className="text-xs text-muted-foreground mt-1 mb-3">
              Факты, подтверждённые коллегами через совместные проекты.
            </p>
            <ul className="space-y-2">
              {data.nftSkills.map((nft, i) => (
                <li key={`${nft.skillName}-${i}`} className="flex items-start gap-2">
                  <span className="text-muted-foreground/60 mt-0.5">—</span>
                  <div className="text-sm">
                    <span className="font-medium">{nft.skillName}</span>
                    {nft.confirmedBy.length > 0 ? (
                      <span className="text-muted-foreground">
                        {' '}— подтверждён {formatConfirmers(nft.confirmedBy)}
                      </span>
                    ) : (
                      <span className="text-muted-foreground"> — NFT выпущен</span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* P0-3 — Evidence Graph (компактная версия для публичного профиля) */}
      <EvidenceGraph userId={u.id} compact />

      {/* Этап 5.3 — HR view Transferable skills (только для HR-агентств) */}
      {isHrViewer && u.accountType === 'individual' && !u.hrInvisible && (
        <HrTransferableBlock userId={u.id} userName={u.name} />
      )}

      {/* Спроси у коллег — информационная плашка (само действие — через кнопки у каждого коллаборатора) */}
      <Card className="bg-lighthouse-gradient-soft border-lighthouse/30">
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-start gap-3">
            <div className="rounded-full bg-background/60 p-2 shrink-0">
              <MessageCircleHeart className="w-5 h-5 text-lighthouse" />
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold">
                Хотите узнать, как с {u.name.split(' ')[0]} работается?
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {canAskColleagues ? (
                  data.collaborators.length > 0
                    ? `Нажмите «Спросить» рядом с любым коллегой выше — отправим личный запрос. Никаких оценок и звёзд, только живые истории.`
                    : `У этого пользователя пока нет публичных совместных проектов. Как только они появятся — вы сможете спросить у коллег.`
                ) : (
                  `Попросите коллег поделиться опытом — без оценок и звёзд, только живые истории.`
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Footer-метка для preview-режима */}
      {previewMode && (
        <div className="text-center text-xs text-muted-foreground">
          <Calendar className="w-3 h-3 inline mr-1" />
          Это публичный вид вашего профиля — так его видят другие.
        </div>
      )}

      {/* R9: Диалог «Спроси у коллег» */}
      {inquiryColleague && (
        <ColleagueInquiryDialog
          open={!!inquiryColleague}
          onOpenChange={(o) => !o && setInquiryColleague(null)}
          colleague={inquiryColleague}
          aboutUser={{
            id: u.id,
            name: u.name,
            avatarUrl: u.avatarUrl,
          }}
        />
      )}

      {/* Правка 3 — Диалог «Написать сообщение» (POST /api/messages) */}
      {messageOpen && (
        <MessageComposeDialog
          open={messageOpen}
          onOpenChange={setMessageOpen}
          toUserId={u.id}
          toUserName={u.name}
        />
      )}
    </div>
  );
}

// ============================================================================
// Phase 3: ProfessionalStatusBadge — бейдж профессионального статуса.
// Используется в публичном профиле рядом с именем/ролью.
// Цветовая схема совпадает с настройками (settings-view.tsx).
// ============================================================================
const PROFESSIONAL_STATUS_META: Record<string, {
  label: string;
  dotClass: string;
  badgeClass: string;
}> = {
  active_searching: {
    label: 'Активно ищу работу',
    dotClass: 'bg-emerald-500',
    badgeClass: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30',
  },
  open_to_offers: {
    label: 'Открыт предложениям',
    dotClass: 'bg-blue-500',
    badgeClass: 'bg-blue-500/10 text-blue-700 dark:text-blue-300 border-blue-500/30',
  },
  open_to_projects: {
    label: 'Ищу проект',
    dotClass: 'bg-amber-500',
    badgeClass: 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30',
  },
  open_to_consulting: {
    label: 'Готов к консультациям',
    dotClass: 'bg-purple-500',
    badgeClass: 'bg-purple-500/10 text-purple-700 dark:text-purple-300 border-purple-500/30',
  },
  not_searching: {
    label: 'Не ищу',
    dotClass: 'bg-muted-foreground',
    badgeClass: 'bg-muted/40 text-muted-foreground border-border',
  },
};

export function ProfessionalStatusBadge({ status }: { status: string | null }) {
  if (!status) return null;
  const meta = PROFESSIONAL_STATUS_META[status];
  if (!meta) return null;
  return (
    <Badge
      variant="outline"
      className={`text-xs gap-1.5 ${meta.badgeClass}`}
      title={meta.label}
    >
      <span
        className={`w-2 h-2 rounded-full inline-block ${meta.dotClass}`}
        aria-hidden
      />
      {meta.label}
    </Badge>
  );
}

function SectionTitle({
  icon,
  label,
  right,
}: {
  icon: React.ReactNode;
  label: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <span className="text-muted-foreground">{icon}</span>
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
      </div>
      {right}
    </div>
  );
}

function statusLabel(s: string) {
  return (
    { recruiting: 'Набор', active: 'Активен', completed: 'Завершён', cancelled: 'Отменён' } as Record<string, string>
  )[s] ?? s;
}

function roleLabel(r: string) {
  return ({ owner: 'владелец', lead: 'лид', member: 'участник' } as Record<string, string>)[r] ?? r;
}

function pluralColl(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'коллега';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'коллеги';
  return 'коллег';
}

function pluralProj(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'проект';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'проекта';
  return 'проектов';
}

function formatConfirmers(names: string[]): string {
  if (names.length === 0) return '';
  if (names.length === 1) return `${shortName(names[0])}`;
  if (names.length === 2) return `${shortName(names[0])} и ${shortName(names[1])}`;
  return `${shortName(names[0])}, ${shortName(names[1])} и другими`;
}

function shortName(fullName: string): string {
  // «Мария Иванова» → «М. Ивановой» (для нарратива)
  const parts = fullName.trim().split(/\s+/);
  if (parts.length < 2) return fullName;
  const first = parts[0];
  const last = parts[parts.length - 1];
  const initial = first[0]?.toUpperCase() ?? '';
  // Склонение фамилии в творительный падеж — упрощённо: «Иванова» → «Ивановой»
  const lastNameTvr = declineLastNameTvr(last);
  return `${initial}. ${lastNameTvr}`;
}

// Очень упрощённое склонение русских фамилий в творительный падеж для нарратива
function declineLastNameTvr(last: string): string {
  if (!last) return last;
  // Женские на -ова/-ева/-ёва/-на
  if (/ова$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/ева$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/ёва$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/на$/i.test(last)) return last.slice(0, -1) + 'ой';
  if (/ская$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/цкая$/i.test(last)) return last.slice(0, -2) + 'ой';
  // Мужские на -ов/-ев/-ёв/-ин/-ын/-ский/-цкий
  if (/ов$/i.test(last)) return last + 'ым';
  if (/ев$/i.test(last)) return last + 'ым';
  if (/ёв$/i.test(last)) return last + 'ым';
  if (/ин$/i.test(last)) return last + 'ым';
  if (/ын$/i.test(last)) return last + 'ым';
  if (/ский$/i.test(last)) return last.slice(0, -2) + 'им';
  if (/цкий$/i.test(last)) return last.slice(0, -2) + 'им';
  // fallback
  return last;
}

// ============================================================================
// Этап 5.3 — HR Transferable skills блок
// Показывается только HR-агентствам (currentUser.accountType='hr_agency') при просмотре
// профиля кандидата (individual). Загружает /api/users/[id]/transferable.
// Хобби показываются только если кандидат дал opt-in (showHobbiesToHr=true).
// ============================================================================
interface TransferableResponse {
  user: {
    id: string;
    name: string;
    title: string | null;
    bio: string | null;
    ipScore: number;
    level: string;
    avatarUrl: string | null;
  };
  confirmedSkills: Array<{
    id: string;
    name: string;
    level: number;
    verificationLevel: string;
    confirmationsCount: number;
  }>;
  hobbies: string[]; // полный список — только если showHobbiesToHr=true
  hobbiesCount: number; // счётчик всегда показывается
  hobbiesVisible: boolean;
  annotation: string;
  engine: 'llm' | 'fallback';
}

function HrTransferableBlock({ userId, userName }: { userId: string; userName: string }) {
  const [data, setData] = React.useState<TransferableResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [invitationOpen, setInvitationOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<TransferableResponse>(`/api/users/${userId}/transferable`);
      setData(res);
    } catch (e: any) {
      // 403 = Privacy Shield / не HR
      setError(e?.message ?? 'Не удалось загрузить transferable skills');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <Card className="border-lighthouse/30">
        <CardContent className="p-4 sm:p-6 space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (error || !data) {
    // Тихая ошибка — не показываем HR'у детали, просто не рендерим блок
    // (Privacy Shield — кандидат сам решил не быть видимым)
    return null;
  }

  return (
    <Card className="border-lighthouse/30 bg-lighthouse-gradient-soft">
      <CardContent className="p-4 sm:p-6 space-y-3">
        <SectionTitle
          icon={<Compass className="w-4 h-4 text-lighthouse" />}
          label="TRANSFERABLE SKILLS"
          right={
            <Badge variant="outline" className="text-xs gap-1">
              {data.engine === 'llm' ? 'AI-аннотация' : 'Из фактов'}
            </Badge>
          }
        />

        {/* AI-аннотация: «Сильные стороны: X, Y. Transferable для: A, B, C.» */}
        <p className="text-sm leading-relaxed pt-1">{data.annotation}</p>

        {/* Подтверждённые навыки */}
        {data.confirmedSkills.length > 0 && (
          <div className="pt-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Подтверждённые навыки ({data.confirmedSkills.length})
            </div>
            <div className="flex flex-wrap gap-1.5">
              {data.confirmedSkills.slice(0, 12).map((s) => (
                <Badge key={s.id} variant="secondary" className="text-xs gap-1">
                  {s.name}
                  <span className="text-xs text-muted-foreground">·{s.level}/5</span>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Хобби — только если showHobbiesToHr=true */}
        {data.hobbiesVisible && data.hobbies.length > 0 ? (
          <div className="pt-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Хобби (видны по opt-in кандидата)
            </div>
            <div className="flex flex-wrap gap-1.5">
              {data.hobbies.map((h, i) => (
                <Badge key={`${h}-${i}`} variant="outline" className="text-xs">
                  {h}
                </Badge>
              ))}
            </div>
          </div>
        ) : data.hobbiesCount > 0 ? (
          <div className="pt-2 text-xs text-muted-foreground italic">
            У кандидата {data.hobbiesCount}{' '}
            {data.hobbiesCount === 1 ? 'хобби' : data.hobbiesCount < 5 ? 'хобби' : 'хобби'}, но он не дал согласия
            на показ HR. Список анонимизирован.
          </div>
        ) : null}

        {/* Кнопка «Отправить персонализированное приглашение» */}
        <div className="pt-3 border-t flex justify-end">
          <Button size="sm" variant="outline" onClick={() => setInvitationOpen(true)} className="gap-1.5">
            <Send className="w-3.5 h-3.5" />
            Отправить персонализированное приглашение
          </Button>
        </div>
      </CardContent>

      {/* Диалог «Персонализированное приглашение» — пока заглушка */}
      {invitationOpen && (
        <InvitationDialog
          open={invitationOpen}
          onOpenChange={setInvitationOpen}
          candidateId={userId}
          candidateName={userName}
          annotation={data.annotation}
        />
      )}
    </Card>
  );
}

// ============================================================================
// Заглушка: диалог персонализированного приглашения
// В продакшене — должно открывать HrContactButton с предзаполненным сообщением
// из AI-аннотации transferable skills. Пока — простая обёртка.
// ============================================================================
function InvitationDialog({
  open,
  onOpenChange,
  candidateId,
  candidateName,
  annotation,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  candidateId: string;
  candidateName: string;
  annotation: string;
}) {
  // Используем существующий HrContactButton внутри диалога — он уже умеет отправлять
  // контакт с сообщением. Предзаполним сообщение аннотацией transferable skills.
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-4 h-4 text-lighthouse" />
            Персонализированное приглашение для {candidateName}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="rounded-lg bg-muted/40 border border-muted p-3 text-xs text-muted-foreground">
            <div className="font-medium text-foreground mb-1">AI-контекст кандидата:</div>
            {annotation}
          </div>
          <p className="text-sm text-muted-foreground">
            Нажмите кнопку ниже, чтобы инициировать контакт. Лимит — 1 контакт в неделю на кандидата.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
              Отмена
            </Button>
            <HrContactButton
              candidateId={candidateId}
              candidateName={candidateName}
              // Сообщение предзаполнить аннотацией — пользователь увидит поле и сможет отредактировать
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// Правка 3 — Блок «Общие контакты» (как Vings/XING)
// Загружает /api/users/[id]/common-contacts, показывает до 3 аватаров + «+N»
// ============================================================================
interface CommonContact {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
}
interface CommonContactsResponse {
  contacts: CommonContact[];
  total: number;
}

function CommonContactsBlock({ userId, userName }: { userId: string; userName: string }) {
  const { setProfileUserId } = useAppStore();
  const [data, setData] = React.useState<CommonContactsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<CommonContactsResponse>(`/api/users/${userId}/common-contacts`);
      setData(res);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить общих контактов');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  return (
    <Card>
      <CardContent className="p-4 sm:p-6">
        <SectionTitle
          icon={<Handshake className="w-4 h-4" />}
          label="ОБЩИЕ КОНТАКТЫ"
          right={
            !loading && data ? (
              <span className="text-xs text-muted-foreground">
                {data.total} {pluralCommon(data.total)}
              </span>
            ) : null
          }
        />

        {loading ? (
          <div className="flex items-center gap-2 mt-3">
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-9 h-9 rounded-full" />
          </div>
        ) : error ? (
          <p className="text-xs text-muted-foreground mt-3">
            Не удалось загрузить общих контактов.
          </p>
        ) : !data || data.total === 0 ? (
          <p className="text-sm text-muted-foreground mt-3">
            Нет общих контактов с {userName.split(' ')[0]}.
          </p>
        ) : (
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            {/* До 3 аватаров */}
            {data.contacts.slice(0, 3).map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setProfileUserId(c.id)}
                title={c.title ? `${c.name} · ${c.title}` : c.name}
                className="group flex flex-col items-center gap-1 transition hover:opacity-80"
              >
                <div className="rounded-full ring-2 ring-background">
                  <UserAvatar name={c.name} avatarUrl={c.avatarUrl} size="sm" />
                </div>
                <span className="text-xs text-muted-foreground max-w-[60px] truncate">
                  {c.name.split(' ')[0]}
                </span>
              </button>
            ))}
            {/* «+N» если больше */}
            {data.total > 3 && (
              <div
                className="flex items-center justify-center w-8 h-8 rounded-full bg-muted text-xs font-semibold text-muted-foreground ring-2 ring-background"
                title={`Ещё ${data.total - 3} общих контактов`}
              >
                +{data.total - 3}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Правка 3 — Блок «Цепочка доверия» (killer feature)
// POST /api/ai/matchmaker { toUserId } → визуализация пути
// ============================================================================
interface MatchmakerPathUser {
  userId: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  ipScore: number;
}
interface MatchmakerPathResponse {
  found: boolean;
  path: MatchmakerPathUser[];
  confidence: number;
  introducerId: string | null;
  introTemplate: string;
}

// KV2 D-01 (фаза E): блок монтируется в profile-view — профиль чужого.
export function TrustChainBlock({ userId, userName }: { userId: string; userName: string }) {
  const { setProfileUserId, user: currentUser } = useAppStore();
  const [data, setData] = React.useState<MatchmakerPathResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Существующий /api/ai/matchmaker POST принимает { toUserId }.
      // Находит кратчайший путь в графе доверия (5 рукопожатий).
      const res = await api<MatchmakerPathResponse>(`/api/ai/matchmaker`, {
        method: 'POST',
        body: JSON.stringify({ toUserId: userId }),
      });
      setData(res);
    } catch (e: any) {
      // 429 — rate limit по тарифу; не показываем как ошибку, просто «Нет цепочки»
      setError(e?.message ?? 'Не удалось построить цепочку доверия');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  // Число «рукопожатий» = число рёбер = path.length - 1
  // path[0] = я, path[last] = целевой пользователь.
  // Прямая связь (path.length === 2) — «Вы связаны напрямую»
  const handshakes = data?.path?.length ? data.path.length - 1 : 0;
  const isDirect = handshakes === 1;

  return (
    <Card className="bg-lighthouse-gradient-soft border-lighthouse/30">
      <CardContent className="p-4 sm:p-6">
        <SectionTitle
          icon={<Link2 className="w-4 h-4 text-lighthouse" />}
          label="ЦЕПОЧКА ДОВЕРИЯ"
          right={
            !loading && data?.found ? (
              <span className="text-xs text-muted-foreground">
                {isDirect ? 'напрямую' : `${handshakes} рукопожатия`}
              </span>
            ) : null
          }
        />

        {loading ? (
          <div className="flex items-center gap-2 mt-3">
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-8 h-1.5" />
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-8 h-1.5" />
            <Skeleton className="w-9 h-9 rounded-full" />
          </div>
        ) : !data || !data.found ? (
          <p className="text-sm text-muted-foreground mt-3">
            Нет цепочки доверия до {userName.split(' ')[0]}.
            {error && error.includes('лимит') && (
              <span className="block mt-1 text-xs text-amber-600 dark:text-amber-400">
                {error}
              </span>
            )}
          </p>
        ) : isDirect ? (
          <div className="mt-3 flex items-center gap-2 text-sm">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-lighthouse/15 text-lighthouse font-medium">
              <Handshake className="w-3.5 h-3.5" />
              Вы связаны напрямую
            </span>
          </div>
        ) : (
          <div className="mt-3 flex items-center gap-1.5 flex-wrap">
            {/* «Ты» — первый узел пути */}
            <PathNode
              name={currentUser?.name ?? 'Вы'}
              avatarUrl={currentUser?.avatarUrl ?? null}
              isMe
            />
            {/* Промежуточные узлы + целевой */}
            {data.path.slice(1).map((node, idx) => (
              <React.Fragment key={node.userId}>
                <Arrow />
                <PathNode
                  name={node.name}
                  avatarUrl={node.avatarUrl}
                  isLast={idx === data.path.length - 2}
                  onClick={() =>
                    idx !== data.path.length - 2 && setProfileUserId(node.userId)
                  }
                />
              </React.Fragment>
            ))}
          </div>
        )}

        {!loading && data?.found && !isDirect && data.path.length > 2 && (
          <div className="mt-3 flex flex-col gap-2">
            <p className="text-xs text-muted-foreground">
              Через {shortFirstName(data.path[1].name)} можно попросить интро.
            </p>
            <IntroRequestButton
              targetId={userId}
              targetName={userName}
              introducerName={data.path[1].name}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// D-01 (KV2): «Запросить знакомство» — дверь к POST /api/intros.
// ============================================================================
const INTRO_PURPOSES: Array<{ value: string; label: string }> = [
  { value: 'job', label: 'Работа' },
  { value: 'project', label: 'Проект' },
  { value: 'mentorship', label: 'Менторство' },
  { value: 'partnership', label: 'Партнёрство' },
  { value: 'other', label: 'Другое' },
];

function IntroRequestButton({
  targetId,
  targetName,
  introducerName,
}: {
  targetId: string;
  targetName: string;
  introducerName: string;
}) {
  const [open, setOpen] = React.useState(false);
  const [purpose, setPurpose] = React.useState('other');
  const [message, setMessage] = React.useState('');
  const [sending, setSending] = React.useState(false);
  const [sent, setSent] = React.useState(false);

  const submit = async () => {
    setSending(true);
    try {
      const res = await api<{ id: string; introducerName: string }>('/api/intros', {
        method: 'POST',
        body: JSON.stringify({
          targetId,
          purpose,
          ...(message.trim() ? { message: message.trim() } : {}),
        }),
      });
      toast({
        title: 'Запрос на знакомство отправлен',
        description: `Посредник: ${res.introducerName ?? introducerName}. Сообщение уйдёт цели после подтверждения.`,
      });
      setSent(true);
      setOpen(false);
    } catch (e: any) {
      toast({
        variant: 'destructive',
        title: 'Не удалось отправить запрос',
        description: e?.message ?? 'Попробуйте позже',
      });
    } finally {
      setSending(false);
    }
  };

  if (sent) {
    return (
      <Button variant="outline" disabled className="w-fit gap-2 text-muted-foreground">
        <Check className="w-4 h-4" />
        Запрос отправлен
      </Button>
    );
  }

  return (
    <>
      <Button onClick={() => setOpen(true)} className="w-fit gap-2">
        <Handshake className="w-4 h-4" />
        Запросить знакомство
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent aria-describedby="intro-request-desc" className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Запросить знакомство с {targetName.split(' ')[0]}</DialogTitle>
          </DialogHeader>
          <p id="intro-request-desc" className="text-sm text-muted-foreground">
            Посредник {introducerName.split(' ')[0]} получит ваш запрос. Сообщение дойдёт до цели только после его подтверждения.
          </p>
          <div className="grid gap-2">
            <Label htmlFor="intro-purpose">Цель знакомства</Label>
            <Select value={purpose} onValueChange={setPurpose}>
              <SelectTrigger id="intro-purpose" aria-label="Цель знакомства">
                <SelectValue placeholder="Выберите цель" />
              </SelectTrigger>
              <SelectContent>
                {INTRO_PURPOSES.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="intro-message">Сообщение посреднику (необязательно)</Label>
            <Textarea
              id="intro-message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              maxLength={2000}
              rows={3}
              placeholder={`Почему вам важно познакомиться с ${targetName.split(' ')[0]}?`}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)} disabled={sending}>Отмена</Button>
            <Button onClick={submit} disabled={sending} className="gap-2">
              <Handshake className="w-4 h-4" />
              {sending ? 'Отправляю…' : 'Отправить запрос'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

function PathNode({
  name,
  avatarUrl,
  isMe = false,
  isLast = false,
  onClick,
}: {
  name: string;
  avatarUrl: string | null;
  isMe?: boolean;
  isLast?: boolean;
  onClick?: () => void;
}) {
  const inner = (
    <>
      <div
        className={cn(
          'rounded-full ring-2 ring-background',
          isMe && 'ring-lighthouse/30'
        )}
      >
        <UserAvatar name={name} avatarUrl={avatarUrl} size="sm" />
      </div>
      <span
        className={cn(
          'text-xs mt-1 max-w-[64px] truncate',
          isLast ? 'font-medium text-foreground' : 'text-muted-foreground'
        )}
      >
        {isMe ? 'Вы' : name.split(' ')[0]}
      </span>
    </>
  );

  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        title={name}
        className="group flex flex-col items-center gap-0.5 transition hover:opacity-80"
      >
        {inner}
      </button>
    );
  }
  return (
    <div className="flex flex-col items-center gap-0.5" title={name}>
      {inner}
    </div>
  );
}

function Arrow() {
  return (
    <ChevronRight className="w-4 h-4 text-muted-foreground/60 self-center mt-[-12px]" />
  );
}

// ============================================================================
// Правка 3 — Диалог «Написать сообщение» (POST /api/messages)
// ============================================================================
function MessageComposeDialog({
  open,
  onOpenChange,
  toUserId,
  toUserName,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  toUserId: string;
  toUserName: string;
}) {
  const [content, setContent] = React.useState('');
  const [sending, setSending] = React.useState(false);

  const handleSend = async () => {
    const trimmed = content.trim();
    if (!trimmed) {
      toast({ title: 'Введите текст сообщения', variant: 'destructive' });
      return;
    }
    setSending(true);
    try {
      await api('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ toUserId, content: trimmed }),
      });
      toast({ title: `Сообщение отправлено для ${toUserName.split(' ')[0]}` });
      setContent('');
      onOpenChange(false);
    } catch (e: any) {
      toast({
        title: 'Не удалось отправить',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-lighthouse" />
            Написать {toUserName.split(' ')[0]}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`Здравствуйте, ${toUserName.split(' ')[0]}! ...`}
            rows={5}
            maxLength={2000}
            disabled={sending}
          />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Максимум 2000 символов</span>
            <span>{content.length}/2000</span>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onOpenChange(false)}
              disabled={sending}
            >
              Отмена
            </Button>
            <Button size="sm" onClick={handleSend} disabled={sending || !content.trim()}>
              {sending ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> Отправка...
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5 mr-1" /> Отправить
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Вспомогательные plural/имя для блоков Правки 3
function pluralCommon(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'общий контакт';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'общих контакта';
  return 'общих контактов';
}

function shortFirstName(fullName: string): string {
  return fullName.trim().split(/\s+/)[0] ?? fullName;
}
```

</details>

---
## Статистика на текущий момент

- Записей: 4. Файлов с кодом: 26 (28 строк в индексе с учётом повторных удалений №003/№004). Строк в резервных копиях: см. индекс (~8060).
- Пустых директорий: 5 (после №003 пустые `src/app/api/hr/`, `src/app/api/hr/[id]/`, `src/app/api/placements/[id]/review/` убраны).

## Запись №005 — старый Wave-1 BizCardDialog (заменён персистной визиткой W5-2)

- **Дата:** 2026-09-19
- **Коммит:** `d8a0057` (рабочее дерево, волна 5)
- **Релиз системы:** 1.1.1-pilot-ready
- **Задача:** W5-1+W5-2+W5-4 (OWNER-UX-PLAN-2026-09-19, шаги 18-20 из 24)
- **Причина:** визитка по ТЗ стала персистной (модель `Bizcard`, одна на пользователя, услуги/логотип/qrIncludes/отправка). Старый диалог работал только со старым stateless-контрактом `POST /api/me/bizcard` (пересчёт без сохранения, поля `displayName/includes`), который полностью переписан (GET/POST/PATCH/DELETE с новыми полями). Контракт несовместим.
- **Доказательство:** `rg "bizcard-dialog" src/` до удаления — единственный импорт `src/components/network/network-view.tsx:19` (переперен на `@/components/bizcard/bizcard-dialog`); `rg "api/me/bizcard" src/` — только сам диалог и PDF-роут (переписан). Новый компонент: `src/components/bizcard/bizcard-dialog.tsx`.
- **Восстановление:** код ниже, либо `git show d8a0057:src/components/trust/bizcard-dialog.tsx`.

```tsx
// BizON — BizCardDialog (Wave 1 S-022): цифровая визитка с QR и печатью A6.
// QR ведёт на публичную страницу-паспорт /p/[token] (REUSE существующей).
// PDF — через системную печать браузера (A6 @media print) — без новых зависимостей.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { IdCard, Printer, QrCode as QrIcon , FileDown } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface BizCardData {
  displayName: string;
  headline: string | null;
  qrDataUrl: string;
  publicToken: string;
  includes: { email: boolean; phone: boolean; skills: boolean };
  contactEmail?: string | null;
  contactPhone?: string | null;
  skills?: string[];
}

export function BizCardDialog({ trigger }: { trigger?: React.ReactNode }) {
  const { user } = useAppStore();
  const [open, setOpen] = React.useState(false);
  const [data, setData] = React.useState<BizCardData | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [displayName, setDisplayName] = React.useState('');
  const [includes, setIncludes] = React.useState({ email: true, phone: false, skills: true });

  async function load() {
    setLoading(true);
    try {
      const res = await api<BizCardData>('/api/me/bizcard', {
        method: 'POST',
        body: JSON.stringify({ displayName: displayName || undefined, includes }),
      });
      setData(res);
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось собрать визитку', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  React.useEffect(() => {
    if (open && user) {
      setDisplayName(user.name ?? '');
      void load();
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button variant="outline" size="sm">
            <IdCard className="w-4 h-4 mr-2" /> Моя визитка
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md" aria-label="Цифровая визитка">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><QrIcon className="w-4 h-4" /> Цифровая визитка</DialogTitle>
          <DialogDescription>QR ведёт на вашу публичную страницу. Данные включаются по вашему выбору.</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Имя на визитке" aria-label="Имя на визитке" />
          <div className="grid grid-cols-3 gap-2 text-sm">
            {([['email', 'Email'], ['phone', 'Телефон'], ['skills', 'Навыки']] as const).map(([k, label]) => (
              <label key={k} className="flex items-center gap-2 cursor-pointer">
                <Checkbox checked={includes[k]} onCheckedChange={(v) => setIncludes((s) => ({ ...s, [k]: v === true }))} />
                {label}
              </label>
            ))}
          </div>

          {data && (
            <div id="bizcard-a6" className="mx-auto w-[300px] rounded-xl border bg-background p-4 print:a6-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold truncate">{data.displayName}</div>
                  {data.headline && <div className="text-xs text-muted-foreground truncate">{data.headline}</div>}
                </div>
                <img src={data.qrDataUrl} alt={`QR визитки ${data.displayName}`} className="w-20 h-20 rounded-md border" />
              </div>
              <div className="mt-2 space-y-0.5 text-xs text-muted-foreground">
                {data.includes.email && data.contactEmail && <div>{data.contactEmail}</div>}
                {data.includes.phone && data.contactPhone && <div>{data.contactPhone}</div>}
                {data.includes.skills && data.skills && data.skills.length > 0 && (
                  <div className="truncate">Навыки: {data.skills.slice(0, 5).join(', ')}</div>
                )}
                <div className="text-[10px] opacity-70">BizON · p/{data.publicToken}</div>
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <Button className="flex-1" onClick={load} disabled={loading}>
              {loading ? 'Собираем…' : 'Обновить'}
            </Button>
            {/* D-12 (KV2): серверный PDF A6 (не только печать браузера) */}
            <Button
              variant="outline"
              onClick={() => {
                const a = document.createElement('a');
                a.href = '/api/me/bizcard/pdf';
                a.download = 'bizon-bizcard-a6.pdf';
                a.click();
              }}
              disabled={!data}
            >
              <FileDown className="w-4 h-4 mr-2" /> PDF A6
            </Button>
            <Button variant="outline" onClick={() => window.print()} disabled={!data}>
              <Printer className="w-4 h-4 mr-2" /> Печать A6
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
```
