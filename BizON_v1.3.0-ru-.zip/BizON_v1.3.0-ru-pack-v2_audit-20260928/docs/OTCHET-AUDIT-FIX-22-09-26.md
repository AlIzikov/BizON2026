# ОТЧЁТ: исполнение аудита 22-09-26 — что сделано, что отложено, что устарело

**Команда 29 v3 (владелец), таймбокс 5 часов, волны W0–W4.**
Исполнитель: координатор + агенты 29-a/29-b/29-c/29-d/29-e/29-f.
Источник аудита: `upload/аудит 22-09-26.txt` (84 нахождения). Матрица верификации: `docs/audit/MATRIX-22-09-26.md`.

---

## 1. Гейты (финал)

| Гейт | Результат |
|---|---|
| bun test tests/ | **576 pass / 0 fail** (2501 expect, 51 файлов; W1: 574/574, W5 +2 контракта заявок) |
| bun run lint | **0 errors** / 5 pre-existing warnings |
| npx tsc --noEmit | **0 ошибок** (W5; см. §9 — на момент W4 этот замер был неверен: фактически 107 ошибок, гейт закрыт дожимом W5) |
| verify-emil-adoption.mjs | **5/5** (EMIL_DOC, MOBILE_BASELINE, VIEWPORT, FOOTER_SAFEAREA, BUTTON_PRESS) |
| Живая приёмка (agent-browser) | лендинг+landmarks ✓, вход владельца через UI ✓, вкладка «Проекты» без краша ✓, смерть сессии → лендинг ✓, Mobile 390: без h-скролла, footer+main ✓ |
| Живая приёмка W5 (доп.) | apply-диалог с восстановленными полями ✓, реальная заявка записана в БД (coverLetter/city/specialization/isRead=false) ✓, console 0 errors ✓ |
| Живые API-пробы | login 200 (owner/qa-01/qa-03/test.private), GDPR export-data 200, trust-explain 401 без сессии; W5: search/unified 200, me/inbound 200, skills evidence 200, c/[token] 200 |
| Якорные коммиты | `5ca9216` (W0 матрица) → `99a1b11` (W1) → `fa9a0f7` (W2) → `d0ec093` (W3-W4) → `aad134e` (W5) |

## 2. Исправлено кодом+тестами (A-класс, закрыто)

### Крипта и секреты (29-b)
- **CRYPTO-001 fail-closed**: `src/lib/security/crypto.ts` — encrypt/decrypt больше не `catch→return ''`; ошибки → throw; пустой вход → ''; добавлен `tryDecrypt()` (→ null) для legacy/недоверенных данных; все вызыватели классифицированы (api-helpers ×8, user-vault, coach-service, totp-service).
- **CRYPTO-002/016**: `src/lib/config/security-env.ts` — requireEnv + валидация 64-hex env-ключа, wire в getEncryptionKey.
- **CRYPTO-009**: формат `BIZON1:<base64(iv|ct|tag)>` + обратная совместимость legacy-шифротекстов.
- **CRYPTO-004**: `src/lib/security/redact-sensitive.ts` (SENSITIVE_KEYS lowercase-фикс мёртвых ключей аудита).
- **CRYPTO-012**: `src/lib/security/canonical-json.ts` + канон-хэширование AuditLog — новые записи с маркером `v2:` в chainHash, legacy-цепочка (150 записей) верифицируется старой формулой, стык бесшовный (проверено на копии БД).
- **CRYPTO-008 доскан**: timing-safe замены — admin-guard (x-admin-token), vc-export (JWS), totp (backup-коды).
- **CRYPTO-017**: `tests/security/crypto.test.ts` — 16 тестов (round-trip BIZON1, tamper→throw, missing key→throw, legacy-decrypt, tryDecrypt, redact, canonical, timing-safe).

### API и протокол (29-c)
- **API-005/006**: единый контракт ошибок `{error: string, code, requestId}` — добавочно, фронтенд-совместимо; коды AUTH_REQUIRED/VALIDATION_ERROR/RATE_LIMITED/CONFLICT/NOT_FOUND/PAYLOAD_TOO_LARGE/UNSUPPORTED_MEDIA_TYPE/TOO_MANY_PARAMETERS/CSRF_REJECTED/INTERNAL_ERROR.
- **API-025**: `x-request-id` на каждый ответ (успех и ошибка), переиспользование клиентского trace-id.
- **API-008**: CSRF origin-гейт на мутации (Origin/Referer vs x-forwarded-host), 403 CSRF_REJECTED, эскейп-хэтч `csrf:false`; критично при SameSite=None в iframe.
- **API-009/010/011**: 415 не-JSON мутациям; 413 по content-length и факту (256KB, эскейп-хэтч `maxBodyBytes`); 400 при >50 query-параметрах.
- **API-012**: `paramsSchema` в withRoute; применён на jobs/[id]/boost.
- **API-027**: пресеты `RATE_CLASSES` (AUTH_STRICT 10/мин, USER_READ 120, AI_EXPENSIVE 20, MONEY 30, PUBLIC_READ 200).
- **API-002**: `/api/auth/me` → withRoute (форма `{user}` и 401 сохранены).
- **API-003/004**: `/api/auth/login` → withRoute({auth:false, strict-schema, AUTH_STRICT}); сохранены 1:1 backoff, 2FA-challenge, cookie, AuditLog (перечень в worklog 29-c).
- **API-034**: `scripts/api-schema-coverage.mjs` — 357 роутов, withRoute **211/357 (59.1%)**, schema 28, инвентарь legacy (`--list-legacy`).
- **Тесты**: `tests/api-contract.test.ts` — 15 тестов (контракт 401, x-request-id, CSRF чужой/свой/нет, 413/415, query>50, 429+code).

### Деньги и БД (29-d)
- **DB-003**: `lumenFraction Float` → `lumenFractionMinor Int` (масштаб 1/1000, константа LUMEN_FRACTION_SCALE); бэкфилл из бэкапа, mismatches=0; потерь < 0.04 люмена.
- **DB-006**: `LumenTransaction.idempotencyKey @unique` + идемпотентные ветки debit() (дубль ключа → один transactionId, P2002-путь).
- **DB-014**: Outbox lease — `lockedAt/lockedBy/nextAttemptAt`, claim через updateMany, backoff attempts²×5s (кап 15 мин), протухший lease (>60s) перекупается.
- **DB-013+API-018**: cursor-пагинация `/api/news` и `/api/notifications` — контракт `{items, pageInfo:{nextCursor, hasNextPage}}`, порядок createdAt+id, legacy-ветка сохранена.
- **DB-005/004 (доказательства)**: `tests/money/lumen-race.test.ts` — 100 параллельных дебетов по 1 → balance=0, 100 ok, 101-й insufficient, ни одного отрицательного; инвариант balance==Σ(txn). Overdraw 40 при 10 → ровно 10 ok.
- **DB-007**: семантика emailHash NULL — `tests/db-invariants.test.ts` + PRAGMA/P2002-проверка уникальностей (DB-020: все @@unique уже на месте).
- 21 тест money/outbox/db-invariants — зелёные.

### UX/UI (29-e — закрытие пробела аудита)
- **P0**: вкладка «Проекты» роняла весь SPA (`project.topics.length` при отсутствии поля в API) — `src/components/projects/feed/projects-feed.tsx`, нормализация `topics ?? tags ?? []`. Подтверждено живьём: до — Application error, после — рендер без ошибок консоли.
- **Глобальный 401-интерцептор** (утрачен при откате песочницы — восстановлен): `src/stores/app-store.ts` api() → 401 вне /api/auth при живом user → setUser(null) + `bizon:session-expired`; `src/app/page.tsx` — тост «Сессия истекла» → лендинг. Проверено живьём: смерть сессии → лендинг; неверный пароль НЕ даёт ложного тоста.
- **app-shell**: `h-screen` → `h-dvh` (iOS-тулбары), safe-area на нижней навигации.
- **Лендинг**: `<main>`-landmark, aria-label навигации, тап-таргеты ≥44px, active:scale + focus-visible на 5 CTA.
- **API-032**: ложный тост «Сохранено» в recommendations-carousel (закладка не ходила на сервер) — устранён; эталонные паттерны подтверждены (jobs-view, trust-stream, store-view).
- **API-033**: нарушений инвалидации кэша не найдено (примеры: companies-view handleFollow, store-view load()).

### Инфраструктура тестов (найдено и починено на гейте W1)
- **Кризис логинов** (блокер приёмки): keyfile пересоздан песочницей 22-09 20:22 → все emailHash невалидны, ни один аккаунт не логинился. Ремонт: `scripts/reset-demo-passwords.ts` (10/10 демо) + создан `scripts/repair-canonical-accounts.ts` (owner, qa-01..05, test.private — идентичность текущим ключом). Живые логины 200.
- **Интерференция тестов**: bun гонит файлы параллельно в одном процессе; env-манипуляции кассовых тестов ломали эскроу wave2 (CASHIER_COMMISSION_UNCONFIGURED / CASHIER_REAL_NOT_ENABLED). Решение: TEST-ONLY `setCashierConfigForTests()` (prod-guard) в virtual-cashier-service, тесты кассы не трогают process.env, wave2 пинит virtual/0%. Канон: тесты не трогают env при параллельном прогоне.
- BizCard logoUrl (легитимные ~5 МБ data URL) — `maxBodyBytes: 6MB` на POST/PATCH.

## 3. Отложено осознанно (B-класс: ADR/документы готовы, исполнение — решение владельца)

| Пункт | Документ | Суть |
|---|---|---|
| DB-001 PostgreSQL | `docs/adr/adr-postgresql-migration.md` (ADR-004) | 10-этапный план аудита; находка: prisma/migrations уже PG-ready, но baseline отстаёт (72 таблицы vs 125 моделей). Сам аудит запрещает слепой переезд |
| API-026 Redis | ADR-004 | KV-абстракция rate-limiter уже Redis-совместима — меняется только бэкенд KVStore |
| DB-021 CI-gate db:push | ADR-004 § | скетч гейта; исполнение — отдельная задача |
| CRYPTO-010/011 разделение секретов | `docs/adr/adr-secrets-separation.md` (ADR-005) | немедленная ротация ЗАПРЕЩЕНА (emailHash всей БД = HMAC текущего ключа — эон-кризис 22-09); находка: policySignature/VC-JWS фолбэка́т на тот же keyfile — разделение наполовину фиктивно; 6-шаговый путь с dual-ключом |
| DB-025/026 домены | `docs/database/domain-ownership.md` | 13 концептов разобраны (UserRecommendation отсутствует в схеме — алиас); User = 112 связей / 13 bounded contexts; algorithmVersion на ReputationSnapshot/ipScore — долг |
| DB-010/011 lifecycle | `docs/database/data-lifecycle.md` | retention/soft/hard/каскады по core-сущностям |
| DB-002 User-агрегат | domain-ownership.md | документ bounded contexts, слом модели запрещён командой |
| API-023 версионирование | ADR-004 | /api/* = versioned-by-contract |
| API-029/030 async lifecycle | ADR-004/005 | длинных синхронных операций не выявлено |
| CRYPTO-007/013 | ADR-005 | verification-token сервис уже существует; DataClassification — в ADR |
| API-001 остаток (152 legacy-роута) | scripts/api-schema-coverage.mjs | дорожная карта миграции на withRoute — следующая сессия |

## 4. Устаревшие утверждения аудита (не исполнялись, с доказательствами)

| Пункт | Утверждение аудита | Факт (file:line) |
|---|---|---|
| DB-005 | дебет не атомарен | lumen-service.ts:351/408/539 — guard-decrement (updateMany where gte) + ledger в одной $transaction (FIX-06). Осталось только доказать тестом — сделано |
| DB-006 | idempotency отсутствует | schema:2376/2775 — idempotencyKey @unique на CashierOperation и payment-callbacks, refundOf @unique на refund |
| API-026 | rate limiter — in-memory Map, не готов к распределённости | rate-limiter.ts:10-26 — KV-абстракция (src/lib/runtime/kv.ts), «при переезде на Redis меняется только бэкенд KVStore» |
| CRYPTO-002/003 | production fallback secret | instrumentation.ts fail-fast + throw при NODE_ENV=production (crypto.ts:70-75); dev-keyfile DEV-ONLY задокументирован. Добавлено лишь: валидация 64-hex |
| API-019 | динамический orderBy из ввода | скан: все orderBy — статические литералы/константы (news:54, notifications:21, feed-service:99) |
| API-024 webhooks | нет подписи | внешних webhook-эндпоинтов через withRoute не найдено (cron идёт по x-cron-secret) — при появлении: signature+timestamp+replay (ADR) |

## 5. C-класс (отказ с причиной)

- **DB-029** (бенчмарки 1M/100M строк): невозможно в песочнице — нет prod-масштаба; зафиксировано в ADR-004 как этап пред-cutover.
- **API-024** (webhook signature): внешних webhooks нет — не к чему применять; правило заложено в ADR.

## 6. Прогресс по 15 экспертам

| # | Эксперт | Статус | Обработка |
|---|---|---|---|
| 1 | (Auth/CSRF — цитируется API-008) | ⏳ не получен | ждём от владельца |
| 2 | Crypto & Secrets (19) | ✅ получен | исполнен (W1, 29-b): A×10, B×4, сканы |
| 3 | Database Architect (30) | ✅ получен | исполнен (W1, 29-d): A×9, B×9, C×1, STALE×4 |
| 4 | API & Protocol (35) | ✅ получен | исполнен (W1, 29-c): A×15, B×4, сканы |
| 5 | DevOps | ⏳ только преамбула | ждём полный текст |
| 6–15 | — | ⏳ не получены | конвейер готов: каждая порция обрабатывается без новой команды (сверка → A/B/C → правки → гейты) |

## 7. Открытые решения владельца (из 29-f)

1. Бюджет/окно PostgreSQL-перехода (ADR-004, этапы 1–10).
2. Судьба денег-журнала при hard delete User: сейчас Cascade на LumenTransaction/CashierOperation — удаление пользователя сносит деньги-журнал (конфликт с append-only); 7 FK без onDelete блокируют hard delete (GDPR не выполняется — cron-cleanup упадёт).
3. Анонимизация переписки при удалении аккаунта (сейчас Cascade стирает диалоги целиком).
4. Единообразие soft-delete (deletedAt-канон vs статусный).

## 8. Честные ограничения

- Строгий decrypt на legacy-записях сторонних пользователей (телефоны старых эпох) теперь даёт ошибку вместо тихого '' — для канон/демо-аккаунтов идентичность отремонтирована, для прочих — tryDecrypt-миграция оставшихся роутов в зоне API (следующая сессия).
- withRoute-покрытие 59.1% — остаток 152 legacy-роута мигрируется по дорожной карте (API-001, класс B-остаток).
- Прогресс реального времени: ~4.5 часа из 5 (таймбокс соблюдён) + дожим W5.

---

## 9. Дожим W5 (после сдачи W3-W4): закрытие tsc-гейта честно

**Поправка к W4:** заявление «2 предсуществующие tsc-ошибки в c/[token]/page.tsx» было **неверным замером** — полный `npx tsc --noEmit` на момент W4 давал **107 ошибок в 27 файлах**; tsc-гейт Команды 29 фактически не был зелёным (в таблице гейтов W4 tsc отсутствовал). Исправлено дожимом W5 (координатор + агенты 29-g/h/i/j), коммит `aad134e`.

### 9.1 Восстановление утерянного контракта схемы (29-g) — живой баг, не только типы
Поля `coverLetter/isRead/city/specialization` (ProjectApplication) и `coverLetter/roleApplied/isRead` (LotResponse) были в схеме 17-09 (`e363602`) и исчезли в автокоммите `40c970b` (19-09, UUID-сообщение — не документированное решение). Фронт-контракт жив (`project-page.tsx:595`, `applications-panel.tsx:39-203`, `my-lots.tsx:289/347/357`) → **apply-флоу и «Мои лоты» были сломаны в runtime** (Prisma unknown field). Восстановлено аддитивным push (данные целы); `message` → Optional (два write-контура). Живое доказательство: заявка владельца записана через UI со всеми полями. Тест-контракт: `tests/api-applications-contract.test.ts`.
ProjectConfirmation: выравнивание кода по схеме (confirmedAt→decidedAt, userId→decidedBy-семантика) — здесь дрейф был в коде, схема не менялась.

### 9.2 Мёртвый код удалён с evidence (29-h, 7 файлов ~870 строк)
`/api/follows` + `follow-button.tsx` (модели Follow никогда не существовало — `git log -S "model Follow"` пуст, роут всегда 500); research-кластер: 3 роута + `research-view.tsx` (фича остановлена на интеграции: поля testKey/scores/summary/provider в схеме отсутствуют, потребителей ноль, тестов ноль); `/api/news/[id]/click` (единственная функция — инкремент несуществующей колонки clicks). Модель ResearchResult в БД не тронута (жива: research-service, ai-co-pilot). Орфан на следующую волну: `src/lib/research-tests.ts` без потребителей.

### 9.3 Выравнивание сервисного слоя по схеме (29-i)
`_intentAlignment` экспортирован (opportunity-service); inbound-service: `direction`→конвенция `type='job'`+`jobId`+`requirements.personId`, `openTo`→`professionalStatus` (gate isOpenToJobOffers, back-compat null); unified-search/company-passport/skills-evidence: `privacyProfile` выпилен (модели нет). Находка: UserSkill relations СУЩЕСТВУЮТ (schema:615-617) — 8 ошибок были от одного excess-property `privacyProfile`, деградировавшего весь include-тип. company-passport `results`-каунт → ProfessionalEvidence groupBy (конвенция project-result-service).

### 9.4 Типы фронтенда и тестов (29-h/29-j)
`DwellItemType`+`ALLOWED_ITEM_TYPES` расширены `'post'` (one-thought-mode — живой фид); `c/[token]` rating→`verifiedResults` (поле rating выпило из контракта в фикс-кампании 17-09). Тесты: kv2 Ctx выровнен, owner-w2 `import type NextRequest`, bun-types `on('exit')` каст (баг bun-types #40003), a5 $transaction типизирован (семантика сохранена).

### 9.5 Расследование POST /api/auth/login 403 (2 шт. в dev.log)
CSRF-гейт API-008 работает корректно: login без Origin → 200, login с совпадающим Origin через гейтвейт :81 → 200, чужой Origin → 403 CSRF_REJECTED (ожидаемо). Легитимный путь владельца (превью/новая вкладка) — работает. Добавлен warn-лог `originHost/requestHost` (без PII) в with-route.ts: при повторении отказа в dev.log сразу видна причина.

### 9.6 Канон W5
1. Полный `npx tsc --noEmit` обязателен в таблице гейтов каждого отчёта (grep-фильтры и частичные прогоны маскируют дрейф).
2. Автокоммиты с UUID-сообщениями — источник дрейфа схемы; после каждого push сверять `git diff` схемы.
3. Удаление мёртвого кода — только с evidence нуля потребителей (src+tests+scripts+adversarial) и отсутствия моделей/полей в истории схемы.
4. Полный bun test гоняет только координатор (общая БД); агенты — точечные файлы.

---

## 10. 29-A-redux (после сдачи W5): свежая верификация 84 ID и закрытие A-остатка ×20

Постановка: конвейер аудита (без новой команды владельца) — реверификация всех 84 находок
аудита 22-09-26 по коду на момент после W5 (гигиена: коммит `7da39e3`), матрица остатка
`docs/audit/MATRIX-22-09-26-RESIDUE.md` (коммит `bde1d04`), затем последовательное закрытие
A-остатка единым райтером (урок 29: параллельные агенты ломали схему).

### 10.1 Остаток верификации (84 ID → A×20 / B×17 / C×5 / УСТАРЕЛ×39)
Верификация read-only (29-a-1/2/3): большая часть критики 22-09-26 уже закрыта Командой 29
(CRYPTO 12/17, DB 9/29, API 18/35 — устарели на момент реверификации). B×17 задокументированы
(ADR-004/005, domain-ownership, data-lifecycle, API-тексты), C×5 отклонены письменно.

### 10.2 Исполнение A×20 (деньги и PII первыми)
- **Cluster C (коммит `c249df9`)**: CRYPTO-003/011 — строковые fallback-секреты
  `dev-vc-key`/`dev-policy-key` удалены; `src/lib/security/signing-key.ts` — цепочка
  env → собственный keyfile назначения → prod throw (реальное разделение ключей VC/policy,
  шаг 4a ADR-005 исполнен в dev-части). CRYPTO-008+API-015 — timing-safe `===`-сравнения
  секретов в 7 роутах (kill-switch, cashier/ports+[id], causality, admin/metrics, metrics, data-plane).
  Тест: `tests/29-c-signing-keys.test.ts` (5/15).
- **29-M-1 (`2f22711`)**: DB-019 — complete проекта атомарным guard `updateMany`
  (TOCTOU: 2 параллельных complete → двойная репутация ADV-C104; race-тест 8 параллельных).
  DB-028 — бюджет AI: атомарный raw-guard `spentUnits+units<=limitUnits` в meterUsage/recordSpend
  (перерасход при гонке невозможен, различены протухший период vs исчерпанный лимит);
  финализация executeApprovedAction — статус+audit одной $transaction («executing навсегда»
  при crash исключён). Тесты: `29-m-project-complete-race` (2), `29-m-ai-budget-race` (3).
- **29-M-2 (`32cc896`)**: DB-015 — durable outbox producer подключён: `emitDurable(tx?)`
  persist'ит outbox-строку В транзакции бизнес-операции (project.completed в transition,
  project.confirmed в confirm); `flushOutboxRow` публикует после коммита (сбой → pending →
  drainOutbox, at-least-once). Раньше события шли in-memory `void EventBus.publish` —
  crash терял событие молча. Тест: `29-m-outbox-durable` (rollback бизнес-операции
  откатывает событие; 5 тестов).
- **29-M-3 (`5319c1d`)**: DB-013 — cursor-пагинация дотянута до posts/feed/messages
  (паттерн news 1:1: lookahead, skip:1+cursor, orderBy с id-tiebreaker, pageInfo;
  legacy offset-ветки сохранены — фронт не сломан). DB-021 — `db:push` через guard
  `scripts/db-push-guarded.js` (NODE_ENV=production → exit 1; канон migrate deploy),
  CI-job в ci.yml. Тест: `29-m-cursor-pagination` (3/23).
- **29-M-4 (`e5dda6d`)**: DB-023 — `notificationSettings Json?` (typed-чтение/запись объектом,
  safeParseSettings принимает JsonValue+легаси-строку); DB-027 — `algorithmVersion`/
  `generatedAt`/`computedAt` в CoachInsight/Opportunity с заполнением в writer'ах
  (coach-v1/inbound-v1/news-bridge-v1); DB-018 — provenance-колонки ProfessionalEvidence
  (projectId/verifiedAt/verifierId/visibility) с заполнением в add/verify
  (инвариант verified⇒verifier непуст); DB-012 — 4 составных индекса лент
  (Post: authorId+createdAt+id, isHidden+createdAt+id; Conversation: fromUserId/toUserId+
  lastMessageAt). Тест: `29-m-schema-invariants` (4/19, PRAGMA index_list).
- **29-A (`2695380`)**: API-005/006 — `errorJson(message, status, code?)` (аддитивно);
  catch-all `e.message→400` устранён в companies/follow и events/rsvp (BizonError → свой
  статус/код, P2003/P2025 → 404, неожиданное → 500+лог). API-007 — политика
  400=схема/422=семантика зафиксирована в шапке with-route. API-001 — money/PII legacy
  мигрированы на withRoute: notifications GET, cashier/status (rate 30/мин сохранён),
  ai/matchmaker (per-тарифный лимит внутри хендлера). API-014 — инвентарь
  `scripts/api-idor-inventory.mjs` (153 динамических роута: OK 51 / MANUAL 102 / OPEN 0)
  + red-team `tests/29-a-idor-money.test.ts` (чужие id в money/PII не отдают данные).
  API-034 — порог-гейт `scripts/api-schema-coverage-gate.mjs` (withRoute 215/359=59%,
  порог зафиксирован, рампа +5%/волна; CI-ready).
- API-012 (низк.) — paramsSchema-инфраструктура готова с 29-c; правило «добавлять на
  денежные [id]-роуты при миграции» продолжается (топап уже withRoute+schema).

### 10.3 Гейты 29-A-redux
| Гейт | Результат |
|---|---|
| npx tsc --noEmit | 0 ошибок (exit 0) |
| bun test tests/ | **620 pass / 0 fail** (2655 expect, 61 файл; базлайн 595 + 25 новых — сходится 1:1) |
| bun run lint | 0 errors / 5 предсуществующих bizcard-warnings |
| Живой смоук | login qa-01 200; me/notifications/lumens/feed/posts/cashier-status/messages → 200; pageInfo в notifications; чужой Origin → 403 CSRF; POST без content-type → 415; x-request-id на ответах; admin/metrics без токена → 401 |
| agent-browser | лендинг → UI-логин qa-01 → лента «Моя лента/Все» → Сообщения → панель «Уведомления» (пустая, консистентно с API); консоль: только предсуществующий aria-warning; Mobile 390×844 — без h-overflow |
| Коммиты | `7da39e3` → `bde1d04` → `c249df9` → `2f22711` → `32cc896` → `5319c1d` → `e5dda6d` → `2695380` (якорные после каждого кластера) |

### 10.4 Канон 29-A-redux
1. Реверификация перед исполнением обязательна даже для СВОЕЙ же матрицы: 3 из «подтверждённых»
   в брифе пунктов (API-002/008/010) уже были закрыты — слепое исполнение задвоило бы работу.
2. Cursor-пагинация — единый паттерн (news-образец): lookahead take+1 ВСЕГДА на основной ветке,
   pageInfo на каждой странице, legacy-ветка с ранним return. Эвристики count-запросов не нужны.
3. Сравнение колонок SQL (spentUnits+units<=limitUnits) не выражается в Prisma-where —
   raw-гейты (`$executeRaw`) валидны, но отмечаются для ADR-004 (замена при PG-миграции).
4. Сигнатуры/подписи платформы эфемерны (VC) или информационны (policy) — смена dev-ключа
   безопасна; для прод-ключей действует порядок ADR-005.
