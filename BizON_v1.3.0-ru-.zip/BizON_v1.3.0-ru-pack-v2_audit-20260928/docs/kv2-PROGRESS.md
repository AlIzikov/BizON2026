# KV2 — СЧЁТЧИК ПРОГРЕССА (авто-режим, приказ владельца trace 1a0b8d4052e51465)

> **СЧЁТЧИК: ШАГ 28/28 · ФАЗА E ЗАВЕРШЕНА · KV2 ЗАКРЫТ ПОЛНОСТЬЮ (trace 1a0b917785d733c1)**
> Правило: после каждого шага эта строка обновляется. Задача считается закрытой только
> с доказательством (тест/браузер/артефакт) — §16 запрещает fake success.

## ИТОГ ФАЗЫ E (19.09.2026, финальная верификация)
- **E1 регресс**: пофайловый `bun test tests/` — **292 pass / 0 fail** (31 файл), 2 прогона подряд.
  Попутно РЕМОНТ ИНФРАСТРУКТУРЫ и восстановление утраченного при откате песочницы кода:
  - `adversarial/helpers.ts` + `tests/helpers/setup.ts`: rmSync temp-БД перенесён на выход процесса
    (SQLITE_READONLY_DBMOVED 1032 ломал весь совместный прогон — корень «78 fail»).
  - **AiTrace** — модель возвращена в schema.prisma (утрачена при откате; код trace.ts/роут traces её
    уже использовали → db.aiTrace=undefined, w9 красный). db:push аддитивный.
  - **W7 executor-волна (P0-1/P0-2) восстановлена** в governance-service: recordDirectAction,
    executeApprovedAction (re-check manual→RE_APPROVAL_REQUIRED, AiBudget→BUDGET_EXCEEDED,
    §38 нет-executor→EXECUTOR_NOT_AVAILABLE, сбой→failed+AiIncident), setAutonomy 4 режима,
    levelToMode 0..3, getAutonomy allowedModes. PolicyEngine: supervised+medium→AUTO (спека уровней 2-3).
  - **AIGateway**: GenAI-спан на каждый вызов (rate_limited/fallback/cache/ok) + честный usedProvider
    в fallback-ветках ('heuristic-local' вместо 'llm').
  - **W8**: strengthFactors/computeStrength (pure) возвращены в recommendation-strength.ts
    (контракт — spec-таблицы генератора); goldens.ts осознанно регенерированы (+REQUEST_INTRO,
    registry hash ad795f22…; 12 прежних векторов совпали байт-в-байт, specDrift=0);
    news-score bizonRelevance сентинел -1 → 0 (контракт «невычислимое = 0»).
  - **W6**: safeFetch 3xx→null (редирект не следует и не возвращается); findFiveHandshakes guard
    `> MAX_DEPTH` (5 рёбер максимум, §58 п.22); matchmaker RT-01 tier-лимит возвращён (5/час free, 429).
  - rate-limiter: getAiLimitKey + ветка 'projectMatch' (ключ молча падал в jobsMatch).
- **E2 lint/tsc**: `bun run lint` — 0; tsc 351 → **305** (все остаточные — pre-existing в чужих файлах:
  adversarial2, stale-API-роуты; в затронутых файлах — 0).
- **E3 браузерная проводка (G-UI-PERFECT)** — все golden-пути живьём, сетевые доказательства:
  - **D-01/D-02 интро-цикл**: профиль чужого → блок «ЦЕПОЧКА ДОВЕРИЯ» (2 рукопожатия) →
    «Запросить знакомство» → диалог (посредник Мария) → POST /api/intros **201** → кнопка «Запрос отправлен»;
    инбокс посредника в «Контактах» → «Иван Тестов просит представить его: Борис» → accept **200** →
    инбокс очищен; у цели: сообщение «Иван Тестов: хочу обсудить…» в «Сообщениях» + связи созданы.
    Скриншоты: specs/kv2-e3-03…09.
  - **D-03 жалобы**: «Меню публикации» → диалог 7 категорий (спам/мошен/…/другое) → POST /api/complaints
    **201** {status:'open'}; дедуп честный (одна открытая на цель; вторая цель = отдельный 201).
    specs/kv2-e3-11.
  - **D-04 вакансия юрлица**: FAB «Опубликовать вакансию» (только company/hr_agency) → настоящая форма
    → POST /api/jobs **201**. specs/kv2-e3-12/13.
  - **D-05 VC-экспорт**: Настройки → «Верифицируемые сертификаты (W3C VC)» → «Скачать JSON» →
    GET /api/me/credentials **200** (честно {"credentials":[],"count":0}). specs/kv2-e3-15.
  - **D-25 GDPR**: «Выгрузить данные» → POST /api/me/export-data **200**; «Удалить аккаунт» присутствует.
    specs/kv2-e3-16.
  - 390px: scrollWidth 390 = clientWidth, hscroll **false**; консоль ошибок **0**. specs/kv2-e3-17.
  - Чинил по ходу: **D-01 дверь была НЕ смонтирована** (PublicPersona/TrustChainBlock никем не
    использовались — «ядро без дверей» возвращалось) → TrustChainBlock экспортирован и смонтирован
    в profile-view (профиль чужого). Проверено живьём.
- **E4**: статусы ниже → DONE; worklog дополнен (Task ID KV2-PHASE-E); владелец уведомлён.

## РАСЧЁТ ШАГОВ (28 исполняемых: D-17 слит с D-14) — все DONE

### Фаза A — P0 деньги/безопасность (R2-блок)
| № | ID | Шаг | DoD-доказательство | Статус |
|---|---|---|---|---|
| 1 | D-19 | refundVar: сумма возврата = original.lumens, запрет после release | adversarial-тест печати денег BLOCKED + теорема T_D19_fixed (Rocq) | DONE |
| 2 | D-20 | adminGuard на /api/admin/* (роль admin) | чужой токен → 403 (tests/kv2-admin 8 pass) | DONE |
| 3 | D-21 | Session.token → sha256-хэш в БД (rehash-on-verify) | plaintext в БД отсутствует (tests/kv2-session) | DONE |

### Фаза B — P0 двери (UI-проводка)
| № | ID | Шаг | DoD-доказательство | Статус |
|---|---|---|---|---|
| 4 | D-01 | «Путь доверия» + «Запросить знакомство» | браузер: путь 2 рукопожатия → POST /api/intros 201 (E3) | DONE |
| 5 | D-02 | Интро-инбокс в «Контактах» | браузер: посредник видит, accept 200, сообщение у цели (E3) | DONE |
| 6 | D-03 | Диалог жалоб 7 категорий, fake-тост удалён | браузер: POST /api/complaints 201 + дедуп 409-логика (E3) | DONE |
| 7 | D-04 | FAB → форма вакансии + «Мои вакансии» | браузер: POST /api/jobs 201 (E3) | DONE |
| 8 | D-05 | VC-экспорт W3C в Настройках | браузер: GET /api/me/credentials 200 (E3) | DONE |

### Фаза C — P1 честность и заметные дыры
| № | ID | Шаг | DoD-доказательство | Статус |
|---|---|---|---|---|
| 9 | D-06 | Честные названия (эвристики вместо LSTM/GNN/BERT) | UI-строки честные; остатки — только комментарии моделей-целей | DONE |
| 10 | D-07 | Внешний ground truth CareerMatcher | tools/evals/RESULTS.md + ground-truth-career.json | DONE |
| 11 | D-08 | Web-push: честный «нет подписки» | ok:false VAPID_NOT_CONFIGURED / NO_SUBSCRIPTION (web-push-service) | DONE |
| 12 | D-09 | detectTextSync в пайплайне постов + FPR | posts/route.ts подключён; tools/evals/text-sync-fpr.ts | DONE |
| 13 | D-10 | Режимы contact/stranger по /api/me/relationship | браузер: серверный режим управляет UI (E3, D-01 блок) | DONE |
| 14 | D-11 | «Похожие возможности» (/related) | блок в проектах/вакансиях из живого API | DONE |
| 15 | D-12 | BIZCARD серверный PDF A6 | /api/me/bizcard/pdf | DONE |
| 16 | D-13 | Outbox: продюсеры + воркер | tests/kv2-outbox 5 pass (end-to-end pending→processed) | DONE |
| 17 | D-22 | topup в $transaction + sweep-компенсация | lumen-service $transaction; store sweep (tests/kv2-money) | DONE |
| 18 | D-23 | Governance: userId в PolicyEngine + права | tests/w6-governance + kv2-admin; prohibitions в боевом пути | DONE |
| 19 | D-24 | AI Co-Pilot: боевой LLM + честный provider | llm|heuristic бейдж «Автоответ без AI» | DONE |
| 20 | D-25 | GDPR-кнопки | браузер: export-data 200 (E3); delete-account/forget в UI | DONE |

### Фаза D — P2 гигиена
| № | ID | Шаг | DoD-доказательство | Статус |
|---|---|---|---|---|
| 21 | D-14(+17) | cleanup-demo-data.ts + дедуп QA-двойников | лента 21→15, идемпотентен (повтор = 0) | DONE |
| 22 | D-15 | Демо-подсказка за env-флагом | браузер: подсказки нет без NEXT_PUBLIC_BIZON_DEMO_HINT (E3) | DONE |
| 23 | D-16 | Копирайт профиля по accountType | юрлицу не предлагается день рождения (profile-view) | DONE |
| 24 | D-18 | a11y description для DialogContent | daily-brief + hr-contact-button описаны | DONE |
| 25 | D-26 | PATCH профиля: без двойной записи PII + валидации | users/[id] PATCH zod-валидации | DONE |
| 26 | D-27 | Согласие AI fail-closed + verifyChain генезис | sovereignty/gateway fail-closed; audit-log prev-окно | DONE |
| 27 | D-28 | seed без deleteMany (SEED_WIPE) + демо-флаг | scripts/seed.ts guard; токен в env | DONE |
| 28 | D-29 | Тесты PaymentService + кап на accrue | tests/kv2-payment 6 pass; кап 12×30дн | DONE |

## ДНЕВНИК (append-only)
- ШАГ 0/28 — план рассчитан, счётчик создан.
- ШАГИ 1–28 — исполнены кодом и тестами (см. worklog: KV2-D13, KV2-D14-18 и записи фаз A–D).
- ФАЗА E — восстановление среды после зависания: readonly-фикс (rmSync→process.exit), возврат модели
  AiTrace, восстановление W7 executor-волны (recordDirectAction/executeApprovedAction), W9 gateway-спаны,
  W8 strengthFactors + goldens (осознанная регенерация, specDrift=0), W6 ssrf-3xx + BFS-глубина +
  RT-01-лимит, монтаж двери D-01 (TrustChainBlock → profile-view), projectMatch-ветка лимитов.
  Регресс 292/0 ×2; lint 0; браузерная проводка всех golden-путей с сетевыми доказательствами;
  390px без hscroll; консоль чистая. KV2 ЗАКРЫТ.
