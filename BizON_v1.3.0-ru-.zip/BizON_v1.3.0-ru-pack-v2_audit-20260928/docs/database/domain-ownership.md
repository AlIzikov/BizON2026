# Domain Ownership: реестр концептов, дубликатов и trust-источников BizON

Создан: 22.09.2026 · Аудит 22-09-26 (DB-025 «дубликаты domain concepts», DB-026 «несколько trust-источников», DB-002 «User — hot aggregate») · Волна W2 (Task 29-f)
Статус: ДОКУМЕНТ-РЕЕСТР (код не меняется). Решения «удалить/read-model» требуют отдельного ADR и миграции данных — вне таймбоксов волн.
Каждая строка сверена с prisma/schema.prisma (позиции указаны).

## 1. Реестр концептов-дубликатов (DB-025)

Правило аудита: если две таблицы отвечают на один вопрос — одна становится derived/read-model либо удаляется.
Ниже — концепты аудита DB-025 и их фактическое состояние в схеме.

| Концепт | Модель в схеме (факт) | Источник истины | Кто derived / связанный | Что делать |
|---|---|---|---|---|
| Репутация-событие (сырой факт) | **ReputationEvent** (schema:771; eventType, payload JSON, weight, impactScore) | Да — сырой лог событий доверия | Питает ipScore-пересчёт и impact-потоки | Оставить (append-only факт) |
| Снимок репутации | **ReputationSnapshot** (schema:1558; ipScore, level, takenAt + breakdown projectsScore/ratingsScore/skillsScore/activityScore/evidenceCoverage:1568-1574) | Историческая серия — да; «текущее состояние» — нет (текущее = User.ipScore) | Derived от ReputationEvent+подтверждений; пишут cron-snapshots.js:173, reputation/snapshots route:63, seed | Оставить как read-model истории (takenAt есть; algorithmVersion на breakdown — добавить при следующей правке схемы) |
| Текущий рейтинг | **User.ipScore / User.level** (schema:33-34) | Да для «сейчас» (пересчёт ReputationService.recompute, формула ТЗ 3.3.1: reputation-service.ts:15-48) | Derived; снапшоты — история | Оставить (материализованный балл + инвариант «пересчёт детерминирован») |
| Индекс доверия (профессиональный) | **TrustIndex** (schema:2185; score, dimension, factors JSON, computedAt) | Нет — derived-индекс | Пишет только professional-trust-service.ts:407-425 (upsert, dimension='professional', factors.formulaVersion='v1', version-check при чтении:478-479) | Оставить как derived/read-model с обязательными source/formulaVersion/computedAt (соответствие DB-026 уже частично в factors) |
| Рекомендация человека | **Recommendation** (schema:2286; author/subject, relationshipType, evidenceIds JSON — provenance:2302, expiresAt, COI:2305, @@unique(author,subject,project):2311) | Да — самостоятельный факт-документ | Не derived; сам является trust-входом | Оставить |
| «UserRecommendation» | **В схеме ОТСУТСТВУЕТ** (rg "UserRecommendation" prisma/schema.prisma → 0) | — | Аудит перечислял его по исторической базе v5; функцию выполняют Recommendation + ProjectRecommendation (schema:2841) | НЕ создавать; имя из аудита считать алиасом Recommendation. Если где-то всплывёт «user recommendation»-фича — расширять Recommendation, а не плодить таблицу |
| Профессиональное доказательство | **ProfessionalEvidence** (schema:1317; type publication/project/review/certification/outcome, verificationLevel claimed→verified→project_verified→expert_verified:1329-1330, confidence, STAR-поля) | Да — первичный evidence-факт | Якорь для TrustIndex-факторов и капитала | Оставить (центральный источник) |
| Утверждение о себе | **Claim** (schema:1497; type skill/experience/achievement, status pending/verified/rejected) | Да — факт заявления пользователя | Verified-состояние — derived от ClaimVerification/Evidence | Оставить; в derived-индексы входят только верифицированные |
| Верификация утверждения | **ClaimVerification** (schema:1519; verdict confirm/refute/neutral, @@unique(claimId,verifierId):1530) | Да — факт вердикта верификатора | Derived от Claim — нет; самостоятельный факт | Оставить |
| Подтверждение проекта заказчиком | **ProjectConfirmation** (schema:2261; clientCompanyId, status approve-семантика, approvedFields/rejectedFields, immutable decision record:2258-2259) | Да — уникальный источник «заказчик подтвердил» | Не дублируется ничем (SkillConfirmation — коллега по навыку, schema:634 — другой контур) | Оставить |
| Отзыв по проекту | **ProjectReview** (schema:2646; wouldWorkAgain, scoreInternal НЕ публикуется §3.3:2653, verifiedOnly, @@unique(project,author,subject):2661) | Да | Внутренний сигнал для trust | Оставить |
| Отзыв о компании | **CompanyReview** (schema:1012; rating 1-5, verifiedEmployee, evidenceType-веса project/client/subcontractor=1.0, employee=0.8, contact=0.3:1022-1026) | Да | Взвешенный рейтинг — derived от этих строк | Оставить; веса — часть алгоритма, версия при изменении |
| Professional intent | **ProfessionalIntent** (schema:2026; explicit/inferred, isActive) | Да (для намерений) | User.openTo/hobbies CSV — legacy-дубликат (DB-024, отдельная миграция) | Источник истины — ProfessionalIntent (зафиксировано в матрице) |

Итог: «двух таблиц на один вопрос» в текущей схеме нет в жёсткой форме; пересечения —
ReputationSnapshot↔User.ipScore (история↔текущее) и TrustIndex↔(Evidence-совокупность)
(индекс↔источники). Оба пересечения легальны при дисциплине «derived помечен и версионирован» (§3).

## 2. User как hot aggregate (DB-002)

Факт по схеме: model User (schema:15-275) содержит **112 relation-полей**: 106 списковых
back-relations и 6 единичных (company:41, referredBy:118, capital:132, recruiterProfile:151,
trustIndex:159, bizcard:261). Это подтверждает «hot aggregate» аудита (upload/аудит 22-09-26.txt:807-880).
Практический риск — User update/row-lock тормозит несвязанные фичи; риск растёт на PostgreSQL
при транзакциях вокруг User (см. ADR-004).

Разделение по bounded contexts (список аудита дословно; отношения User посчитаны):

| Bounded context | Связи User (факт схемы) | Примечание |
|---|---|---|
| Identity | passwordHash, twoFactorSecret/Enabled, backupCodes, passportToken, sessions, verificationTokens, referralsMade/referredBy | auth-ядро; User = identity root |
| Profile | title, bio*, location*, avatarUrl, birthday, hobbies, bizcard, BizcardShare, careerEntries, resumes, careerCompasses, narratives, notificationSettings, preferences | PII-контур C1 |
| Professional Graph | connectionsFrom/To, skill-контур (skills, confirmations), inquiriesSent/Received/About, mentorshipsAsMentor/Mentee | связи и подтверждения |
| Projects | ownedProjects, memberships, lotsPublished/lotAssignments/lotResponses, milestoneComments, projectApplications, projectComments, savedProjects, projectViews/Shares/Recos, ownedLots, reportsFiled | |
| Trust-Evidence | professionalEvidences, claims, claimVerifications, reputationEvents, reputationSnapshots, trustIndex, capital, actionEvents, culturalSignals | см. §3 |
| Jobs | jobApplications, jobViewLogs, managedJobs, searchPreferences, savedJobs, savedFilters, placementsAsHrAgency/Candidate, hrContactsInitiated/Received, recruiterProfile, hrClients | |
| Company-HR | company, employments, followedCompanies, companyReviews | |
| Social | posts, postLikes, postComments, postPollVotes, postAccessGrants, savedPosts, savedAds, adImpressions, community-контур (ownedCommunities, memberships, communityPosts), events (organizedEvents, eventParticipations), newsSharesSent/Received | |
| Messaging | conversationsFrom/To, messages | |
| AI | aiInsights, coachQuestions, coachInsights, ignoredTopics, professionalIntents, hypotheses | |
| Billing/Lumens | lumenTransactions, lumenBalance/Rubles/FractionMinor (schema:217-227), subscriptions, cashierOperations, storeItems, storeBookingsBought/Sold | деньги — изолированный writer LumenService (FIX-06) |
| Governance | complaintsFiled, prohibitions (UserProhibition), daoProposals/daoVotes, nftSkills | |
| Notifications | notifications, pushSubscriptions, birthdayPlans, emailNotificationsEnabled, dndEnabled | |

Правила (зафиксировано, исполнение — эволюционно):
1. Relations НЕ удаляем (требование аудита) — контексты фиксируются для проектирования нового кода:
   писатель у каждой подсистемы — свой сервис (intro-service, LumenService, audit-log-vault…), прямой
   `prisma.user.update` из чужого контекста не добавлять.
2. User = identity root: новые «состояния подсистем» — в собственных таблицах, а не в колонках User
   (анти-пример по аудиту: lumen-состояние в User — уже закрыто minor-units; subscriptionTier —
   дубль Subscription, задокументирован).
3. Транзакции НЕ оборачивать несколько подсистем вокруг одной строки User без нужды — hot-row риск
   (усилится row-level блокировками PG).

## 3. Trust-источники и derived-индексы (DB-026)

Правило BizON (аудит, upload/аудит 22-09-26.txt:1656-1663): источник истины доверия —

**Evidence + confirmed actions + relationship provenance.**

Конкретно в схеме: ProfessionalEvidence (verificationLevel) + ClaimVerification + ProjectConfirmation
(заказчик) + SkillConfirmation (коллега) + Review-контуры (ProjectReview/CompanyReview с
evidenceType-весами) + Recommendation с relationshipType/evidenceIds (provenance, schema:2301-2305).
Действия без evidence (клики, активность) — НЕ trust, а внутренние сигналы (ReputationEvent
impactScore — внутренний; TrustStateService: Trust ≠ Currency, nonTransferable — trust-state-service.ts:1-19).

Требование к любому derived-индексу доверия (TrustIndex, ReputationSnapshot, рейтинги, AI-выводы):
поля **source / version / calculatedAt / algorithmVersion** обязательны, чтобы ответить «почему
вчера A, а сегодня B» и пересчитать при смене формулы.

Фактическое соответствие:
- **TrustIndex**: computedAt (schema:2191) + factors.formulaVersion='v1' (professional-trust-service.ts:7,231,401);
  при чтении индекс с чужой версией формулы отбрасывается (строка 478-479) — паттерн «версия в payload»
  уже работает. Чего не хватает: явного `source`-списка и `algorithmVersion` как колонки (внутри factors
  — ок, но контракт должен быть единым).
- **ReputationSnapshot**: takenAt (schema:1563) есть; algorithmVersion на breakdown-полях (1568-1574)
  отсутствует — формула живёт в коде (cron-snapshots.js, реплика ReputationService.recompute).
  Требуемое действие: добавить algorithmVersion при следующей правке схемы (аддитивно).
- **AiInsight**: algorithmVersion + generatedAt (schema:1416-1418, DB-027 закрыт 29-d) — эталонный образец.
- **User.ipScore**: материализованный балл — обязан пересчитываться из источников детерминированной
  формулой (reputation-service.ts:15-48); формула не версионирована — туда же, вместе со Snapshot.

Запрет DB-026: нельзя одновременно назначить «TrustIndex = произвольный score», «Recommendation = trust»,
«ReputationSnapshot = trust» без reconciliation-правила. Правило reconciliation: приоритет источников —
(1) верифицированные Evidence/Confirmations, (2) подтверждённые действия (immutable decision records),
(3) рекомендации с provenance; любой derived-индекс публикует свою формулу-версию и может быть
пересчитан из (1)-(3).

## Отклонённые альтернативы

- **«Слить ReputationEvent+Snapshot+TrustIndex в одну таблицу метрик»** — теряется различие
  факт/история/индекс; слияние ломает cron-историю и пересчёты. Отклонено; вместо этого — дисциплина
  версионирования derived.
- **«Удалить 'дубликат' UserRecommendation из схемы»** — удалять нечего: модели в схеме нет (проверено) —
  пункт аудита относится к исторической базе v5; зафиксировано как алиас.
- **«Рефакторить User на 13 агрегатов сейчас»** — требование аудита обратное («Не удалять relations»);
  hot-aggregate решается дисциплиной писателей и контекстов, а не разрушительной миграцией. Отклонено
  как несвоевременное (риск > выгоды в pilot).

## Честный статус

- Реестр соответствует схеме на 22.09.2026 (позиции моделей проверены).
- algorithmVersion на ReputationSnapshot/User.ipScore-формуле — НЕ исполнено (требуется аддитивная
  правка схемы + кода, отдельная задача; занесено в трекинг).
- `source`-поле на TrustIndex — НЕ исполнено (версия формулы внутри factors уже есть).
- Всё «что делать: удалить/read-model» — только через отдельный ADR с миграцией и adversarial-приёмкой;
  в этой волне код и схема не менялись.
