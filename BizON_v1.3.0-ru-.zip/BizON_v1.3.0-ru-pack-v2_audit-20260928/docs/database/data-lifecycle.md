# Data Lifecycle: retention, удаление, анонимизация, GDPR/152-ФЗ

Создан: 22.09.2026 · Аудит 22-09-26 (DB-010 «soft-delete единообразно», DB-011 «GDPR-удаление ≠ удаление User», DB-007 «emailHash nullable semantics»; append-only: DB-016/закон) · Волна W2 (Task 29-f)
Статус: ДОКУМЕНТ-РЕЕСТР (код/схема не менялись). Все утверждения сверены с prisma/schema.prisma и кодом; расхождения кода со схемой указаны честно.

## 1. Принципы

1. **Soft delete** — где есть, помечается `deletedAt`; читатели обязаны фильтровать. В схеме `deletedAt`
   есть ТОЛЬКО на четырёх моделях: **User** (schema:191, комментарий 187-190: 30 дней на восстановление,
   затем cron физически удаляет), **Project** (schema:711), **ProjectComment** (schema:2814),
   **Lot** (schema:2953). Требование DB-010 «soft-delete единообразно на всех user-owned моделях»
   в схеме НЕ исполнено и сознательно не дублируется вслепую: у части моделей soft-удаление выражено
   статусом (см. §2), у остальных — hard delete каскадом.
2. **Hard delete** — физическое удаление строки; связи определяют `onDelete` схемы
   (147 × `Cascade`, 11 × `SetNull`; Prisma default для required-FK без onDelete — **Restrict**).
3. **Append-only** — журналы денег и аудита не удаляются и не изменяются никогда (см. §3).
4. **Anonymization** — альтернатива удалению там, где FK-целостность графа важнее стирания строки
   (реализовано для User: forget-me, §4).

## 2. Реестр core-сущностей

| Сущность (schema:line) | Soft delete | Hard delete / каскад | Anonymization | Retention / примечание |
|---|---|---|---|---|
| **User** (15) | `deletedAt` :191; ставится POST /api/me/delete-account (route:46-49), 30 дней на восстановление, доступ блокируется auth | `prisma.user.delete` — scripts/cron-cleanup-deleted.js:114 (порог 30 дней, батч 50). ⚠️ Каскад НЕ полный — см. §5.1 | forget-me (§4) | ПД — по закону «цель достигнута»; аудит-факты о пользователе остаются (§3) |
| **Project** (649) | `deletedAt` :711 (мягкое удаление; «поле потеряно откатом, код жив» — design-16-audit) | owner → Cascade :685; clientCompany → SetNull :688 | Нет | Удаление юзера сносит его проекты вместе с members/confirmations/reviews — см. §5.1 |
| **ProfessionalEvidence** (1317) | Статусный: `status active\|hidden\|deleted` :1333 | user → Cascade :1338 | Нет | Soft-delete через статус, не deletedAt — фильтрация обязательна в читателях |
| **Conversation / Message** (1172 / 1188) | Нет | оба участника → Cascade :1179-1180; Message: cascade по conversation :1199 и author :1200 | Нет | Сообщения УДАЛЯЮТСЯ при hard delete любого участника (целиком диалог при удалении обоих) — продуктовое следствие для владельца |
| **Post** (478) | Нет (модерация через isHidden :509) | author → Cascade :513; likes/comments/savedBy — дочерние | Нет | |
| **LumenTransaction** (354) | Нет (append-only) | ⚠️ user → **Cascade** :370 — ledger пользователя сносится вместе с User (§5.2) | Нет | Идемпотентность: idempotencyKey @unique :367, refundOf @unique :363 |
| **AuditLog** (1345) | Нет | **Не удаляется никогда** (§3); actorId без FK :1347 — запись переживает удаление User | Не требуется (запись без PII — политика CRYPTO-013) | 152-ФЗ ст.19 / ТЗ 3.7: хранение 2 года (src/lib/data-vault/audit-log.ts:3); append-only подтверждено: `auditLog.update/delete*` в src — 0 совпадений |
| **AiTrace** (2481) | Нет | Нет каскада: `userId String?` **без FK** :2489 — строки переживают удаление User | Требуется (содержит атрибуты запросов, attributesJson :2501) | Retention не задан — см. §5.3 |
| **Session** (906) | Нет (TTL expiresAt :910) | user → Cascade :913; deleteMany при delete-account (route:54) и forget-me (route:96) | Не требуется | В БД только sha256 токена (src/lib/security/session-token.ts:8, 21-23) — сырой токен не хранится |
| CashierOperation (2788) | Нет | ⚠️ user → Cascade :2803 (журнал платежей сносится с User — §5.2) | Нет | idempotencyKey @unique :2795 |

Прочие статусные soft-delete (вне deletedAt-канона): Recommendation `active|revoked` (:2296),
ProfessionalEvidence `active|hidden|deleted` (:1333), AiInsight `isSeen`, Complaint
`open|resolved|dismissed` (:328) — единство механизма (DB-010) не достигнуто; зафиксировано как долг.

## 3. Что НЕ удаляется никогда (append-only, DB-016/закон)

- **AuditLog** — единственный доказуемый след обработки ПД (152-ФЗ ст.19): записи создаются
  (audit-log.ts; forget-me:104-120, cron-cleanup:90-106), изменения/удаления в коде отсутствуют
  (rg `auditLog.(delete|update|upsert|deleteMany)` → 0). Неизменяемость подкреплена hash-chain
  (`chainHash` :1354; legacy-формула + v2-канонический JSON, data-vault/audit-log.ts:22-28).
- **LumenTransaction** — бухгалтерский ledger (DB-004: balance = Σ(ledger)); append-only по смыслу,
  ИД-ссылки (idempotencyKey/refundOf) не переживают удаление владельца — см. конфликт §5.2.
- **CashierOperation** — журнал ответов «оплачено/нет» платёжных портов.
- Внутреннее правило: эти таблицы не имеют ни одного delete/update вызова в src; Adversarial-тест
  «PUT/DELETE на AuditLog отсутствует» (DB-016) — в наборе 29-a/W1.

## 4. GDPR/152-ФЗ: удаление User — фактическая механика

Два контура (право на удаление / право на забвение):

1. **POST /api/me/delete-account** (soft): `deletedAt=now` (route:46-49), сессии инвалидируются
   (route:54), AuditLog `account_soft_delete` (route:61-75). emailHash и PII ОСТАЮТСЯ 30 дней
   (восстановление) — следствие: email остаётся занятым (unique по всем строкам, §6).
2. **POST /api/me/forget-me** (немедленное): обнуляет все PII-поля — email, bio, location, phone,
   title, avatarUrl, birthday, hobbies, newsSources + все *Encrypted + twoFactorSecret
   (route:59-92), `emailHash=null` (route:77-79), name → «Удалённый пользователь», passwordHash →
   мусор (вход невозможен), сессии deleteMany (route:96), AuditLog `right_to_be_forgotten`
   (route:104-120), `deletedAt=now`.
3. **scripts/cron-cleanup-deleted.js** — физическое удаление: пользователи с `deletedAt < now-30д`
   (cron-cleanup-deleted.js:62-73), AuditLog ДО удаления (строки 90-106), затем `prisma.user.delete`
   (:114). Комментарий скрипта утверждает «каскад сделает остальное» — по схеме это НЕ совсем так (§5.1).

## 5. Честные расхождения и риски (проверено по схеме)

### 5.1 Hard delete User блокируется связями без onDelete (P2003)

FK на User с required-связью и БЕЗ `onDelete` → Prisma default **Restrict** → `prisma.user.delete`
упадёт с P2003 при наличии хотя бы одной строки. Полный список (проверен по всей схеме — 7 FK-связей
в 6 моделях):
- PublicationAuthor — schema:1957
- Recruiter — schema:1990
- ProfessionalIntent — schema:2037
- Mentorship (mentor) — schema:2102
- Mentorship (mentee) — schema:2103
- Subscription — schema:2130
- AdPressure — schema:2175

То есть cron-cleanup-deleted.js:114 для «обычного» активного пользователя (с подпиской/интентом/
менторством/рекрутёрским профилем) завершится ошибкой `status:'error'` (обработка есть, :118-121),
но удаление не произойдёт — GDPR-обязательство не выполняется. Требуемое: миграция схемы —
`onDelete: Cascade` (или явная политика) на перечисленных связях + интеграционный тест
«User с такими связями удаляется».

### 5.2 Конфликт: деньги-журнал удаляется вместе с User

LumenTransaction.user → **Cascade** (:370), CashierOperation.user → **Cascade** (:2803): физическое
удаление User сносит его ledger. Для Privacy — корректно, для бухгалтерии/споров — нет (журнал
платежей обязан переживать аккаунт). Требуется решение владельца: (а) оставить Cascade (деньги
пилота незначимы) или (б) перевести на `onDelete: Restrict` + анонимизацию владельца (ledger без PII,
userId как псевдоним). До решения — жёсткий delete User означает и стирание денежных доказательств.

### 5.3 Где персональные данные МОГУТ остаться после удаления User (честный список)

| Место | Почему остаётся | ПД? | Требуемое действие |
|---|---|---|---|
| **AiTrace** (:2481) | `userId` без FK; записи не каскадятся | Да: attributesJson (:2501) может нести промпты/контекст запросов пользователя | Anonymization job: трейс с userId удалённого → обезличить/удалить; retention-политика |
| **ResearchResult** (:2516) | `userId` без FK (:2518) | Да: answers — ответы на тесты/опросники (:2523), consent :2526 | Включить в anonymization job |
| **AuditLog** (:1345) | actorId без FK; append-only (§3) | По политике — нет (без PII; CRYPTO-013 gate добавит enforcement) | Ничего; retention 2 года → затем ротация/архив |
| **ReputationEvent.payload** (:775) | user → Cascade :780 — удаляется ВМЕСТЕ с User (ок) | — | Ничего |
| **TrainingExample** (:306) | Без FK на User СОВЕРШЕННО (schema:305 «Без FK на User сознательно», features без PII) | Нет by design | Контроль при расширении фичевого пайплайна |
| In-process KV-кэши (rate-limiter, ai-cache, tempTokenStore — kv.ts:219 и инстансы модулей) | Живут в памяти инстанса с TTL | Возможны userId-ключи | TTL-очистка достаточна; при Redis-переезде — префикс + TTL (ADR-004) |
| Серверные логи (console) | 29-b: console-пути не содержат credential/PII-значений; forget-me/delete-account логируют Error без значений | Нет | Держать redact-sensitive (CRYPTO-004) обязательным для новых логов |
| Сообщения/посты других участников | Message.author → Cascade :1200 — удаляются с автором; НО переписка двух живых участников исчезает целиком | Продуктовый вопрос, не PII-утечка | Решение владельца: заменять автора на «Удалённый пользователь» вместо Cascade (как делает forget-me с именем) |

Итог DB-011: «удалён User» ≠ «удалены ПД». Автоматически переживают User: AiTrace, ResearchResult,
AuditLog (без ПД), плюс KV-кэши до TTL. Требуется **anonymization job** (флаг/скрипт: по событию
hard delete пройтись по AiTrace/ResearchResult удалённого userId) — в схеме и коде его пока нет.

## 6. emailHash NULL — семантика (DB-007)

- `emailHash String? @unique` (schema:21); NULL **не участвует** в unique-поиске — несколько
  пользователей с emailHash=null существуют одновременно: тест tests/db-invariants.test.ts:57-88
  («два User с emailHash=null валидны одновременно», NULL — не search-key).
- Значение NULL означает: **legacy** (аккаунты до C1-миграции хэширования) либо **removed**
  (forget-me обнуляет emailHash: route:77-79). Поиск живых пользователей по email всегда идёт
  через равенство хэша + `deletedAt: null` (scripts/repair-canonical-accounts.ts:70,
  scripts/reset-demo-passwords.ts:80).
- Логин по email при emailHash=null невозможен (нечем адресовать строку) — это и есть семантика
  «removed/legacy»: строка жива для FK-целостности графа, но не адресуется.
- PostgreSQL-примечание (DB-007/ADR-004): на PG несколько NULL в @unique допустимы (как в SQLite);
  «уникальность только активных» требует partial unique index `WHERE deletedAt IS NULL`
  (upload/аудит 22-09-26.txt:1044-1052) — отдельной миграцией при PG-переходе; до него email
  soft-deleted-аккаунта остаётся занятым до purge (§4, п.1).

## 7. Требуемые работы (трекинг, код не менялся в этой волне)

1. Миграция onDelete для 7 Restrict-связей (§5.1) + тест hard-delete-со-связями.
2. Решение владельца по ledger-каскаду (§5.2) — до PG-перехода (ADR-004 этап data migration).
3. Anonymization job для AiTrace/ResearchResult (§5.3) + retention-политика AiTrace.
4. Единообразие soft-delete (DB-010): либо extended deletedAt-канон, либо фиксация статусного
   soft-delete как документированного стандарта для статусных моделей.
5. Search/cache/AI-memory removal при удалении — покрыть anonymization job'ом после Redis/поискового
   индекса (сейчас поиск — прямые запросы к БД, отдельного индекса нет).

## Отклонённые альтернативы

- **«Добавить deletedAt на все ~60 user-owned модели»** — механическое единообразие ломает append-only
  журналы и статусные модели, усложняет каждый читатель фильтром; DB-010 принят как «политика по
  классам сущностей» (см. §2/§7.4), а не как дублирование колонки.
- **«Анонимизировать вместо удаления везде (никого не удалять физически)»** — конфликтует с
  152-ФЗ (право на удаление) и раздувает БД; оставлено точечно только для FK-целостности графа
  (forget-me + запись User до purge).
- **«Удалять User сразу hard без 30-дневного окна»** — убирает восстановление после ошибок/угонов;
  окно уже реализовано (delete-account) и оставлено.

## Честный статус

- Документ отражает схему и код на 22.09.2026; все file:line проверены.
- §5.1 (Restrict-блокировка hard delete) — реальный дефект GDPR-контура: до миграции onDelete
  cron-cleanup не удаляет пользователей с Subscription/ProfessionalIntent/Mentorship/Recruiter/
  PublicationAuthor/AdPressure.
- §5.2 (каскад денег-журнала) — противоречие append-only, требует решения владельца.
- Anonymization job, retention AiTrace/ResearchResult, унификация soft-delete — НЕ исполнены;
  внесены в трекинг §7. Решений «тихо принять и забыть» нет: всё перечислено явно.
