
## [1.1.0-pilot-ready+fix] — 2026-09-15

### Hotfix среды песочницы (пост-релиз, найдено независимой ре-верификацией)

- FIXED (P0, env): платформа песочницы пересоздаёт `.env` при каждом boot — запиненный в `.env` ключ `BIZON_ENCRYPTION_KEY` терялся, эфемерный per-process fallback ломал `emailHash`/`emailEncrypted` всех пользователей после рестарта. Теперь dev-fallback — **стабильный keyfile** `.bizon-encryption-key` (0600, вне git/архивов); production по-прежнему fail-secure без env-ключа.
- FIXED: repair-email-hashes.ts восстановил 11 email-записей из бэкапа plaintext'ов (lookup 11/11) и честно очистил 2 мёртвых (не расшифровываемых) артефакта-теста; plaintext email = 0.
- FIXED (P0, env): CSP frame-ancestors dev-политики не пускал iframe превью-панели (`*.space-z.ai`) → ERR_BLOCKED_BY_RESPONSE; allowlist песочницы включён в dev-политику в коде (production не тронут, DEF-29/W1.11 сохранён).
- ADDED: тест 2a (w1) — стабильность dev-ключа между «рестартами»; runtime E2E: регистрация через API → lookup/decrypt из независимого процесса → plaintext=null.

## [1.1.0-pilot-ready] — 2026-09-14

### Внедрение внешнего аудита (волны W1–W5), независимая верификация каждого гейта

### Security (W1)
- FIXED (P0): soft-deleted пользователь мог аутентифицироваться — deletedAt проверяется во всех 4 путях сессий (getUserFromRequest, loginUser, AuthService.login, AuthService.getByToken, AuthVault.verifySession)
- FIXED (P0): plaintext email 0/32 (миграция + запрет новых plaintext-записей в 2 регистрах); пин стабильного BIZON_ENCRYPTION_KEY (корень проблемы эфемерных ключей)
- ADDED: rate limit на 2FA-confirm (брутфорс TOTP) и люмены-кошелёк; SSRF: egress kill-switch + double DNS resolve; CSP разделён по средам (production = 'self')

### Truth (W1)
- FIXED (P0): companyFit больше не заглушка 88 — null при отсутствии данных; UI показывает «—»
- FIXED (P0): interested-companies — реальные activeJobsCount вместо random; честный заголовок
- FIXED (P0): завершение проекта ≠ подтверждение заказчиком (auto-confirmed удалён)
- NFT-минт: честно отключён до реального блокчейн-контура

### Evidence & Recommendation (W2)
- ADDED: Project Evidence Engine — подтверждение проекта заказчиком по полям (анти-коллюзия: только сотрудники компании-заказчика; публична только approvedFields; decision immutable)
- ADDED: Recommendation Engine — структурированные рекомендации с основанием, скрытый мультипликативный strength, evidence-связь с подтверждёнными проектами, revoke

### Governance (W3)
- ADDED: Human–AI Governance Layer — 9 моделей, Action Registry (12 действий), Policy Engine (политика сильнее промпта), Decision Inbox (не исполнитель), AiBudget (второй предохранитель к люменам), градуированный kill-switch (env + персистентная политика, без участия AI), пауза агентов; режимы на старте: manual/collaborative только
- ADDED: универсальный AI-аудит — каждый вызов AIGateway пишет AiAuditLog

### Research & Intent & News (W4)
- ADDED: ResearchResult — опросники как AI-сигналы (consent обязателен, version, expiry, серверный score)
- ADDED: UnifiedIntentService — единый снимок намерения (intents + research + profile + поведение) для всех подсистем
- ADDED: BizON News Score 20/20/20/15/15/10 — объяснимое ранжирование ленты новостей

### UX (W2/W5)
- FIXED: поиск ведёт к сущностям (не на «/»); реальный UI 2FA (enable/confirm/disable); выдуманные «+~14 к Надёжности» удалены; sponsor-переход реален (targetUrl + noopener); кнопки-обещания «Скоро» → disabled с объяснением

### QA
- ADDED: 43 bun-теста на изолированных копиях БД (security/truth/formulas/evidence/governance/research/news)
- ADDED: check-audit-catalog.mjs — DOC-MISMATCH гейт (89 моделей / 251 роут в снапшоте)

# BizON — changelog

Полная история: `docs/handover/08-version-history.md` · Журнал работ: `worklog.md`

## 1.0.0-rc.1 «Audit Snapshot» (2026-09-11)
- Заморозка кода для внешнего аудита; пакет документации `docs/handover/` (описание всех функций, API, модели данных, AI-контура, реестр проблем, план R1–R6).
- Архив аудита: `releases/BizON_v1.0.0-rc.1_audit-20260911.zip`.
- Создан `.env.example`; пакет переименован `nextjs_tailwind_shadcn_ts` → `bizon`, версия зафиксирована `1.0.0-rc.1`.

## 10.09.2026 — волны качества
- FIX-волна FIX-01…FIX-09: 4×P0 безопасности, деньги в транзакциях (CAS/refund @unique), withRoute ×21, дизайн-контраст, email-верификация + ToS + `/legal`, kill-switch дивидендов. Балл аудита 5,4 → 7,4 (`docs/AFTER-AUDIT.md`).
- Волны A (5/5), B (6/6), C (5/5), P0 (2/2), быстрые победы A–I (5/5) — хвосты STUBS-аудита, AI Co-Pilot на реальном LLM.

## Волны 1–11 (2026-09)
Каркас, «только реальные данные», Professional Trust/IP-score, вакансии с бустами, события, мессенджер, онбординг, explore-квиз, подразделы, люмены, NewsShare «Рекомендовано …» (`docs/CHECKPOINT.md`).
