#!/usr/bin/env python3
# =============================================================================
# BizON — R2 (Task 41): MATCHMAKER_EVAL — оффлайн-оценка весов резонанс-матча.
#
# Директива R2: «MATCHMAKER_EVAL (Python-скрипт оффлайн-калибровки весов)».
# Канон директивы §2: калибровка — ТОЛЬКО после 500+ наймов, через
# MATCHMAKER_EVAL + DAO-голосование. Скрипт готовит пайплайн:
#
#   1. Синтетическая «история наймов» (стенд для методологии): пары
#      «кандидат × вакансия» с факторами (skill/value/culture/growth/warmBonus)
#      и исходом найма. В R2+ вместо синтетики — экспорт ResonanceMatch
#      (GET /api/resonance/companies?export=1 — план R3) + реальный флаг найма.
#   2. Оценка качества ТЕКУЩИХ весов (0.35/0.30/0.20/0.15): AUC/C-index
#      «score → успешный найм», Sensitivity по факторам.
#   3. Предложение-кандидаты весов (только ОТЧЁТ: изменение весов в formula.ts
#      — отдельный PR + DAO-голосование, канон).
#
# Запуск: python3 simulations/matchmaker_eval.py
# =============================================================================

import numpy as np

rng = np.random.default_rng(41)  # seed = номер задачи

WEIGHTS_CURRENT = {"skill": 0.35, "value": 0.30, "culture": 0.20, "growth": 0.15}
N_HIRES = 600  # стенд: «500+ наймов» из директивы


def resonance_score(factors: dict, weights: dict) -> float:
    """Взвешенное геометрическое среднее (та же формула, что formula.ts)."""
    s = 1.0
    for k, w in weights.items():
        s *= max(factors[k], 1e-9) ** w
    return s


def simulate_history(n: int):
    """Синтетическая история: факторы пары → исход найма.
    Истинная модель исхода: найм вероятнее при высоких skill и culture
    (hidden truth), плюс шум. Это НЕ прод — стенд для проверки, что eval
    умеет отличать хорошие веса от плохих."""
    rows = []
    for _ in range(n):
        factors = {
            "skill": rng.beta(2, 2),
            "value": rng.beta(2, 2),
            "culture": rng.beta(2, 2),
            "growth": rng.beta(2, 2),
        }
        warm = rng.random() < 0.25
        # скрытая истина: найм ≈ логистика от skill и culture (вес 0.35/0.20
        # в текущей формуле — разумное приближение; eval должен это увидеть)
        logit = 3.5 * factors["skill"] + 2.0 * factors["culture"] + 0.8 * factors["value"] + 0.4 * factors["growth"] - 3.0
        p_hire = 1 / (1 + np.exp(-logit))
        hired = rng.random() < p_hire
        rows.append((factors, warm, hired))
    return rows


def c_index(scores: np.ndarray, outcomes: np.ndarray) -> float:
    """AUC (Mann-Whitney C-index): доля пар «успешный > неуспешный» по score."""
    pos = scores[outcomes == 1]
    neg = scores[outcomes == 0]
    if len(pos) == 0 or len(neg) == 0:
        return 0.5
    wins = 0.0
    for p in pos:
        wins += np.sum(p > neg) + 0.5 * np.sum(p == neg)
    return wins / (len(pos) * len(neg))


def evaluate(weights: dict, history) -> float:
    scores = np.array([resonance_score(f, weights) * (1.1 if warm else 1.0) for f, warm, _ in history])
    outcomes = np.array([1 if h else 0 for _, _, h in history])
    return c_index(scores, outcomes)


def main():
    print("=" * 72)
    print("BizON R2 — MATCHMAKER_EVAL: оффлайн-оценка весов резонанс-матча")
    print("=" * 72)

    history = simulate_history(N_HIRES)
    hires = sum(1 for _, _, h in history if h)
    print(f"\n[1] История: {N_HIRES} пар, наймов {hires} ({hires / N_HIRES:.0%}) "
          f"(синтетический стенд; реальные данные — экспорт ResonanceMatch в R3)")

    auc_current = evaluate(WEIGHTS_CURRENT, history)
    print(f"\n[2] Текущие веса {WEIGHTS_CURRENT}:")
    print(f"    AUC (score → найм) = {auc_current:.3f}")

    print("\n[3] Sensitivity: подмешиваем альтернативные веса (ТОЛЬКО ОТЧЁТ —")
    print("    изменение formula.ts = отдельный PR + DAO-голосование после 500+ наймов):")
    alternatives = {
        "равномерные 0.25×4": {"skill": 0.25, "value": 0.25, "culture": 0.25, "growth": 0.25},
        "skill-центричные 0.6": {"skill": 0.6, "value": 0.15, "culture": 0.15, "growth": 0.10},
        "culture-центричные 0.5": {"skill": 0.2, "value": 0.15, "culture": 0.5, "growth": 0.15},
        "без value": {"skill": 0.42, "value": 0.0, "culture": 0.34, "growth": 0.24},
    }
    best_key, best_auc = "текущие (0.35/0.30/0.20/0.15)", auc_current
    for name, w in alternatives.items():
        auc = evaluate(w, history)
        marker = ""
        if auc > best_auc:
            best_auc, best_key = auc, name
            marker = "  ← выше текущих"
        print(f"    {name}: AUC = {auc:.3f}{marker}")

    print("\n[4] Вердикт eval:")
    if auc_current >= 0.65:
        print(f"    Текущие веса разделяют исходы хорошо (AUC {auc_current:.3f}) — менять оснований нет.")
    else:
        print(f"    AUC {auc_current:.3f} < 0.65: кандидат на ревизию — {best_key} (AUC {best_auc:.3f}).")
        print("    Действие: DAO-предложение после набора 500+ РЕАЛЬНЫХ наймов (не сейчас).")
    print("\nПайплайн готов: в R3 подключается экспорт реальных ResonanceMatch вместо синтетики.")


if __name__ == "__main__":
    main()
