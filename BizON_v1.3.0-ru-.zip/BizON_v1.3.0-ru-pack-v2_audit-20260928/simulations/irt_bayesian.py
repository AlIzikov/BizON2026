#!/usr/bin/env python3
# =============================================================================
# BizON — R2 (Task 41): IRT Bayesian (MCMC) — simulations/irt_bayesian.py
#
# Директива R2: «IRT Bayesian (MCMC) в simulations/irt_bayesian.py».
# Зачем: EM (irt_calibration.py) даёт точечные оценки a/b; байесовский MCMC
# даёт ПОЛНОЕ апостериорное распределение — честные интервалы неопределённости
# калибровок (канон «INSUFFICIENT_DATA вместо выдумки»: неуверенная калибровка
# обязана выглядеть неуверенной).
#
# Реализация: Metropolis-within-Gibbs по (a_j, b_j) каждого item, θ интегрируется
# квадрапунктурами (marginal MCMC, без сэмплирования θ респондентов — быстрее и
# устойчивее для 40 items). Сравнение с EM на тех же данных.
#
# Запуск: python3 simulations/irt_bayesian.py
# =============================================================================

import numpy as np

rng = np.random.default_rng(41)

TRAITS = ["autonomy", "structure", "growth", "stability", "prestige", "altruism", "risk", "teamwork"]
LEVEL_B = np.array([-2.0, -1.0, 0.0, 1.0, 2.0])
LEVEL_A = np.array([1.0, 1.2, 1.3, 1.2, 1.1])

ITEMS = []
for trait in TRAITS:
    for level in range(1, 6):
        ITEMS.append({"slug": f"{trait}-L{level}", "a": LEVEL_A[level - 1], "b": LEVEL_B[level - 1]})

QUAD = np.linspace(-4, 4, 25)
QW = np.exp(-0.5 * QUAD**2)
QW /= QW.sum()


def logistic(x):
    return 1.0 / (1.0 + np.exp(-x))


def marginal_loglik(a: np.ndarray, b: np.ndarray, resp: np.ndarray) -> float:
    """∫ L(data|θ) φ(θ) dθ по квадрапунктурам (сумма по респондентам)."""
    P = logistic(a[:, None] * (QUAD[None, :] - b[:, None]))          # (M, Q)
    P = np.repeat(P[None, :, :], resp.shape[0], axis=0)              # (N, M, Q)
    lik = np.prod(P ** resp[:, :, None] * (1 - P) ** (1 - resp[:, :, None]), axis=1)
    marg = lik @ QW
    return float(np.sum(np.log(np.clip(marg, 1e-300, None))))


def mcmc_calibrate(resp: np.ndarray, n_iter: int = 400, burn: int = 100, seed_prop: float = 0.08):
    """Metropolis-within-Gibbs: обновляем (a_j, b_j) поочерёдно.
    Априоры: a ~ N(1.2, 0.5²) (обрезка 0.3..2.5), b ~ N(0, 1.5²) (обрезка ±3)."""
    m = resp.shape[1]
    a = np.full(m, 1.0)
    b = np.zeros(m)
    keep_a, keep_b = [], []
    ll = marginal_loglik(a, b, resp)

    for it in range(n_iter):
        for j in range(m):
            # proposal
            a_prop = a.copy(); a_prop[j] = float(np.clip(a[j] + rng.normal(0, seed_prop), 0.3, 2.5))
            b_prop = b.copy(); b_prop[j] = float(np.clip(b[j] + rng.normal(0, seed_prop), -3, 3))
            ll_prop = marginal_loglik(a_prop, b_prop, resp)
            # лог-априоры
            lp_cur = -0.5 * ((a[j] - 1.2) / 0.5) ** 2 - 0.5 * (b[j] / 1.5) ** 2
            lp_prop = -0.5 * ((a_prop[j] - 1.2) / 0.5) ** 2 - 0.5 * (b_prop[j] / 1.5) ** 2
            if np.log(rng.random() + 1e-300) < (ll_prop - ll) + (lp_prop - lp_cur):
                a, b, ll = a_prop, b_prop, ll_prop
        if it >= burn:
            keep_a.append(a.copy())
            keep_b.append(b.copy())

    return np.array(keep_a), np.array(keep_b)  # (S, M) — апостериорные сэмплы


def main():
    print("=" * 72)
    print("BizON R2 — IRT Bayesian (MCMC, Metropolis-within-Gibbs)")
    print("=" * 72)

    # данные: 800 респондентов × 40 items по истинным калибровкам банка
    n_resp = 800
    true_theta = np.clip(rng.normal(0, 1, n_resp), -2.4, 2.4)
    resp = np.zeros((n_resp, len(ITEMS)))
    for i, th in enumerate(true_theta):
        for j, item in enumerate(ITEMS):
            resp[i, j] = 1.0 if rng.random() < logistic(item["a"] * (th - item["b"])) else 0.0

    print(f"\n[1] Данные: {n_resp} респондентов × {len(ITEMS)} items (синтетика по калибровкам банка)")

    a_s, b_s = mcmc_calibrate(resp, n_iter=400, burn=100)
    a_mean = a_s.mean(axis=0)
    b_mean = b_s.mean(axis=0)
    a_true = np.array([i["a"] for i in ITEMS])
    b_true = np.array([i["b"] for i in ITEMS])

    print(f"\n[2] Точность апостериорного среднего ({a_s.shape[0]} сэмплов):")
    print(f"    RMSE(â, a_true) = {float(np.sqrt(np.mean((a_mean - a_true) ** 2))):.3f}")
    print(f"    RMSE(b̂, b_true) = {float(np.sqrt(np.mean((b_mean - b_true) ** 2))):.3f}")

    # 95%-интервалы: честная неопределённость калибровок
    a_lo, a_hi = np.percentile(a_s, [2.5, 97.5], axis=0)
    b_lo, b_hi = np.percentile(b_s, [2.5, 97.5], axis=0)
    a_cover = float(np.mean((a_true >= a_lo) & (a_true <= a_hi)))
    b_cover = float(np.mean((b_true >= b_lo) & (b_true <= b_hi)))
    print(f"\n[3] Покрытие 95%-интервалами (ideal ≈ 0.95):")
    print(f"    a: {a_cover:.2f}, b: {b_cover:.2f}")

    print("\n[4] Пример апостериора (первый item):")
    print(f"    a = {a_mean[0]:.2f} [{a_lo[0]:.2f}, {a_hi[0]:.2f}] (true {a_true[0]:.2f})")
    print(f"    b = {b_mean[0]:.2f} [{b_lo[0]:.2f}, {b_hi[0]:.2f}] (true {b_true[0]:.2f})")

    print("\n[5] Вывод: MCMC даёт не только точку, но и ИНТЕРВАЛ калибровки —")
    print("    в R3+ реальный экспорт ответов получает честные интервалы, а не выдумку точности.")


if __name__ == "__main__":
    main()
