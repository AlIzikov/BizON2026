// BizON Resonance SDK (TypeScript) — СГЕНЕРИРОВАНО scripts/generate-sdks.ts из docs/api/openapi.yaml
// Канон: INSUFFICIENT_DATA — обычный ответ (не исключение); ошибки — {error, code, requestId}.

export interface BizonXAI {
  reasons: string[];
  missing: string[];
  formulaVersion?: string;
  engineVersion?: string;
}

export interface BizonApiError {
  error: string;
  code?: string;
  requestId?: string;
}

export class BizonError extends Error {
  constructor(
    public status: number,
    public body: BizonApiError,
  ) {
    super(body.error);
  }
}

export interface BizonClientOptions {
  baseUrl?: string;      // default '' — same-origin
  fetchImpl?: typeof fetch;
  getSessionCookie?: () => string | undefined; // для Node-использования
}

const INSUFFICIENT_DATA = 'INSUFFICIENT_DATA' as const;

export class BizonClient {
  private f: typeof fetch;
  constructor(private opts: BizonClientOptions = {}) {
    this.f = opts.fetchImpl ?? fetch;
  }

  private async request<T>(path: string, init?: RequestInit): Promise<T> {
    const res = await this.f((this.opts.baseUrl ?? '') + path, {
      ...init,
      headers: {
        'content-type': 'application/json',
        ...(this.opts.getSessionCookie?.() ? { cookie: 'bizon_session=' + this.opts.getSessionCookie() } : {}),
        ...init?.headers,
      },
    });
    const body = (await res.json()) as T & Partial<BizonApiError>;
    if (!res.ok) throw new BizonError(res.status, body as BizonApiError);
    return body;
  }

  // ---------- Резонанс-профиль ----------

  getProfile() {
    return this.request<{ status: string; answeredCount: number; minAnswersRequired: number; xai: BizonXAI }>(
      '/api/resonance/profile',
    );
  }

  async getNextQuestion() {
    const next = await this.request<{ done: boolean; item?: { id: string; text: string; traitLabel: string }; progress?: { answeredCount: number; minAnswersRequired: number } }>(
      '/api/resonance/next',
    );
    return next;
  }

  async answer(itemId: string, rawScore: 1 | 2 | 3 | 4 | 5) {
    return this.request<{ answeredCount: number; status: string; xai: BizonXAI }>('/api/resonance/answer', {
      method: 'POST',
      body: JSON.stringify({ itemId, rawScore }),
    });
  }

  explain() {
    return this.request<{ status: string; rankedTraits?: unknown[]; xai: BizonXAI }>('/api/resonance/explain');
  }

  // ---------- Матчи ----------

  async matchJob(jobId: string) {
    const m = await this.request<{ status: string; score: number | null; factors?: Record<string, number>; xai: BizonXAI }>(
      '/api/resonance/match/job/' + jobId,
    );
    return m.status === INSUFFICIENT_DATA ? m : m; // честно: статус сохраняется, score может быть null
  }

  matchCompanies(limit = 20) {
    return this.request<{ status: string; companies: Array<{ companyId: string; name: string; score: number; xai: BizonXAI }> }>(
      '/api/resonance/companies?limit=' + limit,
    );
  }

  // ---------- Анкета компании ----------

  getCompanyResonance(companyId: string) {
    return this.request<{ exists: boolean; status: string; resonance?: Record<string, unknown>; xai: BizonXAI }>(
      '/api/companies/' + companyId + '/resonance',
    );
  }

  saveCompanyResonance(
    companyId: string,
    input: { offering: Record<string, number>; team: Record<string, number>; evidence: Array<{ ref: string; note: string }> },
  ) {
    return this.request<{ exists: boolean; resonance: Record<string, unknown>; xai: BizonXAI }>(
      '/api/companies/' + companyId + '/resonance',
      { method: 'PUT', body: JSON.stringify(input) },
    );
  }

  // ---------- Endorsements ----------

  listEndorsements(subjectId: string, skillName?: string) {
    const q = new URLSearchParams({ subjectId, ...(skillName ? { skillName } : {}) });
    return this.request<{ endorsements: Array<{ id: string; skillName: string; weight: number; xai: { weightExplanation: string } }>; count: number }>(
      '/api/endorsements?' + q,
    );
  }

  createEndorsement(subjectId: string, skillName: string, text: string) {
    return this.request<{ endorsement: { id: string; weight: number }; factors: unknown; xai: BizonXAI }>(
      '/api/endorsements',
      { method: 'POST', body: JSON.stringify({ subjectId, skillName, text }) },
    );
  }

  revokeEndorsement(id: string) {
    return this.request<{ status: string; weight: number; xai: BizonXAI }>('/api/endorsements/' + id + '/revoke', {
      method: 'POST',
    });
  }

  // ---------- Team Builder ----------

  saveTeamAsProject(input: { title: string; roles: Array<{ title: string; skills: string[]; count?: number }>; maxSize?: number | null; description?: string }) {
    return this.request<{ projectId: string; title: string; membersAdded: number; xai: BizonXAI }>(
      '/api/team-builder/save',
      { method: 'POST', body: JSON.stringify(input) },
    );
  }
}

export default BizonClient;
