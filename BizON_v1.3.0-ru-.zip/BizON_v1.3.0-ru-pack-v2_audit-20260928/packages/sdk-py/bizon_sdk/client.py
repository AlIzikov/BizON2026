"""BizON Resonance SDK (Python) — СГЕНЕРИРОВАНО scripts/generate-sdks.ts.

Канон: INSUFFICIENT_DATA — обычный ответ; 4xx → BizonError(error, code, requestId).
Зависимости: только стандартная библиотека (urllib) — детерминизм и переносимость.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional
from urllib import request as _urlrequest, error as _urlerror

INSUFFICIENT_DATA = "INSUFFICIENT_DATA"


@dataclass
class BizonError(Exception):
    status: int
    error: str
    code: Optional[str] = None
    request_id: Optional[str] = None

    def __str__(self) -> str:  # noqa: D105
        return f"[{self.status}] {self.error} (code={self.code}, requestId={self.request_id})"


class BizonClient:
    """Тонкий клиент резонанс-API BizON."""

    def __init__(self, base_url: str = "", session_cookie: Optional[str] = None, timeout: int = 15) -> None:
        self._base = base_url.rstrip("/")
        self._cookie = session_cookie
        self._timeout = timeout

    def _request(self, path: str, method: str = "GET", body: Optional[dict] = None) -> dict[str, Any]:
        data = json.dumps(body).encode() if body is not None else None
        req = _urlrequest.Request(
            self._base + path,
            data=data,
            method=method,
            headers={"content-type": "application/json", **({"cookie": f"bizon_session={self._cookie}"} if self._cookie else {})},
        )
        try:
            with _urlrequest.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode())
        except _urlerror.HTTPError as e:
            payload = json.loads(e.read().decode() or "{}")
            raise BizonError(
                status=e.code,
                error=payload.get("error", "unknown"),
                code=payload.get("code"),
                request_id=payload.get("requestId"),
            ) from None

    # ---------- Резонанс-профиль ----------

    def get_profile(self) -> dict:
        return self._request("/api/resonance/profile")

    def get_next_question(self) -> dict:
        return self._request("/api/resonance/next")

    def answer(self, item_id: str, raw_score: int) -> dict:
        assert 1 <= raw_score <= 5, "rawScore 1..5"
        return self._request("/api/resonance/answer", method="POST", body={"itemId": item_id, "rawScore": raw_score})

    def explain(self) -> dict:
        return self._request("/api/resonance/explain")

    # ---------- Матчи ----------

    def match_job(self, job_id: str) -> dict:
        return self._request(f"/api/resonance/match/job/{job_id}")

    def match_companies(self, limit: int = 20) -> dict:
        return self._request(f"/api/resonance/companies?limit={limit}")

    # ---------- Анкета компании ----------

    def get_company_resonance(self, company_id: str) -> dict:
        return self._request(f"/api/companies/{company_id}/resonance")

    def save_company_resonance(self, company_id: str, offering: dict, team: dict, evidence: list) -> dict:
        return self._request(
            f"/api/companies/{company_id}/resonance",
            method="PUT",
            body={"offering": offering, "team": team, "evidence": evidence},
        )

    # ---------- Endorsements ----------

    def list_endorsements(self, subject_id: str, skill_name: Optional[str] = None) -> dict:
        q = f"subjectId={subject_id}" + (f"&skillName={skill_name}" if skill_name else "")
        return self._request(f"/api/endorsements?{q}")

    def create_endorsement(self, subject_id: str, skill_name: str, text: str) -> dict:
        return self._request("/api/endorsements", method="POST", body={"subjectId": subject_id, "skillName": skill_name, "text": text})

    def revoke_endorsement(self, endorsement_id: str) -> dict:
        return self._request(f"/api/endorsements/{endorsement_id}/revoke", method="POST")

    # ---------- Team Builder ----------

    def save_team_as_project(self, title: str, roles: list, max_size: Optional[int] = None, description: Optional[str] = None) -> dict:
        body: dict[str, Any] = {"title": title, "roles": roles}
        if max_size is not None:
            body["maxSize"] = max_size
        if description:
            body["description"] = description
        return self._request("/api/team-builder/save", method="POST", body=body)
