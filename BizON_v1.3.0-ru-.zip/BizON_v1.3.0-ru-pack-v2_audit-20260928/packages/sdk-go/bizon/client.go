// BizON Resonance SDK (Go) — СГЕНЕРИРОВАНО scripts/generate-sdks.ts.
// Канон: INSUFFICIENT_DATA — обычный ответ; 4xx → *BizonError.
package bizon

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
)

type XAI struct {
	Reasons        []string `json:"reasons"`
	Missing        []string `json:"missing"`
	FormulaVersion string   `json:"formulaVersion,omitempty"`
}

type BizonError struct {
	Status    int    `json:"-"`
	Error     string `json:"error"`
	Code      string `json:"code,omitempty"`
	RequestID string `json:"requestId,omitempty"`
}

func (e *BizonError) String() string { return fmt.Sprintf("[%d] %s (code=%s)", e.Status, e.Error, e.Code) }

type Client struct {
	BaseURL    string
	Session    string // значение cookie bizon_session
	HTTPClient *http.Client
}

func New(baseURL, sessionCookie string) *Client {
	return &Client{BaseURL: baseURL, Session: sessionCookie, HTTPClient: http.DefaultClient}
}

func (c *Client) do(path, method string, body any, out any) error {
	var rdr *bytes.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rdr = bytes.NewReader(b)
	} else {
		rdr = bytes.NewReader(nil)
	}
	req, err := http.NewRequest(method, c.BaseURL+path, rdr)
	if err != nil {
		return err
	}
	req.Header.Set("content-type", "application/json")
	if c.Session != "" {
		req.Header.Set("cookie", "bizon_session="+c.Session)
	}
	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	decoder := json.NewDecoder(resp.Body)
	if resp.StatusCode >= 400 {
		var apiErr BizonError
		_ = decoder.Decode(&apiErr)
		apiErr.Status = resp.StatusCode
		return &apiErr
	}
	return decoder.Decode(out)
}

func (c *Client) GetProfile() (map[string]any, error) {
	var out map[string]any
	err := c.do("/api/resonance/profile", "GET", nil, &out)
	return out, err
}

func (c *Client) MatchJob(jobID string) (map[string]any, error) {
	var out map[string]any
	err := c.do("/api/resonance/match/job/"+jobID, "GET", nil, &out)
	return out, err
}

func (c *Client) ListEndorsements(subjectID, skillName string) (map[string]any, error) {
	var out map[string]any
	err := c.do("/api/endorsements?subjectId="+subjectID+"&skillName="+skillName, "GET", nil, &out)
	return out, err
}

func (c *Client) SaveTeamAsProject(title string, roles []map[string]any) (map[string]any, error) {
	var out map[string]any
	err := c.do("/api/team-builder/save", "POST", map[string]any{"title": title, "roles": roles}, &out)
	return out, err
}
