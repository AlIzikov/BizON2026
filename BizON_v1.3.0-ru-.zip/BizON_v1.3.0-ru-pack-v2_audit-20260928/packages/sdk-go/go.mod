module github.com/bizon/resonance-sdk-go

go 1.22
