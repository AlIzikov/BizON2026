// =============================================================================
// Адверсарий A (Task ID: adv-a) — аутентификация / IDOR / admin / паспорта / privesc.
//
// Цель — ДОКАЗАТЬ, что BizON ломается. Ничего не чиним.
//   BLOCKED   — защита сработала (401/403/404/отказ), тест зелёный.
//   EXPLOITED — атака успешна: verdict() бросает, тест красный = доказательство.
//
// Поверхности (по worklog.md: withRoute-гейт getUserFromRequest → 401):
//   1. Подделка сессии (мусорный/просроченный токен) на authed-роутах.
//   2. IDOR: юзер B против ресурсов юзера A (профиль, ДР-планы, карьера, проекты).
//   3. Анонимный доступ: /api/users/[id]/persona, /api/projects/[id] (evidence).
//   4. Админ-поверхности с обычной сессией; /api/metrics без Bearer.
//   5. Privilege escalation через PATCH своего профиля (roles/isVerified/...).
//   6. Публичные паспорта /api/p/[token], /api/c/[token] — перебор/инъекция.
//   7. SSE /api/notifications/stream с мусорной сессией.
// =============================================================================

// ПЕРВЫЙ импорт — helpers изолирует БД (копия db/custom.db в tmpdir).
import { verdict, DEAD_SESSION, sessionHeaders, callRoute, cleanupAdvDb } from './helpers';

import { beforeAll, afterAll, describe, test } from 'bun:test';
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

const SESSION_TTL_MS = 60 * 60 * 1000;

function jsonHeaders(token: string): Record<string, string> {
  return { 'content-type': 'application/json', cookie: `bizon_session=${token}` };
}

async function advUser(name: string, overrides: Record<string, unknown> = {}) {
  return db.user.create({
    data: {
      name,
      title: 'QA-Adversary',
      passwordHash: 'pbkdf2$600000$ab$cd', // логин в тестах не используется
      accountType: 'individual',
      roles: 'QA',
      ...overrides,
    },
  });
}

async function makeSession(userId: string, token: string, expiresAt: Date) {
  await db.session.create({ data: { userId, token, expiresAt } });
}

const tokA = `advtok-a-${Date.now()}`;
const tokB = `advtok-b-${Date.now()}`;
const tokExpired = `advtok-exp-${Date.now()}`;

let userA: Awaited<ReturnType<typeof advUser>> | null = null;
let userB: Awaited<ReturnType<typeof advUser>> | null = null;
let privateProjectId = '';
let planAId = '';
let entryAId = '';

beforeAll(async () => {
  // A — «жертва»: секретное био и «привилегированная» роль в CSV (атака перебором полей)
  userA = await advUser('ADV-A Жертва', {
    bio: 'СЕКРЕТНОЕ-БИО-ADV-A',
    roles: 'engineer,ADV-SECRET-ROLE',
  });
  // B — «нападающий»: обычный пользователь, никаких связей с A
  userB = await advUser('ADV-A Нападающий');

  await makeSession(userA.id, tokA, new Date(Date.now() + SESSION_TTL_MS));
  await makeSession(userB.id, tokB, new Date(Date.now() + SESSION_TTL_MS));
  await makeSession(userA.id, tokExpired, new Date(Date.now() - 1000)); // просроченная

  // Приватный проект A с защищёнными W2-evidence полями (создаём через API от имени A,
  // затем помечаем confidentiality/visibility/status в «закрытое» состояние).
  const created = await callRoute(
    (await import('@/app/api/projects/route')).POST,
    'http://localhost/api/projects',
    {
      method: 'POST',
      headers: jsonHeaders(tokA),
      body: JSON.stringify({
        title: 'ADV-A приватный проект',
        description: 'Внутренние данные, посторонним читать нельзя',
        problem: 'СЕКРЕТНАЯ-ПРОБЛЕМА-ADV-A',
        solution: 'СЕКРЕТНОЕ-РЕШЕНИЕ-ADV-A',
      }),
    },
  );
  if (created.status !== 201) throw new Error(`окружение: создание проекта вернуло ${created.status}`);
  privateProjectId = (await created.json() as { project: { id: string } }).project.id;
  await db.project.update({
    where: { id: privateProjectId },
    data: { confidentiality: 'private', visibility: 'private', status: 'cancelled' },
  });

  // Ресурсы A для IDOR-проб
  const plan = await db.birthdayPlan.create({
    data: { ownerId: userA.id, personName: 'Секретный Контакт', dateMonth: 5, dateDay: 10 },
  });
  planAId = plan.id;
  const entry = await db.careerEntry.create({
    data: { userId: userA.id, title: 'Секретная Запись', company: 'Секретная Компания', position: 'Секретная Должность', startDate: new Date() },
  });
  entryAId = entry.id;
});

afterAll(cleanupAdvDb);

// =============================================================================
describe('ADV-A: подделка/жизненный цикл сессии', () => {
  test('ADV-A101: мусорная сессия → GET /api/users/<id чужого профиля> обязан 401', async () => {
    const { GET } = await import('@/app/api/users/[id]/route');
    const res = await callRoute(
      GET,
      `http://localhost/api/users/${userA!.id}`,
      { headers: sessionHeaders(DEAD_SESSION), params: { id: userA!.id } },
    );
    verdict(
      'ADV-A101',
      res.status === 401,
      `мусорный токен bizon_session=${DEAD_SESSION} на GET /api/users/<id> → статус ${res.status} (ожидался 401)`,
    );
  });

  test('ADV-A102: мусорная сессия → GET /api/me/blind-spots обязан 401', async () => {
    const { GET } = await import('@/app/api/me/blind-spots/route');
    const res = await callRoute(
      GET,
      'http://localhost/api/me/blind-spots',
      { headers: sessionHeaders(DEAD_SESSION) },
    );
    verdict(
      'ADV-A102',
      res.status === 401,
      `мусорный токен на /api/me/blind-spots → статус ${res.status} (ожидался 401)`,
    );
  });

  test('ADV-A103: мусорная сессия → POST /api/projects (создание) обязан 401', async () => {
    const { POST } = await import('@/app/api/projects/route');
    const res = await callRoute(
      POST,
      'http://localhost/api/projects',
      {
        method: 'POST',
        headers: { 'content-type': 'application/json', cookie: `bizon_session=${DEAD_SESSION}` },
        body: JSON.stringify({ title: 'Взлом', description: 'создание без сессии' }),
      },
    );
    verdict(
      'ADV-A103',
      res.status === 401,
      `мусорный токен на POST /api/projects → статус ${res.status} (ожидался 401, проект не создан)`,
    );
  });

  test('ADV-A104: просроченная сессия (expiresAt в прошлом) → 401', async () => {
    const { GET } = await import('@/app/api/me/blind-spots/route');
    const res = await callRoute(
      GET,
      'http://localhost/api/me/blind-spots',
      { headers: sessionHeaders(tokExpired) },
    );
    verdict(
      'ADV-A104',
      res.status === 401,
      `expiresAt в прошлом на /api/me/blind-spots → статус ${res.status} (ожидался 401, сессия уничтожена)`,
    );
  });

  test('ADV-A105: мусорная сессия → SSE GET /api/notifications/stream обязан отказать (401)', async () => {
    const { GET } = await import('@/app/api/notifications/stream/route');
    const res = await callRoute(
      GET,
      'http://localhost/api/notifications/stream',
      { headers: sessionHeaders(DEAD_SESSION) },
    );
    verdict(
      'ADV-A105',
      res.status === 401,
      `мусорный токен на SSE-стриме → статус ${res.status} (${res.headers.get('content-type')}; ожидался 401 text/plain, поток не открыт)`,
    );
  });
});

// =============================================================================
describe('ADV-A: IDOR — юзер B против ресурсов юзера A', () => {
  test('ADV-A106: B PATCH чужого профиля /api/users/<A.id> обязан 403', async () => {
    const { PATCH } = await import('@/app/api/users/[id]/route');
    const res = await callRoute(
      PATCH,
      `http://localhost/api/users/${userA!.id}`,
      {
        method: 'PATCH',
        headers: jsonHeaders(tokB),
        body: JSON.stringify({ name: 'HACKED-BY-B', bio: 'подменено нападающим' }),
        params: { id: userA!.id },
      },
    );
    const victim = await db.user.findUnique({ where: { id: userA!.id }, select: { name: true, bio: true } });
    const intact = victim?.name === 'ADV-A Жертва' && victim?.bio === 'СЕКРЕТНОЕ-БИО-ADV-A';
    verdict(
      'ADV-A106',
      res.status === 403 && intact,
      `B (своя валидная сессия) PATCH /api/users/${userA!.id} → статус ${res.status}, данные жертвы ${intact ? 'не изменены' : 'ИЗМЕНЕНЫ'} (ожидался 403)`,
    );
  });

  test('ADV-A107: B PATCH чужого ДР-плана /api/birthday-plans/<план A> обязан 403', async () => {
    const { PATCH } = await import('@/app/api/birthday-plans/[id]/route');
    const res = await callRoute(
      PATCH,
      `http://localhost/api/birthday-plans/${planAId}`,
      {
        method: 'PATCH',
        headers: jsonHeaders(tokB),
        body: JSON.stringify({ comment: 'IDOR-атака нападающего' }),
        params: { id: planAId },
      },
    );
    const plan = await db.birthdayPlan.findUnique({ where: { id: planAId }, select: { comment: true } });
    verdict(
      'ADV-A107',
      res.status === 403 && plan?.comment === '',
      `B PATCH чужого birthday-plan → статус ${res.status}, comment в БД = «${plan?.comment}» (ожидался 403 и пустой комментарий)`,
    );
  });

  test('ADV-A108: B PATCH чужой карьер-записи /api/career-entries/<запись A> обязан 403', async () => {
    const { PATCH } = await import('@/app/api/career-entries/[id]/route');
    const res = await callRoute(
      PATCH,
      `http://localhost/api/career-entries/${entryAId}`,
      {
        method: 'PATCH',
        headers: jsonHeaders(tokB),
        body: JSON.stringify({ position: 'HACKED-BY-B' }),
        params: { id: entryAId },
      },
    );
    const entry = await db.careerEntry.findUnique({ where: { id: entryAId }, select: { position: true } });
    verdict(
      'ADV-A108',
      res.status === 403 && entry?.position === 'Секретная Должность',
      `B PATCH чужой career-entry → статус ${res.status}, position в БД = «${entry?.position}» (ожидался 403)`,
    );
  });
});

// =============================================================================
describe('ADV-A: анонимный доступ к защищённым данным', () => {
  test('ADV-A109: БЕЗ сессии GET /api/users/<id>/persona отдаёт био+роли (обход FIX-02/P0-3)', async () => {
    // Соседний GET /api/users/[id] без сессии = 401 (FIX-02 P0-3), а persona-роут
    // вообще не проверяет сессию. Проверяем на реальном пользователе A.
    const { GET } = await import('@/app/api/users/[id]/persona/route');
    const req = new NextRequest(`http://localhost/api/users/${userA!.id}/persona`);
    const res = await GET(req, { params: Promise.resolve({ id: userA!.id }) });
    let body: { user?: { bio?: string | null; roles?: string[] } } = {};
    try { body = await res.json(); } catch { /* не JSON — тоже находка */ }
    const leakedBio = Boolean(body.user?.bio);
    const leakedRoles = (body.user?.roles ?? []).length > 0;
    verdict(
      'ADV-A109',
      !(res.status === 200 && leakedBio && leakedRoles),
      `аноним GET /api/users/<id>/persona → ${res.status}; bio утекло: ${leakedBio} («${body.user?.bio}»), roles утекли: ${leakedRoles} (${JSON.stringify(body.user?.roles)}) — соседний /api/users/[id] требует сессию, persona — нет`,
    );
  });

  test('ADV-A110: БЕЗ сессии GET /api/projects/<id> отдаёт W2-evidence (problem/solution) приватного проекта', async () => {
    // W2-движок отдаёт evidence только через approvedFields-проекцию (GET /evidence),
    // но «сырой» GET /api/projects/[id] не имеет ни auth-гейта, ни фильтра confidentiality.
    const { GET } = await import('@/app/api/projects/[id]/route');
    const res = await callRoute(
      GET,
      `http://localhost/api/projects/${privateProjectId}`,
      { params: { id: privateProjectId } }, // БЕЗ cookie — полностью анонимно
    );
    let body: { project?: { problem?: string | null; solution?: string | null; confidentiality?: string } } = {};
    try { body = await res.json(); } catch { /* ignore */ }
    const p = body.project;
    const leaked =
      res.status === 200 &&
      p?.problem === 'СЕКРЕТНАЯ-ПРОБЛЕМА-ADV-A' &&
      p?.solution === 'СЕКРЕТНОЕ-РЕШЕНИЕ-ADV-A';
    verdict(
      'ADV-A110',
      !leaked,
      `аноним GET /api/projects/<id> (confidentiality=${p?.confidentiality}) → ${res.status}; problem утекло: ${p?.problem === 'СЕКРЕТНАЯ-ПРОБЛЕМА-ADV-A'}, solution утекло: ${p?.solution === 'СЕКРЕТНОЕ-РЕШЕНИЕ-ADV-A'} — никакого auth-гейта в роуте нет`,
    );
  });

  test('ADV-A111: B вступает (PATCH action=join) в private+cancelled проект A без согласия владельца', async () => {
    const { PATCH } = await import('@/app/api/projects/[id]/route');
    const res = await callRoute(
      PATCH,
      `http://localhost/api/projects/${privateProjectId}`,
      {
        method: 'PATCH',
        headers: jsonHeaders(tokB),
        body: JSON.stringify({ action: 'join' }),
        params: { id: privateProjectId },
      },
    );
    const member = await db.projectMember.findUnique({
      where: { projectId_userId: { projectId: privateProjectId, userId: userB!.id } },
    });
    verdict(
      'ADV-A111',
      !(res.status === 200 && !!member),
      `B PATCH action=join в проект A (visibility=private, status=cancelled) → ${res.status}; участник создан в БД: ${!!member} — ни проверки видимости/статуса, ни согласия владельца`,
    );
  });
});

// =============================================================================
describe('ADV-A: повышение привилегий и админ-поверхности', () => {
  test('ADV-A112: PATCH своего профиля с roles=admin/isVerified/subscriptionTier не меняет привилегии', async () => {
    const { PATCH } = await import('@/app/api/users/[id]/route');
    const res = await callRoute(
      PATCH,
      `http://localhost/api/users/${userB!.id}`,
      {
        method: 'PATCH',
        headers: jsonHeaders(tokB),
        body: JSON.stringify({
          name: 'ADV-A Нападающий',
          roles: 'admin,superadmin',
          isVerified: true,
          subscriptionTier: 'enterprise',
          accountType: 'company',
        }),
        params: { id: userB!.id },
      },
    );
    const after = await db.user.findUnique({
      where: { id: userB!.id },
      select: { roles: true, isVerified: true, subscriptionTier: true, accountType: true },
    });
    const escalated =
      after!.roles.split(',').map((r) => r.trim()).includes('admin') ||
      after!.isVerified === true ||
      after!.accountType === 'company';
    verdict(
      'ADV-A112',
      res.status === 200 && !escalated,
      `self-PATCH c roles=admin/isVerified/subscriptionTier=enterprise/accountType=company → ${res.status}; БД после: roles=«${after!.roles}», isVerified=${after!.isVerified}, accountType=«${after!.accountType}» (whitelist полей должен игнорировать привилегированные)`,
    );
  });

  test('ADV-A113: обычная сессия на /api/admin/* обязана получить отказ (401/403)', async () => {
    const results: string[] = [];
    const causality = await callRoute(
      (await import('@/app/api/admin/causality/route')).GET,
      'http://localhost/api/admin/causality',
      { headers: sessionHeaders(tokB) },
    );
    results.push(`causality=${causality.status}`);
    const adminMetrics = await callRoute(
      (await import('@/app/api/admin/metrics/route')).GET,
      'http://localhost/api/admin/metrics',
      { headers: sessionHeaders(tokB) },
    );
    results.push(`admin/metrics=${adminMetrics.status}`);
    const dataPlane = await callRoute(
      (await import('@/app/api/admin/data-plane/route')).GET,
      'http://localhost/api/admin/data-plane',
      { headers: sessionHeaders(tokB) },
    );
    results.push(`data-plane=${dataPlane.status}`);
    const allDenied = [causality, adminMetrics, dataPlane].every((r) => r.status === 401 || r.status === 403);
    verdict(
      'ADV-A113',
      allDenied,
      `сессия обычного юзера (roles=QA) на админ-роутах → ${results.join(', ')} (ожидались 401/403, не 200)`,
    );
  });

  test('ADV-A114: /api/metrics без Bearer METRICS_TOKEN и без админ-сессии обязан 401', async () => {
    const { GET } = await import('@/app/api/metrics/route');
    const anon = await callRoute(GET, 'http://localhost/api/metrics');
    const withUserSession = await callRoute(
      GET,
      'http://localhost/api/metrics',
      { headers: sessionHeaders(tokB) },
    );
    verdict(
      'ADV-A114',
      anon.status === 401 && withUserSession.status === 401,
      `GET /api/metrics: аноним → ${anon.status}, сессия обычного юзера → ${withUserSession.status} (ожидались 401; METRICS_TOKEN в окружении не задан)`,
    );
  });
});

// =============================================================================
describe('ADV-A: публичные паспорта — перебор и инъекция токена', () => {
  test('ADV-A115: короткий/несуществующий/подрезанный токен → единый 404 без утечки существования', async () => {
    const checks: { label: string; status: number; message: string }[] = [];
    const probe = async (label: string, base: 'p' | 'c', token: string) => {
      const mod = await import(base === 'p' ? '@/app/api/p/[token]/route' : '@/app/api/c/[token]/route');
      const res = await callRoute(mod.GET, `http://localhost/api/${base}/${token}`, { params: { token } });
      let message = '';
      try { message = ((await res.json()) as { error?: string }).error ?? ''; } catch { /* ignore */ }
      checks.push({ label, status: res.status, message });
    };

    await probe('p:короткий(2)', 'p', 'ab');
    await probe('p:64hex-несуществующий', 'p', 'f'.repeat(64));
    await probe('p:SQL-инъекция', 'p', "' OR 1=1 --");
    await probe('c:короткий(2)', 'c', 'ab');
    await probe('c:64hex-несуществующий', 'c', 'e'.repeat(64));

    // Реальный паспорт: включаем A свой паспорт и проверяем, что усечённый/удлинённый
    // токен НЕ отдаёт паспорт (только точное совпадение).
    let realTokenChecked = '';
    const enable = await callRoute(
      (await import('@/app/api/me/passport/enable/route')).POST,
      'http://localhost/api/me/passport/enable',
      { method: 'POST', headers: jsonHeaders(tokA) },
    );
    if (enable.status === 200) {
      const real = ((await enable.json()) as { token?: string }).token ?? '';
      if (real.length >= 16) {
        realTokenChecked = real;
        await probe('p:реальный-усечённый', 'p', real.slice(0, real.length - 2));
        await probe('p:реальный+мусор', 'p', `${real}00`);
      }
    } else {
      console.warn(`[ADV-A115] окружение: enable паспорта вернул ${enable.status} — реальный токен не проверялся`);
    }

    const notFoundEverywhere = checks.every((c) => c.status === 404);
    const messages = new Set(checks.filter((c) => c.status === 404).map((c) => c.message));
    const noDifferential = messages.size <= 2; // сообщения p/c могут отличаться между собой, но не внутри семейства
    verdict(
      'ADV-A115',
      notFoundEverywhere && noDifferential,
      `перебор/инъекция токенов паспорта → ${checks.map((c) => `${c.label}:${c.status}`).join(', ')}; уникальных сообщений об ошибке: ${[...messages].length}; реальный токен ${realTokenChecked ? 'проверялся (усечённый/удлинённый → 404)' : 'не проверялся (enable недоступен)'}`,
    );
  });
});
