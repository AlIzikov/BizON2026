// =============================================================================
// Адверсариальное ревью BizON (приказ владельца, trace 1a0b3473dee710fd).
// Цель — ДОКАЗАТЬ, что BizON ломается. Каждая атака воспроизводится тестом.
// НИЧЕГО НЕ ЧИНИТСЯ: находка EXPLOITED = падающий тест = доказательство уязвимости.
//
// Протокол вердиктов:
//   BLOCKED   — защита сработала, тест зелёный (атака отбита).
//   EXPLOITED — атака успешна: verdict() печатает находку и бросает — тест красный.
//
// Изоляция: каждый прогон работает с КОПИЕЙ db/custom.db во временной папке
// (аналог tests/helpers/setup.ts). Пишущие атаки не портят реальную базу.
// ЭТОТ ФАЙЛ ДОЛЖЕН ИМПОРТИРОВАТЬСЯ ПЕРВЫМ в каждом атакующем тест-файле
// (до любых импортов из '@/...').
// =============================================================================
import { cpSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';

// Next types делают NODE_ENV readonly — обходим через Object.assign
Object.assign(process.env, { NODE_ENV: 'test' });
process.env.BIZON_ENCRYPTION_KEY = process.env.BIZON_ENCRYPTION_KEY || 'a'.repeat(64);

const dir = mkdtempSync(path.join(tmpdir(), 'bizon-adv-'));
const testDbPath = path.join(dir, 'adv.db');
cpSync(path.resolve(import.meta.dir, '../db/custom.db'), testDbPath);
process.env.DATABASE_URL = `file:${testDbPath}`;

export const ADV_DB_PATH = testDbPath;

/**
 * Завершение прогона — удаляет временную БД. Вызывать в afterAll().
 *
 * KV2-фаза E (фикс инфраструктуры): bun test выполняет ВСЕ файлы в ОДНОМ
 * процессе. rmSync здесь в afterAll первого завершившегося атакующего файла
 * удалял общий /tmp-каталог ДО того, как его отработают остальные файлы —
 * все последующие записи падали с SQLITE_READONLY_DBMOVED (1032,
 * «attempt to write a readonly database») по всему регрессу.
 * Очистка отложена до выхода процесса: изоляция сохранена, файлы не ломаются.
 */
let advExitHooked = false;
export function cleanupAdvDb(): void {
  if (advExitHooked) return;
  advExitHooked = true;
  // bun-types overrides.d.ts (#40003): собственный on("memoryPressure") затеняет
  // унаследованный generic-метод EventEmitter — process.on("exit") не типизируется.
  // Каст к EventEmitter не меняет рантайм: регистрируется тот же exit-хук.
  (process as unknown as import('node:events').EventEmitter).on('exit', () => {
    try {
      rmSync(dir, { recursive: true, force: true });
    } catch {
      // ignore
    }
  });
}

/** Печатает вердикт пробы. blocked=false → EXPLOITED (тест падает — доказательство). */
export function verdict(id: string, blocked: boolean, detail: string): void {
  console.log(`[${id}] ${blocked ? 'BLOCKED' : 'EXPLOITED'} — ${detail}`);
  if (!blocked) throw new Error(`EXPLOITED ${id}: ${detail}`);
}

/** Мусорная сессия: должна отклоняться всеми authed-поверхностями (401). */
export const DEAD_SESSION = 'deadbeef-dead-beef-dead-000000000000';

/** Заголовки с подделанной сессией. */
export function sessionHeaders(token: string): Record<string, string> {
  return { cookie: `bizon_session=${token}` };
}

/**
 * Прямой вызов withRoute-обёрнутого хендлера (белый ящик, но auth-гейт реальный:
 * getUserFromRequest читает куку из Request). Пример:
 *   const { GET } = await import('@/app/api/users/[id]/route');
 *   const res = await callRoute(GET, 'http://localhost/api/users/x', { headers: sessionHeaders(DEAD_SESSION), params: { id: 'x' } });
 */
export async function callRoute(
  // (...args: never[]) — универсально контравариантный функциональный тип:
  // совместим с ЛЮБЫМ хендлером (withRoute-обёрнутым, сырым NextRequest-роутом,
  // с params {id}/{slug} или без) — bun исполняет одинаково, tsc не мешает.
  handler: (...args: never[]) => Response | Promise<Response>,
  url: string,
  opts: { method?: string; headers?: Record<string, string>; body?: string; params?: Record<string, string> } = {},
): Promise<Response> {
  const req = new Request(url, {
    method: opts.method ?? (opts.body ? 'POST' : 'GET'),
    headers: opts.headers,
    body: opts.body,
  });
  const ctx = opts.params ? { params: Promise.resolve(opts.params) } : undefined;
  return await (
    handler as unknown as (req: Request, ctx?: { params?: Promise<Record<string, string>> }) => Promise<Response>
  )(req, ctx);
}
