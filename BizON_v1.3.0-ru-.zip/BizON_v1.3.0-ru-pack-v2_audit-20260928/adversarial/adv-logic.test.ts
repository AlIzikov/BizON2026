// =============================================================================
// АДВЕРСАРИЙ C (adv-c) — бизнес-логика BizON: состояния, дубликаты, лимиты,
// гонки, устойчивость, утечки скрытого, одноразовость.
//
// Каждая проба = атакующее доказательство. verdict(id, false, ...) → тест красный
// = EXPLOITED (дыра доказана). verdict(id, true, ...) → BLOCKED (защита сработала).
// НИЧЕГО НЕ ЧИНИТСЯ. Только этот файл; helpers.ts не трогаем.
// =============================================================================

// ПЕРВЫЙ импорт (сетап изолированной БД и env — до любых '@/...').
import {
  verdict,
  DEAD_SESSION,
  sessionHeaders,
  callRoute,
  cleanupAdvDb,
} from './helpers';

import { afterAll, beforeAll, describe, expect, test } from 'bun:test';

import { db } from '@/lib/db';
import { MAX_PROPOSAL_PER_USER } from '@/lib/projects/constants';

// ---------- инфраструктура проб ----------

let u1: { id: string }; let tok1: string; // rate-limit N+1
let u2: { id: string }; let tok2: string; // per-user изоляция + дубликаты claims
let u3: { id: string }; let tok3: string; // проекты: complete-farm / transition / cap
let u4: { id: string }; let tok4: string; // community-гонка + зритель скрытого
let u5: { id: string }; let tok5: string; // владелец STEALTH-проекта + verify-токен

/** Заглушка NextRequest для legacy-роутов, читающих req.nextUrl (verify-email). */
function reqWithQuery(url: string): import('next/server').NextRequest {
  const stub = new Request(url);
  Object.assign(stub, { nextUrl: new URL(url) });
  return stub as unknown as import('next/server').NextRequest;
}

beforeAll(async () => {
  const mk = async (name: string) =>
    db.user.create({
      data: {
        name,
        title: 'ADV-C',
        passwordHash: 'pbkdf2$600000$ab$cd',
        accountType: 'individual',
        roles: 'QA',
      },
    });
  const mkSession = async (userId: string) => {
    const token = `advc-${userId.slice(-6)}-${Date.now()}-${Math.floor(Math.random() * 1e9)}`;
    await db.session.create({
      data: { userId, token, expiresAt: new Date(Date.now() + 3600_000) },
    });
    return token;
  };
  u1 = await mk('ADV-C У1 RateLimit');
  u2 = await mk('ADV-C У2 Isolation');
  u3 = await mk('ADV-C У3 Projects');
  u4 = await mk('ADV-C У4 Community');
  u5 = await mk('ADV-C У5 Stealth');
  tok1 = await mkSession(u1.id);
  tok2 = await mkSession(u2.id);
  tok3 = await mkSession(u3.id);
  tok4 = await mkSession(u4.id);
  tok5 = await mkSession(u5.id);
});

afterAll(() => cleanupAdvDb());

// =============================================================================
// Вектор 1: rate-limit обход — N+1 вызов подряд одним «юзером».
// /api/claims POST использует checkUserRateLimit(user.id, 'claims:create',
// ...MUTATION_LIMITS.eventsCreate = [10, 1 час]). 11-й вызов обязан отказать (429).
// =============================================================================
describe('ADV-C: rate limits', () => {
  test('ADV-C101: лимит claims:create — 11-й вызов подряд должен отказать (429)', async () => {
    const { POST: claimsPOST } = await import('@/app/api/claims/route');
    const statuses: number[] = [];
    for (let i = 0; i < 11; i++) {
      const res = await callRoute(
        claimsPOST,
        'http://localhost/api/claims',
        {
          method: 'POST',
          headers: sessionHeaders(tok1),
          body: JSON.stringify({ type: 'skill', title: `ADV-C rl ${i}` }),
        },
      );
      statuses.push(res.status);
    }
    const last = statuses[10]!;
    const blocked = last === 429;
    verdict(
      'ADV-C101',
      blocked,
      `лимит claims:create (10/час): 11 POST подряд одним юзером → [${statuses.join(', ')}]; ` +
        (blocked
          ? '11-й отклонён 429 — per-user окно работает'
          : `11-й вернул ${last} — checkUserRateLimit НЕ сработал, спам-лимит обходится`),
    );
    expect(last).toBe(429);
  });

  test('ADV-C102: лимит per-user, а не глобальный — у второго юзера своё окно', async () => {
    const { POST: claimsPOST } = await import('@/app/api/claims/route');
    const res = await callRoute(
      claimsPOST,
      'http://localhost/api/claims',
      {
        method: 'POST',
        headers: sessionHeaders(tok2),
        body: JSON.stringify({ type: 'skill', title: 'ADV-C isolated user' }),
      },
    );
    const blocked = res.status === 201;
    verdict(
      'ADV-C102',
      blocked,
      `ключ лимита = user:${u1.id}:claims:create исчерпан в ADV-C101; запрос ОТ ДРУГОГО юзера (u2) → ${res.status} ` +
        (blocked
          ? '— бакет per-user, чужой лимит не задевает (IP/глобального фапаута нет)'
          : '— второй юзер тоже заблокирован: лимит глобальный/IP-based, это ложные отказы'),
    );
    expect(res.status).toBe(201);
  });
});

// =============================================================================
// Вектор 2: дубликаты. Claim без @@unique — один и тот же claim дважды.
// =============================================================================
describe('ADV-C: дубликаты', () => {
  test('ADV-C103: одинаковый claim дважды — должен быть дедуп/409, фактически создаются 2 записи', async () => {
    const { POST: claimsPOST } = await import('@/app/api/claims/route');
    const payload = {
      type: 'achievement',
      title: 'ADV-C dup claim',
      description: 'абсолютно одинаковый claim',
    };
    const r1 = await callRoute(claimsPOST, 'http://localhost/api/claims', {
      method: 'POST',
      headers: sessionHeaders(tok2),
      body: JSON.stringify(payload),
    });
    const r2 = await callRoute(claimsPOST, 'http://localhost/api/claims', {
      method: 'POST',
      headers: sessionHeaders(tok2),
      body: JSON.stringify(payload),
    });
    const dups = await db.claim.count({
      where: { userId: u2.id, title: payload.title },
    });
    const blocked = !(r1.status === 201 && r2.status === 201 && dups === 2);
    verdict(
      'ADV-C103',
      blocked,
      `POST /api/claims ×2 с идентичным телом → ${r1.status}/${r2.status}, в БД ${dups} одинаковых claim'а; ` +
        (blocked
          ? 'дедуп/ограничение сработали'
          : 'дубликаты создаются свободно: спам-claims, каждый можно верифицировать отдельно → ферма доверия'),
    );
  });
});

// =============================================================================
// Векторы 4/6: гонки статусов + невалидные переходы (проекты).
// PATCH /api/projects/[id] {action:'complete'} не проверяет текущий статус →
// повторное «завершение» = повторное awardBulk(project_completed) = ферма IP-score.
// =============================================================================
describe('ADV-C: состояния проектов', () => {
  test('ADV-C104: двойное завершение проекта — повторный complete должен отклоняться, фактически репутация начисляется повторно', async () => {
    const { POST: projectsPOST } = await import('@/app/api/projects/route');
    const { PATCH: projectPATCH } = await import('@/app/api/projects/[id]/route');

    const created = await callRoute(projectsPOST, 'http://localhost/api/projects', {
      method: 'POST',
      headers: sessionHeaders(tok3),
      body: JSON.stringify({ title: 'ADV-C farm', description: 'double complete' }),
    });
    expect(created.status).toBe(201);
    const { project } = (await created.json()) as { project: { id: string } };

    const complete = () =>
      callRoute(projectPATCH, `http://localhost/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: sessionHeaders(tok3),
        params: { id: project.id },
        body: JSON.stringify({ action: 'complete', rating: 5 }),
      });

    const c1 = await complete();
    expect(c1.status).toBe(200);
    const ip1 = (await db.user.findUnique({ where: { id: u3.id } }))!.ipScore;
    const ev1 = await db.reputationEvent.count({
      where: { userId: u3.id, eventType: 'project_completed' },
    });

    const c2 = await complete(); // повторное завершение УЖЕ завершённого
    const ip2 = (await db.user.findUnique({ where: { id: u3.id } }))!.ipScore;
    const ev2 = await db.reputationEvent.count({
      where: { userId: u3.id, eventType: 'project_completed' },
    });

    const blocked = c2.status !== 200 || (ev2 === ev1 && ip2 <= ip1);
    verdict(
      'ADV-C104',
      blocked,
      `двойной PATCH complete: #1=200, #2=${c2.status}; reputationEvent(project_completed) ${ev1}→${ev2}, ipScore ${ip1}→${ip2}; ` +
        (blocked
          ? 'повтор завершения отклонён/не даёт награды'
          : 'владелец завершает проект бесконечно: каждый клик = +reputationEvent и рост IP-score (awardBulk без дедупа) — ферма доверия'),
    );
  });

  test('ADV-C105: state machine /transition — владелец API-проекта не может сделать ВАЛИДНЫЙ переход (role owner ≠ FOUNDER)', async () => {
    const { POST: projectsPOST } = await import('@/app/api/projects/route');
    const { POST: transitionPOST } = await import('@/app/api/projects/[id]/transition/route');

    const created = await callRoute(projectsPOST, 'http://localhost/api/projects', {
      method: 'POST',
      headers: sessionHeaders(tok3),
      body: JSON.stringify({ title: 'ADV-C transition', description: 'state machine' }),
    });
    expect(created.status).toBe(201);
    const { project } = (await created.json()) as { project: { id: string } };

    // recruiting → нормализуется в PROPOSAL; PROPOSAL → CANCELLED разрешён PROJECT_TRANSITIONS
    const t = await callRoute(
      transitionPOST,
      `http://localhost/api/projects/${project.id}/transition`,
      {
        method: 'POST',
        headers: sessionHeaders(tok3),
        params: { id: project.id },
        body: JSON.stringify({ status: 'CANCELLED' }),
      },
    );
    const body = (await t.json()) as { error?: string };
    // Защита = валидный переход владельца применяется (200)
    const blocked = t.status === 200;
    verdict(
      'ADV-C105',
      blocked,
      `владелец (member.role='owner' — так пишет POST /api/projects и seed) делает разрешённый переход PROPOSAL→CANCELLED → ${t.status} «${body.error ?? ''}»; ` +
        (blocked
          ? 'переход применился'
          : '403 «Только основатель»: transition требует role FOUNDER, который НИГДЕ не создаётся (rg по src) — машина состояний PROJ мертва для всех проектов, созданных через API'),
    );
  });

  test('ADV-C106: MAX_PROPOSAL_PER_USER=3 (константа «спам-фильтр») не enforced — 4 проекта создаются без отказа', async () => {
    const { POST: projectsPOST } = await import('@/app/api/projects/route');
    const statuses: number[] = [];
    for (let i = 0; i < 4; i++) {
      const res = await callRoute(projectsPOST, 'http://localhost/api/projects', {
        method: 'POST',
        headers: sessionHeaders(tok3),
        body: JSON.stringify({ title: `ADV-C spam cap ${i}`, description: 'cap probe' }),
      });
      statuses.push(res.status);
    }
    const created = statuses.filter((s) => s === 201).length;
    const blocked = created <= MAX_PROPOSAL_PER_USER;
    verdict(
      'ADV-C106',
      blocked,
      `MAX_PROPOSAL_PER_USER=${MAX_PROPOSAL_PER_USER} объявлен в src/lib/projects/constants.ts:159, но rg показывает: ноль использований; ` +
        `4 POST подряд → [${statuses.join(', ')}] — создано ${created}; ` +
        (blocked ? 'кап сработал' : 'кап «спам-фильтр» — мёртвая константа, безлимитное создание проектов'),
    );
  });
});

// =============================================================================
// Вектор 3: стаб wallet/transfer = 410 TRUST_NOT_CURRENCY на ВСЕ методы
// (регресс-проба: GET/POST/PUT/PATCH/DELETE).
// =============================================================================
describe('ADV-C: wallet/transfer стаб', () => {
  test('ADV-C107: все 5 методов /api/wallet/transfer должны вернуть 410 TRUST_NOT_CURRENCY', async () => {
    const wt = await import('@/app/api/wallet/transfer/route');
    const deviations: string[] = [];
    for (const method of ['GET', 'POST', 'PUT', 'DELETE'] as const) {
      const handler = wt[method];
      if (typeof handler !== 'function') {
        deviations.push(`${method}: хендлер не экспортирован`);
        continue;
      }
      const res = await callRoute(
        handler,
        'http://localhost/api/wallet/transfer',
        { method, headers: sessionHeaders(DEAD_SESSION) },
      );
      const body = (await res.json()) as { code?: string };
      if (res.status !== 410 || body?.code !== 'TRUST_NOT_CURRENCY') {
        deviations.push(`${method}→${res.status} code=${body?.code ?? '—'}`);
      }
    }
    if (typeof (wt as Record<string, unknown>).PATCH !== 'function') {
      deviations.push('PATCH: хендлер не экспортирован (в Next это 405, а не 410-стаб)');
    }
    verdict(
      'ADV-C107',
      deviations.length === 0,
      deviations.length === 0
        ? 'GET/POST/PUT/DELETE/PATCH → 410 TRUST_NOT_CURRENCY, стаб полон'
        : `регресс стаба TRUST_NOT_CURRENCY: ${deviations.join('; ')}`,
    );
  });
});

// =============================================================================
// Вектор 5: несуществующие/мусорные ID — обязаны быть 404/401, не 500.
// =============================================================================
describe('ADV-C: несуществующие ID', () => {
  test('ADV-C108: мусорные id ("x".repeat(200), "999…") на projects/claims/birthday-plans → 404/401, не 500', async () => {
    const garbage = 'x'.repeat(200);
    const longNum = '9'.repeat(64);

    const { GET: projectGET } = await import('@/app/api/projects/[id]/route');
    const { PATCH: claimPATCH, DELETE: claimDELETE, GET: claimGET } = await import(
      '@/app/api/claims/[id]/route'
    );
    const { PATCH: planPATCH } = await import('@/app/api/birthday-plans/[id]/route');

    const failures: string[] = [];
    const expectStatus = async (label: string, res: Response, allowed: number[]) => {
      if (!allowed.includes(res.status)) failures.push(`${label}→${res.status}`);
    };

    // projects/[id] GET без auth — мусорный 200-символьный id
    await expectStatus(
      'projects GET x200',
      await callRoute(projectGET, `http://localhost/api/projects/${garbage}`, {
        params: { id: garbage },
      }),
      [404],
    );
    // claims: PATCH/DELETE несуществующий + мусорный
    await expectStatus(
      'claims PATCH 999',
      await callRoute(claimPATCH, `http://localhost/api/claims/${longNum}`, {
        method: 'PATCH',
        headers: sessionHeaders(tok2),
        params: { id: longNum },
        body: JSON.stringify({ title: 'nope' }),
      }),
      [404],
    );
    await expectStatus(
      'claims DELETE 999',
      await callRoute(claimDELETE, `http://localhost/api/claims/${longNum}`, {
        method: 'DELETE',
        headers: sessionHeaders(tok2),
        params: { id: longNum },
      }),
      [404],
    );
    // birthday-plans PATCH чужой/несуществующий
    await expectStatus(
      'birthday-plans PATCH 999',
      await callRoute(planPATCH, `http://localhost/api/birthday-plans/${longNum}`, {
        method: 'PATCH',
        headers: sessionHeaders(tok2),
        params: { id: longNum },
        body: JSON.stringify({ status: 'done' }),
      }),
      [404],
    );
    // мёртвая сессия → 401 (а не 500)
    await expectStatus(
      'claims GET dead-session',
      await callRoute(claimGET, `http://localhost/api/claims/${longNum}`, {
        headers: sessionHeaders(DEAD_SESSION),
        params: { id: longNum },
      }),
      [401],
    );

    verdict(
      'ADV-C108',
      failures.length === 0,
      failures.length === 0
        ? 'все мусорные id → 404/401, 500 нигде нет; notes: /api/news/[id] и /api/notifications/[id] как отдельные роуты не существуют (нет поверхности)'
        : `на мусорных id получены не-404/401 ответы (устойчивость сломана): ${failures.join('; ')}`,
    );
  });

  test('ADV-C109: PATCH join в несуществующий проект — обязан быть 404, фактически 500/успех (FK/сирота)', async () => {
    const { PATCH: projectPATCH } = await import('@/app/api/projects/[id]/route');
    const bogus = 'adv-c-nonexistent-project-000';
    const res = await callRoute(
      projectPATCH,
      `http://localhost/api/projects/${bogus}`,
      {
        method: 'PATCH',
        headers: sessionHeaders(tok2),
        params: { id: bogus },
        body: JSON.stringify({ action: 'join' }),
      },
    );
    const blocked = res.status === 404;
    verdict(
      'ADV-C109',
      blocked,
      `PATCH /api/projects/{bogus} action=join → ${res.status}; ветка join делает projectMember.create без проверки существования проекта: ` +
        (blocked
          ? '404 — проект проверяется'
          : res.status === 500
            ? '500 из-за необработанной FK-ошибки Prisma (P2003 не смаппен) — мусорный id роняет роут вместо 404'
            : 'запись создалась — участник «присоединился» к несуществующему проекту (сирота в БД)'),
    );
  });
});

// =============================================================================
// Вектор 7: лимиты/переполнения — граница размера и мусорный JSON.
// =============================================================================
describe('ADV-C: устойчивость', () => {
  test('ADV-C110: POST /api/projects с title 10KB — должен быть 422, не 500', async () => {
    const { POST: projectsPOST } = await import('@/app/api/projects/route');
    const res = await callRoute(projectsPOST, 'http://localhost/api/projects', {
      method: 'POST',
      headers: sessionHeaders(tok3),
      body: JSON.stringify({ title: 'Ж'.repeat(10_000), description: 'oversize' }),
    });
    const blocked = res.status === 422;
    verdict(
      'ADV-C110',
      blocked,
      `title 10000 символов → ${res.status}; ` +
        (blocked
          ? '422 (max 200) — граница удержана'
          : 'не-422 на границе размера — валидация длины дырявая/упала'),
    );
    expect(res.status).toBe(422);
  });

  test('ADV-C111: POST /api/projects с битым JSON — должен быть 400, фактически 500', async () => {
    const { POST: projectsPOST } = await import('@/app/api/projects/route');
    const res = await callRoute(projectsPOST, 'http://localhost/api/projects', {
      method: 'POST',
      headers: sessionHeaders(tok3),
      body: '{"title": oops-no-json',
    });
    const blocked = res.status === 400;
    verdict(
      'ADV-C111',
      blocked,
      `битый JSON в POST /api/projects → ${res.status}; ` +
        (blocked
          ? '400 — корректный разбор'
          : '500 «Ошибка создания проекта»: req.json() вне отдельного catch — синтакс-ошибка клиента роняет серверную ветку (withRoute-роуты дают 400, legacy — нет)'),
    );
  });
});

// =============================================================================
// Вектор 4: гонка — два параллельных join в одно сообщество одним юзером.
// Защита: pre-check + @@unique([communityId, userId]) → ровно 1 участник.
// =============================================================================
describe('ADV-C: гонки', () => {
  test('ADV-C112: Promise.all двух join — дублей быть не должно, ровно один 200 и membersCount+1', async () => {
    const slug = `adv-c-race-${Date.now()}`;
    const community = await db.community.create({
      data: {
        name: 'ADV-C Race',
        slug,
        description: 'гонка join',
        ownerId: u4.id,
        minIpScore: 0,
        visibility: 'public',
      },
    });
    const { POST: joinPOST } = await import('@/app/api/communities/[slug]/join/route');
    const [r1, r2] = await Promise.all([
      callRoute(joinPOST, `http://localhost/api/communities/${slug}/join`, {
        method: 'POST',
        headers: sessionHeaders(tok4),
        params: { slug },
      }),
      callRoute(joinPOST, `http://localhost/api/communities/${slug}/join`, {
        method: 'POST',
        headers: sessionHeaders(tok4),
        params: { slug },
      }),
    ]);
    const rows = await db.communityMember.count({ where: { communityId: community.id } });
    const after = await db.community.findUnique({ where: { id: community.id } });
    const okCount = [r1.status, r2.status].filter((s) => s === 200).length;
    const rejOk = [r1.status, r2.status].some((s) => s === 409 || s === 400);
    const blocked = rows === 1 && (after?.membersCount ?? 0) === 1 && okCount === 1 && rejOk;
    verdict(
      'ADV-C112',
      blocked,
      `два параллельных POST join одним юзером → ${r1.status}/${r2.status}, строк member=${rows}, membersCount=${after?.membersCount}; ` +
        (blocked
          ? 'уникальность удержала гонку: один вход, второй 409, счётчик не разъехался'
          : 'гонка дала двойное создание или рассинхрон membersCount — конкурентность ломает целостность'),
    );
  });
});

// =============================================================================
// Вектор 9: опережение видимости — скрытый (STEALTH) проект утекает.
// Список /api/projects не фильтрует visibility; GET /api/projects/[id] вообще без auth.
// =============================================================================
describe('ADV-C: утечка скрытого', () => {
  test('ADV-C113: STEALTH-проект виден постороннему юзеру в списке /api/projects', async () => {
    const stealth = await db.project.create({
      data: {
        title: 'ADV-C STEALTH секретный',
        description: 'видимость STEALTH — только по приглашению',
        ownerId: u5.id,
        status: 'recruiting',
        visibility: 'STEALTH',
        budget: 999999,
      },
    });
    const { GET: projectsGET } = await import('@/app/api/projects/route');
    // legacy-роут читает req.nextUrl — подкладываем заглушку (см. reqWithQuery)
    const req = new Request('http://localhost/api/projects', {
      headers: sessionHeaders(tok4), // посторонний
    });
    Object.assign(req, { nextUrl: new URL('http://localhost/api/projects') });
    const res = await projectsGET(req as never);
    expect(res.status).toBe(200);
    const { projects } = (await res.json()) as { projects: Array<{ id: string }> };
    const leaked = projects.some((p) => p.id === stealth.id);
    verdict(
      'ADV-C113',
      !leaked,
      leaked
        ? `STEALTH-проект ${stealth.id} (u5) отдался постороннему u4 в списке: GET /api/projects не фильтрует visibility (where = только status) — критичная утечка скрытых проектов с бюджетом`
        : 'скрытый проект в списке не виден',
    );
  });

  test('ADV-C114: GET /api/projects/[id] STEALTH-проекта БЕЗ сессии → должен быть 401/404, фактически 200', async () => {
    const stealth = await db.project.create({
      data: {
        title: 'ADV-C STEALTH no-auth',
        description: 'чтение без сессии',
        ownerId: u5.id,
        status: 'recruiting',
        visibility: 'STEALTH',
      },
    });
    const { GET: projectGET } = await import('@/app/api/projects/[id]/route');
    const res = await callRoute(
      projectGET,
      `http://localhost/api/projects/${stealth.id}`,
      { params: { id: stealth.id } }, // ни куки, ни Bearer
    );
    const blocked = res.status === 401 || res.status === 404;
    verdict(
      'ADV-C114',
      blocked,
      `анонимный GET /api/projects/${stealth.id} (visibility=STEALTH) → ${res.status}; ` +
        (blocked
          ? 'анонимный доступ закрыт'
          : 'роут вообще не вызывает getUserFromRequest: любой аноним читает полный проект, включая STEALTH/PRIVATE, с составом команды'),
    );
  });
});

// =============================================================================
// Вектор 10: повторное использование одноразового (email verify-токен).
// =============================================================================
describe('ADV-C: одноразовость', () => {
  test('ADV-C115: verify-email токен срабатывает один раз; второй клик должен отказать', async () => {
    const { createEmailVerificationToken } = await import(
      '@/lib/services/verification-token'
    );
    const { GET: verifyGET } = await import('@/app/api/auth/verify-email/route');
    const { token } = await createEmailVerificationToken(u5.id);
    const url = `http://localhost/api/auth/verify-email?token=${token}`;
    const r1 = await verifyGET(reqWithQuery(url));
    const r2 = await verifyGET(reqWithQuery(url));
    const left = await db.verificationToken.count({ where: { userId: u5.id } });
    const blocked = r1.status === 302 && r2.status === 400 && left === 0;
    verdict(
      'ADV-C115',
      blocked,
      `первый клик → ${r1.status} (ожидаем 302), повторный → ${r2.status} (ожидаем 400), токенов в БД осталось ${left}; ` +
        (blocked
          ? 'одноразовость подтверждена (токен удалён атомарно с подтверждением)'
          : 'токен многоразовый/не удаляется — повторное использование одноразового возможно'),
    );
  });
});

// =============================================================================
// Вектор 8: health/метрики/корень.
// =============================================================================
describe('ADV-C: инфра-поверхность', () => {
  test('ADV-C116: /api/health → 200/503; /api/metrics без auth → 401/403; /api → 200 json', async () => {
    const { GET: healthGET } = await import('@/app/api/health/route');
    const { GET: metricsGET } = await import('@/app/api/metrics/route');
    const { GET: rootGET } = await import('@/app/api/route');

    const h = await callRoute(healthGET, 'http://localhost/api/health');
    const m = await callRoute(metricsGET, 'http://localhost/api/metrics');
    const r = await callRoute(rootGET, 'http://localhost/api/');

    const healthOk = h.status === 200 || h.status === 503; // деградация допустима, 500 — нет
    const metricsDenied = m.status === 401 || m.status === 403;
    const rootOk = r.status === 200;
    const blocked = healthOk && metricsDenied && rootOk;

    let healthBody: Record<string, unknown> = {};
    try {
      healthBody = (await h.json()) as Record<string, unknown>;
    } catch {
      /* ignore */
    }

    verdict(
      'ADV-C116',
      blocked,
      `health=${h.status} (db=${String(healthBody.db)}), metrics без auth=${m.status}, /api=${r.status}; ` +
        (blocked
          ? 'инфра-поверхность ведёт себя по контракту (health не 500, метрики закрыты, корень отвечает)'
          : 'нарушение контракта инфра-эндпоинтов (500 на health / открытые метрики / падение корня)'),
    );
    expect(healthOk).toBe(true);
    expect(metricsDenied).toBe(true);
    expect(rootOk).toBe(true);
  });
});
