// =============================================================================
// ADV-B (adversarial agent B) — инъекции и валидация входа. Red-team.
// Цель: ДОКАЗАТЬ, что BizON ломается. Ничего не чиним: EXPLOITED = красный тест.
//
// Протокол: BLOCKED — защита сработала (тест зелёный); EXPLOITED — атака
// успешна (verdict бросает → тест красный = доказательство).
//
// Покрытие проб:
//   ADV-B101  zod-обход: тело без обязательных полей / пустое тело → 400
//   ADV-B102  zod-обход: неправильные типы (число, массив, deep-nested, объекты в tags)
//   ADV-B103  100KB-строки + prototype pollution (__proto__/constructor через JSON.parse)
//   ADV-B104  Prisma raw-SQL: SQL-инъекция через q + проверка целостности БД
//             (статически: rg '$queryRaw|$executeRaw|queryRawUnsafe' по src/ → 0 совпадений)
//   ADV-B105  Prisma where-инъекция: toUserId: {"not":null} — объект вместо скаляра
//   ADV-B106  не-JSON тело на schema-роутах → 400 (+ auth-гейт до парсинга тела)
//   ADV-B107  Роуты ВНЕ withRoute: POST /api/projects — не-JSON и не-скалярный title → 500
//   ADV-B108  Числовые яды: ?limit=abc → NaN → unhandled 500 (GET /api/posts, /api/search)
//   ADV-B109  Stored XSS: <script>/<img onerror>/javascript: в постах и комментариях
//   ADV-B110  Path traversal: /api/c/[token], /api/p/[token]: ../../, %2e%2e%2f, \0, file:
//   ADV-B111  Unicode: RTL-override/zero-width/ZWJ имя — регистрация/профиль не падают
//   ADV-B112  POST /api/events (pro): javascript:-URL, maxParticipants=-100, title 100KB
//
// Изоляция: helpers.ts копирует db/custom.db во временную папку (DATABASE_URL).
// Прогон: cd /home/z/my-project && bun test adversarial/adv-injection.test.ts
// =============================================================================
import { verdict, DEAD_SESSION, sessionHeaders, callRoute, cleanupAdvDb } from './helpers';

import { afterAll, beforeAll, describe, test } from 'bun:test';

let token = '';
let userId = '';

const JSON_H = (t: string) => ({ ...sessionHeaders(t), 'content-type': 'application/json' });

/**
 * callRoute для СЫРЫХ роутов (вне withRoute): они читают req.nextUrl (NextRequest),
 * которого нет у plain Request из helpers.callRoute. Эмуляция Next-окружения —
 * чиним харнесс, не код. Для withRoute-роутов используем helpers.callRoute как есть.
 */
async function callNext(
  // (...args: never[]) — контравариантная совместимость с любым хендлером
  handler: (...args: never[]) => Response | Promise<Response>,
  url: string,
  opts: { method?: string; headers?: Record<string, string>; body?: string; params?: Record<string, string> } = {},
): Promise<Response> {
  const { NextRequest } = await import('next/server');
  const req = new NextRequest(url, {
    method: opts.method ?? (opts.body ? 'POST' : 'GET'),
    headers: opts.headers,
    body: opts.body,
  } as unknown as ConstructorParameters<typeof NextRequest>[1]);
  const ctx = opts.params ? { params: Promise.resolve(opts.params) } : undefined;
  return await (
    handler as unknown as (req: Request, ctx?: { params?: Promise<Record<string, string>> }) => Promise<Response>
  )(req as unknown as Request, ctx);
}

beforeAll(async () => {
  // Валидный юзер + сессия — как в tests/w1.test.ts (registerUser + db.session.create)
  const { registerUser } = await import('@/lib/auth');
  const { db } = await import('@/lib/db');
  const { user } = await registerUser({
    email: `adv-b-attacker-${Date.now()}@bizon.test`,
    password: 'AdvB-Passw0rd!x',
    name: 'ADV-B Attacker',
  });
  userId = user.id;
  token = `advb-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  await db.session.create({
    data: { userId: user.id, token, expiresAt: new Date(Date.now() + 3600_000) },
  });
});

afterAll(cleanupAdvDb);

describe('ADV-B: injection / input validation', () => {
  test('ADV-B101 — zod-обход: missing required fields и пустое тело (POST /api/posts)', async () => {
    const { POST } = await import('@/app/api/posts/route');
    const r1 = await callRoute(POST, 'http://localhost/api/posts', {
      method: 'POST',
      headers: JSON_H(token),
      body: JSON.stringify({ type: 'regular', tags: ['no-content'] }), // content отсутствует
    });
    const r2 = await callRoute(POST, 'http://localhost/api/posts', {
      method: 'POST',
      headers: JSON_H(token),
      body: '', // пустое тело
    });
    const blocked = r1.status === 400 && r2.status === 400;
    verdict(
      'ADV-B101',
      blocked,
      `POST /api/posts без content → ${r1.status}; пустое тело → ${r2.status} (оба должны быть 400)`,
    );
  });

  test('ADV-B102 — zod-обход: неправильные типы (число/массив/deep-nested/объекты в tags)', async () => {
    const { POST } = await import('@/app/api/posts/route');
    const bodies = [
      JSON.stringify({ content: 12345 }), // число вместо строки
      JSON.stringify(['content-as-array']), // массив вместо объекта
      JSON.stringify({ content: { deep: { nested: { x: 1 } } } }), // вложенный объект
      JSON.stringify({ content: 'ok', tags: [{ inject: 1 }, ['nested']] }), // объекты внутри массива
    ];
    const statuses: number[] = [];
    for (const body of bodies) {
      const r = await callRoute(POST, 'http://localhost/api/posts', {
        method: 'POST',
        headers: JSON_H(token),
        body,
      });
      statuses.push(r.status);
    }
    const blocked = statuses.every((s) => s === 400);
    verdict(
      'ADV-B102',
      blocked,
      `4 пробы не-скалярных типов на POST /api/posts → [${statuses.join(', ')}] (все должны быть 400)`,
    );
  });

  test('ADV-B103 — 100KB-строка + prototype pollution (__proto__/constructor)', async () => {
    const { POST } = await import('@/app/api/posts/route');

    // (1) 100KB content — zod max 5000 должен отклонить
    const big = 'A'.repeat(102400);
    const r1 = await callRoute(POST, 'http://localhost/api/posts', {
      method: 'POST',
      headers: JSON_H(token),
      body: JSON.stringify({ content: big }),
    });

    // (2) prototype pollution: сырой JSON с __proto__/constructor как own-свойствами
    //     (JSON.parse в withRoute создаёт own __proto__; zod обязан вырезать)
    const protoBody =
      '{"content":"ADV-B103 proto probe post","__proto__":{"isAdmin":true,"ipScore":9999},"constructor":{"prototype":{"hacked":true}}}';
    const r2 = await callRoute(POST, 'http://localhost/api/posts', {
      method: 'POST',
      headers: JSON_H(token),
      body: protoBody,
    });

    let protoSafe = false;
    let detail2 = `status ${r2.status}`;
    if (r2.status === 201) {
      const j: any = await r2.json();
      const polluted =
        (Object.prototype as any).isAdmin !== undefined ||
        (Object.prototype as any).hacked !== undefined ||
        (Object.prototype as any).ipScore === 9999;
      const leaked =
        JSON.stringify(j).includes('isAdmin') || JSON.stringify(j).includes('hacked');
      protoSafe = !polluted && !leaked;
      detail2 = `201, prototype polluted=${polluted}, ключи утекли в ответ=${leaked}`;
    }

    const blocked = r1.status === 400 && protoSafe;
    verdict(
      'ADV-B103',
      blocked,
      `100KB content → ${r1.status} (нужно 400); proto-pollution: ${detail2} (нужно: нет загрязнения Object.prototype, ключи вырезаны)`,
    );
  });

  test('ADV-B104 — SQL-инъекция через q (raw SQL отсутствует) + целостность User-таблицы', async () => {
    const { GET } = await import('@/app/api/search/route');
    const { db } = await import('@/lib/db');
    const payload = "'; DROP TABLE User;--";
    const r = await callNext(
      GET,
      `http://localhost/api/search?q=${encodeURIComponent(payload)}`,
      { headers: sessionHeaders(token) },
    );
    const j: any = await r.json();
    // Целостность: после атаки user-таблица на месте, читается, записи есть
    const stillWorks = await db.user.findMany({ take: 1, select: { id: true } });
    const count = await db.user.count();
    const blocked =
      r.status === 200 && Array.isArray(stillWorks) && stillWorks.length === 1 && count > 0;
    verdict(
      'ADV-B104',
      blocked,
      `GET /api/search?q="'; DROP TABLE User;--" → ${r.status}, echo=${JSON.stringify(
        j?.query,
      )}, после атаки User-таблица читается (findMany ok, count=${count}) — raw SQL в src/ отсутствует ($queryRaw=0)`,
    );
  });

  test('ADV-B105 — Prisma where-инъекция: toUserId объектом {"not":null} (POST /api/messages)', async () => {
    const { POST } = await import('@/app/api/messages/route');
    const r = await callRoute(POST, 'http://localhost/api/messages', {
      method: 'POST',
      headers: JSON_H(token),
      body: JSON.stringify({ toUserId: { not: null }, content: 'ADV-B105 where-injection' }),
    });
    // bizonId-схема (regex whitelist) обязана отбить объект → 400
    const blocked = r.status === 400;
    verdict(
      'ADV-B105',
      blocked,
      `POST /api/messages {"toUserId":{"not":null}} → ${r.status} (объект вместо скаляра должен быть 400, не фильтр/500)`,
    );
  });

  test('ADV-B106 — не-JSON тело на schema-роутах → 400; auth-гейт раньше парсинга тела', async () => {
    const { POST } = await import('@/app/api/posts/route');
    const { POST: postMsg } = await import('@/app/api/messages/route');

    const r1 = await callRoute(POST, 'http://localhost/api/posts', {
      method: 'POST',
      headers: JSON_H(token),
      body: 'not json{{{',
    });
    const r2 = await callRoute(postMsg, 'http://localhost/api/messages', {
      method: 'POST',
      headers: JSON_H(token),
      body: 'not json{{{',
    });
    // Контроль: мусорная сессия отклоняется (401) ещё до разбора тела
    const r0 = await callRoute(POST, 'http://localhost/api/posts', {
      method: 'POST',
      headers: { ...sessionHeaders(DEAD_SESSION), 'content-type': 'application/json' },
      body: 'not json{{{',
    });
    const blocked = r1.status === 400 && r2.status === 400 && r0.status === 401;
    verdict(
      'ADV-B106',
      blocked,
      `"not json{{{" на /api/posts → ${r1.status}, /api/messages → ${r2.status}; DEAD_SESSION → ${r0.status} (нужно 400/400/401, без 500 и утечки стека)`,
    );
  });

  test('ADV-B107 — роуты вне withRoute: POST /api/projects — не-JSON и не-скалярный title → 500', async () => {
    const { POST } = await import('@/app/api/projects/route');
    const r1 = await callNext(POST, 'http://localhost/api/projects', {
      method: 'POST',
      headers: JSON_H(token),
      body: 'not json{{{', // ожидался 400 как на schema-роутах
    });
    const r2 = await callNext(POST, 'http://localhost/api/projects', {
      method: 'POST',
      headers: JSON_H(token),
      body: JSON.stringify({ title: 12345, description: 'ADV-B107 wrong type' }), // title-число
    });
    const blocked = r1.status === 400 && r2.status >= 400 && r2.status < 500;
    verdict(
      'ADV-B107',
      blocked,
      `POST /api/projects (вне withRoute): не-JSON → ${r1.status} (эталон withRoute = 400); title:12345 → ${r2.status} (нужен 4xx, не 500)`,
    );
  });

  test('ADV-B108 — числовые яды: ?limit=abc → NaN → unhandled 500 (GET /api/posts, /api/search)', async () => {
    const results: string[] = [];
    let blocked = true;

    const { GET: getPosts } = await import('@/app/api/posts/route');
    try {
      const r = await callNext(getPosts, 'http://localhost/api/posts?limit=abc', {
        headers: sessionHeaders(token),
      });
      results.push(`posts=${r.status}`);
      if (r.status >= 500) blocked = false;
    } catch (e) {
      results.push(`posts=UNHANDLED_THROW(${(e as Error).name})`);
      blocked = false; // необработанное исключение = сырой 500 без withRoute-маппинга
    }

    const { GET: getSearch } = await import('@/app/api/search/route');
    try {
      const r = await callNext(getSearch, 'http://localhost/api/search?q=ok&limit=abc', {
        headers: sessionHeaders(token),
      });
      results.push(`search=${r.status}`);
      if (r.status >= 500) blocked = false;
    } catch (e) {
      results.push(`search=UNHANDLED_THROW(${(e as Error).name})`);
      blocked = false;
    }

    verdict(
      'ADV-B108',
      blocked,
      `limit=abc (NaN в take/skip) → ${results.join('; ')} — числовой параметр без валидации не должен ронять хендлер`,
    );
  });

  test('ADV-B109 — stored XSS: <script>/<img onerror> в посте и комментарии хранятся дословно', async () => {
    const { POST } = await import('@/app/api/posts/route');
    const { GET } = await import('@/app/api/posts/route');
    const { POST: postComment } = await import('@/app/api/posts/[id]/comment/route');
    // GET /api/posts — сырой роут (req.nextUrl) → callNext; withRoute-роуты → callRoute

    const xssPayload =
      '<script>alert("adv-b-xss")</script> <img src=x onerror=alert(1)> [javascript:alert(2)]';
    const r = await callRoute(POST, 'http://localhost/api/posts', {
      method: 'POST',
      headers: JSON_H(token),
      body: JSON.stringify({ content: xssPayload }),
    });

    let stored = false;
    let commentStored = false;
    let readback = false;
    let postId = '';
    if (r.status === 201) {
      const j: any = await r.json();
      postId = j?.post?.id ?? '';
      stored = (j?.post?.content ?? '').includes('<script>alert("adv-b-xss")</script>');
    }

    if (postId) {
      const rc = await callRoute(postComment, `http://localhost/api/posts/${postId}/comment`, {
        method: 'POST',
        headers: JSON_H(token),
        body: JSON.stringify({ content: '<img src=x onerror="alert(1)">' }),
        params: { id: postId },
      });
      commentStored = rc.status === 201;

      const rg = await callNext(GET, 'http://localhost/api/posts', {
        headers: sessionHeaders(token),
      });
      const list: any = await rg.json();
      const row = (list?.posts ?? []).find((p: any) => p.id === postId);
      readback =
        !!row &&
        row.content.includes('<img src=x onerror=alert(1)>') &&
        (row.comments ?? []).some((c: any) =>
          (c.content ?? '').includes('<img src=x onerror="alert(1)">'),
        );
    }

    // javascript:-URL в imageUrl — SSRF-гейт isUrlSafeForStorage должен отклонить (4xx)
    const ri = await callRoute(POST, 'http://localhost/api/posts', {
      method: 'POST',
      headers: JSON_H(token),
      body: JSON.stringify({ content: 'img probe', imageUrl: 'javascript:alert(document.cookie)' }),
    });
    const jsUrlBlocked = ri.status >= 400 && ri.status < 500;

    // payload хранится и возвращается дословно (пост + комментарий) = stored-XSS носитель
    // (рендер не проверялся здесь — medium «хранится несанитизированно»)
    const blocked = !(stored && commentStored && readback);
    verdict(
      'ADV-B109',
      blocked,
      `post content='<script>…' stored=${stored}, readback=${readback}, comment stored=${commentStored}; imageUrl 'javascript:' → ${ri.status} (отбит=${jsUrlBlocked}). Если EXPLOITED — payload хранится/возвращается БЕЗ санитизации → потенциальный stored XSS (рендер проверять отдельно, medium)`,
    );
  });

  test('ADV-B110 — path traversal в token-параметрах (/api/c/[token], /api/p/[token])', async () => {
    const { GET: getC } = await import('@/app/api/c/[token]/route');
    const { GET: getP } = await import('@/app/api/p/[token]/route');

    const traversalTokens = [
      '../../db/custom.db',
      '%2e%2e%2f%2e%2e%2fdb%2fcustom.db',
      'file:///etc/passwd',
      '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0db',
      '....//....//....//etc/passwd',
    ];
    const statuses: string[] = [];
    let blocked = true;

    for (const t of traversalTokens) {
      try {
        const r = await callRoute(getC, `http://localhost/api/c/x`, {
          headers: sessionHeaders(DEAD_SESSION), // публичный эндпоинт — cookie не важен
          params: { token: t },
        });
        statuses.push(`${t.slice(0, 12)}…=${r.status}`);
        if (r.status >= 500) blocked = false;
      } catch (e) {
        statuses.push(`${t.slice(0, 12)}…=UNHANDLED_THROW(${(e as Error).name})`);
        blocked = false;
      }
    }
    try {
      const r = await callRoute(getP, 'http://localhost/api/p/x', {
        params: { token: '../../' + 'db/custom.db'.padStart(20, '.') },
      });
      statuses.push(`p[../]=${r.status}`);
      if (r.status >= 500) blocked = false;
    } catch (e) {
      statuses.push(`p[../]=UNHANDLED_THROW(${(e as Error).name})`);
      blocked = false;
    }

    verdict(
      'ADV-B110',
      blocked,
      `токены с ../ %2e%2e \\0 file: → ${statuses.join('; ')} — доступ к файлам/500 недопустимы (ожидаем 404)`,
    );
  });

  test('ADV-B111 — Unicode-имя (RTL-override/zero-width/ZWJ): регистрация и профиль не падают', async () => {
    const rtlName =
      '\u202E' + 'gnot-emаn' + '\u202C' + '\u200B'.repeat(10) + '👩‍💻'.repeat(2) + '\u200D' + 'z';
    const { db } = await import('@/lib/db');
    let blocked = true;
    let detail = '';

    try {
      // (1) библиотечный путь (registerUser — тот же write-path, что и HTTP-роут)
      const { registerUser } = await import('@/lib/auth');
      const { user } = await registerUser({
        email: `adv-b-uni-${Date.now()}@bizon.test`,
        password: 'AdvB-Passw0rd!x',
        name: rtlName,
      });
      const t2 = `advbuni-${Date.now()}`;
      await db.session.create({
        data: { userId: user.id, token: t2, expiresAt: new Date(Date.now() + 3600_000) },
      });
      const { GET: getMe } = await import('@/app/api/auth/me/route');
      const rMe = await callRoute(getMe, 'http://localhost/api/auth/me', {
        headers: sessionHeaders(t2),
      });
      const jMe: any = await rMe.json();
      // fix-adversarial: контракт обновлён после внедрения stripBidiControls
      // (bidi-spoofing защита). Безопасное поведение = имя сохранено БЕЗ
      // bidi-контролов/zero-width (кроме легитимных ZWJ/ZWNJ в emoji),
      // профиль не падает. Bidi-спуфинг должен быть вычищен.
      const BIDI = /[\u202A-\u202E\u2066-\u2069\u200E\u200F\u200B\uFEFF]/;
      const storedName: string = jMe?.user?.name ?? '';
      const meOk =
        rMe.status === 200 && storedName.length > 0 && !BIDI.test(storedName); // имя без bidi-контролов
      detail += `registerUser+me: me=${rMe.status}, bidiClean=${meOk}, stored="${storedName.slice(0, 24)}…"`;

      // (2) HTTP-роут: контроль (обычное имя) vs атака (RTL-имя).
      //     Вне Next request scope cookies() может кидать — сравниваем с контролем,
      //     чтобы не спутать ограничение окружения с реальным 500 от payload.
      const { POST: postRegister } = await import('@/app/api/auth/register/route');
      const ctrl = await callNext(postRegister, 'http://localhost/api/auth/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          email: `adv-b-ctrl-${Date.now()}@bizon.test`,
          password: 'AdvB-Passw0rd!x',
          name: 'ADV-B Control',
          acceptedTos: true,
        }),
      });
      const attack = await callNext(postRegister, 'http://localhost/api/auth/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          email: `adv-b-rtl-${Date.now()}@bizon.test`,
          password: 'AdvB-Passw0rd!x',
          name: rtlName,
          acceptedTos: true,
        }),
      });
      detail += `; HTTP register: ctrl=${ctrl.status}, rtl=${attack.status}`;

      if (ctrl.status >= 500) {
        // окружение: HTTP-роут недоступен вне Next scope — полагаемся на (1)
        detail += ' (control 500 → ограничение окружения, вердикт по (1))';
        blocked = meOk;
      } else {
        blocked = meOk && attack.status < 500;
      }
      if (meOk) detail += '; bidi-контролы вычищены stripBidiControls (bidi-spoofing закрыт)';
    } catch (e) {
      blocked = false;
      detail = `UNHANDLED_THROW: ${(e as Error).message.slice(0, 120)}`;
    }

    verdict(
      'ADV-B111',
      blocked,
      `Unicode-имя (${rtlName.length} симв., RTL+ZWSP+ZWJ-эмодзи) → ${detail}`,
    );
  });

  test('ADV-B112 — POST /api/events (pro): javascript:-URL, maxParticipants=-100, title 100KB — без zod хранится как есть', async () => {
    const { db } = await import('@/lib/db');
    await db.user.update({ where: { id: userId }, data: { subscriptionTier: 'pro' } });

    const { POST } = await import('@/app/api/events/route');
    const { GET } = await import('@/app/api/events/route');

    const r = await callNext(POST, 'http://localhost/api/events', {
      method: 'POST',
      headers: JSON_H(token),
      body: JSON.stringify({
        title: '<img src=x onerror=alert(3)> ' + 'A'.repeat(100_000),
        description: 'ADV-B112 validation-gap probe',
        startDate: '2027-01-01T10:00:00.000Z',
        imageUrl: 'javascript:alert(document.cookie)',
        maxParticipants: -100,
      }),
    });

    let blocked: boolean;
    let detail = `POST /api/events → ${r.status}`;
    if (r.status === 201) {
      const rg = await callNext(GET, 'http://localhost/api/events', {
        headers: sessionHeaders(token),
      });
      const list: any = await rg.json();
      const row = (list?.events ?? []).find((e: any) => e.maxParticipants === -100);
      const storedJsUrl = row?.imageUrl === 'javascript:alert(document.cookie)';
      const storedXssTitle = (row?.title ?? '').includes('<img src=x onerror=alert(3)>');
      const storedHuge = (row?.title ?? '').length > 100_000;
      blocked = !(row && storedJsUrl && storedXssTitle && storedHuge);
      detail += `; stored: jsUrl=${storedJsUrl}, xssTitle=${storedXssTitle}, titleLen=${
        (row?.title ?? '').length
      }, maxParticipants=-100=${!!row}`;
      detail +=
        ' — роут вне withRoute/zod: javascript:-URL и XSS-payload хранятся несанитизированно (stored-XSS риск, medium), лимитов длины/границ чисел нет';
    } else if (r.status >= 400 && r.status < 500) {
      blocked = true; // отбито — хорошо
    } else {
      blocked = false; // 500/throw на нестандартном, но валидном JSON
      detail += ' — 500 вместо 4xx/201';
    }

    verdict('ADV-B112', blocked, detail);
  });
});
