#!/bin/bash
# BizON — init-скрипт PostgreSQL (docker-entrypoint-initdb.d)
# Создаёт БД и пользователя из env при ПЕРВОЙ инициализации volume.
#
# Используемые переменные (все с фолбэками):
#   POSTGRES_USER / BIZON_DB_USER      (по умолчанию bizon)
#   POSTGRES_PASSWORD / BIZON_DB_PASSWORD (по умолчанию bizon)
#   POSTGRES_DB / BIZON_DB_NAME        (по умолчанию bizon)
#
# Монтируется в docker-compose.yml как:
#   ./init-postgres.sh:/docker-entrypoint-initdb.d/10-init-postgres.sh:ro
#
# Официальный образ postgres уже создаёт POSTGRES_USER/POSTGRES_DB; этот скрипт
# добаляет отдельного app-юзера и БД, если их имена отличаются (BIZON_DB_*),
# и выдаёт ему права.

set -euo pipefail

APP_USER="${BIZON_DB_USER:-${POSTGRES_USER:-bizon}}"
APP_PASSWORD="${BIZON_DB_PASSWORD:-${POSTGRES_PASSWORD:-bizon}}"
APP_DB="${BIZON_DB_NAME:-${POSTGRES_DB:-bizon}}"

echo ">>> init-postgres: user='${APP_USER}', db='${APP_DB}'"

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
  -- Пользователь приложения (если ещё не существует)
  DO \$\$
  BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${APP_USER}') THEN
      CREATE ROLE "${APP_USER}" LOGIN PASSWORD '${APP_PASSWORD}';
    ELSE
      ALTER ROLE "${APP_USER}" WITH LOGIN PASSWORD '${APP_PASSWORD}';
    END IF;
  END
  \$\$;

  -- База приложения (если ещё не существует)
  SELECT 'CREATE DATABASE "${APP_DB}" OWNER "${APP_USER}"'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${APP_DB}')\gexec

  -- Права
  GRANT ALL PRIVILEGES ON DATABASE "${APP_DB}" TO "${APP_USER}";
EOSQL

# GRANT на схему public для работы Prisma (migrate/push) в PG 15+
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$APP_DB" <<-EOSQL
  GRANT ALL ON SCHEMA public TO "${APP_USER}";
  ALTER SCHEMA public OWNER TO "${APP_USER}";
EOSQL

echo ">>> init-postgres: готово"
